# -*- coding: utf-8 -*-
"""
ARG subtype model: 100p Fusion teacher + multi-length DNA student
=================================================================

干净版修改目标：
- teacher：仍然只用 100p fusion embedding 训练；
- student：使用 60p + 70p + 80p + 90p + 100p DNA/NT embedding 共同训练；
- 测试：分别在 60p / 70p / 80p / 90p / 100p DNA embedding 上测试；
- 输出：每个长度的 fragment-level 和 base-ID-level 结果；
- checkpoint 保存格式保持和原代码一致：
    model_checkpoint.pth
    scaler_fusion.joblib
    scaler_dna.joblib
    subtype_encoder.joblib

推荐文件放在同一目录：
    1.100p_all_fusion_embedding_512_with_label.csv
    1.60p_ARG_DNA_with_label.csv
    1.70p_ARG_DNA_with_label.csv
    1.80p_ARG_DNA_with_label.csv
    1.90_ARG_DNA_with_label.csv
    1.100p_ARG_DNA_with_label.csv
    3.100p_all_Refined_embeddings_512.csv    # 可选
    train_set.csv
    test_set.csv
"""

import random
import copy
import multiprocessing as mp
from pathlib import Path
from collections import Counter
import re
import json
import time

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader, WeightedRandomSampler

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    classification_report,
)


# =========================
# 1. 配置
# =========================

BASE_DIR = Path(__file__).resolve().parent

FUSION_FILE = BASE_DIR / "1.100p_all_fusion_embedding_512_with_label.csv"
REFINED_FILE = BASE_DIR / "3.100p_all_Refined_embeddings_512.csv"

TRAIN_SPLIT_FILE = BASE_DIR / "train_set.csv"
TEST_SPLIT_FILE = BASE_DIR / "test_set.csv"

DNA_FILES = {
    "60p": BASE_DIR / "1.60p_ARG_DNA_with_label.csv",
    "70p": BASE_DIR / "1.70p_ARG_DNA_with_label.csv",
    "80p": BASE_DIR / "1.80p_ARG_DNA_with_label.csv",
    "90p": BASE_DIR / "1.90_ARG_DNA_with_label.csv",
    "100p": BASE_DIR / "1.100p_ARG_DNA_with_label.csv",
}

# 如果你的 90p 文件名是 1.90p_ARG_DNA_with_label.csv，这里会自动替换
DNA_FILE_ALTERNATIVES = {
    "90p": [
        BASE_DIR / "1.90_ARG_DNA_with_label.csv",
        BASE_DIR / "1.90p_ARG_DNA_with_label.csv",
    ],
}

TRAIN_LENGTHS = ["60p", "70p", "80p", "90p", "100p"]
TEST_LENGTHS = ["60p", "70p", "80p", "90p", "100p"]

OUTPUT_DIR = BASE_DIR / "multilen_nt_teacher_dna_student_outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id"
]

SUBTYPE_COL = "Subtype"
TYPE_COL = "Type"

SEED = 42
ENSEMBLE_SEEDS = [42]

BATCH_SIZE = 512
NUM_WORKERS = 0
PIN_MEMORY = True

# teacher
EPOCHS_TEACHER = 90
LR_TEACHER = 3e-4
PATIENCE_TEACHER = 25

# student
EPOCHS_STUDENT = 240
LR_STUDENT = 1.2e-4
PATIENCE_STUDENT = 40

WEIGHT_DECAY = 5e-5
MIN_DELTA = 1e-5

# 不再用 test set 做 early stopping
INTERNAL_VAL_RATIO = 0.12

FUSION_HIDDEN_DIM = 768
DNA_HIDDEN_DIM = 1024
EMBED_DIM = 512
NUM_RES_BLOCKS = 2
DROPOUT = 0.18

USE_ARCFACE = True
ARCFACE_MARGIN = 0.15
COSFACE_MARGIN = 0.18
LOGIT_SCALE = 28.0

LABEL_SMOOTHING = 0.002

USE_MILD_CLASS_WEIGHT = True
CLASS_WEIGHT_POWER = 0.18
CLASS_WEIGHT_CLIP_MIN = 0.85
CLASS_WEIGHT_CLIP_MAX = 1.50

USE_WEIGHTED_SAMPLER = True
SAMPLER_WEIGHT_POWER = 0.25
SAMPLER_CLIP_MIN = 0.70
SAMPLER_CLIP_MAX = 2.00

# teacher loss
LAMBDA_TEACHER_CE = 1.00
LAMBDA_TEACHER_SUPCON = 0.25
LAMBDA_TEACHER_REFINED_ANCHOR = 0.02

# multi-length student loss
# 对短片段不能过强 pair/KD，因此比原代码降低 pair 和 KD，保留 center alignment
LAMBDA_STUDENT_CE = 1.00
LAMBDA_STUDENT_SUPCON = 0.20
LAMBDA_PAIR_ALIGN = 0.08
LAMBDA_CENTER_ALIGN = 0.20
LAMBDA_LOGIT_KD = 0.08
LAMBDA_REFINED_ANCHOR = 0.02

SUPCON_TEMPERATURE = 0.10
KD_TEMPERATURE = 3.0

USE_REFINED_INIT = False
USE_REFINED_ANCHOR = True

USE_EMA = True
EMA_DECAY = 0.995

EVAL_EVERY_TEACHER = 2
EVAL_EVERY_STUDENT = 2

DEFAULT_MIN_PROB = 0.40
DEFAULT_MIN_MARGIN = 0.08

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# =========================
# 2. 工具函数
# =========================

def log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def dataloader_kwargs():
    if NUM_WORKERS and NUM_WORKERS > 0:
        return {
            "num_workers": NUM_WORKERS,
            "pin_memory": PIN_MEMORY,
            "persistent_workers": True,
            "prefetch_factor": 2,
        }
    return {
        "num_workers": 0,
        "pin_memory": PIN_MEMORY,
    }


def find_key_col(df, candidates=KEY_CANDIDATES):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def normalize_key(s):
    return s.astype(str).str.strip()


def normalize_base_id_one(x):
    """
    把 fragment ID 还原成原始 base ID。
    支持：
    gene_1 / gene_2 / gene_3 / gene_4 / gene_5
    gene_part1
    gene_frag1
    gene_fragment1
    gene_window1
    """
    s = str(x).strip()
    s = re.sub(r"\s+", "", s)

    patterns = [
        r"(_60p|_70p|_80p|_90p|_100p)?(_part)[0-9]+$",
        r"(_60pct|_70pct|_80pct|_90pct|_100pct)?(_part)[0-9]+$",
        r"(_p60|_p70|_p80|_p90|_p100)?(_part)[0-9]+$",
        r"(_frag)[0-9]+$",
        r"(_fragment)[0-9]+$",
        r"(_window)[0-9]+$",
        r"(_piece)[0-9]+$",
        r"(_segment)[0-9]+$",
        r"(_seg)[0-9]+$",
        r"(\.part)[0-9]+$",
        r"(-part)[0-9]+$",
        r"(_[1-5])$",
    ]

    for p in patterns:
        s2 = re.sub(p, "", s, flags=re.IGNORECASE)
        if s2 != s:
            return s2

    return s


def get_feature_cols(df):
    exclude_cols = {
        "KEY",
        "base_id",
        "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "protein_id", "Protein_id",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count",
        "Pred_Subtype",
        "Length",
        "Split",
        "split",
        "fold",
        "Fold",
        "part",
        "Part",
        "Unnamed: 0",
        "index",
        "Index",
        "label_id",
        "subtype_id",
        "type_id",
    }

    cols = []
    for c in df.columns:
        if c in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def l2_normalize_np(x, eps=1e-12):
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + eps)


def infer_type_from_subtype(subtype):
    s = str(subtype)
    if "__" in s:
        return s.split("__", 1)[0]
    return "Unknown"


def read_csv_auto(path):
    path = Path(path)
    if path.suffix.lower() in [".tsv", ".txt"]:
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def resolve_dna_file(length_name):
    if length_name in DNA_FILE_ALTERNATIVES:
        for p in DNA_FILE_ALTERNATIVES[length_name]:
            if p.exists():
                return p

    p = DNA_FILES[length_name]
    if p.exists():
        return p

    raise FileNotFoundError(f"Cannot find DNA file for {length_name}: {p}")


# =========================
# 3. 指标函数
# =========================

def compute_metrics(y_true, y_pred):
    if len(y_true) == 0:
        return {
            "sample_count": 0,
            "subtype_count": 0,
            "ACC": np.nan,
            "WEIGHTED_PRECISION": np.nan,
            "WEIGHTED_RECALL": np.nan,
            "WEIGHTED_F1": np.nan,
            "MACRO_PRECISION": np.nan,
            "MACRO_RECALL": np.nan,
            "MACRO_F1": np.nan,
            "MICRO_PRECISION": np.nan,
            "MICRO_RECALL": np.nan,
            "MICRO_F1": np.nan,
            "MCC": np.nan,
        }

    return {
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MICRO_PRECISION": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_RECALL": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_F1": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def print_metrics(title, metrics):
    print("\n" + title)
    for k, v in metrics.items():
        if isinstance(v, float) or isinstance(v, np.floating):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")


def per_class_metrics(y_true, y_pred, class_names, split_name):
    rows = []
    for cid in sorted(np.unique(y_true)):
        true_bin = (y_true == cid).astype(int)
        pred_bin = (y_pred == cid).astype(int)

        support = int(true_bin.sum())
        pred_count = int(pred_bin.sum())
        correct = int(((y_true == cid) & (y_pred == cid)).sum())

        rows.append({
            "split": split_name,
            SUBTYPE_COL: class_names[cid],
            "class_id": int(cid),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct,
            "ACC": correct / support if support > 0 else 0.0,
            "PRECISION": precision_score(true_bin, pred_bin, zero_division=0),
            "RECALL": recall_score(true_bin, pred_bin, zero_division=0),
            "F1": f1_score(true_bin, pred_bin, zero_division=0),
            "MCC": matthews_corrcoef(true_bin, pred_bin)
            if len(np.unique(true_bin)) > 1 or len(np.unique(pred_bin)) > 1
            else 0.0,
        })

    out = pd.DataFrame(rows)
    return out.sort_values(["support", SUBTYPE_COL], ascending=[False, True]).reset_index(drop=True)


def compute_type_metrics_from_df(df, split_name):
    y_true = df[TYPE_COL].astype(str).values
    y_pred = df["Pred_Type"].astype(str).values

    return {
        "split": split_name,
        "sample_count": int(len(df)),
        "type_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MICRO_PRECISION": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_RECALL": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_F1": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


# =========================
# 4. class weight / sampler
# =========================

def make_mild_class_weights(y, num_classes):
    counts = np.bincount(y, minlength=num_classes).astype(np.float32)
    counts = np.maximum(counts, 1.0)
    weights = (counts.mean() / counts) ** CLASS_WEIGHT_POWER
    weights = weights / weights.mean()
    weights = np.clip(weights, CLASS_WEIGHT_CLIP_MIN, CLASS_WEIGHT_CLIP_MAX)
    return weights.astype(np.float32)


def make_sampler_weights(y):
    counts = np.bincount(y).astype(np.float32)
    counts = np.maximum(counts, 1.0)
    class_w = (counts.mean() / counts) ** SAMPLER_WEIGHT_POWER
    class_w = class_w / class_w.mean()
    class_w = np.clip(class_w, SAMPLER_CLIP_MIN, SAMPLER_CLIP_MAX)
    return class_w[y].astype(np.float32)


def train_val_split_base_ids(train_split, val_ratio=0.12, seed=42):
    rng = np.random.default_rng(seed)

    train_ids = []
    val_ids = []

    for subtype, sub_df in train_split.groupby(SUBTYPE_COL):
        keys = sub_df["KEY"].astype(str).values.copy()
        rng.shuffle(keys)

        if len(keys) >= 5:
            n_val = max(1, int(round(len(keys) * val_ratio)))
            n_val = min(n_val, len(keys) - 1)
            val_ids.extend(keys[:n_val].tolist())
            train_ids.extend(keys[n_val:].tolist())
        else:
            train_ids.extend(keys.tolist())

    rng.shuffle(train_ids)
    rng.shuffle(val_ids)

    return set(train_ids), set(val_ids)


# =========================
# 5. 模型
# =========================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()

        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])

        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = nn.functional.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=30.0, margin=0.20, easy_margin=False):
        super().__init__()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = scale
        self.margin = margin
        self.easy_margin = easy_margin

        self.cos_m = np.cos(margin)
        self.sin_m = np.sin(margin)
        self.th = np.cos(np.pi - margin)
        self.mm = np.sin(np.pi - margin) * margin

    def forward(self, z, labels=None):
        z = nn.functional.normalize(z, p=2, dim=1)
        w = nn.functional.normalize(self.weight, p=2, dim=1)

        cosine = nn.functional.linear(z, w)

        if labels is None:
            return cosine * self.scale

        cosine_float = cosine.float()

        if USE_ARCFACE:
            sine = torch.sqrt(torch.clamp(1.0 - torch.pow(cosine_float, 2), min=1e-7))
            phi = cosine_float * self.cos_m - sine * self.sin_m

            if self.easy_margin:
                phi = torch.where(cosine_float > 0, phi, cosine_float)
            else:
                phi = torch.where(cosine_float > self.th, phi, cosine_float - self.mm)
        else:
            phi = cosine_float - COSFACE_MARGIN

        one_hot = torch.zeros_like(cosine_float)
        one_hot.scatter_(1, labels.view(-1, 1), 1.0)

        output = (one_hot * phi) + ((1.0 - one_hot) * cosine_float)
        output = output * self.scale
        return output

    def normalized_weight(self):
        return nn.functional.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    def __init__(self, fusion_dim, num_classes):
        super().__init__()
        self.encoder = Encoder(
            input_dim=fusion_dim,
            hidden_dim=FUSION_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )
        self.head = ArcMarginHead(EMBED_DIM, num_classes, scale=LOGIT_SCALE, margin=ARCFACE_MARGIN)

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


class DNAStudent(nn.Module):
    def __init__(self, dna_dim, num_classes):
        super().__init__()
        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=DNA_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )
        self.head = ArcMarginHead(EMBED_DIM, num_classes, scale=LOGIT_SCALE, margin=ARCFACE_MARGIN)

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


# =========================
# 6. Loss / EMA
# =========================

class LabelSmoothingCrossEntropy(nn.Module):
    def __init__(self, weight=None, smoothing=0.005):
        super().__init__()
        self.weight = weight
        self.smoothing = smoothing

    def forward(self, logits, target):
        return nn.functional.cross_entropy(
            logits,
            target,
            weight=self.weight,
            label_smoothing=self.smoothing
        )


def supervised_contrastive_loss(features, labels, temperature=0.10):
    device = features.device
    labels = labels.contiguous().view(-1, 1)

    mask = torch.eq(labels, labels.T).float().to(device)
    contrast = torch.matmul(features.float(), features.float().T) / temperature
    contrast = contrast - contrast.max(dim=1, keepdim=True).values.detach()

    logits_mask = torch.ones_like(mask) - torch.eye(mask.shape[0], device=device)
    mask = mask * logits_mask

    exp_contrast = torch.exp(contrast) * logits_mask
    log_prob = contrast - torch.log(exp_contrast.sum(dim=1, keepdim=True) + 1e-12)

    pos_count = mask.sum(dim=1)
    valid = pos_count > 0

    if valid.sum() == 0:
        return torch.tensor(0.0, device=device)

    mean_log_prob_pos = (mask * log_prob).sum(dim=1) / (pos_count + 1e-12)
    return -mean_log_prob_pos[valid].mean()


def cosine_pull_loss(z, target_z):
    z = nn.functional.normalize(z.float(), p=2, dim=1)
    target_z = nn.functional.normalize(target_z.float(), p=2, dim=1)
    return (1.0 - torch.sum(z * target_z, dim=1)).mean()


def kd_loss(student_logits, teacher_logits, temperature=3.0):
    s = nn.functional.log_softmax(student_logits.float() / temperature, dim=1)
    t = nn.functional.softmax(teacher_logits.float().detach() / temperature, dim=1)
    return nn.functional.kl_div(s, t, reduction="batchmean") * (temperature ** 2)


def refined_anchor_loss(head, refined_proto_t):
    if refined_proto_t is None:
        return torch.tensor(0.0, device=DEVICE)

    w = head.normalized_weight()
    r = nn.functional.normalize(refined_proto_t.float(), p=2, dim=1)

    if w.shape != r.shape:
        return torch.tensor(0.0, device=w.device)

    return (1.0 - torch.sum(w * r, dim=1)).mean()


class EMA:
    def __init__(self, model, decay=0.995):
        self.decay = decay
        self.shadow = {}
        self.backup = {}

        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.detach().clone()

    def update(self, model):
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = (1.0 - self.decay) * param.detach() + self.decay * self.shadow[name]

    def apply_shadow(self, model):
        self.backup = {}
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.backup[name] = param.detach().clone()
                param.data.copy_(self.shadow[name].data)

    def restore(self, model):
        for name, param in model.named_parameters():
            if param.requires_grad and name in self.backup:
                param.data.copy_(self.backup[name].data)
        self.backup = {}


# =========================
# 7. 数据读取
# =========================

def load_split_files():
    train_split = read_csv_auto(TRAIN_SPLIT_FILE)
    test_split = read_csv_auto(TEST_SPLIT_FILE)

    train_key = find_key_col(train_split)
    test_key = find_key_col(test_split)

    if train_key is None:
        raise ValueError("train_set.csv 中没有找到 key 列")
    if test_key is None:
        raise ValueError("test_set.csv 中没有找到 key 列")

    train_split = train_split.rename(columns={train_key: "KEY"})
    test_split = test_split.rename(columns={test_key: "KEY"})

    train_split["KEY"] = normalize_key(train_split["KEY"])
    test_split["KEY"] = normalize_key(test_split["KEY"])

    for df in [train_split, test_split]:
        for col in [SUBTYPE_COL, TYPE_COL]:
            if col in df.columns:
                df[col] = df[col].astype(str).str.strip().replace(["nan", "None", "NAN", ""], "Unknown")

    if SUBTYPE_COL not in train_split.columns or SUBTYPE_COL not in test_split.columns:
        raise ValueError("train_set.csv 和 test_set.csv 必须包含 Subtype 列")

    if TYPE_COL not in train_split.columns:
        train_split[TYPE_COL] = train_split[SUBTYPE_COL].map(infer_type_from_subtype)
    if TYPE_COL not in test_split.columns:
        test_split[TYPE_COL] = test_split[SUBTYPE_COL].map(infer_type_from_subtype)

    train_split = train_split.drop_duplicates(subset=["KEY"], keep="first").reset_index(drop=True)
    test_split = test_split.drop_duplicates(subset=["KEY"], keep="first").reset_index(drop=True)

    return train_split, test_split


def load_fusion_train(train_split):
    fusion_df = read_csv_auto(FUSION_FILE)
    fusion_key = find_key_col(fusion_df)

    if fusion_key is None:
        raise ValueError("FUSION_FILE 中没有找到 key 列")

    fusion_df = fusion_df.rename(columns={fusion_key: "KEY"})
    fusion_df["KEY"] = normalize_key(fusion_df["KEY"])

    if fusion_df["KEY"].duplicated().sum() > 0:
        print("Warning: fusion duplicated KEY. Keep first.")
        fusion_df.drop_duplicates(subset=["KEY"], keep="first", inplace=True)

    label_cols = ["KEY", SUBTYPE_COL, TYPE_COL]
    train_label = train_split[label_cols].copy()

    train_fusion = pd.merge(
        train_label,
        fusion_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    for col in [SUBTYPE_COL, TYPE_COL]:
        split_col = f"{col}_split"
        if split_col in train_fusion.columns:
            train_fusion[col] = train_fusion[split_col].astype(str).str.strip()

    train_fusion["base_id"] = train_fusion["KEY"].astype(str)

    print("Fusion train:", train_fusion.shape)

    if len(train_fusion) == 0:
        raise ValueError("train_fusion 为空，请检查 fusion 文件和 train_set 的 KEY 是否一致")

    return train_fusion.reset_index(drop=True)


def load_dna_by_length(train_split, test_split):
    train_label = train_split[["KEY", SUBTYPE_COL, TYPE_COL]].copy()
    test_label = test_split[["KEY", SUBTYPE_COL, TYPE_COL]].copy()

    train_subtype_map = dict(zip(train_label["KEY"], train_label[SUBTYPE_COL]))
    train_type_map = dict(zip(train_label["KEY"], train_label[TYPE_COL]))

    test_subtype_map = dict(zip(test_label["KEY"], test_label[SUBTYPE_COL]))
    test_type_map = dict(zip(test_label["KEY"], test_label[TYPE_COL]))

    train_dna_by_len = {}
    test_dna_by_len = {}
    used_files = {}

    for length_name in TRAIN_LENGTHS:
        dna_file = resolve_dna_file(length_name)
        used_files[length_name] = str(dna_file)

        print(f"\nLoading {length_name}: {dna_file.name}")
        dna_df = read_csv_auto(dna_file)

        dna_key = find_key_col(dna_df)
        if dna_key is None:
            raise ValueError(f"{dna_file.name} 中没有找到 key 列")

        dna_df = dna_df.rename(columns={dna_key: "KEY"})
        dna_df["KEY"] = normalize_key(dna_df["KEY"])
        dna_df["base_id"] = dna_df["KEY"].map(normalize_base_id_one)
        dna_df["Length"] = length_name

        if dna_df["KEY"].duplicated().sum() > 0:
            print(f"Warning: {length_name} duplicated KEY. Keep first.")
            dna_df.drop_duplicates(subset=["KEY"], keep="first", inplace=True)

        dna_df["Train_Subtype"] = dna_df["base_id"].map(train_subtype_map)
        dna_df["Train_Type"] = dna_df["base_id"].map(train_type_map)
        dna_df["Test_Subtype"] = dna_df["base_id"].map(test_subtype_map)
        dna_df["Test_Type"] = dna_df["base_id"].map(test_type_map)

        train_df = dna_df[dna_df["Train_Subtype"].notna()].copy()
        train_df[SUBTYPE_COL] = train_df["Train_Subtype"].astype(str)
        train_df[TYPE_COL] = train_df["Train_Type"].astype(str)
        train_df["Split"] = "train"

        test_df = dna_df[dna_df["Test_Subtype"].notna()].copy()
        test_df[SUBTYPE_COL] = test_df["Test_Subtype"].astype(str)
        test_df[TYPE_COL] = test_df["Test_Type"].astype(str)
        test_df["Split"] = "test"

        drop_cols = ["Train_Subtype", "Train_Type", "Test_Subtype", "Test_Type"]
        train_df.drop(columns=[c for c in drop_cols if c in train_df.columns], inplace=True)
        test_df.drop(columns=[c for c in drop_cols if c in test_df.columns], inplace=True)

        train_dna_by_len[length_name] = train_df.reset_index(drop=True)
        test_dna_by_len[length_name] = test_df.reset_index(drop=True)

        print(f"{length_name} train DNA:", train_df.shape)
        print(f"{length_name} test DNA:", test_df.shape)

    return train_dna_by_len, test_dna_by_len, used_files


def build_refined_proto(subtype_encoder):
    p = Path(REFINED_FILE)
    if not p.exists():
        print("Refined file not found. Skip refined.")
        return None, []

    refined_df = pd.read_csv(p)

    if SUBTYPE_COL not in refined_df.columns:
        print("Refined has no Subtype column. Skip refined.")
        return None, []

    refined_df[SUBTYPE_COL] = refined_df[SUBTYPE_COL].astype(str).str.strip()

    cols = get_feature_cols(refined_df)
    if len(cols) == 0:
        print("Refined has no numeric columns. Skip refined.")
        return None, []

    tmp = refined_df.copy()
    tmp[cols] = tmp[cols].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)

    grouped = tmp.groupby(SUBTYPE_COL)[cols].mean()

    missing = [c for c in subtype_encoder.classes_ if c not in grouped.index]
    if len(missing) > 0:
        print(f"Refined missing {len(missing)} subtype(s). Skip refined.")
        return None, cols

    proto = np.stack([grouped.loc[c].values.astype(np.float32) for c in subtype_encoder.classes_], axis=0)
    proto = l2_normalize_np(proto)

    if proto.shape[1] != EMBED_DIM:
        print(f"Refined dim={proto.shape[1]} != EMBED_DIM={EMBED_DIM}. Skip refined.")
        return None, cols

    print("Using refined proto:", proto.shape)
    return proto.astype(np.float32), cols


# =========================
# 8. DataLoader / evaluation
# =========================

def make_loader(X, y, shuffle=True, weighted=True):
    dataset = TensorDataset(
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
    )

    if weighted and USE_WEIGHTED_SAMPLER:
        sw = make_sampler_weights(y)
        sampler = WeightedRandomSampler(
            weights=torch.tensor(sw, dtype=torch.double),
            num_samples=len(sw),
            replacement=True,
        )
        shuffle_flag = False
    else:
        sampler = None
        shuffle_flag = shuffle

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=shuffle_flag,
        sampler=sampler,
        **dataloader_kwargs()
    )


def make_student_loader(Xd, y, z_pair_target=None, center_target=None, logits_target=None):
    tensors = [
        torch.tensor(Xd, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
        torch.tensor(z_pair_target, dtype=torch.float32),
        torch.tensor(center_target, dtype=torch.float32),
        torch.tensor(logits_target, dtype=torch.float32),
    ]

    dataset = TensorDataset(*tensors)

    if USE_WEIGHTED_SAMPLER:
        sw = make_sampler_weights(y)
        sampler = WeightedRandomSampler(
            weights=torch.tensor(sw, dtype=torch.double),
            num_samples=len(sw),
            replacement=True,
        )
        shuffle_flag = False
    else:
        sampler = None
        shuffle_flag = True

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=shuffle_flag,
        sampler=sampler,
        **dataloader_kwargs()
    )


def evaluate_model(model, X, y_true):
    model.eval()

    pred_all = []
    conf_all = []
    margin_all = []
    logits_all = []

    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs()
    )

    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            _, logits_plain, _ = model(xb, labels=None)
            logits_plain = logits_plain.float()

            probs = torch.softmax(logits_plain, dim=1)
            top2 = torch.topk(probs, k=2, dim=1)

            pred_all.append(top2.indices[:, 0].cpu().numpy())
            conf_all.append(top2.values[:, 0].cpu().numpy())
            margin_all.append((top2.values[:, 0] - top2.values[:, 1]).cpu().numpy())
            logits_all.append(logits_plain.cpu().numpy())

    pred_all = np.concatenate(pred_all)
    conf_all = np.concatenate(conf_all)
    margin_all = np.concatenate(margin_all)
    logits_all = np.concatenate(logits_all)

    return {
        "metrics": compute_metrics(y_true, pred_all),
        "pred": pred_all,
        "confidence": conf_all,
        "margin": margin_all,
        "logits": logits_all,
    }


def evaluate_ensemble(models, X, y_true):
    probs_all = []

    for model in models:
        model.eval()
        probs_this = []

        loader = DataLoader(
            TensorDataset(torch.tensor(X, dtype=torch.float32)),
            batch_size=BATCH_SIZE,
            shuffle=False,
            **dataloader_kwargs()
        )

        with torch.no_grad():
            for (xb,) in loader:
                xb = xb.to(DEVICE, non_blocking=True)
                _, logits_plain, _ = model(xb, labels=None)
                probs_this.append(torch.softmax(logits_plain.float(), dim=1).cpu().numpy())

        probs_all.append(np.concatenate(probs_this))

    mean_probs = np.mean(np.stack(probs_all, axis=0), axis=0)
    pred = mean_probs.argmax(axis=1)

    sorted_probs = np.sort(mean_probs, axis=1)[:, ::-1]
    confidence = sorted_probs[:, 0]
    margin = sorted_probs[:, 0] - sorted_probs[:, 1]

    return {
        "metrics": compute_metrics(y_true, pred),
        "pred": pred,
        "confidence": confidence,
        "margin": margin,
        "probs": mean_probs,
    }


# =========================
# 9. Train teacher / targets / student
# =========================

def train_teacher(Xf_train, y_train, Xf_eval, y_eval, num_classes, refined_proto_t):
    print("\nTraining fusion teacher...")

    model = FusionTeacher(Xf_train.shape[1], num_classes).to(DEVICE)

    if USE_REFINED_INIT and refined_proto_t is not None:
        if refined_proto_t.shape == model.head.weight.shape:
            with torch.no_grad():
                model.head.weight.copy_(refined_proto_t)
            print("Initialized teacher head with refined proto.")

    weight_t = torch.tensor(
        make_mild_class_weights(y_train, num_classes) if USE_MILD_CLASS_WEIGHT else np.ones(num_classes, dtype=np.float32),
        dtype=torch.float32,
        device=DEVICE
    )

    criterion = LabelSmoothingCrossEntropy(weight=weight_t, smoothing=LABEL_SMOOTHING)
    loader = make_loader(Xf_train, y_train, shuffle=True, weighted=True)

    optimizer = optim.AdamW(model.parameters(), lr=LR_TEACHER, weight_decay=WEIGHT_DECAY)
    scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    best_score = -1.0
    best_state = None
    no_improve = 0

    for epoch in range(1, EPOCHS_TEACHER + 1):
        model.train()
        total_loss = 0.0

        for xb, yb in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits_margin, _, z = model(xb, labels=yb)
                loss_ce = criterion(logits_margin, yb)
                loss_sup = supervised_contrastive_loss(z.float(), yb, temperature=SUPCON_TEMPERATURE)

                if USE_REFINED_ANCHOR:
                    loss_ref = refined_anchor_loss(model.head, refined_proto_t)
                else:
                    loss_ref = torch.tensor(0.0, device=DEVICE)

                loss = (
                    LAMBDA_TEACHER_CE * loss_ce
                    + LAMBDA_TEACHER_SUPCON * loss_sup
                    + LAMBDA_TEACHER_REFINED_ANCHOR * loss_ref
                )

            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler_amp.step(optimizer)
            scaler_amp.update()

            total_loss += loss.item() * xb.size(0)

        if (epoch % EVAL_EVERY_TEACHER == 0) or (epoch == 1) or (epoch == EPOCHS_TEACHER):
            eval_out = evaluate_model(model, Xf_eval, y_eval)
            wp = eval_out["metrics"]["WEIGHTED_PRECISION"]
            wf1 = eval_out["metrics"]["WEIGHTED_F1"]
            acc = eval_out["metrics"]["ACC"]
            score = wp + 0.10 * wf1 + 0.03 * acc

            if score > best_score + MIN_DELTA:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                no_improve = 0
            else:
                no_improve += 1
        else:
            wp = float("nan")
            wf1 = float("nan")
            acc = float("nan")

        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS_TEACHER:
            print(
                f"[Teacher {epoch:03d}] loss={total_loss/len(loader.dataset):.4f} | "
                f"eval_wp={wp:.4f} | eval_f1={wf1:.4f} | eval_acc={acc:.4f}"
            )

        if no_improve >= PATIENCE_TEACHER:
            print(f"Teacher early stop at epoch {epoch}, best score={best_score:.4f}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    return model


def precompute_fusion_targets(teacher, Xf_train, y_train, base_ids, num_classes):
    print("\nPrecomputing fusion teacher targets...")

    teacher.eval()

    z_all = []
    logits_all = []

    loader = DataLoader(
        TensorDataset(torch.tensor(Xf_train, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs()
    )

    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            _, logits_plain, z = teacher(xb, labels=None)
            z_all.append(z.float().cpu().numpy())
            logits_all.append(logits_plain.float().cpu().numpy())

    z_all = np.concatenate(z_all).astype(np.float32)
    logits_all = np.concatenate(logits_all).astype(np.float32)

    centers = np.zeros((num_classes, z_all.shape[1]), dtype=np.float32)
    for cid in range(num_classes):
        idx = y_train == cid
        if idx.sum() > 0:
            centers[cid] = z_all[idx].mean(axis=0)
        else:
            centers[cid] = 0.0

    centers = l2_normalize_np(centers).astype(np.float32)

    z_map = {str(k): z_all[i] for i, k in enumerate(base_ids)}
    logits_map = {str(k): logits_all[i] for i, k in enumerate(base_ids)}

    print("fusion z:", z_all.shape)
    print("fusion centers:", centers.shape)
    print("fusion logits:", logits_all.shape)

    return z_map, logits_map, centers


def train_student(
    seed_i,
    Xd_train,
    y_train,
    Xd_eval,
    y_eval,
    z_pair_target,
    center_target,
    logits_target,
    teacher_head_weight,
    num_classes,
    refined_proto_t,
):
    print(f"\nTraining DNA student seed={seed_i}...")

    seed_everything(seed_i)

    model = DNAStudent(Xd_train.shape[1], num_classes).to(DEVICE)

    with torch.no_grad():
        model.head.weight.copy_(teacher_head_weight.detach().clone())
    print("Initialized DNA student head with fusion teacher head.")

    weight_t = torch.tensor(
        make_mild_class_weights(y_train, num_classes) if USE_MILD_CLASS_WEIGHT else np.ones(num_classes, dtype=np.float32),
        dtype=torch.float32,
        device=DEVICE
    )

    criterion = LabelSmoothingCrossEntropy(weight=weight_t, smoothing=LABEL_SMOOTHING)

    loader = make_student_loader(
        Xd=Xd_train,
        y=y_train,
        z_pair_target=z_pair_target,
        center_target=center_target,
        logits_target=logits_target,
    )

    optimizer = optim.AdamW(model.parameters(), lr=LR_STUDENT, weight_decay=WEIGHT_DECAY)
    scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    ema = EMA(model, decay=EMA_DECAY) if USE_EMA else None

    best_score = -1.0
    best_state = None
    best_ema = None
    no_improve = 0

    for epoch in range(1, EPOCHS_STUDENT + 1):
        model.train()

        total_loss = 0.0
        total_ce = 0.0
        total_pair = 0.0
        total_center = 0.0
        total_kd = 0.0
        total_sup = 0.0

        for xd, yb, z_pair, z_center, logits_t in loader:
            xd = xd.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)
            z_pair = z_pair.to(DEVICE, non_blocking=True)
            z_center = z_center.to(DEVICE, non_blocking=True)
            logits_t = logits_t.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits_margin, logits_plain, zd = model(xd, labels=yb)

                loss_ce = criterion(logits_margin, yb)
                loss_sup = supervised_contrastive_loss(zd.float(), yb, temperature=SUPCON_TEMPERATURE)
                loss_pair = cosine_pull_loss(zd, z_pair)
                loss_center = cosine_pull_loss(zd, z_center)
                loss_kd = kd_loss(logits_plain, logits_t, temperature=KD_TEMPERATURE)

                if USE_REFINED_ANCHOR:
                    loss_ref = refined_anchor_loss(model.head, refined_proto_t)
                else:
                    loss_ref = torch.tensor(0.0, device=DEVICE)

                loss = (
                    LAMBDA_STUDENT_CE * loss_ce
                    + LAMBDA_STUDENT_SUPCON * loss_sup
                    + LAMBDA_PAIR_ALIGN * loss_pair
                    + LAMBDA_CENTER_ALIGN * loss_center
                    + LAMBDA_LOGIT_KD * loss_kd
                    + LAMBDA_REFINED_ANCHOR * loss_ref
                )

            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler_amp.step(optimizer)
            scaler_amp.update()

            if ema is not None:
                ema.update(model)

            bs = xd.size(0)
            total_loss += loss.item() * bs
            total_ce += loss_ce.item() * bs
            total_sup += loss_sup.item() * bs
            total_pair += loss_pair.item() * bs
            total_center += loss_center.item() * bs
            total_kd += loss_kd.item() * bs

        if (epoch % EVAL_EVERY_STUDENT == 0) or (epoch == 1) or (epoch == EPOCHS_STUDENT):
            if ema is not None:
                ema.apply_shadow(model)
                eval_out = evaluate_model(model, Xd_eval, y_eval)
                ema.restore(model)
            else:
                eval_out = evaluate_model(model, Xd_eval, y_eval)

            wp = eval_out["metrics"]["WEIGHTED_PRECISION"]
            wf1 = eval_out["metrics"]["WEIGHTED_F1"]
            acc = eval_out["metrics"]["ACC"]
            score = wp + 0.15 * wf1 + 0.05 * acc

            if score > best_score + MIN_DELTA:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                if ema is not None:
                    best_ema = {k: v.detach().cpu().clone() for k, v in ema.shadow.items()}
                no_improve = 0
            else:
                no_improve += 1
        else:
            wp = float("nan")
            wf1 = float("nan")
            acc = float("nan")

        n = len(loader.dataset)
        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS_STUDENT:
            print(
                f"[Student {epoch:03d}] "
                f"loss={total_loss/n:.4f} | ce={total_ce/n:.4f} | sup={total_sup/n:.4f} | "
                f"pair={total_pair/n:.4f} | center={total_center/n:.4f} | kd={total_kd/n:.4f} | "
                f"eval_wp={wp:.4f} | eval_f1={wf1:.4f} | eval_acc={acc:.4f}"
            )

        if no_improve >= PATIENCE_STUDENT:
            print(f"Student early stop at epoch {epoch}, best score={best_score:.4f}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    if ema is not None and best_ema is not None:
        ema.shadow = best_ema
        ema.apply_shadow(model)
        print("Loaded best EMA shadow.")

    return model


# =========================
# 10. 输出函数
# =========================

def make_prediction_df(df, pred_out, encoder):
    pred_subtype = encoder.inverse_transform(pred_out["pred"])
    pred_type = [infer_type_from_subtype(x) for x in pred_subtype]

    out = df[["KEY", "base_id", "Length", TYPE_COL, SUBTYPE_COL]].copy()
    out["Pred_Subtype"] = pred_subtype
    out["Pred_Type"] = pred_type
    out["subtype_confidence"] = pred_out["confidence"]
    out["subtype_margin"] = pred_out["margin"]
    out["Subtype_correct"] = out[SUBTYPE_COL].astype(str).values == out["Pred_Subtype"].astype(str).values
    out["Type_correct"] = out[TYPE_COL].astype(str).values == out["Pred_Type"].astype(str).values
    out["high_confidence"] = (
        (out["subtype_confidence"] >= DEFAULT_MIN_PROB)
        & (out["subtype_margin"] >= DEFAULT_MIN_MARGIN)
    )

    return out


def aggregate_baseid_predictions(fragment_df, probs, encoder):
    subtype_classes = list(encoder.classes_)
    base_ids = fragment_df["base_id"].astype(str).values

    rows = []

    for base_id in pd.unique(base_ids):
        idx = np.where(base_ids == base_id)[0]
        mean_probs = probs[idx].mean(axis=0)

        pidx = int(mean_probs.argmax())
        pred_subtype = subtype_classes[pidx]
        pred_type = infer_type_from_subtype(pred_subtype)

        sorted_probs = np.sort(mean_probs)[::-1]
        conf = float(sorted_probs[0])
        margin = float(sorted_probs[0] - sorted_probs[1]) if len(sorted_probs) > 1 else 0.0

        true_subtype = Counter(fragment_df.iloc[idx][SUBTYPE_COL].astype(str).tolist()).most_common(1)[0][0]
        true_type = Counter(fragment_df.iloc[idx][TYPE_COL].astype(str).tolist()).most_common(1)[0][0]
        length = Counter(fragment_df.iloc[idx]["Length"].astype(str).tolist()).most_common(1)[0][0]

        rows.append({
            "base_id": base_id,
            "Length": length,
            "n_fragments": int(len(idx)),
            TYPE_COL: true_type,
            SUBTYPE_COL: true_subtype,
            "Pred_Subtype": pred_subtype,
            "Pred_Type": pred_type,
            "subtype_confidence": conf,
            "subtype_margin": margin,
            "Subtype_correct": true_subtype == pred_subtype,
            "Type_correct": true_type == pred_type,
            "high_confidence": (conf >= DEFAULT_MIN_PROB) and (margin >= DEFAULT_MIN_MARGIN),
        })

    return pd.DataFrame(rows)


def save_eval_for_length(length_name, df_test, X_test, y_test, models, encoder, summary_rows, type_summary_rows):
    test_out = evaluate_ensemble(models, X_test, y_test)

    fragment_df = make_prediction_df(df_test, test_out, encoder)
    fragment_df.round(6).to_csv(
        OUTPUT_DIR / f"subtype_predictions_{length_name}_fragment.csv",
        index=False,
        encoding="utf-8-sig"
    )

    high_df = fragment_df[fragment_df["high_confidence"]].copy()
    rejected_df = fragment_df[~fragment_df["high_confidence"]].copy()

    high_df.round(6).to_csv(
        OUTPUT_DIR / f"subtype_predictions_{length_name}_fragment_high_confidence.csv",
        index=False,
        encoding="utf-8-sig"
    )
    rejected_df.round(6).to_csv(
        OUTPUT_DIR / f"subtype_predictions_{length_name}_fragment_rejected.csv",
        index=False,
        encoding="utf-8-sig"
    )

    frag_metrics = compute_metrics(y_test, test_out["pred"])
    summary_rows.append({"split": f"{length_name}_fragment", **frag_metrics})

    per_class_df = per_class_metrics(
        y_true=y_test,
        y_pred=test_out["pred"],
        class_names=encoder.classes_,
        split_name=f"{length_name}_fragment"
    ).round(6)
    per_class_df.to_csv(
        OUTPUT_DIR / f"subtype_metrics_{length_name}_fragment_by_class.csv",
        index=False,
        encoding="utf-8-sig"
    )

    type_summary_rows.append(
        compute_type_metrics_from_df(fragment_df, split_name=f"{length_name}_fragment_type_from_subtype")
    )

    base_df = aggregate_baseid_predictions(fragment_df, test_out["probs"], encoder)
    base_df.round(6).to_csv(
        OUTPUT_DIR / f"subtype_predictions_{length_name}_baseid.csv",
        index=False,
        encoding="utf-8-sig"
    )

    y_base_true = encoder.transform(base_df[SUBTYPE_COL].astype(str).values)
    y_base_pred = encoder.transform(base_df["Pred_Subtype"].astype(str).values)

    base_metrics = compute_metrics(y_base_true, y_base_pred)
    summary_rows.append({"split": f"{length_name}_baseid", **base_metrics})

    type_summary_rows.append(
        compute_type_metrics_from_df(base_df, split_name=f"{length_name}_baseid_type_from_subtype")
    )

    with open(OUTPUT_DIR / f"classification_report_{length_name}_fragment.txt", "w", encoding="utf-8") as f:
        f.write(classification_report(
            y_true=fragment_df[SUBTYPE_COL].astype(str).values,
            y_pred=fragment_df["Pred_Subtype"].astype(str).values,
            zero_division=0,
            digits=4
        ))

    with open(OUTPUT_DIR / f"classification_report_{length_name}_baseid.txt", "w", encoding="utf-8") as f:
        f.write(classification_report(
            y_true=base_df[SUBTYPE_COL].astype(str).values,
            y_pred=base_df["Pred_Subtype"].astype(str).values,
            zero_division=0,
            digits=4
        ))

    print_metrics(f"=== {length_name} FRAGMENT SUBTYPE ===", frag_metrics)
    print_metrics(f"=== {length_name} BASE-ID SUBTYPE ===", base_metrics)

    return fragment_df, base_df


# =========================
# 11. Main
# =========================

def main():
    seed_everything(SEED)

    print("Using device:", DEVICE)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    print("\nLoading split files...")
    train_split, test_split = load_split_files()

    encoder = LabelEncoder()
    encoder.fit(sorted(train_split[SUBTYPE_COL].astype(str).unique()))
    num_classes = len(encoder.classes_)

    print("Subtype count:", num_classes)

    test_split = test_split[test_split[SUBTYPE_COL].isin(set(encoder.classes_))].reset_index(drop=True)

    fit_base_ids, val_base_ids = train_val_split_base_ids(
        train_split,
        val_ratio=INTERNAL_VAL_RATIO,
        seed=SEED
    )

    print("Fit base IDs:", len(fit_base_ids))
    print("Val base IDs:", len(val_base_ids))

    print("\nLoading 100p fusion teacher data...")
    train_fusion = load_fusion_train(train_split)
    train_fusion = train_fusion[train_fusion[SUBTYPE_COL].isin(set(encoder.classes_))].reset_index(drop=True)

    fusion_cols = get_feature_cols(train_fusion)
    if len(fusion_cols) == 0:
        raise ValueError("fusion 特征列为 0")

    train_fusion_fit = train_fusion[train_fusion["base_id"].astype(str).isin(fit_base_ids)].copy()
    train_fusion_val = train_fusion[train_fusion["base_id"].astype(str).isin(val_base_ids)].copy()

    if len(train_fusion_fit) == 0:
        raise ValueError("train_fusion_fit 为空，请检查 KEY")
    if len(train_fusion_val) == 0:
        raise ValueError("train_fusion_val 为空，请检查 KEY")

    Xf_fit_raw = to_float_matrix(train_fusion_fit, fusion_cols)
    Xf_val_raw = to_float_matrix(train_fusion_val, fusion_cols)
    Xf_all_raw = to_float_matrix(train_fusion, fusion_cols)

    y_fusion_fit = encoder.transform(train_fusion_fit[SUBTYPE_COL].astype(str).values).astype(np.int64)
    y_fusion_val = encoder.transform(train_fusion_val[SUBTYPE_COL].astype(str).values).astype(np.int64)
    y_fusion_all = encoder.transform(train_fusion[SUBTYPE_COL].astype(str).values).astype(np.int64)

    scaler_fusion = StandardScaler()
    Xf_fit = scaler_fusion.fit_transform(Xf_fit_raw).astype(np.float32)
    Xf_val = scaler_fusion.transform(Xf_val_raw).astype(np.float32)
    Xf_all = scaler_fusion.transform(Xf_all_raw).astype(np.float32)

    print("\nLoading multi-length DNA data...")
    train_dna_by_len, test_dna_by_len, used_dna_files = load_dna_by_length(train_split, test_split)

    first_len = TRAIN_LENGTHS[0]
    dna_cols = get_feature_cols(train_dna_by_len[first_len])

    if len(dna_cols) == 0:
        raise ValueError("DNA 特征列为 0")

    for length_name in TRAIN_LENGTHS:
        missing = [c for c in dna_cols if c not in train_dna_by_len[length_name].columns]
        if len(missing) > 0:
            raise ValueError(f"{length_name} DNA 缺少特征列，例如：{missing[:10]}")

    print("\nFeature dims:")
    print("fusion dim:", len(fusion_cols))
    print("DNA dim:", len(dna_cols))

    train_dna_all = pd.concat(
        [train_dna_by_len[length_name] for length_name in TRAIN_LENGTHS],
        axis=0
    ).reset_index(drop=True)

    train_dna_all = train_dna_all[train_dna_all[SUBTYPE_COL].isin(set(encoder.classes_))].reset_index(drop=True)

    dna_fit_df = train_dna_all[train_dna_all["base_id"].astype(str).isin(fit_base_ids)].copy().reset_index(drop=True)
    dna_val_df = train_dna_all[train_dna_all["base_id"].astype(str).isin(val_base_ids)].copy().reset_index(drop=True)

    if len(dna_fit_df) == 0:
        raise ValueError("dna_fit_df 为空，请检查 base_id 解析")
    if len(dna_val_df) == 0:
        raise ValueError("dna_val_df 为空，请检查 base_id 解析")

    print("\nStudent DNA fit fragments:", len(dna_fit_df))
    print("Student DNA val fragments:", len(dna_val_df))

    Xd_fit_raw = to_float_matrix(dna_fit_df, dna_cols)
    Xd_val_raw = to_float_matrix(dna_val_df, dna_cols)

    y_dna_fit = encoder.transform(dna_fit_df[SUBTYPE_COL].astype(str).values).astype(np.int64)
    y_dna_val = encoder.transform(dna_val_df[SUBTYPE_COL].astype(str).values).astype(np.int64)

    scaler_dna = StandardScaler()
    Xd_fit = scaler_dna.fit_transform(Xd_fit_raw).astype(np.float32)
    Xd_val = scaler_dna.transform(Xd_val_raw).astype(np.float32)

    refined_proto_np, refined_cols = build_refined_proto(encoder)
    refined_proto_t = None
    if refined_proto_np is not None:
        refined_proto_t = torch.tensor(refined_proto_np, dtype=torch.float32, device=DEVICE)

    # 1) Train fusion teacher
    teacher = train_teacher(
        Xf_train=Xf_fit,
        y_train=y_fusion_fit,
        Xf_eval=Xf_val,
        y_eval=y_fusion_val,
        num_classes=num_classes,
        refined_proto_t=refined_proto_t,
    )

    teacher_fit_eval = evaluate_model(teacher, Xf_fit, y_fusion_fit)
    teacher_val_eval = evaluate_model(teacher, Xf_val, y_fusion_val)

    print_metrics("=== FUSION TEACHER FIT METRICS ===", teacher_fit_eval["metrics"])
    print_metrics("=== FUSION TEACHER VAL METRICS ===", teacher_val_eval["metrics"])

    # 2) Precompute teacher targets on all train fusion base IDs
    z_map, logits_map, fusion_centers = precompute_fusion_targets(
        teacher=teacher,
        Xf_train=Xf_all,
        y_train=y_fusion_all,
        base_ids=train_fusion["base_id"].astype(str).values,
        num_classes=num_classes,
    )

    # 3) Build student targets for fit DNA fragments
    keep_mask = dna_fit_df["base_id"].astype(str).isin(z_map.keys()).values
    if keep_mask.sum() < len(dna_fit_df):
        print(f"Filter student fit fragments with fusion target: {len(dna_fit_df)} -> {keep_mask.sum()}")

    dna_fit_df = dna_fit_df[keep_mask].reset_index(drop=True)
    Xd_fit = Xd_fit[keep_mask]
    y_dna_fit = y_dna_fit[keep_mask]

    z_pair_target = np.stack(
        [z_map[str(k)] for k in dna_fit_df["base_id"].astype(str).values],
        axis=0
    ).astype(np.float32)

    logits_target = np.stack(
        [logits_map[str(k)] for k in dna_fit_df["base_id"].astype(str).values],
        axis=0
    ).astype(np.float32)

    center_target = fusion_centers[y_dna_fit].astype(np.float32)

    # 4) Train DNA student
    models = []
    seed_rows = []

    for seed_i in ENSEMBLE_SEEDS:
        student = train_student(
            seed_i=seed_i,
            Xd_train=Xd_fit,
            y_train=y_dna_fit,
            Xd_eval=Xd_val,
            y_eval=y_dna_val,
            z_pair_target=z_pair_target,
            center_target=center_target,
            logits_target=logits_target,
            teacher_head_weight=teacher.head.weight,
            num_classes=num_classes,
            refined_proto_t=refined_proto_t,
        )

        fit_out_single = evaluate_model(student, Xd_fit, y_dna_fit)
        val_out_single = evaluate_model(student, Xd_val, y_dna_val)

        print_metrics(f"=== DNA STUDENT SEED {seed_i} FIT ===", fit_out_single["metrics"])
        print_metrics(f"=== DNA STUDENT SEED {seed_i} VAL ===", val_out_single["metrics"])

        seed_rows.append({
            "seed": seed_i,
            **{f"fit_{k}": v for k, v in fit_out_single["metrics"].items()},
            **{f"val_{k}": v for k, v in val_out_single["metrics"].items()},
        })

        models.append(student)

    val_out = evaluate_ensemble(models, Xd_val, y_dna_val)
    print_metrics("=== ENSEMBLE DNA VAL METRICS ===", val_out["metrics"])

    summary_rows = [
        {"split": "fusion_teacher_fit", **teacher_fit_eval["metrics"]},
        {"split": "fusion_teacher_val", **teacher_val_eval["metrics"]},
        {"split": "dna_student_val_multilength", **val_out["metrics"]},
    ]

    type_summary_rows = []

    all_fragment_outputs = []
    all_baseid_outputs = []

    # 5) Evaluate each length
    for length_name in TEST_LENGTHS:
        print(f"\nEvaluating {length_name}...")

        test_df = test_dna_by_len[length_name].copy()
        test_df = test_df[test_df[SUBTYPE_COL].isin(set(encoder.classes_))].reset_index(drop=True)

        if len(test_df) == 0:
            print(f"Skip {length_name}: empty test_df")
            continue

        Xd_test_raw = to_float_matrix(test_df, dna_cols)
        Xd_test = scaler_dna.transform(Xd_test_raw).astype(np.float32)
        y_test = encoder.transform(test_df[SUBTYPE_COL].astype(str).values).astype(np.int64)

        fragment_df, base_df = save_eval_for_length(
            length_name=length_name,
            df_test=test_df,
            X_test=Xd_test,
            y_test=y_test,
            models=models,
            encoder=encoder,
            summary_rows=summary_rows,
            type_summary_rows=type_summary_rows,
        )

        all_fragment_outputs.append(fragment_df)
        all_baseid_outputs.append(base_df)

    if len(all_fragment_outputs) > 0:
        pd.concat(all_fragment_outputs, axis=0).round(6).to_csv(
            OUTPUT_DIR / "subtype_predictions_all_lengths_fragment.csv",
            index=False,
            encoding="utf-8-sig"
        )

    if len(all_baseid_outputs) > 0:
        pd.concat(all_baseid_outputs, axis=0).round(6).to_csv(
            OUTPUT_DIR / "subtype_predictions_all_lengths_baseid.csv",
            index=False,
            encoding="utf-8-sig"
        )

    metrics_df = pd.DataFrame(summary_rows).round(6)
    metrics_df.to_csv(OUTPUT_DIR / "all_dataset_summary.csv", index=False, encoding="utf-8-sig")

    type_metrics_df = pd.DataFrame(type_summary_rows).round(6)
    type_metrics_df.to_csv(OUTPUT_DIR / "type_metrics_from_subtype_summary.csv", index=False, encoding="utf-8-sig")

    seed_metrics_df = pd.DataFrame(seed_rows).round(6)
    seed_metrics_df.to_csv(OUTPUT_DIR / "subtype_single_seed_metrics.csv", index=False, encoding="utf-8-sig")

    # 6) Save checkpoint
    checkpoint = {
        "model_name": "multilen_nt_teacher_dna_student",
        "teacher_state_dict": teacher.state_dict(),
        "student_state_dicts": [m.state_dict() for m in models],
        "ensemble_seeds": ENSEMBLE_SEEDS,
        "train_lengths": TRAIN_LENGTHS,
        "test_lengths": TEST_LENGTHS,
        "fusion_dim": int(Xf_fit.shape[1]),
        "dna_dim": int(Xd_fit.shape[1]),
        "num_classes": int(num_classes),
        "embed_dim": int(EMBED_DIM),
        "fusion_feature_cols": fusion_cols,
        "dna_feature_cols": dna_cols,
        "refined_feature_cols": refined_cols,
        "subtype_classes": encoder.classes_.tolist(),
        "fusion_centers": fusion_centers,
        "used_dna_files": used_dna_files,
        "config": {
            "INTERNAL_VAL_RATIO": INTERNAL_VAL_RATIO,
            "LAMBDA_STUDENT_CE": LAMBDA_STUDENT_CE,
            "LAMBDA_STUDENT_SUPCON": LAMBDA_STUDENT_SUPCON,
            "LAMBDA_PAIR_ALIGN": LAMBDA_PAIR_ALIGN,
            "LAMBDA_CENTER_ALIGN": LAMBDA_CENTER_ALIGN,
            "LAMBDA_LOGIT_KD": LAMBDA_LOGIT_KD,
            "LAMBDA_REFINED_ANCHOR": LAMBDA_REFINED_ANCHOR,
            "LR_STUDENT": LR_STUDENT,
            "EPOCHS_STUDENT": EPOCHS_STUDENT,
        }
    }

    torch.save(checkpoint, OUTPUT_DIR / "model_checkpoint.pth")
    joblib.dump(scaler_fusion, OUTPUT_DIR / "scaler_fusion.joblib")
    joblib.dump(scaler_dna, OUTPUT_DIR / "scaler_dna.joblib")
    joblib.dump(encoder, OUTPUT_DIR / "subtype_encoder.joblib")

    run_info = {
        "base_dir": str(BASE_DIR),
        "output_dir": str(OUTPUT_DIR),
        "fusion_file": str(FUSION_FILE),
        "train_split_file": str(TRAIN_SPLIT_FILE),
        "test_split_file": str(TEST_SPLIT_FILE),
        "used_dna_files": used_dna_files,
        "train_lengths": TRAIN_LENGTHS,
        "test_lengths": TEST_LENGTHS,
        "fusion_dim": int(Xf_fit.shape[1]),
        "dna_dim": int(Xd_fit.shape[1]),
        "num_classes": int(num_classes),
        "fit_base_ids": int(len(fit_base_ids)),
        "val_base_ids": int(len(val_base_ids)),
        "student_fit_fragments": int(len(dna_fit_df)),
        "student_val_fragments": int(len(dna_val_df)),
    }

    with open(OUTPUT_DIR / "run_info.json", "w", encoding="utf-8") as f:
        json.dump(run_info, f, indent=2, ensure_ascii=False)

    print("\nSaved outputs to:", OUTPUT_DIR.resolve())
    print("重点看：")
    print(" - all_dataset_summary.csv")
    print(" - type_metrics_from_subtype_summary.csv")
    print(" - subtype_predictions_90p_fragment.csv")
    print(" - subtype_predictions_90p_baseid.csv")
    print(" - model_checkpoint.pth")
    print(" - scaler_dna.joblib")
    print(" - subtype_encoder.joblib")
    print("Done.")


if __name__ == "__main__":
    mp.freeze_support()
    main()