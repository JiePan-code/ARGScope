#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
根据 test_sequence_predictions.csv 计算五种测试指标。

默认用法：
1. 将本脚本放到 test_sequence_predictions.csv 同一文件夹。
2. 运行本脚本。
3. 结果会保存到同目录下新建的 five_metrics_results 文件夹。

输出内容：
- ARG/nonARG 总体指标：macro、weighted、micro 三行
- Type 总体指标：macro、weighted、micro 三行
- Subtype 总体指标：macro、weighted、micro 三行
- 每个 Type 的 one-vs-rest 五种指标

五种指标：Accuracy、Precision、Recall、F1、MCC。

说明：
- 总体 Accuracy 是所有序列的准确率。
- 总体 MCC 是标准 multiclass MCC。
- Accuracy 和 MCC 不区分 macro/weighted/micro，所以三行中数值相同。
- 每个 Type 的指标采用 one-vs-rest：当前 Type 为正类，其余 Type 为负类。
- 本脚本只使用 Python 标准库，不需要安装 pandas 或 scikit-learn。
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path
from typing import Iterable, Sequence


DEFAULT_INPUT_NAME = "test_sequence_predictions.csv"
DEFAULT_OUTPUT_DIR_NAME = "five_metrics_results"

REQUIRED_COLUMNS = (
    "true_ARG",
    "predicted_ARG",
    "true_type",
    "predicted_type",
    "true_subtype",
    "predicted_subtype",
)

AVERAGES = ("macro", "weighted", "micro")
METRIC_COLUMNS = ("accuracy", "precision", "recall", "f1", "mcc")


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="计算 ARG/nonARG、Type、Subtype 及逐 Type 的五种指标。"
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=script_dir / DEFAULT_INPUT_NAME,
        help=(
            "输入预测 CSV。默认读取本脚本同目录下的 "
            f"{DEFAULT_INPUT_NAME}。"
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "结果文件夹。默认在输入 CSV 同目录下创建 "
            f"{DEFAULT_OUTPUT_DIR_NAME}。"
        ),
    )
    return parser.parse_args()


def safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def sorted_labels(
    y_true: Iterable[str],
    y_pred: Iterable[str],
) -> list[str]:
    labels = set(y_true) | set(y_pred)
    return sorted(labels, key=lambda value: (value.casefold(), value))


def normalize_text_labels(
    values: Sequence[object],
    column_name: str,
) -> list[str]:
    result: list[str] = []
    for row_number, value in enumerate(values, start=2):
        if value is None or str(value).strip() == "":
            raise ValueError(
                f"列 {column_name!r} 在 CSV 第 {row_number} 行存在空标签。"
            )
        result.append(str(value).strip())
    return result


def normalize_arg_labels(
    values: Sequence[object],
    column_name: str,
) -> list[str]:
    """把常见二分类写法统一为 ARG 和 nonARG。"""
    arg_values = {
        "1",
        "1.0",
        "true",
        "arg",
        "positive",
        "pos",
        "yes",
    }
    nonarg_values = {
        "0",
        "0.0",
        "false",
        "nonarg",
        "non-arg",
        "negative",
        "neg",
        "no",
    }

    normalized: list[str] = []
    for row_number, value in enumerate(values, start=2):
        if value is None or str(value).strip() == "":
            raise ValueError(
                f"列 {column_name!r} 在 CSV 第 {row_number} 行存在空标签。"
            )

        text = str(value).strip()
        key = text.casefold().replace("_", "").replace(" ", "")
        if key in arg_values:
            normalized.append("ARG")
        elif key in nonarg_values:
            normalized.append("nonARG")
        else:
            raise ValueError(
                f"列 {column_name!r} 在 CSV 第 {row_number} 行存在"
                f"无法识别的标签：{text!r}"
            )
    return normalized


def calculate_multiclass_mcc(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    labels: Sequence[str],
) -> float:
    """按标准 confusion-matrix 公式计算 multiclass MCC。"""
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    correct = sum(true == pred for true, pred in zip(y_true, y_pred))

    sum_true_pred = sum(
        true_counts[label] * predicted_counts[label] for label in labels
    )
    sum_true_squared = sum(true_counts[label] ** 2 for label in labels)
    sum_pred_squared = sum(predicted_counts[label] ** 2 for label in labels)

    numerator = correct * n_samples - sum_true_pred
    denominator = math.sqrt(
        (n_samples**2 - sum_pred_squared)
        * (n_samples**2 - sum_true_squared)
    )
    return safe_divide(numerator, denominator)


def calculate_overall_metrics(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    level_name: str,
) -> list[dict[str, object]]:
    """计算一个标签层级的 macro、weighted、micro 三行结果。"""
    if len(y_true) != len(y_pred):
        raise ValueError(f"{level_name} 的真实标签和预测标签数量不一致。")
    if not y_true:
        raise ValueError(f"{level_name} 没有可用于计算的数据。")

    labels = sorted_labels(y_true, y_pred)
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive = Counter(
        true for true, pred in zip(y_true, y_pred) if true == pred
    )

    correct = sum(true_positive.values())
    accuracy = safe_divide(correct, n_samples)
    mcc = calculate_multiclass_mcc(y_true, y_pred, labels)

    per_class: dict[str, dict[str, float]] = {}
    for label in labels:
        tp = true_positive[label]
        fp = predicted_counts[label] - tp
        fn = true_counts[label] - tp
        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)
        per_class[label] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": true_counts[label],
        }

    rows: list[dict[str, object]] = []
    for average in AVERAGES:
        if average == "macro":
            precision = safe_divide(
                sum(per_class[label]["precision"] for label in labels),
                len(labels),
            )
            recall = safe_divide(
                sum(per_class[label]["recall"] for label in labels),
                len(labels),
            )
            f1 = safe_divide(
                sum(per_class[label]["f1"] for label in labels),
                len(labels),
            )
        elif average == "weighted":
            precision = safe_divide(
                sum(
                    per_class[label]["precision"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            recall = safe_divide(
                sum(
                    per_class[label]["recall"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            f1 = safe_divide(
                sum(
                    per_class[label]["f1"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
        else:  # micro
            micro_tp = correct
            micro_fp = n_samples - correct
            micro_fn = n_samples - correct
            precision = safe_divide(micro_tp, micro_tp + micro_fp)
            recall = safe_divide(micro_tp, micro_tp + micro_fn)
            f1 = safe_divide(2 * precision * recall, precision + recall)

        rows.append(
            {
                "level": level_name,
                "average": average,
                "n_samples": n_samples,
                "n_classes_union": len(labels),
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": mcc,
            }
        )

    return rows


def calculate_binary_mcc(tp: int, fp: int, fn: int, tn: int) -> float:
    numerator = tp * tn - fp * fn
    denominator = math.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    )
    return safe_divide(numerator, denominator)


def calculate_each_type_metrics(
    true_type: Sequence[str],
    predicted_type: Sequence[str],
) -> list[dict[str, object]]:
    """对每个 Type 做 one-vs-rest 五指标计算。"""
    labels = sorted_labels(true_type, predicted_type)
    n_samples = len(true_type)
    rows: list[dict[str, object]] = []

    for label in labels:
        tp = fp = fn = tn = 0
        for true, pred in zip(true_type, predicted_type):
            true_positive_class = true == label
            predicted_positive_class = pred == label

            if true_positive_class and predicted_positive_class:
                tp += 1
            elif not true_positive_class and predicted_positive_class:
                fp += 1
            elif true_positive_class and not predicted_positive_class:
                fn += 1
            else:
                tn += 1

        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)

        rows.append(
            {
                "type": label,
                "true_support": tp + fn,
                "predicted_count": tp + fp,
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "tn": tn,
                "accuracy": safe_divide(tp + tn, n_samples),
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": calculate_binary_mcc(tp, fp, fn, tn),
            }
        )

    rows.sort(
        key=lambda row: (
            -int(row["true_support"]),
            str(row["type"]).casefold(),
            str(row["type"]),
        )
    )
    return rows


def read_prediction_rows(input_csv: Path) -> tuple[list[dict[str, str]], list[str]]:
    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("输入 CSV 没有表头。")

        fieldnames = [name.strip() for name in reader.fieldnames]
        missing_columns = [
            column for column in REQUIRED_COLUMNS if column not in fieldnames
        ]
        if missing_columns:
            raise ValueError(
                "预测文件缺少必要列：" + ", ".join(missing_columns)
            )

        rows = list(reader)

    if not rows:
        raise ValueError("输入 CSV 没有数据行。")

    # 如果 CSV 中存在 test 记录，只使用 test；纯测试文件不受影响。
    if "split" in fieldnames:
        test_rows = [
            row
            for row in rows
            if str(row.get("split", "")).strip().casefold() == "test"
        ]
        if test_rows:
            rows = test_rows

    return rows, fieldnames


def rounded_row(row: dict[str, object]) -> dict[str, object]:
    result = dict(row)
    for column in METRIC_COLUMNS:
        if column in result:
            result[column] = round(float(result[column]), 6)
    return result


def save_csv(
    rows: Sequence[dict[str, object]],
    path: Path,
    fieldnames: Sequence[str],
) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rounded_row(row) for row in rows)


def main() -> None:
    args = parse_args()
    input_csv = args.input.expanduser().resolve()
    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else input_csv.parent / DEFAULT_OUTPUT_DIR_NAME
    )

    if not input_csv.is_file():
        raise FileNotFoundError(
            f"找不到输入文件：{input_csv}\n"
            f"请把本脚本与 {DEFAULT_INPUT_NAME} 放在同一文件夹，"
            "或者使用 --input 指定文件。"
        )

    rows, _ = read_prediction_rows(input_csv)

    true_arg = normalize_arg_labels(
        [row["true_ARG"] for row in rows], "true_ARG"
    )
    predicted_arg = normalize_arg_labels(
        [row["predicted_ARG"] for row in rows], "predicted_ARG"
    )
    true_type = normalize_text_labels(
        [row["true_type"] for row in rows], "true_type"
    )
    predicted_type = normalize_text_labels(
        [row["predicted_type"] for row in rows], "predicted_type"
    )
    true_subtype = normalize_text_labels(
        [row["true_subtype"] for row in rows], "true_subtype"
    )
    predicted_subtype = normalize_text_labels(
        [row["predicted_subtype"] for row in rows], "predicted_subtype"
    )

    arg_metrics = calculate_overall_metrics(
        true_arg, predicted_arg, "ARG_nonARG"
    )
    type_metrics = calculate_overall_metrics(
        true_type, predicted_type, "type"
    )
    subtype_metrics = calculate_overall_metrics(
        true_subtype, predicted_subtype, "subtype"
    )
    each_type_metrics = calculate_each_type_metrics(
        true_type, predicted_type
    )

    output_dir.mkdir(parents=True, exist_ok=True)

    overall_columns = (
        "level",
        "average",
        "n_samples",
        "n_classes_union",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )
    each_type_columns = (
        "type",
        "true_support",
        "predicted_count",
        "tp",
        "fp",
        "fn",
        "tn",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )

    save_csv(
        arg_metrics + type_metrics + subtype_metrics,
        output_dir / "00_all_three_levels_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        arg_metrics,
        output_dir / "01_ARG_nonARG_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        type_metrics,
        output_dir / "02_type_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        subtype_metrics,
        output_dir / "03_subtype_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        each_type_metrics,
        output_dir / "04_each_type_one_vs_rest_five_metrics.csv",
        each_type_columns,
    )

    print("计算完成。")
    print(f"输入文件：{input_csv}")
    print(f"测试序列数：{len(rows)}")
    print(f"结果文件夹：{output_dir}")
    print("已生成 5 个 CSV 结果文件。")


if __name__ == "__main__":
    main()
