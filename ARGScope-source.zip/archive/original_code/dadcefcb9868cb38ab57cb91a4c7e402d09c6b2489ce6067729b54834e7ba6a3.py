"""Precision-only selected display. Original predictions and complete results are immutable."""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/novel_gene_type_heatmaps_20260923/data/Novel_gene_per_type_precision_recall_F1.csv'
PREDICTIONS = Path('E:/1. ARGmodel/1. NonARG_training/new model result8.24/5. novel gene')
OUT = ROOT / 'outputs/novel_gene_selected_precision_20260925'
DEST = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Novel_gene_selected_precision_20260925')
NAME = 'Novel_gene_selected_precision_ge_095'
COLORS = {'AA': '#387F8D', 'NT': '#C88A43'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = digest(SOURCE)
    frame = pd.read_csv(SOURCE, keep_default_na=False)
    selected = frame.loc[frame.Support.gt(0) & frame.Precision.ge(.95)].copy()
    assert selected.groupby('Modality').size().to_dict() == {'AA': 6, 'NT': 2}
    audits = []
    hashes = {str(SOURCE): before}
    for mod, folder in [('AA', '1.Protein_novel_gene_100pct'), ('NT', '2.DNA_novel_gene_100pct')]:
        source = PREDICTIONS / folder / 'test_sequence_predictions.csv'
        hashes[str(source)] = digest(source)
        raw = pd.read_csv(source, keep_default_na=False)
        assert raw.sequence_id.is_unique and len(raw) == 4494
        actual = raw.loc[raw.true_ARG.eq(1)].copy()
        assert len(actual) == 2247 and actual.novel_ARG_subtype.eq(1).all()
        assert actual.split.eq('test').all()
        for record in frame.loc[frame.Modality.eq(mod)].to_dict('records'):
            p = actual.predicted_type.eq(record['Type'])
            t = actual.true_type.eq(record['Type'])
            tp, pred, support = int((p & t).sum()), int(p.sum()), int(t.sum())
            precision = tp / pred if pred else 0.
            assert (tp, pred, support) == (record['TP'], record['Predicted'], record['Support'])
            assert abs(precision - record['Precision']) < 1e-12
        audits.append({'modality': mod, 'reference_ARG_n': 2247, 'supported_types': 16,
                       'selected_types': int(selected.Modality.eq(mod).sum()), 'source': str(source)})
    selected = selected.sort_values(['Modality', 'Precision', 'Predicted'], ascending=[True, False, False])
    columns = ['Model', 'Type_display', 'Precision', 'TP', 'Predicted', 'Support', 'Scope']
    selected[columns].to_csv(OUT / 'Selected_precision_ge_095.csv', index=False, encoding='utf-8-sig')
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'text.color': '#203746',
                         'axes.labelcolor': '#203746', 'xtick.color': '#506473',
                         'ytick.color': '#203746', 'svg.hashsalt': 'novel-precision-only-20260925'})
    fig = plt.figure(figsize=(8.25, 5.60), dpi=160, facecolor='none')
    fig.text(.025, .978, 'Resistance-type assignments to unseen ARG subtypes',
             ha='left', va='top', fontsize=14, weight='bold')
    fig.text(.025, .926, 'Selected categories with precision ≥ 0.95', fontsize=11, va='top')
    fig.text(.025, .090, 'Evaluated on reference ARG sequences only (n = 2,247).', fontsize=9.6, va='top')
    fig.text(.025, .055, 'Counts: correct assignments / all predictions of that type within the evaluated set.',
             fontsize=9.3, va='top')
    for mod, title_y, bottom, height in [('AA', .858, .390, .395), ('NT', .304, .145, .13)]:
        subset = selected.loc[selected.Modality.eq(mod)]
        n = len(subset)
        fig.text(.025, title_y, f'ARGScope-{mod} ({"protein" if mod == "AA" else "DNA"})',
                 fontsize=12.5, color=COLORS[mod], weight='bold', va='top')
        ax = fig.add_axes([.225, bottom, .445, height], facecolor='none')
        ax.set_xlim(-.01, 1.035)
        ax.set_ylim(n - .5, -.5)
        ax.set_yticks(np.arange(n), subset.Type_display.tolist(), fontsize=11)
        ax.tick_params(axis='y', length=0, pad=8)
        ax.set_xticks([0, .25, .5, .75, 1], ['0', '0.25', '0.50', '0.75', '1.00'], fontsize=9.5)
        ax.tick_params(axis='x', length=3, pad=3, color='#AAB8C1')
        ax.set_xlabel('Precision', fontsize=10.5, labelpad=4)
        ax.grid(axis='x', color='#E5EAED', lw=.7, zorder=0)
        ax.axvline(.95, color='#81909C', linestyle=(0, (3, 3)), lw=.8, zorder=1)
        for spine in ['top', 'left', 'right']:
            ax.spines[spine].set_visible(False)
        ax.spines['bottom'].set_color('#9BA9B3')
        ax.spines['bottom'].set_linewidth(.7)
        for i, row in enumerate(subset.itertuples()):
            ax.hlines(i, 0, row.Precision, color='#CAD7DC' if mod == 'AA' else '#E4D8C8', lw=1.1, zorder=2)
            ax.scatter(row.Precision, i, s=65, marker='o' if mod == 'AA' else 'D',
                       color=COLORS[mod], edgecolor='white', linewidth=.65, zorder=4)
            y = bottom + height * (1 - (i + .5) / n)
            fig.text(.745, y, f'{row.Precision:.4f}', fontsize=11.5,
                     ha='center', va='center', weight='bold', color=COLORS[mod])
            fig.text(.905, y, f'{row.TP} / {row.Predicted}', fontsize=10.8,
                     ha='center', va='center')
        label_y = bottom + height + .016
        fig.text(.745, label_y, 'Precision', fontsize=9.7, ha='center')
        fig.text(.905, label_y, 'Correct / predicted', fontsize=9.7, ha='center')
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    clipped = []
    for text in fig.findobj(match=Text):
        if text.get_visible() and text.get_text():
            b = text.get_window_extent(renderer)
            if b.width and b.height and (b.x0 < -1 or b.y0 < -1 or b.x1 > width + 1 or b.y1 > height + 1):
                clipped.append(text.get_text())
    assert not clipped, clipped
    with plt.rc_context({'svg.fonttype': 'path'}):
        fig.savefig(OUT / (NAME + '.svg'), transparent=True)
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / (NAME + '_editable.svg'), transparent=True)
    fig.savefig(OUT / (NAME + '_transparent.tif'), dpi=300, transparent=True,
                pil_kwargs={'compression': 'tiff_lzw'})
    with Image.open(OUT / (NAME + '_transparent.tif')) as im:
        assert im.size == (2475, 1680)
        assert all(float(v) == 300 for v in im.info['dpi'])
        rgba = im.convert('RGBA')
        assert rgba.getchannel('A').getextrema() == (0, 255)
    bg = Image.new('RGBA', rgba.size, 'white')
    bg.alpha_composite(rgba)
    bg.convert('RGB').save(OUT / (NAME + '_white.tif'), compression='tiff_lzw', dpi=(300, 300))
    preview = bg.convert('RGB')
    preview.thumbnail((1485, 1008), Image.Resampling.LANCZOS)
    preview.save(OUT / (NAME + '_preview.png'))
    plt.close(fig)
    assert all(digest(Path(path)) == value for path, value in hashes.items())
    report = {'selection': 'Support > 0 and per-type Precision >= 0.95, independently for AA and NT',
              'scope': '2,247 reference ARG sequences, subtype-disjoint test set',
              'metrics_not_displayed': ['Recall', 'F1'], 'source_files_unchanged': True,
              'all_original_results_retained': True, 'test_populations_changed': False,
              'outside_canvas': clipped, 'source_sha256': hashes, 'sequence_level_checks': audits,
              'tif_dimensions': [2475, 1680], 'tif_dpi': [300, 300]}
    (OUT / 'verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    print(json.dumps({'output': str(OUT), 'selected': selected[columns].to_dict('records')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
