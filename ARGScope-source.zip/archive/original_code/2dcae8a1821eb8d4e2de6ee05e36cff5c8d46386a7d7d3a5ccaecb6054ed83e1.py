import pandas as pd
import torch
import torch.nn as nn
import math


# ==========================================================
# 1 严格 Cross-Attention 模块
# ==========================================================

class StrictCrossAttention(nn.Module):
    """
    严格 Cross-Attention:
        Q = AA embedding
        K = NT embedding
        V = NT embedding
    """

    def __init__(self, dim_aa, dim_nt, d_model=512, n_heads=8):
        super().__init__()

        assert d_model % n_heads == 0, "d_model 必须能被 n_heads 整除"

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.q_proj = nn.Linear(dim_aa, d_model)
        self.k_proj = nn.Linear(dim_nt, d_model)
        self.v_proj = nn.Linear(dim_nt, d_model)

        self.out_proj = nn.Linear(d_model, d_model)
        self.layernorm = nn.LayerNorm(d_model)

    def forward(self, aa_feat, nt_feat):
        """
        aa_feat: [B, dim_aa]
        nt_feat: [B, dim_nt]

        返回:
            fused: [B, d_model]
            attn_weights: [B, n_heads]
        """
        B = aa_feat.size(0)

        Q = self.q_proj(aa_feat)
        K = self.k_proj(nt_feat)
        V = self.v_proj(nt_feat)

        Q = Q.view(B, self.n_heads, self.head_dim)
        K = K.view(B, self.n_heads, self.head_dim)
        V = V.view(B, self.n_heads, self.head_dim)

        scores = (Q * K).sum(-1) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(scores, dim=-1)

        context = attn_weights.unsqueeze(-1) * V
        context = context.reshape(B, self.d_model)

        fused = self.out_proj(context)
        fused = self.layernorm(fused + self.q_proj(aa_feat))

        return fused, attn_weights


# ==========================================================
# 2 文件路径
# ==========================================================

nt_file = "final_equal_BGC_nonBGC_dna_embedding_fixed.txt"
aa_file = "final_equal_BGC_nonBGC_protein_embed_1280_fixed.txt"
label_file = "final_equal_BGC_nonBGC_id_type_subtype_fixed.csv"

output_file = "1.all_fusion_embedding_512_with_label.csv"
attn_output_file = "1.all_cross_attention_weights.csv"


# ==========================================================
# 3 label 文件列名设置
# ==========================================================

# 如果你的 label 文件中 ID 列不是 id，代码后面会自动尝试使用第一列
label_id_col = "id"

# Type / Subtype 列名
label_type_col = "Type"
label_subtype_col = "Subtype"


# ==========================================================
# 4 读取 embedding txt 文件
# ==========================================================

def read_embedding_txt(file_path):
    """
    读取 embedding txt 文件。

    支持格式:
        ID value1 value2 value3 ...

    支持空格、多个空格、tab 混合分隔。
    第一列必须是 ID，后面所有列必须是数值。
    """

    df = pd.read_csv(
        file_path,
        sep=r"\s+",
        header=None,
        engine="python"
    )

    if df.shape[1] < 2:
        raise ValueError(
            f"{file_path} 读取后列数小于 2。"
            f"请检查文件是否为空，或者是否不是空格/tab 分隔格式。"
        )

    # 第一列是 ID
    df[0] = df[0].astype(str).str.strip()

    # 清理 ID 中可能存在的隐藏字符
    df[0] = df[0].str.replace("\ufeff", "", regex=False)
    df[0] = df[0].str.replace("\r", "", regex=False)
    df[0] = df[0].str.replace("\n", "", regex=False)

    # 数值列转 float
    for col in df.columns[1:]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # 检查是否有无法转换成数值的内容
    bad_mask = df.iloc[:, 1:].isna().any(axis=1)

    if bad_mask.any():
        bad_rows = df.loc[bad_mask]
        print(f"\n警告: {file_path} 中存在无法转成数值的行，数量: {len(bad_rows)}")
        print("前 5 行异常内容如下:")
        print(bad_rows.head())

        raise ValueError(
            f"{file_path} 存在非数值 embedding，请检查文件格式。"
        )

    return df


# ==========================================================
# 5 读取并对齐 NT 和 AA embedding
# ==========================================================

nt_df = read_embedding_txt(nt_file)
aa_df = read_embedding_txt(aa_file)

id_col_nt = nt_df.columns[0]
id_col_aa = aa_df.columns[0]

nt_df[id_col_nt] = nt_df[id_col_nt].astype(str).str.strip()
aa_df[id_col_aa] = aa_df[id_col_aa].astype(str).str.strip()

nt_ids = nt_df[id_col_nt]
aa_ids = aa_df[id_col_aa]

common_ids = sorted(list(set(nt_ids) & set(aa_ids)))

print("NT 样本数:", len(nt_ids))
print("AA 样本数:", len(aa_ids))
print("交集样本数:", len(common_ids))

print("\nNT 前 5 个 ID:")
print(nt_ids.head().tolist())

print("\nAA 前 5 个 ID:")
print(aa_ids.head().tolist())

if len(common_ids) == 0:
    print("\n错误: NT 和 AA embedding 没有任何共同 ID。")
    print("请检查两个 embedding 文件第一列 ID 是否一致。")
    print("常见问题包括:")
    print("1. 一个文件 ID 是 CAE02599.1，另一个是 CAE02599")
    print("2. ID 前后有隐藏字符")
    print("3. 文件不是空格/tab 分隔")
    print("4. 某个 embedding 文件第一列不是 ID")

    raise ValueError("NT 和 AA embedding 的 ID 交集为 0，停止运行。")

nt_aligned = (
    nt_df[nt_df[id_col_nt].isin(common_ids)]
    .set_index(id_col_nt)
    .loc[common_ids]
)

aa_aligned = (
    aa_df[aa_df[id_col_aa].isin(common_ids)]
    .set_index(id_col_aa)
    .loc[common_ids]
)

# 此时 nt_aligned 和 aa_aligned 已经去掉 ID 列，只剩 embedding 数值
nt_feat = torch.tensor(nt_aligned.values, dtype=torch.float32)
aa_feat = torch.tensor(aa_aligned.values, dtype=torch.float32)

print("\nNT 特征形状:", nt_feat.shape)
print("AA 特征形状:", aa_feat.shape)

if nt_feat.shape[0] == 0 or aa_feat.shape[0] == 0:
    raise ValueError("对齐后的 embedding 样本数为 0，停止运行。")

if nt_feat.shape[1] == 0 or aa_feat.shape[1] == 0:
    raise ValueError("embedding 特征维度为 0，停止运行。")


# ==========================================================
# 6 GPU 自动调用
# ==========================================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("\nUsing device:", device)

nt_feat = nt_feat.to(device)
aa_feat = aa_feat.to(device)


# ==========================================================
# 7 初始化模型
# ==========================================================

dim_aa = aa_feat.shape[1]
dim_nt = nt_feat.shape[1]

print("AA embedding 维度:", dim_aa)
print("NT embedding 维度:", dim_nt)

model = StrictCrossAttention(
    dim_aa=dim_aa,
    dim_nt=dim_nt,
    d_model=512,
    n_heads=8
).to(device)

model.eval()


# ==========================================================
# 8 前向传播
# ==========================================================

with torch.no_grad():
    fused_feat, attn_weights = model(aa_feat, nt_feat)

print("\n融合特征形状:", fused_feat.shape)
print("注意力权重形状:", attn_weights.shape)


# ==========================================================
# 9 保存融合特征
# ==========================================================

fusion_np = fused_feat.cpu().numpy()
feature_cols = [f"fusion_{i}" for i in range(fusion_np.shape[1])]

fusion_df = pd.DataFrame(fusion_np, columns=feature_cols)
fusion_df.insert(0, "id", common_ids)


# ==========================================================
# 10 保存 cross-attention 权重
# ==========================================================

attn_np = attn_weights.cpu().numpy()
attn_cols = [f"head_{i}" for i in range(attn_np.shape[1])]

attn_df = pd.DataFrame(attn_np, columns=attn_cols)
attn_df.insert(0, "id", common_ids)

attn_df.to_csv(attn_output_file, index=False)
print("已保存注意力权重到:", attn_output_file)


# ==========================================================
# 11 读取 label，并合并 Type / Subtype
# ==========================================================

label_df = pd.read_csv(label_file)

print("\nLabel 文件列名:")
print(label_df.columns.tolist())

# 如果找不到 id 列，默认使用第一列作为 ID 列
if label_id_col not in label_df.columns:
    print(f"警告: label 文件中找不到列 {label_id_col}，将使用第一列作为 ID 列。")
    label_id_col = label_df.columns[0]

required_cols = [label_id_col, label_type_col, label_subtype_col]

for col in required_cols:
    if col not in label_df.columns:
        raise ValueError(f"label 文件缺少列: {col}")

label_df[label_id_col] = label_df[label_id_col].astype(str).str.strip()
label_df[label_id_col] = label_df[label_id_col].str.replace("\ufeff", "", regex=False)
label_df[label_id_col] = label_df[label_id_col].str.replace("\r", "", regex=False)
label_df[label_id_col] = label_df[label_id_col].str.replace("\n", "", regex=False)

label_df = label_df[[label_id_col, label_type_col, label_subtype_col]].copy()
label_df.columns = ["id", "Type", "Subtype"]

# 如果 label 中存在重复 ID，只保留第一条
dup_n = label_df["id"].duplicated().sum()
if dup_n > 0:
    print(f"警告: label 文件中存在重复 ID 数量: {dup_n}，将只保留第一条。")
    label_df = label_df.drop_duplicates(subset=["id"], keep="first")

final_df = fusion_df.merge(label_df, on="id", how="left")

# 调整列顺序：id, Type, Subtype, embedding...
final_df = final_df[["id", "Type", "Subtype"] + feature_cols]

matched_n = final_df["Type"].notna().sum()
unmatched_n = final_df["Type"].isna().sum()

print("\n匹配到标签的样本数:", matched_n)
print("未匹配到标签的样本数:", unmatched_n)

if unmatched_n > 0:
    missing_label_ids = final_df.loc[final_df["Type"].isna(), "id"]
    missing_label_ids.to_csv("missing_label_ids.csv", index=False)
    print("未匹配到标签的 ID 已保存到: missing_label_ids.csv")


# ==========================================================
# 12 输出最终 CSV
# ==========================================================

final_df.to_csv(output_file, index=False)

print("\n已保存融合特征到:", output_file)
print("最终输出样本数:", len(final_df))
print("最终输出列数:", final_df.shape[1])