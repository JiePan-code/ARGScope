from pathlib import Path
import pandas as pd, numpy as np, hashlib, json
out=Path(__file__).resolve().parent.parent
root=out.parent
app=root/"ARGScope_80_20_results/apply_argscope_protein_and_DNA"
manifest=pd.read_csv(out/"input_file_manifest.csv")
report=[]
for mod in ("protein","dna"):
    src=app/mod/"100%_test_sequence_predictions.csv"
    raw=pd.read_csv(src,keep_default_na=False)
    d=raw.loc[raw["split"].eq("test")].copy()
    assert len(d)==4574 and not d.sequence_id.duplicated().any()
    sha=hashlib.sha256(src.read_bytes()).hexdigest()
    assert sha==manifest.loc[manifest.Path.eq(str(src)),"SHA256"].item()
    saved=Path(__file__).resolve().parent/"data"/mod
    full=pd.read_csv(saved/"full_confusion_counts_audit.csv",index_col=0)
    order=full.index.tolist()
    assert order[-1]=="nonARG"
    assert set(order[:-1])==set(pd.read_csv(out/"ARGScope_23_types.csv").Type)
    assert set(d.true_type)<=set(order) and set(d.predicted_type)<=set(order)
    actual=pd.crosstab(d.true_type,d.predicted_type).reindex(index=order,columns=order,fill_value=0)
    np.testing.assert_array_equal(full.to_numpy(),actual.to_numpy())
    core=actual.iloc[:-1,:-1].to_numpy()
    denominator=actual.iloc[:-1,:].sum(axis=1).to_numpy()
    normalized=core/denominator[:,None]
    np.testing.assert_allclose(normalized,pd.read_csv(saved/"D_row_normalized_23types.csv",index_col=0).to_numpy(),atol=1e-14)
    errors=core.copy(); np.fill_diagonal(errors,0)
    np.testing.assert_array_equal(errors,pd.read_csv(saved/"E_off_diagonal_counts_23types.csv",index_col=0).to_numpy())
    arg=d[d.true_type.ne("nonARG")].copy()
    err=arg[arg.true_subtype.ne(arg.predicted_subtype)].copy()
    err["Type_correct_count"]=err.true_type.eq(err.predicted_type).astype(int)
    keys=["true_subtype","predicted_subtype","true_type","predicted_type"]
    pairs=err.groupby(keys).agg(Count=("sequence_id","size"),Type_correct_count=("Type_correct_count","sum")).reset_index()
    pairs["Type_correct_percent"]=100*pairs.Type_correct_count/pairs.Count
    prior=pd.read_csv(saved/"F_all_subtype_error_pairs.csv",keep_default_na=False)
    pd.testing.assert_frame_equal(pairs.sort_values(keys).reset_index(drop=True),prior.sort_values(keys).reset_index(drop=True),check_dtype=False)
    top=pd.read_csv(saved/"F_displayed_top20.csv",keep_default_na=False)
    pd.testing.assert_frame_equal(top,prior.head(20),check_dtype=False)
    n=len(arg)
    acc=float(np.trace(core)/n)
    summary=pd.read_csv(out/mod.title()/"100pct/Type_overall_macro_weighted_micro.csv") if mod=="protein" else pd.read_csv(out/"DNA/100pct/Type_overall_macro_weighted_micro.csv")
    own=summary[(summary.Model=="ARGScope") & (summary.Average=="macro")].iloc[0]
    assert abs(acc-own.Accuracy)<1e-14
    p=np.divide(np.diag(core),core.sum(axis=0),out=np.zeros(23),where=core.sum(axis=0)!=0)
    r=np.diag(core)/denominator
    f=np.divide(2*p*r,p+r,out=np.zeros(23),where=(p+r)!=0)
    for val,col in [(p.mean(),"Precision"),(r.mean(),"Recall"),(f.mean(),"F1")]:
        assert abs(val-own[col])<1e-14,(col,val,own[col])
    report.append(dict(modality=mod,source=str(src),sha256=sha,n_all=len(d),n_ARG=n,Type_correct=int(np.trace(core)),Type_cross_errors=int(errors.sum()),ARG_to_nonARG=int(actual.iloc[:-1,-1].sum()),Subtype_errors=len(err),Subtype_error_pairs=len(pairs),matrix_matches=True,error_pairs_match=True,latest_metrics_match=True,top_pairs=top[keys+["Count"]].head(3).to_dict("records")))
text=json.dumps(report,ensure_ascii=False,indent=2)
(Path(__file__).resolve().parent/"verification.json").write_text(text,encoding="utf-8")
print(text)
