#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
FULL SARG - FINAL DATABASE BUILD + STRICT QC

Place this script directly in:
    SARG_full_DNA_completion/

Required root files:
    3.SARG_v3.2_20220917_Long_subdatabase.fasta
    3.SARG_v3.2_20220917_Long_subdatabase_structure.txt
    Nucleotide_SARG_v3.2_Long.fasta
    Nucleotide_SARG_v3.2_Long_structure.txt
    all_arg_nonarg_dna.fasta
    all_arg_nonarg_structure.txt

Required STEP-2 files:
    02_new_NCBI_DNA_download/
        SARG_newly_retrieved_exact_natural_DNA.fasta
        SARG_new_NCBI_DNA_retrieval_results.csv

Required STEP-3 files:
    03_synthetic_backtranslation/
        SARG_remaining_backtranslated_synthetic_DNA.fasta
        SARG_remaining_backtranslated_synthetic_DNA_mapping.csv

Selection priority
------------------
ONLY validation-passing candidates are eligible.

Priority 1:
    Original nucleotide sequence from Nucleotide_SARG_v3.2_Long.

Priority 2:
    Natural DNA previously recovered/verified in all_arg_nonarg_dna,
    plus the newly NCBI-retrieved exact natural CDS.

Priority 3:
    Synthetic back-translated DNA for the final unresolved proteins.

For multiple candidates within the same source level:
    1. strict exact translation preferred over ambiguity-compatible translation
    2. fewer ambiguous nucleotide characters
    3. deterministic source/order tie-break

Final required invariant:
    full protein IDs == final protein FASTA IDs
                     == final DNA FASTA IDs
                     == final structure IDs

One protein -> exactly one selected DNA.

Final outputs:
    04_final_full_SARG_database/
        SARG_full_final_protein.fasta
        SARG_full_final_DNA.fasta
        SARG_full_final_structure.txt
        SARG_full_final_DNA_mapping.csv
        SARG_full_final_selected_translation_audit.csv
        SARG_full_all_DNA_candidate_audit.csv
        SARG_full_final_source_summary.csv
        SARG_full_final_QC_summary.txt
        QC_FAILED_proteins.csv   [only if completeness fails]
"""

from __future__ import annotations

import csv
import re
import importlib.util
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any


# =============================================================================
# Paths
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

FULL_PROTEIN_FASTA = (
    SCRIPT_DIR
    / "3.SARG_v3.2_20220917_Long_subdatabase.fasta"
)

FULL_PROTEIN_STRUCTURE = (
    SCRIPT_DIR
    / "3.SARG_v3.2_20220917_Long_subdatabase_structure.txt"
)

ORIGINAL_SARG_DNA_FASTA = (
    SCRIPT_DIR
    / "Nucleotide_SARG_v3.2_Long.fasta"
)

ORIGINAL_SARG_DNA_STRUCTURE = (
    SCRIPT_DIR
    / "Nucleotide_SARG_v3.2_Long_structure.txt"
)

PREVIOUS_VERIFIED_DNA_FASTA = (
    SCRIPT_DIR
    / "all_arg_nonarg_dna.fasta"
)

PREVIOUS_VERIFIED_STRUCTURE = (
    SCRIPT_DIR
    / "all_arg_nonarg_structure.txt"
)

NEW_NCBI_DNA_FASTA = (
    SCRIPT_DIR
    / "02_new_NCBI_DNA_download"
    / "SARG_newly_retrieved_exact_natural_DNA.fasta"
)

NEW_NCBI_RESULTS_CSV = (
    SCRIPT_DIR
    / "02_new_NCBI_DNA_download"
    / "SARG_new_NCBI_DNA_retrieval_results.csv"
)

SYNTHETIC_DNA_FASTA = (
    SCRIPT_DIR
    / "03_synthetic_backtranslation"
    / "SARG_remaining_backtranslated_synthetic_DNA.fasta"
)

SYNTHETIC_MAPPING_CSV = (
    SCRIPT_DIR
    / "03_synthetic_backtranslation"
    / "SARG_remaining_backtranslated_synthetic_DNA_mapping.csv"
)

OUTPUT_DIR = (
    SCRIPT_DIR
    / "04_final_full_SARG_database"
)

FINAL_PROTEIN_FASTA = (
    OUTPUT_DIR
    / "SARG_full_final_protein.fasta"
)

FINAL_DNA_FASTA = (
    OUTPUT_DIR
    / "SARG_full_final_DNA.fasta"
)

FINAL_STRUCTURE = (
    OUTPUT_DIR
    / "SARG_full_final_structure.txt"
)

FINAL_MAPPING = (
    OUTPUT_DIR
    / "SARG_full_final_DNA_mapping.csv"
)

FINAL_SELECTED_AUDIT = (
    OUTPUT_DIR
    / "SARG_full_final_selected_translation_audit.csv"
)

ALL_CANDIDATE_AUDIT = (
    OUTPUT_DIR
    / "SARG_full_all_DNA_candidate_audit.csv"
)

SOURCE_SUMMARY = (
    OUTPUT_DIR
    / "SARG_full_final_source_summary.csv"
)

QC_SUMMARY = (
    OUTPUT_DIR
    / "SARG_full_final_QC_summary.txt"
)

QC_FAILED_PROTEINS = (
    OUTPUT_DIR
    / "QC_FAILED_proteins.csv"
)


QC_RESCUE_FASTA = (
    OUTPUT_DIR
    / "SARG_final_QC_rescue_backtranslated_synthetic_DNA.fasta"
)

QC_RESCUE_MAPPING = (
    OUTPUT_DIR
    / "SARG_final_QC_rescue_backtranslated_synthetic_DNA_mapping.csv"
)

BACKTRANSLATION_SCRIPT = (
    SCRIPT_DIR
    / "03_backtranslate_remaining_SARG_proteins_empirical_codon_usage.py"
)


# =============================================================================
# Source definitions
# =============================================================================

SOURCE_ORIGINAL = "original_SARG_nucleotide"
SOURCE_PREVIOUS = "previous_verified_download"
SOURCE_NEW_NCBI = "new_NCBI_retrieved"
SOURCE_SYNTHETIC = "synthetic_backtranslation"

SOURCE_PRIORITY = {
    SOURCE_ORIGINAL: 1,
    SOURCE_PREVIOUS: 2,
    SOURCE_NEW_NCBI: 2,
    SOURCE_SYNTHETIC: 3,
}

# Deterministic tie-break only. Both previous/new NCBI are Priority 2 natural DNA.
SOURCE_SUBPRIORITY = {
    SOURCE_ORIGINAL: 0,
    SOURCE_PREVIOUS: 0,
    SOURCE_NEW_NCBI: 1,
    SOURCE_SYNTHETIC: 0,
}

SOURCE_NATURE = {
    SOURCE_ORIGINAL: "natural",
    SOURCE_PREVIOUS: "natural",
    SOURCE_NEW_NCBI: "natural",
    SOURCE_SYNTHETIC: "synthetic",
}


# =============================================================================
# Standard genetic code
# =============================================================================

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",

    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",

    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",

    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

BACTERIAL_START_CODONS = {
    "ATG",
    "GTG",
    "TTG",
    "CTG",
    "ATT",
    "ATC",
    "ATA",
}

CANONICAL_AA = set(
    "ACDEFGHIKLMNPQRSTVWY"
)

# Keep consistent with the previous SARG DNA verification logic:
# these target-protein residues are treated as ambiguous/wildcard positions.
AMBIGUOUS_TARGET_AA = set(
    "XBZJUO?"
)

VALID_IUPAC_DNA = set(
    "ACGTNRYKMSWBDHV"
)


# =============================================================================
# Data class
# =============================================================================

@dataclass
class Candidate:
    protein_id: str
    source: str
    source_record_id: str
    dna: str
    source_order: int
    original_nucleotide_id: str = ""
    retrieval_accession: str = ""
    retrieval_method: str = ""
    metadata_note: str = ""


# =============================================================================
# Basic helpers
# =============================================================================

def require_file(
    path: Path,
    label: str,
):
    if not path.is_file():
        raise FileNotFoundError(
            f"{label} not found:\n{path}"
        )


def canonical_id(
    value: Any,
) -> str:
    text = str(
        value
    ).strip()

    return (
        text.split()[0]
        if text
        else ""
    )


def clean_protein(
    sequence: str,
) -> str:
    return (
        "".join(
            sequence.split()
        )
        .upper()
        .replace("-", "")
        .rstrip("*")
    )


def clean_dna(
    sequence: str,
) -> str:
    return (
        "".join(
            sequence.split()
        )
        .upper()
        .replace("U", "T")
        .replace("-", "")
    )


def read_fasta(
    path: Path,
    molecule: str,
):
    order = []
    records = {}

    current_id = None
    header = ""
    chunks = []

    def save_current():
        nonlocal current_id
        nonlocal header
        nonlocal chunks

        if current_id is None:
            return

        if current_id in records:
            raise ValueError(
                f"Duplicate FASTA ID in {path.name}: {current_id}"
            )

        raw_sequence = "".join(
            chunks
        )

        if molecule == "protein":
            sequence = clean_protein(
                raw_sequence
            )

        elif molecule == "DNA":
            sequence = clean_dna(
                raw_sequence
            )

        else:
            raise ValueError(
                f"Unknown molecule: {molecule}"
            )

        records[
            current_id
        ] = {
            "header":
                header,

            "sequence":
                sequence,
        }

        order.append(
            current_id
        )

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        for line_number, raw in enumerate(
            handle,
            start=1,
        ):
            line = raw.strip()

            if not line:
                continue

            if line.startswith(">"):
                save_current()

                header = line[
                    1:
                ].strip()

                if not header:
                    raise ValueError(
                        f"Empty FASTA header: "
                        f"{path}:{line_number}"
                    )

                current_id = canonical_id(
                    header
                )

                chunks = []

            else:
                if current_id is None:
                    raise ValueError(
                        "Sequence before first FASTA header: "
                        f"{path}:{line_number}"
                    )

                chunks.append(
                    line
                )

        save_current()

    return (
        order,
        records,
    )


def detect_delimiter(
    path: Path,
) -> str:
    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        first_line = handle.readline()

    return (
        "\t"
        if "\t" in first_line
        else ","
    )


def read_table(
    path: Path,
):
    delimiter = detect_delimiter(
        path
    )

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        reader = csv.DictReader(
            handle,
            delimiter=delimiter,
        )

        if reader.fieldnames is None:
            raise ValueError(
                f"No table header: {path}"
            )

        return (
            list(
                reader.fieldnames
            ),
            list(
                reader
            ),
        )


def write_csv(
    path: Path,
    fields: list[str],
    rows: list[dict],
):
    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            extrasaction="ignore",
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def write_tsv(
    path: Path,
    fields: list[str],
    rows: list[dict],
):
    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            extrasaction="ignore",
            lineterminator="\n",
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def wrap_sequence(
    sequence: str,
    width: int = 80,
):
    return "\n".join(
        sequence[
            index:
            index + width
        ]
        for index
        in range(
            0,
            len(sequence),
            width,
        )
    )


def first_existing_value(
    row: dict,
    candidates: list[str],
):
    for column in candidates:
        if column not in row:
            continue

        value = canonical_id(
            row.get(
                column,
                "",
            )
        )

        if value:
            return value

    return ""


# =============================================================================
# Translation verification
# =============================================================================

def translate_frame0(
    dna: str,
    target_starts_m: bool,
):
    dna = clean_dna(
        dna
    )

    translated = []

    for index in range(
        0,
        len(dna) - 2,
        3,
    ):
        codon = dna[
            index:
            index + 3
        ]

        translated.append(
            CODON_TABLE.get(
                codon,
                "X",
            )
        )

    if (
        translated
        and target_starts_m
        and dna[
            :3
        ] in BACTERIAL_START_CODONS
    ):
        translated[
            0
        ] = "M"

    return "".join(
        translated
    )


def residues_compatible(
    target: str,
    translated_without_terminal_stop: str,
):
    if len(
        target
    ) != len(
        translated_without_terminal_stop
    ):
        return False

    for target_aa, translated_aa in zip(
        target,
        translated_without_terminal_stop,
    ):
        if target_aa in AMBIGUOUS_TARGET_AA:
            # Ambiguous target residue can match any translated residue
            # except an internal stop.
            if translated_aa == "*":
                return False

            continue

        if target_aa != translated_aa:
            return False

    return True


def verify_dna_to_protein(
    protein_sequence: str,
    dna_sequence: str,
    source: str,
):
    protein = clean_protein(
        protein_sequence
    )

    dna = clean_dna(
        dna_sequence
    )

    invalid_dna_chars = sorted(
        set(
            dna
        )
        - VALID_IUPAC_DNA
    )

    frame0_translation_raw = translate_frame0(
        dna,
        target_starts_m=protein.startswith(
            "M"
        ),
    )

    terminal_stop_present = (
        frame0_translation_raw.endswith(
            "*"
        )
    )

    translation_no_terminal_stop = (
        frame0_translation_raw[
            :-1
        ]
        if terminal_stop_present
        else frame0_translation_raw
    )

    internal_stop_count = (
        translation_no_terminal_stop.count(
            "*"
        )
    )

    if source == SOURCE_SYNTHETIC:
        allowed_lengths = {
            3
            * len(
                protein
            )
        }

    else:
        allowed_lengths = {
            3
            * len(
                protein
            ),
            3
            * (
                len(
                    protein
                )
                + 1
            ),
        }

    length_valid = (
        len(
            dna
        )
        in allowed_lengths
    )

    compatible = residues_compatible(
        protein,
        translation_no_terminal_stop,
    )

    strict_exact = (
        protein
        == translation_no_terminal_stop
    )

    no_internal_stops = (
        internal_stop_count
        == 0
    )

    alphabet_valid = (
        len(
            invalid_dna_chars
        )
        == 0
    )

    accepted = (
        length_valid
        and no_internal_stops
        and compatible
        and alphabet_valid
    )

    ambiguous_nt_count = sum(
        base not in {
            "A",
            "C",
            "G",
            "T",
        }
        for base in dna
    )

    if accepted:
        match_class = (
            "strict_exact"
            if strict_exact
            else "compatible_exact"
        )

    else:
        match_class = "failed"

    failure_reasons = []

    if not alphabet_valid:
        failure_reasons.append(
            "invalid_DNA_alphabet"
        )

    if not length_valid:
        failure_reasons.append(
            "unexpected_DNA_length"
        )

    if not no_internal_stops:
        failure_reasons.append(
            "internal_stop"
        )

    if not compatible:
        failure_reasons.append(
            "translation_mismatch"
        )

    return {
        "accepted":
            accepted,

        "match_class":
            match_class,

        "strict_exact":
            strict_exact,

        "compatible_exact":
            compatible,

        "protein_length_aa":
            len(
                protein
            ),

        "DNA_length_nt":
            len(
                dna
            ),

        "translated_length_aa":
            len(
                translation_no_terminal_stop
            ),

        "terminal_stop_present":
            terminal_stop_present,

        "internal_stop_count":
            internal_stop_count,

        "length_valid":
            length_valid,

        "alphabet_valid":
            alphabet_valid,

        "invalid_DNA_chars":
            "".join(
                invalid_dna_chars
            ),

        "ambiguous_nt_count":
            ambiguous_nt_count,

        "failure_reason":
            ";".join(
                failure_reasons
            ),

        "translated_sequence":
            translation_no_terminal_stop,
    }


# =============================================================================
# Load full protein universe
# =============================================================================

def load_full_protein_database():
    protein_order, protein_records = read_fasta(
        FULL_PROTEIN_FASTA,
        "protein",
    )

    structure_fields, structure_rows = read_table(
        FULL_PROTEIN_STRUCTURE
    )

    required_columns = {
        "SARG.Seq.ID",
        "Type",
        "Subtype",
    }

    missing = (
        required_columns
        - set(
            structure_fields
        )
    )

    if missing:
        raise ValueError(
            "Full SARG protein structure missing columns: "
            f"{sorted(missing)}"
        )

    structure_by_id = {}

    subtype_to_type = {}

    for row in structure_rows:
        protein_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        if not protein_id:
            raise ValueError(
                "Empty SARG.Seq.ID in full protein structure"
            )

        if protein_id in structure_by_id:
            raise ValueError(
                f"Duplicate SARG.Seq.ID in full structure: {protein_id}"
            )

        type_name = str(
            row.get(
                "Type",
                "",
            )
        ).strip()

        subtype_name = str(
            row.get(
                "Subtype",
                "",
            )
        ).strip()

        if (
            subtype_name in subtype_to_type
            and subtype_to_type[
                subtype_name
            ]
            != type_name
        ):
            raise ValueError(
                "Subtype maps to multiple Types: "
                f"{subtype_name}"
            )

        subtype_to_type[
            subtype_name
        ] = type_name

        structure_by_id[
            protein_id
        ] = row

    fasta_ids = set(
        protein_records
    )

    structure_ids = set(
        structure_by_id
    )

    if fasta_ids != structure_ids:
        raise ValueError(
            "Full protein FASTA/structure IDs differ:\n"
            f"  FASTA only     = "
            f"{len(fasta_ids-structure_ids)}\n"
            f"  Structure only = "
            f"{len(structure_ids-fasta_ids)}"
        )

    return (
        protein_order,
        protein_records,
        structure_fields,
        structure_by_id,
    )


# =============================================================================
# Candidate source 1: original SARG nucleotide
# =============================================================================

def load_original_sarg_candidates(
    full_protein_ids: set[str],
):
    dna_order, dna_records = read_fasta(
        ORIGINAL_SARG_DNA_FASTA,
        "DNA",
    )

    structure_fields, structure_rows = read_table(
        ORIGINAL_SARG_DNA_STRUCTURE
    )

    required = {
        "AminoAcidID",
        "NucleotideID",
    }

    missing = (
        required
        - set(
            structure_fields
        )
    )

    if missing:
        raise ValueError(
            "Original nucleotide structure missing columns: "
            f"{sorted(missing)}"
        )

    dna_ids_in_structure = []

    candidates = defaultdict(
        list
    )

    source_order = 0

    for row in structure_rows:
        protein_id = canonical_id(
            row.get(
                "AminoAcidID",
                "",
            )
        )

        nucleotide_id = canonical_id(
            row.get(
                "NucleotideID",
                "",
            )
        )

        if not nucleotide_id:
            raise ValueError(
                "Original nucleotide structure contains empty NucleotideID"
            )

        dna_ids_in_structure.append(
            nucleotide_id
        )

        if protein_id not in full_protein_ids:
            continue

        if nucleotide_id not in dna_records:
            continue

        source_order += 1

        candidates[
            protein_id
        ].append(
            Candidate(
                protein_id=protein_id,
                source=SOURCE_ORIGINAL,
                source_record_id=nucleotide_id,
                dna=dna_records[
                    nucleotide_id
                ][
                    "sequence"
                ],
                source_order=source_order,
                original_nucleotide_id=nucleotide_id,
                metadata_note="Nucleotide_SARG_v3.2_Long",
            )
        )

    if set(
        dna_order
    ) != set(
        dna_ids_in_structure
    ):
        raise ValueError(
            "Original nucleotide FASTA/structure IDs differ:\n"
            f"  FASTA only     = "
            f"{len(set(dna_order)-set(dna_ids_in_structure))}\n"
            f"  Structure only = "
            f"{len(set(dna_ids_in_structure)-set(dna_order))}"
        )

    return candidates


# =============================================================================
# Candidate source 2A: previous all_arg_nonarg verified DNA
# =============================================================================

def load_previous_verified_candidates(
    full_protein_ids: set[str],
):
    dna_order, dna_records = read_fasta(
        PREVIOUS_VERIFIED_DNA_FASTA,
        "DNA",
    )

    structure_fields, structure_rows = read_table(
        PREVIOUS_VERIFIED_STRUCTURE
    )

    candidates = defaultdict(
        list
    )

    seen_pairs = set()

    source_order = 0

    def add_candidate(
        protein_id: str,
        dna_id: str,
        note: str,
    ):
        nonlocal source_order

        if protein_id not in full_protein_ids:
            return

        if dna_id not in dna_records:
            return

        key = (
            protein_id,
            dna_id,
        )

        if key in seen_pairs:
            return

        seen_pairs.add(
            key
        )

        source_order += 1

        candidates[
            protein_id
        ].append(
            Candidate(
                protein_id=protein_id,
                source=SOURCE_PREVIOUS,
                source_record_id=dna_id,
                dna=dna_records[
                    dna_id
                ][
                    "sequence"
                ],
                source_order=source_order,
                metadata_note=note,
            )
        )

    # Most final paired datasets use protein ID directly as DNA FASTA ID.
    for dna_id in dna_order:
        if dna_id in full_protein_ids:
            add_candidate(
                dna_id,
                dna_id,
                "direct_FASTA_ID_match",
            )

    protein_id_columns = [
        "protein_id",
        "AminoAcidID",
        "Original.SARG.Seq.ID",
        "Original_SARG_Seq_ID",
        "SARG.Seq.ID",
        "SARG_Seq_ID",
    ]

    dna_id_columns = [
        "DNA_id",
        "DNA.ID",
        "NucleotideID",
        "Nucleotide.ID",
        "output_DNA_id",
        "original_DNA_id",
        "Selected.DNA.ID",
    ]

    for row in structure_rows:
        possible_protein_ids = []

        for column in protein_id_columns:
            if column not in row:
                continue

            value = canonical_id(
                row.get(
                    column,
                    "",
                )
            )

            if (
                value
                and value in full_protein_ids
                and value not in possible_protein_ids
            ):
                possible_protein_ids.append(
                    value
                )

        if not possible_protein_ids:
            continue

        dna_id = first_existing_value(
            row,
            dna_id_columns,
        )

        # If no explicit DNA column exists, paired datasets commonly use
        # protein ID itself as FASTA ID.
        for protein_id in possible_protein_ids:
            candidate_dna_id = dna_id

            if candidate_dna_id not in dna_records:
                if protein_id in dna_records:
                    candidate_dna_id = protein_id
                else:
                    continue

            add_candidate(
                protein_id,
                candidate_dna_id,
                "structure_mapping",
            )

    return candidates


# =============================================================================
# Candidate source 2B: newly retrieved NCBI natural CDS
# =============================================================================

def load_new_ncbi_candidates(
    full_protein_ids: set[str],
):
    dna_order, dna_records = read_fasta(
        NEW_NCBI_DNA_FASTA,
        "DNA",
    )

    result_fields, result_rows = read_table(
        NEW_NCBI_RESULTS_CSV
    )

    result_by_protein = {}

    if "protein_id" in result_fields:
        for row in result_rows:
            protein_id = canonical_id(
                row.get(
                    "protein_id",
                    "",
                )
            )

            if not protein_id:
                continue

            if str(
                row.get(
                    "status",
                    "",
                )
            ).strip() != "EXACT_NATURAL_CDS":
                continue

            result_by_protein[
                protein_id
            ] = row

    candidates = defaultdict(
        list
    )

    source_order = 0

    for dna_id in dna_order:
        # STEP 2 outputs the original protein ID as the first FASTA token.
        protein_id = dna_id

        if protein_id not in full_protein_ids:
            continue

        source_order += 1

        result_row = result_by_protein.get(
            protein_id,
            {},
        )

        candidates[
            protein_id
        ].append(
            Candidate(
                protein_id=protein_id,
                source=SOURCE_NEW_NCBI,
                source_record_id=dna_id,
                dna=dna_records[
                    dna_id
                ][
                    "sequence"
                ],
                source_order=source_order,
                retrieval_accession=str(
                    result_row.get(
                        "nucleotide_accession",
                        "",
                    )
                ).strip(),
                retrieval_method=str(
                    result_row.get(
                        "retrieval_method",
                        "",
                    )
                ).strip(),
                metadata_note="STEP2_exact_natural_CDS",
            )
        )

    return candidates


# =============================================================================
# Candidate source 3: synthetic backtranslation
# =============================================================================

def load_synthetic_candidates(
    full_protein_ids: set[str],
):
    dna_order, dna_records = read_fasta(
        SYNTHETIC_DNA_FASTA,
        "DNA",
    )

    mapping_fields, mapping_rows = read_table(
        SYNTHETIC_MAPPING_CSV
    )

    mapping_by_protein = {}

    if "protein_id" in mapping_fields:
        for row in mapping_rows:
            protein_id = canonical_id(
                row.get(
                    "protein_id",
                    "",
                )
            )

            if protein_id:
                mapping_by_protein[
                    protein_id
                ] = row

    candidates = defaultdict(
        list
    )

    source_order = 0

    for dna_id in dna_order:
        protein_id = dna_id

        if protein_id not in full_protein_ids:
            continue

        source_order += 1

        row = mapping_by_protein.get(
            protein_id,
            {},
        )

        candidates[
            protein_id
        ].append(
            Candidate(
                protein_id=protein_id,
                source=SOURCE_SYNTHETIC,
                source_record_id=dna_id,
                dna=dna_records[
                    dna_id
                ][
                    "sequence"
                ],
                source_order=source_order,
                metadata_note=str(
                    row.get(
                        "DNA_source",
                        DNA_SOURCE_IF_MISSING,
                    )
                ).strip(),
            )
        )

    return candidates


DNA_SOURCE_IF_MISSING = (
    "synthetic_backtranslation_empirical_SARG_codon_usage"
)


# =============================================================================
# Candidate evaluation / selection
# =============================================================================

def evaluate_all_candidates(
    protein_order,
    protein_records,
    candidate_maps,
):
    all_candidates_by_protein = defaultdict(
        list
    )

    for candidate_map in candidate_maps:
        for protein_id, candidates in candidate_map.items():
            all_candidates_by_protein[
                protein_id
            ].extend(
                candidates
            )

    candidate_audit_rows = []

    evaluated_by_protein = defaultdict(
        list
    )

    for protein_id in protein_order:
        protein_sequence = protein_records[
            protein_id
        ][
            "sequence"
        ]

        for candidate in all_candidates_by_protein.get(
            protein_id,
            [],
        ):
            verification = verify_dna_to_protein(
                protein_sequence,
                candidate.dna,
                candidate.source,
            )

            evaluated = {
                "candidate":
                    candidate,

                "verification":
                    verification,
            }

            evaluated_by_protein[
                protein_id
            ].append(
                evaluated
            )

            candidate_audit_rows.append(
                {
                    "protein_id":
                        protein_id,

                    "source":
                        candidate.source,

                    "source_priority":
                        SOURCE_PRIORITY[
                            candidate.source
                        ],

                    "natural_or_synthetic":
                        SOURCE_NATURE[
                            candidate.source
                        ],

                    "source_record_id":
                        candidate.source_record_id,

                    "original_nucleotide_id":
                        candidate.original_nucleotide_id,

                    "retrieval_accession":
                        candidate.retrieval_accession,

                    "retrieval_method":
                        candidate.retrieval_method,

                    "source_order":
                        candidate.source_order,

                    "accepted":
                        verification[
                            "accepted"
                        ],

                    "match_class":
                        verification[
                            "match_class"
                        ],

                    "strict_exact":
                        verification[
                            "strict_exact"
                        ],

                    "compatible_exact":
                        verification[
                            "compatible_exact"
                        ],

                    "protein_length_aa":
                        verification[
                            "protein_length_aa"
                        ],

                    "DNA_length_nt":
                        verification[
                            "DNA_length_nt"
                        ],

                    "translated_length_aa":
                        verification[
                            "translated_length_aa"
                        ],

                    "terminal_stop_present":
                        verification[
                            "terminal_stop_present"
                        ],

                    "internal_stop_count":
                        verification[
                            "internal_stop_count"
                        ],

                    "length_valid":
                        verification[
                            "length_valid"
                        ],

                    "alphabet_valid":
                        verification[
                            "alphabet_valid"
                        ],

                    "invalid_DNA_chars":
                        verification[
                            "invalid_DNA_chars"
                        ],

                    "ambiguous_nt_count":
                        verification[
                            "ambiguous_nt_count"
                        ],

                    "failure_reason":
                        verification[
                            "failure_reason"
                        ],

                    "metadata_note":
                        candidate.metadata_note,
                }
            )

    return (
        evaluated_by_protein,
        candidate_audit_rows,
    )


def candidate_rank(
    evaluated,
):
    candidate = evaluated[
        "candidate"
    ]

    verification = evaluated[
        "verification"
    ]

    return (
        SOURCE_PRIORITY[
            candidate.source
        ],

        0
        if verification[
            "strict_exact"
        ]
        else 1,

        verification[
            "ambiguous_nt_count"
        ],

        SOURCE_SUBPRIORITY[
            candidate.source
        ],

        candidate.source_order,

        candidate.source_record_id,
    )


def select_one_per_protein(
    protein_order,
    evaluated_by_protein,
):
    selected = {}

    unresolved_rows = []

    for protein_id in protein_order:
        evaluated_candidates = evaluated_by_protein.get(
            protein_id,
            [],
        )

        accepted = [
            item
            for item
            in evaluated_candidates
            if item[
                "verification"
            ][
                "accepted"
            ]
        ]

        if not accepted:
            source_status = Counter(
                item[
                    "candidate"
                ].source
                for item
                in evaluated_candidates
            )

            failure_details = []

            for item in evaluated_candidates:
                candidate = item[
                    "candidate"
                ]

                verification = item[
                    "verification"
                ]

                failure_details.append(
                    (
                        f"{candidate.source}:"
                        f"{candidate.source_record_id}:"
                        f"{verification['failure_reason']}"
                    )
                )

            unresolved_rows.append(
                {
                    "protein_id":
                        protein_id,

                    "candidate_count":
                        len(
                            evaluated_candidates
                        ),

                    "candidate_source_counts":
                        ";".join(
                            f"{source}={count}"
                            for source, count
                            in sorted(
                                source_status.items()
                            )
                        ),

                    "failure_details":
                        " | ".join(
                            failure_details
                        ),
                }
            )

            continue

        accepted.sort(
            key=candidate_rank
        )

        selected[
            protein_id
        ] = accepted[
            0
        ]

    return (
        selected,
        unresolved_rows,
    )



# =============================================================================
# Automatic final-QC rescue
# =============================================================================

def load_backtranslation_module():
    """
    Reuse exactly the same empirical SARG codon-usage backtranslation logic
    that was used in STEP 3. This avoids maintaining a second, divergent
    backtranslation implementation here.
    """
    if not BACKTRANSLATION_SCRIPT.is_file():
        raise FileNotFoundError(
            "Backtranslation script required for automatic QC rescue not found:\n"
            f"{BACKTRANSLATION_SCRIPT}"
        )

    spec = importlib.util.spec_from_file_location(
        "sarg_step3_backtranslation",
        BACKTRANSLATION_SCRIPT,
    )

    if spec is None or spec.loader is None:
        raise RuntimeError(
            f"Could not import STEP-3 backtranslation script:\n"
            f"{BACKTRANSLATION_SCRIPT}"
        )

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    required_functions = [
        "learn_empirical_codon_usage",
        "backtranslate_one",
    ]

    for function_name in required_functions:
        if not hasattr(module, function_name):
            raise RuntimeError(
                "STEP-3 backtranslation script is missing required function: "
                f"{function_name}"
            )

    return module


def rescue_unresolved_with_empirical_backtranslation(
    unresolved_rows,
    protein_records,
    structure_by_id,
    evaluated_by_protein,
    candidate_audit_rows,
):
    """
    If an old/original DNA was PRESENT but fails final translation QC, that
    protein was never sent through the earlier 'missing DNA' workflow.

    Such a protein is biologically equivalent to having no usable DNA for the
    final paired database. To preserve 100% protein coverage, generate exactly
    ONE explicitly-labelled synthetic DNA using the same empirical SARG codon
    usage strategy as STEP 3.

    This rescue is only invoked AFTER:
        original SARG DNA,
        previous verified/downloaded DNA,
        newly downloaded NCBI DNA,
        STEP-3 synthetic DNA
    have all failed to provide a validation-passing candidate.
    """
    unresolved_ids = [
        row["protein_id"]
        for row in unresolved_rows
    ]

    if not unresolved_ids:
        return []

    print()
    print(
        "FINAL QC RESCUE:",
        flush=True,
    )
    print(
        f"  {len(unresolved_ids):,} protein(s) have DNA records, "
        "but none pass the final translation QC.",
        flush=True,
    )
    print(
        "  Generating one additional explicitly-labelled synthetic "
        "backtranslation for each using the SAME STEP-3 empirical "
        "SARG codon-usage method.",
        flush=True,
    )

    bt = load_backtranslation_module()

    learned = bt.learn_empirical_codon_usage()

    # Current STEP-3 returns:
    # codon_probs, aa_probs, natural_gc_values, ...
    codon_probs = learned[0]
    aa_probs = learned[1]
    natural_gc_values = learned[2]

    rescue_records = []
    rescue_mapping_rows = []

    source_order_base = 10_000_000

    for rescue_index, protein_id in enumerate(
        unresolved_ids,
        start=1,
    ):
        protein_sequence = protein_records[
            protein_id
        ][
            "sequence"
        ]

        result = bt.backtranslate_one(
            protein_id,
            protein_sequence,
            codon_probs,
            aa_probs,
            natural_gc_values,
        )

        dna = clean_dna(
            result[
                "dna"
            ]
        )

        candidate = Candidate(
            protein_id=protein_id,
            source=SOURCE_SYNTHETIC,
            source_record_id=(
                f"{protein_id}__FINAL_QC_RESCUE"
            ),
            dna=dna,
            source_order=(
                source_order_base
                + rescue_index
            ),
            metadata_note=(
                "final_QC_rescue_after_all_natural_and_existing_candidates_"
                "failed_translation_validation"
            ),
        )

        verification = verify_dna_to_protein(
            protein_sequence,
            dna,
            SOURCE_SYNTHETIC,
        )

        if not verification[
            "accepted"
        ]:
            raise RuntimeError(
                "Automatic final-QC rescue produced a DNA that failed "
                f"verification for protein: {protein_id}"
            )

        evaluated_by_protein[
            protein_id
        ].append(
            {
                "candidate":
                    candidate,

                "verification":
                    verification,
            }
        )

        candidate_audit_rows.append(
            {
                "protein_id":
                    protein_id,

                "source":
                    candidate.source,

                "source_priority":
                    SOURCE_PRIORITY[
                        candidate.source
                    ],

                "natural_or_synthetic":
                    SOURCE_NATURE[
                        candidate.source
                    ],

                "source_record_id":
                    candidate.source_record_id,

                "original_nucleotide_id":
                    "",

                "retrieval_accession":
                    "",

                "retrieval_method":
                    "",

                "source_order":
                    candidate.source_order,

                "accepted":
                    verification[
                        "accepted"
                    ],

                "match_class":
                    verification[
                        "match_class"
                    ],

                "strict_exact":
                    verification[
                        "strict_exact"
                    ],

                "compatible_exact":
                    verification[
                        "compatible_exact"
                    ],

                "protein_length_aa":
                    verification[
                        "protein_length_aa"
                    ],

                "DNA_length_nt":
                    verification[
                        "DNA_length_nt"
                    ],

                "translated_length_aa":
                    verification[
                        "translated_length_aa"
                    ],

                "terminal_stop_present":
                    verification[
                        "terminal_stop_present"
                    ],

                "internal_stop_count":
                    verification[
                        "internal_stop_count"
                    ],

                "length_valid":
                    verification[
                        "length_valid"
                    ],

                "alphabet_valid":
                    verification[
                        "alphabet_valid"
                    ],

                "invalid_DNA_chars":
                    verification[
                        "invalid_DNA_chars"
                    ],

                "ambiguous_nt_count":
                    verification[
                        "ambiguous_nt_count"
                    ],

                "failure_reason":
                    verification[
                        "failure_reason"
                    ],

                "metadata_note":
                    candidate.metadata_note,
            }
        )

        structure_row = structure_by_id[
            protein_id
        ]

        rescue_records.append(
            {
                "protein_id":
                    protein_id,

                "dna":
                    dna,

                "Type":
                    str(
                        structure_row.get(
                            "Type",
                            "",
                        )
                    ).strip(),

                "Subtype":
                    str(
                        structure_row.get(
                            "Subtype",
                            "",
                        )
                    ).strip(),

                "previous_candidate_failure_summary":
                    next(
                        (
                            row.get(
                                "failure_details",
                                "",
                            )
                            for row
                            in unresolved_rows
                            if row[
                                "protein_id"
                            ] == protein_id
                        ),
                        "",
                    ),
            }
        )

        rescue_mapping_rows.append(
            {
                "DNA_id":
                    protein_id,

                "protein_id":
                    protein_id,

                "Type":
                    str(
                        structure_row.get(
                            "Type",
                            "",
                        )
                    ).strip(),

                "Subtype":
                    str(
                        structure_row.get(
                            "Subtype",
                            "",
                        )
                    ).strip(),

                "DNA_source":
                    SOURCE_SYNTHETIC,

                "natural_or_synthetic":
                    "synthetic",

                "rescue_reason":
                    (
                        "all_existing_candidates_failed_final_translation_QC"
                    ),

                "protein_length_aa":
                    len(
                        clean_protein(
                            protein_sequence
                        )
                    ),

                "DNA_length_nt":
                    len(
                        dna
                    ),

                "target_empirical_GC_fraction":
                    result.get(
                        "target_gc",
                        "",
                    ),

                "synthetic_GC_fraction":
                    result.get(
                        "gc",
                        "",
                    ),

                "GC_distance":
                    result.get(
                        "gc_distance",
                        "",
                    ),

                "ambiguous_AA_resolutions":
                    ";".join(
                        result.get(
                            "resolutions",
                            [],
                        )
                    ),

                "selected_candidate_index":
                    result.get(
                        "candidate_index",
                        "",
                    ),
            }
        )

        print(
            f"    rescue [{rescue_index}/{len(unresolved_ids)}] "
            f"{protein_id} -> PASS",
            flush=True,
        )

    with QC_RESCUE_FASTA.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:
        for record in rescue_records:
            handle.write(
                f">{record['protein_id']} "
                f"DNA_source={SOURCE_SYNTHETIC} "
                f"natural_or_synthetic=synthetic "
                f"rescue_reason=existing_DNA_failed_final_QC "
                f"Type={record['Type']} "
                f"Subtype={record['Subtype']}\n"
                f"{wrap_sequence(record['dna'])}\n"
            )

    write_csv(
        QC_RESCUE_MAPPING,
        [
            "DNA_id",
            "protein_id",
            "Type",
            "Subtype",
            "DNA_source",
            "natural_or_synthetic",
            "rescue_reason",
            "protein_length_aa",
            "DNA_length_nt",
            "target_empirical_GC_fraction",
            "synthetic_GC_fraction",
            "GC_distance",
            "ambiguous_AA_resolutions",
            "selected_candidate_index",
        ],
        rescue_mapping_rows,
    )

    return rescue_records


# =============================================================================
# Final outputs + QC
# =============================================================================

def build_final_outputs(
    protein_order,
    protein_records,
    structure_fields,
    structure_by_id,
    selected,
    candidate_audit_rows,
):
    # ------------------------------------------------------------------
    # Candidate audit is written even if final completeness fails.
    # ------------------------------------------------------------------

    write_csv(
        ALL_CANDIDATE_AUDIT,
        [
            "protein_id",
            "source",
            "source_priority",
            "natural_or_synthetic",
            "source_record_id",
            "original_nucleotide_id",
            "retrieval_accession",
            "retrieval_method",
            "source_order",
            "accepted",
            "match_class",
            "strict_exact",
            "compatible_exact",
            "protein_length_aa",
            "DNA_length_nt",
            "translated_length_aa",
            "terminal_stop_present",
            "internal_stop_count",
            "length_valid",
            "alphabet_valid",
            "invalid_DNA_chars",
            "ambiguous_nt_count",
            "failure_reason",
            "metadata_note",
        ],
        candidate_audit_rows,
    )

    expected_ids = set(
        protein_order
    )

    selected_ids = set(
        selected
    )

    if selected_ids != expected_ids:
        raise RuntimeError(
            "Internal completeness error before final output: "
            f"selected={len(selected_ids)}, "
            f"expected={len(expected_ids)}"
        )

    # ------------------------------------------------------------------
    # Protein FASTA: preserve original full-SARG protein sequence/header.
    # ------------------------------------------------------------------

    with FINAL_PROTEIN_FASTA.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:
        for protein_id in protein_order:
            record = protein_records[
                protein_id
            ]

            handle.write(
                f">{record['header']}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

    # ------------------------------------------------------------------
    # DNA FASTA:
    # normalize first token to protein ID for exact one-to-one pairing.
    # Keep original source ID/accession in the header metadata.
    # ------------------------------------------------------------------

    with FINAL_DNA_FASTA.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:
        for protein_id in protein_order:
            evaluated = selected[
                protein_id
            ]

            candidate = evaluated[
                "candidate"
            ]

            verification = evaluated[
                "verification"
            ]

            source_identifier = (
                candidate.original_nucleotide_id
                or candidate.retrieval_accession
                or candidate.source_record_id
            )

            handle.write(
                f">{protein_id} "
                f"DNA_source={candidate.source} "
                f"natural_or_synthetic="
                f"{SOURCE_NATURE[candidate.source]} "
                f"source_record_id={candidate.source_record_id} "
                f"source_accession={source_identifier} "
                f"translation_match="
                f"{verification['match_class']}\n"
                f"{wrap_sequence(candidate.dna)}\n"
            )

    # ------------------------------------------------------------------
    # Mapping / structure / selected audit.
    # ------------------------------------------------------------------

    mapping_rows = []

    structure_rows = []

    selected_audit_rows = []

    selected_source_counts = Counter()

    selected_match_counts = Counter()

    selected_nature_counts = Counter()

    for protein_id in protein_order:
        original_row = structure_by_id[
            protein_id
        ]

        evaluated = selected[
            protein_id
        ]

        candidate = evaluated[
            "candidate"
        ]

        verification = evaluated[
            "verification"
        ]

        selected_source_counts[
            candidate.source
        ] += 1

        selected_match_counts[
            verification[
                "match_class"
            ]
        ] += 1

        selected_nature_counts[
            SOURCE_NATURE[
                candidate.source
            ]
        ] += 1

        source_identifier = (
            candidate.original_nucleotide_id
            or candidate.retrieval_accession
            or candidate.source_record_id
        )

        mapping_rows.append(
            {
                "protein_id":
                    protein_id,

                "DNA_id":
                    protein_id,

                "Type":
                    str(
                        original_row.get(
                            "Type",
                            "",
                        )
                    ).strip(),

                "Subtype":
                    str(
                        original_row.get(
                            "Subtype",
                            "",
                        )
                    ).strip(),

                "DNA_source":
                    candidate.source,

                "source_priority":
                    SOURCE_PRIORITY[
                        candidate.source
                    ],

                "natural_or_synthetic":
                    SOURCE_NATURE[
                        candidate.source
                    ],

                "source_record_id":
                    candidate.source_record_id,

                "original_nucleotide_id":
                    candidate.original_nucleotide_id,

                "retrieval_accession":
                    candidate.retrieval_accession,

                "retrieval_method":
                    candidate.retrieval_method,

                "translation_match":
                    verification[
                        "match_class"
                    ],

                "protein_length_aa":
                    verification[
                        "protein_length_aa"
                    ],

                "DNA_length_nt":
                    verification[
                        "DNA_length_nt"
                    ],

                "terminal_stop_present":
                    verification[
                        "terminal_stop_present"
                    ],

                "ambiguous_nt_count":
                    verification[
                        "ambiguous_nt_count"
                    ],
            }
        )

        structure_row = {
            "SARG.Seq.ID":
                protein_id,

            "Type":
                str(
                    original_row.get(
                        "Type",
                        "",
                    )
                ).strip(),

            "Subtype":
                str(
                    original_row.get(
                        "Subtype",
                        "",
                    )
                ).strip(),

            "DNA.ID":
                protein_id,

            "DNA.Source":
                candidate.source,

            "Natural.or.Synthetic":
                SOURCE_NATURE[
                    candidate.source
                ],

            "Source.Record.ID":
                candidate.source_record_id,

            "Source.Accession":
                source_identifier,

            "Translation.Match":
                verification[
                    "match_class"
                ],

            "Protein.Length.aa":
                verification[
                    "protein_length_aa"
                ],

            "DNA.Length.nt":
                verification[
                    "DNA_length_nt"
                ],
        }

        # Preserve any additional columns from the original full-SARG structure.
        for field in structure_fields:
            if field in {
                "SARG.Seq.ID",
                "Type",
                "Subtype",
            }:
                continue

            output_field = (
                field
                if field not in structure_row
                else f"Original.{field}"
            )

            structure_row[
                output_field
            ] = original_row.get(
                field,
                "",
            )

        structure_rows.append(
            structure_row
        )

        selected_audit_rows.append(
            {
                "protein_id":
                    protein_id,

                "DNA_source":
                    candidate.source,

                "natural_or_synthetic":
                    SOURCE_NATURE[
                        candidate.source
                    ],

                "source_record_id":
                    candidate.source_record_id,

                "source_accession":
                    source_identifier,

                "accepted":
                    verification[
                        "accepted"
                    ],

                "match_class":
                    verification[
                        "match_class"
                    ],

                "strict_exact":
                    verification[
                        "strict_exact"
                    ],

                "compatible_exact":
                    verification[
                        "compatible_exact"
                    ],

                "protein_length_aa":
                    verification[
                        "protein_length_aa"
                    ],

                "DNA_length_nt":
                    verification[
                        "DNA_length_nt"
                    ],

                "translated_length_aa":
                    verification[
                        "translated_length_aa"
                    ],

                "terminal_stop_present":
                    verification[
                        "terminal_stop_present"
                    ],

                "internal_stop_count":
                    verification[
                        "internal_stop_count"
                    ],

                "length_valid":
                    verification[
                        "length_valid"
                    ],

                "alphabet_valid":
                    verification[
                        "alphabet_valid"
                    ],

                "ambiguous_nt_count":
                    verification[
                        "ambiguous_nt_count"
                    ],
            }
        )

    write_csv(
        FINAL_MAPPING,
        [
            "protein_id",
            "DNA_id",
            "Type",
            "Subtype",
            "DNA_source",
            "source_priority",
            "natural_or_synthetic",
            "source_record_id",
            "original_nucleotide_id",
            "retrieval_accession",
            "retrieval_method",
            "translation_match",
            "protein_length_aa",
            "DNA_length_nt",
            "terminal_stop_present",
            "ambiguous_nt_count",
        ],
        mapping_rows,
    )

    base_structure_fields = [
        "SARG.Seq.ID",
        "Type",
        "Subtype",
        "DNA.ID",
        "DNA.Source",
        "Natural.or.Synthetic",
        "Source.Record.ID",
        "Source.Accession",
        "Translation.Match",
        "Protein.Length.aa",
        "DNA.Length.nt",
    ]

    extra_structure_fields = []

    for field in structure_fields:
        if field in {
            "SARG.Seq.ID",
            "Type",
            "Subtype",
        }:
            continue

        output_field = (
            field
            if field not in base_structure_fields
            else f"Original.{field}"
        )

        if output_field not in extra_structure_fields:
            extra_structure_fields.append(
                output_field
            )

    final_structure_fields = (
        base_structure_fields
        + extra_structure_fields
    )

    write_tsv(
        FINAL_STRUCTURE,
        final_structure_fields,
        structure_rows,
    )

    write_csv(
        FINAL_SELECTED_AUDIT,
        [
            "protein_id",
            "DNA_source",
            "natural_or_synthetic",
            "source_record_id",
            "source_accession",
            "accepted",
            "match_class",
            "strict_exact",
            "compatible_exact",
            "protein_length_aa",
            "DNA_length_nt",
            "translated_length_aa",
            "terminal_stop_present",
            "internal_stop_count",
            "length_valid",
            "alphabet_valid",
            "ambiguous_nt_count",
        ],
        selected_audit_rows,
    )

    source_summary_rows = []

    for source in [
        SOURCE_ORIGINAL,
        SOURCE_PREVIOUS,
        SOURCE_NEW_NCBI,
        SOURCE_SYNTHETIC,
    ]:
        count = selected_source_counts.get(
            source,
            0,
        )

        source_summary_rows.append(
            {
                "DNA_source":
                    source,

                "natural_or_synthetic":
                    SOURCE_NATURE[
                        source
                    ],

                "selected_count":
                    count,

                "percent_of_final":
                    (
                        100.0
                        * count
                        / len(
                            protein_order
                        )
                    ),
            }
        )

    write_csv(
        SOURCE_SUMMARY,
        [
            "DNA_source",
            "natural_or_synthetic",
            "selected_count",
            "percent_of_final",
        ],
        source_summary_rows,
    )

    return {
        "selected_source_counts":
            selected_source_counts,

        "selected_match_counts":
            selected_match_counts,

        "selected_nature_counts":
            selected_nature_counts,
    }


def final_roundtrip_qc(
    expected_protein_order,
    structure_by_id,
):
    # Re-read the newly written final files from disk.
    final_protein_order, final_proteins = read_fasta(
        FINAL_PROTEIN_FASTA,
        "protein",
    )

    final_dna_order, final_dna = read_fasta(
        FINAL_DNA_FASTA,
        "DNA",
    )

    final_structure_fields, final_structure_rows = read_table(
        FINAL_STRUCTURE
    )

    final_structure_ids = [
        canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )
        for row
        in final_structure_rows
    ]

    expected_ids = set(
        expected_protein_order
    )

    protein_ids = set(
        final_protein_order
    )

    dna_ids = set(
        final_dna_order
    )

    structure_ids = set(
        final_structure_ids
    )

    checks = {}

    checks[
        "expected_count"
    ] = len(
        expected_protein_order
    )

    checks[
        "final_protein_count"
    ] = len(
        final_protein_order
    )

    checks[
        "final_DNA_count"
    ] = len(
        final_dna_order
    )

    checks[
        "final_structure_count"
    ] = len(
        final_structure_rows
    )

    checks[
        "protein_IDs_unique"
    ] = (
        len(
            final_protein_order
        )
        == len(
            protein_ids
        )
    )

    checks[
        "DNA_IDs_unique"
    ] = (
        len(
            final_dna_order
        )
        == len(
            dna_ids
        )
    )

    checks[
        "structure_IDs_unique"
    ] = (
        len(
            final_structure_ids
        )
        == len(
            structure_ids
        )
    )

    checks[
        "protein_ID_set_equals_expected"
    ] = (
        protein_ids
        == expected_ids
    )

    checks[
        "DNA_ID_set_equals_expected"
    ] = (
        dna_ids
        == expected_ids
    )

    checks[
        "structure_ID_set_equals_expected"
    ] = (
        structure_ids
        == expected_ids
    )

    checks[
        "protein_and_DNA_order_identical"
    ] = (
        final_protein_order
        == final_dna_order
    )

    checks[
        "protein_and_structure_order_identical"
    ] = (
        final_protein_order
        == final_structure_ids
    )

    roundtrip_failures = []

    strict_count = 0

    compatible_count = 0

    synthetic_count = 0

    for row in final_structure_rows:
        protein_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        source = str(
            row.get(
                "DNA.Source",
                "",
            )
        ).strip()

        if source == SOURCE_SYNTHETIC:
            synthetic_count += 1

        verification = verify_dna_to_protein(
            final_proteins[
                protein_id
            ][
                "sequence"
            ],
            final_dna[
                protein_id
            ][
                "sequence"
            ],
            source,
        )

        if not verification[
            "accepted"
        ]:
            roundtrip_failures.append(
                {
                    "protein_id":
                        protein_id,

                    "source":
                        source,

                    "reason":
                        verification[
                            "failure_reason"
                        ],
                }
            )

        if verification[
            "match_class"
        ] == "strict_exact":
            strict_count += 1

        elif verification[
            "match_class"
        ] == "compatible_exact":
            compatible_count += 1

    checks[
        "all_final_DNA_translation_verified"
    ] = (
        len(
            roundtrip_failures
        )
        == 0
    )

    # Label integrity after writing/re-reading.
    label_mismatch_count = 0

    for row in final_structure_rows:
        protein_id = canonical_id(
            row[
                "SARG.Seq.ID"
            ]
        )

        original = structure_by_id[
            protein_id
        ]

        if (
            str(
                row.get(
                    "Type",
                    "",
                )
            ).strip()
            != str(
                original.get(
                    "Type",
                    "",
                )
            ).strip()
            or str(
                row.get(
                    "Subtype",
                    "",
                )
            ).strip()
            != str(
                original.get(
                    "Subtype",
                    "",
                )
            ).strip()
        ):
            label_mismatch_count += 1

    checks[
        "Type_Subtype_labels_preserved"
    ] = (
        label_mismatch_count
        == 0
    )

    # Final global PASS.
    boolean_keys = [
        "protein_IDs_unique",
        "DNA_IDs_unique",
        "structure_IDs_unique",
        "protein_ID_set_equals_expected",
        "DNA_ID_set_equals_expected",
        "structure_ID_set_equals_expected",
        "protein_and_DNA_order_identical",
        "protein_and_structure_order_identical",
        "all_final_DNA_translation_verified",
        "Type_Subtype_labels_preserved",
    ]

    final_pass = all(
        checks[
            key
        ]
        for key
        in boolean_keys
    )

    checks[
        "strict_exact_count"
    ] = strict_count

    checks[
        "compatible_exact_count"
    ] = compatible_count

    checks[
        "synthetic_selected_count"
    ] = synthetic_count

    checks[
        "roundtrip_translation_failure_count"
    ] = len(
        roundtrip_failures
    )

    checks[
        "label_mismatch_count"
    ] = label_mismatch_count

    checks[
        "FINAL_QC_PASS"
    ] = final_pass

    return (
        checks,
        roundtrip_failures,
    )


# =============================================================================
# Main
# =============================================================================

def main():
    required_files = [
        (
            FULL_PROTEIN_FASTA,
            "Full SARG protein FASTA",
        ),
        (
            FULL_PROTEIN_STRUCTURE,
            "Full SARG protein structure",
        ),
        (
            ORIGINAL_SARG_DNA_FASTA,
            "Original SARG DNA FASTA",
        ),
        (
            ORIGINAL_SARG_DNA_STRUCTURE,
            "Original SARG DNA structure",
        ),
        (
            PREVIOUS_VERIFIED_DNA_FASTA,
            "Previous verified DNA FASTA",
        ),
        (
            PREVIOUS_VERIFIED_STRUCTURE,
            "Previous verified structure",
        ),
        (
            NEW_NCBI_DNA_FASTA,
            "New NCBI DNA FASTA",
        ),
        (
            NEW_NCBI_RESULTS_CSV,
            "New NCBI retrieval results",
        ),
        (
            SYNTHETIC_DNA_FASTA,
            "Synthetic DNA FASTA",
        ),
        (
            SYNTHETIC_MAPPING_CSV,
            "Synthetic DNA mapping",
        ),
    ]

    for path, label in required_files:
        require_file(
            path,
            label,
        )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        "FULL SARG FINAL DATABASE BUILD + STRICT QC",
        flush=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        "Selection priority:",
        flush=True,
    )

    print(
        "  1. Original SARG nucleotide DNA",
        flush=True,
    )

    print(
        "  2. Verified downloaded natural DNA "
        "(previous + new NCBI)",
        flush=True,
    )

    print(
        "  3. Synthetic backtranslation",
        flush=True,
    )

    print(
        "Only DNA candidates passing final DNA->protein verification "
        "can be selected.",
        flush=True,
    )

    # ------------------------------------------------------------------
    # Full proteins.
    # ------------------------------------------------------------------

    print()
    print(
        "[1/6] Loading full SARG protein universe...",
        flush=True,
    )

    (
        protein_order,
        protein_records,
        structure_fields,
        structure_by_id,
    ) = load_full_protein_database()

    full_ids = set(
        protein_order
    )

    print(
        f"Full proteins : {len(protein_order):,}",
        flush=True,
    )

    print(
        f"Full subtypes : "
        f"{len(set(str(structure_by_id[x]['Subtype']).strip() for x in protein_order)):,}",
        flush=True,
    )

    # ------------------------------------------------------------------
    # Sources.
    # ------------------------------------------------------------------

    print()
    print(
        "[2/6] Loading original SARG nucleotide candidates...",
        flush=True,
    )

    original_candidates = load_original_sarg_candidates(
        full_ids
    )

    print(
        f"Proteins with >=1 original candidate : "
        f"{len(original_candidates):,}",
        flush=True,
    )

    print()
    print(
        "[3/6] Loading previously verified/downloaded candidates...",
        flush=True,
    )

    previous_candidates = load_previous_verified_candidates(
        full_ids
    )

    print(
        f"Proteins with >=1 previous candidate : "
        f"{len(previous_candidates):,}",
        flush=True,
    )

    print()
    print(
        "[4/6] Loading newly retrieved NCBI + synthetic candidates...",
        flush=True,
    )

    new_ncbi_candidates = load_new_ncbi_candidates(
        full_ids
    )

    synthetic_candidates = load_synthetic_candidates(
        full_ids
    )

    print(
        f"Proteins with new NCBI candidate     : "
        f"{len(new_ncbi_candidates):,}",
        flush=True,
    )

    print(
        f"Proteins with synthetic candidate    : "
        f"{len(synthetic_candidates):,}",
        flush=True,
    )

    # ------------------------------------------------------------------
    # Verify every candidate and select.
    # ------------------------------------------------------------------

    print()
    print(
        "[5/6] Re-validating ALL candidate DNA against full SARG proteins...",
        flush=True,
    )

    (
        evaluated_by_protein,
        candidate_audit_rows,
    ) = evaluate_all_candidates(
        protein_order,
        protein_records,
        [
            original_candidates,
            previous_candidates,
            new_ncbi_candidates,
            synthetic_candidates,
        ],
    )

    selected, unresolved_rows = select_one_per_protein(
        protein_order,
        evaluated_by_protein,
    )

    print(
        f"Proteins selected before rescue : "
        f"{len(selected):,}/{len(protein_order):,}",
        flush=True,
    )

    # ------------------------------------------------------------------
    # IMPORTANT:
    # STEP 1 checked DNA PRESENCE, not final translation validity.
    # Therefore a small number of proteins can appear 'covered' by an old
    # DNA record yet have no sequence that passes this stricter final QC.
    #
    # These proteins were never part of the 286 STEP-3 synthetic set.
    # Rescue ONLY those final-QC failures with the same empirical
    # backtranslation method used in STEP 3.
    # ------------------------------------------------------------------

    rescue_records = []

    if unresolved_rows:
        rescue_records = rescue_unresolved_with_empirical_backtranslation(
            unresolved_rows,
            protein_records,
            structure_by_id,
            evaluated_by_protein,
            candidate_audit_rows,
        )

        selected, unresolved_rows = select_one_per_protein(
            protein_order,
            evaluated_by_protein,
        )

    accepted_candidate_count = sum(
        str(
            row[
                "accepted"
            ]
        ).lower()
        == "true"
        for row
        in candidate_audit_rows
    )

    print(
        f"All candidate records evaluated : "
        f"{len(candidate_audit_rows):,}",
        flush=True,
    )

    print(
        f"Validation-passing candidates   : "
        f"{accepted_candidate_count:,}",
        flush=True,
    )

    print(
        f"Additional QC-rescue synthetic  : "
        f"{len(rescue_records):,}",
        flush=True,
    )

    print(
        f"Proteins successfully selected  : "
        f"{len(selected):,}/{len(protein_order):,}",
        flush=True,
    )

    # Always write candidate audit.
    write_csv(
        ALL_CANDIDATE_AUDIT,
        [
            "protein_id",
            "source",
            "source_priority",
            "natural_or_synthetic",
            "source_record_id",
            "original_nucleotide_id",
            "retrieval_accession",
            "retrieval_method",
            "source_order",
            "accepted",
            "match_class",
            "strict_exact",
            "compatible_exact",
            "protein_length_aa",
            "DNA_length_nt",
            "translated_length_aa",
            "terminal_stop_present",
            "internal_stop_count",
            "length_valid",
            "alphabet_valid",
            "invalid_DNA_chars",
            "ambiguous_nt_count",
            "failure_reason",
            "metadata_note",
        ],
        candidate_audit_rows,
    )

    if unresolved_rows:
        write_csv(
            QC_FAILED_PROTEINS,
            [
                "protein_id",
                "candidate_count",
                "candidate_source_counts",
                "failure_details",
            ],
            unresolved_rows,
        )

        raise RuntimeError(
            "\nFINAL DATABASE NOT WRITTEN because "
            f"{len(unresolved_rows)} protein(s) still have no "
            "validation-passing DNA even after automatic synthetic rescue.\n"
            f"Inspect:\n{QC_FAILED_PROTEINS}"
        )

    # ------------------------------------------------------------------
    # Final outputs.
    # ------------------------------------------------------------------

    selection_summary = build_final_outputs(
        protein_order,
        protein_records,
        structure_fields,
        structure_by_id,
        selected,
        candidate_audit_rows,
    )

    # ------------------------------------------------------------------
    # Strict disk round-trip QC.
    # ------------------------------------------------------------------

    print()
    print(
        "[6/6] Re-reading final output files and running round-trip QC...",
        flush=True,
    )

    (
        qc_checks,
        roundtrip_failures,
    ) = final_roundtrip_qc(
        protein_order,
        structure_by_id,
    )

    summary_lines = [
        "selection_rule\t"
        "original_SARG > verified_downloaded_natural > synthetic",

        "selection_requires_translation_validation\tTrue",

        f"expected_full_SARG_proteins\t"
        f"{len(protein_order)}",
    ]

    for key, value in qc_checks.items():
        summary_lines.append(
            f"{key}\t{value}"
        )

    for source in [
        SOURCE_ORIGINAL,
        SOURCE_PREVIOUS,
        SOURCE_NEW_NCBI,
        SOURCE_SYNTHETIC,
    ]:
        summary_lines.append(
            f"selected_source::{source}\t"
            f"{selection_summary['selected_source_counts'].get(source, 0)}"
        )

    for nature, count in sorted(
        selection_summary[
            "selected_nature_counts"
        ].items()
    ):
        summary_lines.append(
            f"selected_nature::{nature}\t{count}"
        )

    for match_class, count in sorted(
        selection_summary[
            "selected_match_counts"
        ].items()
    ):
        summary_lines.append(
            f"translation_match::{match_class}\t{count}"
        )

    QC_SUMMARY.write_text(
        "\n".join(
            summary_lines
        )
        + "\n",
        encoding="utf-8",
    )

    print()
    print(
        "=" * 120,
        flush=True,
    )

    print(
        "FINAL BUILD RESULT",
        flush=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        f"Expected proteins : {qc_checks['expected_count']:,}",
        flush=True,
    )

    print(
        f"Final proteins    : {qc_checks['final_protein_count']:,}",
        flush=True,
    )

    print(
        f"Final DNA         : {qc_checks['final_DNA_count']:,}",
        flush=True,
    )

    print(
        f"Final structure   : {qc_checks['final_structure_count']:,}",
        flush=True,
    )

    print()
    print(
        "Selected DNA source counts:",
        flush=True,
    )

    for source in [
        SOURCE_ORIGINAL,
        SOURCE_PREVIOUS,
        SOURCE_NEW_NCBI,
        SOURCE_SYNTHETIC,
    ]:
        print(
            f"  {source:<30} "
            f"{selection_summary['selected_source_counts'].get(source, 0):,}",
            flush=True,
        )

    print()
    print(
        "Translation verification:",
        flush=True,
    )

    print(
        f"  strict_exact      : "
        f"{qc_checks['strict_exact_count']:,}",
        flush=True,
    )

    print(
        f"  compatible_exact  : "
        f"{qc_checks['compatible_exact_count']:,}",
        flush=True,
    )

    print(
        f"  failures          : "
        f"{qc_checks['roundtrip_translation_failure_count']:,}",
        flush=True,
    )

    print()
    print(
        f"Protein/DNA IDs identical : "
        f"{qc_checks['protein_ID_set_equals_expected'] and qc_checks['DNA_ID_set_equals_expected']}",
        flush=True,
    )

    print(
        f"Protein/DNA order identical: "
        f"{qc_checks['protein_and_DNA_order_identical']}",
        flush=True,
    )

    print(
        f"Type/Subtype preserved     : "
        f"{qc_checks['Type_Subtype_labels_preserved']}",
        flush=True,
    )

    print(
        f"All DNA translate correctly: "
        f"{qc_checks['all_final_DNA_translation_verified']}",
        flush=True,
    )

    print()
    print(
        f"FINAL_QC_PASS = {qc_checks['FINAL_QC_PASS']}",
        flush=True,
    )

    print()

    if not qc_checks[
        "FINAL_QC_PASS"
    ]:
        raise RuntimeError(
            f"Final round-trip QC failed. Inspect:\n{QC_SUMMARY}"
        )

    print(
        "Final files:",
        flush=True,
    )

    print(
        f"  Protein FASTA : {FINAL_PROTEIN_FASTA}",
        flush=True,
    )

    print(
        f"  DNA FASTA     : {FINAL_DNA_FASTA}",
        flush=True,
    )

    print(
        f"  Structure     : {FINAL_STRUCTURE}",
        flush=True,
    )

    print(
        f"  Mapping       : {FINAL_MAPPING}",
        flush=True,
    )

    print(
        f"  QC summary    : {QC_SUMMARY}",
        flush=True,
    )


if __name__ == "__main__":
    main()
