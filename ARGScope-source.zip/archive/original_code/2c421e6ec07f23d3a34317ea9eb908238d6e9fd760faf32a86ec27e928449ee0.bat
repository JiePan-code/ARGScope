@echo off
setlocal
chcp 65001 >nul
set "PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
pushd "%~dp0"
if not exist "%PY%" goto missing_python
"%PY%" -u "00_preflight_check.py"
if errorlevel 1 goto failed
echo.
echo PRECHECK PASSED.
pause
exit /b 0

:missing_python
echo Python not found: %PY%
pause
exit /b 2

:failed
echo.
echo PRECHECK FAILED. Read the error above.
pause
exit /b 1
