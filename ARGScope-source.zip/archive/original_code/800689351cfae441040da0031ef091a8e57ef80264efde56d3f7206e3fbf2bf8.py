#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import glob
import math
import gzip
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib_venn import venn2


# ============================================================
# 1. 路径
# ============================================================

# 本脚本放在：
# DNA_model_818_Diamond0.2_predictions/
#
# 目录结构：
#
# DNA_model_818_Diamond0.2_predictions/
# ├── VN图_1比1.py
# ├── ARG_11_predict/
# │   ├── argbert_1_diamond0.2_candidate_reads/
# │   ├── argbert_2_diamond0.2_candidate_reads/
# │   ├── argbert_3_diamond0.2_candidate_reads/
# │   ├── argscope_1_diamond0.2_candidate_reads/
# │   ├── ...
# │   └── argscope_6_diamond0.2_candidate_reads/
# │
# └── BLASTN_current_ARGScope_labelspace/
#     ├── argbert_1/
#     ├── argbert_2/
#     ├── argbert_3/
#     ├── argscope_1/
#     ├── ...
#     └── argscope_6/


BASE_DIR = os.path.dirname(os.path.abspath(__file__))

PRED_ROOT = os.path.join(
    BASE_DIR,
    "ARG_11_predict"
)

BLAST_ROOT = os.path.join(
    BASE_DIR,
    "BLASTN_current_ARGScope_labelspace"
)

OUT_DIR = os.path.join(
    BASE_DIR,
    "Venn_ARG11_vs_BLAST_current_scope"
)

os.makedirs(OUT_DIR, exist_ok=True)


# ============================================================
# 2. 固定 9 个数据集顺序
# ============================================================

SAMPLES = [
    "argbert_1",
    "argbert_2",
    "argbert_3",
    "argscope_1",
    "argscope_2",
    "argscope_3",
    "argscope_4",
    "argscope_5",
    "argscope_6",
]


# ============================================================
# 3. 工具函数
# ============================================================

def natural_key(text):
    """
    自然排序：
    xxx_2 在 xxx_10 前面
    """
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", str(text))
    ]


def check_paths():
    """
    检查根目录
    """

    print("=" * 100)
    print("ARGScope 1:1 dataset")
    print("Venn: ARG11 model predictions vs BLASTN current ARGScope labelspace")
    print("=" * 100)

    print(f"BASE_DIR   : {BASE_DIR}")
    print(f"PRED_ROOT  : {PRED_ROOT}")
    print(f"BLAST_ROOT : {BLAST_ROOT}")
    print(f"OUT_DIR    : {OUT_DIR}")
    print()

    if not os.path.isdir(PRED_ROOT):
        raise FileNotFoundError(
            f"\nPrediction root not found:\n{PRED_ROOT}\n"
        )

    if not os.path.isdir(BLAST_ROOT):
        raise FileNotFoundError(
            f"\nBLAST root not found:\n{BLAST_ROOT}\n"
        )


# ============================================================
# 4. 自动寻找 prediction 文件
# ============================================================

def read_header(file_path):
    """
    只读取表头，判断是不是 prediction 文件
    """

    try:
        df = pd.read_csv(
            file_path,
            nrows=3
        )

        return df.columns.tolist()

    except Exception:
        return []


def find_prediction_files(sample_dir):
    """
    递归寻找 prediction CSV。

    判断依据：
        必须同时存在：
            read_id
            predicted_ARG

    支持：
        .csv
        .csv.gz
    """

    candidates = []

    for root, dirs, files in os.walk(sample_dir):

        for filename in files:

            lower = filename.lower()

            if not (
                lower.endswith(".csv")
                or lower.endswith(".csv.gz")
            ):
                continue

            fp = os.path.join(root, filename)

            cols = read_header(fp)

            if (
                "read_id" in cols
                and "predicted_ARG" in cols
            ):
                candidates.append(fp)

    candidates = sorted(
        candidates,
        key=natural_key
    )

    return candidates


# ============================================================
# 5. 读取 ARG11 模型预测的 ARG reads
# ============================================================

def load_predicted_arg_ids(sample_dir):

    files = find_prediction_files(sample_dir)

    if not files:

        raise FileNotFoundError(
            f"\nNo prediction CSV containing "
            f"'read_id' and 'predicted_ARG' found in:\n"
            f"{sample_dir}\n"
        )

    print()
    print("Prediction files:")

    all_ids = set()

    total_rows = 0

    for fp in files:

        print(f"    {fp}")

        df = pd.read_csv(
            fp,
            usecols=[
                "read_id",
                "predicted_ARG"
            ]
        )

        total_rows += len(df)

        pred_value = pd.to_numeric(
            df["predicted_ARG"],
            errors="coerce"
        )

        ids = set(
            df.loc[
                pred_value == 1,
                "read_id"
            ]
            .astype(str)
            .str.strip()
            .tolist()
        )

        all_ids.update(ids)

    print()
    print(f"    Prediction total rows : {total_rows:,}")
    print(f"    Unique predicted ARG  : {len(all_ids):,}")

    return all_ids, total_rows, files


# ============================================================
# 6. 自动寻找 BLAST current scope all hits
# ============================================================

def find_blast_file(sample_dir, sample_name):

    # --------------------------------------------------------
    # 第一优先级：
    # argbert_1_current_scope_all_hits.tsv
    # --------------------------------------------------------

    preferred = os.path.join(
        sample_dir,
        f"{sample_name}_current_scope_all_hits.tsv"
    )

    if os.path.exists(preferred):
        return preferred

    # --------------------------------------------------------
    # 第二优先级：
    # 任意 *_current_scope_all_hits.tsv
    # --------------------------------------------------------

    files = glob.glob(
        os.path.join(
            sample_dir,
            "**",
            "*_current_scope_all_hits.tsv"
        ),
        recursive=True
    )

    if files:

        files = sorted(files, key=natural_key)

        return files[0]

    # --------------------------------------------------------
    # 第三优先级：
    # 检查其他 TSV，看是否包含 qseqid
    # --------------------------------------------------------

    all_tsv = glob.glob(
        os.path.join(
            sample_dir,
            "**",
            "*.tsv"
        ),
        recursive=True
    )

    for fp in all_tsv:

        try:

            df = pd.read_csv(
                fp,
                sep="\t",
                nrows=3
            )

            if "qseqid" in df.columns:

                return fp

        except Exception:
            continue

    raise FileNotFoundError(
        f"\nNo suitable BLAST TSV found in:\n"
        f"{sample_dir}\n"
    )


# ============================================================
# 7. 读取 BLAST current-scope reads
# ============================================================

def load_blast_ids(sample_dir, sample_name):

    fp = find_blast_file(
        sample_dir,
        sample_name
    )

    print()
    print("BLAST file:")
    print(f"    {fp}")

    df = pd.read_csv(
        fp,
        sep="\t"
    )

    original_rows = len(df)

    if "qseqid" not in df.columns:

        raise ValueError(
            f"'qseqid' column not found:\n{fp}"
        )

    # --------------------------------------------------------
    # 如果有 current_scope_status，
    # 只使用 in_scope
    # --------------------------------------------------------

    if "current_scope_status" in df.columns:

        status = (
            df["current_scope_status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        df = df[
            status == "in_scope"
        ].copy()

    ids = set(
        df["qseqid"]
        .astype(str)
        .str.strip()
        .tolist()
    )

    print()
    print(f"    BLAST rows            : {original_rows:,}")
    print(f"    Current-scope rows    : {len(df):,}")
    print(f"    Unique BLAST reads    : {len(ids):,}")

    return ids, original_rows, len(df), fp


# ============================================================
# 8. 单独画一张 Venn
# ============================================================

def draw_single_venn(
    sample,
    pred_ids,
    blast_ids,
    output_file
):

    pred_only = len(
        pred_ids - blast_ids
    )

    blast_only = len(
        blast_ids - pred_ids
    )

    intersection = len(
        pred_ids & blast_ids
    )

    fig, ax = plt.subplots(
        figsize=(7.2, 6.5)
    )

    v = venn2(
        subsets=(
            pred_only,
            blast_only,
            intersection
        ),
        set_labels=(
            "ARGScope DL",
            "BLASTN"
        ),
        ax=ax
    )

    # --------------------------------------------------------
    # 数字千位分隔
    # --------------------------------------------------------

    if v.get_label_by_id("10") is not None:
        v.get_label_by_id("10").set_text(
            f"{pred_only:,}"
        )

    if v.get_label_by_id("01") is not None:
        v.get_label_by_id("01").set_text(
            f"{blast_only:,}"
        )

    if v.get_label_by_id("11") is not None:
        v.get_label_by_id("11").set_text(
            f"{intersection:,}"
        )

    # 字号
    for label in [
        v.get_label_by_id("10"),
        v.get_label_by_id("01"),
        v.get_label_by_id("11")
    ]:
        if label is not None:
            label.set_fontsize(13)

    for label in v.set_labels:
        if label is not None:
            label.set_fontsize(12)

    ax.set_title(
        sample,
        fontsize=15,
        pad=18
    )

    plt.tight_layout()

    plt.savefig(
        output_file,
        dpi=400,
        bbox_inches="tight"
    )

    plt.close()


# ============================================================
# 9. 画 9 数据集 3x3 总图
# ============================================================

def draw_panel(records, output_file):

    n = len(records)

    ncols = 3
    nrows = math.ceil(
        n / ncols
    )

    fig, axes = plt.subplots(
        nrows,
        ncols,
        figsize=(17, 15)
    )

    axes = axes.flatten()

    for i, rec in enumerate(records):

        ax = axes[i]

        pred_only = rec["ARG11_only"]
        blast_only = rec["BLAST_only"]
        intersection = rec["Intersection"]

        v = venn2(
            subsets=(
                pred_only,
                blast_only,
                intersection
            ),
            set_labels=(
                "ARGScope DL",
                "BLASTN"
            ),
            ax=ax
        )

        if v.get_label_by_id("10") is not None:
            v.get_label_by_id("10").set_text(
                f"{pred_only:,}"
            )

        if v.get_label_by_id("01") is not None:
            v.get_label_by_id("01").set_text(
                f"{blast_only:,}"
            )

        if v.get_label_by_id("11") is not None:
            v.get_label_by_id("11").set_text(
                f"{intersection:,}"
            )

        for label in [
            v.get_label_by_id("10"),
            v.get_label_by_id("01"),
            v.get_label_by_id("11")
        ]:
            if label is not None:
                label.set_fontsize(12)

        for label in v.set_labels:
            if label is not None:
                label.set_fontsize(10)

        ax.set_title(
            rec["Dataset"],
            fontsize=14,
            pad=12
        )

    # 多余 subplot 删除
    for j in range(n, len(axes)):
        axes[j].axis("off")

    fig.suptitle(
        "ARGScope DL vs BLASTN: Read-level overlap (1:1 datasets)",
        fontsize=18,
        y=0.995
    )

    plt.tight_layout(
        rect=[
            0,
            0,
            1,
            0.975
        ]
    )

    plt.savefig(
        output_file,
        dpi=400,
        bbox_inches="tight"
    )

    plt.close()


# ============================================================
# 10. 主程序
# ============================================================

def main():

    check_paths()

    records = []

    for sample in SAMPLES:

        print()
        print("=" * 100)
        print(f"Processing dataset: {sample}")
        print("=" * 100)

        # ----------------------------------------------------
        # Prediction 文件夹名字
        #
        # argbert_1
        # ->
        # argbert_1_diamond0.2_candidate_reads
        # ----------------------------------------------------

        pred_folder_name = (
            f"{sample}_diamond0.2_candidate_reads"
        )

        pred_dir = os.path.join(
            PRED_ROOT,
            pred_folder_name
        )

        blast_dir = os.path.join(
            BLAST_ROOT,
            sample
        )

        print()
        print("Prediction directory:")
        print(f"    {pred_dir}")

        print()
        print("BLAST directory:")
        print(f"    {blast_dir}")

        if not os.path.isdir(pred_dir):

            print()
            print(
                f"[WARNING] Prediction folder not found. "
                f"Skip: {pred_dir}"
            )

            continue

        if not os.path.isdir(blast_dir):

            print()
            print(
                f"[WARNING] BLAST folder not found. "
                f"Skip: {blast_dir}"
            )

            continue

        # ----------------------------------------------------
        # ARGScope model
        # ----------------------------------------------------

        pred_ids, pred_total_rows, pred_files = \
            load_predicted_arg_ids(
                pred_dir
            )

        # ----------------------------------------------------
        # BLAST
        # ----------------------------------------------------

        (
            blast_ids,
            blast_total_rows,
            blast_scope_rows,
            blast_file
        ) = load_blast_ids(
            blast_dir,
            sample
        )

        # ----------------------------------------------------
        # overlap
        # ----------------------------------------------------

        intersection_ids = (
            pred_ids & blast_ids
        )

        pred_only_ids = (
            pred_ids - blast_ids
        )

        blast_only_ids = (
            blast_ids - pred_ids
        )

        union_ids = (
            pred_ids | blast_ids
        )

        intersection = len(
            intersection_ids
        )

        pred_only = len(
            pred_only_ids
        )

        blast_only = len(
            blast_only_ids
        )

        pred_n = len(
            pred_ids
        )

        blast_n = len(
            blast_ids
        )

        union_n = len(
            union_ids
        )

        # ----------------------------------------------------
        # overlap rate
        # ----------------------------------------------------

        if pred_n > 0:
            intersection_over_arg11 = (
                intersection / pred_n
            )
        else:
            intersection_over_arg11 = 0.0

        if blast_n > 0:
            intersection_over_blast = (
                intersection / blast_n
            )
        else:
            intersection_over_blast = 0.0

        if union_n > 0:
            jaccard = (
                intersection / union_n
            )
        else:
            jaccard = 0.0

        # ----------------------------------------------------
        # 打印
        # ----------------------------------------------------

        print()
        print("-" * 70)

        print(
            f"ARGScope DL ARG reads : {pred_n:,}"
        )

        print(
            f"BLASTN ARG reads      : {blast_n:,}"
        )

        print(
            f"Intersection          : {intersection:,}"
        )

        print(
            f"ARGScope DL only      : {pred_only:,}"
        )

        print(
            f"BLASTN only           : {blast_only:,}"
        )

        print(
            f"Intersection / DL     : "
            f"{intersection_over_arg11:.4f} "
            f"({intersection_over_arg11 * 100:.2f}%)"
        )

        print(
            f"Intersection / BLAST  : "
            f"{intersection_over_blast:.4f} "
            f"({intersection_over_blast * 100:.2f}%)"
        )

        print(
            f"Jaccard               : "
            f"{jaccard:.4f}"
        )

        print("-" * 70)

        # ----------------------------------------------------
        # 单张图
        # ----------------------------------------------------

        output_png = os.path.join(
            OUT_DIR,
            f"{sample}_ARG11_vs_BLAST_Venn.png"
        )

        draw_single_venn(
            sample,
            pred_ids,
            blast_ids,
            output_png
        )

        print()
        print(
            f"Saved Venn:"
            f"\n    {output_png}"
        )

        # ----------------------------------------------------
        # 保存交集 read ID
        # ----------------------------------------------------

        intersection_file = os.path.join(
            OUT_DIR,
            f"{sample}_intersection_read_ids.txt"
        )

        with open(
            intersection_file,
            "w",
            encoding="utf-8"
        ) as fout:

            for rid in sorted(
                intersection_ids,
                key=natural_key
            ):
                fout.write(
                    rid + "\n"
                )

        # ----------------------------------------------------
        # 保存 ARGScope-only
        # ----------------------------------------------------

        dl_only_file = os.path.join(
            OUT_DIR,
            f"{sample}_ARGScopeDL_only_read_ids.txt"
        )

        with open(
            dl_only_file,
            "w",
            encoding="utf-8"
        ) as fout:

            for rid in sorted(
                pred_only_ids,
                key=natural_key
            ):
                fout.write(
                    rid + "\n"
                )

        # ----------------------------------------------------
        # 保存 BLAST-only
        # ----------------------------------------------------

        blast_only_file = os.path.join(
            OUT_DIR,
            f"{sample}_BLASTN_only_read_ids.txt"
        )

        with open(
            blast_only_file,
            "w",
            encoding="utf-8"
        ) as fout:

            for rid in sorted(
                blast_only_ids,
                key=natural_key
            ):
                fout.write(
                    rid + "\n"
                )

        # ----------------------------------------------------
        # summary record
        # ----------------------------------------------------

        records.append({

            "Dataset":
                sample,

            "ARG11_predicted_ARG":
                pred_n,

            "BLAST_current_scope":
                blast_n,

            "Intersection":
                intersection,

            "ARG11_only":
                pred_only,

            "BLAST_only":
                blast_only,

            "Union":
                union_n,

            "Intersection_over_ARG11":
                intersection_over_arg11,

            "Intersection_over_BLAST":
                intersection_over_blast,

            "Jaccard":
                jaccard,

            "Prediction_total_rows":
                pred_total_rows,

            "BLAST_total_rows":
                blast_total_rows,

            "BLAST_current_scope_rows":
                blast_scope_rows,

            "Prediction_files":
                ";".join(pred_files),

            "BLAST_file":
                blast_file
        })

    # ========================================================
    # Summary CSV
    # ========================================================

    if not records:

        raise RuntimeError(
            "No datasets were successfully processed."
        )

    summary_df = pd.DataFrame(
        records
    )

    summary_csv = os.path.join(
        OUT_DIR,
        "ARG11_vs_BLAST_Venn_summary_1to1.csv"
    )

    summary_df.to_csv(
        summary_csv,
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f"
    )

    # ========================================================
    # 3 x 3 panel
    # ========================================================

    panel_png = os.path.join(
        OUT_DIR,
        "ARG11_vs_BLAST_Venn_9datasets_1to1.png"
    )

    draw_panel(
        records,
        panel_png
    )

    print()
    print("=" * 100)
    print("ALL DONE")
    print("=" * 100)

    print()
    print("Summary:")
    print(
        summary_df[
            [
                "Dataset",
                "ARG11_predicted_ARG",
                "BLAST_current_scope",
                "Intersection",
                "ARG11_only",
                "BLAST_only",
                "Intersection_over_ARG11",
                "Intersection_over_BLAST",
                "Jaccard"
            ]
        ].to_string(index=False)
    )

    print()
    print(
        f"Summary CSV:\n"
        f"    {summary_csv}"
    )

    print()
    print(
        f"9-dataset Venn panel:\n"
        f"    {panel_png}"
    )

    print()
    print(
        f"All individual figures and read-ID files:\n"
        f"    {OUT_DIR}"
    )

    print("=" * 100)


if __name__ == "__main__":
    main()