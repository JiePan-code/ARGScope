"""Task-aware palette revision, with prior layout, metrics and UMAP fixed."""
from pathlib import Path
import importlib.util
import json
import shutil
import zipfile
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap, to_rgb

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('readable_figures',HERE/'redesign_figure2_figure3_readable.py')
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
OUT=HERE/'outputs/figure2_figure3_multicolor_20260923'
DELIVERY=Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Figure2_Figure3_多色配色版_20260923')
PREVIOUS=HERE/'outputs/figure2_figure3_readable_compact_20260923'
base.OUT=OUT

MODEL_COLORS={'ARGNet':'#89949E','DeepARG':'#8472B0','PLM-ARG':'#BDA364',
              'FunGeneTyper':'#64A598','ARGScope':'#CF4877'}
METRIC_COLORS=dict(zip(base.FIELDS,['#86AECC','#86B7AF','#D8BF83','#CC96AB','#AFA3C7']))
HEAT_COLORS=['#F7F8F2','#DDEBCF','#A2CDBC','#62ACA4','#357D86','#255866']
CONF_COLORS=['#F5F7FC','#DCE5F4','#B2C6E2','#80A0CA','#5477A7','#304F79']
ERROR_COLORS=['#FFF9F1','#F8E5BF','#EFC889','#DAA359','#BC7B38','#895026']
ERROR_CORRECT='#519D92'
ERROR_INCORRECT='#CC8495'


def luminance(rgb):
    v=np.array(to_rgb(rgb))
    linear=np.where(v<=.04045,v/12.92,((v+.055)/1.055)**2.4)
    return float(linear@np.array([.2126,.7152,.0722]))


def foreground(rgb):
    lum=luminance(rgb[:3])
    return '#FFFFFF' if 1.05/(lum+.05)>(lum+.05)/.05 else '#000000'


def edge(color):return tuple(np.array(to_rgb(color))*.72)


base.foreground=foreground


class MulticolorBuilder(base.FigureBuilder):
    def __init__(self,mod):
        super().__init__(mod)
        self.theme=dict(self.theme,main=MODEL_COLORS['ARGScope'])
        self.cmap=LinearSegmentedColormap.from_list('cream_teal',HEAT_COLORS,N=256)

    def radar(self):
        frame=super().radar()
        ax=self.groups['A'][0]
        for line in ax.lines:
            if line.get_label() in MODEL_COLORS:line.set_color(MODEL_COLORS[line.get_label()])
        for patch in ax.patches:patch.set_facecolor(MODEL_COLORS['ARGScope'])
        for artist in self.extra['A']:
            if hasattr(artist,'legend_handles'):
                for handle,text in zip(artist.legend_handles,artist.get_texts()):
                    handle.set_color(MODEL_COLORS[text.get_text()])
        return frame

    def bars(self):
        super().bars()
        bars=self.groups['B'][0].patches
        assert len(bars)==5
        for patch,metric in zip(bars,base.FIELDS):
            patch.set_facecolor(METRIC_COLORS[metric]);patch.set_edgecolor(edge(METRIC_COLORS[metric]))

    def matrices(self):
        heat=self.cmap
        self.cmap=LinearSegmentedColormap.from_list('slate_blue',CONF_COLORS,N=256)
        super().matrices()
        self.cmap=heat
        errors=LinearSegmentedColormap.from_list('amber_errors',ERROR_COLORS,N=256)
        errors.set_bad('#E7EAED')
        ax=self.groups['F'][0]
        mesh=ax.collections[0]
        mesh.set_cmap(errors)
        mesh.colorbar.solids.set_rasterized(False)
        for t in ax.texts:
            t.set_color(foreground(errors(mesh.norm(float(t.get_text())))))

    def errors(self):
        super().errors()
        for ax in self.groups['G']:
            for patch in ax.patches:
                c=ERROR_INCORRECT if patch.get_hatch() else ERROR_CORRECT
                patch.set_facecolor(c);patch.set_edgecolor(edge(c))
        for artist in self.extra['G']:
            if hasattr(artist,'legend_handles'):
                for handle,c in zip(artist.legend_handles,[ERROR_CORRECT,ERROR_INCORRECT]):
                    handle.set_facecolor(c);handle.set_edgecolor(edge(c))

    def verify(self):
        super().verify()
        contrasts=[]
        for ax,t,j,i,v in self.checks:
            bg=luminance(self.cmap(v)[:3]);fg=luminance(t.get_color())
            ratio=(max(bg,fg)+.05)/(min(bg,fg)+.05)
            assert ratio>=4.5
            contrasts.append(ratio)
        base.AUDIT[self.mod]['color_checks']={
            'heatmap_text_min_contrast':min(contrasts),
            'continuous_scales_monotonic_luminance':True,
            'UMAP_category_colors_unchanged':True,
            'same_model_and_metric_colors_across_figures':True,
            'error_status_also_encoded_by_hatching':True}

    def compact_composite(self):
        """Keep all exported subpanels complete; simplify only the main composite."""
        W,H=base.W,base.H
        first,best=self.groups['D'][0],self.groups['D'][-1]
        first.set_position([.49/W,(H-12.93-2.97)/H,3.98/W,2.97/H])
        best.set_position([4.77/W,(H-12.93-2.97)/H,3.98/W,2.97/H])
        self.groups['D_compact']=[first,best]
        old_legend=self.extra['D'][0]
        compact_legend=self.fig.legend(handles=old_legend.legend_handles,
            labels=[t.get_text() for t in old_legend.get_texts()],ncol=3,loc='upper left',mode='expand',
            bbox_to_anchor=(.40/W,1-16.30/H,8.20/W,0),bbox_transform=self.fig.transFigure,
            fontsize=17.5,frameon=False,borderaxespad=0,borderpad=0,
            handletextpad=.35,handlelength=.7,columnspacing=.75,labelspacing=.36)
        self.extra['D_compact']=[compact_legend]
        # Panel E moves to the right of the two retained UMAP checkpoints.
        for ax in self.groups['E']:
            p=ax.get_position()
            ax.set_position([p.x0+9.41/W,p.y0+5.40/H,p.width,p.height])
        # Panel F is the lower-left panel.
        for ax in self.groups['F']:
            p=ax.get_position()
            ax.set_position([p.x0-9.41/W,p.y0-2.21/H,p.width,p.height])
        # Panel G uses the existing first ten error pairs, without reranking.
        g=self.groups['G'][0]
        g.set_position([14.20/W,(H-21.18-5.05)/H,4.16/W,5.05/H])
        self.groups['G_compact']=[g]
        self.extra['G_compact']=[]
        self.text('G_compact',14.05,20.04,'Top 10 subtype error pairs',ha='center',fontsize=21)
        old_glegend=next(a for a in self.extra['G'] if hasattr(a,'legend_handles'))
        compact_glegend=self.fig.legend(handles=old_glegend.legend_handles,
            labels=[t.get_text() for t in old_glegend.get_texts()],ncol=1,loc='upper center',
            bbox_to_anchor=(14.03/W,1-20.48/H),frameon=False,fontsize=17,
            handlelength=1.1,handletextpad=.45,labelspacing=.24,borderaxespad=0)
        self.extra['G_compact'].append(compact_glegend)
        for letter,x,top in [('D',.1,12.42),('E',9.51,12.42),('F',.1,20.00),('G',9.51,20.00)]:
            self.letters[ord(letter)-ord('A')].set_position((x/W,1-top/H))
        base.AUDIT[self.mod]['compact_composite']={
            'umap_epochs':[0,135 if self.mod=='Protein' else 132],
            'error_pairs_shown':10,'error_pairs_order':'Original first ten, no reranking',
            'full_four_epoch_and_top20_subpanels_retained':True,
            'panel_order':'A-B / C / D-E / F-G'}

    def export(self,name,groups=None,letters=False,preview=True):
        if groups is None and name.endswith('_combined'):
            self.compact_composite()
            super().export(f'Figure{self.number}D_{self.mod}_Epoch0_Best_compact',['D_compact'])
            super().export(f'Figure{self.number}G_{self.mod}_Top10_compact',['G_compact'])
            groups=['A','B','C','D_compact','E','F','G_compact']
        return super().export(name,groups,letters,preview)


def main():
    font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':19,'text.color':base.INK,
        'axes.labelcolor':base.INK,'xtick.color':base.INK,'ytick.color':base.INK,
        'figure.facecolor':'none','axes.facecolor':'none','savefig.transparent':True,
        'svg.fonttype':'path','hatch.linewidth':.65,'axes.linewidth':.8})
    for colors in [HEAT_COLORS,CONF_COLORS,ERROR_COLORS]:
        cmap=LinearSegmentedColormap.from_list('check',colors,N=256)
        vals=[luminance(cmap(v)[:3]) for v in np.linspace(0,1,256)]
        assert np.all(np.diff(vals)<=0)
    OUT.mkdir(parents=True,exist_ok=True)
    for mod in ['Protein','DNA']:MulticolorBuilder(mod).run()
    previous=json.loads((PREVIOUS/'verification.json').read_text(encoding='utf-8'))
    assert base.INPUT_HASHES==previous['input_sha256']
    for path,h in base.INPUT_HASHES.items():assert base.sha(path)==h
    for mod in ['Protein','DNA']:
        assert base.AUDIT[mod]['umap']==previous['modalities'][mod]['umap']
        assert base.AUDIT[mod]['heatmap']==previous['modalities'][mod]['heatmap']
        shutil.copytree(base.SOURCE/mod,OUT/'plot_data'/mod,dirs_exist_ok=True)
    old_exports={e['name']:e for e in previous['exports']}
    for current in base.EXPORTS:
        if current['name'] not in old_exports or current['name'].endswith('_combined'):continue
        old=old_exports[current['name']]
        np.testing.assert_allclose([current['width_in'],current['height_in']],
                                   [old['width_in'],old['height_in']],atol=1e-10,rtol=0)
    shutil.copy2(base.PALETTE,OUT/'plot_data/umap_reference_palette.csv')
    for p in [Path(__file__),HERE/'redesign_figure2_figure3_readable.py']:
        shutil.copy2(p,OUT/'plot_data'/p.name)
    palette={'models':MODEL_COLORS,'metrics':METRIC_COLORS,'heatmap':HEAT_COLORS,
             'row_normalized_confusion':CONF_COLORS,'misclassification_counts':ERROR_COLORS,
             'type_correct_error':ERROR_CORRECT,'type_incorrect_error':ERROR_INCORRECT,
             'umap':'Unchanged source categorical palette'}
    (OUT/'palette.json').write_text(json.dumps(palette,indent=2),encoding='utf-8')
    report={'modalities':base.AUDIT,'input_sha256':base.INPUT_HASHES,'exports':base.EXPORTS,
            'values_recomputed':False,'source_files_modified':False,'fonts_and_full_subpanel_layouts_unchanged':True,
            'composites_simplified_at_user_request':True,
            'matches_previous_data_hashes':True,'palette':palette,
            'note':'Existing model-specific evaluation populations and displayed classes remain unchanged.'}
    (OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    note='''# Figure 2 / Figure 3 多色配色版

更新配色并精简组图，不修改指标、样本、评价口径、UMAP坐标和字号。

- A：模型使用稳定的灰、紫、金、青绿和玫瑰色，与 Figure 4 的模型配色一致。
- B：ACC、Precision、Recall、F1、MCC 使用五种柔和色，两种输入模型采用一致的指标颜色。原有柱体纹理保留。
- C：浅米绿到深青色的连续色阶，全部指标沿用相同0–1范围，数字根据背景自动采用黑/白高对比文字。
- D：原有UMAP类别颜色和坐标全部保留。
- E：蓝灰色连续色阶，表示行归一化混淆比例。
- F：琥珀棕色连续色阶，表示误分类计数。数字与颜色条仍反映原有计数范围。
- G：青绿表示subtype错误但type正确，玫瑰色加斜线表示type也错误。

两套图包含组图和A–G子图，另附各指标热图、各epoch的UMAP、独立图例。
组图按照A–B / C / D–E / F–G排列。D只展示Epoch 0和Best epoch，G只展示原排序前10个错误对。
完整版独立D子图仍含4个epoch，独立G子图仍含前20个错误对，可直接用于补充材料。
另附与精简组图一致的D（Epoch0_Best_compact）和G（Top10_compact）子图。
均为透明背景Arial纯矢量SVG。主文件文字转曲以避免字体替换，editable_text保留可编辑文字。
推荐组图按整版或双栏通栏宽度使用。以前的单色版本保留不覆盖。
原始模型的测试记录覆盖范围不一致，本次只改颜色，不构成重新完成的同样本比较。
'''
    (OUT/'README.md').write_text(note,encoding='utf-8')
    DELIVERY.mkdir(parents=True,exist_ok=True)
    for folder in ['Figure2_Protein','Figure3_DNA','editable_text','previews','plot_data']:
        shutil.copytree(OUT/folder,DELIVERY/folder,dirs_exist_ok=True)
    for file in ['README.md','verification.json','palette.json']:shutil.copy2(OUT/file,DELIVERY/file)
    with zipfile.ZipFile(DELIVERY/'Figure2_Figure3_多色版_SVG.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in DELIVERY.rglob('*'):
            if p.is_file() and p.suffix!='.zip':z.write(p,p.relative_to(DELIVERY))
    print('PASS: original data and fonts retained; full subpanels preserved; main composites simplified.',flush=True)
    print('DELIVERY',DELIVERY,flush=True)


if __name__=='__main__':main()
