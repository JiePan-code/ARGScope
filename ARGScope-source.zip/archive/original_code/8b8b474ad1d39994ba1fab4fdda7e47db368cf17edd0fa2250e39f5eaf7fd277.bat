@echo off
setlocal
chcp 65001 >nul
set "PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
pushd "%~dp0"
if not exist "%PY%" (
    echo Python not found: %PY%
    pause
    exit /b 2
)
"%PY%" -u "ablations\wo_transfer\05_dna_student_wo_transfer.py"
if errorlevel 1 (
    echo.
    echo DNA W/O TRANSFER STOPPED. Read the error above.
    pause
    exit /b 1
)
echo.
echo DNA W/O TRANSFER COMPLETED.
pause
exit /b 0
