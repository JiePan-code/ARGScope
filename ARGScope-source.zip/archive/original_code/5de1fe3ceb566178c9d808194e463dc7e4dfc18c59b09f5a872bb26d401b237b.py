import os
import glob
import time
import torch
from transformers import AutoTokenizer, AutoModel


# =========================
# 参数设置
# =========================

MODEL_NAME = "zhihan1996/DNABERT-2-117M"

INPUT_DIR = r"E:\1. ARG模型对比\1. ARG真实数据\merged_fasta_chunks"

OUTPUT_DIR = r"E:\1. ARG模型对比\1. ARG真实数据\dnabert2_embeddings_pt"

FASTA_PATTERN = "argbert_1_1_kneaddata_merged_chunk_*.fasta"

# 从第几个 chunk 开始跑
START_CHUNK_ID = 1

# 跑到第几个 chunk
# 跑全部设为 None
END_CHUNK_ID = None

# GPU batch size
# 如果显存不足，改成 32 或 16
BATCH_SIZE = 64

# DNABERT2 tokenizer 后长度会压缩
# 真实 reads 一般 128 足够
MODEL_MAX_LENGTH = 128

# 每 100 万条保存一个 .pt
# 你的 fasta 本身就是每 100 万条一个，所以每个 fasta 会输出一个 .pt
SAVE_EVERY = 1_000_000

# 正式跑全部数据设为 None
# 测试时可以设为 10000
MAX_RECORDS_PER_FASTA = None

# 每多少条打印一次进度
PRINT_EVERY = 10_000

# 保存为 float16，文件大小约为 float32 的一半
SAVE_FLOAT16 = True

# 如果 .pt 已经存在，是否跳过
# 正式断点续跑建议 True
# 如果你要重新跑，先删除旧的 .pt 文件
SKIP_EXISTING_PT = True


# =========================
# FASTA 读取
# =========================

def read_fasta_generator(fasta_file):
    seq_id = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith(">"):
                if seq_id is not None:
                    yield seq_id, "".join(seq_lines).upper()

                seq_id = line[1:].split()[0]
                seq_lines = []
            else:
                seq_lines.append(line)

        if seq_id is not None:
            yield seq_id, "".join(seq_lines).upper()


def clean_dna(seq):
    allowed = set("ACGTN")
    return "".join(base if base in allowed else "N" for base in seq.upper())


def get_chunk_id_from_filename(fasta_path):
    base = os.path.basename(fasta_path)
    name = os.path.splitext(base)[0]

    # expected:
    # argbert_1_1_kneaddata_merged_chunk_001
    chunk_str = name.split("_chunk_")[-1]
    return int(chunk_str)


# =========================
# Mean pooling
# =========================

def mean_pooling(hidden_states, attention_mask):
    """
    hidden_states: [batch, seq_len, hidden]
    attention_mask: [batch, seq_len]
    return: [batch, hidden]
    """
    mask = attention_mask.unsqueeze(-1).expand(hidden_states.size()).float()
    summed = torch.sum(hidden_states * mask, dim=1)
    counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    return summed / counts


# =========================
# 保存 .pt
# =========================

def save_pt(
    output_dir,
    output_prefix,
    ids_buffer,
    emb_buffer,
    input_fasta
):
    if not ids_buffer:
        return

    output_pt = os.path.join(
        output_dir,
        f"{output_prefix}.pt"
    )

    if SKIP_EXISTING_PT and os.path.exists(output_pt):
        print(f"Skip existing: {output_pt}")
        return

    print("Concatenating embeddings...")
    embeddings = torch.cat(emb_buffer, dim=0)

    if SAVE_FLOAT16:
        embeddings = embeddings.half()
    else:
        embeddings = embeddings.float()

    print(f"Saving: {output_pt}")

    torch.save(
        {
            "ids": ids_buffer,
            "embeddings": embeddings,
            "embedding_dim": embeddings.shape[1],
            "dtype": str(embeddings.dtype),
            "num_sequences": len(ids_buffer),
            "source_fasta": input_fasta,
            "model_name": MODEL_NAME,
            "model_max_length": MODEL_MAX_LENGTH,
            "pooling": "mean_pooling_with_attention_mask",
        },
        output_pt
    )

    file_size_gb = os.path.getsize(output_pt) / 1024 / 1024 / 1024

    print(f"Saved: {output_pt}")
    print(f"Sequences: {len(ids_buffer):,}")
    print(f"Embedding shape: {tuple(embeddings.shape)}")
    print(f"File size: {file_size_gb:.3f} GB")
    print("-" * 80)


# =========================
# 单个 FASTA 处理
# =========================

def extract_one_fasta(input_fasta, tokenizer, model, device):
    output_prefix = os.path.splitext(os.path.basename(input_fasta))[0]
    output_pt = os.path.join(OUTPUT_DIR, f"{output_prefix}.pt")

    if SKIP_EXISTING_PT and os.path.exists(output_pt):
        print(f"Already exists, skip this fasta: {output_pt}")
        return

    print("=" * 80)
    print(f"Start FASTA: {input_fasta}")
    print(f"Output PT: {output_pt}")
    print("=" * 80)

    start_time = time.time()

    total_count = 0

    batch_ids = []
    batch_seqs = []

    ids_buffer = []
    emb_buffer = []

    def process_batch(ids, seqs):
        nonlocal total_count, ids_buffer, emb_buffer

        inputs = tokenizer(
            seqs,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=MODEL_MAX_LENGTH
        )

        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            if device == "cuda":
                with torch.cuda.amp.autocast():
                    outputs = model(**inputs)
                    hidden_states = outputs[0]
                    embeddings = mean_pooling(
                        hidden_states,
                        inputs["attention_mask"]
                    )
            else:
                outputs = model(**inputs)
                hidden_states = outputs[0]
                embeddings = mean_pooling(
                    hidden_states,
                    inputs["attention_mask"]
                )

        embeddings = embeddings.detach().cpu()

        ids_buffer.extend(ids)
        emb_buffer.append(embeddings)

        total_count += len(ids)

        if total_count % PRINT_EVERY == 0:
            elapsed = time.time() - start_time
            speed = total_count / elapsed if elapsed > 0 else 0

            print(
                f"{output_prefix} | "
                f"Processed: {total_count:,} sequences | "
                f"Elapsed: {elapsed / 60:.2f} min | "
                f"Speed: {speed:.2f} seq/s"
            )

    for seq_id, seq in read_fasta_generator(input_fasta):
        if MAX_RECORDS_PER_FASTA is not None and total_count >= MAX_RECORDS_PER_FASTA:
            break

        seq = clean_dna(seq)

        batch_ids.append(seq_id)
        batch_seqs.append(seq)

        if len(batch_ids) >= BATCH_SIZE:
            process_batch(batch_ids, batch_seqs)
            batch_ids = []
            batch_seqs = []

    if batch_ids:
        process_batch(batch_ids, batch_seqs)

    save_pt(
        output_dir=OUTPUT_DIR,
        output_prefix=output_prefix,
        ids_buffer=ids_buffer,
        emb_buffer=emb_buffer,
        input_fasta=input_fasta
    )

    total_time = time.time() - start_time

    print("=" * 80)
    print(f"Finished FASTA: {input_fasta}")
    print(f"Total sequences: {total_count:,}")
    print(f"Total time: {total_time / 60:.2f} min")

    if total_time > 0:
        print(f"Average speed: {total_count / total_time:.2f} seq/s")

    print("=" * 80)


# =========================
# 主程序
# =========================

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    fasta_files = sorted(
        glob.glob(os.path.join(INPUT_DIR, FASTA_PATTERN))
    )

    if not fasta_files:
        raise FileNotFoundError(
            f"No fasta files found in {INPUT_DIR} with pattern {FASTA_PATTERN}"
        )

    selected_files = []

    for fasta_file in fasta_files:
        chunk_id = get_chunk_id_from_filename(fasta_file)

        if chunk_id < START_CHUNK_ID:
            continue

        if END_CHUNK_ID is not None and chunk_id > END_CHUNK_ID:
            continue

        selected_files.append(fasta_file)

    if not selected_files:
        raise ValueError(
            "No fasta files selected. Check START_CHUNK_ID and END_CHUNK_ID."
        )

    print("Selected FASTA files:")
    for f in selected_files:
        print(f"  {os.path.basename(f)}")

    print(f"Total selected files: {len(selected_files)}")
    print("=" * 80)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")

    if device == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    else:
        print("Warning: CUDA not available. This will be very slow.")

    print("Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_NAME,
        trust_remote_code=True
    )

    print("Loading DNABERT2 model...")
    model = AutoModel.from_pretrained(
        MODEL_NAME,
        trust_remote_code=True
    )

    model.to(device)
    model.eval()

    all_start_time = time.time()

    for input_fasta in selected_files:
        extract_one_fasta(
            input_fasta=input_fasta,
            tokenizer=tokenizer,
            model=model,
            device=device
        )

        if device == "cuda":
            torch.cuda.empty_cache()

    all_time = time.time() - all_start_time

    print("#" * 80)
    print("All selected FASTA files finished.")
    print(f"Total files: {len(selected_files)}")
    print(f"Total time: {all_time / 60:.2f} min")
    print(f"Output directory: {OUTPUT_DIR}")
    print("#" * 80)


if __name__ == "__main__":
    main()