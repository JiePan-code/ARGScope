# -*- coding: utf-8 -*-
"""Train a DNA-only ARG/nonARG + ARG-subtype student from current PT files.

Training-only information
-------------------------
1. DNABERT-2 fragment embeddings (student input; 768 dimensions).
2. Supervised gated-fusion fragment embeddings (teacher input; 512 dimensions).
3. Residual-GAT refined ARG subtype prototypes (484 x 512).

Inference-only information
--------------------------
Only a DNABERT-2 DNA embedding is required.  The model first predicts
ARG/nonARG.  If ARG is predicted, it predicts one of the ARG subtypes.

Leakage policy
--------------
The script inherits ``model_splits`` from the gated-fusion PT.  Statistics,
teacher/student optimization and class weights use only ``train``.  Model
selection uses only ``validation``.  ``test`` is evaluated once after model
selection.  All fragments from the same original sequence must have one split.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import os
import random
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader, TensorDataset


SCRIPT_VERSION = (
    "2026-08-18-DNA-fusion-refined-precision-priority-"
    "ARG1-nonARG10-GPU-v1"
)
NONARG_CANONICAL = "nonARG"

HERE = Path(__file__).resolve().parent

# =============================================================================
# ARG:nonARG = 1:10, 50aa/150nt pipeline
# =============================================================================

DEFAULT_DNA_PT = (
    HERE
    / "DNA_embedding"
    / "fixed_50aa_150nt"
    / "fixed_50aa_150nt_chunk_000001_dnabert2_CLS.pt"
)

DEFAULT_FUSION_PT = (
    HERE
    / "Gated_fusion_ARG1_nonARG10_50aa_150nt_supervised"
    / "all_50aa_150nt_supervised_gated_fused_embeddings.pt"
)

DEFAULT_REFINED_PT = (
    HERE
    / "Refined_subtype_prototypes_ARG1_nonARG10_50aa_150nt"
    / "refined_ARG_subtype_prototypes_residual_GAT.pt"
)

DEFAULT_STRUCTURE = (
    HERE
    / "ARG1_nonARG10"
    / "all_arg_nonarg_structure.txt"
)

DEFAULT_OUTPUT_DIR = (
    HERE
    / "DNA_student_ARG1_nonARG10_50aa_150nt_fusion_refined_precision_v2"
)


@dataclass
class Config:
    seed: int = 20260817
    batch_size: int = 512
    num_workers: int = 0  # safest default on Windows
    teacher_epochs: int = 80
    student_epochs: int = 160
    teacher_patience: int = 15
    student_patience: int = 25
    teacher_lr: float = 3.0e-4
    student_lr: float = 2.0e-4
    weight_decay: float = 5.0e-5
    hidden_dim: int = 1024
    embedding_dim: int = 512
    dropout: float = 0.18
    temperature: float = 3.0
    logit_scale_binary: float = 16.0
    logit_scale_subtype: float = 24.0
    label_smoothing: float = 0.002
    # Mild weighting is deliberate: the primary selection target is weighted
    # precision on all validation samples, not rare-class recall at any cost.
    class_weight_power: float = 0.18
    # Teacher loss weights
    teacher_binary_ce: float = 1.0
    teacher_subtype_ce: float = 1.0
    teacher_feature_anchor: float = 0.10
    teacher_refined_anchor: float = 0.05
    # DNA student loss weights
    student_binary_ce: float = 1.0
    student_subtype_ce: float = 1.30
    student_binary_kd: float = 0.20
    student_subtype_kd: float = 0.05
    student_feature_align: float = 0.15
    student_prototype_align: float = 0.15
    student_head_anchor: float = 0.05
    gradient_clip: float = 1.0
    min_delta: float = 1.0e-5


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train the ARG1:nonARG10 DNA-only hierarchical student using fusion and refined prototypes."
    )
    parser.add_argument("--dna-pt", type=Path, default=DEFAULT_DNA_PT)
    parser.add_argument("--fusion-pt", type=Path, default=DEFAULT_FUSION_PT)
    parser.add_argument("--refined-pt", type=Path, default=DEFAULT_REFINED_PT)
    parser.add_argument("--structure", type=Path, default=DEFAULT_STRUCTURE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--batch-size", type=int, default=Config.batch_size)
    parser.add_argument("--teacher-epochs", type=int, default=Config.teacher_epochs)
    parser.add_argument("--student-epochs", type=int, default=Config.student_epochs)
    parser.add_argument("--num-workers", type=int, default=Config.num_workers)
    parser.add_argument("--seed", type=int, default=Config.seed)
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True
    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def canonical_id(value: Any) -> str:
    return str(value).strip().split()[0]


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()
    return NONARG_CANONICAL if text.lower() == "nonarg" else text


def load_pt(path: Path) -> Any:
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def require_tensor_2d(value: Any, name: str) -> torch.Tensor:
    if not isinstance(value, torch.Tensor) or value.ndim != 2:
        raise ValueError(f"{name} must be a two-dimensional torch.Tensor")
    value = value.detach().cpu().float().contiguous()
    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} contains NaN or Inf")
    return value


def extract_embedding_pt(path: Path, description: str) -> tuple[list[str], torch.Tensor, dict]:
    obj = load_pt(path)
    if not isinstance(obj, dict):
        raise TypeError(f"{description} PT must contain a dictionary: {path}")
    id_key = next((key for key in ("ids", "fragment_ids", "sequence_ids") if key in obj), None)
    emb_key = next((key for key in ("embeddings", "mean_embeddings", "features") if key in obj), None)
    if id_key is None or emb_key is None:
        raise KeyError(
            f"{description} PT requires ID and embedding fields; keys={sorted(obj.keys())}"
        )
    ids = [canonical_id(value) for value in obj[id_key]]
    embeddings = require_tensor_2d(obj[emb_key], f"{description} embeddings")
    if len(ids) != embeddings.shape[0]:
        raise ValueError(
            f"{description} row mismatch: IDs={len(ids)}, embeddings={embeddings.shape[0]}"
        )
    if len(set(ids)) != len(ids):
        duplicates = len(ids) - len(set(ids))
        raise ValueError(f"{description} has {duplicates} duplicate fragment IDs")
    return ids, embeddings, obj


def validate_paths(args: argparse.Namespace) -> None:
    for path, name in (
        (args.dna_pt, "DNA embedding PT"),
        (args.fusion_pt, "gated-fusion PT"),
        (args.refined_pt, "refined prototype PT"),
        (args.structure, "ARG/nonARG structure file"),
    ):
        if not path.is_file():
            raise FileNotFoundError(f"{name} not found: {path}")
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and not args.overwrite:
        raise FileExistsError(
            f"Output directory is not empty: {args.output_dir}\n"
            "Use --overwrite to replace files made by this script."
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)


def load_subtype_to_type(structure_path: Path) -> dict[str, str]:
    """Read the authoritative Subtype-to-Type mapping from the structure file."""
    with structure_path.open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(8192)
        handle.seek(0)
        delimiter = "\t" if "\t" in sample.splitlines()[0] else ","
        reader = csv.DictReader(handle, delimiter=delimiter)
        if not reader.fieldnames or "Type" not in reader.fieldnames or "Subtype" not in reader.fieldnames:
            raise ValueError(
                f"Structure file must contain Type and Subtype columns: {structure_path}; "
                f"columns={reader.fieldnames}"
            )
        mapping: dict[str, str] = {}
        for row in reader:
            subtype = canonical_subtype(row.get("Subtype", ""))
            type_name = str(row.get("Type", "")).strip()
            if not subtype or subtype.lower() in {"nan", "none"}:
                continue
            if subtype.lower() == "nonarg":
                type_name = NONARG_CANONICAL
            if not type_name:
                raise ValueError(f"Empty Type for Subtype={subtype} in {structure_path}")
            if subtype in mapping and mapping[subtype] != type_name:
                raise ValueError(
                    f"Subtype maps to multiple Types: {subtype}; "
                    f"{mapping[subtype]} versus {type_name}"
                )
            mapping[subtype] = type_name
    if not mapping:
        raise ValueError(f"No Subtype-to-Type mappings found: {structure_path}")
    return mapping


def load_and_align_data(
    dna_path: Path,
    fusion_path: Path,
    refined_path: Path,
    structure_path: Path,
) -> dict[str, Any]:
    dna_ids, dna_embeddings, _ = extract_embedding_pt(dna_path, "DNA")
    fusion_ids, fusion_embeddings, fusion_obj = extract_embedding_pt(fusion_path, "fusion")

    required = ("original_ids", "subtypes", "model_splits")
    missing = [key for key in required if key not in fusion_obj]
    if missing:
        raise KeyError(f"Fusion PT is missing metadata fields: {missing}")

    n = len(fusion_ids)
    original_ids = [canonical_id(value) for value in fusion_obj["original_ids"]]
    subtypes = [canonical_subtype(value) for value in fusion_obj["subtypes"]]
    model_splits = [str(value).strip().lower() for value in fusion_obj["model_splits"]]
    if not all(len(values) == n for values in (original_ids, subtypes, model_splits)):
        raise ValueError("Fusion IDs, original IDs, subtypes and model_splits must have equal lengths")
    invalid_splits = sorted(set(model_splits) - {"train", "validation", "test"})
    if invalid_splits:
        raise ValueError(f"Invalid model_splits: {invalid_splits}")

    dna_index = {value: index for index, value in enumerate(dna_ids)}
    missing_dna = [value for value in fusion_ids if value not in dna_index]
    if missing_dna:
        raise ValueError(
            f"{len(missing_dna)} fusion fragments have no DNA embedding; examples={missing_dna[:10]}"
        )
    alignment = torch.tensor([dna_index[value] for value in fusion_ids], dtype=torch.long)
    dna_embeddings = dna_embeddings.index_select(0, alignment).contiguous()

    if fusion_embeddings.shape[1] != 512:
        raise ValueError(f"Expected fusion dimension 512, found {fusion_embeddings.shape[1]}")
    if dna_embeddings.shape[1] != 768:
        raise ValueError(
            f"Expected DNABERT-2 dimension 768, found {dna_embeddings.shape[1]}. "
            "Please use the corrected DNABERT-2 PT rather than the old 1024-D result."
        )

    per_original: dict[str, tuple[str, str]] = {}
    fragment_counts: defaultdict[str, int] = defaultdict(int)
    for original_id, subtype, split in zip(original_ids, subtypes, model_splits):
        current = (subtype, split)
        if original_id in per_original and per_original[original_id] != current:
            raise ValueError(
                f"Original ID has inconsistent subtype/split: {original_id}; "
                f"{per_original[original_id]} versus {current}"
            )
        per_original[original_id] = current
        fragment_counts[original_id] += 1

    refined_obj = load_pt(refined_path)
    if not isinstance(refined_obj, dict):
        raise TypeError("Refined prototype PT must contain a dictionary")
    if "arg_subtype_names" not in refined_obj or "refined_arg_subtype_prototypes" not in refined_obj:
        raise KeyError(
            "Refined PT requires 'arg_subtype_names' and "
            "'refined_arg_subtype_prototypes'"
        )
    arg_names = [canonical_subtype(value) for value in refined_obj["arg_subtype_names"]]
    refined = require_tensor_2d(
        refined_obj["refined_arg_subtype_prototypes"], "refined ARG prototypes"
    )
    if len(arg_names) != refined.shape[0] or refined.shape[1] != 512:
        raise ValueError(
            f"Refined prototype mismatch: names={len(arg_names)}, shape={tuple(refined.shape)}"
        )
    if any(name.lower() == "nonarg" for name in arg_names):
        raise ValueError("nonARG must not be present in the ARG subtype prototype graph")
    if len(set(arg_names)) != len(arg_names):
        raise ValueError("Duplicate subtype names in refined prototype PT")

    observed_arg = {value for value in subtypes if value.lower() != "nonarg"}
    refined_arg = set(arg_names)
    if observed_arg != refined_arg:
        raise ValueError(
            "ARG subtype set differs between fusion and refined PT. "
            f"Missing in refined={sorted(observed_arg-refined_arg)[:10]}; "
            f"extra in refined={sorted(refined_arg-observed_arg)[:10]}"
        )
    if NONARG_CANONICAL not in set(subtypes):
        raise ValueError("No nonARG records were found")

    subtype_to_type = load_subtype_to_type(structure_path)
    missing_type_mapping = sorted(set(subtypes) - set(subtype_to_type))
    if missing_type_mapping:
        raise ValueError(
            f"{len(missing_type_mapping)} observed Subtypes have no Type mapping; "
            f"examples={missing_type_mapping[:10]}"
        )
    type_names = sorted(
        {subtype_to_type[name] for name in arg_names}, key=lambda value: value.lower()
    )

    arg_to_index = {name: index for index, name in enumerate(arg_names)}
    binary_targets = torch.tensor(
        [0 if value.lower() == "nonarg" else 1 for value in subtypes], dtype=torch.long
    )
    arg_targets = torch.tensor(
        [-1 if value.lower() == "nonarg" else arg_to_index[value] for value in subtypes],
        dtype=torch.long,
    )
    split_indices = {
        split: torch.tensor(
            [index for index, value in enumerate(model_splits) if value == split],
            dtype=torch.long,
        )
        for split in ("train", "validation", "test")
    }
    if any(indices.numel() == 0 for indices in split_indices.values()):
        raise ValueError(
            f"All three splits must be nonempty: "
            f"{ {key: value.numel() for key, value in split_indices.items()} }"
        )

    print(f"DNA embedding shape       : {tuple(dna_embeddings.shape)}", flush=True)
    print(f"Fusion embedding shape    : {tuple(fusion_embeddings.shape)}", flush=True)
    print(f"Refined prototype shape   : {tuple(refined.shape)}", flush=True)
    print(f"Fragment IDs aligned      : {fusion_ids == [dna_ids[i] for i in alignment.tolist()]}", flush=True)
    print(f"Unique originals          : {len(per_original):,}", flush=True)
    print(f"ARG subtype count         : {len(arg_names):,}", flush=True)
    print(f"ARG Type count            : {len(type_names):,}", flush=True)
    print(f"Fragments/original        : {dict(sorted(set(fragment_counts.values()) and {x: list(fragment_counts.values()).count(x) for x in set(fragment_counts.values())}.items()))}", flush=True)
    for split, indices in split_indices.items():
        originals = {original_ids[i] for i in indices.tolist()}
        subtype_count = len({subtypes[i] for i in indices.tolist()})
        print(
            f"{split:10s}: fragments={indices.numel():,}, originals={len(originals):,}, "
            f"subtypes={subtype_count:,}",
            flush=True,
        )

    return {
        "fragment_ids": fusion_ids,
        "original_ids": original_ids,
        "subtypes": subtypes,
        "model_splits": model_splits,
        "dna": dna_embeddings,
        "fusion": fusion_embeddings,
        "refined": F.normalize(refined, p=2, dim=1),
        "arg_names": arg_names,
        "type_names": type_names,
        "subtype_to_type": subtype_to_type,
        "binary_targets": binary_targets,
        "arg_targets": arg_targets,
        "split_indices": split_indices,
        "source_fusion": fusion_obj,
        "source_refined": refined_obj,
    }


def mild_class_weights(targets: torch.Tensor, number_classes: int, power: float) -> torch.Tensor:
    counts = torch.bincount(targets, minlength=number_classes).float().clamp_min(1.0)
    weights = (counts.mean() / counts).pow(power)
    weights = weights / weights.mean()
    return weights.clamp(0.70, 2.50)


class CosineHead(nn.Module):
    def __init__(self, number_classes: int, dimension: int, scale: float):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(number_classes, dimension))
        nn.init.xavier_uniform_(self.weight)
        self.scale = float(scale)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.scale * F.linear(
            F.normalize(features, p=2, dim=1),
            F.normalize(self.weight, p=2, dim=1),
        )

    def normalized_weight(self) -> torch.Tensor:
        return F.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    """Classifier heads on the fixed current 512-D gated-fusion space.

    The gated-fusion embedding is already subtype supervised.  V2 therefore
    keeps its coordinates fixed instead of learning a second feature mapper.
    Only the classification heads are optimized.
    """

    def __init__(self, refined: torch.Tensor, config: Config):
        super().__init__()
        d = config.embedding_dim
        self.binary_head = CosineHead(2, d, config.logit_scale_binary)
        self.arg_head = CosineHead(refined.shape[0], d, config.logit_scale_subtype)
        with torch.no_grad():
            self.arg_head.weight.copy_(refined)

    def encode(self, fusion: torch.Tensor) -> torch.Tensor:
        return F.normalize(fusion, p=2, dim=1)

    def forward(self, fusion: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        z = self.encode(fusion)
        return self.binary_head(z), self.arg_head(z), z


class ResidualBlock(nn.Module):
    def __init__(self, dimension: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.gelu(x + self.net(x))


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        config: Config,
    ):
        super().__init__()
        self.register_buffer("dna_mean", dna_mean.clone())
        self.register_buffer("dna_std", dna_std.clone())
        self.input = nn.Sequential(
            nn.Linear(dna_dimension, config.hidden_dim),
            nn.LayerNorm(config.hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
        )
        self.blocks = nn.Sequential(
            ResidualBlock(config.hidden_dim, config.dropout),
            ResidualBlock(config.hidden_dim, config.dropout),
        )
        self.output = nn.Sequential(
            nn.Linear(config.hidden_dim, config.embedding_dim),
            nn.LayerNorm(config.embedding_dim),
        )
        self.binary_head = CosineHead(2, config.embedding_dim, config.logit_scale_binary)
        self.arg_head = CosineHead(
            number_arg_subtypes, config.embedding_dim, config.logit_scale_subtype
        )

    def encode(self, dna: torch.Tensor) -> torch.Tensor:
        dna = (dna - self.dna_mean) / self.dna_std
        hidden = self.blocks(self.input(dna))
        return F.normalize(self.output(hidden), p=2, dim=1)

    def forward(self, dna: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        z = self.encode(dna)
        return self.binary_head(z), self.arg_head(z), z


def initialize_binary_centers(
    model: FusionTeacher,
    fusion: torch.Tensor,
    binary_targets: torch.Tensor,
) -> None:
    centers = []
    normalized = F.normalize(fusion, p=2, dim=1)
    for label in (0, 1):
        center = normalized[binary_targets == label].mean(dim=0)
        centers.append(F.normalize(center, p=2, dim=0))
    with torch.no_grad():
        model.binary_head.weight.copy_(torch.stack(centers))


def make_loader(
    indices: torch.Tensor,
    dna: torch.Tensor,
    fusion: torch.Tensor,
    binary_targets: torch.Tensor,
    arg_targets: torch.Tensor,
    config: Config,
    shuffle: bool,
) -> DataLoader:
    dataset = TensorDataset(
        dna.index_select(0, indices),
        fusion.index_select(0, indices),
        binary_targets.index_select(0, indices),
        arg_targets.index_select(0, indices),
        indices,
    )
    return DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=shuffle,
        num_workers=config.num_workers,
        pin_memory=True,
        persistent_workers=config.num_workers > 0,
        drop_last=False,
    )


def amp_context(device: torch.device, enabled: bool):
    return torch.autocast(device_type=device.type, dtype=torch.float16, enabled=enabled)


def make_grad_scaler(enabled: bool):
    try:
        return torch.amp.GradScaler("cuda", enabled=enabled)
    except (AttributeError, TypeError):
        return torch.cuda.amp.GradScaler(enabled=enabled)


def cosine_pull(features: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    return (1.0 - (F.normalize(features.float(), p=2, dim=1) * F.normalize(targets.float(), p=2, dim=1)).sum(dim=1)).mean()


def kd_loss(student: torch.Tensor, teacher: torch.Tensor, temperature: float) -> torch.Tensor:
    log_prob = F.log_softmax(student.float() / temperature, dim=1)
    target_prob = F.softmax(teacher.float().detach() / temperature, dim=1)
    return F.kl_div(log_prob, target_prob, reduction="batchmean") * temperature**2


def safe_mcc(true: np.ndarray, predicted: np.ndarray) -> float:
    if len(true) == 0 or len(np.unique(true)) < 2 or len(np.unique(predicted)) < 2:
        return 0.0
    return float(matthews_corrcoef(true, predicted))


def metric_dict(true: np.ndarray, predicted: np.ndarray) -> dict[str, float | int]:
    if len(true) == 0:
        return {
            "n": 0,
            "accuracy": 0.0,
            "macro_precision": 0.0,
            "weighted_precision": 0.0,
            "macro_recall": 0.0,
            "weighted_recall": 0.0,
            "macro_f1": 0.0,
            "weighted_f1": 0.0,
            "mcc": 0.0,
        }
    return {
        "n": int(len(true)),
        "accuracy": float(accuracy_score(true, predicted)),
        "macro_precision": float(
            precision_score(true, predicted, average="macro", zero_division=0)
        ),
        "weighted_precision": float(
            precision_score(true, predicted, average="weighted", zero_division=0)
        ),
        "macro_recall": float(
            recall_score(true, predicted, average="macro", zero_division=0)
        ),
        "weighted_recall": float(
            recall_score(true, predicted, average="weighted", zero_division=0)
        ),
        "macro_f1": float(f1_score(true, predicted, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(true, predicted, average="weighted", zero_division=0)),
        "mcc": safe_mcc(true, predicted),
    }


@torch.no_grad()
def collect_model_outputs(
    model: nn.Module,
    input_embeddings: torch.Tensor,
    indices: torch.Tensor,
    batch_size: int,
    device: torch.device,
    use_amp: bool,
) -> dict[str, torch.Tensor]:
    model.eval()
    loader = DataLoader(
        TensorDataset(input_embeddings.index_select(0, indices), indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    binary_logits, arg_logits, features, row_indices = [], [], [], []
    for xb, global_indices in loader:
        xb = xb.to(device, non_blocking=True)
        with amp_context(device, use_amp):
            binary, subtype, z = model(xb)
        binary_logits.append(binary.float().cpu())
        arg_logits.append(subtype.float().cpu())
        features.append(z.float().cpu())
        row_indices.append(global_indices)
    return {
        "indices": torch.cat(row_indices),
        "binary_logits": torch.cat(binary_logits),
        "arg_logits": torch.cat(arg_logits),
        "features": torch.cat(features),
    }


def predictions_and_metrics(
    outputs: dict[str, torch.Tensor],
    binary_targets: torch.Tensor,
    arg_targets: torch.Tensor,
    binary_threshold: float = 0.50,
) -> tuple[dict[str, dict[str, float | int]], dict[str, np.ndarray]]:
    indices = outputs["indices"]
    true_binary = binary_targets.index_select(0, indices).numpy()
    true_arg = arg_targets.index_select(0, indices).numpy()
    binary_prob = torch.softmax(outputs["binary_logits"], dim=1).numpy()
    arg_prob = torch.softmax(outputs["arg_logits"], dim=1).numpy()
    pred_binary = (binary_prob[:, 1] >= binary_threshold).astype(np.int64)
    pred_arg = arg_prob.argmax(axis=1)
    true_full = np.where(true_binary == 0, 0, true_arg + 1)
    predicted_full = np.where(pred_binary == 0, 0, pred_arg + 1)
    arg_mask = true_binary == 1
    metrics = {
        "binary": metric_dict(true_binary, pred_binary),
        "ARG_subtype_oracle_binary": metric_dict(true_arg[arg_mask], pred_arg[arg_mask]),
        "end_to_end_485_class": metric_dict(true_full, predicted_full),
    }
    arrays = {
        "indices": indices.numpy(),
        "true_binary": true_binary,
        "pred_binary": pred_binary,
        "true_arg": true_arg,
        "pred_arg": pred_arg,
        "true_full": true_full,
        "predicted_full": predicted_full,
        "binary_ARG_probability": binary_prob[:, 1],
        "ARG_subtype_probability": arg_prob.max(axis=1),
    }
    return metrics, arrays


@torch.no_grad()
def aggregate_original_outputs(
    outputs: dict[str, torch.Tensor],
    original_ids: list[str],
    binary_targets: torch.Tensor,
    arg_targets: torch.Tensor,
    model: nn.Module,
) -> tuple[dict[str, torch.Tensor], list[str]]:
    groups: dict[str, list[int]] = defaultdict(list)
    global_indices = outputs["indices"].tolist()
    for local_index, global_index in enumerate(global_indices):
        groups[original_ids[global_index]].append(local_index)

    ordered_ids = list(groups)
    mean_features = []
    representative_indices = []
    for original_id in ordered_ids:
        local = torch.tensor(groups[original_id], dtype=torch.long)
        z = outputs["features"].index_select(0, local).mean(dim=0)
        mean_features.append(F.normalize(z, p=2, dim=0))
        representative_indices.append(global_indices[groups[original_id][0]])
        binary_values = binary_targets[torch.tensor([global_indices[x] for x in groups[original_id]])]
        arg_values = arg_targets[torch.tensor([global_indices[x] for x in groups[original_id]])]
        if len(torch.unique(binary_values)) != 1 or len(torch.unique(arg_values)) != 1:
            raise ValueError(f"Inconsistent labels within original ID: {original_id}")

    feature_tensor = torch.stack(mean_features)
    binary_logits = model.binary_head(feature_tensor.to(next(model.parameters()).device)).float().cpu()
    arg_logits = model.arg_head(feature_tensor.to(next(model.parameters()).device)).float().cpu()
    return {
        "indices": torch.tensor(representative_indices, dtype=torch.long),
        "binary_logits": binary_logits,
        "arg_logits": arg_logits,
        "features": feature_tensor,
    }, ordered_ids


def validation_score(metrics: dict[str, dict[str, float | int]]) -> float:
    full = metrics["end_to_end_485_class"]
    subtype = metrics["ARG_subtype_oracle_binary"]
    binary = metrics["binary"]
    # Precision-priority selection on all samples.  There is no rejection,
    # Unknown class or confidence filtering: coverage always remains 100%.
    return (
        0.45 * float(subtype["weighted_precision"])
        + 0.25 * float(full["weighted_precision"])
        + 0.15 * float(full["accuracy"])
        + 0.10 * float(full["mcc"])
        + 0.05 * float(binary["weighted_precision"])
    )


def evaluate_for_selection(
    model: nn.Module,
    inputs: torch.Tensor,
    validation_indices: torch.Tensor,
    data: dict[str, Any],
    config: Config,
    device: torch.device,
    use_amp: bool,
) -> tuple[float, dict[str, Any]]:
    fragment_outputs = collect_model_outputs(
        model, inputs, validation_indices, config.batch_size, device, use_amp
    )
    fragment_metrics, _ = predictions_and_metrics(
        fragment_outputs, data["binary_targets"], data["arg_targets"]
    )
    original_outputs, _ = aggregate_original_outputs(
        fragment_outputs,
        data["original_ids"],
        data["binary_targets"],
        data["arg_targets"],
        model,
    )
    original_metrics, _ = predictions_and_metrics(
        original_outputs, data["binary_targets"], data["arg_targets"]
    )
    return validation_score(original_metrics), {
        "fragment": fragment_metrics,
        "original": original_metrics,
    }


def select_binary_threshold_on_validation(
    model: nn.Module,
    inputs: torch.Tensor,
    data: dict[str, Any],
    config: Config,
    device: torch.device,
    use_amp: bool,
) -> tuple[float, list[dict[str, Any]]]:
    """Select an ARG probability threshold using validation originals only.

    Every sample is still classified as ARG or nonARG.  This is threshold
    calibration, not rejection or confidence filtering.
    """
    fragment_outputs = collect_model_outputs(
        model,
        inputs,
        data["split_indices"]["validation"],
        config.batch_size,
        device,
        use_amp,
    )
    original_outputs, _ = aggregate_original_outputs(
        fragment_outputs,
        data["original_ids"],
        data["binary_targets"],
        data["arg_targets"],
        model,
    )
    indices = original_outputs["indices"]
    true_binary = data["binary_targets"].index_select(0, indices).numpy()
    probability = torch.softmax(original_outputs["binary_logits"], dim=1)[:, 1].numpy()
    rows = []
    best_threshold = 0.50
    best_score = -math.inf
    for threshold in np.round(np.arange(0.30, 0.901, 0.01), 2):
        predicted = (probability >= threshold).astype(np.int64)
        arg_precision = float(
            precision_score(true_binary, predicted, pos_label=1, zero_division=0)
        )
        arg_recall = float(
            recall_score(true_binary, predicted, pos_label=1, zero_division=0)
        )
        accuracy = float(accuracy_score(true_binary, predicted))
        mcc = safe_mcc(true_binary, predicted)
        score = 0.70 * arg_precision + 0.20 * accuracy + 0.10 * mcc
        rows.append({
            "threshold": float(threshold),
            "ARG_precision": arg_precision,
            "ARG_recall": arg_recall,
            "accuracy": accuracy,
            "mcc": mcc,
            "selection_score": score,
            "coverage": 1.0,
        })
        if score > best_score + 1.0e-12:
            best_score = score
            best_threshold = float(threshold)
    print(
        f"Selected binary ARG threshold on validation originals: {best_threshold:.2f} "
        f"(precision-priority score={best_score:.6f}, coverage=1.0)",
        flush=True,
    )
    return best_threshold, rows


def train_teacher(
    data: dict[str, Any],
    config: Config,
    device: torch.device,
    use_amp: bool,
) -> tuple[FusionTeacher, list[dict[str, Any]], int, float]:
    train_indices = data["split_indices"]["train"]
    validation_indices = data["split_indices"]["validation"]
    train_arg = data["arg_targets"].index_select(0, train_indices)
    arg_only = train_arg[train_arg >= 0]
    subtype_weights = mild_class_weights(
        arg_only, len(data["arg_names"]), config.class_weight_power
    ).to(device)

    model = FusionTeacher(data["refined"], config).to(device)
    initialize_binary_centers(
        model,
        data["fusion"].index_select(0, train_indices).to(device),
        data["binary_targets"].index_select(0, train_indices).to(device),
    )
    refined_device = data["refined"].to(device)
    loader = make_loader(
        train_indices,
        data["dna"],
        data["fusion"],
        data["binary_targets"],
        data["arg_targets"],
        config,
        shuffle=True,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.teacher_lr, weight_decay=config.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=5, min_lr=1.0e-6
    )
    scaler = make_grad_scaler(use_amp)
    history = []
    best_score = -math.inf
    best_epoch = 0
    best_state = None
    no_improvement = 0

    print("\n===== TRAIN FUSION TEACHER (TRAIN ONLY) =====", flush=True)
    for epoch in range(1, config.teacher_epochs + 1):
        model.train()
        totals = defaultdict(float)
        seen = 0
        for _, fusion, binary_y, arg_y, _ in loader:
            fusion = fusion.to(device, non_blocking=True)
            binary_y = binary_y.to(device, non_blocking=True)
            arg_y = arg_y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with amp_context(device, use_amp):
                binary_logits, arg_logits, z = model(fusion)
                loss_binary = F.cross_entropy(
                    binary_logits.float(), binary_y, label_smoothing=config.label_smoothing
                )
                arg_mask = arg_y >= 0
                loss_subtype = F.cross_entropy(
                    arg_logits[arg_mask].float(),
                    arg_y[arg_mask],
                    weight=subtype_weights,
                    label_smoothing=config.label_smoothing,
                )
                loss_feature = cosine_pull(z, F.normalize(fusion, p=2, dim=1))
                loss_refined = (
                    1.0 - (model.arg_head.normalized_weight() * refined_device).sum(dim=1)
                ).mean()
                loss = (
                    config.teacher_binary_ce * loss_binary
                    + config.teacher_subtype_ce * loss_subtype
                    + config.teacher_feature_anchor * loss_feature
                    + config.teacher_refined_anchor * loss_refined
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip)
            scaler.step(optimizer)
            scaler.update()
            batch_n = binary_y.shape[0]
            seen += batch_n
            for key, value in (
                ("loss", loss), ("binary", loss_binary), ("subtype", loss_subtype),
                ("feature", loss_feature), ("refined", loss_refined),
            ):
                totals[key] += float(value.detach()) * batch_n

        score, validation = evaluate_for_selection(
            model,
            data["fusion"],
            validation_indices,
            data,
            config,
            device,
            use_amp,
        )
        scheduler.step(score)
        row = {
            "stage": "teacher",
            "epoch": epoch,
            "loss": totals["loss"] / seen,
            "binary_loss": totals["binary"] / seen,
            "subtype_loss": totals["subtype"] / seen,
            "feature_loss": totals["feature"] / seen,
            "refined_loss": totals["refined"] / seen,
            "validation_score": score,
            "validation_original_weighted_precision": validation["original"]["end_to_end_485_class"]["weighted_precision"],
            "validation_original_macro_f1": validation["original"]["end_to_end_485_class"]["macro_f1"],
            "lr": optimizer.param_groups[0]["lr"],
        }
        history.append(row)
        print(
            f"Teacher epoch {epoch:03d} | loss={row['loss']:.5f} | "
            f"val_score={score:.5f} | val_original_weighted_precision="
            f"{row['validation_original_weighted_precision']:.5f} | lr={row['lr']:.2e}",
            flush=True,
        )
        if score > best_score + config.min_delta:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            no_improvement = 0
        else:
            no_improvement += 1
        if no_improvement >= config.teacher_patience:
            print(f"Teacher early stopping at epoch {epoch}", flush=True)
            break
    if best_state is None:
        raise RuntimeError("Fusion teacher did not produce a checkpoint")
    model.load_state_dict(best_state)
    model.eval()
    return model, history, best_epoch, best_score


def train_student(
    teacher: FusionTeacher,
    data: dict[str, Any],
    config: Config,
    device: torch.device,
    use_amp: bool,
) -> tuple[DNAStudent, list[dict[str, Any]], int, float, torch.Tensor, torch.Tensor]:
    train_indices = data["split_indices"]["train"]
    validation_indices = data["split_indices"]["validation"]
    dna_train = data["dna"].index_select(0, train_indices)
    dna_mean = dna_train.mean(dim=0)
    dna_std = dna_train.std(dim=0, unbiased=False).clamp_min(1.0e-6)
    train_arg = data["arg_targets"].index_select(0, train_indices)
    arg_only = train_arg[train_arg >= 0]
    subtype_weights = mild_class_weights(
        arg_only, len(data["arg_names"]), config.class_weight_power
    ).to(device)

    model = DNAStudent(
        data["dna"].shape[1],
        dna_mean,
        dna_std,
        len(data["arg_names"]),
        config,
    ).to(device)
    with torch.no_grad():
        model.binary_head.weight.copy_(teacher.binary_head.weight)
        model.arg_head.weight.copy_(teacher.arg_head.weight)
    teacher_binary_anchor = teacher.binary_head.normalized_weight().detach()
    teacher_arg_anchor = teacher.arg_head.normalized_weight().detach()
    refined = data["refined"].to(device)

    # Separate train-only nonARG center.  It is never inserted into the ARG graph.
    train_fusion = F.normalize(data["fusion"].index_select(0, train_indices), p=2, dim=1)
    train_binary = data["binary_targets"].index_select(0, train_indices)
    nonarg_center = F.normalize(train_fusion[train_binary == 0].mean(dim=0), p=2, dim=0).to(device)

    loader = make_loader(
        train_indices,
        data["dna"],
        data["fusion"],
        data["binary_targets"],
        data["arg_targets"],
        config,
        shuffle=True,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.student_lr, weight_decay=config.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=7, min_lr=1.0e-6
    )
    scaler = make_grad_scaler(use_amp)
    history = []
    best_score = -math.inf
    best_epoch = 0
    best_state = None
    no_improvement = 0
    teacher.eval()

    print("\n===== TRAIN DNA-ONLY STUDENT (TRAIN ONLY) =====", flush=True)
    for epoch in range(1, config.student_epochs + 1):
        model.train()
        totals = defaultdict(float)
        seen = 0
        for dna, fusion, binary_y, arg_y, _ in loader:
            dna = dna.to(device, non_blocking=True)
            fusion = fusion.to(device, non_blocking=True)
            binary_y = binary_y.to(device, non_blocking=True)
            arg_y = arg_y.to(device, non_blocking=True)
            with torch.no_grad():
                with amp_context(device, use_amp):
                    teacher_binary, teacher_arg, teacher_z = teacher(fusion)
            optimizer.zero_grad(set_to_none=True)
            with amp_context(device, use_amp):
                student_binary, student_arg, student_z = model(dna)
                loss_binary = F.cross_entropy(
                    student_binary.float(), binary_y, label_smoothing=config.label_smoothing
                )
                arg_mask = arg_y >= 0
                loss_subtype = F.cross_entropy(
                    student_arg[arg_mask].float(),
                    arg_y[arg_mask],
                    weight=subtype_weights,
                    label_smoothing=config.label_smoothing,
                )
                loss_binary_kd = kd_loss(student_binary, teacher_binary, config.temperature)
                loss_subtype_kd = kd_loss(
                    student_arg[arg_mask], teacher_arg[arg_mask], config.temperature
                )
                loss_feature = cosine_pull(student_z, teacher_z)
                target_prototypes = torch.empty_like(student_z)
                target_prototypes[arg_mask] = refined.index_select(0, arg_y[arg_mask])
                target_prototypes[~arg_mask] = nonarg_center
                loss_prototype = cosine_pull(student_z, target_prototypes)
                loss_head = (
                    1.0
                    - (model.binary_head.normalized_weight() * teacher_binary_anchor).sum(dim=1)
                ).mean() + (
                    1.0
                    - (model.arg_head.normalized_weight() * teacher_arg_anchor).sum(dim=1)
                ).mean()
                loss = (
                    config.student_binary_ce * loss_binary
                    + config.student_subtype_ce * loss_subtype
                    + config.student_binary_kd * loss_binary_kd
                    + config.student_subtype_kd * loss_subtype_kd
                    + config.student_feature_align * loss_feature
                    + config.student_prototype_align * loss_prototype
                    + config.student_head_anchor * loss_head
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip)
            scaler.step(optimizer)
            scaler.update()
            batch_n = binary_y.shape[0]
            seen += batch_n
            for key, value in (
                ("loss", loss), ("binary", loss_binary), ("subtype", loss_subtype),
                ("binary_kd", loss_binary_kd), ("subtype_kd", loss_subtype_kd),
                ("feature", loss_feature), ("prototype", loss_prototype), ("head", loss_head),
            ):
                totals[key] += float(value.detach()) * batch_n

        score, validation = evaluate_for_selection(
            model,
            data["dna"],
            validation_indices,
            data,
            config,
            device,
            use_amp,
        )
        scheduler.step(score)
        row = {
            "stage": "student",
            "epoch": epoch,
            "loss": totals["loss"] / seen,
            "binary_loss": totals["binary"] / seen,
            "subtype_loss": totals["subtype"] / seen,
            "binary_kd_loss": totals["binary_kd"] / seen,
            "subtype_kd_loss": totals["subtype_kd"] / seen,
            "feature_loss": totals["feature"] / seen,
            "prototype_loss": totals["prototype"] / seen,
            "head_loss": totals["head"] / seen,
            "validation_score": score,
            "validation_original_weighted_precision": validation["original"]["end_to_end_485_class"]["weighted_precision"],
            "validation_original_macro_f1": validation["original"]["end_to_end_485_class"]["macro_f1"],
            "lr": optimizer.param_groups[0]["lr"],
        }
        history.append(row)
        print(
            f"Student epoch {epoch:03d} | loss={row['loss']:.5f} | "
            f"val_score={score:.5f} | val_original_weighted_precision="
            f"{row['validation_original_weighted_precision']:.5f} | lr={row['lr']:.2e}",
            flush=True,
        )
        if score > best_score + config.min_delta:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            no_improvement = 0
        else:
            no_improvement += 1
        if no_improvement >= config.student_patience:
            print(f"Student early stopping at epoch {epoch}", flush=True)
            break
    if best_state is None:
        raise RuntimeError("DNA student did not produce a checkpoint")
    model.load_state_dict(best_state)
    model.eval()
    return model, history, best_epoch, best_score, dna_mean, dna_std


def evaluate_split(
    model: DNAStudent,
    split: str,
    data: dict[str, Any],
    config: Config,
    device: torch.device,
    use_amp: bool,
    binary_threshold: float,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    outputs = collect_model_outputs(
        model,
        data["dna"],
        data["split_indices"][split],
        config.batch_size,
        device,
        use_amp,
    )
    fragment_metrics, fragment_arrays = predictions_and_metrics(
        outputs,
        data["binary_targets"],
        data["arg_targets"],
        binary_threshold=binary_threshold,
    )
    original_outputs, ordered_original_ids = aggregate_original_outputs(
        outputs,
        data["original_ids"],
        data["binary_targets"],
        data["arg_targets"],
        model,
    )
    original_metrics, original_arrays = predictions_and_metrics(
        original_outputs,
        data["binary_targets"],
        data["arg_targets"],
        binary_threshold=binary_threshold,
    )
    full_names = [NONARG_CANONICAL] + data["arg_names"]

    fragment_rows = []
    for local, global_index in enumerate(fragment_arrays["indices"]):
        fragment_rows.append({
            "split": split,
            "fragment_id": data["fragment_ids"][global_index],
            "original_id": data["original_ids"][global_index],
            "true_subtype": full_names[fragment_arrays["true_full"][local]],
            "predicted_subtype": full_names[fragment_arrays["predicted_full"][local]],
            "predicted_ARG": int(fragment_arrays["pred_binary"][local]),
            "ARG_probability": float(fragment_arrays["binary_ARG_probability"][local]),
            "ARG_subtype_max_probability": float(fragment_arrays["ARG_subtype_probability"][local]),
        })
    original_rows = []
    for local, original_id in enumerate(ordered_original_ids):
        original_rows.append({
            "split": split,
            "original_id": original_id,
            "true_subtype": full_names[original_arrays["true_full"][local]],
            "predicted_subtype": full_names[original_arrays["predicted_full"][local]],
            "predicted_ARG": int(original_arrays["pred_binary"][local]),
            "ARG_probability": float(original_arrays["binary_ARG_probability"][local]),
            "ARG_subtype_max_probability": float(original_arrays["ARG_subtype_probability"][local]),
        })
    return {"fragment": fragment_metrics, "original": original_metrics}, fragment_rows, original_rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fieldnames = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def one_vs_rest_class_metrics(
    true_labels: list[str],
    predicted_labels: list[str],
    class_names: list[str],
    class_column: str,
    split: str,
    sequence_level: str,
) -> list[dict[str, Any]]:
    true_array = np.asarray(true_labels, dtype=object)
    predicted_array = np.asarray(predicted_labels, dtype=object)
    number = len(true_array)
    rows = []
    for class_name in class_names:
        true_positive_mask = true_array == class_name
        predicted_positive_mask = predicted_array == class_name
        tp = int(np.sum(true_positive_mask & predicted_positive_mask))
        fp = int(np.sum(~true_positive_mask & predicted_positive_mask))
        fn = int(np.sum(true_positive_mask & ~predicted_positive_mask))
        tn = int(number - tp - fp - fn)
        binary_true = true_positive_mask.astype(np.int64)
        binary_predicted = predicted_positive_mask.astype(np.int64)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
        rows.append({
            class_column: class_name,
            "split": split,
            "sequence_level": sequence_level,
            "ACC": (tp + tn) / number if number else 0.0,
            "Precision": precision,
            "Recall": recall,
            "F1": f1,
            "MCC": safe_mcc(binary_true, binary_predicted),
            "support": int(tp + fn),
            "predicted_count": int(tp + fp),
            "correct_count": tp,
            "wrong_count": int(fp + fn),
            "TP": tp,
            "FP": fp,
            "FN": fn,
            "TN": tn,
            "total_samples": number,
            "coverage": 1.0,
        })
    return rows


def build_separate_level_metric_tables(
    fragment_rows: list[dict[str, Any]],
    original_rows: list[dict[str, Any]],
    data: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    subtype_rows: list[dict[str, Any]] = []
    type_rows: list[dict[str, Any]] = []
    binary_rows: list[dict[str, Any]] = []
    for sequence_level, source_rows in (
        ("fragment", fragment_rows),
        ("original", original_rows),
    ):
        for split in ("train", "validation", "test"):
            selected = [row for row in source_rows if row["split"] == split]
            true_subtype = [row["true_subtype"] for row in selected]
            predicted_subtype = [row["predicted_subtype"] for row in selected]
            subtype_rows.extend(
                one_vs_rest_class_metrics(
                    true_subtype,
                    predicted_subtype,
                    data["arg_names"],
                    "Subtype",
                    split,
                    sequence_level,
                )
            )

            mapping = data["subtype_to_type"]
            true_type = [mapping[value] for value in true_subtype]
            predicted_type = [mapping[value] for value in predicted_subtype]
            type_rows.extend(
                one_vs_rest_class_metrics(
                    true_type,
                    predicted_type,
                    data["type_names"],
                    "Type",
                    split,
                    sequence_level,
                )
            )

            true_binary = [
                NONARG_CANONICAL if value.lower() == "nonarg" else "ARG"
                for value in true_subtype
            ]
            predicted_binary = [
                NONARG_CANONICAL if value.lower() == "nonarg" else "ARG"
                for value in predicted_subtype
            ]
            binary_rows.extend(
                one_vs_rest_class_metrics(
                    true_binary,
                    predicted_binary,
                    ["ARG", NONARG_CANONICAL],
                    "Class",
                    split,
                    sequence_level,
                )
            )
    return subtype_rows, type_rows, binary_rows


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    return value


def main() -> None:
    args = parse_args()
    validate_paths(args)
    config = Config(
        seed=args.seed,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        teacher_epochs=args.teacher_epochs,
        student_epochs=args.student_epochs,
    )
    set_seed(config.seed)
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU is unavailable. "
            "CPU fallback is disabled for this ARGScope training script."
        )

    device = torch.device("cuda:0")
    use_amp = not args.no_amp
    started = time.time()

    print("=" * 120, flush=True)
    print("ARG1:nonARG10 DNA-only hierarchical student from gated fusion and refined ARG prototypes", flush=True)
    print("=" * 120, flush=True)
    print(f"Script version : {SCRIPT_VERSION}", flush=True)
    print(f"DNA PT         : {args.dna_pt}", flush=True)
    print(f"Fusion PT      : {args.fusion_pt}", flush=True)
    print(f"Refined PT     : {args.refined_pt}", flush=True)
    print(f"Structure      : {args.structure}", flush=True)
    print(f"Output dir     : {args.output_dir}", flush=True)
    print("Dataset ratio  : ARG:nonARG = 1:10", flush=True)
    print("DNA input      : DNABERT-2 first_token_CLS, 768D", flush=True)
    print("Teacher input  : supervised gated fusion, 512D", flush=True)
    print("Prototype prior: residual-GAT refined ARG prototypes, 512D", flush=True)
    print(f"Device         : {device}", flush=True)
    print(f"AMP            : {use_amp}", flush=True)
    print(f"GPU            : {torch.cuda.get_device_name(0)}", flush=True)
    print(f"CUDA version   : {torch.version.cuda}", flush=True)
    print("CPU fallback   : disabled", flush=True)
    print(
        f"GPU total mem  : "
        f"{torch.cuda.get_device_properties(0).total_memory/(1024**3):.2f} GiB",
        flush=True,
    )

    data = load_and_align_data(
        args.dna_pt, args.fusion_pt, args.refined_pt, args.structure
    )
    if config.embedding_dim != data["fusion"].shape[1]:
        raise ValueError("Config embedding dimension must equal fusion dimension")

    torch.cuda.empty_cache()
    print(
        f"GPU memory before training: "
        f"allocated={torch.cuda.memory_allocated(0)/(1024**3):.3f} GiB, "
        f"reserved={torch.cuda.memory_reserved(0)/(1024**3):.3f} GiB",
        flush=True,
    )

    teacher, teacher_history, teacher_best_epoch, teacher_best_score = train_teacher(
        data, config, device, use_amp
    )
    torch.cuda.empty_cache()
    print(
        f"GPU memory after teacher : "
        f"allocated={torch.cuda.memory_allocated(0)/(1024**3):.3f} GiB, "
        f"reserved={torch.cuda.memory_reserved(0)/(1024**3):.3f} GiB",
        flush=True,
    )

    student, student_history, student_best_epoch, student_best_score, dna_mean, dna_std = train_student(
        teacher, data, config, device, use_amp
    )

    torch.cuda.empty_cache()
    print(
        f"GPU memory after student : "
        f"allocated={torch.cuda.memory_allocated(0)/(1024**3):.3f} GiB, "
        f"reserved={torch.cuda.memory_reserved(0)/(1024**3):.3f} GiB",
        flush=True,
    )

    binary_threshold, threshold_rows = select_binary_threshold_on_validation(
        student, data["dna"], data, config, device, use_amp
    )

    # Test is first touched here, after both teacher and student selection.
    all_metrics = {}
    all_fragment_rows = []
    all_original_rows = []
    for split in ("train", "validation", "test"):
        metrics, fragment_rows, original_rows = evaluate_split(
            student, split, data, config, device, use_amp, binary_threshold
        )
        all_metrics[split] = metrics
        all_fragment_rows.extend(fragment_rows)
        all_original_rows.extend(original_rows)
        print(f"\n===== DNA-ONLY {split.upper()} RESULTS =====", flush=True)
        for level in ("fragment", "original"):
            full = metrics[level]["end_to_end_485_class"]
            binary = metrics[level]["binary"]
            subtype = metrics[level]["ARG_subtype_oracle_binary"]
            print(
                f"{level:8s} | end-to-end ACC={full['accuracy']:.6f}, "
                f"weighted_precision={full['weighted_precision']:.6f}, "
                f"macro_precision={full['macro_precision']:.6f}, MCC={full['mcc']:.6f} | "
                f"binary weighted_precision={binary['weighted_precision']:.6f} | "
                f"ARG subtype weighted_precision={subtype['weighted_precision']:.6f}",
                flush=True,
            )

    subtype_level_rows, type_level_rows, binary_level_rows = build_separate_level_metric_tables(
        all_fragment_rows, all_original_rows, data
    )
    overall_rows = []
    for split, split_metrics in all_metrics.items():
        for sequence_level, level_metrics in split_metrics.items():
            for task, values in level_metrics.items():
                overall_rows.append({
                    "split": split,
                    "sequence_level": sequence_level,
                    "task": task,
                    **values,
                    "coverage": 1.0,
                })

    checkpoint = {
        "model_name": "DNA-only hierarchical fusion-teacher refined-prototype student",
        "script_version": SCRIPT_VERSION,
        "ARG_nonARG_training_ratio": "1:10",
        "DNA_embedding_definition": (
            "DNABERT-2-117M native BPE; final hidden state first token/CLS; "
            "768 dimensions; max_token_length=512"
        ),
        "student_state_dict": {key: value.detach().cpu() for key, value in student.state_dict().items()},
        "teacher_state_dict": {key: value.detach().cpu() for key, value in teacher.state_dict().items()},
        "dna_input_dimension": int(data["dna"].shape[1]),
        "embedding_dimension": int(config.embedding_dim),
        "arg_subtype_names": data["arg_names"],
        "full_class_names": [NONARG_CANONICAL] + data["arg_names"],
        "nonARG_class_index": 0,
        "selected_binary_ARG_probability_threshold": float(binary_threshold),
        "refined_ARG_subtype_prototypes": data["refined"],
        "dna_train_mean": dna_mean,
        "dna_train_std": dna_std,
        "teacher_best_epoch": int(teacher_best_epoch),
        "teacher_best_validation_score": float(teacher_best_score),
        "student_best_epoch": int(student_best_epoch),
        "student_best_validation_score": float(student_best_score),
        "metrics": all_metrics,
        "configuration": asdict(config),
        "inference_rule": (
            "DNA embedding -> DNA student; binary head predicts nonARG/ARG; "
            "if ARG, ARG subtype cosine head predicts one of 484 ARG subtypes"
        ),
        "training_rule": (
            "train optimizes teacher/student; validation selects epochs; "
            "test evaluated once after selection; inference uses DNA only"
        ),
        "source_DNA_pt": str(args.dna_pt),
        "source_fusion_pt": str(args.fusion_pt),
        "source_refined_pt": str(args.refined_pt),
        "source_structure": str(args.structure),
    }
    checkpoint_path = (
        args.output_dir
        / "DNA_student_fusion_refined_model.pt"
    )

    temporary = checkpoint_path.with_suffix(
        ".pt.tmp"
    )

    with temporary.open("wb") as handle:
        torch.save(
            checkpoint,
            handle,
        )
        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temporary,
        checkpoint_path,
    )
    write_csv(args.output_dir / "training_history.csv", teacher_history + student_history)
    write_csv(args.output_dir / "fragment_predictions.csv", all_fragment_rows)
    write_csv(args.output_dir / "original_predictions.csv", all_original_rows)
    write_csv(args.output_dir / "binary_ARG_threshold_validation_sweep.csv", threshold_rows)
    write_csv(args.output_dir / "overall_metrics.csv", overall_rows)
    write_csv(args.output_dir / "subtype_level_metrics.csv", subtype_level_rows)
    write_csv(args.output_dir / "type_level_metrics.csv", type_level_rows)
    write_csv(args.output_dir / "ARG_nonARG_level_metrics.csv", binary_level_rows)
    with (args.output_dir / "metrics.json").open("w", encoding="utf-8") as handle:
        json.dump(json_safe(all_metrics), handle, ensure_ascii=False, indent=2)

    print("\n" + "=" * 120, flush=True)
    print("DNA STUDENT TRAINING COMPLETED", flush=True)
    print("=" * 120, flush=True)
    print(f"Teacher best epoch : {teacher_best_epoch}", flush=True)
    print(f"Student best epoch : {student_best_epoch}", flush=True)
    print(f"Binary ARG threshold: {binary_threshold:.2f} (validation selected)", flush=True)
    print(f"Model checkpoint   : {checkpoint_path}", flush=True)
    print(f"Subtype metrics    : {args.output_dir / 'subtype_level_metrics.csv'}", flush=True)
    print(f"Type metrics       : {args.output_dir / 'type_level_metrics.csv'}", flush=True)
    print(f"ARG/nonARG metrics : {args.output_dir / 'ARG_nonARG_level_metrics.csv'}", flush=True)
    print(
        f"Peak GPU memory    : "
        f"{torch.cuda.max_memory_allocated(0)/(1024**3):.3f} GiB",
        flush=True,
    )
    print(f"Elapsed minutes    : {(time.time() - started) / 60.0:.3f}", flush=True)


if __name__ == "__main__":
    main()
