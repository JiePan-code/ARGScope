#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Protein + DNA type-level radial bar comparisons for partial sequences.

This script generates exactly EIGHT independent figures:
    Protein_60_radial_comparison_fixed
    Protein_70_radial_comparison_fixed
    Protein_80_radial_comparison_fixed
    Protein_90_radial_comparison_fixed
    DNA_60_radial_comparison_fixed
    DNA_70_radial_comparison_fixed
    DNA_80_radial_comparison_fixed
    DNA_90_radial_comparison_fixed

Visual style follows the previous 100% radial comparison:
- no figure title
- model identity encoded by fill color
- one figure per completeness level, so no hatch legend is needed
- five metric groups: Accuracy, Precision, Recall, F1-score, MCC
- 600-dpi PNG/TIF plus vector PDF/SVG

Expected simplified CSV content (example):
    ,Class,ACC,Precision,Recall,F1,MCC
    Long AA,Type,...
    60%,Type,...
    70%,Type,...
    80%,Type,...
    90%,Type,...

The script searches recursively below its own directory for *longaa*.csv and
*longnt*.csv files and identifies model names from folder/file names.
"""

from __future__ import annotations

from pathlib import Path
import math
import re

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch


# =============================================================================
# 1) Paths and data definition
# =============================================================================
SCRIPT_DIR = Path(__file__).resolve().parent
OUTDIR = SCRIPT_DIR / "Protein_DNA_60_90_radial_comparison_FIXED_8fig"
OUTDIR.mkdir(parents=True, exist_ok=True)

SEARCH_PATTERNS = {
    "Protein": [
        "**/*longaa.csv",
        "**/*LongAA*.csv",
        "**/*long_aa*.csv",
    ],
    "DNA": [
        "**/*longnt.csv",
        "**/*LongNT*.csv",
        "**/*long_nt*.csv",
    ],
}

MODEL_ORDER = {
    "Protein": ["PLM-ARG", "ARGNet", "DeepARG", "Fungenetyper", "ARGScope"],
    "DNA": ["ARGNet", "DeepARG", "Fungenetyper", "ARGScope"],
}

REQUIRED_MODELS = {
    "Protein": ["PLM-ARG", "ARGNet", "DeepARG", "Fungenetyper", "ARGScope"],
    "DNA": ["ARGNet", "DeepARG", "ARGScope"],
}

MODEL_COLORS = {
    "ARGNet": "#4C84C4",
    "DeepARG": "#7DB7E8",
    "Fungenetyper": "#C9DEF1",
    "PLM-ARG": "#F4F4F4",
    "ARGScope": "#1F5AA6",
}

CONDITIONS = ["60%", "70%", "80%", "90%"]

METRIC_ORDER = ["Accuracy", "Precision", "Recall", "F1-score", "MCC"]
METRIC_COLUMN_MAP = {
    "Accuracy": ["ACC", "Accuracy", "accuracy", "acc"],
    "Precision": ["Precision", "precision", "weighted_precision", "weightedprecision"],
    "Recall": ["Recall", "recall", "weighted_recall", "weightedrecall"],
    "F1-score": ["F1", "f1", "F1-score", "f1-score", "weighted_f1", "weightedf1"],
    "MCC": ["MCC", "mcc", "matthews_correlation_coefficient"],
}

CLASS_COLUMN_CANDIDATES = ["Class", "class", "Level", "level", "Task", "task"]


# =============================================================================
# 2) Output / style settings
# =============================================================================
FIGSIZE = (7.2, 7.2)
DPI = 600
SAVE_TRANSPARENT = True
SAVE_PNG = True
SAVE_TIF = True
SAVE_PDF = True
SAVE_SVG = True

FONT_FAMILY = "Arial"
TITLE = ""
METRIC_LABEL_SIZE = 12
RADIAL_TICK_SIZE = 8.5
LEGEND_SIZE = 9

VISUAL_INNER_RADIUS = 0.55
VISUAL_OUTER_RADIUS = 1.18
BAR_SLOT_WIDTH = 0.20
GROUP_GAP = 0.55
BAR_WIDTH_SCALE = 0.82
BAR_EDGE_COLOR = "#4A4A4A"
BAR_EDGE_WIDTH = 0.8

VALUE_MAX = 1.00
AUTO_PAD = 0.02
MIN_ALLOWED = 0.00
MAX_TICKS = 8


# =============================================================================
# 3) Utilities
# =============================================================================
def normalized_name(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(text).lower())


def infer_model_name(path: Path) -> str | None:
    token = normalized_name(str(path))

    if "argscope" in token:
        return "ARGScope"
    if "plmarg" in token:
        return "PLM-ARG"
    if "fungenetyper" in token or "fungentyper" in token or "fungenetype" in token:
        return "Fungenetyper"
    if "deeparg" in token:
        return "DeepARG"
    if "argnet" in token:
        return "ARGNet"
    return None


def canonical_filename(modality: str, model: str) -> str:
    suffix = "longaa" if modality == "Protein" else "longnt"
    prefixes = {
        "ARGNet": "argnet",
        "DeepARG": "deeparg",
        "Fungenetyper": "fungenetyper",
        "PLM-ARG": "plmarg",
        "ARGScope": "argscope",
    }
    return f"{prefixes[model]}_{suffix}.csv"


def collect_input_files(modality: str) -> dict[str, Path]:
    hits: list[Path] = []
    for pattern in SEARCH_PATTERNS[modality]:
        hits.extend(SCRIPT_DIR.glob(pattern))

    hits = sorted(
        set(
            p for p in hits
            if p.is_file() and OUTDIR not in p.parents
        )
    )

    candidates: dict[str, list[Path]] = {}
    for path in hits:
        model = infer_model_name(path)
        if model is None:
            continue
        if modality == "DNA" and model == "PLM-ARG":
            continue
        candidates.setdefault(model, []).append(path)

    file_map: dict[str, Path] = {}
    for model, paths in candidates.items():
        canonical = canonical_filename(modality, model)

        def score(path: Path) -> tuple[int, int, int]:
            name = path.name.lower()
            exact = int(name == canonical)
            contains = int(normalized_name(canonical[:-4]) in normalized_name(path.stem))
            shortness = -len(str(path))
            return (exact, contains, shortness)

        file_map[model] = max(paths, key=score)

    return file_map


def find_metric_column(df: pd.DataFrame, candidate_names: list[str]) -> str:
    lower_map = {str(c).strip().lower(): c for c in df.columns}
    normalized_map = {normalized_name(c): c for c in df.columns}

    for name in candidate_names:
        key = name.strip().lower()
        if key in lower_map:
            return str(lower_map[key])
        norm = normalized_name(name)
        if norm in normalized_map:
            return str(normalized_map[norm])

    raise KeyError(
        f"Cannot find metric column among {candidate_names}. "
        f"Available columns: {list(df.columns)}"
    )


def find_class_column(df: pd.DataFrame) -> str | None:
    lower_map = {str(c).strip().lower(): c for c in df.columns}
    for name in CLASS_COLUMN_CANDIDATES:
        key = name.lower()
        if key in lower_map:
            return str(lower_map[key])
    return None


def filter_type_rows(df: pd.DataFrame) -> pd.DataFrame:
    class_col = find_class_column(df)
    if class_col is None:
        return df

    text = df[class_col].astype(str).str.strip().str.lower()
    type_mask = text.isin({"type", "type_level", "type-level", "arg type", "arg_type"})
    if bool(type_mask.any()):
        return df.loc[type_mask].copy()
    return df


def parse_condition(value) -> str | None:
    text = str(value).strip().lower()
    if not text or text == "nan":
        return None

    compact = normalized_name(text)

    for number in ("60", "70", "80", "90"):
        if re.search(rf"(?<!\d){number}\s*%(?!\d)", text):
            return f"{number}%"
        if compact in {number, f"{number}p", f"{number}pct", f"{number}percent", f"pct{number}", f"percent{number}"}:
            return f"{number}%"
        if compact.startswith(f"{number}pct") or compact.startswith(f"{number}percent"):
            return f"{number}%"
        if compact.startswith(f"pct{number}") or compact.startswith(f"percent{number}"):
            return f"{number}%"

    return None


def detect_condition_column(df: pd.DataFrame, metric_cols: dict[str, str]) -> str:
    excluded = set(metric_cols.values())
    class_col = find_class_column(df)
    if class_col is not None:
        excluded.add(class_col)

    for col in df.columns:
        if col in excluded:
            continue
        key = normalized_name(col)
        if key.startswith("unnamed") or key in {"dataset", "condition", "length", "completeness", "percent", "coverage"}:
            values = df[col].astype(str).tolist()
            if any(parse_condition(v) is not None for v in values):
                return str(col)

    for col in df.columns:
        if col in excluded:
            continue
        values = df[col].astype(str).tolist()
        if any(parse_condition(v) is not None for v in values):
            return str(col)

    raise ValueError(
        "Could not identify the completeness/condition column. "
        f"Columns={list(df.columns)}"
    )


def load_model_conditions(path: Path, model_name: str, modality: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.dropna(axis=0, how="all").copy()
    df = filter_type_rows(df)

    metric_cols = {
        metric: find_metric_column(df, METRIC_COLUMN_MAP[metric])
        for metric in METRIC_ORDER
    }
    condition_col = detect_condition_column(df, metric_cols)

    rows = []
    for _, row in df.iterrows():
        condition = parse_condition(row[condition_col])
        if condition not in set(CONDITIONS):
            continue

        record = {
            "Modality": modality,
            "Model": model_name,
            "Condition": condition,
            "File": str(path),
        }

        valid = True
        for metric in METRIC_ORDER:
            try:
                value = float(row[metric_cols[metric]])
            except Exception:
                valid = False
                break
            if not np.isfinite(value):
                valid = False
                break
            record[metric] = value

        if valid:
            rows.append(record)

    out = pd.DataFrame(rows)
    if out.empty:
        raise ValueError(f"No usable 60/70/80/90 Type-level rows found in: {path}")

    duplicates = out["Condition"].duplicated(keep=False)
    if duplicates.any():
        dup_conditions = out.loc[duplicates, "Condition"].tolist()
        raise ValueError(
            f"Duplicate completeness rows in {path}: {dup_conditions}. "
            "Please keep one Type-level row per completeness."
        )

    return out


def choose_tick_step(vmin: float, vmax: float) -> float:
    span = vmax - vmin
    if span <= 0.06:
        return 0.01
    if span <= 0.12:
        return 0.02
    if span <= 0.25:
        return 0.05
    return 0.10


def compute_scale_bounds(values: np.ndarray) -> tuple[float, np.ndarray]:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return 0.0, np.arange(0.0, 1.01, 0.2)

    actual_min = float(np.min(finite))
    proposed_min = actual_min - AUTO_PAD
    step = choose_tick_step(proposed_min, VALUE_MAX)
    scale_min = math.floor(proposed_min / step) * step
    scale_min = min(scale_min, actual_min)
    scale_min = max(MIN_ALLOWED, scale_min) if actual_min >= MIN_ALLOWED else scale_min
    scale_min = round(scale_min, 3)

    ticks = np.arange(scale_min, VALUE_MAX + step * 0.5, step)
    while len(ticks) > MAX_TICKS:
        step *= 2
        ticks = np.arange(scale_min, VALUE_MAX + step * 0.5, step)

    return scale_min, np.round(ticks, 3)


def map_value_to_radius(value: float, scale_min: float) -> float:
    if VALUE_MAX <= scale_min:
        return VISUAL_OUTER_RADIUS
    frac = (value - scale_min) / (VALUE_MAX - scale_min)
    frac = max(0.0, min(1.0, frac))
    return VISUAL_INNER_RADIUS + frac * (VISUAL_OUTER_RADIUS - VISUAL_INNER_RADIUS)


# =============================================================================
# 4) Data collection
# =============================================================================
def collect_modality_data(modality: str) -> tuple[pd.DataFrame, list[str]]:
    file_map = collect_input_files(modality)

    print("\n" + "=" * 104)
    print(f"{modality} input discovery")
    print("=" * 104)
    for model in MODEL_ORDER[modality]:
        print(f"  {model:13s}: {file_map.get(model, 'NOT FOUND')}")

    missing_required = [model for model in REQUIRED_MODELS[modality] if model not in file_map]
    if missing_required:
        raise FileNotFoundError(
            f"Missing required {modality} model CSV(s): " + ", ".join(missing_required)
        )

    active_models = [model for model in MODEL_ORDER[modality] if model in file_map]

    frames = [load_model_conditions(file_map[model], model, modality) for model in active_models]
    data = pd.concat(frames, ignore_index=True)

    expected = set(CONDITIONS)
    for model in active_models:
        available = set(data.loc[data["Model"] == model, "Condition"])
        missing = sorted(expected - available)
        if missing:
            raise ValueError(f"{modality}/{model} is missing conditions: {missing}")

    return data, active_models


# =============================================================================
# 5) Plotting
# =============================================================================
def make_single_condition_plot(
    data: pd.DataFrame,
    modality: str,
    models: list[str],
    condition: str,
    scale_min: float,
    tick_values: np.ndarray,
    out_prefix: Path,
) -> None:
    tick_radii = [map_value_to_radius(float(v), scale_min) for v in tick_values]

    n_metrics = len(METRIC_ORDER)
    n_models = len(models)

    total_units = n_metrics * (n_models * BAR_SLOT_WIDTH + GROUP_GAP)
    unit_angle = 2 * np.pi / total_units
    actual_bar_width = BAR_SLOT_WIDTH * unit_angle * BAR_WIDTH_SCALE

    theta_list: list[float] = []
    height_list: list[float] = []
    color_list: list[str] = []
    metric_centers: list[float] = []

    current_unit = 0.0
    for metric in METRIC_ORDER:
        group_thetas = []
        for model in models:
            selected = data[(data["Model"] == model) & (data["Condition"] == condition)]
            if len(selected) != 1:
                raise RuntimeError(
                    f"Expected one row for {modality}/{model}/{condition}; found {len(selected)}"
                )

            value = float(selected.iloc[0][metric])
            center_unit = current_unit + BAR_SLOT_WIDTH / 2.0
            theta = center_unit * unit_angle
            radius_value = map_value_to_radius(value, scale_min)

            theta_list.append(theta)
            height_list.append(radius_value - VISUAL_INNER_RADIUS)
            color_list.append(MODEL_COLORS[model])
            group_thetas.append(theta)

            current_unit += BAR_SLOT_WIDTH

        metric_centers.append(float(np.mean(group_thetas)))
        current_unit += GROUP_GAP

    fig = plt.figure(figsize=FIGSIZE)
    fig.patch.set_alpha(0 if SAVE_TRANSPARENT else 1)
    ax = plt.subplot(111, polar=True)
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, VISUAL_OUTER_RADIUS + 0.18)

    ax.bar(
        theta_list,
        height_list,
        width=actual_bar_width,
        bottom=VISUAL_INNER_RADIUS,
        color=color_list,
        edgecolor=BAR_EDGE_COLOR,
        linewidth=BAR_EDGE_WIDTH,
        align="center",
        zorder=3,
    )

    ax.set_yticks(tick_radii)
    ax.set_yticklabels([f"{float(v):.3f}" for v in tick_values], fontsize=RADIAL_TICK_SIZE)
    ax.set_rlabel_position(0)
    ax.yaxis.grid(True, color="#D7D7D7", linewidth=0.85)
    ax.xaxis.grid(True, color="#E4E4E4", linewidth=0.85)
    ax.set_xticks([])

    center_circle = plt.Circle(
        (0.5, 0.5),
        0.18,
        transform=ax.transAxes,
        facecolor=(1, 1, 1, 0 if SAVE_TRANSPARENT else 1),
        edgecolor="#D8D8D8",
        linewidth=0.8,
        zorder=4,
    )
    ax.add_artist(center_circle)

    label_radius = VISUAL_OUTER_RADIUS + 0.11
    for theta, metric in zip(metric_centers, METRIC_ORDER):
        ax.text(theta, label_radius, metric, ha="center", va="center", fontsize=METRIC_LABEL_SIZE)

    if TITLE:
        ax.set_title(TITLE, pad=20)

    handles = [
        Patch(facecolor=MODEL_COLORS[model], edgecolor=BAR_EDGE_COLOR, linewidth=0.8, label=model)
        for model in models
    ]
    ax.legend(
        handles=handles,
        loc="center left",
        bbox_to_anchor=(1.02, 0.28),
        frameon=True,
        facecolor=(1, 1, 1, 0.92),
        edgecolor="#D0D0D0",
        fontsize=LEGEND_SIZE,
        borderpad=0.35,
        labelspacing=0.25,
        handlelength=1.35,
        handletextpad=0.45,
    )

    plt.tight_layout()

    if SAVE_PNG:
        fig.savefig(out_prefix.with_suffix(".png"), dpi=DPI, transparent=SAVE_TRANSPARENT)
    if SAVE_TIF:
        fig.savefig(out_prefix.with_suffix(".tif"), dpi=DPI, transparent=SAVE_TRANSPARENT)
    if SAVE_PDF:
        fig.savefig(out_prefix.with_suffix(".pdf"), transparent=SAVE_TRANSPARENT)
    if SAVE_SVG:
        fig.savefig(out_prefix.with_suffix(".svg"), transparent=SAVE_TRANSPARENT)

    plt.close(fig)


def export_scale_info(modality: str, scale_min: float, tick_values: np.ndarray) -> None:
    lines = [
        f"Modality: {modality}",
        f"Shared radial scale min for 60%-90%: {scale_min:.3f}",
        "Tick values: " + ", ".join(f"{float(v):.3f}" for v in tick_values),
    ]
    (OUTDIR / f"{modality}_radial_scale_info.txt").write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# 6) Main
# =============================================================================
def main() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [FONT_FAMILY, "DejaVu Sans", "Liberation Sans"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "axes.unicode_minus": False,
            "savefig.facecolor": "none" if SAVE_TRANSPARENT else "white",
            "savefig.edgecolor": "none" if SAVE_TRANSPARENT else "white",
        }
    )

    print("=" * 104)
    print("Protein + DNA 60/70/80/90 radial comparison (8 figures)")
    print("=" * 104)
    print("Search root:", SCRIPT_DIR)
    print("Output dir :", OUTDIR)

    all_frames = []

    for modality in ("Protein", "DNA"):
        data, active_models = collect_modality_data(modality)
        all_frames.append(data)

        values = data[METRIC_ORDER].to_numpy(dtype=float)
        scale_min, tick_values = compute_scale_bounds(values)
        export_scale_info(modality, scale_min, tick_values)

        print(f"\n[{modality}] active models: {active_models}")
        print(f"[{modality}] shared scale min: {scale_min:.3f}")
        print(f"[{modality}] ticks: " + ", ".join(f"{float(v):.3f}" for v in tick_values))

        for condition in CONDITIONS:
            tag = condition.replace("%", "")
            out_prefix = OUTDIR / f"{modality}_{tag}_radial_comparison_fixed"
            make_single_condition_plot(
                data=data,
                modality=modality,
                models=active_models,
                condition=condition,
                scale_min=scale_min,
                tick_values=tick_values,
                out_prefix=out_prefix,
            )
            print(f"[SAVE] {modality} {condition} -> {out_prefix.name}.png/.tif/.pdf/.svg")

    full_summary = pd.concat(all_frames, ignore_index=True)

    modality_rank = {"Protein": 0, "DNA": 1}
    condition_rank = {"60%": 0, "70%": 1, "80%": 2, "90%": 3}
    model_rank = {
        modality: {model: i for i, model in enumerate(MODEL_ORDER[modality])}
        for modality in MODEL_ORDER
    }

    full_summary["_modality_rank"] = full_summary["Modality"].map(modality_rank)
    full_summary["_model_rank"] = full_summary.apply(
        lambda row: model_rank[row["Modality"]][row["Model"]], axis=1
    )
    full_summary["_condition_rank"] = full_summary["Condition"].map(condition_rank)

    full_summary = full_summary.sort_values(
        ["_modality_rank", "_model_rank", "_condition_rank"]
    ).drop(columns=["_modality_rank", "_model_rank", "_condition_rank"])

    summary_path = OUTDIR / "Protein_DNA_60_90_radial_plot_data.csv"
    full_summary.to_csv(summary_path, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 104)
    print("Exactly eight figures have been generated:")
    for modality in ("Protein", "DNA"):
        for condition in CONDITIONS:
            print(f"  {modality}_{condition.replace('%', '')}_radial_comparison_fixed")
    print("Plot data:", summary_path)
    print("Done.")


if __name__ == "__main__":
    main()
