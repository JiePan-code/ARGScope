import pandas as pd
import numpy as np


def split_for_novel_subtype_within_known_type(
    file_path,
    type_col="Type",
    subtype_col="Subtype",
    test_ratio=0.3,
    random_state=42,
    train_output="train_set_type.csv",
    test_output="test_set_type.csv",
    stats_output="type_subtype_split_statistics.csv",
    subtype_status_output="subtype_holdout_status.csv"
):
    # =========================
    # 1. 读取数据
    # =========================
    df = pd.read_csv(file_path).copy()
    df = df.reset_index(drop=True)

    required_cols = [type_col, subtype_col]
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"数据中未找到必要列: {col}")

    if len(df) == 0:
        raise ValueError("输入数据为空。")

    df[type_col] = df[type_col].astype(str).str.strip()
    df[subtype_col] = df[subtype_col].astype(str).str.strip()

    # 保留原始行号，用于严格检查 train/test 是否有重复
    df["_original_index"] = df.index

    rng = np.random.default_rng(random_state)

    train_parts = []
    test_parts = []
    type_stats = []
    subtype_status_rows = []

    # =========================
    # 2. 按 Type 逐个处理
    # =========================
    for type_name, type_df in df.groupby(type_col, sort=False):
        type_df = type_df.copy()
        n_type = len(type_df)

        subtype_counts = type_df[subtype_col].value_counts()
        subtype_list = subtype_counts.index.astype(str).tolist()
        n_subtypes = len(subtype_list)

        # =====================================================
        # 规则 1：
        # Type 样本数 = 1
        # 只放入 train，不进入 test
        # =====================================================
        if n_type == 1:
            train_sub = type_df.copy()
            test_sub = type_df.iloc[0:0].copy()

            split_mode = "type_single_sample_train_only"
            novel_subtype_eval = False

            subtype_status_rows.append({
                "Type": type_name,
                "Subtype": subtype_list[0],
                "Subtype_count": int(subtype_counts.iloc[0]),
                "Assigned_split": "train",
                "Split_mode": split_mode,
                "Novel_subtype_eval": novel_subtype_eval
            })

        # =====================================================
        # 规则 2：
        # Type 样本数 >= 2，但 Type 内只有 1 个 Subtype
        # 做普通 Type 分类测试，不能算 novel subtype 测试
        # =====================================================
        elif n_subtypes == 1:
            shuffled = type_df.sample(frac=1, random_state=random_state).reset_index(drop=True)

            n_test = int(round(n_type * test_ratio))
            n_test = max(1, n_test)
            n_test = min(n_test, n_type - 1)
            n_train = n_type - n_test

            train_sub = shuffled.iloc[:n_train].copy()
            test_sub = shuffled.iloc[n_train:].copy()

            split_mode = "ordinary_type_split_single_subtype"
            novel_subtype_eval = False

            subtype_status_rows.append({
                "Type": type_name,
                "Subtype": subtype_list[0],
                "Subtype_count": int(subtype_counts.iloc[0]),
                "Assigned_split": "train_and_test",
                "Split_mode": split_mode,
                "Novel_subtype_eval": novel_subtype_eval
            })

        # =====================================================
        # 规则 3：
        # Type 内 Subtype 数 >= 2
        # 按 Subtype/gene family 做 holdout
        # test 中的 subtype 不在 train 中出现
        # =====================================================
        else:
            subtype_array = np.array(subtype_list, dtype=object)
            rng.shuffle(subtype_array)

            n_test_subtypes = int(round(n_subtypes * test_ratio))
            n_test_subtypes = max(1, n_test_subtypes)
            n_test_subtypes = min(n_test_subtypes, n_subtypes - 1)

            test_subtypes = set(subtype_array[:n_test_subtypes].tolist())
            train_subtypes = set(subtype_array[n_test_subtypes:].tolist())

            train_sub = type_df[type_df[subtype_col].isin(train_subtypes)].copy()
            test_sub = type_df[type_df[subtype_col].isin(test_subtypes)].copy()

            # 理论上不会发生，但做保护
            if len(train_sub) == 0 or len(test_sub) == 0:
                shuffled = type_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
                n_test = int(round(n_type * test_ratio))
                n_test = max(1, n_test)
                n_test = min(n_test, n_type - 1)
                n_train = n_type - n_test

                train_sub = shuffled.iloc[:n_train].copy()
                test_sub = shuffled.iloc[n_train:].copy()

                split_mode = "fallback_sample_split"
                novel_subtype_eval = False

                for st, cnt in subtype_counts.items():
                    subtype_status_rows.append({
                        "Type": type_name,
                        "Subtype": st,
                        "Subtype_count": int(cnt),
                        "Assigned_split": "fallback_train_or_test",
                        "Split_mode": split_mode,
                        "Novel_subtype_eval": novel_subtype_eval
                    })
            else:
                split_mode = "novel_subtype_holdout_within_known_type"
                novel_subtype_eval = True

                for st, cnt in subtype_counts.items():
                    assigned = "test_novel_subtype" if st in test_subtypes else "train_known_subtype"

                    subtype_status_rows.append({
                        "Type": type_name,
                        "Subtype": st,
                        "Subtype_count": int(cnt),
                        "Assigned_split": assigned,
                        "Split_mode": split_mode,
                        "Novel_subtype_eval": novel_subtype_eval
                    })

        train_parts.append(train_sub)

        if len(test_sub) > 0:
            test_parts.append(test_sub)

        type_stats.append({
            "Type": type_name,
            "Total_count": int(n_type),
            "Subtype_count": int(n_subtypes),
            "Train_count": int(len(train_sub)),
            "Test_count": int(len(test_sub)),
            "Train_ratio": float(len(train_sub) / n_type),
            "Test_ratio": float(len(test_sub) / n_type),
            "Split_mode": split_mode,
            "Novel_subtype_eval": bool(novel_subtype_eval)
        })

    # =========================
    # 3. 合并 train/test
    # =========================
    train_df = pd.concat(train_parts, ignore_index=True)

    if len(test_parts) > 0:
        test_df = pd.concat(test_parts, ignore_index=True)
    else:
        raise RuntimeError("test 集为空。请检查是否所有 Type 都只有 1 条样本。")

    train_df = train_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
    test_df = test_df.sample(frac=1, random_state=random_state).reset_index(drop=True)

    # =========================
    # 4. 严格检查 train/test 不重复
    # =========================
    train_original_ids = set(train_df["_original_index"].tolist())
    test_original_ids = set(test_df["_original_index"].tolist())
    overlap_ids = train_original_ids & test_original_ids

    if len(overlap_ids) > 0:
        raise RuntimeError(
            f"错误：Train/Test 存在重复原始样本数: {len(overlap_ids)}。"
        )

    # =========================
    # 5. 检查 Type 覆盖
    # =========================
    all_types = set(df[type_col].astype(str).unique())
    train_types = set(train_df[type_col].astype(str).unique())
    test_types = set(test_df[type_col].astype(str).unique())

    type_counts = df[type_col].value_counts()
    single_sample_types = set(type_counts[type_counts == 1].index.astype(str))
    multi_sample_types = set(type_counts[type_counts >= 2].index.astype(str))

    missing_train_types = sorted(all_types - train_types)
    missing_test_multi_types = sorted(multi_sample_types - test_types)

    if len(missing_train_types) > 0:
        raise RuntimeError(
            "错误：以下 Type 没有出现在 train 中：\n"
            + "\n".join(map(str, missing_train_types[:50]))
        )

    if len(missing_test_multi_types) > 0:
        raise RuntimeError(
            "错误：以下样本数 >= 2 的 Type 没有出现在 test 中：\n"
            + "\n".join(map(str, missing_test_multi_types[:50]))
        )

    # =========================
    # 6. 检查 novel subtype holdout 是否成功
    # =========================
    subtype_status_df = pd.DataFrame(subtype_status_rows)

    novel_types = subtype_status_df[
        subtype_status_df["Novel_subtype_eval"] == True
    ][type_col if type_col in subtype_status_df.columns else "Type"].unique()

    leak_rows = []

    for type_name in novel_types:
        train_subtypes_for_type = set(
            train_df.loc[train_df[type_col] == type_name, subtype_col].astype(str).unique()
        )
        test_subtypes_for_type = set(
            test_df.loc[test_df[type_col] == type_name, subtype_col].astype(str).unique()
        )

        overlap_subtypes = train_subtypes_for_type & test_subtypes_for_type

        if len(overlap_subtypes) > 0:
            for st in sorted(overlap_subtypes):
                leak_rows.append({
                    "Type": type_name,
                    "Subtype": st
                })

    if len(leak_rows) > 0:
        leak_df = pd.DataFrame(leak_rows)
        leak_df.to_csv(
            "subtype_leakage_error.csv",
            index=False,
            encoding="utf-8-sig"
        )
        raise RuntimeError(
            "错误：novel subtype holdout 中存在 subtype 同时出现在 train/test。"
            "已保存 subtype_leakage_error.csv"
        )

    # =========================
    # 7. 删除辅助列并保存
    # =========================
    train_df_out = train_df.drop(columns=["_original_index"])
    test_df_out = test_df.drop(columns=["_original_index"])

    train_df_out.to_csv(train_output, index=False, encoding="utf-8-sig")
    test_df_out.to_csv(test_output, index=False, encoding="utf-8-sig")

    stats_df = pd.DataFrame(type_stats)
    stats_df.to_csv(stats_output, index=False, encoding="utf-8-sig")

    subtype_status_df.to_csv(
        subtype_status_output,
        index=False,
        encoding="utf-8-sig"
    )

    # =========================
    # 8. 输出统计
    # =========================
    total_n = len(df)
    train_n = len(train_df_out)
    test_n = len(test_df_out)

    mode_counts = stats_df["Split_mode"].value_counts()

    novel_eval_types = stats_df.loc[
        stats_df["Novel_subtype_eval"] == True,
        "Type"
    ].tolist()

    ordinary_types = stats_df.loc[
        stats_df["Split_mode"] == "ordinary_type_split_single_subtype",
        "Type"
    ].tolist()

    single_train_only_types = stats_df.loc[
        stats_df["Split_mode"] == "type_single_sample_train_only",
        "Type"
    ].tolist()

    print("数据划分完成")
    print(f"原始总样本数: {total_n}")
    print(f"原始 Type 数: {df[type_col].nunique()}")
    print(f"原始 Subtype 数: {df[subtype_col].nunique()}")

    print("\n划分规则:")
    print("1. Type 样本数 = 1：只放入 train，不进入 test，不参与 novel subtype 评估")
    print("2. Type 样本数 >= 2，但 Type 内只有 1 个 subtype：普通 Type 分类测试，不算 novel subtype 测试")
    print("3. Type 内 subtype 数 >= 2：按 subtype/gene family holdout，test subtype 不在 train 中出现")

    print("\n最终数据集:")
    print(f"Train 样本数: {train_n}")
    print(f"Test 样本数: {test_n}")
    print(f"Train 比例: {train_n / (train_n + test_n):.4f}")
    print(f"Test 比例: {test_n / (train_n + test_n):.4f}")

    print("\nType 覆盖:")
    print(f"Train Type 数: {train_df_out[type_col].nunique()}")
    print(f"Test Type 数: {test_df_out[type_col].nunique()}")
    print(f"样本数 = 1 且只进 train 的 Type 数: {len(single_sample_types)}")
    print(f"样本数 >= 2 且进入 test 的 Type 数: {len(multi_sample_types)}")
    print("Train 是否覆盖所有 Type:", len(missing_train_types) == 0)
    print("Test 是否覆盖所有样本数 >= 2 的 Type:", len(missing_test_multi_types) == 0)

    print("\n划分模式统计:")
    print(mode_counts)

    print("\nNovel subtype 评估 Type 数:", len(novel_eval_types))
    print("普通 Type 分类测试 Type 数:", len(ordinary_types))
    print("只进 train 的单样本 Type 数:", len(single_train_only_types))

    print("\nTrain/Test 重复原始样本数:", len(overlap_ids))

    print("\nTrain Type 分布:")
    print(train_df_out[type_col].value_counts().sort_index())

    print("\nTest Type 分布:")
    print(test_df_out[type_col].value_counts().sort_index())

    print("\n已保存文件:")
    print(f"Train: {train_output}")
    print(f"Test: {test_output}")
    print(f"Type 统计: {stats_output}")
    print(f"Subtype holdout 状态: {subtype_status_output}")

    return train_df_out, test_df_out, stats_df, subtype_status_df


# =========================
# 执行
# =========================
split_for_novel_subtype_within_known_type(
    file_path="all_arg_nonarg_id_label.csv",
    type_col="Type",
    subtype_col="Subtype",
    test_ratio=0.3,
    random_state=42,
    train_output="train_set_type.csv",
    test_output="test_set_type.csv",
    stats_output="type_subtype_split_statistics.csv",
    subtype_status_output="subtype_holdout_status.csv"
)