import torch
from transformers import AutoTokenizer, AutoModel

model_name = "zhihan1996/DNABERT-2-117M"

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)

tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    trust_remote_code=True
)

model = AutoModel.from_pretrained(
    model_name,
    trust_remote_code=True
).to(device)

dna = "ACGTAGCATCGGATCTATCTATCGACACTTGGTTATCGATCTACGAGCATCTCGTTAGC"

inputs = tokenizer(dna, return_tensors="pt")
inputs = {k: v.to(device) for k, v in inputs.items()}

with torch.no_grad():
    hidden_states = model(**inputs)[0]

embedding = torch.mean(hidden_states[0], dim=0)

print("Hidden states:", hidden_states.shape)
print("Embedding:", embedding.shape)