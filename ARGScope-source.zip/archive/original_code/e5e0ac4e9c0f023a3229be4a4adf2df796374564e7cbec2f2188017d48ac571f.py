"""Publication-sized radar small multiples; selection uses precision alone."""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/novel_gene_type_heatmaps_20260923/data/Novel_gene_per_type_precision_recall_F1.csv'
PRIOR_AUDIT = ROOT / 'outputs/novel_gene_publication_bars_20260925/verification.json'
OUT = ROOT / 'outputs/novel_gene_small_radars_20260925'
NAME = 'Novel_gene_selected_types_small_radars'
ORDER = ['Beta-lactams', 'Trimethoprim', 'Fosfomycin', 'Quinolones', 'Tetracyclines', 'Sulfonamide']
STYLE = {'AA': {'color': '#367C92', 'marker': 'o'}, 'NT': {'color': '#BD8138', 'marker': 'D'}}
W_MM, H_MM = 180, 220
ANGLES = np.radians([90, -30, 210])
DIRECTIONS = np.column_stack([np.cos(ANGLES), np.sin(ANGLES)])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def draw_radar(fig, row, cx_mm, bottom_mm, text_boxes):
    style = STYLE[row.Modality]
    color = style['color']
    width_mm = 54
    height_mm = width_mm * 2.71 / 3.24
    ax = fig.add_axes([(cx_mm - width_mm / 2) / W_MM, bottom_mm / H_MM,
                      width_mm / W_MM, height_mm / H_MM], facecolor='none')
    ax.set_xlim(-1.62, 1.62)
    ax.set_ylim(-.93, 1.78)
    ax.set_aspect('equal')
    ax.set_axis_off()
    for radius in [.25, .5, .75, 1]:
        ax.add_patch(Polygon(DIRECTIONS * radius, closed=True, fill=False,
                             edgecolor='#B3C1C9' if radius == 1 else '#DFE6EA',
                             lw=.85 if radius == 1 else .65, zorder=1))
    for x, y in DIRECTIONS:
        ax.plot([0, x], [0, y], lw=.65, color='#D5DFE4', zorder=1)
    values = np.array([row.Precision, row.Recall, row.F1], dtype=float)
    points = DIRECTIONS * values[:, None]
    polygon = Polygon(points, closed=True, facecolor=color, alpha=.20, edgecolor='none', zorder=2)
    ax.add_patch(polygon)
    ax.plot(*np.vstack([points, points[0]]).T, color=color, lw=1.5, zorder=3)
    ax.scatter(points[:, 0], points[:, 1], s=16, marker=style['marker'],
               c=color, edgecolors='white', linewidth=.45, zorder=4)
    for value in [.5, 1]:
        ax.text(-.10, value, f'{value:.1f}', fontsize=6.8, color='#7B8990', ha='right', va='center', zorder=5)
    ax.text(-.045, -.19, '0', fontsize=6.6, color='#7B8990', ha='right', va='center', zorder=5)
    metric_positions = [('Precision', row.Precision, 0, 1.42, 1.17, 'center'),
                        ('Recall', row.Recall, 1.01, -.30, -.59, 'left'),
                        ('F1', row.F1, -1.01, -.30, -.59, 'right')]
    for metric, value, x, label_y, value_y, ha in metric_positions:
        text_boxes.append(ax.text(x, label_y, metric, fontsize=8.2, ha=ha, va='bottom', color='#303A40'))
        text_boxes.append(ax.text(x, value_y, f'{value:.4f}', fontsize=8.6, ha=ha, va='bottom',
                                  weight='bold', color=color))
    title_mm = bottom_mm + height_mm + 8.7
    count_mm = bottom_mm + height_mm + 4.3
    text_boxes.append(fig.text(cx_mm / W_MM, title_mm / H_MM, row.Type_display,
                              ha='center', va='center', fontsize=10.1, weight='bold', color='#25353C'))
    text_boxes.append(fig.text(cx_mm / W_MM, count_mm / H_MM,
                              f'n = {row.Support}; pred = {row.Predicted}', ha='center', va='center',
                              fontsize=8, color='#607077'))
    return {'model': row.Model, 'type': row.Type_display, 'values': values.tolist(),
            'reference_n': int(row.Support), 'predicted_n': int(row.Predicted),
            'points': points.tolist(), 'axis_ranges': [[0, 1], [0, 1], [0, 1]]}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    prior = json.loads(PRIOR_AUDIT.read_text(encoding='utf-8'))
    assert prior['source_files_unchanged']
    assert all(sha(Path(p)) == h for p, h in prior['source_sha256'].items())
    hashes = prior['source_sha256']
    data = pd.read_csv(SOURCE, keep_default_na=False)
    selected = data.loc[data.Support.gt(0) & data.Precision.ge(.95)].copy()
    selected['sort'] = selected.Type_display.map({name: i for i, name in enumerate(ORDER)})
    selected = selected.sort_values(['Modality', 'sort'])
    assert selected.groupby('Modality').size().to_dict() == {'AA': 6, 'NT': 2}
    for row in selected.itertuples():
        assert np.allclose([row.Precision, row.Recall, row.F1],
                           [row.TP / row.Predicted, row.TP / row.Support, 2 * row.TP / (row.Predicted + row.Support)],
                           rtol=0, atol=1e-12)
    selected.drop(columns='sort').to_csv(OUT / 'Selected_types_source_data.csv', index=False, encoding='utf-8-sig')
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 9, 'svg.hashsalt': 'novel-small-radars-20260925',
                         'pdf.fonttype': 42, 'text.color': '#25353C'})
    fig = plt.figure(figsize=(W_MM / 25.4, H_MM / 25.4), dpi=180, facecolor='none')
    text_boxes = []
    for letter, mod, title, y in [('A', 'AA', 'ARGScope-AA (protein)', 214.5),
                                   ('B', 'NT', 'ARGScope-NT (DNA)', 76.5)]:
        text_boxes.append(fig.text(4 / W_MM, y / H_MM, letter, ha='left', va='center', fontsize=13.5, weight='bold'))
        text_boxes.append(fig.text(13 / W_MM, y / H_MM, title, ha='left', va='center', fontsize=11.5,
                                  weight='bold', color=STYLE[mod]['color']))
    plots = []
    aa_rows = list(selected.loc[selected.Modality.eq('AA')].itertuples())
    for index, row in enumerate(aa_rows):
        center = [30, 90, 150][index % 3]
        bottom = [151, 86][index // 3]
        plots.append(draw_radar(fig, row, center, bottom, text_boxes))
    nt_rows = list(selected.loc[selected.Modality.eq('NT')].itertuples())
    for row, center in zip(nt_rows, [58, 122]):
        plots.append(draw_radar(fig, row, center, 13, text_boxes))
    text_boxes.append(fig.text(.025, 7.0 / H_MM,
                              'Selected types: precision ≥ 0.95. n = reference count; pred = predicted count.',
                              ha='left', va='center', fontsize=7.8, color='#54646C'))
    text_boxes.append(fig.text(.025, 3.1 / H_MM,
                              'Reference ARG sequences only (n = 2,247). All metric axes range from 0 to 1.',
                              ha='left', va='center', fontsize=7.8, color='#54646C'))
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    outside, overlaps = [], []
    for text in fig.findobj(match=Text):
        if text.get_visible() and text.get_text():
            box = text.get_window_extent(renderer)
            if box.width and box.height and (box.x0 < -1 or box.y0 < -1 or box.x1 > width + 1 or box.y1 > height + 1):
                outside.append(text.get_text())
    for index, a in enumerate(text_boxes):
        for b in text_boxes[index + 1:]:
            if a.get_window_extent(renderer).overlaps(b.get_window_extent(renderer)):
                overlaps.append([a.get_text(), b.get_text()])
    assert not outside, outside
    assert not overlaps, overlaps
    with plt.rc_context({'svg.fonttype': 'path'}):
        fig.savefig(OUT / (NAME + '.svg'), transparent=True)
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / (NAME + '_editable.svg'), transparent=True)
    fig.savefig(OUT / (NAME + '.pdf'), transparent=True)
    fig.savefig(OUT / (NAME + '_transparent_300dpi.tif'), dpi=300, transparent=True,
                pil_kwargs={'compression': 'tiff_lzw'})
    with Image.open(OUT / (NAME + '_transparent_300dpi.tif')) as im:
        assert tuple(float(v) for v in im.info['dpi']) == (300, 300)
        rgba = im.convert('RGBA')
        assert rgba.getchannel('A').getextrema() == (0, 255)
        pixels = im.size
    bg = Image.new('RGBA', pixels, 'white')
    bg.alpha_composite(rgba)
    bg.convert('RGB').save(OUT / (NAME + '_white_300dpi.tif'), compression='tiff_lzw', dpi=(300, 300))
    preview = bg.convert('RGB')
    preview.thumbnail((1275, 1559), Image.Resampling.LANCZOS)
    preview.save(OUT / (NAME + '_preview.png'))
    preview.convert('L').save(OUT / 'QA_grayscale.png')
    plt.close(fig)
    assert all(sha(Path(p)) == h for p, h in hashes.items())
    report = {'display_id': 'novel-gene-selected-type-small-radars-v1',
              'source_sha256': hashes, 'source_files_unchanged': True,
              'selection': 'Precision >= 0.95 and reference support > 0, independently by model',
              'recall_or_F1_filter': False, 'scope': '2247 true ARG sequences only',
              'full_original_results_retained': True, 'radar_panels': plots,
              'metric_order_clockwise_from_top': ['Precision', 'Recall', 'F1'],
              'physical_mm': [W_MM, H_MM], 'tif_pixels': list(pixels), 'tif_dpi': [300, 300],
              'outside_canvas': outside, 'overlapping_labels': overlaps,
              'metric_axes_independent': True, 'not_a_ternary_plot': True}
    (OUT / 'verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    print(json.dumps({'output': str(OUT), 'size': pixels, 'plots': len(plots)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
