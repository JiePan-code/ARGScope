from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

CSV_FILE = BASE_DIR / "all_dataset_summary.csv"

OUTPUT_DIR = BASE_DIR / "DNA_polar_summary_figure"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "DNA_all_dataset_polar_metrics.pdf"
OUTPUT_TIF = OUTPUT_DIR / "DNA_all_dataset_polar_metrics.tif"
OUTPUT_DATA = OUTPUT_DIR / "DNA_all_dataset_polar_metrics_used_data.csv"


# =========================================================
# 2. 参数设置
# =========================================================

DATASET_ORDER = [
    "LongNT",
    "30p",
    "40p",
    "50p",
    "60p",
    "70p",
    "80p",
]

# 图例显示名称：30p -> 30%，40p -> 40% ...
DATASET_LABELS = {
    "LongNT": "LongNT",
    "30p": "30%",
    "40p": "40%",
    "50p": "50%",
    "60p": "60%",
    "70p": "70%",
    "80p": "80%",
}

# 兼容不同写法
DATASET_NAME_MAP = {
    "longnt": "LongNT",
    "long nt": "LongNT",
    "long_nt": "LongNT",
    "longdna": "LongNT",
    "long dna": "LongNT",
    "long_dna": "LongNT",

    "30p": "30p",
    "30%": "30p",
    "30": "30p",

    "40p": "40p",
    "40%": "40p",
    "40": "40p",

    "50p": "50p",
    "50%": "50p",
    "50": "50p",

    "60p": "60p",
    "60%": "60p",
    "60": "60p",

    "70p": "70p",
    "70%": "70p",
    "70": "70p",

    "80p": "80p",
    "80%": "80p",
    "80": "80p",
}

METRICS = [
    "test_ACC",
    "test_WEIGHTED_PRECISION",
    "test_WEIGHTED_RECALL",
    "test_WEIGHTED_F1",
    "test_MCC",
]

METRIC_LABELS = {
    "test_ACC": "Accuracy",
    "test_WEIGHTED_PRECISION": "Precision",
    "test_WEIGHTED_RECALL": "Recall",
    "test_WEIGHTED_F1": "F1-score",
    "test_MCC": "MCC",
}

# 固定 0.800 到 1.000
R_MIN = 0.75
R_MAX = 0.85

GROUP_GAP = 1.3
BAR_WIDTH_RATIO = 0.82

TIF_DPI = 300

COLORS = [
    "#3C5488",  # LongNT
    "#4DBBD5",  # 30%
    "#91D1C2",  # 40%
    "#B09C85",  # 50%
    "#E64B35",  # 60%
    "#00A087",  # 70%
    "#F39B7F",  # 80%
]

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})


# =========================================================
# 3. 读取数据
# =========================================================

if not CSV_FILE.exists():
    raise FileNotFoundError(f"找不到文件: {CSV_FILE}")

df = pd.read_csv(CSV_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["dataset"] + METRICS
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"CSV 文件缺少这些列: {missing_cols}")

df["dataset"] = df["dataset"].astype(str).str.strip()


# =========================================================
# 4. 标准化 dataset 名称
# =========================================================

def normalize_dataset_name(x):
    x_raw = str(x).strip()
    x_key = x_raw.lower().replace("-", " ").replace("_", " ")
    x_key = " ".join(x_key.split())
    x_key_no_space = x_key.replace(" ", "")

    if x_key in DATASET_NAME_MAP:
        return DATASET_NAME_MAP[x_key]

    if x_key_no_space in DATASET_NAME_MAP:
        return DATASET_NAME_MAP[x_key_no_space]

    return x_raw


df["dataset_original"] = df["dataset"]
df["dataset"] = df["dataset"].map(normalize_dataset_name)

print("\nCSV 中识别到的 dataset 名称:")
print(sorted(df["dataset"].unique().tolist()))


# =========================================================
# 5. 筛选目标 dataset
# =========================================================

df = df[df["dataset"].isin(DATASET_ORDER)].copy()

if len(df) == 0:
    raise ValueError(
        "没有匹配到 LongNT, 30p, 40p, 50p, 60p, 70p, 80p。\n"
        "请检查 all_dataset_summary.csv 中 dataset 列的实际名称。"
    )

missing_datasets = [x for x in DATASET_ORDER if x not in df["dataset"].tolist()]
if missing_datasets:
    raise ValueError(f"CSV 中缺少这些 dataset: {missing_datasets}")

df["dataset"] = pd.Categorical(
    df["dataset"],
    categories=DATASET_ORDER,
    ordered=True,
)

df = df.sort_values("dataset").reset_index(drop=True)

for metric in METRICS:
    df[metric] = pd.to_numeric(df[metric], errors="coerce")

if df[METRICS].isna().any().any():
    raise ValueError("指标列中存在无法转换为数值的内容，请检查 CSV。")

df[["dataset", "dataset_original"] + METRICS].to_csv(
    OUTPUT_DATA,
    index=False,
    encoding="utf-8-sig",
)

print("\nLoaded data:")
print(df[["dataset"] + METRICS])


# =========================================================
# 6. 建立颜色映射
# =========================================================

dataset_color_map = {
    dataset: COLORS[i]
    for i, dataset in enumerate(DATASET_ORDER)
}


# =========================================================
# 7. 计算 polar bar 位置
# =========================================================

n_metrics = len(METRICS)
n_datasets = len(df)

total_units = n_metrics * n_datasets + n_metrics * GROUP_GAP
angle_per_unit = 2 * np.pi / total_units

theta_list = []
height_list = []
color_list = []
metric_center_angles = []

current_unit = 0

for metric in METRICS:
    block_start = current_unit

    for _, row in df.iterrows():
        dataset = str(row["dataset"])
        theta = current_unit * angle_per_unit
        value = float(row[metric])

        if value < R_MIN:
            print(
                f"Warning: {dataset} 的 {metric} = {value:.4f} "
                f"低于 R_MIN={R_MIN:.2f}，图中会被截断。"
            )

        if value > R_MAX:
            print(
                f"Warning: {dataset} 的 {metric} = {value:.4f} "
                f"高于 R_MAX={R_MAX:.2f}，图中会被截断。"
            )

        theta_list.append(theta)
        height_list.append(value - R_MIN)
        color_list.append(dataset_color_map[dataset])

        current_unit += 1

    block_end = current_unit - 1
    center_unit = (block_start + block_end) / 2
    metric_center_angles.append(center_unit * angle_per_unit)

    current_unit += GROUP_GAP

theta_arr = np.array(theta_list)
height_arr = np.array(height_list)
bar_width = angle_per_unit * BAR_WIDTH_RATIO


# =========================================================
# 8. 绘图
# =========================================================

fig = plt.figure(figsize=(6.2, 6.2), dpi=600)
ax = plt.subplot(111, polar=True)

ax.set_theta_offset(np.pi / 2)
ax.set_theta_direction(-1)

ax.bar(
    theta_arr,
    height_arr,
    width=bar_width,
    bottom=R_MIN,
    color=color_list,
    edgecolor="black",
    linewidth=0.45,
    alpha=0.95,
    zorder=5,
)

ax.set_ylim(R_MIN, R_MAX)

yticks = np.round(np.arange(R_MIN, R_MAX + 0.001, 0.025), 3)
ax.set_yticks(yticks)
ax.set_yticklabels([f"{x:.3f}" for x in yticks], fontsize=7)
ax.set_rlabel_position(0)

ax.set_xticks([])

ax.grid(
    True,
    linestyle="-",
    linewidth=0.45,
    alpha=0.45,
    zorder=0,
)

label_radius = R_MAX + (R_MAX - R_MIN) * 0.18

for angle, metric in zip(metric_center_angles, METRICS):
    label = METRIC_LABELS.get(metric, metric)

    ax.text(
        angle,
        label_radius,
        label,
        ha="center",
        va="center",
        fontsize=11,
        clip_on=False,
    )

ax.spines["polar"].set_linewidth(1.0)
ax.spines["polar"].set_color("black")


# =========================================================
# 9. 图例：显示 LongNT, 30%, 40%, 50%, 60%, 70%, 80%
# =========================================================

legend_handles = []

for dataset in DATASET_ORDER:
    legend_handles.append(
        mpl.patches.Patch(
            facecolor=dataset_color_map[dataset],
            edgecolor="black",
            linewidth=0.4,
            label=DATASET_LABELS[dataset],
        )
    )

ax.legend(
    handles=legend_handles,
    loc="lower right",
    bbox_to_anchor=(1.28, 0.06),
    frameon=True,
    fontsize=7,
    borderpad=0.4,
    handlelength=1.2,
    handletextpad=0.4,
)

plt.tight_layout()

ax.legend(
    handles=legend_handles,
    loc="lower right",
    bbox_to_anchor=(1.34, 0.06),
    frameon=True,
    fontsize=7,
    borderpad=0.4,
    handlelength=1.2,
    handletextpad=0.4,
    title="Long sequence",
    title_fontsize=7,
)
# =========================================================
# 10. 保存
# =========================================================

fig.savefig(OUTPUT_PDF, bbox_inches="tight")

fig.savefig(
    OUTPUT_TIF,
    dpi=TIF_DPI,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 11. 输出
# =========================================================

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_DATA)