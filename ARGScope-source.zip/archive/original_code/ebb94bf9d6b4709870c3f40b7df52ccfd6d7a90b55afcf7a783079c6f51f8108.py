#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Split SARG IDs into train/test according to Subtype.

Rules
-----
Subtype count = 1:
    all -> train

Subtype count = 2:
    1 -> train
    1 -> test

Subtype count >= 3:
    approximately 2:1 train:test
    n_test  = (n + 1) // 3
    n_train = n - n_test

Examples:
    3 -> 2 train / 1 test
    4 -> 3 train / 1 test
    5 -> 3 train / 2 test
    6 -> 4 train / 2 test

Outputs
-------
train_ids.txt
test_ids.txt

The output order follows the original structure file order.
"""

from pathlib import Path
from collections import defaultdict
import csv
import hashlib
import random


# =============================================================================
# Settings
# =============================================================================

ROOT = Path(__file__).resolve().parent

INPUT = ROOT / "SARG_full_final_structure.txt"

TRAIN_OUT = ROOT / "train_ids.txt"
TEST_OUT = ROOT / "test_ids.txt"

SEED = 20260822

ID_COL = "SARG.Seq.ID"
SUBTYPE_COL = "Subtype"


# =============================================================================
# Helpers
# =============================================================================

def subtype_seed(subtype: str) -> int:
    """Stable subtype-specific seed."""
    raw = f"{SEED}|{subtype}".encode("utf-8")
    digest = hashlib.sha256(raw).digest()

    return int.from_bytes(
        digest[:8],
        byteorder="big",
        signed=False,
    )


def split_counts(n: int) -> tuple[int, int]:
    """Return n_train, n_test."""
    if n == 1:
        return 1, 0

    if n == 2:
        return 1, 1

    n_test = (n + 1) // 3
    n_train = n - n_test

    return n_train, n_test


# =============================================================================
# Main
# =============================================================================

def main():
    print("=" * 80)
    print("SARG subtype-aware train/test ID split")
    print("=" * 80)

    if not INPUT.is_file():
        raise FileNotFoundError(
            f"Input file not found:\n{INPUT}"
        )

    # -------------------------------------------------------------------------
    # Read structure
    # -------------------------------------------------------------------------

    rows = []

    with INPUT.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                "Structure file has no header."
            )

        for required in (
            ID_COL,
            SUBTYPE_COL,
        ):
            if required not in reader.fieldnames:
                raise ValueError(
                    f"Missing required column: {required}"
                )

        for row_number, row in enumerate(
            reader,
            start=2,
        ):
            seq_id = (
                row.get(ID_COL, "")
                .strip()
            )

            subtype = (
                row.get(SUBTYPE_COL, "")
                .strip()
            )

            if not seq_id:
                raise ValueError(
                    f"Empty {ID_COL} at line {row_number}"
                )

            if not subtype:
                raise ValueError(
                    f"Empty {SUBTYPE_COL} at line {row_number}"
                )

            rows.append(
                {
                    "id": seq_id,
                    "subtype": subtype,
                }
            )

    if not rows:
        raise ValueError(
            "No records found."
        )

    ids = [
        row["id"]
        for row in rows
    ]

    if len(ids) != len(set(ids)):
        raise ValueError(
            "Duplicate SARG.Seq.ID found."
        )

    # -------------------------------------------------------------------------
    # Group row indices by subtype
    # -------------------------------------------------------------------------

    subtype_to_indices = defaultdict(list)

    for index, row in enumerate(rows):
        subtype_to_indices[
            row["subtype"]
        ].append(index)

    # -------------------------------------------------------------------------
    # Assign train/test
    # -------------------------------------------------------------------------

    train_index_set = set()
    test_index_set = set()

    singleton_subtypes = 0
    doubleton_subtypes = 0
    multi_subtypes = 0

    for subtype in sorted(
        subtype_to_indices
    ):
        indices = (
            subtype_to_indices[
                subtype
            ]
        )

        n = len(indices)

        n_train, n_test = split_counts(n)

        if n == 1:
            singleton_subtypes += 1

        elif n == 2:
            doubleton_subtypes += 1

        else:
            multi_subtypes += 1

        rng = random.Random(
            subtype_seed(subtype)
        )

        shuffled = indices.copy()
        rng.shuffle(shuffled)

        test_indices = set(
            shuffled[:n_test]
        )

        train_indices = [
            idx
            for idx in indices
            if idx not in test_indices
        ]

        if len(train_indices) != n_train:
            raise RuntimeError(
                f"Train count mismatch: {subtype}"
            )

        if len(test_indices) != n_test:
            raise RuntimeError(
                f"Test count mismatch: {subtype}"
            )

        train_index_set.update(
            train_indices
        )

        test_index_set.update(
            test_indices
        )

    # -------------------------------------------------------------------------
    # QC
    # -------------------------------------------------------------------------

    if train_index_set & test_index_set:
        raise RuntimeError(
            "Train/test overlap detected."
        )

    all_indices = set(
        range(len(rows))
    )

    if (
        train_index_set
        | test_index_set
    ) != all_indices:
        raise RuntimeError(
            "Some records were not assigned."
        )

    # Verify every subtype again.
    for subtype, indices in subtype_to_indices.items():
        expected_train, expected_test = split_counts(
            len(indices)
        )

        actual_train = sum(
            idx in train_index_set
            for idx in indices
        )

        actual_test = sum(
            idx in test_index_set
            for idx in indices
        )

        if (
            actual_train != expected_train
            or actual_test != expected_test
        ):
            raise RuntimeError(
                f"Subtype QC failed: {subtype}; "
                f"expected {expected_train}/{expected_test}, "
                f"observed {actual_train}/{actual_test}"
            )

    # -------------------------------------------------------------------------
    # Keep original structure-file order in final ID files
    # -------------------------------------------------------------------------

    train_ids = [
        rows[index]["id"]
        for index in range(len(rows))
        if index in train_index_set
    ]

    test_ids = [
        rows[index]["id"]
        for index in range(len(rows))
        if index in test_index_set
    ]

    # -------------------------------------------------------------------------
    # Save only IDs
    # -------------------------------------------------------------------------

    TRAIN_OUT.write_text(
        "\n".join(train_ids) + "\n",
        encoding="utf-8",
    )

    TEST_OUT.write_text(
        "\n".join(test_ids) + "\n",
        encoding="utf-8",
    )

    # -------------------------------------------------------------------------
    # Report
    # -------------------------------------------------------------------------

    print(f"Input records : {len(rows):,}")
    print(
        f"Subtypes      : "
        f"{len(subtype_to_indices):,}"
    )
    print()

    print(
        f"Subtype n=1   : "
        f"{singleton_subtypes:,}"
    )
    print(
        f"Subtype n=2   : "
        f"{doubleton_subtypes:,}"
    )
    print(
        f"Subtype n>=3  : "
        f"{multi_subtypes:,}"
    )
    print()

    print(
        f"Train IDs     : "
        f"{len(train_ids):,}"
    )
    print(
        f"Test IDs      : "
        f"{len(test_ids):,}"
    )
    print()

    print("QC:")
    print("  overlap              : 0")
    print("  all IDs retained     : True")
    print("  subtype rules passed : True")
    print()

    print(f"Train file: {TRAIN_OUT}")
    print(f"Test file : {TEST_OUT}")


if __name__ == "__main__":
    main()
