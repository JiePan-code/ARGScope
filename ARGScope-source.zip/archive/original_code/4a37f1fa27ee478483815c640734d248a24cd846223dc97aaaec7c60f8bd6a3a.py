#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope final DNA Student - local inference on percent_60/70/80/90.

Put this script directly in:
    4.DNA_student_subtype2_newsplit/

Expected files/folders:
    4.DNA_student_subtype2_newsplit/
    ├─ DNA_student_best_model_before_test.pt
    ├─ test_ids.txt
    ├─ test_sequence_predictions.csv
    ├─ DNABERT2_embedding/          # name is auto-detected
    │  ├─ percent_60/
    │  ├─ percent_70/
    │  ├─ percent_80/
    │  └─ percent_90/
    └─ apply_DNA_student_percent60_90_local.py

The embedding-root auto-detection also accepts names such as:
    _NABERT2_embedding
    NABERT2_embedding
    DNABERT2_OFFICIAL_MEAN_768_embeddings_ALL7_A100

Inference:
    DNABERT-2 768D
      -> train-only standardization stored in checkpoint
      -> Linear(768, hidden_dim) + LN + GELU + Dropout
      -> two residual blocks
      -> Linear(hidden_dim, 512) + LN
      -> L2 normalization
      -> binary cosine head
      -> ARG-subtype cosine head

The model is NOT retrained. Fusion/refined features are NOT used in inference.

Evaluation:
    1. fragment: each _1/_2/_3/_4/_5 fragment independently.
    2. original_mean_5parts: mean of five 512D DNA-Student z vectors,
       followed by L2 normalization and the SAME trained heads.

CUDA only. No silent CPU fallback.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)

SCRIPT_VERSION = "2026-09-03-local-DNA-subtype2-percent60-90-v1"
NONARG = "nonARG"
CONDITIONS = ("percent_60", "percent_70", "percent_80", "percent_90")
DNA_DIM = 768


# =============================================================================
# CLI
# =============================================================================

def parse_args():
    base_dir = Path(__file__).resolve().parent

    p = argparse.ArgumentParser(
        description=(
            "Apply the final DNA Student to percent_60/70/80/90 "
            "DNABERT-2 768D embeddings on a local GPU."
        )
    )

    p.add_argument("--base-dir", type=Path, default=base_dir)
    p.add_argument("--model", type=Path, default=None)
    p.add_argument("--embedding-root", type=Path, default=None)
    p.add_argument("--test-ids", type=Path, default=None)
    p.add_argument("--test-labels", type=Path, default=None)
    p.add_argument("--output-root", type=Path, default=None)

    p.add_argument(
        "--conditions",
        nargs="+",
        default=list(CONDITIONS),
        choices=list(CONDITIONS),
    )

    p.add_argument(
        "--batch-size",
        type=int,
        default=2048,
        help="Conservative default for an 8-GB local GPU.",
    )

    p.add_argument(
        "--expected-parts",
        type=int,
        default=5,
    )

    p.add_argument(
        "--no-amp",
        action="store_true",
    )

    p.add_argument(
        "--allow-incomplete-originals",
        action="store_true",
        help=(
            "Use originals with >0 available fragments in original-level "
            "evaluation. Default uses only originals with exactly 5 fragments."
        ),
    )

    p.add_argument(
        "--overwrite",
        action="store_true",
    )

    return p.parse_args()


# =============================================================================
# Helpers
# =============================================================================

def canonical_id(value: Any) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()

    compact = "".join(
        ch
        for ch in text.lower()
        if ch.isalnum()
    )

    if compact in {
        "nonarg",
        "nonresistance",
        "negative",
        "nonresistant",
    }:
        return NONARG

    return text


def is_nonarg(value: Any) -> bool:
    return canonical_subtype(value) == NONARG


def torch_load_cpu(path: Path):
    try:
        return torch.load(
            path,
            map_location="cpu",
            weights_only=False,
        )
    except TypeError:
        return torch.load(
            path,
            map_location="cpu",
        )


def get_first_value(
    obj: dict,
    keys: tuple[str, ...],
    default=None,
):
    for key in keys:
        if key in obj:
            return obj[key]

    return default


def write_csv(
    path: Path,
    rows: list[dict[str, Any]],
):
    if not rows:
        return

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames = []
    seen = set()

    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )
        writer.writeheader()
        writer.writerows(rows)


def json_safe(value):
    if isinstance(value, dict):
        return {
            str(k): json_safe(v)
            for k, v in value.items()
        }

    if isinstance(value, (list, tuple)):
        return [
            json_safe(v)
            for v in value
        ]

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, np.integer):
        return int(value)

    if isinstance(value, np.floating):
        return float(value)

    return value


def safe_mcc(
    true: np.ndarray,
    predicted: np.ndarray,
) -> float:
    if len(true) == 0:
        return 0.0

    if (
        len(np.unique(true)) < 2
        or len(np.unique(predicted)) < 2
    ):
        return 0.0

    return float(
        matthews_corrcoef(
            true,
            predicted,
        )
    )


def metric_dict(
    true: np.ndarray,
    predicted: np.ndarray,
):
    if len(true) == 0:
        return {
            "n": 0,
            "accuracy": 0.0,
            "macro_precision": 0.0,
            "weighted_precision": 0.0,
            "micro_precision": 0.0,
            "macro_recall": 0.0,
            "weighted_recall": 0.0,
            "micro_recall": 0.0,
            "macro_f1": 0.0,
            "weighted_f1": 0.0,
            "micro_f1": 0.0,
            "mcc": 0.0,
        }

    return {
        "n":
            int(len(true)),

        "accuracy":
            float(
                accuracy_score(
                    true,
                    predicted,
                )
            ),

        "macro_precision":
            float(
                precision_score(
                    true,
                    predicted,
                    average="macro",
                    zero_division=0,
                )
            ),

        "weighted_precision":
            float(
                precision_score(
                    true,
                    predicted,
                    average="weighted",
                    zero_division=0,
                )
            ),

        "micro_precision":
            float(
                precision_score(
                    true,
                    predicted,
                    average="micro",
                    zero_division=0,
                )
            ),

        "macro_recall":
            float(
                recall_score(
                    true,
                    predicted,
                    average="macro",
                    zero_division=0,
                )
            ),

        "weighted_recall":
            float(
                recall_score(
                    true,
                    predicted,
                    average="weighted",
                    zero_division=0,
                )
            ),

        "micro_recall":
            float(
                recall_score(
                    true,
                    predicted,
                    average="micro",
                    zero_division=0,
                )
            ),

        "macro_f1":
            float(
                f1_score(
                    true,
                    predicted,
                    average="macro",
                    zero_division=0,
                )
            ),

        "weighted_f1":
            float(
                f1_score(
                    true,
                    predicted,
                    average="weighted",
                    zero_division=0,
                )
            ),

        "micro_f1":
            float(
                f1_score(
                    true,
                    predicted,
                    average="micro",
                    zero_division=0,
                )
            ),

        "mcc":
            safe_mcc(
                true,
                predicted,
            ),
    }


# =============================================================================
# DNA Student model
# =============================================================================

@dataclass
class ModelConfig:
    hidden_dim: int
    embedding_dim: int
    dropout: float
    logit_scale_binary: float
    logit_scale_subtype: float


class CosineHead(nn.Module):

    def __init__(
        self,
        number_classes: int,
        dimension: int,
        scale: float,
    ):
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(
                number_classes,
                dimension,
            )
        )

        nn.init.xavier_uniform_(
            self.weight
        )

        self.scale = float(scale)

    def forward(
        self,
        features: torch.Tensor,
    ):
        return self.scale * F.linear(
            F.normalize(
                features,
                p=2,
                dim=1,
            ),
            F.normalize(
                self.weight,
                p=2,
                dim=1,
            ),
        )


class ResidualBlock(nn.Module):

    def __init__(
        self,
        dimension: int,
        dropout: float,
    ):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
            nn.GELU(),
            nn.Dropout(
                dropout
            ),
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
        )

    def forward(
        self,
        x: torch.Tensor,
    ):
        return F.gelu(
            x
            + self.net(x)
        )


class DNAStudent(nn.Module):

    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        config: ModelConfig,
    ):
        super().__init__()

        self.register_buffer(
            "dna_mean",
            dna_mean.clone(),
        )

        self.register_buffer(
            "dna_std",
            dna_std.clone(),
        )

        self.input = nn.Sequential(
            nn.Linear(
                dna_dimension,
                config.hidden_dim,
            ),
            nn.LayerNorm(
                config.hidden_dim
            ),
            nn.GELU(),
            nn.Dropout(
                config.dropout
            ),
        )

        self.blocks = nn.Sequential(
            ResidualBlock(
                config.hidden_dim,
                config.dropout,
            ),
            ResidualBlock(
                config.hidden_dim,
                config.dropout,
            ),
        )

        self.output = nn.Sequential(
            nn.Linear(
                config.hidden_dim,
                config.embedding_dim,
            ),
            nn.LayerNorm(
                config.embedding_dim
            ),
        )

        self.binary_head = CosineHead(
            2,
            config.embedding_dim,
            config.logit_scale_binary,
        )

        self.arg_head = CosineHead(
            number_arg_subtypes,
            config.embedding_dim,
            config.logit_scale_subtype,
        )

    def encode(
        self,
        dna: torch.Tensor,
    ):
        dna = (
            dna
            - self.dna_mean
        ) / self.dna_std

        hidden = self.blocks(
            self.input(
                dna
            )
        )

        return F.normalize(
            self.output(
                hidden
            ),
            p=2,
            dim=1,
        )

    def forward(
        self,
        dna: torch.Tensor,
    ):
        z = self.encode(
            dna
        )

        return (
            self.binary_head(z),
            self.arg_head(z),
            z,
        )


def load_model(
    checkpoint_path: Path,
    device: torch.device,
):
    checkpoint = torch_load_cpu(
        checkpoint_path
    )

    if not isinstance(
        checkpoint,
        dict,
    ):
        raise TypeError(
            f"DNA checkpoint must be a dict: {checkpoint_path}"
        )

    state = get_first_value(
        checkpoint,
        (
            "student_state_dict",
            "model_state_dict",
            "state_dict",
        ),
    )

    if not isinstance(
        state,
        dict,
    ):
        raise KeyError(
            "Checkpoint has no Student state_dict."
        )

    arg_names_raw = get_first_value(
        checkpoint,
        (
            "arg_subtype_names",
            "ARG_subtype_names",
            "subtype_names",
        ),
    )

    if arg_names_raw is None:
        raise KeyError(
            "Checkpoint has no arg_subtype_names."
        )

    arg_names = [
        canonical_subtype(value)
        for value in arg_names_raw
    ]

    if len(arg_names) != len(set(arg_names)):
        raise ValueError(
            "Duplicate ARG subtype names in checkpoint."
        )

    if any(
        is_nonarg(value)
        for value in arg_names
    ):
        raise ValueError(
            "ARG subtype list unexpectedly contains nonARG."
        )

    required_state_keys = (
        "input.0.weight",
        "output.0.weight",
        "binary_head.weight",
        "arg_head.weight",
    )

    missing_state = [
        key
        for key in required_state_keys
        if key not in state
    ]

    if missing_state:
        raise KeyError(
            f"Missing DNA Student state keys: {missing_state}"
        )

    dna_dimension = int(
        state[
            "input.0.weight"
        ].shape[1]
    )

    hidden_dim = int(
        state[
            "input.0.weight"
        ].shape[0]
    )

    embedding_dim = int(
        state[
            "output.0.weight"
        ].shape[0]
    )

    if dna_dimension != DNA_DIM:
        raise ValueError(
            f"Expected DNABERT-2 input dimension {DNA_DIM}; "
            f"found {dna_dimension}."
        )

    if int(
        state[
            "arg_head.weight"
        ].shape[0]
    ) != len(arg_names):
        raise ValueError(
            "arg_head rows and ARG subtype names differ."
        )

    configuration = get_first_value(
        checkpoint,
        (
            "configuration",
            "config",
            "best_configuration",
            "best_parameters",
        ),
        default={},
    )

    if not isinstance(
        configuration,
        dict,
    ):
        configuration = {}

    config = ModelConfig(
        hidden_dim=hidden_dim,
        embedding_dim=embedding_dim,
        dropout=float(
            configuration.get(
                "dropout",
                0.10,
            )
        ),
        logit_scale_binary=float(
            configuration.get(
                "logit_scale_binary",
                16.0,
            )
        ),
        logit_scale_subtype=float(
            configuration.get(
                "logit_scale_subtype",
                22.0,
            )
        ),
    )

    dna_mean = get_first_value(
        checkpoint,
        (
            "dna_train_mean",
            "dna_mean",
        ),
    )

    dna_std = get_first_value(
        checkpoint,
        (
            "dna_train_std",
            "dna_std",
        ),
    )

    if dna_mean is None:
        dna_mean = state.get(
            "dna_mean"
        )

    if dna_std is None:
        dna_std = state.get(
            "dna_std"
        )

    if not isinstance(
        dna_mean,
        torch.Tensor,
    ) or not isinstance(
        dna_std,
        torch.Tensor,
    ):
        raise ValueError(
            "Checkpoint does not contain DNA train mean/std."
        )

    dna_mean = (
        dna_mean
        .detach()
        .cpu()
        .float()
        .reshape(-1)
    )

    dna_std = (
        dna_std
        .detach()
        .cpu()
        .float()
        .reshape(-1)
    )

    if (
        dna_mean.numel() != DNA_DIM
        or dna_std.numel() != DNA_DIM
    ):
        raise ValueError(
            f"DNA mean/std dimension mismatch: "
            f"{dna_mean.numel()} / {dna_std.numel()}"
        )

    model = DNAStudent(
        dna_dimension=dna_dimension,
        dna_mean=dna_mean,
        dna_std=dna_std,
        number_arg_subtypes=len(
            arg_names
        ),
        config=config,
    )

    model.load_state_dict(
        state,
        strict=True,
    )

    model = model.to(
        device
    )

    model.eval()

    threshold = float(
        get_first_value(
            checkpoint,
            (
                "selected_binary_ARG_probability_threshold",
                "fixed_binary_ARG_probability_threshold",
                "selected_binary_threshold",
                "binary_threshold",
            ),
            default=0.80,
        )
    )

    if not (
        0.0
        <= threshold
        <= 1.0
    ):
        raise ValueError(
            f"Invalid binary threshold: {threshold}"
        )

    subtype_to_type = checkpoint.get(
        "subtype_to_type",
        {},
    )

    if not isinstance(
        subtype_to_type,
        dict,
    ):
        subtype_to_type = {}

    subtype_to_type = {
        canonical_subtype(key):
            str(value).strip()
        for key, value
        in subtype_to_type.items()
    }

    subtype_to_type[
        NONARG
    ] = NONARG

    print(
        "\n===== DNA MODEL LOADED ====="
    )
    print(
        f"Checkpoint       : {checkpoint_path}"
    )
    print(
        f"Training version : "
        f"{checkpoint.get('script_version', 'NA')}"
    )
    print(
        f"Architecture     : "
        f"{dna_dimension} -> {hidden_dim} -> {embedding_dim}"
    )
    print(
        f"ARG subtypes     : {len(arg_names):,}"
    )
    print(
        f"ARG threshold    : {threshold:.4f}"
    )
    print(
        f"Dropout          : {config.dropout}"
    )
    print(
        f"Binary scale     : {config.logit_scale_binary}"
    )
    print(
        f"Subtype scale    : {config.logit_scale_subtype}"
    )

    return (
        model,
        checkpoint,
        arg_names,
        subtype_to_type,
        threshold,
        config,
    )


# =============================================================================
# Local path detection / truth
# =============================================================================

def detect_embedding_root(
    base_dir: Path,
) -> Path:

    candidates = [
        base_dir / "DNABERT2_embedding",
        base_dir / "_NABERT2_embedding",
        base_dir / "NABERT2_embedding",
        base_dir / "DNABERT_2_embedding",
        base_dir / "DNABERT2_OFFICIAL_MEAN_768_embeddings_ALL7_A100",
    ]

    for candidate in candidates:
        if (
            candidate.is_dir()
            and all(
                (
                    candidate
                    / condition
                ).is_dir()
                for condition in CONDITIONS
            )
        ):
            return candidate

    # Fallback: search first-level subfolders.
    matches = []

    for path in base_dir.iterdir():
        if not path.is_dir():
            continue

        name = path.name.lower()

        if (
            "bert" not in name
            and "dna" not in name
        ):
            continue

        if all(
            (
                path
                / condition
            ).is_dir()
            for condition in CONDITIONS
        ):
            matches.append(path)

    if len(matches) == 1:
        return matches[0]

    if len(matches) > 1:
        raise ValueError(
            "Multiple possible DNABERT-2 embedding roots found: "
            f"{matches}. Use --embedding-root explicitly."
        )

    raise FileNotFoundError(
        "Cannot auto-detect DNABERT-2 embedding folder under:\n"
        f"{base_dir}\n"
        "Use --embedding-root to specify it."
    )


def detect_model(
    base_dir: Path,
) -> Path:

    candidates = (
        # Preferred: validation-selected model saved BEFORE final TEST reporting.
        "DNA_student_best_model_before_test.pt",
        "DNA_student_long_model.pt",
        "DNA_student_best_so_far.pt",
    )

    for name in candidates:
        path = (
            base_dir
            / name
        )

        if path.is_file():
            return path

    raise FileNotFoundError(
        "Cannot find a DNA Student checkpoint. Expected one of:\n"
        + "\n".join(
            str(
                base_dir
                / name
            )
            for name in candidates
        )
    )


def read_test_ids(
    path: Path,
):
    ids = []
    seen = set()

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line_number, raw in enumerate(
            handle,
            start=1,
        ):
            seq_id = canonical_id(
                raw
            )

            if not seq_id:
                continue

            if seq_id in seen:
                raise ValueError(
                    f"Duplicate TEST ID at line {line_number}: "
                    f"{seq_id}"
                )

            seen.add(
                seq_id
            )

            ids.append(
                seq_id
            )

    if not ids:
        raise ValueError(
            f"No TEST IDs found: {path}"
        )

    return ids


def find_column(
    fieldnames,
    candidates,
    required=True,
):
    lowered = {
        name.lower():
            name
        for name in fieldnames
    }

    for candidate in candidates:

        if candidate in fieldnames:
            return candidate

        if candidate.lower() in lowered:
            return lowered[
                candidate.lower()
            ]

    if required:
        raise ValueError(
            f"Cannot find columns {candidates}; "
            f"available={fieldnames}"
        )

    return None


def load_test_truth(
    path: Path,
):
    """
    Uses ONLY true labels from the final full-length DNA TEST prediction table.
    Its predicted labels are never reused.
    """

    truth = {}

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle
        )

        if not reader.fieldnames:
            raise ValueError(
                f"No header: {path}"
            )

        id_column = find_column(
            reader.fieldnames,
            (
                "sequence_id",
                "SARG.Seq.ID",
                "id",
                "ID",
                "original_id",
            ),
        )

        subtype_column = find_column(
            reader.fieldnames,
            (
                "true_subtype",
                "Subtype",
                "subtype",
            ),
        )

        type_column = find_column(
            reader.fieldnames,
            (
                "true_type",
                "Type",
                "type",
            ),
            required=False,
        )

        for line_number, row in enumerate(
            reader,
            start=2,
        ):
            seq_id = canonical_id(
                row.get(
                    id_column,
                    "",
                )
            )

            subtype = canonical_subtype(
                row.get(
                    subtype_column,
                    "",
                )
            )

            type_name = (
                str(
                    row.get(
                        type_column,
                        "",
                    )
                ).strip()
                if type_column is not None
                else ""
            )

            if not seq_id:
                continue

            if not subtype:
                raise ValueError(
                    f"Empty true subtype at line {line_number}: "
                    f"{path}"
                )

            if is_nonarg(
                subtype
            ):
                type_name = NONARG

            current = (
                subtype,
                type_name,
            )

            previous = truth.setdefault(
                seq_id,
                current,
            )

            if previous != current:
                raise ValueError(
                    f"Inconsistent truth for {seq_id}: "
                    f"{previous} vs {current}"
                )

    if not truth:
        raise ValueError(
            f"No true labels found: {path}"
        )

    return truth


# =============================================================================
# Embedding PT loading
# =============================================================================

def discover_pt_files(
    condition_folder: Path,
):

    if not condition_folder.is_dir():
        raise FileNotFoundError(
            f"Condition folder not found: "
            f"{condition_folder}"
        )

    files = sorted(
        path
        for path
        in condition_folder.glob(
            "*.pt"
        )
        if (
            path.is_file()
            and not path.name.endswith(
                ".tmp"
            )
        )
    )

    if not files:
        raise FileNotFoundError(
            f"No .pt files found: "
            f"{condition_folder}"
        )

    chunk_files = [
        path
        for path in files
        if (
            "chunk"
            in path.name.lower()
            or "part"
            in path.name.lower()
        )
    ]

    # Avoid reading both chunks and a merged duplicate.
    return (
        chunk_files
        if chunk_files
        else files
    )


def extract_embedding_pt(
    path: Path,
):

    obj = torch_load_cpu(
        path
    )

    if not isinstance(
        obj,
        dict,
    ):
        raise TypeError(
            f"Embedding PT must contain a dict: "
            f"{path}"
        )

    ids = get_first_value(
        obj,
        (
            "ids",
            "sequence_ids",
            "fragment_ids",
        ),
    )

    embeddings = get_first_value(
        obj,
        (
            "embeddings",
            "mean_embeddings",
            "features",
        ),
    )

    if (
        ids is None
        or embeddings is None
    ):
        raise KeyError(
            f"Embedding PT requires IDs + embeddings: "
            f"{path}; keys={sorted(obj.keys())}"
        )

    ids = [
        canonical_id(
            value
        )
        for value in ids
    ]

    if (
        not isinstance(
            embeddings,
            torch.Tensor,
        )
        or embeddings.ndim != 2
    ):
        raise ValueError(
            f"Invalid embedding tensor: {path}"
        )

    embeddings = (
        embeddings
        .detach()
        .cpu()
        .float()
        .contiguous()
    )

    if embeddings.shape[0] != len(ids):
        raise ValueError(
            f"ID/embedding mismatch in {path}: "
            f"{len(ids)} vs {embeddings.shape[0]}"
        )

    if embeddings.shape[1] != DNA_DIM:
        raise ValueError(
            f"Expected DNABERT-2 {DNA_DIM}D embeddings; "
            f"found {embeddings.shape[1]} in {path}"
        )

    if len(ids) != len(set(ids)):
        raise ValueError(
            f"Duplicate IDs inside: {path}"
        )

    if not bool(
        torch.isfinite(
            embeddings
        ).all()
    ):
        raise ValueError(
            f"NaN/Inf in embeddings: {path}"
        )

    pooling = str(
        get_first_value(
            obj,
            (
                "pooling",
                "embedding_definition",
            ),
            default="",
        )
    ).lower()

    if (
        pooling
        and "cls"
        in pooling
        and "mean"
        not in pooling
    ):
        raise ValueError(
            f"Embedding PT appears to use CLS instead of "
            f"official/native mean pooling: {path}; "
            f"pooling={pooling}"
        )

    return (
        ids,
        embeddings,
    )


def fragment_to_original(
    fragment_id: str,
    test_ids: set[str],
):
    """
    Project design:
        original -> original_1 ... original_5

    A suffix is removed ONLY if the stripped candidate exists in test_ids.txt.
    This prevents accidental stripping of genuine underscores/numbers in IDs.
    """

    fragment_id = canonical_id(
        fragment_id
    )

    if fragment_id in test_ids:
        return (
            fragment_id,
            "",
        )

    patterns = (
        r"^(.*)_([1-9][0-9]*)$",
        r"^(.*)\.part([1-9][0-9]*)$",
        r"^(.*)_part([1-9][0-9]*)$",
        r"^(.*)\|part([1-9][0-9]*)$",
        r"^(.*)-part([1-9][0-9]*)$",
    )

    for pattern in patterns:
        match = re.match(
            pattern,
            fragment_id,
            flags=re.IGNORECASE,
        )

        if match:
            candidate = canonical_id(
                match.group(1)
            )

            part = str(
                match.group(2)
            )

            if candidate in test_ids:
                return (
                    candidate,
                    part,
                )

    return (
        None,
        "",
    )


# =============================================================================
# Inference
# =============================================================================

def amp_context(
    enabled: bool,
):
    return torch.autocast(
        device_type="cuda",
        dtype=torch.float16,
        enabled=enabled,
    )


@torch.inference_mode()
def infer_embeddings(
    model: DNAStudent,
    embeddings: torch.Tensor,
    batch_size: int,
    threshold: float,
    use_amp: bool,
    device: torch.device,
):

    pred_binary_all = []
    pred_arg_all = []
    arg_probability_all = []
    subtype_probability_all = []
    feature_all = []

    for start in range(
        0,
        embeddings.shape[0],
        batch_size,
    ):

        xb = embeddings[
            start:
            start
            + batch_size
        ].to(
            device,
            non_blocking=True,
        )

        with amp_context(
            use_amp
        ):
            (
                binary_logits,
                arg_logits,
                z,
            ) = model(
                xb
            )

        binary_prob = torch.softmax(
            binary_logits.float(),
            dim=1,
        )

        arg_prob = torch.softmax(
            arg_logits.float(),
            dim=1,
        )

        pred_binary = (
            binary_prob[
                :,
                1
            ]
            >= threshold
        ).long()

        (
            subtype_probability,
            pred_arg,
        ) = arg_prob.max(
            dim=1
        )

        pred_binary_all.append(
            pred_binary.cpu()
        )

        pred_arg_all.append(
            pred_arg.cpu()
        )

        arg_probability_all.append(
            binary_prob[
                :,
                1
            ].cpu()
        )

        subtype_probability_all.append(
            subtype_probability.cpu()
        )

        feature_all.append(
            z.float().cpu()
        )

    return {
        "pred_binary":
            torch.cat(
                pred_binary_all
            ),

        "pred_arg":
            torch.cat(
                pred_arg_all
            ),

        "ARG_probability":
            torch.cat(
                arg_probability_all
            ),

        "ARG_subtype_probability":
            torch.cat(
                subtype_probability_all
            ),

        "features":
            torch.cat(
                feature_all
            ),
    }


# =============================================================================
# Metrics
# =============================================================================

def metrics_from_indices(
    true_binary,
    true_arg,
    pred_binary,
    pred_arg,
):

    true_full = np.where(
        true_binary == 0,
        0,
        true_arg + 1,
    )

    pred_full = np.where(
        pred_binary == 0,
        0,
        pred_arg + 1,
    )

    arg_mask = (
        true_binary == 1
    )

    return {
        "ARG_nonARG":
            metric_dict(
                true_binary,
                pred_binary,
            ),

        "ARG_Subtype":
            metric_dict(
                true_arg[
                    arg_mask
                ],
                pred_arg[
                    arg_mask
                ],
            ),

        "End_to_end":
            metric_dict(
                true_full,
                pred_full,
            ),
    }


def summary_metric_rows(
    condition,
    sequence_level,
    metrics,
):

    rows = []

    for task in (
        "ARG_nonARG",
        "ARG_Subtype",
        "End_to_end",
    ):

        values = metrics[
            task
        ]

        row = {
            "modality":
                "DNA",

            "model":
                "ARGScope-DNA_final_newsplit",

            "condition":
                condition,

            "sequence_level":
                sequence_level,

            "task":
                task,

            **values,
        }

        rows.append(
            row
        )

    return rows


def one_vs_rest_metrics(
    condition,
    sequence_level,
    true_labels,
    predicted_labels,
    class_names,
    class_column,
):

    true_array = np.asarray(
        true_labels,
        dtype=object,
    )

    predicted_array = np.asarray(
        predicted_labels,
        dtype=object,
    )

    total = len(
        true_array
    )

    rows = []

    for class_name in class_names:

        true_positive = (
            true_array
            == class_name
        )

        predicted_positive = (
            predicted_array
            == class_name
        )

        tp = int(
            np.sum(
                true_positive
                & predicted_positive
            )
        )

        fp = int(
            np.sum(
                ~true_positive
                & predicted_positive
            )
        )

        fn = int(
            np.sum(
                true_positive
                & ~predicted_positive
            )
        )

        tn = int(
            total
            - tp
            - fp
            - fn
        )

        precision = (
            tp
            / (
                tp
                + fp
            )
            if (
                tp
                + fp
            )
            else 0.0
        )

        recall = (
            tp
            / (
                tp
                + fn
            )
            if (
                tp
                + fn
            )
            else 0.0
        )

        specificity = (
            tn
            / (
                tn
                + fp
            )
            if (
                tn
                + fp
            )
            else 0.0
        )

        f1 = (
            2.0
            * precision
            * recall
            / (
                precision
                + recall
            )
            if (
                precision
                + recall
            )
            else 0.0
        )

        rows.append(
            {
                "modality":
                    "DNA",

                "model":
                    "ARGScope-DNA_final_newsplit",

                "condition":
                    condition,

                "sequence_level":
                    sequence_level,

                class_column:
                    class_name,

                "ACC":
                    (
                        (
                            tp
                            + tn
                        )
                        / total
                        if total
                        else 0.0
                    ),

                "Precision":
                    precision,

                "Recall":
                    recall,

                "Specificity":
                    specificity,

                "F1":
                    f1,

                "MCC":
                    safe_mcc(
                        true_positive.astype(
                            np.int64
                        ),
                        predicted_positive.astype(
                            np.int64
                        ),
                    ),

                "support":
                    int(
                        tp
                        + fn
                    ),

                "predicted_count":
                    int(
                        tp
                        + fp
                    ),

                "TP":
                    tp,

                "FP":
                    fp,

                "FN":
                    fn,

                "TN":
                    tn,

                "total_samples":
                    total,

                "coverage":
                    1.0,
            }
        )

    return rows


def build_level_tables(
    condition,
    sequence_level,
    rows,
    arg_names,
    subtype_to_type,
):

    true_subtype = [
        row[
            "true_subtype"
        ]
        for row in rows
    ]

    predicted_subtype = [
        row[
            "predicted_subtype"
        ]
        for row in rows
    ]

    subtype_rows = one_vs_rest_metrics(
        condition,
        sequence_level,
        true_subtype,
        predicted_subtype,
        arg_names,
        "Subtype",
    )

    type_names = sorted(
        {
            subtype_to_type[
                name
            ]
            for name in arg_names
            if name in subtype_to_type
        },
        key=str.lower,
    )

    true_type = [
        row[
            "true_type"
        ]
        for row in rows
    ]

    predicted_type = [
        row[
            "predicted_type"
        ]
        for row in rows
    ]

    type_rows = one_vs_rest_metrics(
        condition,
        sequence_level,
        true_type,
        predicted_type,
        type_names,
        "Type",
    )

    true_binary = [
        (
            NONARG
            if is_nonarg(
                value
            )
            else "ARG"
        )
        for value in true_subtype
    ]

    predicted_binary = [
        (
            NONARG
            if is_nonarg(
                value
            )
            else "ARG"
        )
        for value in predicted_subtype
    ]

    binary_rows = one_vs_rest_metrics(
        condition,
        sequence_level,
        true_binary,
        predicted_binary,
        [
            "ARG",
            NONARG,
        ],
        "Class",
    )

    return (
        subtype_rows,
        type_rows,
        binary_rows,
    )


# =============================================================================
# One condition
# =============================================================================

def process_condition(
    condition,
    args,
    model,
    arg_names,
    subtype_to_type,
    threshold,
    test_ids_ordered,
    truth,
    use_amp,
    device,
):

    input_folder = (
        args.embedding_root
        / condition
    )

    output_folder = (
        args.output_root
        / condition
    )

    output_folder.mkdir(
        parents=True,
        exist_ok=True,
    )

    pt_files = discover_pt_files(
        input_folder
    )

    test_id_set = set(
        test_ids_ordered
    )

    arg_to_index = {
        name:
            index
        for index, name
        in enumerate(
            arg_names
        )
    }

    print(
        "\n"
        + "=" * 110
    )
    print(
        f"DNA CONDITION: {condition}"
    )
    print(
        "=" * 110
    )
    print(
        f"Embedding folder : {input_folder}"
    )
    print(
        f"PT file count    : {len(pt_files)}"
    )

    for path in pt_files:
        print(
            f"  - {path.name}"
        )

    seen_fragment_ids = set()

    all_rows = []
    feature_chunks = []

    true_binary_all = []
    true_arg_all = []
    pred_binary_all = []
    pred_arg_all = []
    originals_all = []

    for file_index, pt_path in enumerate(
        pt_files,
        start=1,
    ):

        (
            ids,
            embeddings,
        ) = extract_embedding_pt(
            pt_path
        )

        duplicate_across = [
            seq_id
            for seq_id in ids
            if seq_id in seen_fragment_ids
        ]

        if duplicate_across:
            raise ValueError(
                f"Duplicate fragment IDs across PT files: "
                f"{duplicate_across[:10]}"
            )

        seen_fragment_ids.update(
            ids
        )

        selected_local = []
        metadata_rows = []

        for local_index, fragment_id in enumerate(
            ids
        ):

            (
                original_id,
                simulation_part,
            ) = fragment_to_original(
                fragment_id,
                test_id_set,
            )

            if original_id is None:
                continue

            if original_id not in truth:
                raise ValueError(
                    f"TEST ID {original_id} has no true label "
                    f"in {args.test_labels}"
                )

            (
                true_subtype,
                true_type,
            ) = truth[
                original_id
            ]

            if is_nonarg(
                true_subtype
            ):
                true_type = NONARG

            elif true_subtype not in arg_to_index:
                raise ValueError(
                    f"True ARG subtype absent from model: "
                    f"{true_subtype}; original={original_id}"
                )

            authoritative_type = subtype_to_type.get(
                true_subtype,
                true_type,
            )

            if (
                true_type
                and authoritative_type
                != true_type
            ):
                raise ValueError(
                    f"Subtype-Type mismatch: "
                    f"subtype={true_subtype}; "
                    f"checkpoint={authoritative_type}; "
                    f"test_csv={true_type}"
                )

            selected_local.append(
                local_index
            )

            metadata_rows.append(
                {
                    "fragment_id":
                        fragment_id,

                    "original_id":
                        original_id,

                    "simulation_part":
                        simulation_part,

                    "true_subtype":
                        true_subtype,

                    "true_type":
                        authoritative_type,
                }
            )

        if not selected_local:

            print(
                f"[{condition}] "
                f"PT {file_index}/{len(pt_files)}: "
                "0 TEST fragments, skipped"
            )

            continue

        selected_embeddings = embeddings.index_select(
            0,
            torch.tensor(
                selected_local,
                dtype=torch.long,
            ),
        )

        inference = infer_embeddings(
            model=model,
            embeddings=selected_embeddings,
            batch_size=args.batch_size,
            threshold=threshold,
            use_amp=use_amp,
            device=device,
        )

        for local_index, metadata in enumerate(
            metadata_rows
        ):

            true_subtype = metadata[
                "true_subtype"
            ]

            true_binary = (
                0
                if is_nonarg(
                    true_subtype
                )
                else 1
            )

            true_arg = (
                -1
                if true_binary == 0
                else arg_to_index[
                    true_subtype
                ]
            )

            pred_binary = int(
                inference[
                    "pred_binary"
                ][
                    local_index
                ].item()
            )

            pred_arg = int(
                inference[
                    "pred_arg"
                ][
                    local_index
                ].item()
            )

            predicted_subtype = (
                NONARG
                if pred_binary == 0
                else arg_names[
                    pred_arg
                ]
            )

            if predicted_subtype not in subtype_to_type:
                raise ValueError(
                    f"No Type mapping for predicted subtype: "
                    f"{predicted_subtype}"
                )

            predicted_type = subtype_to_type[
                predicted_subtype
            ]

            row = {
                "modality":
                    "DNA",

                "model":
                    "ARGScope-DNA_final_newsplit",

                "condition":
                    condition,

                "sequence_level":
                    "fragment",

                "fragment_id":
                    metadata[
                        "fragment_id"
                    ],

                "original_id":
                    metadata[
                        "original_id"
                    ],

                "simulation_part":
                    metadata[
                        "simulation_part"
                    ],

                "true_subtype":
                    true_subtype,

                "predicted_subtype":
                    predicted_subtype,

                "true_type":
                    metadata[
                        "true_type"
                    ],

                "predicted_type":
                    predicted_type,

                "true_ARG":
                    true_binary,

                "predicted_ARG":
                    pred_binary,

                "ARG_probability":
                    float(
                        inference[
                            "ARG_probability"
                        ][
                            local_index
                        ].item()
                    ),

                "ARG_subtype_max_probability":
                    float(
                        inference[
                            "ARG_subtype_probability"
                        ][
                            local_index
                        ].item()
                    ),

                "binary_threshold":
                    float(
                        threshold
                    ),

                "source_pt":
                    pt_path.name,
            }

            all_rows.append(
                row
            )

            true_binary_all.append(
                true_binary
            )

            true_arg_all.append(
                true_arg
            )

            pred_binary_all.append(
                pred_binary
            )

            pred_arg_all.append(
                pred_arg
            )

            originals_all.append(
                metadata[
                    "original_id"
                ]
            )

        feature_chunks.append(
            inference[
                "features"
            ]
        )

        print(
            f"[{condition}] "
            f"PT {file_index}/{len(pt_files)} | "
            f"rows={len(ids):,} | "
            f"TEST rows={len(metadata_rows):,} | "
            f"cumulative TEST={len(all_rows):,}"
        )

        del (
            embeddings,
            selected_embeddings,
            inference,
        )

        torch.cuda.empty_cache()

    if not all_rows:
        raise RuntimeError(
            f"No TEST fragments found: "
            f"{condition}"
        )

    features = torch.cat(
        feature_chunks,
        dim=0,
    )

    if features.shape[0] != len(
        all_rows
    ):
        raise RuntimeError(
            "Feature/prediction row mismatch."
        )

    # -------------------------------------------------------------------------
    # Coverage
    # -------------------------------------------------------------------------

    fragment_counts = Counter(
        originals_all
    )

    observed_originals = set(
        fragment_counts
    )

    missing_originals = (
        set(
            test_ids_ordered
        )
        - observed_originals
    )

    complete_originals = {
        original_id
        for original_id, count
        in fragment_counts.items()
        if count
        == args.expected_parts
    }

    incomplete_originals = {
        original_id
        for original_id, count
        in fragment_counts.items()
        if count
        != args.expected_parts
    }

    coverage_rows = []

    for original_id in test_ids_ordered:

        count = int(
            fragment_counts.get(
                original_id,
                0,
            )
        )

        coverage_rows.append(
            {
                "condition":
                    condition,

                "original_id":
                    original_id,

                "fragment_count":
                    count,

                "expected_parts":
                    int(
                        args.expected_parts
                    ),

                "is_complete":
                    int(
                        count
                        == args.expected_parts
                    ),

                "is_missing":
                    int(
                        count == 0
                    ),
            }
        )

    write_csv(
        output_folder
        / "coverage_qc_by_original.csv",
        coverage_rows,
    )

    coverage_summary = {
        "condition":
            condition,

        "test_originals_expected":
            len(
                test_ids_ordered
            ),

        "test_originals_observed":
            len(
                observed_originals
            ),

        "test_originals_complete":
            len(
                complete_originals
            ),

        "test_originals_incomplete_nonzero":
            len(
                incomplete_originals
            ),

        "test_originals_missing":
            len(
                missing_originals
            ),

        "test_fragments_observed":
            len(
                all_rows
            ),

        "expected_parts_per_original":
            int(
                args.expected_parts
            ),

        "fragment_count_distribution":
            {
                str(key):
                    int(value)
                for key, value
                in sorted(
                    Counter(
                        fragment_counts.values()
                    ).items()
                )
            },

        "missing_original_examples":
            sorted(
                missing_originals
            )[
                :20
            ],

        "incomplete_original_examples":
            sorted(
                incomplete_originals
            )[
                :20
            ],
    }

    with (
        output_folder
        / "coverage_summary.json"
    ).open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            json_safe(
                coverage_summary
            ),
            handle,
            ensure_ascii=False,
            indent=2,
        )

    print(
        f"TEST fragments      : {len(all_rows):,}"
    )
    print(
        f"TEST originals seen : "
        f"{len(observed_originals):,}/"
        f"{len(test_ids_ordered):,}"
    )
    print(
        f"Complete originals  : "
        f"{len(complete_originals):,}"
    )
    print(
        f"Incomplete originals: "
        f"{len(incomplete_originals):,}"
    )
    print(
        f"Missing originals   : "
        f"{len(missing_originals):,}"
    )
    print(
        f"Fragments/original  : "
        f"{dict(sorted(Counter(fragment_counts.values()).items()))}"
    )

    # -------------------------------------------------------------------------
    # Fragment metrics
    # -------------------------------------------------------------------------

    fragment_metrics = metrics_from_indices(
        np.asarray(
            true_binary_all,
            dtype=np.int64,
        ),
        np.asarray(
            true_arg_all,
            dtype=np.int64,
        ),
        np.asarray(
            pred_binary_all,
            dtype=np.int64,
        ),
        np.asarray(
            pred_arg_all,
            dtype=np.int64,
        ),
    )

    fragment_metric_rows = summary_metric_rows(
        condition,
        "fragment",
        fragment_metrics,
    )

    (
        fragment_subtype_rows,
        fragment_type_rows,
        fragment_binary_rows,
    ) = build_level_tables(
        condition,
        "fragment",
        all_rows,
        arg_names,
        subtype_to_type,
    )

    write_csv(
        output_folder
        / "DNA_fragment_test_predictions.csv",
        all_rows,
    )

    write_csv(
        output_folder
        / "DNA_fragment_test_metrics.csv",
        fragment_metric_rows,
    )

    write_csv(
        output_folder
        / "DNA_fragment_subtype_level_metrics.csv",
        fragment_subtype_rows,
    )

    write_csv(
        output_folder
        / "DNA_fragment_type_level_metrics.csv",
        fragment_type_rows,
    )

    write_csv(
        output_folder
        / "DNA_fragment_ARG_nonARG_level_metrics.csv",
        fragment_binary_rows,
    )

    # -------------------------------------------------------------------------
    # Original-level aggregation:
    # mean 5 DNA Student 512D z -> L2 normalize -> SAME trained heads.
    # -------------------------------------------------------------------------

    original_to_feature_indices = defaultdict(
        list
    )

    original_truth = {}

    for index, row in enumerate(
        all_rows
    ):

        original_id = row[
            "original_id"
        ]

        original_to_feature_indices[
            original_id
        ].append(
            index
        )

        current_truth = (
            row[
                "true_subtype"
            ],
            row[
                "true_type"
            ],
        )

        previous = original_truth.setdefault(
            original_id,
            current_truth,
        )

        if previous != current_truth:
            raise ValueError(
                f"Inconsistent labels within original "
                f"{original_id}: "
                f"{previous} vs {current_truth}"
            )

    if args.allow_incomplete_originals:

        selected_originals = [
            original_id
            for original_id
            in test_ids_ordered
            if fragment_counts.get(
                original_id,
                0,
            ) > 0
        ]

        original_level = (
            "original_mean_available_parts"
        )

    else:

        selected_originals = [
            original_id
            for original_id
            in test_ids_ordered
            if fragment_counts.get(
                original_id,
                0,
            ) == args.expected_parts
        ]

        original_level = (
            f"original_mean_"
            f"{args.expected_parts}"
            f"parts"
        )

    if not selected_originals:
        raise RuntimeError(
            f"No originals available for original-level "
            f"evaluation: {condition}"
        )

    original_feature_rows = []

    for original_id in selected_originals:

        selected_indices = torch.tensor(
            original_to_feature_indices[
                original_id
            ],
            dtype=torch.long,
        )

        z = features.index_select(
            0,
            selected_indices,
        ).mean(
            dim=0
        )

        original_feature_rows.append(
            z
        )

    original_features = F.normalize(
        torch.stack(
            original_feature_rows,
            dim=0,
        ),
        p=2,
        dim=1,
    )

    original_pred_binary = []
    original_pred_arg = []
    original_arg_probability = []
    original_subtype_probability = []

    with torch.inference_mode():

        for start in range(
            0,
            len(
                selected_originals
            ),
            args.batch_size,
        ):

            z = original_features[
                start:
                start
                + args.batch_size
            ].to(
                device,
                non_blocking=True,
            )

            with amp_context(
                use_amp
            ):

                binary_logits = model.binary_head(
                    z
                )

                arg_logits = model.arg_head(
                    z
                )

            binary_prob = torch.softmax(
                binary_logits.float(),
                dim=1,
            )

            arg_prob = torch.softmax(
                arg_logits.float(),
                dim=1,
            )

            pred_binary = (
                binary_prob[
                    :,
                    1
                ]
                >= threshold
            ).long()

            (
                subtype_probability,
                pred_arg,
            ) = arg_prob.max(
                dim=1
            )

            original_pred_binary.extend(
                pred_binary
                .cpu()
                .tolist()
            )

            original_pred_arg.extend(
                pred_arg
                .cpu()
                .tolist()
            )

            original_arg_probability.extend(
                binary_prob[
                    :,
                    1
                ]
                .cpu()
                .tolist()
            )

            original_subtype_probability.extend(
                subtype_probability
                .cpu()
                .tolist()
            )

    original_rows = []
    original_true_binary = []
    original_true_arg = []

    for index, original_id in enumerate(
        selected_originals
    ):

        (
            true_subtype,
            true_type,
        ) = original_truth[
            original_id
        ]

        true_binary = (
            0
            if is_nonarg(
                true_subtype
            )
            else 1
        )

        true_arg = (
            -1
            if true_binary == 0
            else arg_to_index[
                true_subtype
            ]
        )

        pred_binary = int(
            original_pred_binary[
                index
            ]
        )

        pred_arg = int(
            original_pred_arg[
                index
            ]
        )

        predicted_subtype = (
            NONARG
            if pred_binary == 0
            else arg_names[
                pred_arg
            ]
        )

        predicted_type = subtype_to_type[
            predicted_subtype
        ]

        original_rows.append(
            {
                "modality":
                    "DNA",

                "model":
                    "ARGScope-DNA_final_newsplit",

                "condition":
                    condition,

                "sequence_level":
                    original_level,

                "original_id":
                    original_id,

                "fragment_count":
                    int(
                        fragment_counts[
                            original_id
                        ]
                    ),

                "true_subtype":
                    true_subtype,

                "predicted_subtype":
                    predicted_subtype,

                "true_type":
                    true_type,

                "predicted_type":
                    predicted_type,

                "true_ARG":
                    true_binary,

                "predicted_ARG":
                    pred_binary,

                "ARG_probability":
                    float(
                        original_arg_probability[
                            index
                        ]
                    ),

                "ARG_subtype_max_probability":
                    float(
                        original_subtype_probability[
                            index
                        ]
                    ),

                "binary_threshold":
                    float(
                        threshold
                    ),
            }
        )

        original_true_binary.append(
            true_binary
        )

        original_true_arg.append(
            true_arg
        )

    original_metrics = metrics_from_indices(
        np.asarray(
            original_true_binary,
            dtype=np.int64,
        ),
        np.asarray(
            original_true_arg,
            dtype=np.int64,
        ),
        np.asarray(
            original_pred_binary,
            dtype=np.int64,
        ),
        np.asarray(
            original_pred_arg,
            dtype=np.int64,
        ),
    )

    original_metric_rows = summary_metric_rows(
        condition,
        original_level,
        original_metrics,
    )

    (
        original_subtype_rows,
        original_type_rows,
        original_binary_rows,
    ) = build_level_tables(
        condition,
        original_level,
        original_rows,
        arg_names,
        subtype_to_type,
    )

    write_csv(
        output_folder
        / "DNA_original_mean_test_predictions.csv",
        original_rows,
    )

    write_csv(
        output_folder
        / "DNA_original_mean_test_metrics.csv",
        original_metric_rows,
    )

    write_csv(
        output_folder
        / "DNA_original_mean_subtype_level_metrics.csv",
        original_subtype_rows,
    )

    write_csv(
        output_folder
        / "DNA_original_mean_type_level_metrics.csv",
        original_type_rows,
    )

    write_csv(
        output_folder
        / "DNA_original_mean_ARG_nonARG_level_metrics.csv",
        original_binary_rows,
    )

    print(
        "\n===== CONDITION METRICS ====="
    )

    fragment_e2e = fragment_metrics[
        "End_to_end"
    ]

    print(
        f"fragment End_to_end | "
        f"n={fragment_e2e['n']:,} | "
        f"ACC={fragment_e2e['accuracy']:.6f} | "
        f"weighted_P={fragment_e2e['weighted_precision']:.6f} | "
        f"weighted_F1={fragment_e2e['weighted_f1']:.6f} | "
        f"MCC={fragment_e2e['mcc']:.6f}"
    )

    original_e2e = original_metrics[
        "End_to_end"
    ]

    print(
        f"{original_level} End_to_end | "
        f"n={original_e2e['n']:,} | "
        f"ACC={original_e2e['accuracy']:.6f} | "
        f"weighted_P={original_e2e['weighted_precision']:.6f} | "
        f"weighted_F1={original_e2e['weighted_f1']:.6f} | "
        f"MCC={original_e2e['mcc']:.6f}"
    )

    return (
        fragment_metric_rows,
        original_metric_rows,
        coverage_summary,
    )


# =============================================================================
# Final combined tables
# =============================================================================

def build_final_tables(
    output_root: Path,
    all_metric_rows,
):

    condition_order = {
        "percent_60": 60,
        "percent_70": 70,
        "percent_80": 80,
        "percent_90": 90,
    }

    task_order = {
        "ARG_nonARG": 0,
        "ARG_Subtype": 1,
        "End_to_end": 2,
    }

    rows = []

    for source in all_metric_rows:

        row = dict(
            source
        )

        row[
            "length_percent"
        ] = condition_order[
            row[
                "condition"
            ]
        ]

        rows.append(
            row
        )

    rows.sort(
        key=lambda row:
            (
                condition_order[
                    row[
                        "condition"
                    ]
                ],
                (
                    0
                    if row[
                        "sequence_level"
                    ]
                    == "fragment"
                    else 1
                ),
                task_order[
                    row[
                        "task"
                    ]
                ],
            )
    )

    write_csv(
        output_root
        / "FINAL_SUMMARY_DNA_percent60_90_local.csv",
        rows,
    )

    end_rows = [
        row
        for row in rows
        if row[
            "task"
        ]
        == "End_to_end"
    ]

    write_csv(
        output_root
        / "FINAL_END_TO_END_DNA_percent60_90_local.csv",
        end_rows,
    )

    metric_names = (
        "n",
        "accuracy",
        "macro_precision",
        "weighted_precision",
        "micro_precision",
        "macro_recall",
        "weighted_recall",
        "micro_recall",
        "macro_f1",
        "weighted_f1",
        "micro_f1",
        "mcc",
    )

    wide_rows = []

    for condition in CONDITIONS:

        condition_rows = [
            row
            for row in end_rows
            if row[
                "condition"
            ]
            == condition
        ]

        if not condition_rows:
            continue

        wide = {
            "modality":
                "DNA",

            "model":
                "ARGScope-DNA_final_newsplit",

            "condition":
                condition,

            "length_percent":
                condition_order[
                    condition
                ],
        }

        for row in condition_rows:

            prefix = (
                "fragment"
                if row[
                    "sequence_level"
                ]
                == "fragment"
                else "original"
            )

            wide[
                f"{prefix}_sequence_level"
            ] = row[
                "sequence_level"
            ]

            for metric_name in metric_names:

                wide[
                    f"{prefix}_{metric_name}"
                ] = row[
                    metric_name
                ]

        wide_rows.append(
            wide
        )

    write_csv(
        output_root
        / "FINAL_END_TO_END_WIDE_DNA_percent60_90_local.csv",
        wide_rows,
    )


# =============================================================================
# Main
# =============================================================================

def main():

    args = parse_args()

    args.base_dir = (
        args.base_dir
        .expanduser()
        .resolve()
    )

    if args.model is None:
        args.model = detect_model(
            args.base_dir
        )

    if args.embedding_root is None:
        args.embedding_root = detect_embedding_root(
            args.base_dir
        )

    if args.test_ids is None:
        args.test_ids = (
            args.base_dir
            / "test_ids.txt"
        )

    if args.test_labels is None:
        args.test_labels = (
            args.base_dir
            / "test_sequence_predictions.csv"
        )

    if args.output_root is None:
        args.output_root = (
            args.base_dir
            / "DNA_percent60_90_local_results"
        )

    args.model = (
        args.model
        .expanduser()
        .resolve()
    )

    args.embedding_root = (
        args.embedding_root
        .expanduser()
        .resolve()
    )

    args.test_ids = (
        args.test_ids
        .expanduser()
        .resolve()
    )

    args.test_labels = (
        args.test_labels
        .expanduser()
        .resolve()
    )

    args.output_root = (
        args.output_root
        .expanduser()
        .resolve()
    )

    print(
        "=" * 110
    )
    print(
        "ARGScope DNA LOCAL PERCENT_60/70/80/90 INFERENCE"
    )
    print(
        "=" * 110
    )
    print(
        f"Script version : {SCRIPT_VERSION}"
    )
    print(
        f"Base directory : {args.base_dir}"
    )
    print(
        f"Model          : {args.model}"
    )
    print(
        f"Embedding root : {args.embedding_root}"
    )
    print(
        f"TEST IDs       : {args.test_ids}"
    )
    print(
        f"TEST truth     : {args.test_labels}"
    )
    print(
        f"Output root    : {args.output_root}"
    )
    print(
        f"Conditions     : {args.conditions}"
    )
    print(
        f"Batch size     : {args.batch_size:,}"
    )

    if not args.model.is_file():
        raise FileNotFoundError(
            f"DNA model not found: "
            f"{args.model}"
        )

    if not args.embedding_root.is_dir():
        raise FileNotFoundError(
            f"DNABERT-2 embedding root not found: "
            f"{args.embedding_root}"
        )

    if not args.test_ids.is_file():
        raise FileNotFoundError(
            f"test_ids.txt not found: "
            f"{args.test_ids}"
        )

    if not args.test_labels.is_file():
        raise FileNotFoundError(
            f"test_sequence_predictions.csv not found: "
            f"{args.test_labels}"
        )

    if args.batch_size < 1:
        raise ValueError(
            "--batch-size must be >= 1"
        )

    if args.expected_parts < 1:
        raise ValueError(
            "--expected-parts must be >= 1"
        )

    if args.output_root.exists():

        if args.overwrite:
            shutil.rmtree(
                args.output_root
            )

        elif any(
            args.output_root.iterdir()
        ):
            raise FileExistsError(
                f"Output directory is not empty:\n"
                f"{args.output_root}\n"
                f"Rerun with --overwrite to replace it."
            )

    args.output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA unavailable. CPU fallback is disabled."
        )

    torch.cuda.set_device(
        0
    )

    device = torch.device(
        "cuda:0"
    )

    use_amp = (
        not args.no_amp
    )

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    try:
        torch.set_float32_matmul_precision(
            "high"
        )
    except Exception:
        pass

    print(
        "\n===== GPU ====="
    )
    print(
        f"torch        : {torch.__version__}"
    )
    print(
        f"CUDA runtime : {torch.version.cuda}"
    )
    print(
        f"GPU          : {torch.cuda.get_device_name(0)}"
    )

    try:
        properties = torch.cuda.get_device_properties(
            0
        )

        print(
            f"VRAM         : "
            f"{properties.total_memory/(1024**3):.2f} GiB"
        )

    except Exception:
        pass

    print(
        f"AMP          : {use_amp}"
    )

    started = time.time()

    (
        model,
        checkpoint,
        arg_names,
        subtype_to_type,
        threshold,
        model_config,
    ) = load_model(
        args.model,
        device,
    )

    test_ids_ordered = read_test_ids(
        args.test_ids
    )

    truth = load_test_truth(
        args.test_labels
    )

    test_id_set = set(
        test_ids_ordered
    )

    truth_id_set = set(
        truth
    )

    missing_truth = (
        test_id_set
        - truth_id_set
    )

    if missing_truth:
        raise ValueError(
            f"{len(missing_truth):,} TEST IDs lack true labels "
            f"in test_sequence_predictions.csv. "
            f"Examples={sorted(missing_truth)[:20]}"
        )

    extra_truth = (
        truth_id_set
        - test_id_set
    )

    if extra_truth:
        print(
            f"[NOTE] Ignoring {len(extra_truth):,} "
            f"truth rows not listed in test_ids.txt."
        )

    # Complete/cross-check subtype -> Type mapping.
    for original_id in test_ids_ordered:

        (
            subtype,
            type_name,
        ) = truth[
            original_id
        ]

        if is_nonarg(
            subtype
        ):
            type_name = NONARG

        if subtype in subtype_to_type:

            if (
                type_name
                and subtype_to_type[
                    subtype
                ]
                != type_name
            ):
                raise ValueError(
                    f"Subtype-Type mapping disagreement for "
                    f"{subtype}: checkpoint="
                    f"{subtype_to_type[subtype]}, "
                    f"test_csv={type_name}"
                )

        else:

            if not type_name:
                raise ValueError(
                    f"No Type mapping for "
                    f"subtype={subtype}"
                )

            subtype_to_type[
                subtype
            ] = type_name

    missing_mapping = [
        subtype
        for subtype in arg_names
        if subtype not in subtype_to_type
    ]

    if missing_mapping:
        raise ValueError(
            f"{len(missing_mapping):,} model ARG subtypes "
            f"lack Type mapping. "
            f"Examples={missing_mapping[:20]}"
        )

    print(
        "\n===== TEST SPLIT ====="
    )
    print(
        f"TEST originals : "
        f"{len(test_ids_ordered):,}"
    )
    print(
        f"Truth matched  : "
        f"{len(test_id_set & truth_id_set):,}"
    )
    print(
        f"ARG subtypes   : "
        f"{len(arg_names):,}"
    )

    all_metric_rows = []
    coverage_summaries = []

    for condition in args.conditions:

        (
            fragment_rows,
            original_rows,
            coverage_summary,
        ) = process_condition(
            condition=condition,
            args=args,
            model=model,
            arg_names=arg_names,
            subtype_to_type=subtype_to_type,
            threshold=threshold,
            test_ids_ordered=test_ids_ordered,
            truth=truth,
            use_amp=use_amp,
            device=device,
        )

        all_metric_rows.extend(
            fragment_rows
        )

        all_metric_rows.extend(
            original_rows
        )

        coverage_summaries.append(
            coverage_summary
        )

    build_final_tables(
        args.output_root,
        all_metric_rows,
    )

    run_summary = {
        "script_version":
            SCRIPT_VERSION,

        "base_dir":
            args.base_dir,

        "model_checkpoint":
            args.model,

        "training_script_version":
            checkpoint.get(
                "script_version",
                "NA",
            ),

        "embedding_root":
            args.embedding_root,

        "test_ids":
            args.test_ids,

        "test_labels":
            args.test_labels,

        "output_root":
            args.output_root,

        "conditions":
            list(
                args.conditions
            ),

        "test_original_count":
            len(
                test_ids_ordered
            ),

        "arg_subtype_count":
            len(
                arg_names
            ),

        "binary_threshold":
            threshold,

        "model_config":
            {
                "hidden_dim":
                    model_config.hidden_dim,

                "embedding_dim":
                    model_config.embedding_dim,

                "dropout":
                    model_config.dropout,

                "logit_scale_binary":
                    model_config.logit_scale_binary,

                "logit_scale_subtype":
                    model_config.logit_scale_subtype,
            },

        "expected_parts":
            int(
                args.expected_parts
            ),

        "allow_incomplete_originals":
            bool(
                args.allow_incomplete_originals
            ),

        "coverage":
            coverage_summaries,

        "gpu":
            torch.cuda.get_device_name(
                0
            ),

        "torch_version":
            torch.__version__,

        "cuda_version":
            torch.version.cuda,

        "amp":
            use_amp,

        "elapsed_minutes":
            (
                time.time()
                - started
            )
            / 60.0,

        "peak_gpu_memory_GiB":
            torch.cuda.max_memory_allocated(
                0
            )
            / (
                1024
                ** 3
            ),
    }

    with (
        args.output_root
        / "run_summary.json"
    ).open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            json_safe(
                run_summary
            ),
            handle,
            ensure_ascii=False,
            indent=2,
        )

    print(
        "\n"
        + "=" * 110
    )
    print(
        "ALL DNA CONDITIONS COMPLETED"
    )
    print(
        "=" * 110
    )
    print(
        "FINAL summary : "
        f"{args.output_root / 'FINAL_SUMMARY_DNA_percent60_90_local.csv'}"
    )
    print(
        "FINAL E2E     : "
        f"{args.output_root / 'FINAL_END_TO_END_DNA_percent60_90_local.csv'}"
    )
    print(
        "FINAL wide    : "
        f"{args.output_root / 'FINAL_END_TO_END_WIDE_DNA_percent60_90_local.csv'}"
    )
    print(
        f"Elapsed       : "
        f"{(time.time()-started)/60.0:.3f} min"
    )
    print(
        f"Peak GPU mem  : "
        f"{torch.cuda.max_memory_allocated(0)/(1024**3):.3f} GiB"
    )


if __name__ == "__main__":
    main()
