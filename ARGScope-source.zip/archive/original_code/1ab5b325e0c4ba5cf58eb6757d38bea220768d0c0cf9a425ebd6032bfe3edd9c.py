#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Select Mutual-KNN K and train residual GAT refined ARG subtype prototypes.

Inputs
------
1. Train-only raw prototype/baseline PT.
2. Supervised gated-fusion PT (needed for fragment-level validation/test).

Leakage control
---------------
* Graph nodes and graph edges come only from train-only raw prototypes.
* GAT optimization uses only model-train ARG original-sequence embeddings.
* K and early stopping are selected only by validation fragment macro-F1.
* Test is evaluated exactly once after K and the best epoch are fixed.
* nonARG is excluded from the ARG subtype graph.

Output
------
Exactly one PT containing the selected refined [484, 512] prototypes, graph,
model state, validation selection results, and final validation/test metrics.
No CSV, JSON, plot, or separate checkpoint is created.
"""

from __future__ import annotations

import argparse
import math
import os
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_RAW_PT = (
    SCRIPT_DIR
    / "Raw_subtype_prototypes_50aa_150nt"
    / "raw_ARG_subtype_prototypes_and_baseline.pt"
)
DEFAULT_FUSED_PT = (
    SCRIPT_DIR
    / "Gated_fusion_50aa_150nt_supervised"
    / "all_50aa_150nt_supervised_gated_fused_embeddings.pt"
)
DEFAULT_OUTPUT_PT = (
    SCRIPT_DIR
    / "Refined_subtype_prototypes_50aa_150nt"
    / "refined_ARG_subtype_prototypes_residual_GAT.pt"
)
SCRIPT_VERSION = "2026-08-17-mutual-knn-residual-gat-refined-prototypes-v1"


@dataclass(frozen=True)
class Configuration:
    k_candidates: tuple[int, ...]
    heads: int
    dropout: float
    epochs: int
    patience: int
    learning_rate: float
    weight_decay: float
    temperature: float
    anchor_weight: float
    type_weight: float
    label_smoothing: float
    maximum_residual_scale: float
    evaluation_batch_size: int
    seed: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train residual GAT refined ARG subtype prototypes."
    )
    parser.add_argument("--raw-pt", type=Path, default=DEFAULT_RAW_PT)
    parser.add_argument("--fused-pt", type=Path, default=DEFAULT_FUSED_PT)
    parser.add_argument("--output-pt", type=Path, default=DEFAULT_OUTPUT_PT)
    parser.add_argument(
        "--k-candidates", nargs="+", type=int, default=[5, 10, 15, 20]
    )
    parser.add_argument("--heads", type=int, default=8)
    parser.add_argument("--dropout", type=float, default=0.15)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--patience", type=int, default=30)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--temperature", type=float, default=0.07)
    parser.add_argument("--anchor-weight", type=float, default=0.10)
    parser.add_argument("--type-weight", type=float, default=0.10)
    parser.add_argument("--label-smoothing", type=float, default=0.03)
    parser.add_argument("--maximum-residual-scale", type=float, default=0.50)
    parser.add_argument("--evaluation-batch-size", type=int, default=8192)
    parser.add_argument("--seed", type=int, default=20260817)
    parser.add_argument(
        "--device", choices=["auto", "cpu", "cuda"], default="auto"
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def choose_device(requested: str) -> torch.device:
    if requested == "cpu":
        return torch.device("cpu")
    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        return torch.device("cuda:0")
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def torch_load_cpu(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def is_nonarg(value: object) -> bool:
    compact = "".join(character for character in str(value).lower() if character.isalnum())
    return compact in {"nonarg", "nonresistance", "negative", "nonresistant"}


def validate_tensor(tensor, shape, description: str) -> torch.Tensor:
    if not isinstance(tensor, torch.Tensor) or tensor.ndim != len(shape):
        raise ValueError(f"{description} must be a {len(shape)}D tensor")
    for observed, expected in zip(tensor.shape, shape):
        if expected is not None and observed != expected:
            raise ValueError(
                f"Unexpected {description} shape: {tuple(tensor.shape)}, expected={shape}"
            )
    tensor = tensor.detach().cpu().float().contiguous()
    if not bool(torch.isfinite(tensor).all()):
        raise ValueError(f"Non-finite values in {description}")
    return tensor


def load_inputs(raw_path: Path, fused_path: Path):
    raw = torch_load_cpu(raw_path)
    fused = torch_load_cpu(fused_path)
    if not isinstance(raw, dict) or not isinstance(fused, dict):
        raise TypeError("Both PT files must contain dictionaries")

    raw_required = {
        "arg_subtype_names",
        "arg_subtype_to_index",
        "raw_arg_subtype_prototypes",
        "prototype_train_original_counts",
        "original_ids",
        "original_mean_embeddings",
        "original_subtypes",
        "original_model_splits",
        "baseline_evaluations",
    }
    fused_required = {"ids", "embeddings", "subtypes", "model_splits"}
    missing_raw = sorted(raw_required - set(raw))
    missing_fused = sorted(fused_required - set(fused))
    if missing_raw:
        raise KeyError(f"Raw PT missing keys: {missing_raw}")
    if missing_fused:
        raise KeyError(f"Fused PT missing keys: {missing_fused}")

    subtype_names = [str(value) for value in raw["arg_subtype_names"]]
    if len(subtype_names) != len(set(subtype_names)):
        raise ValueError("Duplicate ARG subtype names")
    if any(is_nonarg(value) for value in subtype_names):
        raise ValueError("nonARG must not be present in ARG subtype prototype names")
    subtype_to_index = {str(key): int(value) for key, value in raw["arg_subtype_to_index"].items()}
    expected_map = {name: index for index, name in enumerate(subtype_names)}
    if subtype_to_index != expected_map:
        raise ValueError("arg_subtype_to_index is inconsistent with arg_subtype_names")

    number_classes = len(subtype_names)
    prototypes = validate_tensor(
        raw["raw_arg_subtype_prototypes"],
        (number_classes, None),
        "raw prototypes",
    )
    prototypes = F.normalize(prototypes, p=2, dim=1)
    embedding_dim = prototypes.shape[1]

    original_ids = [str(value) for value in raw["original_ids"]]
    original_subtypes = [str(value) for value in raw["original_subtypes"]]
    original_splits = [str(value).lower() for value in raw["original_model_splits"]]
    original_embeddings = validate_tensor(
        raw["original_mean_embeddings"],
        (len(original_ids), embedding_dim),
        "original mean embeddings",
    )
    original_embeddings = F.normalize(original_embeddings, p=2, dim=1)
    if not (len(original_ids) == len(original_subtypes) == len(original_splits)):
        raise ValueError("Original metadata length mismatch")

    fragment_ids = [str(value) for value in fused["ids"]]
    fragment_subtypes = [str(value) for value in fused["subtypes"]]
    fragment_splits = [str(value).lower() for value in fused["model_splits"]]
    fragment_embeddings = validate_tensor(
        fused["embeddings"],
        (len(fragment_ids), embedding_dim),
        "fragment fused embeddings",
    )
    fragment_embeddings = F.normalize(fragment_embeddings, p=2, dim=1)
    if not (len(fragment_ids) == len(fragment_subtypes) == len(fragment_splits)):
        raise ValueError("Fragment metadata length mismatch")

    observed_arg = {
        label for label in original_subtypes + fragment_subtypes if not is_nonarg(label)
    }
    if observed_arg != set(subtype_names):
        raise ValueError(
            f"ARG subtype set mismatch: prototypes={len(subtype_names)}, "
            f"observed={len(observed_arg)}"
        )

    print(f"ARG raw prototypes    : {tuple(prototypes.shape)}", flush=True)
    print(f"Original embeddings   : {tuple(original_embeddings.shape)}", flush=True)
    print(f"Fragment embeddings   : {tuple(fragment_embeddings.shape)}", flush=True)
    return {
        "raw_object": raw,
        "fused_object": fused,
        "subtype_names": subtype_names,
        "subtype_to_index": subtype_to_index,
        "raw_prototypes": prototypes,
        "original_ids": original_ids,
        "original_subtypes": original_subtypes,
        "original_splits": original_splits,
        "original_embeddings": original_embeddings,
        "fragment_ids": fragment_ids,
        "fragment_subtypes": fragment_subtypes,
        "fragment_splits": fragment_splits,
        "fragment_embeddings": fragment_embeddings,
    }


def select_arg_split(features, ids, labels, splits, target_split, label_map):
    indices = [
        index
        for index, (label, split) in enumerate(zip(labels, splits))
        if split == target_split and not is_nonarg(label)
    ]
    if not indices:
        raise ValueError(f"No ARG samples in split={target_split}")
    tensor_indices = torch.tensor(indices, dtype=torch.long)
    selected_features = features.index_select(0, tensor_indices).contiguous()
    selected_targets = torch.tensor(
        [label_map[labels[index]] for index in indices], dtype=torch.long
    )
    selected_ids = [ids[index] for index in indices]
    return selected_features, selected_targets, selected_ids


def build_mutual_knn_graph(prototypes: torch.Tensor, k: int):
    number_nodes = prototypes.shape[0]
    if not 1 <= k < number_nodes:
        raise ValueError(f"K must satisfy 1 <= K < {number_nodes}, observed {k}")
    similarity = prototypes @ prototypes.T
    similarity.fill_diagonal_(-torch.inf)
    neighbors = similarity.topk(k=k, dim=1).indices
    directed = torch.zeros((number_nodes, number_nodes), dtype=torch.bool)
    rows = torch.arange(number_nodes).unsqueeze(1).expand_as(neighbors)
    directed[rows, neighbors] = True
    mutual = directed & directed.T
    adjacency = mutual.clone()
    adjacency.fill_diagonal_(True)
    undirected_edge_count = int(mutual.triu(diagonal=1).sum().item())
    neighbor_degrees = mutual.sum(dim=1).to(torch.long)
    isolated_without_self = int((neighbor_degrees == 0).sum().item())
    edge_index = adjacency.nonzero(as_tuple=False).T.contiguous()
    return {
        "adjacency": adjacency,
        "edge_index": edge_index,
        "undirected_edge_count": undirected_edge_count,
        "neighbor_degrees": neighbor_degrees,
        "isolated_nodes_without_self": isolated_without_self,
    }


class DenseGraphAttentionLayer(nn.Module):
    def __init__(self, dimension: int, heads: int, dropout: float):
        super().__init__()
        if dimension % heads != 0:
            raise ValueError(f"dimension={dimension} must be divisible by heads={heads}")
        self.dimension = dimension
        self.heads = heads
        self.head_dimension = dimension // heads
        self.projection = nn.Linear(dimension, dimension, bias=False)
        self.attention_source = nn.Parameter(torch.empty(heads, self.head_dimension))
        self.attention_target = nn.Parameter(torch.empty(heads, self.head_dimension))
        self.output_projection = nn.Linear(dimension, dimension, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.projection.weight)
        nn.init.xavier_uniform_(self.output_projection.weight)
        nn.init.xavier_uniform_(self.attention_source)
        nn.init.xavier_uniform_(self.attention_target)

    def forward(self, nodes: torch.Tensor, adjacency: torch.Tensor):
        number_nodes = nodes.shape[0]
        transformed = self.projection(nodes).view(
            number_nodes, self.heads, self.head_dimension
        ).permute(1, 0, 2)
        source_score = (transformed * self.attention_source[:, None, :]).sum(dim=2)
        target_score = (transformed * self.attention_target[:, None, :]).sum(dim=2)
        scores = self.leaky_relu(source_score[:, :, None] + target_score[:, None, :])
        scores = scores.masked_fill(~adjacency.unsqueeze(0), -torch.inf)
        attention = torch.softmax(scores, dim=2)
        attention = self.dropout(attention)
        aggregated = torch.matmul(attention, transformed)
        aggregated = aggregated.permute(1, 0, 2).reshape(number_nodes, self.dimension)
        return self.output_projection(aggregated)


class ResidualPrototypeGAT(nn.Module):
    def __init__(
        self,
        dimension: int,
        heads: int,
        dropout: float,
        number_types: int,
        maximum_residual_scale: float,
    ):
        super().__init__()
        self.gat1 = DenseGraphAttentionLayer(dimension, heads, dropout)
        self.gat2 = DenseGraphAttentionLayer(dimension, heads, dropout)
        self.norm1 = nn.LayerNorm(dimension)
        self.norm2 = nn.LayerNorm(dimension)
        self.dropout = nn.Dropout(dropout)
        self.type_classifier = nn.Linear(dimension, number_types)
        self.residual_scale_logit = nn.Parameter(torch.tensor(-2.0))
        self.maximum_residual_scale = float(maximum_residual_scale)

    def forward(self, raw_prototypes: torch.Tensor, adjacency: torch.Tensor):
        hidden = self.gat1(raw_prototypes, adjacency)
        hidden = self.norm1(F.elu(hidden))
        hidden = self.dropout(hidden)
        update = self.gat2(hidden, adjacency)
        update = self.norm2(update)
        residual_scale = self.maximum_residual_scale * torch.sigmoid(
            self.residual_scale_logit
        )
        refined = F.normalize(raw_prototypes + residual_scale * update, p=2, dim=1)
        type_logits = self.type_classifier(refined)
        return refined, type_logits, residual_scale


def subtype_to_type(subtype: str) -> str:
    return subtype.split("__", 1)[0] if "__" in subtype else subtype


def class_weights(targets: torch.Tensor, number_classes: int) -> torch.Tensor:
    counts = torch.bincount(targets, minlength=number_classes).float()
    if bool((counts == 0).any()):
        raise ValueError("At least one ARG Subtype is absent from model-train")
    weights = counts.rsqrt()
    return weights / weights.mean()


def confusion_metrics(
    true_targets: torch.Tensor,
    predictions: torch.Tensor,
    top5_correct: torch.Tensor,
    maximum_similarity: torch.Tensor,
    number_classes: int,
):
    true_np = true_targets.cpu().numpy().astype(np.int64, copy=False)
    pred_np = predictions.cpu().numpy().astype(np.int64, copy=False)
    confusion = np.zeros((number_classes, number_classes), dtype=np.int64)
    np.add.at(confusion, (true_np, pred_np), 1)
    tp = np.diag(confusion).astype(np.float64)
    support = confusion.sum(axis=1).astype(np.float64)
    predicted_count = confusion.sum(axis=0).astype(np.float64)
    precision = np.divide(
        tp, predicted_count, out=np.zeros_like(tp), where=predicted_count != 0
    )
    recall = np.divide(tp, support, out=np.zeros_like(tp), where=support != 0)
    f1 = np.divide(
        2.0 * precision * recall,
        precision + recall,
        out=np.zeros_like(tp),
        where=(precision + recall) != 0,
    )
    total = float(confusion.sum())
    active = support > 0
    sample_weights = support / total if total else np.zeros_like(support)
    correct = float(tp.sum())

    predicted_marginal = confusion.sum(axis=0).astype(np.float64)
    true_marginal = confusion.sum(axis=1).astype(np.float64)
    numerator = correct * total - float(np.dot(predicted_marginal, true_marginal))
    denominator = math.sqrt(
        max(total * total - float(np.dot(predicted_marginal, predicted_marginal)), 0.0)
        * max(total * total - float(np.dot(true_marginal, true_marginal)), 0.0)
    )
    mcc = numerator / denominator if denominator > 0 else 0.0
    return {
        "support": int(total),
        "evaluated_subtypes": int(active.sum()),
        "top1_accuracy": float(correct / total) if total else 0.0,
        "top5_accuracy": float(top5_correct.float().mean().item()),
        "macro_precision": float(precision[active].mean()),
        "macro_recall": float(recall[active].mean()),
        "macro_f1": float(f1[active].mean()),
        "weighted_precision": float(np.sum(precision * sample_weights)),
        "weighted_recall": float(np.sum(recall * sample_weights)),
        "weighted_f1": float(np.sum(f1 * sample_weights)),
        "mcc": float(mcc),
        "mean_max_cosine_similarity": float(maximum_similarity.mean().item()),
        "median_max_cosine_similarity": float(maximum_similarity.median().item()),
        "confusion_matrix": torch.from_numpy(confusion.astype(np.int32, copy=False)),
    }


@torch.no_grad()
def evaluate_prototypes(
    features: torch.Tensor,
    targets: torch.Tensor,
    prototypes: torch.Tensor,
    batch_size: int,
):
    predictions = []
    maximum_similarities = []
    top5_results = []
    top_k = min(5, prototypes.shape[0])
    for start in range(0, features.shape[0], batch_size):
        end = min(start + batch_size, features.shape[0])
        similarities = features[start:end] @ prototypes.T
        values, indices = similarities.topk(k=top_k, dim=1)
        true_batch = targets[start:end]
        predictions.append(indices[:, 0].cpu())
        maximum_similarities.append(values[:, 0].float().cpu())
        top5_results.append((indices == true_batch.unsqueeze(1)).any(dim=1).cpu())
    predictions = torch.cat(predictions)
    maximum_similarities = torch.cat(maximum_similarities)
    top5_correct = torch.cat(top5_results)
    metrics = confusion_metrics(
        targets.cpu(),
        predictions,
        top5_correct,
        maximum_similarities,
        prototypes.shape[0],
    )
    return {
        "metrics": metrics,
        "true_subtype_indices": targets.cpu(),
        "predicted_subtype_indices": predictions,
        "maximum_cosine_similarities": maximum_similarities,
        "top5_correct": top5_correct,
    }


def train_one_k(
    k: int,
    raw_prototypes: torch.Tensor,
    graph: dict,
    train_features: torch.Tensor,
    train_targets: torch.Tensor,
    validation_fragment_features: torch.Tensor,
    validation_fragment_targets: torch.Tensor,
    type_targets: torch.Tensor,
    number_types: int,
    config: Configuration,
    device: torch.device,
):
    set_seed(config.seed + k * 1009)
    model = ResidualPrototypeGAT(
        dimension=raw_prototypes.shape[1],
        heads=config.heads,
        dropout=config.dropout,
        number_types=number_types,
        maximum_residual_scale=config.maximum_residual_scale,
    ).to(device)
    raw_device = raw_prototypes.to(device)
    adjacency = graph["adjacency"].to(device)
    train_features = train_features.to(device)
    train_targets = train_targets.to(device)
    validation_fragment_features = validation_fragment_features.to(device)
    validation_fragment_targets = validation_fragment_targets.to(device)
    type_targets = type_targets.to(device)

    subtype_weight = class_weights(train_targets.cpu(), raw_prototypes.shape[0]).to(device)
    type_weight = class_weights(type_targets.cpu(), number_types).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=8, min_lr=1e-6
    )

    best_score = -math.inf
    best_accuracy = -math.inf
    best_epoch = -1
    best_state = None
    best_validation_metrics = None
    epochs_without_improvement = 0
    history = []

    for epoch in range(1, config.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        refined, type_logits, residual_scale = model(raw_device, adjacency)
        subtype_logits = (train_features @ refined.T) / config.temperature
        subtype_loss = F.cross_entropy(
            subtype_logits,
            train_targets,
            weight=subtype_weight,
            label_smoothing=config.label_smoothing,
        )
        anchor_loss = (1.0 - (refined * raw_device).sum(dim=1)).mean()
        type_loss = F.cross_entropy(type_logits, type_targets, weight=type_weight)
        loss = (
            subtype_loss
            + config.anchor_weight * anchor_loss
            + config.type_weight * type_loss
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()

        model.eval()
        with torch.no_grad():
            refined_validation, _, scale_validation = model(raw_device, adjacency)
            validation = evaluate_prototypes(
                validation_fragment_features,
                validation_fragment_targets,
                refined_validation,
                config.evaluation_batch_size,
            )
        validation_metrics = validation["metrics"]
        score = float(validation_metrics["macro_f1"])
        accuracy = float(validation_metrics["top1_accuracy"])
        scheduler.step(score)
        current_lr = optimizer.param_groups[0]["lr"]
        history.append(
            {
                "epoch": epoch,
                "total_loss": float(loss.item()),
                "subtype_loss": float(subtype_loss.item()),
                "anchor_loss": float(anchor_loss.item()),
                "type_loss": float(type_loss.item()),
                "validation_fragment_accuracy": accuracy,
                "validation_fragment_macro_f1": score,
                "residual_scale": float(scale_validation.item()),
                "learning_rate": float(current_lr),
            }
        )
        print(
            f"K={k:02d} Epoch {epoch:03d} | loss={loss.item():.6f} | "
            f"val_ACC={accuracy:.4f} | val_macro_F1={score:.4f} | "
            f"scale={scale_validation.item():.4f} | lr={current_lr:.2e}",
            flush=True,
        )

        improved = score > best_score + 1e-7 or (
            abs(score - best_score) <= 1e-7 and accuracy > best_accuracy + 1e-7
        )
        if improved:
            best_score = score
            best_accuracy = accuracy
            best_epoch = epoch
            best_validation_metrics = validation_metrics
            best_state = {
                name: tensor.detach().cpu().clone()
                for name, tensor in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= config.patience:
                print(f"K={k:02d} early stopping at epoch {epoch}", flush=True)
                break

    if best_state is None or best_validation_metrics is None:
        raise RuntimeError(f"K={k} did not produce a valid model")
    del model
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return {
        "k": k,
        "graph_undirected_edges": graph["undirected_edge_count"],
        "graph_isolated_nodes_without_self": graph["isolated_nodes_without_self"],
        "graph_neighbor_degrees": graph["neighbor_degrees"],
        "best_epoch": best_epoch,
        "best_validation_fragment_metrics": best_validation_metrics,
        "best_state_dict": best_state,
        "history": history,
    }


def metrics_without_confusion(metrics: dict) -> dict:
    return {key: value for key, value in metrics.items() if key != "confusion_matrix"}


def metric_deltas(refined_metrics: dict, raw_metrics: dict) -> dict:
    keys = [
        "top1_accuracy",
        "top5_accuracy",
        "macro_precision",
        "macro_recall",
        "macro_f1",
        "weighted_f1",
        "mcc",
    ]
    return {
        key: float(refined_metrics[key]) - float(raw_metrics[key])
        for key in keys
        if key in refined_metrics and key in raw_metrics
    }


def print_metrics(name: str, evaluation: dict) -> None:
    metrics = evaluation["metrics"]
    print(
        f"{name:28s} | n={metrics['support']:,} | "
        f"subtypes={metrics['evaluated_subtypes']:,} | "
        f"ACC={metrics['top1_accuracy']:.6f} | "
        f"macro_F1={metrics['macro_f1']:.6f} | "
        f"weighted_F1={metrics['weighted_f1']:.6f} | "
        f"MCC={metrics['mcc']:.6f}",
        flush=True,
    )


def main() -> None:
    args = parse_args()
    for path, description in ((args.raw_pt, "Raw prototype PT"), (args.fused_pt, "Gated fusion PT")):
        if not path.is_file():
            raise FileNotFoundError(f"{description} not found: {path}")
    if args.output_pt.exists() and not args.overwrite:
        raise FileExistsError(
            f"Output already exists: {args.output_pt}\nUse --overwrite to replace it."
        )
    if not args.k_candidates or any(k < 1 for k in args.k_candidates):
        raise ValueError("All K candidates must be positive")
    if len(set(args.k_candidates)) != len(args.k_candidates):
        raise ValueError("K candidates must be unique")
    if args.heads < 1 or args.epochs < 1 or args.patience < 1:
        raise ValueError("Heads, epochs, and patience must be positive")
    if not 0.0 < args.temperature:
        raise ValueError("Temperature must be positive")
    if not 0.0 < args.maximum_residual_scale <= 1.0:
        raise ValueError("Maximum residual scale must be in (0, 1]")

    config = Configuration(
        k_candidates=tuple(args.k_candidates),
        heads=args.heads,
        dropout=args.dropout,
        epochs=args.epochs,
        patience=args.patience,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        temperature=args.temperature,
        anchor_weight=args.anchor_weight,
        type_weight=args.type_weight,
        label_smoothing=args.label_smoothing,
        maximum_residual_scale=args.maximum_residual_scale,
        evaluation_batch_size=args.evaluation_batch_size,
        seed=args.seed,
    )
    set_seed(config.seed)
    device = choose_device(args.device)
    args.output_pt.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    print("=" * 125, flush=True)
    print("Mutual-KNN selection and residual GAT refined ARG subtype prototypes", flush=True)
    print("=" * 125, flush=True)
    print(f"Script version : {SCRIPT_VERSION}", flush=True)
    print(f"Raw PT         : {args.raw_pt}", flush=True)
    print(f"Fused PT       : {args.fused_pt}", flush=True)
    print(f"Output PT      : {args.output_pt}", flush=True)
    print(f"K candidates   : {list(config.k_candidates)}", flush=True)
    print(f"Device         : {device}", flush=True)

    data = load_inputs(args.raw_pt, args.fused_pt)
    subtype_names = data["subtype_names"]
    subtype_to_index = data["subtype_to_index"]
    raw_prototypes = data["raw_prototypes"]
    if raw_prototypes.shape[1] % config.heads != 0:
        raise ValueError(
            f"Embedding dimension {raw_prototypes.shape[1]} is not divisible by heads={config.heads}"
        )

    train_original_features, train_original_targets, _ = select_arg_split(
        data["original_embeddings"],
        data["original_ids"],
        data["original_subtypes"],
        data["original_splits"],
        "train",
        subtype_to_index,
    )
    validation_original_features, validation_original_targets, validation_original_ids = select_arg_split(
        data["original_embeddings"],
        data["original_ids"],
        data["original_subtypes"],
        data["original_splits"],
        "validation",
        subtype_to_index,
    )
    test_original_features, test_original_targets, test_original_ids = select_arg_split(
        data["original_embeddings"],
        data["original_ids"],
        data["original_subtypes"],
        data["original_splits"],
        "test",
        subtype_to_index,
    )
    validation_fragment_features, validation_fragment_targets, validation_fragment_ids = select_arg_split(
        data["fragment_embeddings"],
        data["fragment_ids"],
        data["fragment_subtypes"],
        data["fragment_splits"],
        "validation",
        subtype_to_index,
    )
    test_fragment_features, test_fragment_targets, test_fragment_ids = select_arg_split(
        data["fragment_embeddings"],
        data["fragment_ids"],
        data["fragment_subtypes"],
        data["fragment_splits"],
        "test",
        subtype_to_index,
    )
    print(f"Train ARG originals       : {train_original_features.shape[0]:,}", flush=True)
    print(f"Validation ARG fragments  : {validation_fragment_features.shape[0]:,}", flush=True)
    print(f"Test ARG fragments        : {test_fragment_features.shape[0]:,}", flush=True)

    type_names = sorted({subtype_to_type(name) for name in subtype_names})
    type_to_index = {name: index for index, name in enumerate(type_names)}
    type_targets = torch.tensor(
        [type_to_index[subtype_to_type(name)] for name in subtype_names], dtype=torch.long
    )
    print(f"ARG Types                 : {len(type_names):,}", flush=True)

    candidate_results = []
    candidate_states = {}
    graphs = {}
    print("\n===== VALIDATION-ONLY K SELECTION =====", flush=True)
    for k in config.k_candidates:
        graph = build_mutual_knn_graph(raw_prototypes, k)
        graphs[k] = graph
        print(
            f"\nK={k}: undirected_edges={graph['undirected_edge_count']:,}, "
            f"isolated_without_self={graph['isolated_nodes_without_self']:,}, "
            f"degree_min={graph['neighbor_degrees'].min().item()}, "
            f"degree_mean={graph['neighbor_degrees'].float().mean().item():.3f}, "
            f"degree_max={graph['neighbor_degrees'].max().item()}",
            flush=True,
        )
        result = train_one_k(
            k,
            raw_prototypes,
            graph,
            train_original_features,
            train_original_targets,
            validation_fragment_features,
            validation_fragment_targets,
            type_targets,
            len(type_names),
            config,
            device,
        )
        candidate_states[k] = result.pop("best_state_dict")
        candidate_results.append(result)

    selected_result = max(
        candidate_results,
        key=lambda item: (
            item["best_validation_fragment_metrics"]["macro_f1"],
            item["best_validation_fragment_metrics"]["top1_accuracy"],
            -item["k"],
        ),
    )
    selected_k = int(selected_result["k"])
    selected_graph = graphs[selected_k]
    selected_state = candidate_states[selected_k]
    print("\n===== SELECTED BY VALIDATION ONLY =====", flush=True)
    print(f"Selected K                    : {selected_k}", flush=True)
    print(f"Selected best epoch           : {selected_result['best_epoch']}", flush=True)
    print(
        f"Selected validation macro F1  : "
        f"{selected_result['best_validation_fragment_metrics']['macro_f1']:.6f}",
        flush=True,
    )

    selected_model = ResidualPrototypeGAT(
        dimension=raw_prototypes.shape[1],
        heads=config.heads,
        dropout=config.dropout,
        number_types=len(type_names),
        maximum_residual_scale=config.maximum_residual_scale,
    ).to(device)
    selected_model.load_state_dict(selected_state)
    selected_model.eval()
    with torch.no_grad():
        refined_prototypes, type_logits, residual_scale = selected_model(
            raw_prototypes.to(device), selected_graph["adjacency"].to(device)
        )
    refined_prototypes = refined_prototypes.detach()

    print("\n===== FINAL EVALUATION AFTER MODEL SELECTION =====", flush=True)
    final_evaluations = {
        "validation_fragment": evaluate_prototypes(
            validation_fragment_features.to(device),
            validation_fragment_targets.to(device),
            refined_prototypes,
            config.evaluation_batch_size,
        ),
        "test_fragment": evaluate_prototypes(
            test_fragment_features.to(device),
            test_fragment_targets.to(device),
            refined_prototypes,
            config.evaluation_batch_size,
        ),
        "validation_original": evaluate_prototypes(
            validation_original_features.to(device),
            validation_original_targets.to(device),
            refined_prototypes,
            config.evaluation_batch_size,
        ),
        "test_original": evaluate_prototypes(
            test_original_features.to(device),
            test_original_targets.to(device),
            refined_prototypes,
            config.evaluation_batch_size,
        ),
    }
    for name, evaluation in final_evaluations.items():
        print_metrics(name, evaluation)

    raw_baselines = {
        name: data["raw_object"]["baseline_evaluations"][name]["metrics"]
        for name in final_evaluations
    }
    deltas = {
        name: metric_deltas(evaluation["metrics"], raw_baselines[name])
        for name, evaluation in final_evaluations.items()
    }
    print("\n===== REFINED MINUS RAW BASELINE =====", flush=True)
    for name, values in deltas.items():
        print(
            f"{name:28s} | delta_ACC={values['top1_accuracy']:+.6f} | "
            f"delta_macro_F1={values['macro_f1']:+.6f} | "
            f"delta_MCC={values['mcc']:+.6f}",
            flush=True,
        )

    output = {
        "arg_subtype_names": subtype_names,
        "arg_subtype_to_index": subtype_to_index,
        "raw_arg_subtype_prototypes": raw_prototypes,
        "refined_arg_subtype_prototypes": refined_prototypes.float().cpu().contiguous(),
        "selected_k": selected_k,
        "selected_best_epoch": int(selected_result["best_epoch"]),
        "selected_residual_scale": float(residual_scale.item()),
        "selected_graph_edge_index_with_self_loops": selected_graph["edge_index"],
        "selected_graph_neighbor_degrees_without_self": selected_graph["neighbor_degrees"],
        "selected_graph_undirected_edge_count": selected_graph["undirected_edge_count"],
        "selected_model_state_dict": selected_state,
        "type_names": type_names,
        "type_to_index": type_to_index,
        "type_targets_per_ARG_subtype": type_targets,
        "candidate_validation_results": candidate_results,
        "final_evaluations": final_evaluations,
        "raw_baseline_metrics": {
            name: metrics_without_confusion(metrics) for name, metrics in raw_baselines.items()
        },
        "refined_minus_raw_metric_deltas": deltas,
        "evaluation_ids": {
            "validation_fragment": validation_fragment_ids,
            "test_fragment": test_fragment_ids,
            "validation_original": validation_original_ids,
            "test_original": test_original_ids,
        },
        "configuration": asdict(config),
        "training_rule": (
            "train ARG originals optimize GAT; validation ARG fragments select K/epoch; "
            "test evaluated only after selection"
        ),
        "fusion_formula": (
            "L2Norm(raw_prototype + residual_scale * two_layer_GAT_update)"
        ),
        "loss_formula": (
            "weighted_subtype_CE + anchor_weight*(1-cos(refined,raw)) + "
            "type_weight*type_CE"
        ),
        "nonARG_policy": "excluded from ARG subtype graph",
        "source_raw_prototype_pt": str(args.raw_pt),
        "source_gated_fusion_pt": str(args.fused_pt),
        "script_version": SCRIPT_VERSION,
    }
    temporary = args.output_pt.with_suffix(args.output_pt.suffix + ".tmp")
    torch.save(output, temporary)
    os.replace(temporary, args.output_pt)

    print("\n" + "=" * 125, flush=True)
    print("RESIDUAL GAT REFINED PROTOTYPES COMPLETED", flush=True)
    print("=" * 125, flush=True)
    print(f"Selected K              : {selected_k}", flush=True)
    print(f"Refined prototype shape : {tuple(refined_prototypes.shape)}", flush=True)
    print(f"Only output file        : {args.output_pt}", flush=True)
    print(f"Elapsed minutes         : {(time.time()-started)/60.0:.3f}", flush=True)


if __name__ == "__main__":
    main()
