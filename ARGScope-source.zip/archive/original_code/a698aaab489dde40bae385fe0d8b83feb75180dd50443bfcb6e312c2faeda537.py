#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Refit all eight UMAPs with one predeclared, unsupervised display profile.

The user requested a more continuous, less tightly clumped point-cloud display.
Only UMAP layout parameters change. No model, feature tensor, sample, label,
classification metric, selected epoch, or existing coordinate file is modified.
"""
import os
os.environ.setdefault("NUMBA_NUM_THREADS", "1")
import hashlib
import json
import time
from importlib.metadata import version
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits
from umap import UMAP

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE / "data/umap"
OUT = HERE / "data/umap_reference_refit"
PARAMS = {
    "n_neighbors": 50, "min_dist": 0.50, "spread": 1.0,
    "n_components": 2, "metric": "cosine", "random_state": 42,
    "transform_seed": 42, "n_jobs": 1, "n_epochs": 500,
    "init": "spectral", "low_memory": True,
    "learning_rate": 1.0, "repulsion_strength": 1.0,
    "negative_sample_rate": 5
}
VERSIONS = {key: version(key) for key in ["umap-learn", "numpy", "numba", "scikit-learn", "torch"]}
PROFILE = "reference_n50_min050"
SOURCE_HASHES = {}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def fit_one(modality, epoch, expected_best):
    original_path = ORIGINAL / "coordinates" / f"{modality}_epoch_{epoch:03d}.csv"
    original_meta_path = original_path.with_suffix(".json")
    metadata = json.loads(original_meta_path.read_text(encoding="utf-8"))
    source = Path(metadata["source"])
    require(source.is_file(), f"Missing original feature file: {source}")
    require(digest(source) == metadata["identity"]["source_sha256"], f"Original feature source changed: {source}")
    require(digest(original_path) == metadata["coordinates_sha256"], "Original UMAP snapshot changed")
    for path in [source, original_path, original_meta_path]:
        SOURCE_HASHES[str(path)] = digest(path)
    reference = pd.read_csv(original_path, float_precision="round_trip")
    require(reference.sequence_id.is_unique and len(reference) == 2287, "Invalid reference cohort")
    raw = torch.load(source, map_location="cpu", weights_only=True)
    require(raw["epoch"] == epoch and raw["split"] == "test" and raw["ARG_only"] is True,
            "Feature epoch/population mismatch")
    ids = list(raw["sequence_ids"])
    require(len(ids) == len(set(ids)) == len(reference), "Missing/duplicate feature IDs")
    positions = pd.Index(ids).get_indexer(reference.sequence_id)
    require((positions >= 0).all(), "Reference ID missing from features")
    np.testing.assert_array_equal(np.asarray(raw["true_types"])[positions], reference.Type)
    np.testing.assert_array_equal(np.asarray(raw["true_subtypes"])[positions], reference.Subtype)
    features = raw["features"].detach().cpu().numpy()[positions].astype(np.float32, copy=False)
    require(features.shape == (2287, 512) and np.isfinite(features).all(), "Invalid features")
    require(np.allclose(np.linalg.norm(features, axis=1), 1, rtol=0, atol=1e-4), "Feature normalization changed")
    require(not raw["experiment_provenance"].get("smoke_test_only", False), "Smoke-test features")
    if epoch == expected_best:
        require(source.name.startswith("run_best_epoch_"), "Not the saved validation-best snapshot")
    identity = {
        "profile": PROFILE, "params": PARAMS, "versions": VERSIONS,
        "source_sha256": digest(source),
        "feature_array_sha256": hashlib.sha256(features.tobytes()).hexdigest(),
        "ordered_ids_sha256": hashlib.sha256("\n".join(reference.sequence_id).encode("utf-8")).hexdigest()
    }
    target = OUT / "coordinates" / original_path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    meta_target = target.with_suffix(".json")
    if target.exists() or meta_target.exists():
        require(target.is_file() and meta_target.is_file(), "Incomplete refit cache")
        old = json.loads(meta_target.read_text(encoding="utf-8"))
        require(old["identity"] == identity, "Refit settings/source changed; select a new profile folder")
        require(digest(target) == old["coordinates_sha256"], "Refit cache altered")
        print(f"CACHED {modality} epoch {epoch}", flush=True)
        result = old
    else:
        start = time.perf_counter()
        print(f"FIT {modality} epoch {epoch}: n_neighbors=50, min_dist=0.50, 2287 x 512", flush=True)
        # Critical: no y argument; neither Type nor subtype labels affect fitting.
        with threadpool_limits(limits=1):
            coords = UMAP(**PARAMS).fit_transform(features)
        require(coords.shape == (2287, 2) and np.isfinite(coords).all(), "Invalid projected coordinates")
        frame = reference[["sequence_id", "Type", "Subtype"]].copy()
        frame["UMAP1"], frame["UMAP2"] = coords[:, 0], coords[:, 1]
        frame.to_csv(target, index=False, encoding="utf-8-sig")
        result = {"identity": identity, "modality": modality, "epoch": epoch,
                  "source": str(source), "coordinates_sha256": digest(target),
                  "n_samples": 2287, "n_types": int(reference.Type.nunique()),
                  "fit_seconds": time.perf_counter() - start,
                  "labels_used_in_fit": False, "coordinates_jittered": False,
                  "class_specific_transforms": False, "points_removed": 0}
        save_json(meta_target, result)
        print(f"DONE {modality} epoch {epoch}: {result['fit_seconds']:.1f}s", flush=True)
    after = pd.read_csv(target, float_precision="round_trip")
    pd.testing.assert_frame_equal(after[["sequence_id", "Type", "Subtype"]],
                                  reference[["sequence_id", "Type", "Subtype"]])
    require(np.isfinite(after[["UMAP1", "UMAP2"]]).all().all(), "Invalid exported coordinates")
    return result


def main():
    selections = json.loads((ORIGINAL / "selected_epochs.json").read_text(encoding="utf-8"))
    OUT.mkdir(parents=True, exist_ok=True)
    # Record this choice BEFORE fitting, not after inspecting class separation.
    plan = {"profile": PROFILE, "params": PARAMS, "versions": VERSIONS,
            "same_parameters_all_modalities_and_epochs": True,
            "purpose": "User-requested display sensitivity variant, not a new model-performance result.",
            "parameters_selected_by_class_separation": False,
            "source_documentation": "https://umap-learn.readthedocs.io/en/latest/parameters.html",
            "selected_epochs": selections}
    plan_path = OUT / "REFIT_PLAN.json"
    if plan_path.exists():
        require(json.loads(plan_path.read_text(encoding="utf-8")) == plan, "Refit plan changed")
    else:
        save_json(plan_path, plan)
    results = []
    for modality in ["protein", "dna"]:
        for epoch in selections[modality]["selected_epochs"]:
            results.append(fit_one(modality, epoch, selections[modality]["best_epoch"]))
    require(all(digest(Path(path)) == before for path, before in SOURCE_HASHES.items()), "Input source changed")
    save_json(OUT / "REFIT_VALIDATION.json", {
        "status": "PASS", "profile": PROFILE, "params": PARAMS,
        "fits": results, "source_hashes": SOURCE_HASHES,
        "source_files_unchanged": True, "labels_used_in_fit": False,
        "n_fits": len(results), "same_cohort_across_epochs": True,
        "training_and_metrics_unchanged": True,
        "interpretation": "This is a layout-parameter variant. Its appearance alone is not evidence of model improvement."
    })
    print("PASS: 8 unsupervised layouts; original features, predictions and coordinates unchanged.", flush=True)


if __name__ == "__main__":
    main()

