"""Offline editorial redesign of the audited ARGScope overview.

Native draw.io text, containers and connectors; reused embedded pictograms.
Never modifies the manuscript, training code, original figures or synced sources.
"""
from pathlib import Path
import base64
import hashlib
import html
import json
import shutil
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/ARGScope_drawio_redesign_v3_20260930'
ASSETS = OUT / 'assets'
OLD = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/ARGScope_Figure1_visual_v2_20260930')
AUDIT = ROOT / 'outputs/argscope_manuscript_aligned_figures_20260929/code_figure_audit_20260929.md'
NAME = 'Figure1_ARGScope_redesign_v3'
BLUE, TEAL, INK, WHITE = '#3478AE', '#259B91', '#283743', '#FFFFFF'


class Canvas:
    def __init__(self):
        self.doc = ET.Element('mxfile', host='Electron', version='31.4.5', type='device',
                              agent='drawio-skill offline ARGScope overview redesign')
        page = ET.SubElement(self.doc, 'diagram', id='argscope-editorial-v3', name='ARGScope overview - redesigned')
        model = ET.SubElement(page, 'mxGraphModel', dx='2600', dy='1780', grid='0', gridSize='10',
                              guides='1', tooltips='1', connect='1', arrows='1', fold='1',
                              page='1', pageScale='1', pageWidth='2600', pageHeight='1780',
                              math='0', shadow='0', lineJumps='1', background=WHITE)
        self.root = ET.SubElement(model, 'root')
        ET.SubElement(self.root, 'mxCell', id='0')
        ET.SubElement(self.root, 'mxCell', id='1', parent='0')
        self.coords = {'1': (0, 0, 2600, 1780)}
        self.parents = {}
        self.text_records = []
        self.edges = []
        self.counter = 0

    def ident(self, prefix):
        self.counter += 1
        return f'{prefix}-{self.counter}'

    def vertex(self, ident, rect, style, label='', parent='1', role='decoration'):
        x, y, w, h = rect
        px, py, _, _ = self.coords[parent]
        cell = ET.SubElement(self.root, 'mxCell', id=ident, value=label, style=style,
                             vertex='1', parent=parent, **{'data-role': role})
        ET.SubElement(cell, 'mxGeometry', x=str(x-px), y=str(y-py), width=str(w), height=str(h), **{'as': 'geometry'})
        self.coords[ident] = rect
        self.parents[ident] = parent
        return ident

    def group(self, ident, rect, color=INK, fill=0, stroke=False, parent='1'):
        return self.vertex(ident, rect,
            f'rounded=1;arcSize=20;absoluteArcSize=1;html=1;container=1;pointerEvents=0;'
            f'collapsible=0;recursiveResize=1;fillColor={color};fillOpacity={fill};'
            f'strokeColor={color if stroke else "none"};strokeOpacity=23;strokeWidth=1.4;'
            f'fontFamily=Arial;fontSize=26;fontColor={INK};', parent=parent, role='container')

    def text(self, label, rect, size=26, bold=False, color=INK, align='left', parent='1', ident=None):
        ident = ident or self.ident('label')
        safe = '<div style="line-height:1.18;">' + '<br>'.join(html.escape(s) for s in label.split('\n')) + '</div>'
        self.text_records.append(dict(id=ident, text=label, rect=rect, size=size, bold=bold))
        return self.vertex(ident, rect,
            f'text;html=1;whiteSpace=wrap;overflow=visible;strokeColor=none;fillColor=none;'
            f'fontFamily=Arial;fontSize={size};fontStyle={int(bold)};fontColor={color};'
            f'align={align};verticalAlign=middle;spacing=0;', safe, parent, 'label')

    def box(self, ident, label, rect, color=INK, fill=6, size=26, bold=False, parent='1', stroke=True):
        safe = '<div style="line-height:1.18;">' + '<br>'.join(html.escape(s) for s in label.split('\n')) + '</div>'
        self.text_records.append(dict(id=ident, text=label, rect=rect, size=size, bold=bold))
        return self.vertex(ident, rect,
            f'rounded=1;arcSize=14;absoluteArcSize=1;html=1;whiteSpace=wrap;'
            f'fillColor={color};fillOpacity={fill};strokeColor={color if stroke else "none"};'
            f'strokeWidth=1.7;strokeOpacity=60;fontFamily=Arial;fontSize={size};'
            f'fontColor={INK};fontStyle={int(bold)};spacing=8;align=center;verticalAlign=middle;',
            safe, parent, 'process')

    def circle(self, ident, label, rect, color=INK, fill=100, size=25, parent='1'):
        return self.vertex(ident, rect,
            f'ellipse;html=1;aspect=fixed;fillColor={color};fillOpacity={fill};strokeColor=none;'
            f'fontFamily=Arial;fontSize={size};fontStyle=1;fontColor={WHITE};', label, parent)

    def icon(self, filename, rect, parent='1', ident=None):
        path = ASSETS / filename
        kind = 'png' if path.suffix.lower() == '.png' else 'svg+xml'
        uri = 'data:image/' + kind + ',' + base64.b64encode(path.read_bytes()).decode('ascii')
        return self.vertex(ident or self.ident('icon'), rect,
            'shape=image;html=1;imageAspect=1;aspect=fixed;strokeColor=none;'
            f'fontFamily=Arial;fontSize=26;image={uri};', parent=parent, role='illustration')

    def edge(self, ident, start, end, via=(), color=INK, dashed=False, arrow=True,
             source=None, target=None, width=2.8, opacity=100):
        attrs = dict(id=ident, value='', edge='1', parent='1')
        style = (f'edgeStyle=none;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;'
                 f'endArrow={"block" if arrow else "none"};endFill=1;endSize=10;'
                 f'strokeColor={color};strokeWidth={width};opacity={opacity};'
                 f'dashed={int(dashed)};dashPattern=8 6;jumpStyle=arc;jumpSize=10;'
                 f'fontFamily=Arial;fontSize=24;fontColor={INK};')
        for node, pt, which in [(source, start, 'exit'), (target, end, 'entry')]:
            if node:
                attrs['source' if which == 'exit' else 'target'] = node
                x, y, w, h = self.coords[node]
                style += f'{which}X={(pt[0]-x)/w:.8f};{which}Y={(pt[1]-y)/h:.8f};{which}Perimeter=0;'
                style += f'{which}Dx=0;{which}Dy=0;'
        attrs['style'] = style
        cell = ET.SubElement(self.root, 'mxCell', attrs)
        geo = ET.SubElement(cell, 'mxGeometry', relative='1', **{'as': 'geometry'})
        for pt, key in [(start, 'sourcePoint'), (end, 'targetPoint')]:
            ET.SubElement(geo, 'mxPoint', x=str(pt[0]), y=str(pt[1]), **{'as': key})
        if via:
            array = ET.SubElement(geo, 'Array', **{'as': 'points'})
            for x, y in via:
                ET.SubElement(array, 'mxPoint', x=str(x), y=str(y))
        self.edges.append(dict(id=ident, source=source, target=target, points=[start, *via, end], dashed=dashed))

    def stage(self, ident, x, number, title, subtitle):
        self.group(ident, (x, 240, 550, 945), fill=2)
        self.circle(f'{ident}-number', str(number), (x+26, 266, 46, 46), parent=ident)
        self.text(title, (x+88, 262, 433, 58), 31, True, parent=ident)
        self.text(subtitle, (x+28, 332, 494, 55), 25, parent=ident)
        self.edge(f'{ident}-rule', (x+28, 405), (x+522, 405), arrow=False, width=1.2, opacity=16)


def prepare_assets():
    ASSETS.mkdir(parents=True, exist_ok=True)
    for filename in ['protein_ribbon.png', 'dna_double_helix.png', 'protein_student.svg',
                     'nucleotide_student.svg', 'protein_embedding.svg', 'nucleotide_embedding.svg',
                     'fused_embedding.svg', 'subtype_clusters.svg', 'mutual_knn.svg',
                     'residual_gat.svg', 'refined_prototypes.svg', 'head_anchoring.svg',
                     'teacher_predictions.svg', 'prototype_alignment.svg']:
        shutil.copy2(OLD / 'assets' / filename, ASSETS / filename)
    lock = f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
    <path d="M20 29V19a12 12 0 0 1 24 0v10" fill="none" stroke="{INK}" stroke-width="5"/>
    <rect x="12" y="27" width="40" height="31" rx="7" fill="{INK}"/>
    <circle cx="32" cy="39" r="4" fill="white"/><path d="M32 40v9" stroke="white" stroke-width="3"/></svg>'''
    (ASSETS / 'fixed_lock.svg').write_text(lock, encoding='utf-8')


def make_figure():
    d = Canvas()
    d.text('ARGScope', (60, 32, 650, 74), 59, True)
    d.text('Multimodal learning. Single-modality deployment.', (63, 111, 1250, 49), 31)
    for xx, color, label in [(1640, BLUE, 'Protein / AA'), (1970, TEAL, 'Nucleotide / NT'), (2308, INK, 'Shared')]:
        d.circle(d.ident('legend-dot'), '', (xx, 65, 16, 16), color)
        d.text(label, (xx+28, 47, 275 if color != INK else 180, 46), 25)
    d.text('A', (60, 183, 42, 40), 33, True)
    d.text('STAGED MULTIMODAL TRAINING', (116, 184, 1050, 40), 29, True)
    d.text('Statistics and prototypes are fitted on model-training data only.',
           (1170, 181, 1330, 46), 25, align='right')

    for ident, x, no, title, subtitle in [
        ('fusion-stage', 60, 1, 'Encode and fuse', 'Paired ARG and non-ARG sequences\nFixed encoders; precomputed features'),
        ('graph-stage', 690, 2, 'Refine subtype prototypes', 'ARG model-training samples only'),
        ('teacher-stage', 1320, 3, 'Train fusion teachers', 'Two branch-specific teachers'),
        ('student-stage', 1950, 4, 'Train students', 'One input modality per student'),
    ]:
        d.stage(ident, x, no, title, subtitle)

    # Stage 1: the encoders are fixed; projections and fusion are learned.
    p = 'fusion-stage'
    d.icon('protein_ribbon.png', (105, 437, 166, 142), p)
    d.icon('dna_double_helix.png', (379, 431, 94, 151), p)
    d.text('Protein', (92, 585, 214, 42), 27, True, BLUE, 'center', p)
    d.text('Nucleotide', (350, 585, 215, 42), 27, True, TEAL, 'center', p)
    d.box('esm2', 'ESM-2', (95, 650, 210, 59), BLUE, size=27, bold=True, parent=p)
    d.box('dnabert2', 'DNABERT-2', (350, 650, 220, 59), TEAL, size=27, bold=True, parent=p)
    d.edge('protein-encoder-input', (200, 627), (200, 650), color=BLUE, target='esm2', width=2.3)
    d.edge('nucleotide-encoder-input', (460, 627), (460, 650), color=TEAL, target='dnabert2', width=2.3)
    d.text('1280D', (95, 713, 210, 41), 25, True, BLUE, 'center', p)
    d.text('768D', (350, 713, 220, 41), 25, True, TEAL, 'center', p)
    d.box('project-aa', 'Standardize\nProject to 512D', (95, 793, 210, 87), BLUE, size=25, parent=p)
    d.box('project-nt', 'Standardize\nProject to 512D', (350, 793, 220, 87), TEAL, size=25, parent=p)
    d.edge('esm-to-proj', (200, 754), (200, 793), color=BLUE, target='project-aa')
    d.edge('nt-to-proj', (460, 754), (460, 793), color=TEAL, target='project-nt')
    d.box('adaptive-gate', 'Adaptive feature-wise gate', (120, 933, 450, 64), size=26, bold=True, parent=p)
    d.edge('aa-proj-gate', (200, 880), (230, 933), [(200, 906), (230, 906)], BLUE, source='project-aa', target='adaptive-gate')
    d.edge('nt-proj-gate', (460, 880), (460, 933), color=TEAL, source='project-nt', target='adaptive-gate')
    d.text('Weighted sum + LayerNorm', (93, 1005, 480, 43), 25, align='center', parent=p)
    d.box('fused-output', 'Fused features · 512D', (113, 1080, 460, 69), size=28, bold=True, fill=10, parent=p)
    d.edge('gate-fused', (345, 1048), (345, 1080), target='fused-output')

    # Stage 2: normalize samples, compute subtype centroids, then refine the graph.
    p = 'graph-stage'
    d.icon('subtype_clusters.svg', (719, 445, 170, 152), p, 'raw-centroid-icon')
    d.text('Subtype centroids', (914, 448, 294, 42), 27, True, parent=p)
    d.text('L2 samples → mean\n→ L2 prototype', (914, 500, 294, 80), 25, parent=p)
    d.edge('centroid-graph', (805, 596), (805, 649), target=None)
    d.icon('mutual_knn.svg', (719, 651, 170, 152), p)
    d.text('Mutual kNN graph', (914, 657, 294, 42), 27, True, parent=p)
    d.text('Cosine similarity\nSelf-loops included', (914, 712, 294, 76), 25, parent=p)
    d.edge('knn-refine', (805, 803), (805, 847))
    d.icon('residual_gat.svg', (719, 854, 170, 152), p)
    d.text('Residual GAT', (914, 858, 294, 42), 27, True, parent=p)
    d.text('Auxiliary type\nsupervision', (914, 917, 294, 76), 25, parent=p)
    d.box('refined-prototypes', 'Refined subtype prototypes', (720, 1080, 486, 69), size=27, bold=True, fill=10, parent=p)
    d.edge('gat-refined', (805, 1006), (805, 1080), target='refined-prototypes')
    d.text('L2-normalized', (914, 1024, 290, 38), 24, parent=p)
    d.text('Non-ARG center is computed separately.', (694, 1198, 550, 40), 24, align='center')

    # Fused ARG features enter prototype construction, not the graph classifier directly.
    d.edge('fused-to-centroids', (573, 1114.5), (719, 521), [(650, 1114.5), (650, 521)],
           source='fused-output', target='raw-centroid-icon')

    # Stage 3: show the teachers as L2 plus parallel heads, never as hidden MLPs.
    p = 'teacher-stage'
    d.box('teacher-fused-input', 'Fused input · 512D', (1360, 432, 470, 60), size=28, bold=True, fill=8, parent=p)
    for branch, y, color in [('aa', 553, BLUE), ('nt', 837, TEAL)]:
        gp = f'{branch}-teacher'
        d.group(gp, (1360, y, 470, 222), color, 4, True, p)
        d.text(f'{branch.upper()} teacher', (1382, y+15, 282, 41), 29, True, color, parent=gp)
        d.icon('fixed_lock.svg', (1764, y+12, 35, 35), gp)
        d.box(f'{branch}-teacher-l2', 'L2\nnormalization', (1380, y+76, 158, 86), color, size=24, parent=gp)
        d.box(f'{branch}-teacher-binary', 'Binary', (1610, y+65, 190, 54), color, size=26, bold=True, parent=gp)
        d.box(f'{branch}-teacher-subtype', 'Subtype', (1610, y+145, 190, 54), color, size=26, bold=True, parent=gp)
        d.edge(f'{branch}-teacher-to-binary', (1538, y+97), (1610, y+92), [(1574, y+97), (1574, y+92)],
               color, source=f'{branch}-teacher-l2', target=f'{branch}-teacher-binary', width=2.2)
        d.edge(f'{branch}-teacher-to-subtype', (1538, y+142), (1610, y+172), [(1574, y+142), (1574, y+172)],
               color, source=f'{branch}-teacher-l2', target=f'{branch}-teacher-subtype', width=2.2)
    d.text('Parallel cosine heads', (1373, 1080, 442, 38), 26, True, align='center', parent=p)
    d.text('Train separately, then freeze', (1353, 1125, 470, 40), 25, align='center', parent=p)

    # Repeated fused input is linked via an uncluttered lower routing corridor.
    d.edge('fused-to-teachers', (343, 1149), (1360, 462),
           [(343, 1290), (1300, 1290), (1300, 462)], source='fused-output', target='teacher-fused-input')
    d.text('Shared fused representations', (473, 1248, 540, 32), 24)
    d.edge('fused-input-nt', (1470, 492), (1380, 956), [(1470, 523), (1340, 523), (1340, 956)],
           source='teacher-fused-input', target='nt-teacher-l2', width=2.2)
    d.edge('fused-input-aa', (1340, 672), (1380, 672), target='aa-teacher-l2', width=2.2)
    d.circle('fused-aa-junction', '', (1336, 668, 8, 8), parent=p)
    # The two dashed arrows terminate at subtype HEADS; they are not sequence inputs.
    d.edge('prototypes-to-aa-head', (1206, 1114.5), (1610, 725),
           [(1267, 1114.5), (1267, 806), (1560, 806), (1560, 725)],
           dashed=True, source='refined-prototypes', target='aa-teacher-subtype', width=2.4)
    d.edge('prototypes-to-nt-head', (1206, 1114.5), (1610, 1009),
           [(1279, 1114.5), (1279, 1074), (1560, 1074), (1560, 1009)],
           dashed=True, source='refined-prototypes', target='nt-teacher-subtype', width=2.4)
    d.text('Subtype-head initialization and anchoring', (1354, 1198, 500, 57), 24, align='center')

    # Stage 4: student input features are modality specific, teacher targets fixed.
    p = 'student-stage'
    for branch, y, color, feature, kd in [
        ('aa', 433, BLUE, 'Protein features · 1280D', 'Subtype KD only'),
        ('nt', 701, TEAL, 'Nucleotide features · 768D', 'Binary + subtype KD')]:
        gp = f'{branch}-student'
        d.group(gp, (1980, y, 490, 224), color, 6, False, p)
        d.icon('protein_student.svg' if branch == 'aa' else 'nucleotide_student.svg', (1998, y+55, 140, 133), gp)
        d.text('ARGScope-'+branch.upper(), (2158, y+27, 286, 44), 30, True, color, parent=gp)
        d.text(feature, (2158, y+78, 291, 67), 25, parent=gp)
        d.text(kd, (2158, y+157, 292, 52), 24, True, parent=gp)
    d.edge('aa-teacher-transfer', (1830, 664), (1980, 545), [(1890, 664), (1890, 545)],
           dashed=True, source='aa-teacher', target='aa-student', width=2.7)
    d.edge('nt-teacher-transfer', (1830, 948), (1980, 813), [(1890, 948), (1890, 813)],
           dashed=True, source='nt-teacher', target='nt-student', width=2.7)
    d.text('Fixed training targets', (1983, 946, 460, 41), 27, True, parent=p)
    target_specs = [
        ('distillation', 'Distillation', 'Teacher predictions', 1980, 992),
        ('feature-alignment', 'Feature alignment', 'Fused features', 1980, 1040),
        ('prototype-alignment', 'Prototype alignment', 'Subtype + non-ARG', 1980, 1088),
        ('head-anchoring', 'Head anchoring', 'Head weights', 1980, 1136),
    ]
    for ident, title, desc, x, y in target_specs:
        d.group(ident, (x, y, 490, 45), INK, 4, False, p)
        d.text(title, (x+10, y+1, 242, 43), 24, True, parent=ident)
        d.text(desc, (x+271, y+1, 211, 43), 22, parent=ident)
    d.text('Binary CE: all samples · Subtype CE/KD: ARG only', (1923, 1198, 600, 57), 23, align='center')

    # Inference occupies a clean horizontal band; no multimodal resources remain.
    d.text('B', (60, 1340, 42, 40), 33, True)
    d.text('SINGLE-MODALITY INFERENCE', (116, 1340, 990, 40), 29, True)
    d.text('Use only the matching encoder and student.', (1540, 1334, 960, 50), 26, align='right')
    d.group('inference-models', (60, 1408, 1202, 293), INK, 2)
    for branch, y, color, icon, encoder in [
        ('aa', 1432, BLUE, 'protein_ribbon.png', 'ESM-2'),
        ('nt', 1571, TEAL, 'dna_double_helix.png', 'DNABERT-2')]:
        d.icon(icon, (88, y-2, 96, 104), 'inference-models')
        d.text('Protein' if branch == 'aa' else 'Nucleotide', (197, y+21, 176, 43), 26, True, color, parent='inference-models')
        d.box(f'infer-{branch}-encoder', encoder, (401, y+7, 185, 74), color, size=25, bold=True, parent='inference-models')
        d.box(f'infer-{branch}-student', 'ARGScope-'+branch.upper(), (643, y+7, 242, 74), color, size=28, bold=True, parent='inference-models')
        d.box(f'infer-{branch}-heads', 'Parallel binary\nand subtype heads', (953, y+7, 277, 74), color, size=25, parent='inference-models')
        d.edge(f'infer-{branch}-encode', (370, y+44), (401, y+44), color=color, target=f'infer-{branch}-encoder')
        d.edge(f'infer-{branch}-student-edge', (586, y+44), (643, y+44), color=color, source=f'infer-{branch}-encoder', target=f'infer-{branch}-student')
        d.edge(f'infer-{branch}-heads-edge', (885, y+44), (953, y+44), color=color, source=f'infer-{branch}-student', target=f'infer-{branch}-heads')
    d.group('annotation', (1432, 1408, 1068, 293), INK, 2)
    d.vertex('arg-decision', (1459, 1480, 171, 136),
             f'rhombus;html=1;whiteSpace=wrap;fillColor={WHITE};strokeColor={INK};strokeWidth=2;'
             f'fontFamily=Arial;fontSize=26;fontStyle=1;fontColor={INK};',
             'ARG /<br>non-ARG', 'annotation', 'decision')
    for branch, cy in [('aa', 1476), ('nt', 1615)]:
        d.edge(f'infer-{branch}-decision', (1230, cy), (1459, 1548), [(1355, cy), (1355, 1548)],
               source=f'infer-{branch}-heads', target='arg-decision', width=2.6)
    d.box('reported-subtype', 'Predicted subtype', (1733, 1447, 305, 73), size=29, bold=True, parent='annotation')
    d.box('reported-type', 'Resistance type', (2160, 1447, 305, 73), size=29, bold=True, parent='annotation')
    d.box('reported-nonarg', 'non-ARG', (1733, 1600, 305, 63), size=29, parent='annotation')
    d.edge('report-arg-subtype', (1630, 1548), (1733, 1483.5), [(1677, 1548), (1677, 1483.5)], source='arg-decision', target='reported-subtype')
    d.text('ARG', (1666, 1438, 85, 36), 23, True)
    d.edge('report-nonarg', (1544.5, 1616), (1733, 1631.5), [(1544.5, 1631.5)], source='arg-decision', target='reported-nonarg')
    d.text('non-ARG', (1583, 1654, 149, 33), 23)
    d.edge('subtype-to-type', (2038, 1483.5), (2160, 1483.5), source='reported-subtype', target='reported-type')
    d.text('Predefined mapping', (2038, 1410, 427, 34), 24, align='center', parent='annotation')
    d.text('Binary decision gates subtype reporting.', (1690, 1545, 731, 40), 24, parent='annotation')

    d.edge('legend-forward', (65, 1740), (132, 1740))
    d.text('Forward / data flow', (149, 1716, 348, 47), 24)
    d.edge('legend-target', (527, 1740), (594, 1740), dashed=True)
    d.text('Training target / constraint', (613, 1716, 470, 47), 24)
    d.text('No fusion module, teacher or prototype graph is required at inference.',
           (1120, 1716, 1380, 47), 25, align='right')
    return d


def main():
    prepare_assets()
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [AUDIT, OLD / 'Figure1_ARGScope_visual_v2.drawio']}
    d = make_figure()
    ET.indent(d.doc)
    output_path = OUT / (NAME + '.drawio')
    ET.ElementTree(d.doc).write(output_path, encoding='utf-8', xml_declaration=True)
    # Validate parent containment and endpoint identities without flattening groups.
    containment = []
    for ident, parent in d.parents.items():
        x, y, w, h = d.coords[ident]
        px, py, pw, ph = d.coords[parent]
        if not (x >= px-.01 and y >= py-.01 and x+w <= px+pw+.01 and y+h <= py+ph+.01):
            containment.append(ident)
    all_ids = {c.get('id') for c in d.root}
    assert len(all_ids) == len(list(d.root)), 'Duplicate IDs'
    assert all(not e['source'] or e['source'] in all_ids for e in d.edges)
    assert all(not e['target'] or e['target'] in all_ids for e in d.edges)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p,h in hashes.items())
    report = dict(canvas=[2600,1780], cells=len(all_ids), edges=len(d.edges),
                  text_cells=len(d.text_records), minimum_font_size=min(t['size'] for t in d.text_records),
                  palette=[BLUE,TEAL,INK], containment_issues=containment,
                  original_files_preserved=True, source_hashes=hashes,
                  evidence='Existing 2026-09-29 code-figure audit; no new training/code claims.',
                  generation='Offline draw.io authoring; no image-generation API used.',
                  key_semantics=['staged learning', 'fixed pretrained encoders', 'feature-wise weighted fusion',
                      'ARG-only subtype graph', 'separate non-ARG center',
                      'teachers: L2 + parallel cosine heads, not MLP',
                      'prototypes initialize and anchor subtype heads',
                      'AA binary KD off; NT binary KD on',
                      'single-modality inference; binary gates reporting; predefined subtype-to-type mapping'])
    (OUT / 'design_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'layout_text.json').write_text(json.dumps(d.text_records, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'layout_edges.json').write_text(json.dumps(d.edges, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'README_新版说明.md').write_text('''# ARGScope 总流程图：draw.io 重设计预览

- 四步训练主线与独立推理区；蓝色为 AA，青绿色为 NT，深灰为共享部分。
- 全部标题、正文、框、分类头及主连接线都是 draw.io 原生可编辑对象。
- 生物图标沿用已有通用示意 PNG；其余小图标为嵌入的 SVG。图标可以独立移动、缩放或替换，但图标内部路径需在矢量编辑器修改。
- 单独保存新版本，不覆盖旧图、论文或科研代码。没有调用任何生图 API。
- 流程内容依据既有 `code_figure_audit_20260929.md` 核验记录。本轮是视觉重设计，不是重新运行模型。
- 原型仅用于 subtype head 初始化/锚定；融合向量才是教师序列输入。教师不画成有隐藏 MLP 的网络。
- 图中节点、矩阵格子和生物结构仅作概念示意，不代表实际样本数、特定蛋白结构或完整网络拓扑。
- 本版是供审阅的总览图，不替代 Figure 2 的训练细节或完整方法描述。

建议在 draw.io 中打开 `.drawio` 源文件编辑。预览与导出应来自同一源文件。
''', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
