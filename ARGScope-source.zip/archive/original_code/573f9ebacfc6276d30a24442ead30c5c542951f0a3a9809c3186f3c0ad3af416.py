import os
from pathlib import Path
import pandas as pd
from Bio import SeqIO


# ==========================================================
# 1. 文件路径
# ==========================================================

BASE_DIR = Path(r"E:\1. ARG模型对比\BGC数据处理\BGC数据")

AA_FASTA = BASE_DIR / "mibig_prot_seqs_4.0.fasta"
DNA_FASTA = BASE_DIR / "mibig_prot_corresponding_dna.fasta"
MAP_CSV = BASE_DIR / "mibig_protein_to_dna_mapping.csv"

OUT_AA_FASTA = BASE_DIR / "mibig_prot_seqs_4.0.clean.fasta"
OUT_DNA_FASTA = BASE_DIR / "mibig_prot_corresponding_dna.clean.fasta"
OUT_MAP_CSV = BASE_DIR / "mibig_protein_to_dna_mapping.clean.csv"

OUT_REMOVED_CSV = BASE_DIR / "mibig_removed_non_matching_records.csv"
OUT_SUMMARY_CSV = BASE_DIR / "mibig_pair_check_summary.csv"


# ==========================================================
# 2. 解析 FASTA header 中的 protein_id
# ==========================================================

def get_protein_id_from_header(header):
    """
    header 示例:
    BGC0000001.5|c1|1-1083|+|AEK75490.1|protein_methyltransferase|AEK75490.1

    第 5 个字段是 protein_id:
    AEK75490.1
    """

    parts = str(header).strip().split("|")

    if len(parts) < 5:
        return None

    protein_id = parts[4].strip()

    if protein_id == "":
        return None

    return protein_id


# ==========================================================
# 3. 读取 FASTA，并按 protein_id 去重
# ==========================================================

def read_fasta_unique_by_protein_id(fasta_file, file_label):
    records = []
    rows = []
    duplicate_rows = []

    seen = set()

    total = 0
    kept = 0
    duplicated = 0
    bad_header = 0

    for rec in SeqIO.parse(str(fasta_file), "fasta"):
        total += 1

        protein_id = get_protein_id_from_header(rec.description)

        if protein_id is None:
            bad_header += 1
            rows.append({
                "source": file_label,
                "protein_id": "",
                "header": rec.description,
                "status": "bad_header"
            })
            continue

        if protein_id in seen:
            duplicated += 1
            duplicate_rows.append({
                "source": file_label,
                "protein_id": protein_id,
                "header": rec.description,
                "status": "duplicated_removed"
            })
            continue

        seen.add(protein_id)
        kept += 1

        records.append(rec)

        rows.append({
            "source": file_label,
            "protein_id": protein_id,
            "header": rec.description,
            "status": "kept_initial"
        })

    info = {
        "source": file_label,
        "total_records": total,
        "kept_unique_records": kept,
        "duplicated_removed": duplicated,
        "bad_header": bad_header,
        "unique_protein_ids": len(seen)
    }

    return records, seen, pd.DataFrame(rows), pd.DataFrame(duplicate_rows), info


# ==========================================================
# 4. 读取 mapping 表，并按 protein_id 去重
# ==========================================================

def read_mapping_unique(map_file):
    df = pd.read_csv(map_file)

    if "protein_id" not in df.columns:
        raise ValueError("mapping 表中缺少 protein_id 列")

    df["protein_id"] = df["protein_id"].astype(str).str.strip()

    before_n = len(df)

    bad_mask = (df["protein_id"] == "") | (df["protein_id"].str.lower() == "nan")
    bad_df = df[bad_mask].copy()
    bad_df["status"] = "bad_protein_id_removed"

    df_valid = df[~bad_mask].copy()

    dup_mask = df_valid.duplicated(subset=["protein_id"], keep="first")
    duplicate_df = df_valid[dup_mask].copy()
    duplicate_df["status"] = "duplicated_removed"

    df_unique = df_valid.drop_duplicates(subset=["protein_id"], keep="first").copy()

    mapping_ids = set(df_unique["protein_id"])

    info = {
        "source": "mapping_csv",
        "total_records": before_n,
        "kept_unique_records": len(df_unique),
        "duplicated_removed": int(dup_mask.sum()),
        "bad_header": len(bad_df),
        "unique_protein_ids": len(mapping_ids)
    }

    removed_df = pd.concat([bad_df, duplicate_df], axis=0, ignore_index=True)

    return df_unique, mapping_ids, removed_df, info


# ==========================================================
# 5. 根据共同 protein_id 过滤 FASTA
# ==========================================================

def filter_fasta_records(records, valid_ids):
    kept_records = []
    removed_rows = []

    for rec in records:
        protein_id = get_protein_id_from_header(rec.description)

        if protein_id in valid_ids:
            kept_records.append(rec)
        else:
            removed_rows.append({
                "source": "fasta_after_intersection_filter",
                "protein_id": protein_id,
                "header": rec.description,
                "status": "not_in_all_three_files_removed"
            })

    return kept_records, pd.DataFrame(removed_rows)


# ==========================================================
# 6. 主程序
# ==========================================================

def main():
    print("Checking input files...")

    for fp in [AA_FASTA, DNA_FASTA, MAP_CSV]:
        print(fp, "exists:", fp.exists())
        if not fp.exists():
            raise FileNotFoundError(f"文件不存在: {fp}")

    print("\nReading AA FASTA...")
    aa_records, aa_ids, aa_rows, aa_dup_rows, aa_info = read_fasta_unique_by_protein_id(
        AA_FASTA,
        "aa_fasta"
    )

    print("Reading DNA FASTA...")
    dna_records, dna_ids, dna_rows, dna_dup_rows, dna_info = read_fasta_unique_by_protein_id(
        DNA_FASTA,
        "dna_fasta"
    )

    print("Reading mapping CSV...")
    map_df_unique, map_ids, map_removed_df, map_info = read_mapping_unique(MAP_CSV)

    print("\nInitial statistics:")
    print("AA unique IDs:", len(aa_ids))
    print("DNA unique IDs:", len(dna_ids))
    print("Mapping unique IDs:", len(map_ids))

    # 三个文件共同存在的 protein_id
    common_ids = aa_ids & dna_ids & map_ids

    print("\nCommon IDs in all three files:", len(common_ids))

    aa_only = aa_ids - common_ids
    dna_only = dna_ids - common_ids
    map_only = map_ids - common_ids

    print("AA IDs removed:", len(aa_only))
    print("DNA IDs removed:", len(dna_only))
    print("Mapping IDs removed:", len(map_only))

    # 过滤 FASTA
    aa_clean_records, aa_removed_by_intersection = filter_fasta_records(
        aa_records,
        common_ids
    )

    dna_clean_records, dna_removed_by_intersection = filter_fasta_records(
        dna_records,
        common_ids
    )

    # 过滤 mapping
    map_clean_df = map_df_unique[map_df_unique["protein_id"].isin(common_ids)].copy()

    map_removed_by_intersection = map_df_unique[
        ~map_df_unique["protein_id"].isin(common_ids)
    ].copy()
    map_removed_by_intersection["status"] = "not_in_all_three_files_removed"

    # 为了确保 mapping 顺序和 AA FASTA 顺序一致
    aa_order = []
    for rec in aa_clean_records:
        aa_order.append(get_protein_id_from_header(rec.description))

    order_df = pd.DataFrame({
        "protein_id": aa_order,
        "_order": range(len(aa_order))
    })

    map_clean_df = map_clean_df.merge(order_df, on="protein_id", how="left")
    map_clean_df = map_clean_df.sort_values("_order").drop(columns=["_order"])

    # DNA FASTA 也按 AA FASTA 的顺序重排
    dna_record_dict = {
        get_protein_id_from_header(rec.description): rec
        for rec in dna_clean_records
    }

    dna_clean_records_ordered = [
        dna_record_dict[pid]
        for pid in aa_order
        if pid in dna_record_dict
    ]

    # 最终一致性检查
    final_aa_ids = [
        get_protein_id_from_header(rec.description)
        for rec in aa_clean_records
    ]

    final_dna_ids = [
        get_protein_id_from_header(rec.description)
        for rec in dna_clean_records_ordered
    ]

    final_map_ids = map_clean_df["protein_id"].tolist()

    if not (final_aa_ids == final_dna_ids == final_map_ids):
        raise ValueError("清洗后仍未一一对应，请检查 ID 顺序或重复情况。")

    print("\nAfter cleaning:")
    print("AA clean records:", len(aa_clean_records))
    print("DNA clean records:", len(dna_clean_records_ordered))
    print("Mapping clean rows:", len(map_clean_df))
    print("One-to-one check:", final_aa_ids == final_dna_ids == final_map_ids)

    # 写出清洗后的文件
    SeqIO.write(aa_clean_records, str(OUT_AA_FASTA), "fasta")
    SeqIO.write(dna_clean_records_ordered, str(OUT_DNA_FASTA), "fasta")
    map_clean_df.to_csv(OUT_MAP_CSV, index=False, encoding="utf-8-sig")

    # 汇总删除记录
    removed_rows = []

    for pid in sorted(aa_only):
        removed_rows.append({
            "source": "aa_fasta",
            "protein_id": pid,
            "status": "not_in_dna_or_mapping"
        })

    for pid in sorted(dna_only):
        removed_rows.append({
            "source": "dna_fasta",
            "protein_id": pid,
            "status": "not_in_aa_or_mapping"
        })

    for pid in sorted(map_only):
        removed_rows.append({
            "source": "mapping_csv",
            "protein_id": pid,
            "status": "not_in_aa_or_dna"
        })

    removed_df = pd.DataFrame(removed_rows)

    extra_removed_parts = [
        aa_dup_rows,
        dna_dup_rows,
        map_removed_df,
        aa_removed_by_intersection,
        dna_removed_by_intersection,
        map_removed_by_intersection
    ]

    extra_removed_parts = [
        x for x in extra_removed_parts
        if x is not None and len(x) > 0
    ]

    if len(extra_removed_parts) > 0:
        extra_removed_df = pd.concat(extra_removed_parts, axis=0, ignore_index=True)
        removed_df = pd.concat([removed_df, extra_removed_df], axis=0, ignore_index=True)

    removed_df.to_csv(OUT_REMOVED_CSV, index=False, encoding="utf-8-sig")

    summary_df = pd.DataFrame([
        aa_info,
        dna_info,
        map_info,
        {
            "source": "final_cleaned",
            "total_records": "",
            "kept_unique_records": len(common_ids),
            "duplicated_removed": "",
            "bad_header": "",
            "unique_protein_ids": len(common_ids)
        }
    ])

    summary_df.to_csv(OUT_SUMMARY_CSV, index=False, encoding="utf-8-sig")

    print("\nSaved files:")
    print("Clean AA FASTA:", OUT_AA_FASTA)
    print("Clean DNA FASTA:", OUT_DNA_FASTA)
    print("Clean mapping CSV:", OUT_MAP_CSV)
    print("Removed records:", OUT_REMOVED_CSV)
    print("Summary:", OUT_SUMMARY_CSV)


if __name__ == "__main__":
    main()