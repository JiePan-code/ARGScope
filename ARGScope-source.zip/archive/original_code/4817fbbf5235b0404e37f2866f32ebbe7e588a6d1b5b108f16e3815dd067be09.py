#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope Novel Gene split
Output ONLY 3 files:
    1) train_ids.txt
    2) test_ids.txt
    3) split_structure.txt

Rules
-----
1. ARG subtypes with only 1 sequence are removed.
2. ARGs are split by WHOLE subtype, never by individual sequence.
3. Every ARG subtype in TEST is completely absent from TRAIN.
4. Every resistance Type appearing in TEST must still exist in TRAIN.
5. Within each Type, whole subtypes are selected so that TEST contains
   approximately 20% of ARG genes for that Type whenever possible.
6. nonARG is sampled so that ARG:nonARG = 1:1 separately in TRAIN and TEST.
7. This split is intended for ARG/nonARG and Type-level Novel Gene evaluation.
   Exact subtype accuracy should not be used for the unseen test subtypes.
"""

from __future__ import annotations

import argparse
import hashlib
import random
import shutil
from pathlib import Path
from typing import Dict, List, Set

import pandas as pd


# =============================================================================
# Configuration
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

DEFAULT_STRUCTURE = SCRIPT_DIR / "all_ARG_nonARG_1to1_structure.txt"
DEFAULT_OUTDIR = SCRIPT_DIR / "ARGScope_novel_gene_split"

SEED = 42
TEST_FRACTION = 0.20
MIN_SUBTYPE_COUNT = 2


# =============================================================================
# Helpers
# =============================================================================

def stable_seed(text: str, seed: int) -> int:
    h = hashlib.md5(text.encode("utf-8")).hexdigest()
    return seed + int(h[:8], 16)


def write_ids(ids: List[str], path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as out:
        for rid in ids:
            out.write(rid + "\n")


def choose_test_subtypes_for_type(
    subtype_counts: Dict[str, int],
    test_fraction: float,
    seed: int,
    type_name: str,
) -> Set[str]:
    """
    Select complete subtypes for TEST so that their total gene count is as
    close as possible to test_fraction of all genes in the Type.

    Constraints:
    - no subtype is split;
    - at least one subtype remains in TRAIN;
    - if a Type has >=2 retained subtypes, at least one subtype goes to TEST.
    """

    items = list(subtype_counts.items())

    if len(items) < 2:
        return set()

    rng = random.Random(stable_seed(type_name, seed))
    rng.shuffle(items)

    total = sum(n for _, n in items)
    target = max(1, int(round(total * test_fraction)))

    # 0/1 subset-sum DP.
    reachable = [False] * (total + 1)
    prev_sum = [-1] * (total + 1)
    prev_item = [-1] * (total + 1)
    reachable[0] = True

    for idx, (_, weight) in enumerate(items):
        for s in range(total - weight, -1, -1):
            if reachable[s] and not reachable[s + weight]:
                reachable[s + weight] = True
                prev_sum[s + weight] = s
                prev_item[s + weight] = idx

    # TEST must be non-empty and cannot contain all genes.
    candidates = [s for s in range(1, total) if reachable[s]]

    if not candidates:
        return set()

    # Closest to 20%; tie-break by preferring <= target, then smaller test set.
    best_sum = min(
        candidates,
        key=lambda s: (
            abs(s - target),
            1 if s > target else 0,
            s,
        ),
    )

    chosen_indices = []
    cur = best_sum

    while cur > 0:
        idx = prev_item[cur]
        if idx < 0:
            raise RuntimeError(
                f"DP reconstruction failed for Type={type_name}"
            )
        chosen_indices.append(idx)
        cur = prev_sum[cur]

    chosen = {items[i][0] for i in chosen_indices}

    # Safety: never remove all subtypes of a Type from TRAIN.
    if len(chosen) >= len(items):
        raise RuntimeError(
            f"Internal error: all subtypes selected for TEST in Type={type_name}"
        )

    return chosen


# =============================================================================
# Main
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--structure",
        type=Path,
        default=DEFAULT_STRUCTURE,
    )
    parser.add_argument(
        "--outdir",
        type=Path,
        default=DEFAULT_OUTDIR,
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=SEED,
    )
    parser.add_argument(
        "--test-fraction",
        type=float,
        default=TEST_FRACTION,
    )
    parser.add_argument(
        "--force",
        action="store_true",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print("=" * 108)
    print("ARGScope Novel Gene split: unseen TEST subtypes, Type-level evaluation")
    print("=" * 108)
    print(f"Structure       : {args.structure}")
    print(f"Output          : {args.outdir}")
    print(f"Seed            : {args.seed}")
    print(f"Target TEST ARG : ~{args.test_fraction:.0%}")
    print("Novel rule      : every TEST ARG subtype is completely absent from TRAIN")
    print("Type rule       : every TEST Type must still be represented in TRAIN")
    print(f"Subtype filter  : remove subtype count < {MIN_SUBTYPE_COUNT}")
    print("Output files    : train_ids.txt / test_ids.txt / split_structure.txt")
    print("=" * 108)

    if not (0.0 < args.test_fraction < 0.5):
        raise ValueError("--test-fraction must be > 0 and < 0.5")

    if not args.structure.exists():
        raise FileNotFoundError(args.structure)

    if args.outdir.exists():
        if not args.force:
            raise FileExistsError(
                f"Output directory already exists:\n{args.outdir}\n"
                "Delete it first or rerun with --force."
            )
        shutil.rmtree(args.outdir)

    args.outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(
        args.structure,
        sep="\t",
        dtype=str,
        keep_default_na=False,
    )

    required = {
        "SARG.Seq.ID",
        "Type",
        "Subtype",
        "ARG.or.nonARG",
    }
    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"Structure file is missing required columns: {sorted(missing)}"
        )

    if df["SARG.Seq.ID"].duplicated().any():
        dup = df.loc[
            df["SARG.Seq.ID"].duplicated(),
            "SARG.Seq.ID",
        ].iloc[0]
        raise ValueError(f"Duplicate SARG.Seq.ID: {dup}")

    cls = df["ARG.or.nonARG"].str.strip().str.lower()

    valid = cls.isin(["arg", "nonarg"])
    if not valid.all():
        bad = sorted(df.loc[~valid, "ARG.or.nonARG"].unique())
        raise ValueError(f"Unexpected ARG.or.nonARG values: {bad}")

    arg_df0 = df.loc[cls.eq("arg")].copy()
    nonarg_df = df.loc[cls.eq("nonarg")].copy()

    print(f"Original total       : {len(df):,}")
    print(f"Original ARG         : {len(arg_df0):,}")
    print(f"Original nonARG      : {len(nonarg_df):,}")
    print(f"Original ARG Types   : {arg_df0['Type'].nunique():,}")
    print(f"Original ARG subtypes: {arg_df0['Subtype'].nunique():,}")

    # -------------------------------------------------------------------------
    # 1. Remove singleton ARG subtypes
    # -------------------------------------------------------------------------
    subtype_counts0 = arg_df0["Subtype"].value_counts()

    singleton_subtypes = set(
        subtype_counts0[
            subtype_counts0 < MIN_SUBTYPE_COUNT
        ].index
    )

    arg_df = arg_df0[
        ~arg_df0["Subtype"].isin(singleton_subtypes)
    ].copy()

    print("-" * 108)
    print(f"Removed singleton subtypes: {len(singleton_subtypes):,}")
    print(f"Removed ARG genes        : {len(arg_df0) - len(arg_df):,}")
    print(f"Retained ARG genes       : {len(arg_df):,}")
    print(f"Retained ARG subtypes    : {arg_df['Subtype'].nunique():,}")

    # -------------------------------------------------------------------------
    # 2. Whole-subtype split inside each Type
    # -------------------------------------------------------------------------
    test_subtypes: Set[str] = set()

    type_details = []

    for type_name, type_df in arg_df.groupby("Type", sort=True):
        subtype_counts = (
            type_df.groupby("Subtype")
            .size()
            .to_dict()
        )

        chosen = choose_test_subtypes_for_type(
            subtype_counts=subtype_counts,
            test_fraction=args.test_fraction,
            seed=args.seed,
            type_name=type_name,
        )

        test_subtypes.update(chosen)

        n_test = int(
            type_df["Subtype"].isin(chosen).sum()
        )

        type_details.append(
            (
                type_name,
                len(type_df),
                len(subtype_counts),
                len(chosen),
                n_test,
            )
        )

    arg_test_df = arg_df[
        arg_df["Subtype"].isin(test_subtypes)
    ].copy()

    arg_train_df = arg_df[
        ~arg_df["Subtype"].isin(test_subtypes)
    ].copy()

    arg_train_ids = set(arg_train_df["SARG.Seq.ID"])
    arg_test_ids = set(arg_test_df["SARG.Seq.ID"])

    train_subtypes = set(arg_train_df["Subtype"])
    test_subtypes_actual = set(arg_test_df["Subtype"])

    subtype_overlap = train_subtypes & test_subtypes_actual
    if subtype_overlap:
        raise RuntimeError(
            "FAILED: TEST ARG subtype leakage into TRAIN:\n"
            + "\n".join(sorted(subtype_overlap)[:50])
        )

    train_types = set(arg_train_df["Type"])
    test_types = set(arg_test_df["Type"])

    missing_test_types = test_types - train_types
    if missing_test_types:
        raise RuntimeError(
            "FAILED: some TEST Types are absent from TRAIN:\n"
            + "\n".join(sorted(missing_test_types))
        )

    if arg_train_ids & arg_test_ids:
        raise RuntimeError("FAILED: ARG TRAIN/TEST ID overlap.")

    if not arg_test_ids:
        raise RuntimeError("No ARG genes were assigned to TEST.")

    print("-" * 108)
    print("Per-Type split:")
    for typ, n_gene, n_sub, n_test_sub, n_test_gene in type_details:
        frac = n_test_gene / n_gene if n_gene else 0.0
        print(
            f"{typ:35s} "
            f"genes={n_gene:5d} "
            f"subtypes={n_sub:4d} "
            f"test_subtypes={n_test_sub:4d} "
            f"test_genes={n_test_gene:5d} "
            f"test_frac={frac:6.2%}"
        )

    # -------------------------------------------------------------------------
    # 3. nonARG sampling for exact 1:1 balance
    # -------------------------------------------------------------------------
    rng = random.Random(args.seed + 10001)

    nonarg_ids = nonarg_df["SARG.Seq.ID"].tolist()
    rng.shuffle(nonarg_ids)

    n_train_arg = len(arg_train_ids)
    n_test_arg = len(arg_test_ids)
    need_nonarg = n_train_arg + n_test_arg

    if len(nonarg_ids) < need_nonarg:
        raise RuntimeError(
            "Not enough nonARG sequences for 1:1 balancing: "
            f"available={len(nonarg_ids):,}, needed={need_nonarg:,}"
        )

    nonarg_train_ids = set(nonarg_ids[:n_train_arg])

    nonarg_test_ids = set(
        nonarg_ids[
            n_train_arg:
            n_train_arg + n_test_arg
        ]
    )

    # -------------------------------------------------------------------------
    # 4. Final split
    # -------------------------------------------------------------------------
    train_ids_set = arg_train_ids | nonarg_train_ids
    test_ids_set = arg_test_ids | nonarg_test_ids

    if train_ids_set & test_ids_set:
        raise RuntimeError("FAILED: final TRAIN/TEST ID overlap.")

    original_order = df["SARG.Seq.ID"].tolist()

    train_ids = [
        rid for rid in original_order
        if rid in train_ids_set
    ]
    test_ids = [
        rid for rid in original_order
        if rid in test_ids_set
    ]

    # One combined structure file only.
    split_lookup = {rid: "train" for rid in train_ids}
    split_lookup.update({rid: "test" for rid in test_ids})

    split_df = df[
        df["SARG.Seq.ID"].isin(train_ids_set | test_ids_set)
    ].copy()

    split_df.insert(
        0,
        "Split",
        split_df["SARG.Seq.ID"].map(split_lookup),
    )

    # -------------------------------------------------------------------------
    # 5. Output ONLY 3 files
    # -------------------------------------------------------------------------
    train_path = args.outdir / "train_ids.txt"
    test_path = args.outdir / "test_ids.txt"
    structure_path = args.outdir / "split_structure.txt"

    write_ids(train_ids, train_path)
    write_ids(test_ids, test_path)

    split_df.to_csv(
        structure_path,
        sep="\t",
        index=False,
    )

    # -------------------------------------------------------------------------
    # 6. Final verification
    # -------------------------------------------------------------------------
    train_arg_n = len(arg_train_ids)
    test_arg_n = len(arg_test_ids)
    train_nonarg_n = len(nonarg_train_ids)
    test_nonarg_n = len(nonarg_test_ids)

    actual_test_fraction = (
        test_arg_n / (train_arg_n + test_arg_n)
    )

    print("=" * 108)
    print("NOVEL GENE SPLIT COMPLETE")
    print("=" * 108)
    print(
        f"TRAIN: total={len(train_ids):,} "
        f"| ARG={train_arg_n:,} "
        f"| nonARG={train_nonarg_n:,}"
    )
    print(
        f"TEST : total={len(test_ids):,} "
        f"| ARG={test_arg_n:,} "
        f"| nonARG={test_nonarg_n:,}"
    )
    print(f"Actual ARG TEST fraction      : {actual_test_fraction:.2%}")
    print(f"TRAIN ARG subtypes            : {len(train_subtypes):,}")
    print(f"TEST ARG subtypes             : {len(test_subtypes_actual):,}")
    print(f"TRAIN/TEST ARG subtype overlap: {len(subtype_overlap)}")
    print(f"TEST Types absent from TRAIN  : {len(missing_test_types)}")
    print("-" * 108)

    print("[PASS] Every TEST ARG subtype is completely absent from TRAIN.")
    print("[PASS] Every TEST ARG Type is represented in TRAIN.")
    print("[PASS] ARG:nonARG = 1:1 in both TRAIN and TEST.")
    print("[PASS] Only 3 files were generated.")
    print("-" * 108)
    print(train_path)
    print(test_path)
    print(structure_path)
    print("=" * 108)


if __name__ == "__main__":
    main()
