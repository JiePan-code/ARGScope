"""w/o Adaptive Gating: fixed 0.5/0.5 fusion with all other fusion settings unchanged."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, data_root_from_launcher, load_base

DATA = data_root_from_launcher(__file__)
m = load_base("01_gated_fusion.py", "fusion_wo_gate_base")
m.ROOT = DATA
m.DATA = DATA
m.DEFAULT_PROTEIN_PT = DATA / "ESM2_full_1to1" / "full_1to1_esm2_mean.pt"
m.DEFAULT_DNA_PT = DATA / "DNABERT2_full_1to1" / "full_1to1_dnabert2_mean.pt"
m.DEFAULT_TRAIN_IDS = DATA / "train_ids_subtype2.txt"
m.DEFAULT_TEST_IDS = DATA / "test_ids_subtype2.txt"
m.DEFAULT_OUTPUT_PT = DATA / "Long_fusion_subtype2_nogate" / "long_fusion_subtype2_nogate.pt"

def equal_weight_encode(self, protein, dna):
    protein, dna = self.standardize(protein, dna)
    protein_projected = self.protein_projection(protein)
    dna_projected = self.dna_projection(dna)
    gate = m.torch.full_like(protein_projected, 0.5)
    fused = self.fusion_norm(0.5 * protein_projected + 0.5 * dna_projected)
    return fused, gate

m.SupervisedGatedFusion.encode = equal_weight_encode
original_stamp = m.contract.stamp_fusion
def stamp(output, structure, train_ids, test_ids, output_path):
    output["fusion_method"] = "Subtype-supervised equal-weight fusion (w/o Adaptive Gating)"
    output["fusion_formula"] = "0.5*protein_projection + 0.5*DNA_projection"
    output["ablation"] = {"label": "w/o Adaptive Gating", "removed_information_path": "learned gate MLP; fixed gate=0.5"}
    return original_stamp(output, structure, train_ids, test_ids, output_path)
m.contract.stamp_fusion = stamp
add_default_structure(DATA)
m.main()
