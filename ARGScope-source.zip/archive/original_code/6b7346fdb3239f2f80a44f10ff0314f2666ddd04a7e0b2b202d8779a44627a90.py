import pandas as pd

# =========================
# 输入文件
# =========================
ARG_PROTEIN_FASTA = "output_protein.fasta"
ARG_DNA_FASTA = "output_dna.fasta"
ARG_LABEL_CSV = "1. Long_AA_label.csv"

NONARG_PROTEIN_FASTA = "sampled_protein_13439.fasta"
NONARG_DNA_FASTA = "sampled_dna_13439.fasta"

# =========================
# 输出文件
# =========================
OUTPUT_PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
OUTPUT_DNA_FASTA = "all_arg_nonarg_dna.fasta"
OUTPUT_LABEL_CSV = "all_arg_nonarg_id_label.csv"

# =========================
# ARG label 文件列名
# =========================
ARG_ID_COL = "id"
ARG_TYPE_COL = "Type"
ARG_SUBTYPE_COL = "Subtype"

# =========================
# nonARG 标签
# =========================
NONARG_TYPE = "nonARG"
NONARG_SUBTYPE = "nonARG"


def read_fasta(fasta_file):
    """
    读取 FASTA
    返回:
        records: dict[id] = sequence
        order: list[id]
    """
    records = {}
    order = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    seq_id = header.split()[0]
                    seq = "".join(seq_lines)
                    if seq_id in records:
                        raise ValueError(f"{fasta_file} 中存在重复 id: {seq_id}")
                    records[seq_id] = seq
                    order.append(seq_id)
                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line)

        if header is not None:
            seq_id = header.split()[0]
            seq = "".join(seq_lines)
            if seq_id in records:
                raise ValueError(f"{fasta_file} 中存在重复 id: {seq_id}")
            records[seq_id] = seq
            order.append(seq_id)

    return records, order


def write_fasta(records, output_file, width=60):
    """
    records: list of (id, seq)
    """
    with open(output_file, "w", encoding="utf-8") as f:
        for seq_id, seq in records:
            f.write(f">{seq_id}\n")
            for i in range(0, len(seq), width):
                f.write(seq[i:i+width] + "\n")


def main():
    # 1. 读取 ARG fasta
    arg_protein_dict, arg_protein_order = read_fasta(ARG_PROTEIN_FASTA)
    arg_dna_dict, arg_dna_order = read_fasta(ARG_DNA_FASTA)

    # 2. 读取 nonARG fasta
    nonarg_protein_dict, nonarg_protein_order = read_fasta(NONARG_PROTEIN_FASTA)
    nonarg_dna_dict, nonarg_dna_order = read_fasta(NONARG_DNA_FASTA)

    # 3. 检查 ARG protein/dna 是否一一对应
    arg_protein_ids = set(arg_protein_dict.keys())
    arg_dna_ids = set(arg_dna_dict.keys())
    if arg_protein_ids != arg_dna_ids:
        only_in_protein = sorted(arg_protein_ids - arg_dna_ids)
        only_in_dna = sorted(arg_dna_ids - arg_protein_ids)
        raise ValueError(
            f"ARG protein 和 DNA id 不一致。\n"
            f"Only in protein: {len(only_in_protein)}\n"
            f"Only in DNA: {len(only_in_dna)}"
        )

    # 4. 检查 nonARG protein/dna 是否一一对应
    nonarg_protein_ids = set(nonarg_protein_dict.keys())
    nonarg_dna_ids = set(nonarg_dna_dict.keys())
    if nonarg_protein_ids != nonarg_dna_ids:
        only_in_protein = sorted(nonarg_protein_ids - nonarg_dna_ids)
        only_in_dna = sorted(nonarg_dna_ids - nonarg_protein_ids)
        raise ValueError(
            f"nonARG protein 和 DNA id 不一致。\n"
            f"Only in protein: {len(only_in_protein)}\n"
            f"Only in DNA: {len(only_in_dna)}"
        )

    # 5. 读取 ARG label
    arg_label_df = pd.read_csv(ARG_LABEL_CSV)

    required_cols = [ARG_ID_COL, ARG_TYPE_COL, ARG_SUBTYPE_COL]
    for col in required_cols:
        if col not in arg_label_df.columns:
            raise ValueError(f"ARG label 文件缺少列: {col}")

    arg_label_df = arg_label_df[[ARG_ID_COL, ARG_TYPE_COL, ARG_SUBTYPE_COL]].copy()
    arg_label_df.columns = ["id", "type", "subtype"]
    arg_label_df["id"] = arg_label_df["id"].astype(str).str.strip()
    arg_label_df["type"] = arg_label_df["type"].astype(str).str.strip()
    arg_label_df["subtype"] = arg_label_df["subtype"].astype(str).str.strip()

    # 6. 只保留既在 ARG fasta 又在 ARG label 里的 id
    arg_common_ids = [x for x in arg_protein_order if x in set(arg_label_df["id"])]
    missing_arg_label = sorted(arg_protein_ids - set(arg_label_df["id"]))
    if len(missing_arg_label) > 0:
        print(f"Warning: ARG fasta 中有 {len(missing_arg_label)} 个 id 在 label 文件中找不到，已自动丢弃。")

    arg_label_df = arg_label_df[arg_label_df["id"].isin(arg_common_ids)].copy()
    arg_label_df = arg_label_df.drop_duplicates(subset=["id"]).copy()

    # 为了保持与 fasta 顺序一致
    arg_label_df = arg_label_df.set_index("id").loc[arg_common_ids].reset_index()

    # 7. 构造 nonARG label
    nonarg_ids = nonarg_protein_order
    nonarg_label_df = pd.DataFrame({
        "id": nonarg_ids,
        "type": [NONARG_TYPE] * len(nonarg_ids),
        "subtype": [NONARG_SUBTYPE] * len(nonarg_ids)
    })

    # 8. 检查 ARG 和 nonARG 是否有重复 id
    overlap_ids = set(arg_common_ids) & set(nonarg_ids)
    if len(overlap_ids) > 0:
        raise ValueError(
            f"ARG 与 nonARG 之间存在重复 id，共 {len(overlap_ids)} 个，例如: {list(sorted(overlap_ids))[:10]}"
        )

    # 9. 合并 protein fasta
    merged_protein_records = []
    for seq_id in arg_common_ids:
        merged_protein_records.append((seq_id, arg_protein_dict[seq_id]))
    for seq_id in nonarg_ids:
        merged_protein_records.append((seq_id, nonarg_protein_dict[seq_id]))

    # 10. 合并 dna fasta
    merged_dna_records = []
    for seq_id in arg_common_ids:
        merged_dna_records.append((seq_id, arg_dna_dict[seq_id]))
    for seq_id in nonarg_ids:
        merged_dna_records.append((seq_id, nonarg_dna_dict[seq_id]))

    # 11. 合并 label
    merged_label_df = pd.concat([arg_label_df, nonarg_label_df], ignore_index=True)

    # 12. 输出文件
    write_fasta(merged_protein_records, OUTPUT_PROTEIN_FASTA)
    write_fasta(merged_dna_records, OUTPUT_DNA_FASTA)
    merged_label_df.to_csv(OUTPUT_LABEL_CSV, index=False)

    # 13. 打印统计
    print("处理完成。")
    print(f"ARG 样本数: {len(arg_common_ids)}")
    print(f"nonARG 样本数: {len(nonarg_ids)}")
    print(f"合并后总样本数: {len(merged_label_df)}")
    print(f"输出 protein FASTA: {OUTPUT_PROTEIN_FASTA}")
    print(f"输出 DNA FASTA: {OUTPUT_DNA_FASTA}")
    print(f"输出 id-label CSV: {OUTPUT_LABEL_CSV}")


if __name__ == "__main__":
    main()