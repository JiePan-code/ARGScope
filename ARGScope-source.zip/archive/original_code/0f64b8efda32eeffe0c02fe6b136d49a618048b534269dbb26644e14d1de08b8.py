from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

# 优先使用这个文件名；如果不存在，会自动寻找类似文件
PRED_FILE = BASE_DIR / "subtype_predictions_all_DNA.csv"

if not PRED_FILE.exists():
    candidate_files = sorted(BASE_DIR.glob("*subtype*prediction*.csv"))

    if len(candidate_files) == 0:
        raise FileNotFoundError(
            "当前文件夹中没有找到 subtype_predictions_all_DNA.csv 或类似的 subtype prediction CSV 文件。"
        )

    PRED_FILE = candidate_files[0]


OUTPUT_DIR = BASE_DIR / "subtype_misclassification_pairs_type_correct"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "subtype_misclassification_pairs_type_correct_top20.pdf"
OUTPUT_TIF = OUTPUT_DIR / "subtype_misclassification_pairs_type_correct_top20.tif"

OUTPUT_CSV = OUTPUT_DIR / "subtype_misclassification_pairs_type_correct_all.csv"
OUTPUT_TOP_CSV = OUTPUT_DIR / "subtype_misclassification_pairs_type_correct_top20.csv"
OUTPUT_ERROR_SAMPLES = OUTPUT_DIR / "subtype_misclassified_samples_with_type_status.csv"


# =========================================================
# 2. 参数设置
# =========================================================

TOP_N = 20

# False：保留所有 subtype 错误，包括 nonARG 相关错误
# True：排除 nonARG → ARG subtype 和 ARG subtype → nonARG
EXCLUDE_NONARG_RELATED = False

# 图中显示短 subtype 名称；CSV 中仍保留完整 subtype 信息
USE_SHORT_LABEL_IN_PLOT = True

TIF_DPI = 300

COLOR_TYPE_CORRECT = "#00A087"    # subtype 错，但 type 对
COLOR_TYPE_INCORRECT = "#E64B35"  # subtype 错，type 也错

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})


# =========================================================
# 3. 读取数据
# =========================================================

df = pd.read_csv(PRED_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["Subtype", "Pred_Subtype"]
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"{PRED_FILE.name} 缺少这些列: {missing_cols}")

df["Subtype"] = df["Subtype"].astype(str).str.strip()
df["Pred_Subtype"] = df["Pred_Subtype"].astype(str).str.strip()


# =========================================================
# 4. 工具函数
# =========================================================

def infer_type_from_subtype(subtype):
    subtype = str(subtype).strip()

    if subtype == "nonARG":
        return "nonARG"

    if "__" in subtype:
        return subtype.split("__", 1)[0]

    return "Unknown"


def shorten_subtype_label(subtype):
    subtype = str(subtype).strip()

    if subtype == "nonARG":
        return "nonARG"

    if "__" in subtype:
        return subtype.split("__", 1)[1]

    return subtype


# =========================================================
# 5. 准备 Type / Pred_Type
# =========================================================

if "Type" not in df.columns:
    df["Type"] = df["Subtype"].map(infer_type_from_subtype)
else:
    df["Type"] = df["Type"].astype(str).str.strip()

if "Pred_Type" not in df.columns:
    df["Pred_Type"] = df["Pred_Subtype"].map(infer_type_from_subtype)
else:
    df["Pred_Type"] = df["Pred_Type"].astype(str).str.strip()


# =========================================================
# 6. 只保留 subtype-level 错误预测
# =========================================================

if "Subtype_correct" in df.columns:
    subtype_correct = df["Subtype_correct"].astype(str).str.lower().str.strip()

    error_df = df[subtype_correct.isin(["false", "0", "no"])].copy()

    if len(error_df) == 0 and (df["Subtype"] != df["Pred_Subtype"]).any():
        error_df = df[df["Subtype"] != df["Pred_Subtype"]].copy()
else:
    error_df = df[df["Subtype"] != df["Pred_Subtype"]].copy()

if EXCLUDE_NONARG_RELATED:
    error_df = error_df[
        (error_df["Subtype"] != "nonARG")
        & (error_df["Pred_Subtype"] != "nonARG")
    ].copy()

if len(error_df) == 0:
    raise ValueError("没有发现符合条件的 subtype-level 错误预测，无法绘制错误预测图。")


# =========================================================
# 7. 判断 type 是否仍然正确
# =========================================================

error_df["Type_Correct_When_Subtype_Wrong"] = (
    error_df["Type"].astype(str) == error_df["Pred_Type"].astype(str)
)

error_df["Type_Status"] = np.where(
    error_df["Type_Correct_When_Subtype_Wrong"],
    "Type correct",
    "Type incorrect",
)

error_df["True_Subtype_full"] = error_df["Subtype"]
error_df["Pred_Subtype_full"] = error_df["Pred_Subtype"]

error_df["True_Subtype_short"] = error_df["Subtype"].map(shorten_subtype_label)
error_df["Pred_Subtype_short"] = error_df["Pred_Subtype"].map(shorten_subtype_label)

error_df["Full_Pair"] = (
    error_df["True_Subtype_full"].astype(str)
    + " \u2192 "
    + error_df["Pred_Subtype_full"].astype(str)
)

error_df["Short_Pair"] = (
    error_df["True_Subtype_short"].astype(str)
    + " \u2192 "
    + error_df["Pred_Subtype_short"].astype(str)
)

error_df.to_csv(
    OUTPUT_ERROR_SAMPLES,
    index=False,
    encoding="utf-8-sig",
)


# =========================================================
# 8. 统计每个 subtype 错误 pair 中 type correct / incorrect 数量
# =========================================================

pair_status_df = (
    error_df
    .groupby(["Subtype", "Pred_Subtype", "Type_Status"])
    .size()
    .reset_index(name="Count")
)

pair_pivot = (
    pair_status_df
    .pivot_table(
        index=["Subtype", "Pred_Subtype"],
        columns="Type_Status",
        values="Count",
        fill_value=0,
        aggfunc="sum",
    )
    .reset_index()
)

for col in ["Type correct", "Type incorrect"]:
    if col not in pair_pivot.columns:
        pair_pivot[col] = 0

pair_pivot["Type_correct_count"] = pair_pivot["Type correct"].astype(int)
pair_pivot["Type_incorrect_count"] = pair_pivot["Type incorrect"].astype(int)

pair_pivot["Total_Count"] = (
    pair_pivot["Type_correct_count"]
    + pair_pivot["Type_incorrect_count"]
)

pair_pivot["Type_correct_percentage"] = (
    pair_pivot["Type_correct_count"] / pair_pivot["Total_Count"] * 100
)

pair_pivot["Type_incorrect_percentage"] = (
    pair_pivot["Type_incorrect_count"] / pair_pivot["Total_Count"] * 100
)

pair_pivot["True_Subtype_full"] = pair_pivot["Subtype"]
pair_pivot["Pred_Subtype_full"] = pair_pivot["Pred_Subtype"]

pair_pivot["True_Subtype_short"] = pair_pivot["Subtype"].map(shorten_subtype_label)
pair_pivot["Pred_Subtype_short"] = pair_pivot["Pred_Subtype"].map(shorten_subtype_label)

pair_pivot["Full_Pair"] = (
    pair_pivot["True_Subtype_full"].astype(str)
    + " \u2192 "
    + pair_pivot["Pred_Subtype_full"].astype(str)
)

pair_pivot["Short_Pair"] = (
    pair_pivot["True_Subtype_short"].astype(str)
    + " \u2192 "
    + pair_pivot["Pred_Subtype_short"].astype(str)
)

if USE_SHORT_LABEL_IN_PLOT:
    pair_pivot["Pair"] = pair_pivot["Short_Pair"]
else:
    pair_pivot["Pair"] = pair_pivot["Full_Pair"]

pair_pivot = (
    pair_pivot
    .sort_values(
        ["Total_Count", "Type_correct_count", "Subtype", "Pred_Subtype"],
        ascending=[False, False, True, True],
    )
    .reset_index(drop=True)
)

output_cols = [
    "Subtype",
    "Pred_Subtype",
    "Full_Pair",
    "Short_Pair",
    "True_Subtype_full",
    "Pred_Subtype_full",
    "True_Subtype_short",
    "Pred_Subtype_short",
    "Type_correct_count",
    "Type_incorrect_count",
    "Total_Count",
    "Type_correct_percentage",
    "Type_incorrect_percentage",
]

pair_pivot[output_cols].to_csv(
    OUTPUT_CSV,
    index=False,
    encoding="utf-8-sig",
)

top_df = pair_pivot.head(TOP_N).copy()

top_df[output_cols].to_csv(
    OUTPUT_TOP_CSV,
    index=False,
    encoding="utf-8-sig",
)


# =========================================================
# 9. 绘图：堆叠横向柱状图
# =========================================================

plot_df = top_df.sort_values("Total_Count", ascending=True).reset_index(drop=True)

n_pairs = len(plot_df)
fig_height = max(4.8, n_pairs * 0.36)

max_label_len = plot_df["Pair"].astype(str).str.len().max()
fig_width = max(8.8, min(13.2, 7.2 + max_label_len * 0.055))

fig, ax = plt.subplots(figsize=(fig_width, fig_height), dpi=600)

y_pos = np.arange(n_pairs)

type_correct_values = plot_df["Type_correct_count"].values
type_incorrect_values = plot_df["Type_incorrect_count"].values
total_values = plot_df["Total_Count"].values

ax.barh(
    y_pos,
    type_correct_values,
    color=COLOR_TYPE_CORRECT,
    edgecolor="black",
    linewidth=0.45,
    height=0.68,
    label="Subtype wrong, type correct",
)

ax.barh(
    y_pos,
    type_incorrect_values,
    left=type_correct_values,
    color=COLOR_TYPE_INCORRECT,
    edgecolor="black",
    linewidth=0.45,
    height=0.68,
    label="Subtype wrong, type incorrect",
)

ax.set_yticks(y_pos)
ax.set_yticklabels(plot_df["Pair"], fontsize=7)

ax.set_xlabel("Number of subtype-level misclassified samples")
ax.set_ylabel("")

ax.set_title(
    f"Top {len(plot_df)} subtype-level misclassification pairs with type-level correctness",
    fontsize=11,
    pad=12,
)

max_total = int(plot_df["Total_Count"].max())

for y, total, type_correct_pct in zip(
    y_pos,
    plot_df["Total_Count"],
    plot_df["Type_correct_percentage"],
):
    ax.text(
        total + max_total * 0.025,
        y,
        f"{int(total)} ({type_correct_pct:.1f}% type-correct)",
        va="center",
        ha="left",
        fontsize=7,
    )

ax.set_xlim(0, max_total * 1.42)

ax.grid(
    axis="x",
    linestyle="-",
    linewidth=0.45,
    alpha=0.45,
)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

legend = ax.legend(
    loc="lower right",
    frameon=True,
    fontsize=7,
    borderpad=0.45,
    handlelength=1.4,
    handletextpad=0.45,
)

legend.get_frame().set_linewidth(0.6)
legend.get_frame().set_edgecolor("black")

plt.tight_layout()


# =========================================================
# 10. 保存图片
# =========================================================

fig.savefig(OUTPUT_PDF, bbox_inches="tight")

fig.savefig(
    OUTPUT_TIF,
    dpi=TIF_DPI,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 11. 输出结果
# =========================================================

print("\nInput file:")
print(PRED_FILE)

print("\nTotal subtype-level misclassified samples:")
print(len(error_df))

print("\nOverall type correctness among subtype-level errors:")
print(error_df["Type_Status"].value_counts())

print("\nTop subtype-level misclassification pairs:")
print(top_df[[
    "Subtype",
    "Pred_Subtype",
    "Full_Pair",
    "Short_Pair",
    "Type_correct_count",
    "Type_incorrect_count",
    "Total_Count",
    "Type_correct_percentage",
]])

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_CSV)
print(OUTPUT_TOP_CSV)
print(OUTPUT_ERROR_SAMPLES)