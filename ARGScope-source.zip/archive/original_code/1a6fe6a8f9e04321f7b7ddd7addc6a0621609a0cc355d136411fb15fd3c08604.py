#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
统计 ARGScope multi-length Protein 模型在 coverage 数据集上的逐 Type 指标。

只读取：
    coverage_evaluation/
        60p_fragment_predictions.csv
        70p_fragment_predictions.csv
        80p_fragment_predictions.csv
        90p_fragment_predictions.csv
        100p_fragment_predictions.csv

每个结果表固定只有6列：
    Type
    ACC
    PRECISION
    RECALL
    F1
    MCC

说明：
    ACC = correct_count / support
    该定义沿用此前逐 Type 表格中的 class-level ACC，
    因此 ACC 与 RECALL 数值相同。
"""

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
)


# =============================================================================
# 1. 路径设置
# =============================================================================

RESULT_ROOT = Path(
    r"E:\1. ARG模型对比\1. NonARG 训练\1.protein_based_model"
    r"\ARGScope_multilength_protein_student_outputs_overlapfix_v2"
)

# 只使用全部覆盖结果
EVALUATION_DIR = RESULT_ROOT / "coverage_evaluation"

OUTPUT_DIR = RESULT_ROOT / "per_type_results_coverage"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

LENGTHS = ["60p", "70p", "80p", "90p", "100p"]

TRUE_TYPE_COL = "Type"
PRED_TYPE_COL = "Pred_Type"

# 用于固定所有长度下的 Type 顺序
TYPE_MAP_FILE = RESULT_ROOT / "subtype_type_map.csv"


# =============================================================================
# 2. 工具函数
# =============================================================================

def normalize_type_name(value):
    return str(value).strip()


def load_expected_types():
    """
    从 subtype_type_map.csv 中读取完整 Type 列表。

    coverage 数据通常覆盖全部 2825 个 Subtype 和全部 31 个 ARG Type。
    """
    if not TYPE_MAP_FILE.is_file():
        return []

    df = pd.read_csv(TYPE_MAP_FILE, low_memory=False)

    type_col = None
    for candidate in ["Type", "type", "TYPE"]:
        if candidate in df.columns:
            type_col = candidate
            break

    if type_col is None:
        return []

    values = (
        df[type_col]
        .dropna()
        .map(normalize_type_name)
    )

    return sorted([x for x in values.unique().tolist() if x])


def calculate_type_metrics(y_true, y_pred, type_name):
    """
    将当前 Type 作为正类，其余 Type 作为负类，计算 one-vs-rest 指标。
    """
    true_mask = y_true == type_name
    pred_mask = y_pred == type_name

    tp = int(np.sum(true_mask & pred_mask))
    fn = int(np.sum(true_mask & ~pred_mask))

    support = tp + fn

    # 与用户此前逐 Type 结果表保持一致
    acc = tp / support if support > 0 else 0.0

    y_true_binary = true_mask.astype(np.int8)
    y_pred_binary = pred_mask.astype(np.int8)

    precision = precision_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )
    recall = recall_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )
    f1 = f1_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )

    if (
        len(np.unique(y_true_binary)) == 1
        and len(np.unique(y_pred_binary)) == 1
    ):
        mcc = 0.0
    else:
        mcc = matthews_corrcoef(
            y_true_binary,
            y_pred_binary,
        )

    return {
        "Type": type_name,
        "ACC": acc,
        "PRECISION": precision,
        "RECALL": recall,
        "F1": f1,
        "MCC": mcc,
    }


def calculate_one_length(length_name, expected_types):
    prediction_file = (
        EVALUATION_DIR
        / f"{length_name}_fragment_predictions.csv"
    )

    if not prediction_file.is_file():
        raise FileNotFoundError(
            f"找不到 coverage 预测文件：{prediction_file}"
        )

    df = pd.read_csv(prediction_file, low_memory=False)

    missing_cols = [
        col for col in [TRUE_TYPE_COL, PRED_TYPE_COL]
        if col not in df.columns
    ]
    if missing_cols:
        raise ValueError(
            f"{prediction_file.name} 缺少列：{missing_cols}\n"
            f"现有列：{df.columns.tolist()}"
        )

    if (
        df[TRUE_TYPE_COL].isna().any()
        or df[PRED_TYPE_COL].isna().any()
    ):
        raise ValueError(
            f"{prediction_file.name} 的 Type 列存在缺失值。"
        )

    y_true = (
        df[TRUE_TYPE_COL]
        .map(normalize_type_name)
        .to_numpy(dtype=str)
    )
    y_pred = (
        df[PRED_TYPE_COL]
        .map(normalize_type_name)
        .to_numpy(dtype=str)
    )

    observed_types = sorted(set(y_true) | set(y_pred))

    if expected_types:
        type_names = sorted(
            set(expected_types) | set(observed_types)
        )
    else:
        type_names = observed_types

    rows = [
        calculate_type_metrics(
            y_true=y_true,
            y_pred=y_pred,
            type_name=type_name,
        )
        for type_name in type_names
    ]

    result = pd.DataFrame(
        rows,
        columns=[
            "Type",
            "ACC",
            "PRECISION",
            "RECALL",
            "F1",
            "MCC",
        ],
    )

    # 保证不同长度下 Type 行顺序完全一致
    result = result.sort_values(
        "Type",
        ascending=True,
    ).reset_index(drop=True)

    return result


# =============================================================================
# 3. 主程序
# =============================================================================

def main():
    print("=" * 80)
    print("ARGScope coverage per-Type metrics: 60p-100p")
    print("=" * 80)
    print("Result root:", RESULT_ROOT)
    print("Coverage directory:", EVALUATION_DIR)
    print("Output directory:", OUTPUT_DIR)

    if not RESULT_ROOT.is_dir():
        raise FileNotFoundError(
            f"结果根目录不存在：{RESULT_ROOT}"
        )

    if not EVALUATION_DIR.is_dir():
        raise FileNotFoundError(
            f"coverage结果目录不存在：{EVALUATION_DIR}"
        )

    expected_types = load_expected_types()

    if expected_types:
        print(
            f"从 subtype_type_map.csv 中读取到 "
            f"{len(expected_types)} 个 Type。"
        )
    else:
        print(
            "未读取固定 Type 列表，将从 coverage 预测文件自动提取。"
        )

    result_tables = {}

    for length_name in LENGTHS:
        result = calculate_one_length(
            length_name=length_name,
            expected_types=expected_types,
        )

        result_tables[length_name] = result

        output_csv = (
            OUTPUT_DIR
            / f"{length_name}_coverage_type_metrics.csv"
        )

        result.round(4).to_csv(
            output_csv,
            index=False,
            encoding="utf-8-sig",
        )

        print(
            f"{length_name}: Type数={len(result)}, "
            f"保存至 {output_csv}"
        )

    # 每个完整度一个工作表，每个工作表只有6列
    output_excel = (
        OUTPUT_DIR
        / "coverage_per_type_metrics_60p_to_100p.xlsx"
    )

    with pd.ExcelWriter(
        output_excel,
        engine="openpyxl",
    ) as writer:
        for length_name in LENGTHS:
            result_tables[length_name].round(4).to_excel(
                writer,
                sheet_name=length_name,
                index=False,
            )

    print("\n完成。")
    print("Excel文件：", output_excel)
    print("每个工作表只有以下6列：")
    print("Type, ACC, PRECISION, RECALL, F1, MCC")


if __name__ == "__main__":
    main()
