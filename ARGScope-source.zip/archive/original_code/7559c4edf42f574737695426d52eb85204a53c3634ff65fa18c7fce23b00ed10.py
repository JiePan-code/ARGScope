"""Visual-only revision of the user's latest editable Figure 1; no source overwrite."""
from pathlib import Path
import base64
import copy
import hashlib
import json
import math
import shutil
import xml.etree.ElementTree as ET
import zlib
from urllib.parse import unquote
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/ARGScope_drawio_20260930/Figure1_ARGScope_overview.drawio')
OUT = ROOT / 'outputs/ARGScope_Figure1_visual_v2_20260930'
ASSETS = OUT / 'assets'
BLUE, TEAL, INK = '#3478AE', '#259B91', '#283743'
GENERATED = Path('C:/Users/Jie Pan/.codex/generated_images/01a0a3ba-f486-7350-8f21-6249a3799116')


def circle(x,y,r,color,opacity=1,stroke='none',sw=0):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" fill-opacity="{opacity}" stroke="{stroke}" stroke-width="{sw}"/>'


def line(x1,y1,x2,y2,color=INK,width=3,opacity=1):
    return f'<path d="M {x1} {y1} L {x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}" opacity="{opacity}" stroke-linecap="round"/>'


def star(x,y,r,color,inner=.46):
    pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5
        rr=r if i%2==0 else r*inner
        pts.append(f'{x+rr*math.cos(a):.2f},{y+rr*math.sin(a):.2f}')
    return f'<polygon points="{" ".join(pts)}" fill="{color}" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/>'


def write_svg(name,body):
    defs=''.join(f'<linearGradient id="{key}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{c}" stop-opacity=".40"/><stop offset="1" stop-color="{c}"/></linearGradient>' for key,c in [('blue',BLUE),('teal',TEAL),('ink',INK)])
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="256" height="224" viewBox="0 0 256 224"><title>{name.replace("_"," ")}</title><defs>{defs}</defs>{body}</svg>'
    path=ASSETS/(name+'.svg')
    path.write_text(svg,encoding='utf-8')
    return path


def matrix(name,colors):
    body=''
    # A compact stack with visible top/side faces and a gridded front.
    for layer in range(2,-1,-1):
        x,y=35+layer*13,66-layer*18
        c=colors[layer % len(colors)]
        body+=f'<rect x="{x}" y="{y}" width="159" height="105" rx="8" fill="#FFFFFF"/>'
        body+=f'<rect x="{x}" y="{y}" width="159" height="105" rx="8" fill="{c}" fill-opacity="{.14+(.1*(2-layer))}" stroke="{c}" stroke-opacity=".7" stroke-width="2.2"/>'
        for row in range(3):
            for col in range(5):
                opacity=.3+.11*((row+col+layer)%5)
                body+=f'<rect x="{x+10+col*28}" y="{y+11+row*28}" width="23" height="23" rx="3" fill="{c}" fill-opacity="{opacity:.2f}"/>'
    return write_svg(name,body)


def clusters():
    body=''
    for x,y,c in [(66,60,BLUE),(189,63,TEAL),(125,158,INK)]:
        body+=circle(x,y,47,c,.08)
        body+=f'<circle cx="{x}" cy="{y}" r="46" stroke="{c}" stroke-width="1.4" stroke-opacity=".23" fill="none"/>'
        for dx,dy,r in [(-24,-13,6),(4,-30,6.5),(30,-4,6),(-18,25,6),(22,27,5.5),(-33,7,5)]:
            body+=circle(x+dx,y+dy,r,c,.85)
        body+=star(x,y,21,c)
    return write_svg('subtype_clusters',body)


def prototypes(name='refined_prototypes',with_center=False):
    body=''
    centers=[(64,65,BLUE),(190,65,TEAL),(127,158,INK)]
    for x,y,c in centers:
        body+=circle(x,y,39,c,.09)
        body+=f'<circle cx="{x}" cy="{y}" r="33" fill="none" stroke="{c}" stroke-width="1.5" stroke-opacity=".22"/>'
        body+=star(x,y,29,c)
    if with_center:
        # An explicitly separate non-ARG centre, not another graph node.
        body=line(153,140,206,169,INK,2,.3)+body
        body+=circle(220,181,21,INK,.12)+circle(220,181,11,INK,.8)
    return write_svg(name,body)


def graph(name,attention=False):
    pts=[(59,49),(136,29),(206,79),(183,170),(81,185),(116,111)]
    colors=[BLUE,TEAL,INK,BLUE,TEAL,BLUE]
    edges=[(0,1),(0,5),(0,4),(1,2),(1,5),(2,3),(2,5),(3,4),(3,5),(4,5)]
    body=''
    for i,j in edges:
        strong=attention and (i,j) in [(0,5),(1,5),(2,5),(3,5)]
        body+=line(*pts[i],*pts[j],colors[i] if strong else INK,5 if strong else 2.5,.9 if strong else .27)
    for (x,y),c in zip(pts,colors):
        # Self-loop glyphs are visible and separate from the node outline.
        body+=f'<path d="M{x-7} {y-11} C{x-31} {y-47} {x+35} {y-47} {x+8} {y-11}" fill="none" stroke="{c}" stroke-opacity=".65" stroke-width="2"/>'
        body+=circle(x,y,17,'#FFFFFF')
        body+=circle(x,y,17,c,.21,c,2.6)
        body+=circle(x-3,y-4,6,c,.55)
    if attention:
        body+=f'<path d="M 218 116 C 263 201 134 235 56 205" fill="none" stroke="{INK}" stroke-width="3" stroke-dasharray="6 5" stroke-linecap="round"/>'
        body+=f'<path d="M 67 201 L 55 205 L 63 216" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'
    return write_svg(name,body)


def network(name,c):
    layers=[[(42,66),(42,158)],[(126,34),(126,86),(126,138),(126,190)],[(214,72),(214,152)]]
    body=''
    for left,right in zip(layers,layers[1:]):
        for p in left:
            for q in right: body+=line(*p,*q,c,2.5,.35)
    for k,layer in enumerate(layers):
        for x,y in layer:
            body+=circle(x,y,18,'#FFFFFF')
            body+=circle(x,y,18,c,.22 if k!=1 else .65,c,2.4)
            body+=circle(x-4,y-5,5,'#FFFFFF',.65)
    return write_svg(name,body)


def predictions():
    body=line(32,187,231,187,INK,3,.7)
    for x,y,w,h,c,o in [(49,107,54,80,INK,.24),(143,43,54,144,INK,.83)]:
        body+=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="7" fill="{c}" fill-opacity="{o}"/>'
    return write_svg('teacher_predictions',body)


def anchoring():
    body=''
    for x,c in [(27,BLUE),(157,INK)]:
        for col in range(3):
            for row in range(4):
                body+=f'<rect x="{x+23*col}" y="{50+30*row}" width="19" height="24" rx="3" fill="{c}" fill-opacity="{.32+.16*((row+col)%4):.2f}"/>'
    body+=f'<path d="M 146 111 L 110 111 M 119 102 L 110 111 L 119 120" fill="none" stroke="{INK}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>'
    return write_svg('head_anchoring',body)


def parse_style(c):
    tokens=c.get('style','').split(';')
    bare=[t for t in tokens if t and '=' not in t]
    props=dict(t.split('=',1) for t in tokens if '=' in t)
    return bare,props


def set_style(c,**updates):
    bare,props=parse_style(c)
    props.update({k:str(v) for k,v in updates.items()})
    c.set('style',';'.join(bare+[f'{k}={v}' for k,v in props.items()])+';')


def main():
    ASSETS.mkdir(parents=True,exist_ok=True)
    source_bytes=SOURCE.read_bytes()
    source_hash=hashlib.sha256(source_bytes).hexdigest()
    doc=ET.fromstring(source_bytes)
    page=doc.find('diagram')
    model=page.find('mxGraphModel')
    if model is None:
        model=ET.fromstring(unquote(zlib.decompress(base64.b64decode(page.text),-15).decode()))
        page.text=None
        page.append(model)
    cells={c.get('id'):c for c in model.iter('mxCell')}
    original_values={k:c.get('value') for k,c in cells.items()}
    original_edges={k:ET.tostring(c).decode() for k,c in cells.items() if c.get('edge')=='1'}
    raw_snapshot=copy.deepcopy(model)

    bio={}
    alpha={}
    for name,fn in [('protein_ribbon','exec-2c35044f-1603-4ef5-9182-fcc69cbac83e.png'),('dna_double_helix','exec-6c21a321-b709-49fd-b414-5e7a5b819409.png')]:
        p=ASSETS/(name+'.png')
        shutil.copy2(GENERATED/fn,p)
        with Image.open(p) as im:
            assert im.mode=='RGBA'
            extrema=im.getchannel('A').getextrema()
            assert extrema[0]==0 and extrema[1]==255
            alpha[name]={'size':im.size,'alpha_range':extrema}
        bio[name]=p

    assets={
        'v7':bio['protein_ribbon'],'v102':bio['protein_ribbon'],
        'v12':bio['dna_double_helix'],'v110':bio['dna_double_helix'],
        'v35':clusters(),'v38':graph('mutual_knn'),
        'v41':graph('residual_gat',True),'v44':prototypes(),
        'v72':predictions(),'v75':matrix('fused_embedding',[BLUE,TEAL,BLUE]),
        'v78':prototypes('prototype_alignment',True),'v81':anchoring(),
        'v87':matrix('protein_embedding',[BLUE]),'v89':network('protein_student',BLUE),
        'v93':matrix('nucleotide_embedding',[TEAL]),'v95':network('nucleotide_student',TEAL),
    }
    for ident,path in assets.items():
        mime='png' if path.suffix=='.png' else 'svg+xml'
        uri='data:image/'+mime+','+base64.b64encode(path.read_bytes()).decode()
        set_style(cells[ident],image=uri,imageAspect=1,aspect='fixed')

    # Rebalance pictograms while keeping encoder/edge anchors and text intact.
    geometry={
        'v7':(43,272,120,120),'v12':(60,414,93,126),
        'v102':(44,1116,110,110),'v110':(60,1236,90,117),
        'v35':(1021,327,177,146),
        'v38':(1288,328,174,145),'v41':(1547,328,174,145),
        'v44':(1806,328,174,145),
        'v72':(638,740,93,94),'v75':(1004,742,94,94),
        'v78':(638,871,94,94),'v81':(1004,871,94,94),
        'v87':(1435,743,100,101),'v93':(1435,868,100,101),
        'v89':(1579,739,117,110),'v95':(1579,864,117,110),
    }
    for ident,rect in geometry.items():
        g=cells[ident].find('mxGeometry')
        for key,val in zip(('x','y','width','height'),rect):g.set(key,str(val))

    panels=['v4','v18','v31','v52','v70','v85','v101','v118']
    for ident in panels:
        set_style(cells[ident],fillColor=INK,fillOpacity=1,strokeColor=INK,
                  strokeOpacity=27,strokeWidth=1.25,arcSize=18)
    for ident in ['v55','v62']:
        set_style(cells[ident],strokeOpacity=65,strokeWidth=1.4,fillOpacity=4,arcSize=14)
    # Refine outlines rather than adding further panel bars or decoration.
    for ident,c in cells.items():
        bare,props=parse_style(c)
        if c.get('vertex')=='1' and c.get('value') and props.get('rounded')=='1':
            set_style(c,strokeWidth=1.5,strokeOpacity=80,arcSize=12,fillOpacity=6)

    assert original_values=={k:c.get('value') for k,c in cells.items()},'Scientific text changed'
    assert original_edges=={k:ET.tostring(c).decode() for k,c in cells.items() if c.get('edge')=='1'},'Edge/flow changed'
    assert source_hash==hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'Original changed during generation'
    page.set('name','Figure 1 - visual refinement v2')
    doc.set('modified','2026-09-30')
    doc.set('agent','ARGScope visual-only refinement; user source preserved')
    output=OUT/'Figure1_ARGScope_visual_v2.drawio'
    ET.indent(doc)
    ET.ElementTree(doc).write(output,encoding='utf-8',xml_declaration=True)
    validation={
        'source':str(SOURCE),'source_sha256':source_hash,
        'output':str(output),'source_preserved':True,
        'all_scientific_text_unchanged':True,'all_flow_edges_unchanged':True,
        'native_cells':len(cells),'replaced_image_cells':len(assets),
        'new_unique_assets':len(set(assets.values())),
        'vector_base_palette':[BLUE,TEAL,INK],
        'biological_icons':'Generic AI-generated explanatory illustrations, not specific structures',
        'generation_mode':'built-in image_gen; new assets, not whole-figure generation',
        'alpha_checks':alpha,
        'changed_geometry':geometry,
        'cell_asset_map':{k:v.name for k,v in assets.items()},
    }
    (OUT/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(validation,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
