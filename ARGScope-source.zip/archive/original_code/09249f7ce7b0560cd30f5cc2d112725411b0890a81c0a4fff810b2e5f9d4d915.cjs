const fs=require('fs');
const path=require('path');
const sharp=require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve('outputs/argscope_subtype_argonly_20260922/bar_labels_fixed');
(async()=>{
 const qa=path.join(root,'qa'); fs.mkdirSync(qa,{recursive:true});
 const checks=[];
 for(const folder of [root,path.join(root,'editable_text')])for(const file of fs.readdirSync(folder).filter(n=>n.endsWith('.svg'))){
  const svg=fs.readFileSync(path.join(folder,file));
  const result=await sharp(svg,{density:216}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const {width,height,channels}=result.info;
  let last=-1,minAlpha=255;
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
   const a=result.data[(y*width+x)*channels+channels-1];
   minAlpha=Math.min(minAlpha,a); if(a>0)last=Math.max(last,y);
  }
  if(minAlpha!==0||height-last-1<18)throw Error('Missing transparent safety margin');
  const variant=folder===root?'outlined':'editable';
  await sharp(svg,{density:180}).resize({width:1100}).flatten({background:'#fff'}).png().toFile(path.join(qa,variant+'_'+file.replace('.svg','.png')));
  checks.push({file,variant,transparent:true,bottom_clearance_px:height-last-1,render_density:216});
 }
 fs.writeFileSync(path.join(root,'render_verification.json'),JSON.stringify(checks,null,2));
 console.log(JSON.stringify(checks));
})().catch(e=>{console.error(e);process.exit(1)});
