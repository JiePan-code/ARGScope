#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Plot Top-N subtype misclassification pairs.

Goal
----
Create a figure like:
    "Top 20 subtype misclassification pairs inferred from ... predictions"

Each horizontal bar corresponds to one misclassification pair:
    true_subtype -> predicted_subtype

The bar is stacked into:
    1) subtype wrong, type correct
    2) subtype wrong, type incorrect

This is useful for showing that many subtype-level errors remain within
the correct parent ARG Type.

Expected CSV columns
--------------------
true_subtype
predicted_subtype
true_type
predicted_type

Outputs
-------
top_subtype_misclassification_pairs/
    top_subtype_misclassification_pairs.png
    top_subtype_misclassification_pairs.pdf
    top_subtype_misclassification_pairs.svg
    top_subtype_misclassification_pairs_summary.csv

Input behavior
--------------
By default, the script automatically detects a suitable CSV in the same
folder as the script.  You can also explicitly set INPUT_CSV.
"""

from __future__ import annotations

from pathlib import Path
import re

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm


# =============================================================================
# Paths
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# Set to None for auto-detection.
# Or set explicitly, e.g.:
# INPUT_CSV = SCRIPT_DIR / "test_sequence_predictions.csv"
INPUT_CSV = None

OUTDIR = SCRIPT_DIR / "top_subtype_misclassification_pairs"
OUTDIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# Required columns
# =============================================================================

TRUE_SUBTYPE_COL = "true_subtype"
PRED_SUBTYPE_COL = "predicted_subtype"
TRUE_TYPE_COL = "true_type"
PRED_TYPE_COL = "predicted_type"

NONARG_LABELS = {
    "nonarg",
    "non-arg",
    "non_args",
    "nonargs",
}

# Default: subtype-level analysis is intended for true ARG sequences.
EXCLUDE_TRUE_NONARG = True


# =============================================================================
# Plot settings
# =============================================================================

TOP_N = 20
DPI = 600
SAVE_PDF = True
SAVE_SVG = True

FONT_FAMILY = "Arial"

# Change font sizes here if needed.
TITLE_SIZE = 9.0
AXIS_LABEL_SIZE = 8.0
X_TICK_SIZE = 6.5
Y_TICK_SIZE = 5.6
LEGEND_SIZE = 5.8
ANNOT_SIZE = 5.5

# Dynamic figure size base.
# Exact final figure size requested by the user.
# Matplotlib figsize uses inches, so convert cm -> inch.
FIG_WIDTH_CM = 9.15
FIG_HEIGHT_CM = 7.80

BASE_WIDTH = FIG_WIDTH_CM / 2.54
BASE_HEIGHT = FIG_HEIGHT_CM / 2.54

COLOR_TYPE_CORRECT = "#13A38B"    # green-teal
COLOR_TYPE_INCORRECT = "#E76F51"  # orange-red
BAR_EDGE = "#333333"
BAR_LINEWIDTH = 0.45

GRID_COLOR = "#D8D8D8"

TITLE_TEXT = "Top 20 subtype misclassification pairs"
TITLE_SUFFIX = "inferred from test predictions"
SHOW_TITLE = False

# Y-axis label shortening.
# The plotted label is allowed to be shorter than the raw subtype text.
# Raw names are preserved in the exported CSV.
MAX_SINGLE_SUBTYPE_LEN = 18
MAX_WHOLE_PAIR_LEN = 28

# Fixed 9.15 x 7.80 cm canvas.
# Start with enough room for Protein/DNA labels, then perform a rendered-width
# check.  The fitting routine can increase the margin and/or slightly reduce
# only the y-tick font if absolutely necessary.
AUTO_FIT_YLABEL_MARGIN = True
INITIAL_LEFT_MARGIN = 0.43
MAX_LEFT_MARGIN = 0.55
YLABEL_EDGE_PAD_PX = 7.0
MIN_Y_TICK_SIZE = 4.4
Y_TICK_SHRINK_STEP = 0.25

# Reserve an empty strip at the BOTTOM of the axes for the legend.
# The legend itself remains at loc="lower right".
# Increase this value if the legend is still too close to the lowest bars.
LEGEND_RESERVED_ROWS = 2.8


# =============================================================================
# Fonts
# =============================================================================

def configure_fonts() -> None:
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [FONT_FAMILY],
        "font.size": X_TICK_SIZE,
        "axes.titlesize": TITLE_SIZE,
        "axes.labelsize": AXIS_LABEL_SIZE,
        "xtick.labelsize": X_TICK_SIZE,
        "ytick.labelsize": Y_TICK_SIZE,
        "legend.fontsize": LEGEND_SIZE,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
        "savefig.facecolor": "white",
        "savefig.edgecolor": "white",
    })


def report_font_status() -> None:
    try:
        path = fm.findfont(FONT_FAMILY, fallback_to_default=False)
        print(f"[FONT] Arial detected: {path}")
    except Exception:
        print("[FONT WARNING] Arial not found. Using fallback sans-serif font.")


# =============================================================================
# Input discovery
# =============================================================================

def resolve_input_csv() -> Path:
    required = {
        TRUE_SUBTYPE_COL,
        PRED_SUBTYPE_COL,
        TRUE_TYPE_COL,
        PRED_TYPE_COL,
    }

    if INPUT_CSV is not None:
        path = Path(INPUT_CSV)
        if not path.is_absolute():
            path = SCRIPT_DIR / path
        if not path.is_file():
            raise FileNotFoundError(f"Cannot find configured input CSV: {path}")
        return path

    candidates = []

    for path in sorted(SCRIPT_DIR.glob("*.csv")):
        try:
            header = pd.read_csv(path, nrows=0)
        except Exception:
            continue

        if required.issubset(set(header.columns)):
            candidates.append(path)

    if len(candidates) == 1:
        return candidates[0]

    preferred = [
        path for path in candidates
        if "test" in path.name.lower() and "prediction" in path.name.lower()
    ]

    if len(preferred) == 1:
        return preferred[0]

    if not candidates:
        raise FileNotFoundError(
            "No suitable CSV was found in the script folder.\n"
            "Required columns:\n"
            f"  - {TRUE_SUBTYPE_COL}\n"
            f"  - {PRED_SUBTYPE_COL}\n"
            f"  - {TRUE_TYPE_COL}\n"
            f"  - {PRED_TYPE_COL}"
        )

    raise RuntimeError(
        "Multiple suitable CSV files were found. Set INPUT_CSV explicitly.\n"
        + "\n".join(f"  - {p.name}" for p in candidates)
    )


# =============================================================================
# Helpers
# =============================================================================

def clean_text(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).strip()


def normalize_nonarg(text: str) -> bool:
    key = re.sub(r"[\s_\-]+", "", str(text).strip().lower())
    return key in {"nonarg", "nonargs"}


def split_subtype_label(label: str):
    """
    If subtype is stored as 'type__subtype', separate the subtype part.
    Otherwise return the original label as subtype_display.
    """
    text = clean_text(label)
    if "__" in text:
        left, right = text.split("__", 1)
        return left, right
    return "", text


def abbreviate_subtype_name(name: str) -> str:
    """
    Shorten one subtype name for plotting only.

    The exported summary CSV still contains the original full subtype names.
    """
    text = clean_text(name)

    # Longest / most specific replacements FIRST.
    replacements = [
        (
            "Acinetobacter baumannii AmpC beta-lactamase",
            "A. baumannii AmpC",
        ),
        (
            "Acinetobacter baumannii AmpC β-lactamase",
            "A. baumannii AmpC",
        ),
        (
            "Other class C beta-lactamase",
            "Class C β-lac.",
        ),
        (
            "Other class C β-lactamase",
            "Class C β-lac.",
        ),
        (
            "Escherichia coli ampC",
            "E. coli ampC",
        ),
        (
            "Pseudomonas aeruginosa",
            "P. aeruginosa",
        ),
        (
            "Acinetobacter baumannii",
            "A. baumannii",
        ),
        (
            "Klebsiella pneumoniae",
            "K. pneumoniae",
        ),
        (
            "Staphylococcus aureus",
            "S. aureus",
        ),
        (
            "Enterococcus faecium",
            "E. faecium",
        ),
        (
            "Enterococcus faecalis",
            "E. faecalis",
        ),
        (
            "Escherichia coli",
            "E. coli",
        ),
        (
            "beta-lactamase",
            "β-lac.",
        ),
        (
            "β-lactamase",
            "β-lac.",
        ),
        (
            "extended-spectrum",
            "ES",
        ),
        (
            "carbapenem-hydrolyzing",
            "carb.-hyd.",
        ),
    ]

    for old_text, new_text in replacements:
        text = text.replace(
            old_text,
            new_text,
        )

    text = re.sub(
        r"\s+",
        " ",
        text,
    ).strip()

    if len(text) > MAX_SINGLE_SUBTYPE_LEN:
        text = (
            text[: MAX_SINGLE_SUBTYPE_LEN - 1]
            .rstrip()
            + "…"
        )

    return text


def clip_text_keep_ends(
    text: str,
    limit: int,
) -> str:
    """
    Truncate a single string while keeping the beginning, which generally
    contains the informative gene/subtype family name.
    """
    if len(text) <= limit:
        return text

    if limit <= 2:
        return text[:limit]

    return (
        text[: limit - 1]
        .rstrip()
        + "…"
    )


def shorten_whole_pair_label(
    true_name: str,
    pred_name: str,
    max_len: int | None = None,
) -> str:
    """
    Limit the complete 'true -> predicted' label rather than limiting the
    two sides independently.

    Both sides are preserved whenever possible.
    """
    if max_len is None:
        max_len = MAX_WHOLE_PAIR_LEN

    arrow = " → "
    pair = f"{true_name}{arrow}{pred_name}"

    if len(pair) <= max_len:
        return pair

    available = max_len - len(arrow)

    # Give the two sides similar space, while guaranteeing that both survive.
    left_limit = max(7, available // 2)
    right_limit = max(7, available - left_limit)

    left = clip_text_keep_ends(
        true_name,
        left_limit,
    )
    right = clip_text_keep_ends(
        pred_name,
        right_limit,
    )

    pair = f"{left}{arrow}{right}"

    if len(pair) > max_len:
        pair = (
            pair[: max_len - 1]
            .rstrip()
            + "…"
        )

    return pair


def concise_pair_label(
    true_subtype: str,
    pred_subtype: str,
) -> str:
    """
    Build a compact display-only label.
    """
    _, true_name = split_subtype_label(
        true_subtype
    )
    _, pred_name = split_subtype_label(
        pred_subtype
    )

    true_name = abbreviate_subtype_name(
        true_name
    )
    pred_name = abbreviate_subtype_name(
        pred_name
    )

    return shorten_whole_pair_label(
        true_name,
        pred_name,
    )


# =============================================================================
# Analysis
# =============================================================================

def prepare_data(df: pd.DataFrame) -> pd.DataFrame:
    required = [
        TRUE_SUBTYPE_COL,
        PRED_SUBTYPE_COL,
        TRUE_TYPE_COL,
        PRED_TYPE_COL,
    ]

    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    work = df[required].copy()

    for col in required:
        work[col] = work[col].map(clean_text)

    work = work[
        (work[TRUE_SUBTYPE_COL] != "")
        & (work[PRED_SUBTYPE_COL] != "")
        & (work[TRUE_TYPE_COL] != "")
        & (work[PRED_TYPE_COL] != "")
    ].copy()

    if EXCLUDE_TRUE_NONARG:
        work = work[
            ~work[TRUE_TYPE_COL].map(normalize_nonarg)
        ].copy()

    work["subtype_correct"] = (
        work[TRUE_SUBTYPE_COL] == work[PRED_SUBTYPE_COL]
    )
    work["type_correct"] = (
        work[TRUE_TYPE_COL] == work[PRED_TYPE_COL]
    )

    errors = work[~work["subtype_correct"]].copy()

    if errors.empty:
        raise RuntimeError("No subtype misclassification records found.")

    errors["pair_key"] = (
        errors[TRUE_SUBTYPE_COL] + "|||"
        + errors[PRED_SUBTYPE_COL]
    )

    errors["pair_label"] = [
        concise_pair_label(t, p)
        for t, p in zip(errors[TRUE_SUBTYPE_COL], errors[PRED_SUBTYPE_COL])
    ]

    return errors


def summarize_pairs(errors: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for pair_key, group in errors.groupby("pair_key", sort=False):
        true_subtype = group[TRUE_SUBTYPE_COL].iloc[0]
        pred_subtype = group[PRED_SUBTYPE_COL].iloc[0]
        pair_label = group["pair_label"].iloc[0]

        total = int(len(group))
        type_correct_n = int(group["type_correct"].sum())
        type_incorrect_n = int(total - type_correct_n)

        type_correct_pct = 100.0 * type_correct_n / total
        type_incorrect_pct = 100.0 * type_incorrect_n / total

        true_type = group[TRUE_TYPE_COL].iloc[0]

        pred_types = (
            group[PRED_TYPE_COL]
            .value_counts()
            .index
            .tolist()
        )

        rows.append({
            "pair_key": pair_key,
            "pair_label": pair_label,
            "true_subtype": true_subtype,
            "predicted_subtype": pred_subtype,
            "true_type": true_type,
            "predicted_type_mode": pred_types[0] if pred_types else "",
            "n_total": total,
            "n_type_correct": type_correct_n,
            "n_type_incorrect": type_incorrect_n,
            "pct_type_correct": type_correct_pct,
            "pct_type_incorrect": type_incorrect_pct,
        })

    summary = pd.DataFrame(rows)

    summary = summary.sort_values(
        ["n_total", "n_type_correct", "pair_label"],
        ascending=[False, False, True],
        kind="mergesort",
    ).reset_index(drop=True)

    if len(summary) > TOP_N:
        summary = summary.iloc[:TOP_N].copy()

    # Reverse for top-to-bottom plotting.
    summary = summary.iloc[::-1].reset_index(drop=True)

    return summary


# =============================================================================
# Plotting
# =============================================================================

def auto_fit_left_margin(
    fig,
    ax,
    right=0.97,
    bottom=0.10,
    top=0.985,
):
    """
    Keep all y-axis labels inside the exact physical canvas.

    Procedure:
      1. render the actual Arial labels;
      2. increase the left margin up to MAX_LEFT_MARGIN;
      3. if still clipped, reduce only y-tick font size in small increments;
      4. perform a final rendered-boundary check.

    The figure is still exported at exactly 9.15 x 7.80 cm.
    """
    if not AUTO_FIT_YLABEL_MARGIN:
        return INITIAL_LEFT_MARGIN

    current_left = INITIAL_LEFT_MARGIN
    current_font = Y_TICK_SIZE

    for _ in range(12):
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()

        tick_labels = [
            label
            for label in ax.get_yticklabels()
            if label.get_text().strip()
        ]

        if not tick_labels:
            return current_left

        bboxes = [
            label.get_window_extent(
                renderer=renderer
            )
            for label in tick_labels
        ]

        min_x = min(
            bbox.x0
            for bbox in bboxes
        )

        if min_x >= YLABEL_EDGE_PAD_PX:
            print(
                f"[LAYOUT] left={current_left:.3f}; "
                f"y-label font={current_font:.2f} pt; "
                f"left-most={min_x:.1f}px"
            )
            return current_left

        fig_width_px = float(
            fig.bbox.width
        )

        # First use available left margin.
        if current_left < MAX_LEFT_MARGIN - 1e-6:
            required_extra = (
                YLABEL_EDGE_PAD_PX
                - min_x
            ) / fig_width_px

            new_left = min(
                MAX_LEFT_MARGIN,
                current_left
                + required_extra
                + 0.008,
            )

            if new_left > current_left + 1e-6:
                current_left = new_left

                fig.subplots_adjust(
                    left=current_left,
                    right=right,
                    bottom=bottom,
                    top=top,
                )

                continue

        # If margin is already at its maximum, reduce only the y labels.
        if current_font > MIN_Y_TICK_SIZE + 1e-6:
            current_font = max(
                MIN_Y_TICK_SIZE,
                current_font
                - Y_TICK_SHRINK_STEP,
            )

            for label in ax.get_yticklabels():
                label.set_fontsize(
                    current_font
                )

            continue

        break

    # Final diagnostic.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()

    final_labels = [
        label
        for label in ax.get_yticklabels()
        if label.get_text().strip()
    ]

    if final_labels:
        final_min_x = min(
            label.get_window_extent(
                renderer=renderer
            ).x0
            for label in final_labels
        )

        print(
            f"[LAYOUT] final left={current_left:.3f}; "
            f"y-label font={current_font:.2f} pt; "
            f"left-most={final_min_x:.1f}px"
        )

        if final_min_x < 0:
            print(
                "[LAYOUT WARNING] A label is still outside the canvas. "
                "Reduce MAX_WHOLE_PAIR_LEN near the top of the script."
            )

    return current_left


def plot_top_pairs(summary: pd.DataFrame) -> None:
    """
    Compact fixed-size publication figure.

    Design decisions:
    - no descriptive title at the top;
    - figure size fixed to 9.15 cm × 7.80 cm;
    - shorter y labels and smaller typography;
    - concise right-side annotation: "n (xx.x%)";
    - legend kept inside the plotting area to save space.
    """
    n_rows = len(summary)
    fig, ax = plt.subplots(
        figsize=(BASE_WIDTH, BASE_HEIGHT),
        facecolor="white",
    )

    y = np.arange(n_rows)
    correct = summary["n_type_correct"].to_numpy(dtype=float)
    incorrect = summary["n_type_incorrect"].to_numpy(dtype=float)
    total = summary["n_total"].to_numpy(dtype=float)

    ax.barh(
        y,
        correct,
        color=COLOR_TYPE_CORRECT,
        edgecolor=BAR_EDGE,
        linewidth=BAR_LINEWIDTH,
        height=0.62,
        label="Subtype wrong, type correct",
    )

    ax.barh(
        y,
        incorrect,
        left=correct,
        color=COLOR_TYPE_INCORRECT,
        edgecolor=BAR_EDGE,
        linewidth=BAR_LINEWIDTH,
        height=0.62,
        label="Subtype wrong, type incorrect",
    )

    ax.set_yticks(y)
    ax.set_yticklabels(
        summary["pair_label"].tolist(),
        fontsize=Y_TICK_SIZE,
    )

    # Reserve a clean empty area below the lowest bar for the lower-right
    # legend.  Bar positions and ranking remain unchanged; only the visible
    # y-range is extended downward.
    ax.set_ylim(
        -LEGEND_RESERVED_ROWS,
        n_rows - 0.35,
    )

    xmax = max(1.0, float(np.max(total)))

    # Keep the legend at the original lower-right position, but reserve
    # an empty region on the right so it does not cover bars/annotations.
    annotation_pad = max(0.24, 0.08 * xmax)
    legend_reserved_width = max(2.4, 0.55 * xmax)

    ax.set_xlim(
        0,
        xmax + annotation_pad + legend_reserved_width,
    )

    ax.set_xlabel("Count", fontsize=AXIS_LABEL_SIZE, labelpad=2)

    if SHOW_TITLE:
        ax.set_title(
            f"{TITLE_TEXT}\n{TITLE_SUFFIX}",
            fontsize=TITLE_SIZE,
            pad=6,
        )

    ax.xaxis.grid(True, color=GRID_COLOR, linewidth=0.5, alpha=0.85)
    ax.set_axisbelow(True)

    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    ax.spines["left"].set_linewidth(0.75)
    ax.spines["bottom"].set_linewidth(0.75)

    ax.tick_params(axis="x", labelsize=X_TICK_SIZE, width=0.65, length=2.8, pad=1.5)
    ax.tick_params(axis="y", width=0.55, length=1.8, pad=1.0)

    # Compact right-side annotation.
    for yi, row in summary.iterrows():
        total_n = int(row["n_total"])
        pct_correct = float(row["pct_type_correct"])
        ax.text(
            row["n_total"] + annotation_pad * 0.45,
            yi,
            f"{total_n} ({pct_correct:.1f}%)",
            va="center",
            ha="left",
            fontsize=ANNOT_SIZE,
            color="#333333",
            clip_on=False,
        )

    # Compact legend at the top.  Keeping it away from the bars and
    # right-side annotations prevents overlap in the fixed-size figure.
    ax.legend(
        loc="lower right",
        frameon=True,
        edgecolor="#666666",
        facecolor="white",
        framealpha=1.0,
        fontsize=LEGEND_SIZE,
        borderpad=0.24,
        labelspacing=0.20,
        handlelength=0.95,
        handletextpad=0.40,
    )

    # Start from the original layout.  For DNA, long subtype labels may need
    # extra left space; auto_fit_left_margin() measures the rendered labels
    # and shifts the plotting area only when necessary.
    plot_top = 0.985 if not SHOW_TITLE else 0.90

    fig.subplots_adjust(
        left=INITIAL_LEFT_MARGIN,
        right=0.97,
        bottom=0.10,
        top=plot_top,
    )

    auto_fit_left_margin(
        fig=fig,
        ax=ax,
        right=0.97,
        bottom=0.10,
        top=plot_top,
    )

    base = OUTDIR / "top_subtype_misclassification_pairs_9.15x7.8cm_legendSafe"

    # Do NOT use bbox_inches="tight" here: tight bounding boxes alter the
    # requested physical output size.  These exports remain exactly
    # 9.15 cm x 7.80 cm.
    fig.savefig(
        str(base) + ".png",
        dpi=DPI,
        facecolor="white",
    )

    if SAVE_PDF:
        fig.savefig(
            str(base) + ".pdf",
            facecolor="white",
        )

    if SAVE_SVG:
        fig.savefig(
            str(base) + ".svg",
            facecolor="white",
        )

    plt.close(fig)


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    configure_fonts()
    report_font_status()

    input_csv = resolve_input_csv()
    print(f"[INPUT] {input_csv}")

    df = pd.read_csv(input_csv)
    errors = prepare_data(df)
    summary = summarize_pairs(errors)

    summary.to_csv(
        OUTDIR / "top_subtype_misclassification_pairs_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    plot_top_pairs(summary)

    print("=" * 84)
    print("Top subtype misclassification pairs")
    print("=" * 84)
    print(f"Total subtype-misclassified ARG sequences : {len(errors):,}")
    print(f"Pairs plotted                             : {len(summary)}")
    print(f"Output directory                          : {OUTDIR}")
    print("\nTop 10 shown pairs:")
    print(summary.iloc[::-1][["pair_label", "n_total", "n_type_correct", "n_type_incorrect"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
