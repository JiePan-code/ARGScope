"""Recalculate existing predictions with nonARG in the evaluated label universe.

No training, inference, source edits, threshold changes, or semantic remapping.
Each comparator keeps its existing labelled input population. DeepARG calls are
left-joined to its complete existing input, so no-call records are not dropped.
"""
from pathlib import Path
import importlib.util
import json
import sys
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW")
OUT = HERE / "outputs/argscope_including_nonARG_20260922"
DATA = OUT / "data"
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("prior_recalculation", ROOT / "rebuild_all_results.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
import strict_type_names as strict

PCTS = [60, 70, 80, 90, 100]
FIELDS = ["Accuracy", "Precision", "Recall", "F1", "MCC"]
ORDER = ["beta_lactam", "trimethoprim", "macrolide-lincosamide-streptogramin", "fusidic_acid",
         "fosfomycin", "aminoglycoside", "quinolone", "multidrug", "vancomycin",
         "chloramphenicol", "florfenicol", "rifamycin", "tetracycline", "other_peptide_antibiotics",
         "bacitracin", "sulfonamide", "tetracenomycin_C", "novobiocin", "tunicamycin",
         "streptothricin", "polymyxin", "bleomycin", "puromycin"]
LABELS = ORDER + ["nonARG"]


def write_csv(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def comparator(mod, model, pct, plm_mapping):
    path = prior.mapped_path(mod, model, pct)
    frame = prior.clean_frame(prior.read(path), "test_id", pct=pct)
    frame["_binary_pred"] = frame.ARG_prediction
    if model == "PLM-ARG":
        prior.verify_plm(frame, pct, plm_mapping)
        rawpath = prior.TRAIN / f"Type_level_performance/PLM_ARG/plmarg_eval_outputs_{pct}p/merged_plmarg_predictions_with_labels.csv"
        rawcol = "raw_pred"
    else:
        rawpath, rawcol = strict.verify_raw(frame, mod, model, pct, prior.RAW, prior.read)
    frame = strict.remap(frame, mod, model, pct, ORDER, rawcol, rawpath)
    frame["raw_type_prediction"] = frame[rawcol].astype(str)
    return path, frame, "archived_cleaned_input" if mod == "DNA" else "archived_labelled_input"


def deeparg(mod, pct, protein_reference):
    callname = (("all_arg_nonarg_protein_deeparg_LS_prot" if pct == 100 else
                 f"protein_{pct}pct_5parts_deeparg_SS_prot") if mod == "Protein" else
                ("all_arg_nonarg_dna_deeparg_SS_nucl" if pct == 100 else
                 f"dna_{pct}pct_5parts_deeparg_SS_nucl"))
    path = prior.RAW / f"DeepARG/{mod.lower() if mod=='Protein' else 'DNA'}/{callname}.mapping.ARG"
    calls = prior.read(path, sep="\t")
    assert calls.read_id.is_unique and calls.read_id.notna().all()
    if mod == "Protein":
        frame = protein_reference[["_id", "_parent", "_y", "true_subtype"]].copy()
        truth_path = prior.mapped_path("Protein", "ARGNet", pct)
    else:
        folder = "dna_all" if pct == 100 else f"dna_{pct}pct"
        truth_path = prior.TRAIN / f"柱状图结果/longNT/deeparg/{folder}/ARG_nonARG_prediction_details.csv"
        raw = prior.read(truth_path)
        assert raw.id.is_unique
        frame = pd.DataFrame({"_id": raw.id.astype(str), "_y": raw.type.astype(str)})
        frame["_parent"] = frame._id if pct == 100 else frame._id.str.replace(r"_[1-5]$", "", regex=True)
        np.testing.assert_array_equal(raw.pred_ARG_binary.eq("ARG"), frame._id.isin(calls.read_id))
    assert len(frame) == (26878 if pct == 100 else 134390)
    assert set(calls.read_id) <= set(frame._id), "Calls outside authoritative input"
    frame["_binary_pred"] = np.where(frame._id.isin(calls.read_id), "ARG", "nonARG")
    indexed = calls.set_index("read_id")["predicted_ARG-class"]
    frame["raw_type_prediction"] = frame._id.map(indexed).fillna("")
    assert frame.loc[frame._binary_pred.eq("ARG"), "raw_type_prediction"].ne("").all()
    pairs = list(zip(frame._binary_pred, frame.raw_type_prediction))
    mapping = {x: strict.map_name(*x, ORDER) for x in set(pairs)}
    frame["_p"] = [mapping[x][0] for x in pairs]
    frame["prediction_origin"] = np.where(frame._binary_pred.eq("ARG"), "reported_ARG_call", "no_ARG_call")
    assert frame._p.eq("nonARG").equals(frame._binary_pred.eq("nonARG"))
    receipt = dict(Modality=mod, Completeness=pct, Input_N=len(frame), ARG_calls=len(calls),
                   Restored_no_call_records=int(frame._binary_pred.eq("nonARG").sum()),
                   Missed_reference_ARG=int((frame._y.ne("nonARG") & frame._binary_pred.eq("nonARG")).sum()),
                   False_positive_nonARG=int((frame._y.eq("nonARG") & frame._binary_pred.eq("ARG")).sum()),
                   Prediction_source=str(path), Input_source=str(truth_path))
    return path, frame, "archived_complete_labelled_input", receipt


def main():
    DATA.mkdir(parents=True, exist_ok=True)
    strict.self_test()
    old_manifest = pd.read_csv(ROOT / "input_file_manifest.csv")
    source_hashes = dict(zip(old_manifest.Path, old_manifest.SHA256))
    plm_mapping = prior.load_module("plm_mapping_including_nonarg", prior.RAW / "PLMARG/Protein/calculate_PLMARG_Protein_metrics.py")
    _, own_full = prior.read_own("Protein", 100)
    assert set(own_full._y) == set(LABELS)
    subtype_labels = sorted(set(own_full.true_subtype) | set(own_full.predicted_subtype))
    assert len(subtype_labels) == 821 and "nonARG" in subtype_labels
    all_rows, per_frames, populations, restorations, cohort_rows = [], [], [], [], []
    raw_subtype_counts = []
    own_truth = {}
    for pct in PCTS:
        protein_reference = None
        for mod, models in prior.MODELS.items():
            own_path, own = prior.read_own(mod, pct)
            own_truth[mod, pct] = own.set_index("_id")._y.sort_index()
            for model in models:
                if model == "ARGScope":
                    path, frame, population = own_path, own.copy(), "new_80_20_heldout_test"
                    frame["raw_type_prediction"] = frame._p
                elif model == "DeepARG":
                    path, frame, population, audit = deeparg(mod, pct, protein_reference)
                    restorations.append(audit)
                else:
                    path, frame, population = comparator(mod, model, pct, plm_mapping)
                    if mod == "Protein" and model == "ARGNet":
                        protein_reference = frame.copy()
                assert frame._id.is_unique and frame._y.ne("").all() and frame._p.ne("").all()
                # Binary discrimination uses the complete available input, unchanged.
                binary, _ = prior.metrics(np.where(frame._y.eq("nonARG"), "nonARG", "ARG"),
                    frame._binary_pred, mod, model, pct, "ARG_nonARG", "ARG_and_nonARG", population, path)
                all_rows += binary
                # Retain the requested 23 ARG reference classes and add nonARG.
                subset = frame.loc[frame._y.isin(LABELS)].copy()
                rows, counts = prior.metrics(subset._y, subset._p, mod, model, pct, "Type",
                    "including_nonARG_fixed24", population, path, fixed_labels=LABELS)
                all_rows += rows
                for key, value in dict(Modality=mod, Model=model, Completeness=pct,
                                       Scope="including_nonARG_fixed24", N=len(subset)).items():
                    counts[key] = value
                per_frames.append(counts)
                if model == "ARGScope":
                    assert subset.true_subtype.eq("nonARG").equals(subset._y.eq("nonARG"))
                    assert set(subset.predicted_subtype) <= set(subtype_labels)
                    assert set(subset.true_subtype) <= set(subtype_labels)
                    subrows, subcounts = prior.metrics(subset.true_subtype, subset.predicted_subtype,
                        mod, model, pct, "Subtype", "including_nonARG_fixed821", population, path,
                        fixed_labels=subtype_labels)
                    all_rows += subrows
                    subcounts = subcounts.rename(columns={"Type": "Subtype"})
                    subcounts["Completeness"] = pct
                    subcounts["Modality"] = mod
                    raw_subtype_counts.append(subcounts)
                common = set(frame._id) & set(own._id)
                lookup = frame.set_index("_id").loc[sorted(common), "_y"]
                truth = own.set_index("_id").loc[sorted(common), "_y"]
                np.testing.assert_array_equal(lookup, truth)
                cohort_rows.append(dict(Modality=mod, Model=model, Completeness=pct,
                    Available_input=len(frame), ARGScope_input=len(own), Shared_IDs=len(common),
                    Missing_ARGScope_IDs=len(own)-len(common), Same_input_ID_set=set(frame._id)==set(own._id),
                    Shared_truth_agrees=True))
                populations.append(dict(Modality=mod, Model=model, Completeness=pct, Population=population,
                    Input_N=len(frame), Type_N=len(subset), Type_ARG_N=int(subset._y.ne("nonARG").sum()),
                    Type_nonARG_N=int(subset._y.eq("nonARG").sum()),
                    Excluded_truth_outside_23_ARG_types=len(frame)-len(subset),
                    Unmapped_predictions_retained=int(subset._p.str.startswith("__").sum()),
                    ARG_predicted_nonARG=int((subset._y.ne("nonARG") & subset._p.eq("nonARG")).sum()),
                    nonARG_predicted_ARG=int((subset._y.eq("nonARG") & subset._p.ne("nonARG")).sum()),
                    Source=str(path)))
                # Save compact, inspectable sequence-level evidence for the 100% panels.
                if pct == 100:
                    columns = ["_id", "_parent", "_y", "_p", "_binary_pred", "raw_type_prediction"]
                    columns += [c for c in ["true_subtype", "predicted_subtype", "prediction_origin"] if c in subset]
                    details = subset[columns].rename(columns={"_id":"sequence_id", "_parent":"parent_sequence_id",
                        "_y":"true_type", "_p":"predicted_type", "_binary_pred":"predicted_ARG_binary"})
                    write_csv(details, DATA / mod / f"{model}_100pct_sequence_evaluation.csv")
                print(f"DONE {mod} {pct}% {model}: type N={len(subset)}, nonARG={int(subset._y.eq('nonARG').sum())}", flush=True)
    for pct in PCTS:
        pd.testing.assert_series_equal(own_truth['Protein',pct], own_truth['DNA',pct])
    metrics = pd.DataFrame(all_rows)
    per_type = pd.concat(per_frames, ignore_index=True)
    write_csv(metrics, DATA / "all_metrics_including_nonARG.csv")
    write_csv(per_type, DATA / "per_type_including_nonARG.csv")
    write_csv(pd.concat(raw_subtype_counts), DATA / "ARGScope_subtype_per_label_counts.csv")
    write_csv(pd.DataFrame(populations), DATA / "population_and_error_audit.csv")
    write_csv(pd.DataFrame(cohort_rows), DATA / "cohort_comparability_audit.csv")
    write_csv(pd.DataFrame(restorations), DATA / "DeepARG_complete_input_restoration.csv")
    write_csv(pd.DataFrame(strict.AUDIT), DATA / "strict_name_mapping_audit.csv")
    for mod in prior.MODELS:
        part = metrics[metrics.Modality.eq(mod)]
        write_csv(part[part.Level.eq("Type")], DATA/mod/"Type_macro_weighted_micro_60_100.csv")
        write_csv(part[part.Level.eq("Subtype")], DATA/mod/"ARGScope_Subtype_macro_weighted_micro_60_100.csv")
        write_csv(part[part.Level.eq("ARG_nonARG")], DATA/mod/"ARG_nonARG_all_averages_60_100.csv")
        write_csv(per_type[per_type.Modality.eq(mod)], DATA/mod/"Per_Type_23_ARG_plus_nonARG_60_100.csv")
    # The binary task must not change merely because annotation scope changed.
    old_binary = pd.concat([pd.read_csv(ROOT/mod/"06_ARG_nonARG_macro_weighted_micro.csv") for mod in prior.MODELS])
    fresh = metrics[metrics.Level.eq("ARG_nonARG") & metrics.Average.ne("ARG_positive")]
    keys = ["Modality", "Model", "Completeness", "Average"]
    merged = fresh.merge(old_binary, on=keys, suffixes=("_new", "_old"), validate="one_to_one")
    assert len(merged) == 120
    for field in FIELDS:
        np.testing.assert_allclose(merged[field+"_new"], merged[field+"_old"], atol=1e-12, rtol=0)
    verified_hashes = []
    for path, metadata in prior.FILES.items():
        current = prior.sha(path)
        assert current == metadata['SHA256'], "Input changed while recalculating"
        if path in source_hashes:
            assert current == source_hashes[path], "Input differs from prior provenance"
        verified_hashes.append(dict(Path=path, **metadata, Prior_manifest_match=(current==source_hashes.get(path))))
    write_csv(pd.DataFrame(verified_hashes), DATA / "input_file_manifest.csv")
    verification = dict(type_labels=LABELS, n_type_labels=24, n_subtype_labels=821,
        metrics_rows=len(metrics), type_groups=40, subtype_groups=10, binary_macro_weighted_micro_unchanged=True,
        independent_formula_crosscheck="Every metric was checked against sklearn using the sequence labels",
        no_training_or_inference=True, strict_name_mapping_unchanged=True,
        reference_nonARG_included_in_type_and_subtype=True, DeepARG_no_call_inputs_restored=True,
        cohorts="Existing model-specific inputs retained at user request. Not a matched-test-set benchmark.",
        comparator_subtype="No comparator predicted-subtype column is available in the supplied evaluation files.")
    (DATA/"calculation_verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8")
    print(metrics[metrics.Model.eq("ARGScope") & metrics.Completeness.eq(100) & metrics.Average.eq("macro")][["Modality","Level"]+FIELDS].to_string(index=False))


if __name__ == "__main__":
    main()
