"""Independent CSV-based verification and same-cohort old/new comparison."""
from pathlib import Path
import sys
import csv
import json
import statistics
import hashlib

import torch
from torch.nn import functional as F
import numpy as np
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT.parent/"BGC_novel dataset"


def read(path):
    with Path(path).open(encoding="utf-8-sig",newline="") as handle:
        return list(csv.DictReader(handle))


def save(path,rows):
    path.parent.mkdir(exist_ok=True,parents=True)
    with path.open("w",encoding="utf-8-sig",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def score(true,pred,labels,average):
    p,r,f,_=precision_recall_fscore_support(true,pred,labels=labels,average=average,zero_division=0)
    return {"accuracy":accuracy_score(true,pred),"precision":p,"recall":r,"f1":f,"mcc":matthews_corrcoef(true,pred)}


def main():
    labels=read(ROOT/"Dataset/normalized_BGC_nonBGC_labels_and_fixed_splits.csv")
    truth={r["id"]:r for r in labels if r["model_split"]=="test"}
    manifest=json.loads((ROOT/"Dataset/dataset_manifest.json").read_text(encoding="utf-8"))
    type_names=["nonBGC"]+sorted({r["type"] for r in labels if r["type"]!="nonBGC"})
    fine_names=["nonBGC"]+manifest["fine_classes"]
    groups={}
    for r in labels:
        if r["group_id"] in groups:
            assert groups[r["group_id"]]==r["model_split"]
        else:
            groups[r["group_id"]]=r["model_split"]
    verified=[]
    new_scores=[]
    for seed in (20260915,20261006,20261007):
        for branch in ("AA","NT"):
            folder=ROOT/f"seed_{seed}"/branch
            summary_path=folder/"run_summary.json"
            if not summary_path.exists():
                continue
            summary=json.loads(summary_path.read_text(encoding="utf-8"))
            for method,tag,key in (("ARGScope","student","student_test_metrics"),("Teacher","teacher","teacher_test_metrics"),("Linear probe","linear_probe","linear_probe_test_metrics")):
                if key not in summary:
                    continue
                records=read(folder/f"{tag}_test_predictions.csv")
                assert len(records)==len(truth)==len({r["id"] for r in records})
                assert {r["id"] for r in records}==set(truth)
                for r in records:
                    reference=truth[r["id"]]
                    assert r["true_type"]==reference["type"] and r["true_subtype"]==reference["subtype"]
                    assert int(r["true_binary"])==int(reference["type"]!="nonBGC")
                    assert int(r["fine_evaluable"])==int(reference["subtype_evaluable"])
                    assert int(r["pred_binary"])==int(float(r["BGC_probability"])>=float(r["binary_threshold"]))
                    if r["pred_type"]=="nonBGC":
                        assert r["pred_subtype"]=="nonBGC" and int(r["pred_binary"])==0
                    else:
                        assert r["pred_subtype"].split(" | ")[0]==r["pred_type"] and int(r["pred_binary"])==1
                binary=score([int(r["true_binary"]) for r in records],[int(r["pred_binary"]) for r in records],[0,1],"binary")
                types=score([r["true_type"] for r in records],[r["pred_type"] for r in records],type_names,"macro")
                fine_records=[r for r in records if int(r["fine_evaluable"])]
                fine=score([r["true_subtype"] for r in fine_records],[r["pred_subtype"] for r in fine_records],fine_names,"weighted")
                expected=summary[key]
                for task,actual,prefix in (("binary",binary,"positive"),("type",types,"macro"),("end_to_end_all_classes",fine,"weighted")):
                    for metric,value in actual.items():
                        field=metric if metric in ("accuracy","mcc") else prefix+"_"+metric
                        assert abs(expected[task][field]-value)<1e-10,(seed,branch,method,task,field,value,expected[task][field])
                verified.append({"seed":seed,"branch":branch,"method":method,"all_test_records":len(records),
                                 "fine_test_records":len(fine_records),"independent_metrics_match":True})
                if method=="ARGScope":
                    for task,values in (("binary",binary),("type",types)):
                        for metric,value in values.items():
                            new_scores.append({"branch":branch,"seed":seed,"task":task,"metric":metric,"value":value})
    old_scores=[]
    old_alignment=[]
    for branch,name in (("AA","1.Protein_student_BGC"),("NT","2.DNA_student_BGC")):
        records=read(SOURCE/"1 Result"/name/"test_sequence_predictions.csv")
        assert len(records)==len(truth)==len({r["id"] for r in records})
        assert {r["id"] for r in records}==set(truth)
        remap=lambda v:"Ribosomal peptide" if v=="RiPP" else v
        assert all(remap(r["true_type"])==truth[r["id"]]["type"] for r in records)
        assert all((r["true_binary"]=="BGC")== (truth[r["id"]]["type"]!="nonBGC") for r in records)
        old_alignment.append({"branch":branch,"same_test_IDs":True,"same_binary_truth":True,
                              "same_type_truth_after_RiPP_rename":True,"records":len(records)})
        binary=score([int(r["true_binary"]=="BGC") for r in records],[int(r["predicted_binary"]=="BGC") for r in records],[0,1],"binary")
        types=score([remap(r["true_type"]) for r in records],[remap(r["predicted_type"]) for r in records],type_names,"macro")
        for task,values in (("binary",binary),("type",types)):
            for metric,value in values.items():
                old_scores.append({"branch":branch,"task":task,"metric":metric,"old_single_run_value":value})
    comparisons=[]
    for r in old_scores:
        values=[x["value"] for x in new_scores if all(x[k]==r[k] for k in ("branch","task","metric"))]
        if values:
            mean=statistics.mean(values)
            comparisons.append({**r,"new_seeds_completed":len(values),"new_mean":mean,
                                "new_sample_std":statistics.stdev(values) if len(values)>1 else "",
                                "descriptive_difference":mean-r["old_single_run_value"]})
    if verified:
        save(ROOT/"Results/independent_verification.csv",verified)
    if comparisons:
        save(ROOT/"Results/old_vs_new_same_cohort.csv",comparisons)
    save(ROOT/"Results/old_test_cohort_alignment.csv",old_alignment)
    provenance=json.loads((ROOT/"experiment_provenance.json").read_text(encoding="utf-8"))
    for name,digest in provenance["legacy_source_sha256"].items():
        assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==digest
    assert hashlib.sha256((ROOT/"Dataset/normalized_BGC_nonBGC_labels_and_fixed_splits.csv").read_bytes()).hexdigest()==manifest["normalized_labels_sha256"]
    # Independently reconstruct raw prototypes using train IDs only.
    torch.set_num_threads(2)
    prototype_checks=[]
    for seed in (20260915,20261006,20261007):
        fusion_path=ROOT/f"seed_{seed}"/"Fusion/graph_input_fusion.pt"
        raw_path=ROOT/f"seed_{seed}"/"Graph/raw_prototypes.pt"
        if not raw_path.exists():
            continue
        fusion=torch.load(fusion_path,map_location="cpu",weights_only=False)
        raw=torch.load(raw_path,map_location="cpu",weights_only=False)
        assert fusion["provenance"]==provenance
        train=[i for i,s in enumerate(fusion["model_splits"]) if s=="train"]
        z=F.normalize(fusion["embeddings"][train].float(),dim=1)
        subtypes=[fusion["subtypes"][i] for i in train]
        recreated=[]
        for name in raw["prototype_subtypes"]:
            ix=torch.tensor([i for i,s in enumerate(subtypes) if s==name])
            assert len(ix)>0
            recreated.append(F.normalize(z[ix].mean(0),dim=0))
        torch.testing.assert_close(torch.stack(recreated),raw["raw_prototypes"].float(),atol=2e-5,rtol=2e-5)
        negatives=torch.tensor([i for i,s in enumerate(subtypes) if s=="nonBGC"])
        center=F.normalize(z[negatives].mean(0),dim=0)
        torch.testing.assert_close(center,raw["nonbgc_reference_centroid"].float().reshape(-1),atol=2e-5,rtol=2e-5)
        prototype_checks.append({"seed":seed,"train_only_raw_prototypes_match":True,"train_only_negative_center_matches":True})
    status={"verified_completed_method_runs":len(verified),"expected_method_runs":18,
            "all_requested_runs_verified":len(verified)==18,"old_test_alignment":old_alignment,
            "independent_metric_library":"scikit-learn","old_code_hashes_unchanged":True,
            "group_split_overlap":0,"train_only_prototype_checks":prototype_checks}
    (ROOT/"Results/verification_status.json").write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(status,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
