"""Reproducible five-metric circular bars and Type Precision radars, 60-90%.

No raw predictions, evaluation populations, label mappings or metrics are changed.
Old bootstrap intervals are intentionally not reused with new point estimates.
"""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Patch
from matplotlib.text import Text
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PCTS = [60, 70, 80, 90]
MODELS = {'Protein': ['ARGNet', 'DeepARG', 'PLM-ARG', 'FunGeneTyper', 'ARGScope'],
          'DNA': ['ARGNet', 'DeepARG', 'ARGScope']}
COLORS = {'ARGNet': '#89949E', 'DeepARG': '#8472B0', 'PLM-ARG': '#BDA364',
          'FunGeneTyper': '#64A598', 'ARGScope': '#CF4877'}
SHORT = {'ARGNet': 'AN', 'DeepARG': 'DA', 'PLM-ARG': 'PL', 'FunGeneTyper': 'FG', 'ARGScope': 'AS'}
STYLES = {'ARGNet': '--', 'DeepARG': ':', 'PLM-ARG': '-.',
          'FunGeneTyper': (0, (4, 1.3, 1.2, 1.3)), 'ARGScope': '-'}
MARKERS = {'ARGNet': 's', 'DeepARG': '^', 'PLM-ARG': 'D', 'FunGeneTyper': 'v', 'ARGScope': 'o'}
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']
METRIC_LABELS = ['ACC', 'Macro\nprecision', 'Macro\nrecall', 'Macro F1', 'MCC']
SECTOR_BG = ['#E4F0F3', '#F1EEDC', '#E6EAF5', '#E5F0E7', '#F6E4ED']
ORDER = ['beta_lactam','trimethoprim','macrolide-lincosamide-streptogramin','fusidic_acid','fosfomycin',
         'aminoglycoside','quinolone','multidrug','vancomycin','chloramphenicol','florfenicol','rifamycin',
         'tetracycline','other_peptide_antibiotics','bacitracin','sulfonamide','tetracenomycin_C','novobiocin',
         'tunicamycin','streptothricin','polymyxin','bleomycin','puromycin']
R0 = .44
CONTEXT = ('Type evaluation on true ARG records using the fixed ARGScope 23-Type label set. '
           'Circular bars show ACC, macro Precision, macro Recall, macro F1, and MCC. '
           'Radars show per-Type Precision only. '
           'Type names use verified same-name correspondences, not forced ontology alignment. '
           'Model cohorts differ and DeepARG uses its supplied selected-hit population; '
           'comparisons are descriptive, not a matched-cohort benchmark. '
           'Radar display filtering does not change any aggregate metric. '
           'No uncertainty intervals were computed for these revised estimates.')
plt.rcParams.update({'font.family': 'Arial', 'font.size': 9, 'text.color': '#24292D',
                     'figure.facecolor': 'white', 'savefig.facecolor': 'white',
                     'svg.fonttype': 'none', 'pdf.fonttype': 42, 'ps.fonttype': 42,
                     'hatch.linewidth': .35})
BAR_RECORDS, RADAR_RECORDS, FILTER_RECORDS, EXPORTS = [], [], [], []


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_data():
    sources = [ROOT/'ARGScope_23_types.csv']
    display_frame = pd.read_csv(sources[0])
    assert len(display_frame) == 23 and set(display_frame.Type) == set(ORDER)
    display = display_frame.set_index('Type').Type_display.to_dict()
    display.update(aminoglycoside='Aminoglycosides', tetracycline='Tetracyclines')
    overalls, per_types, tables = {}, {}, {}
    for mod, models in MODELS.items():
        src = ROOT/mod/'01_Type_barplot_macro_five_metrics.csv'
        src_per = ROOT/mod/'03_Per_Type_fixed23_five_metrics.csv'
        sources += [src, src_per]
        overall = pd.read_csv(src)
        overall = overall[overall.Completeness.isin(PCTS)].copy()
        per = pd.read_csv(src_per)
        per = per[per.Completeness.isin(PCTS)].copy()
        assert len(overall) == len(models)*4 and len(per) == len(models)*4*23
        assert not overall.duplicated(['Model','Completeness']).any()
        assert not per.duplicated(['Model','Completeness','Type']).any()
        assert overall.Scope.eq('ARG_only').all() and overall.Average.eq('macro').all()
        assert overall.N_labels_averaged.eq(23).all() and per.Scope.eq('ARG_only').all()
        assert set(overall.Model) == set(models) and set(per.Type) == set(ORDER)
        assert np.isfinite(overall[METRICS]).all().all()
        assert overall[METRICS].ge(0).all().all() and overall[METRICS].le(1).all().all()
        # Reconcile all plotted aggregates except MCC against the per-class counts.
        for (model,pct), rows in per.groupby(['Model','Completeness']):
            assert len(rows) == 23 and rows.N.nunique() == 1
            assert int(rows.Support.sum()) == int(rows.N.iloc[0])
            row = overall[(overall.Model==model)&(overall.Completeness==pct)].iloc[0]
            assert abs(rows.TP.sum()/row.N-row.Accuracy) < 2e-14
            for key in ['Precision','Recall','F1']:
                assert abs(rows[key].mean()-row[key]) < 2e-14
            den = rows.TP.to_numpy(float)+rows.FP.to_numpy(float)
            recomputed = np.divide(rows.TP.to_numpy(float),den,out=np.zeros(23),where=den>0)
            np.testing.assert_allclose(recomputed,rows.Precision,rtol=0,atol=2e-14)
        for pct in PCTS:
            table = per[per.Completeness==pct].pivot(index='Type',columns='Model',values='Precision')
            table = table.reindex(index=ORDER, columns=models)
            assert table.notna().all().all(), 'Unexpected missing data in fixed23 results'
            own_ok = table.ARGScope.gt(0)
            other_ok = table.drop(columns='ARGScope').gt(0).any(axis=1)
            keep = own_ok & other_ok
            for typ in ORDER:
                FILTER_RECORDS.append(dict(Modality=mod,Completeness=pct,Type=typ,
                    ARGScope_precision=float(table.loc[typ,'ARGScope']),Shown=bool(keep.loc[typ]),
                    Reason='displayed' if keep.loc[typ] else ('ARGScope_precision_zero' if not own_ok.loc[typ]
                            else 'all_comparators_precision_zero')))
            tables[mod,pct] = table.loc[keep].copy()
            assert len(tables[mod,pct]) >= 3
        overalls[mod], per_types[mod] = overall, per
    return overalls, per_types, tables, display, {str(p):digest(p) for p in sources}


def axes_mm(fig,x,top,width,height,polar=False):
    fw,fh = fig.get_size_inches()*25.4
    return fig.add_axes([x/fw,1-(top+height)/fh,width/fw,height/fh],
                        projection='polar' if polar else None)


def text_mm(fig,x,top,text,**kwargs):
    fw,fh = fig.get_size_inches()*25.4
    return fig.text(x/fw,1-top/fh,text,**kwargs)


def rotation(theta):
    deg = (90-np.degrees(theta)+180)%360-180
    return deg-180 if deg>90 else deg+180 if deg < -90 else deg


def draw_sector(ax,mod,pct,overall,figure_name):
    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0,2.10)
    ax.grid(False)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.spines['polar'].set_visible(False)
    models = MODELS[mod]
    rows = overall[overall.Completeness.eq(pct)].set_index('Model')
    label_texts = []
    for k,metric in enumerate(METRICS):
        center = k*2*np.pi/5
        span = np.deg2rad(57)
        left,right = center-span/2,center+span/2
        ax.bar(center,1,bottom=R0,width=span,facecolor=SECTOR_BG[k],edgecolor='#687078',linewidth=.65,zorder=0)
        theta = np.linspace(left,right,120)
        for tick in [0,.25,.5,.75,1]:
            ax.plot(theta,np.full_like(theta,R0+tick),color='#99A1A6',lw=.4,zorder=1)
        for tick in [0,.5,1]:
            ax.text(left-.043,R0+tick,f'{tick:.1f}',ha='center',va='center',fontsize=5.9,
                    rotation=rotation(left),rotation_mode='anchor',color='#4C535B')
        step = span/len(models)
        for j,model in enumerate(models):
            t = left+(j+.5)*step
            value = float(rows.loc[model,metric])
            bar = ax.bar(t,value,bottom=R0,width=.79*step,color=COLORS[model],edgecolor='#5C6267',
                         lw=.55,hatch='///' if model=='DeepARG' else None,zorder=3)[0]
            np.testing.assert_allclose([bar.get_height(),bar.get_y()],[value,R0],rtol=0,atol=3e-16)
            # Alternate annotation radii to separate long rotated four-decimal labels.
            label_radius = R0 + (.40 if j % 2 else .74)
            label = ax.text(t,label_radius,f'{value:.4f}',ha='center',va='center',fontsize=6.6,
                            rotation=rotation(t),rotation_mode='anchor',color='#131B20',zorder=5)
            label_texts.append(label)
            ax.text(t,1.535,SHORT[model],ha='center',va='center',fontsize=6.0,
                    rotation=rotation(t),rotation_mode='anchor',color='#343A40')
            BAR_RECORDS.append(dict(Figure=figure_name,Modality=mod,Completeness=pct,Model=model,
                                    Metric=metric,Value=value,Bar_height=bar.get_height(),
                                    Baseline=R0,Label=f'{value:.4f}',N=int(rows.loc[model,'N'])))
        outward_align = 'left' if np.sin(center)>.1 else 'right' if np.sin(center)<-.1 else 'center'
        ax.text(center,1.745,METRIC_LABELS[k],ha=outward_align,va='center',fontsize=7.3,
                linespacing=1.05,fontweight='bold')
    ax.text(0,0,f'{pct}%\n{mod}',ha='center',va='center',fontsize=9,fontweight='bold',linespacing=1.3)
    return label_texts


def spread(y,spacing=.145):
    indexes = np.argsort(y)
    values = np.array(y)[indexes]
    for i in range(1,len(values)):
        values[i] = max(values[i],values[i-1]+spacing)
    values -= (values[0]+values[-1])/2
    output = np.empty(len(values))
    output[indexes] = values
    return output


def draw_radar(ax,mod,pct,table,display,figure_name):
    types = list(table.index)
    angles = np.pi/2-(np.arange(len(types))+.5)*2*np.pi/len(types)
    ux,uy = np.cos(angles),np.sin(angles)
    texts = []
    for r in [.2,.4,.6,.8,1.]:
        ax.add_patch(Circle((0,0),r,facecolor='none',edgecolor='#D8DEE3' if r<1 else '#68737E',
                            lw=.5 if r<1 else .7,zorder=0))
    for x,y in zip(ux,uy):
        ax.plot([0,x],[0,y],lw=.4,color='#E5E8EC',zorder=0)
    for side in [-1,1]:
        indexes = [i for i in range(len(types)) if (ux[i]<0)==(side<0)]
        ys = spread(uy[indexes]*1.1)
        for i,y in zip(indexes,ys):
            x = ux[i]*1.06+side*.025
            ax.plot([ux[i]*1.01,x-side*.015],[uy[i]*1.01,y],color='#BBC2C9',lw=.4)
            texts.append(ax.text(x,y,display[types[i]],va='center',ha='left' if side>0 else 'right',
                                 fontsize=8.1,clip_on=False))
    for model in MODELS[mod]:
        values = table[model].to_numpy(float)
        xs,ys = np.r_[ux*values,ux[0]*values[0]],np.r_[uy*values,uy[0]*values[0]]
        line, = ax.plot(xs,ys,color=COLORS[model],ls=STYLES[model],lw=.95,
                       marker=MARKERS[model],ms=2.8,mew=.65,
                       mfc=COLORS[model] if model=='ARGScope' else 'white',
                       zorder=5 if model=='ARGScope' else 3)
        for i,typ in enumerate(types):
            RADAR_RECORDS.append(dict(Figure=figure_name,Modality=mod,Completeness=pct,Model=model,
                                     Type=typ,Precision=float(values[i]),
                                     X=float(line.get_xdata()[i]),Y=float(line.get_ydata()[i])))
    for r in [.2,.4,.6,.8,1.]:
        a = np.deg2rad(83)
        ax.text(r*np.cos(a)+.018,r*np.sin(a)-.02,f'{r:.1f}',fontsize=6.1,ha='left',va='center',
                color='#707A83',zorder=8,bbox=dict(facecolor='white',edgecolor='none',alpha=.78,pad=.2))
    ax.set(xlim=(-2.03,2.03),ylim=(-1.35,1.35),aspect='equal')
    ax.axis('off')
    return texts


def legend(fig,top,radar=False):
    if radar:
        handles = [Line2D([0],[0],color=COLORS[m],ls=STYLES[m],marker=MARKERS[m],lw=1.1,ms=3.4,
                         mfc=COLORS[m] if m=='ARGScope' else 'white',label=m) for m in MODELS['Protein']]
    else:
        handles = [Patch(facecolor=COLORS[m],edgecolor='#5B6268',hatch='///' if m=='DeepARG' else None,
                         label=f'{SHORT[m]}  {m}') for m in MODELS['Protein']]
    h = fig.get_figheight()*25.4
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,1-top/h),ncol=5,
               frameon=False,fontsize=9.4,columnspacing=2,handlelength=2.8 if radar else 1.6)


def sector_group(fig,top,overall,name):
    legend(fig,top+1)
    groups = []
    for row,mod in enumerate(MODELS):
        for col,pct in enumerate(PCTS):
            ax = axes_mm(fig,4+104*col,top+6+99*row,100,100,polar=True)
            groups.append(draw_sector(ax,mod,pct,overall[mod],name))
    return groups


def radar_group(fig,top,tables,display,name):
    legend(fig,top+1,radar=True)
    groups = []
    for row,mod in enumerate(MODELS):
        for col,pct in enumerate(PCTS):
            ax = axes_mm(fig,20+99*col,top+20+75*row,93,65)
            groups.append(draw_radar(ax,mod,pct,tables[mod,pct],display,name))
            if row==0:
                text_mm(fig,66.5+99*col,top+13,f'{pct}%',ha='center',va='center',fontsize=11)
        text_mm(fig,7,top+52.5+75*row,mod,rotation=90,ha='center',va='center',fontsize=11,fontweight='bold')
    return groups


def check_layout(fig,groups):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    boundary = fig.bbox
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        box = text.get_window_extent(renderer)
        if box.width and box.height:
            assert box.x0>=boundary.x0-1 and box.y0>=boundary.y0-1 and box.x1<=boundary.x1+1 and box.y1<=boundary.y1+1, ('text outside canvas',text.get_text())
    labels = [t for group in groups for t in group]
    for i,left in enumerate(labels):
        for right in labels[i+1:]:
            assert not left.get_window_extent(renderer).overlaps(right.get_window_extent(renderer)), ('overlap',left.get_text(),right.get_text())


def save(fig,name,groups):
    check_layout(fig,groups)
    for ext in ['png','pdf','svg']:
        path = HERE/f'{name}.{ext}'
        metadata = {'Subject':CONTEXT} if ext=='pdf' else {'Description':CONTEXT}
        fig.savefig(path,dpi=400,metadata=metadata)
        if ext=='png':
            with Image.open(path) as im:
                im.verify()
        elif ext=='svg':
            ET.parse(path)
        else:
            assert path.read_bytes().startswith(b'%PDF-')
        EXPORTS.append(dict(File=path.name,SHA256=digest(path),Width_mm=fig.get_figwidth()*25.4,
                            Height_mm=fig.get_figheight()*25.4,Layout_check='PASS'))
    fig.savefig(HERE/f'{name}_preview.png',dpi=140)
    plt.close(fig)


def main():
    HERE.mkdir(exist_ok=True)
    (HERE/'data').mkdir(exist_ok=True)
    overall,per,tables,display,hashes = load_data()
    first,second,combined = '01_Type_five_metrics_circular_2x4','02_Type_precision_radar_2x4','03_Combined_five_metrics_and_precision'
    print('Rendering five metrics: ACC, macro Precision, macro Recall, macro F1, MCC...',flush=True)
    fig = plt.figure(figsize=(420/25.4,210/25.4))
    save(fig,first,sector_group(fig,0,overall,first))
    print('Rendering Type precision radars...',flush=True)
    fig = plt.figure(figsize=(420/25.4,168/25.4))
    save(fig,second,radar_group(fig,0,tables,display,second))
    print('Rendering combined vector figure...',flush=True)
    fig = plt.figure(figsize=(420/25.4,380/25.4))
    groups = sector_group(fig,0,overall,combined)
    groups += radar_group(fig,212,tables,display,combined)
    save(fig,combined,groups)
    bars,points = pd.DataFrame(BAR_RECORDS),pd.DataFrame(RADAR_RECORDS)
    for row in bars.itertuples():
        source=overall[row.Modality]
        value=float(source[(source.Model==row.Model)&(source.Completeness==row.Completeness)].iloc[0][row.Metric])
        assert row.Value==value and row.Label==f'{value:.4f}'
        assert abs(row.Bar_height-value)<3e-16
    for row in points.itertuples():
        value=float(tables[row.Modality,row.Completeness].loc[row.Type,row.Model])
        assert row.Precision==value and abs(np.hypot(row.X,row.Y)-value)<5e-16
    assert len(bars[bars.Figure==first])==160 and set(bars.Metric)==set(METRICS)
    assert len(EXPORTS)==9
    for path,value in hashes.items():
        assert digest(path)==value,'Input changed during plotting'
    for name,frame in [('rendered_circular_values',bars),('rendered_radar_values',points),
                       ('type_display_filter',pd.DataFrame(FILTER_RECORDS)),
                       ('source_overall_macro',pd.concat(overall.values(),ignore_index=True)),
                       ('source_per_type',pd.concat(per.values(),ignore_index=True))]:
        frame.to_csv(HERE/'data'/f'{name}.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    report=dict(Status='PASS',Input_hashes=hashes,Exports=EXPORTS,Circular_metrics=METRICS,
                Precision_Recall_F1_average='macro',Radar_metric='per-Type Precision',
                NonARG_in_Type_labels=False,Fixed_aggregate_labels=23,
                Type_counts={f'{m}_{p}':len(t) for (m,p),t in tables.items()},
                Main_circular_values=160,Main_radar_values=int(points.Figure.eq(second).sum()),
                All_plotted_values_match_latest_CSVs=True,Source_files_unchanged=True,
                Reused_old_confidence_intervals=False,Same_test_cohort_across_models=False,
                Outside_canvas_text=0,Numeric_and_type_label_overlaps=0)
    (HERE/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=ROOT/'Latest_60_90_circular_and_radar.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(HERE.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and 'superseded_precision_only' not in path.parts:
                z.write(path,Path(HERE.name)/path.relative_to(HERE))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print(json.dumps({k:v for k,v in report.items() if k not in ['Input_hashes','Exports']},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    main()
