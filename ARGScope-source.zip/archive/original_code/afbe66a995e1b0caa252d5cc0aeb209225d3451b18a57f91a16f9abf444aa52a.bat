@echo off
chcp 65001 >nul
setlocal
set "ARGPLOT_PYTHON=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%ARGPLOT_PYTHON%" set "ARGPLOT_PYTHON=python"
"%ARGPLOT_PYTHON%" -X utf8 -B -u "%~dp0plot_publication_panels.py" --cached
if errorlevel 1 echo Plotting failed. Please check the message above.
pause
