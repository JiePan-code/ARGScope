#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
对 ARG:nonARG = 1:10 的“未切割原始序列”structure 按 Subtype 分层划分 train/test。

逻辑与之前 1:1 数据集的划分代码保持一致：

1. 输入是未切割的：
       all_arg_nonarg_structure.txt

2. 每个 Subtype 单独划分：
       目标 test 比例 = 20%

3. 每个 Subtype 至少：
       2 train
       1 test

4. 当某个 Subtype 恰好有 3 条原始序列时：
       2 train
       1 test

5. 固定随机种子：
       20260817

6. 输出：
       all_arg_nonarg_structure_train.txt
       all_arg_nonarg_structure_test.txt
       all_arg_nonarg_train_test_split.csv

7. 后续 30aa / 40aa / 50aa 的五片段数据，
   都根据 Original.SARG.Seq.ID 继承这里的同一个 Split。

脚本建议直接放在：

    ARG1_nonARG10/
    ├── all_arg_nonarg_structure.txt
    ├── all_arg_nonarg_protein.fasta
    ├── all_arg_nonarg_dna.fasta
    ├── paired_simulated_fragments_5parts/
    └── split_ARG1_nonARG10_original_train_test.py
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
import random
from collections import Counter, defaultdict
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

DEFAULT_INPUT = (
    SCRIPT_DIR
    / "all_arg_nonarg_structure.txt"
)


def parse_args() -> argparse.Namespace:

    parser = argparse.ArgumentParser(
        description=(
            "Split ARG1:nonARG10 original structure "
            "into train/test by Subtype."
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT,
        help="输入未切割的 all_arg_nonarg_structure.txt",
    )

    parser.add_argument(
        "--test-fraction",
        type=float,
        default=0.20,
        help="每个 Subtype 的目标 test 比例，默认 0.20",
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=20260817,
        help="随机种子，默认 20260817",
    )

    parser.add_argument(
        "--min-subtype-count",
        type=int,
        default=3,
        help="允许划分的最小 Subtype 数量，默认 3",
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="输出目录；默认使用输入文件所在目录",
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="允许覆盖已经存在的输出文件",
    )

    return parser.parse_args()


def canonical_id(
    value: object,
) -> str:

    text = str(
        value
    ).strip()

    return (
        text.split()[0]
        if text
        else ""
    )


def stable_subtype_seed(
    global_seed: int,
    subtype: str,
) -> int:

    payload = (
        f"{global_seed}\0{subtype}"
    ).encode(
        "utf-8"
    )

    return int.from_bytes(
        hashlib.sha256(
            payload
        ).digest()[:8],
        "big",
    )


def calculate_test_count(
    n: int,
    test_fraction: float,
) -> int:

    if n < 3:

        raise ValueError(
            f"Subtype count must be >=3, observed {n}"
        )

    if n == 3:

        return 1

    target = int(
        math.floor(
            n
            * test_fraction
            + 0.5
        )
    )

    return max(
        1,
        min(
            target,
            n - 2,
        ),
    )


def read_structure(
    path: Path,
):

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:

            raise ValueError(
                f"Structure 文件没有表头：{path}"
            )

        fieldnames = list(
            reader.fieldnames
        )

        required = {
            "SARG.Seq.ID",
            "Type",
            "Subtype",
        }

        missing = sorted(
            required
            - set(fieldnames)
        )

        if missing:

            raise ValueError(
                f"Structure 缺少必要列：{missing}"
            )

        rows = list(
            reader
        )

    if not rows:

        raise ValueError(
            f"Structure 文件没有数据行：{path}"
        )

    ids = []

    for row_number, row in enumerate(
        rows,
        start=2,
    ):

        seq_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        subtype = str(
            row.get(
                "Subtype",
                "",
            )
        ).strip()

        type_name = str(
            row.get(
                "Type",
                "",
            )
        ).strip()

        if not seq_id:

            raise ValueError(
                f"第 {row_number} 行的 "
                "SARG.Seq.ID 为空"
            )

        if not subtype:

            raise ValueError(
                f"第 {row_number} 行的 "
                f"Subtype 为空：{seq_id}"
            )

        if not type_name:

            raise ValueError(
                f"第 {row_number} 行的 "
                f"Type 为空：{seq_id}"
            )

        row[
            "SARG.Seq.ID"
        ] = seq_id

        row[
            "Subtype"
        ] = subtype

        row[
            "Type"
        ] = type_name

        ids.append(
            seq_id
        )

    duplicate_ids = [
        seq_id
        for seq_id, count
        in Counter(
            ids
        ).items()
        if count > 1
    ]

    if duplicate_ids:

        raise ValueError(
            f"发现 {len(duplicate_ids)} 个重复 ID，"
            f"例如：{duplicate_ids[:10]}"
        )

    return (
        fieldnames,
        rows,
    )


def split_rows(
    rows: list[
        dict[str, str]
    ],
    test_fraction: float,
    seed: int,
    min_subtype_count: int,
):

    groups: dict[
        str,
        list[int],
    ] = defaultdict(
        list
    )

    for index, row in enumerate(
        rows
    ):

        groups[
            row[
                "Subtype"
            ]
        ].append(
            index
        )

    too_small = {
        subtype:
            len(indices)

        for subtype, indices
        in groups.items()

        if len(indices)
        < min_subtype_count
    }

    if too_small:

        preview = sorted(
            too_small.items(),
            key=lambda item: (
                item[1],
                item[0],
            ),
        )[:20]

        raise ValueError(
            f"发现 {len(too_small)} 个数量小于 "
            f"{min_subtype_count} 的 Subtype："
            f"{preview}"
        )

    split_by_index: dict[
        int,
        str,
    ] = {}

    subtype_summary = []

    for subtype in sorted(
        groups
    ):

        indices = list(
            groups[
                subtype
            ]
        )

        rng = random.Random(
            stable_subtype_seed(
                seed,
                subtype,
            )
        )

        rng.shuffle(
            indices
        )

        n_total = len(
            indices
        )

        n_test = (
            calculate_test_count(
                n_total,
                test_fraction,
            )
        )

        test_indices = set(
            indices[
                :n_test
            ]
        )

        for index in indices:

            split_by_index[
                index
            ] = (
                "test"
                if index
                in test_indices
                else "train"
            )

        subtype_summary.append(
            {
                "Subtype":
                    subtype,

                "Total":
                    n_total,

                "Train":
                    n_total
                    - n_test,

                "Test":
                    n_test,
            }
        )

    if (
        len(
            split_by_index
        )
        != len(rows)
    ):

        raise RuntimeError(
            "内部错误：并非所有记录都获得了 split"
        )

    train_rows = [
        row
        for index, row
        in enumerate(
            rows
        )
        if split_by_index[
            index
        ]
        == "train"
    ]

    test_rows = [
        row
        for index, row
        in enumerate(
            rows
        )
        if split_by_index[
            index
        ]
        == "test"
    ]

    return (
        train_rows,
        test_rows,
        split_by_index,
        subtype_summary,
    )


def write_tsv(
    path: Path,
    fieldnames: list[str],
    rows: list[
        dict[str, str]
    ],
) -> None:

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            delimiter="\t",
            lineterminator="\n",
            extrasaction="ignore",
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def write_split_csv(
    path: Path,
    rows: list[
        dict[str, str]
    ],
    split_by_index: dict[
        int,
        str,
    ],
) -> None:

    columns = [
        "SARG.Seq.ID",
        "Type",
        "Subtype",
        "Split",
    ]

    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=columns,
            lineterminator="\n",
        )

        writer.writeheader()

        for index, row in enumerate(
            rows
        ):

            writer.writerow(
                {
                    "SARG.Seq.ID":
                        row[
                            "SARG.Seq.ID"
                        ],

                    "Type":
                        row[
                            "Type"
                        ],

                    "Subtype":
                        row[
                            "Subtype"
                        ],

                    "Split":
                        split_by_index[
                            index
                        ],
                }
            )


def verify_outputs(
    original_rows,
    train_rows,
    test_rows,
    subtype_summary,
) -> None:

    original_ids = {
        row[
            "SARG.Seq.ID"
        ]
        for row
        in original_rows
    }

    train_ids = {
        row[
            "SARG.Seq.ID"
        ]
        for row
        in train_rows
    }

    test_ids = {
        row[
            "SARG.Seq.ID"
        ]
        for row
        in test_rows
    }

    if (
        train_ids
        & test_ids
    ):

        raise RuntimeError(
            "Train 和 test 存在重复 ID"
        )

    if (
        train_ids
        | test_ids
    ) != original_ids:

        raise RuntimeError(
            "Train + test 与原始 ID 集合不一致"
        )

    train_counts = Counter(
        row[
            "Subtype"
        ]
        for row
        in train_rows
    )

    test_counts = Counter(
        row[
            "Subtype"
        ]
        for row
        in test_rows
    )

    all_subtypes = {
        item[
            "Subtype"
        ]
        for item
        in subtype_summary
    }

    if (
        set(
            train_counts
        )
        != all_subtypes
        or set(
            test_counts
        )
        != all_subtypes
    ):

        raise RuntimeError(
            "并非所有 Subtype 都同时出现在 train 和 test"
        )

    if (
        min(
            train_counts.values()
        )
        < 2
        or min(
            test_counts.values()
        )
        < 1
    ):

        raise RuntimeError(
            "未满足每个 Subtype 至少 "
            "2 train + 1 test"
        )

    for item in subtype_summary:

        if (
            item[
                "Total"
            ]
            == 3
            and (
                item[
                    "Train"
                ]
                != 2
                or item[
                    "Test"
                ]
                != 1
            )
        ):

            raise RuntimeError(
                "数量为3的 Subtype 未按2/1划分："
                f"{item['Subtype']}"
            )


def main() -> None:

    args = parse_args()

    args.input = (
        args.input
        .expanduser()
        .resolve()
    )

    if not args.input.is_file():

        raise FileNotFoundError(
            f"找不到输入文件：{args.input}"
        )

    if not (
        0.0
        < args.test_fraction
        < 1.0
    ):

        raise ValueError(
            "--test-fraction 必须在 0 和 1 之间"
        )

    if (
        args.min_subtype_count
        < 3
    ):

        raise ValueError(
            "--min-subtype-count 不能小于 3"
        )

    output_dir = (
        args.output_dir
        or args.input.parent
    )

    output_dir = (
        output_dir
        .expanduser()
        .resolve()
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    train_path = (
        output_dir
        / "all_arg_nonarg_structure_train.txt"
    )

    test_path = (
        output_dir
        / "all_arg_nonarg_structure_test.txt"
    )

    split_path = (
        output_dir
        / "all_arg_nonarg_train_test_split.csv"
    )

    output_paths = [
        train_path,
        test_path,
        split_path,
    ]

    existing = [
        str(path)
        for path
        in output_paths
        if path.exists()
    ]

    if (
        existing
        and not args.overwrite
    ):

        raise FileExistsError(
            "以下输出文件已经存在；"
            "如需覆盖请添加 --overwrite：\n"
            + "\n".join(
                existing
            )
        )

    print(
        "=" * 100
    )

    print(
        "ARG1:nonARG10 - 按 Subtype 分层划分原始序列 train/test"
    )

    print(
        "=" * 100
    )

    print(
        f"输入文件       : {args.input}"
    )

    print(
        "输入层级       : 未切割 original sequences"
    )

    print(
        f"Test 目标比例  : {args.test_fraction:.4f}"
    )

    print(
        f"随机种子       : {args.seed}"
    )

    (
        fieldnames,
        rows,
    ) = read_structure(
        args.input
    )

    (
        train_rows,
        test_rows,
        split_by_index,
        subtype_summary,
    ) = split_rows(
        rows=rows,
        test_fraction=args.test_fraction,
        seed=args.seed,
        min_subtype_count=args.min_subtype_count,
    )

    verify_outputs(
        rows,
        train_rows,
        test_rows,
        subtype_summary,
    )

    write_tsv(
        train_path,
        fieldnames,
        train_rows,
    )

    write_tsv(
        test_path,
        fieldnames,
        test_rows,
    )

    write_split_csv(
        split_path,
        rows,
        split_by_index,
    )

    count_three = sum(
        item[
            "Total"
        ]
        == 3
        for item
        in subtype_summary
    )

    subtype_counts = Counter(
        row[
            "Subtype"
        ]
        for row
        in rows
    )

    arg_count = sum(
        count
        for subtype, count
        in subtype_counts.items()
        if subtype.lower()
        != "nonarg"
    )

    nonarg_count = sum(
        count
        for subtype, count
        in subtype_counts.items()
        if subtype.lower()
        == "nonarg"
    )

    print()
    print(
        "=" * 100
    )

    print(
        "划分完成并通过检查"
    )

    print(
        "=" * 100
    )

    print(
        f"总原始记录数                : {len(rows):,}"
    )

    print(
        f"ARG 原始序列数              : {arg_count:,}"
    )

    print(
        f"nonARG 原始序列数           : {nonarg_count:,}"
    )

    if arg_count:

        print(
            "实际 ARG:nonARG            : "
            f"1:{nonarg_count / arg_count:.4f}"
        )

    print(
        f"Subtype 数                  : {len(subtype_summary):,}"
    )

    print(
        f"恰好3条的 Subtype 数        : {count_three:,}"
    )

    print(
        f"Train 原始记录数            : {len(train_rows):,}"
    )

    print(
        f"Test 原始记录数             : {len(test_rows):,}"
    )

    print(
        f"实际 Test 比例              : "
        f"{len(test_rows) / len(rows):.4%}"
    )

    print(
        "Train/Test ID 是否无重叠    : True"
    )

    print(
        "所有 Subtype 是否两边均存在 : True"
    )

    print(
        "3条的 Subtype 是否均为2/1   : True"
    )

    print()
    print(
        "输出文件："
    )

    print(
        f"  {train_path}"
    )

    print(
        f"  {test_path}"
    )

    print(
        f"  {split_path}"
    )

    print()
    print(
        "后续 30aa/40aa/50aa fragment "
        "全部通过 Original.SARG.Seq.ID "
        "继承这个 split CSV。"
    )


if __name__ == "__main__":
    main()
