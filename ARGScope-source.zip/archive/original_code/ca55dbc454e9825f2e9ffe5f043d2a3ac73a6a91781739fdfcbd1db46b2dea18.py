#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope / ARG-OAP / DeepARG real-data Type-level boxplot + scatter comparison
=============================================================================

What this script does
---------------------
1. Recursively scans ARGScope real-data folders:
      ARGScope_DIAMOND_gate010_realdata_predictions/
      ARGScope_DIAMOND_gate020_realdata_predictions/
      ...
   and reads every:
      all_samples_ARG_predictions.csv

2. Reads ARG-OAP Type counts:
      ARGOAP/unnormalized_count.type.revised.txt

3. Reads DeepARG real-data results:
      DeepARG_Fast结果/*.clean.deeparg.mapping.ARG

4. Harmonizes Type names across the three tools.

5. Uses one fixed ARGScope parameter setting: gate=0.20 and DIAMOND=0.50,
   then compares it with ARG-OAP and DeepARG.

6. For every shared Type, draws:
      boxplot + jittered sample-level points
   like the faceted example figure.

7. Outputs both:
      A. raw Type count
      B. within-tool relative abundance (%)

Fixed setting
-------------
FIXED_GATE = 0.20
FIXED_DIAMOND = 0.50

Python 3.8 compatible.
Dependencies:
    pandas numpy matplotlib
"""

from __future__ import print_function

import math
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =============================================================================
# 1. CONFIG
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

# -----------------------------------------------------------------------------
# FIXED ARGScope FILTERING PARAMETERS
# -----------------------------------------------------------------------------
# Only this gate + DIAMOND combination will be plotted.
FIXED_GATE = 0.50
FIXED_DIAMOND = 0.20

OUT_DIR = ROOT_DIR / "ARGScope_ARGOAP_DeepARG_FIXED_g050_d02_Type_boxscatter_sample_colors"
FIG_DIR = OUT_DIR / "figures"
TABLE_DIR = OUT_DIR / "tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)

# Do not hard-code the comparison-tool folder names.
# The script will auto-detect the actual ARG-OAP file and DeepARG folder.
ARG_OAP_FILE = None
DEEPARG_DIR = None

ARGSCOPE_FILE_NAME = "all_samples_ARG_predictions.csv"
DEEPARG_PATTERN = "*.clean.deeparg.mapping.ARG"

# -----------------------------------------------------------------------------
# PARAMETER GROUPING
# -----------------------------------------------------------------------------
# Options:
#   "by_gate"    : fixed gate, split DIAMOND values into groups
#   "by_diamond" : fixed DIAMOND, split gate values into groups
#   "custom"     : use CUSTOM_GROUPS exactly
AUTO_GROUP_MODE = "by_gate"

# Maximum number of ARGScope parameter configurations in one figure group.
# ARG-OAP and DeepARG are then added automatically.
CONFIGS_PER_GROUP = 3

# Used only when AUTO_GROUP_MODE == "custom".
# Any number of groups can be defined.
# Format: "group name": [(gate, diamond), (gate, diamond), ...]
CUSTOM_GROUPS = {
    "Candidate_group_A": [
        (0.10, 0.20),
        (0.20, 0.20),
        (0.30, 0.20),
    ],
    "Candidate_group_B": [
        (0.10, 0.50),
        (0.20, 0.50),
        (0.30, 0.50),
    ],
}

# -----------------------------------------------------------------------------
# TYPE SELECTION
# -----------------------------------------------------------------------------
# "shared_all_three": Type must be detected at least once by ARGScope (any
#                      configuration), ARG-OAP, and DeepARG.
# "union":            union of canonical Types from the three tools.
TYPE_SELECTION_MODE = "shared_all_three"

# None = draw all selected Types.
# Example: 20 = only top 20 Types based on average relative abundance.
TOP_N_TYPES = None

# Type ordering:
#   "abundance"  : highest overall relative abundance first
#   "alphabetical"
TYPE_ORDER_MODE = "abundance"

# -----------------------------------------------------------------------------
# FIGURE LAYOUT
# -----------------------------------------------------------------------------
FACET_NCOLS = 5
FACET_NROWS = 4
PANEL_WIDTH = 3.10
PANEL_HEIGHT = 2.55

DPI = 600
SAVE_PDF = True
SAVE_SVG = True

POINT_SIZE = 22
POINT_ALPHA = 0.80
JITTER_WIDTH = 0.075
BOX_WIDTH = 0.56

# Make both raw-count and relative-abundance figures.
MAKE_RAW_COUNT = True
MAKE_RELATIVE_ABUNDANCE = True

# Optional log10(count+1) figure.
MAKE_LOG10_COUNT = False

# Show sample-level points on top of boxplots.
SHOW_SCATTER = True

# Main model colors: all ARGScope configurations use related red tones.
ARG_OAP_COLOR = "#B8B8B8"
DEEPARG_COLOR = "#6D8FB3"
ARGSCOPE_COLORS = [
    "#F4A3A3",
    "#EB7777",
    "#DF5555",
    "#CC3636",
    "#AF1F1F",
    "#8F1010",
]

# Preferred sample order.
PREFERRED_SAMPLES = [
    "argbert_1", "argbert_2", "argbert_3",
    "argscope_1", "argscope_2", "argscope_3",
    "argscope_4", "argscope_5", "argscope_6",
]

# Fixed colors for the 9 real-data samples.
# The SAME sample keeps the SAME color in ARGScope / ARG-OAP / DeepARG,
# so each colored point can be tracked across the three tools.
SAMPLE_COLORS = {
    "argbert_1": "#E64B35",
    "argbert_2": "#4DBBD5",
    "argbert_3": "#00A087",
    "argscope_1": "#3C5488",
    "argscope_2": "#F39B7F",
    "argscope_3": "#8491B4",
    "argscope_4": "#91D1C2",
    "argscope_5": "#DC0000",
    "argscope_6": "#7E6148",
}

# Fixed horizontal offsets, one per sample, instead of random jitter.
# This makes the same sample easier to track across ARGScope / ARG-OAP / DeepARG.
SAMPLE_JITTER_MAX = 0.16

# -----------------------------------------------------------------------------
# FONT / STYLE
# -----------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9.0,
    "axes.titlesize": 9.3,
    "axes.labelsize": 9.0,
    "xtick.labelsize": 7.4,
    "ytick.labelsize": 7.4,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 2. TYPE MAPPING
# =============================================================================

def clean_token(x):
    if pd.isna(x):
        return ""
    s = str(x).strip().lower()
    s = s.replace("β", "beta")
    s = re.sub(r"[\s/_-]+", "_", s)
    s = re.sub(r"[^a-z0-9_]", "", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_")


# Canonical ARGScope-style Type names.
TYPE_ALIASES = {
    "aminoglycoside": "aminoglycoside",
    "aminoglycosides": "aminoglycoside",

    "aminocoumarin": "novobiocin",
    "aminocoumarins": "novobiocin",
    "novobiocin": "novobiocin",

    "bacitracin": "bacitracin",

    "beta_lactam": "beta_lactam",
    "betalactam": "beta_lactam",
    "betalactams": "beta_lactam",

    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "phenicols": "chloramphenicol",

    "fluoroquinolone": "quinolone",
    "fluoroquinolones": "quinolone",
    "quinolone": "quinolone",
    "quinolones": "quinolone",

    "fosfomycin": "fosfomycin",
    "fusidic_acid": "fusidic_acid",

    "glycopeptide": "vancomycin",
    "glycopeptides": "vancomycin",
    "vancomycin": "vancomycin",

    "mls": "macrolide-lincosamide-streptogramin",
    "macrolide_lincosamide_streptogramin": "macrolide-lincosamide-streptogramin",

    "multidrug": "multidrug",
    "multi_drug_resistance": "multidrug",

    "mupirocin": "mupirocin",

    "pleuromutilin": "pleuromutilin_tiamulin",
    "pleuromutilin_tiamulin": "pleuromutilin_tiamulin",

    "polymyxin": "polymyxin",

    "rifamycin": "rifamycin",
    "rifampin": "rifamycin",
    "rifampicin": "rifamycin",

    "streptothricin": "streptothricin",
    "nucleoside": "streptothricin",
    "nucleosides": "streptothricin",

    "sulfonamide": "sulfonamide",
    "sulfonamides": "sulfonamide",

    "tetracenomycin_c": "tetracenomycin_C",
    "tetracycline": "tetracycline",
    "trimethoprim": "trimethoprim",

    "triclosan": "triclosan",
    "tunicamycin": "tunicamycin",
    "puromycin": "puromycin",
}

# Clearly non-Type / ambiguous ARG-OAP rows to exclude.
EXCLUDE_RAW_TYPES = {
    "pneumoniae",
    "perfringens",
    "fabrum",
    "monocytogenes",
    "cloacae",
    "class",
    "lividans",
    "23s",
    "anguillarum",
    "efflux",
    "baumannii",
    "pseudomallei",
    "coli",
    "intrinsic",
    "other_peptide_antibiotics",
}

# Ambiguous / unsupported DeepARG broad classes are excluded rather than forced
# into an ARGScope Type.
EXCLUDE_DEEPARG_CLASSES = {
    "unclassified",
    "peptide",
    "fosmidomycin",
    "nitroimidazole",
    "others",
    "other",
}


def canonical_type(raw):
    token = clean_token(raw)
    if token in EXCLUDE_RAW_TYPES:
        return None
    if token in TYPE_ALIASES:
        return TYPE_ALIASES[token]
    # Keep already-clean ARGScope labels when no explicit alias is needed.
    raw_s = str(raw).strip()
    if raw_s and token not in EXCLUDE_DEEPARG_CLASSES:
        return raw_s
    return None


# =============================================================================
# 3. ARGScope LOADING
# =============================================================================

def infer_gate_from_path(path):
    for part in path.parts:
        m = re.search(r"gate(\d+)", part.lower())
        if m:
            return int(m.group(1)) / 100.0
    return None


def infer_diamond_from_path(path):
    for part in reversed(path.parts):
        m = re.search(r"diamond\s*([01]?\.\d+)", part.lower())
        if m:
            return float(m.group(1))
    return None


def parse_diamond_value(value):
    s = str(value).strip().lower()
    m = re.search(r"([01]?\.\d+)", s)
    if m:
        return float(m.group(1))
    return None


def discover_argscope_prediction_files():
    files = []
    for p in ROOT_DIR.rglob(ARGSCOPE_FILE_NAME):
        if OUT_DIR in p.parents:
            continue
        if infer_gate_from_path(p) is None:
            continue
        files.append(p)
    return sorted(files)


def load_argscope_counts():
    files = discover_argscope_prediction_files()
    if not files:
        raise FileNotFoundError(
            "Cannot find any %s under ARGScope_DIAMOND_gate* folders." % ARGSCOPE_FILE_NAME
        )

    parts = []
    diagnostics = []

    print("=" * 90)
    print("Reading ARGScope Type predictions")
    print("=" * 90)
    print("Files found:", len(files))

    for i, path in enumerate(files, start=1):
        gate = infer_gate_from_path(path)
        path_diamond = infer_diamond_from_path(path)

        df = pd.read_csv(path)
        required = {"sample_name", "Pred_Type"}
        missing = required - set(df.columns)
        if missing:
            print("[SKIP]", path, "missing", missing)
            continue

        if "Pred_ARG" in df.columns:
            df = df[df["Pred_ARG"].astype(str).str.upper() == "ARG"].copy()

        # Deduplicate read predictions if read_id exists.
        if "read_id" in df.columns:
            dedup_cols = ["sample_name", "read_id"]
            if "diamond_threshold" in df.columns:
                dedup_cols.append("diamond_threshold")
            df = df.drop_duplicates(subset=dedup_cols, keep="first").copy()

        df["Type"] = df["Pred_Type"].map(canonical_type)
        df = df[df["Type"].notna()].copy()

        if "diamond_threshold" in df.columns:
            df["diamond"] = df["diamond_threshold"].map(parse_diamond_value)
        else:
            df["diamond"] = path_diamond

        if path_diamond is not None:
            df["diamond"] = df["diamond"].fillna(path_diamond)

        df["gate"] = float(gate)
        df = df[df["diamond"].notna()].copy()

        g = (
            df.groupby(["gate", "diamond", "sample_name", "Type"], as_index=False)
              .size()
              .rename(columns={"sample_name": "sample", "size": "Count"})
        )
        g["model"] = "ARGScope"
        parts.append(g)

        diagnostics.append({
            "file": str(path.relative_to(ROOT_DIR)),
            "gate": gate,
            "path_diamond": path_diamond,
            "rows_after_filter": len(df),
            "unique_diamonds": ",".join(str(x) for x in sorted(df["diamond"].dropna().unique())),
            "samples": df["sample_name"].nunique(),
            "types": df["Type"].nunique(),
        })

        print("[%03d/%03d] gate=%.2f | diamonds=%s | rows=%d | %s" % (
            i, len(files), gate,
            sorted(df["diamond"].dropna().unique().tolist()),
            len(df), path.relative_to(ROOT_DIR)
        ))

    if not parts:
        raise RuntimeError("No usable ARGScope prediction files were parsed.")

    out = pd.concat(parts, ignore_index=True)

    # If the same configuration was found in multiple files, combine counts.
    out = (
        out.groupby(["gate", "diamond", "sample", "Type", "model"], as_index=False)["Count"]
           .sum()
    )

    pd.DataFrame(diagnostics).to_csv(
        TABLE_DIR / "ARGScope_file_scan_diagnostics.csv",
        index=False, encoding="utf-8-sig"
    )
    out.to_csv(
        TABLE_DIR / "ARGScope_type_counts_all_parameter_settings.csv",
        index=False, encoding="utf-8-sig"
    )
    return out


# =============================================================================
# 3B. AUTO-DETECT ARG-OAP / DeepARG INPUTS
# =============================================================================

def find_argoap_file():
    """Find unnormalized_count.type.revised.txt under ROOT_DIR recursively."""
    exact = ROOT_DIR / "ARGOAP" / "unnormalized_count.type.revised.txt"
    if exact.exists():
        return exact

    candidates = [
        p for p in ROOT_DIR.rglob("unnormalized_count.type.revised.txt")
        if OUT_DIR not in p.parents
    ]
    if not candidates:
        raise FileNotFoundError(
            "Cannot find unnormalized_count.type.revised.txt anywhere under ROOT_DIR: %s"
            % ROOT_DIR
        )

    candidates = sorted(candidates, key=lambda p: (len(p.parts), str(p).lower()))
    if len(candidates) > 1:
        print("[WARN] Multiple ARG-OAP type files found; using:", candidates[0])
        for p in candidates[1:]:
            print("       other candidate:", p)
    return candidates[0]


def find_deeparg_dir():
    """
    Find the directory containing *.clean.deeparg.mapping.ARG files.
    This avoids depending on a fixed Chinese/English folder name.
    """
    exact = ROOT_DIR / "DeepARG_Fast结果"
    if exact.exists():
        exact_files = sorted(exact.glob(DEEPARG_PATTERN))
        if exact_files:
            return exact

    files = [
        p for p in ROOT_DIR.rglob(DEEPARG_PATTERN)
        if OUT_DIR not in p.parents
    ]
    if not files:
        raise FileNotFoundError(
            "Cannot find any DeepARG files matching %s under ROOT_DIR: %s"
            % (DEEPARG_PATTERN, ROOT_DIR)
        )

    # Usually all 9 files are in one folder. If more than one candidate parent
    # exists, choose the folder containing the largest number of matching files.
    parent_counts = {}
    for p in files:
        parent_counts[p.parent] = parent_counts.get(p.parent, 0) + 1

    ranked = sorted(
        parent_counts.items(),
        key=lambda kv: (-kv[1], len(kv[0].parts), str(kv[0]).lower()),
    )
    best_dir, best_count = ranked[0]

    if len(ranked) > 1:
        print("[WARN] Multiple DeepARG result directories found.")
        print("       using:", best_dir, "| files=", best_count)
        for p, n in ranked[1:]:
            print("       other:", p, "| files=", n)

    return best_dir

# =============================================================================
# 4. ARG-OAP LOADING
# =============================================================================

def load_argoap_counts():
    # Auto-detect the actual ARG-OAP type-count file every time this loader runs.
    # Do not depend on the optional global argoap_file, which may be None.
    argoap_file = find_argoap_file()
    print("[ARG-OAP] detected file:", argoap_file)

    if not argoap_file.exists():
        raise FileNotFoundError("Missing ARG-OAP Type file: %s" % argoap_file)

    df = pd.read_csv(argoap_file, sep="\t")
    if "gene" not in df.columns:
        raise ValueError("ARG-OAP file must contain a 'gene' column.")

    df["Type"] = df["gene"].map(canonical_type)

    excluded = df[df["Type"].isna()].copy()
    excluded.to_csv(
        TABLE_DIR / "ARGOAP_excluded_type_rows.csv",
        index=False, encoding="utf-8-sig"
    )

    df = df[df["Type"].notna()].copy()
    sample_cols = [c for c in df.columns if c not in {"gene", "Type"}]

    long_df = df.melt(
        id_vars=["Type"],
        value_vars=sample_cols,
        var_name="sample",
        value_name="Count",
    )
    long_df["Count"] = pd.to_numeric(long_df["Count"], errors="coerce").fillna(0.0)
    long_df = long_df.groupby(["sample", "Type"], as_index=False)["Count"].sum()
    long_df["model"] = "ARG-OAP"

    long_df.to_csv(
        TABLE_DIR / "ARGOAP_type_counts.csv",
        index=False, encoding="utf-8-sig"
    )
    return long_df


# =============================================================================
# 5. DeepARG LOADING
# =============================================================================

def infer_sample_from_deeparg_filename(path):
    suffix = ".clean.deeparg.mapping.ARG"
    name = path.name
    if name.endswith(suffix):
        return name[:-len(suffix)]
    return name.split(".clean", 1)[0]


def canonical_deeparg_type(raw):
    token = clean_token(raw)
    if token in EXCLUDE_DEEPARG_CLASSES:
        return None
    return canonical_type(raw)


def load_deeparg_counts():
    deeparg_dir = find_deeparg_dir()
    print("[DeepARG] detected folder:", deeparg_dir)

    files = sorted(deeparg_dir.glob(DEEPARG_PATTERN))
    if not files:
        raise FileNotFoundError("No DeepARG result files found in %s" % deeparg_dir)

    parts = []
    diagnostics = []

    for path in files:
        sample = infer_sample_from_deeparg_filename(path)
        df = pd.read_csv(path, sep="\t")

        if "predicted_ARG-class" not in df.columns:
            print("[SKIP DeepARG]", path.name, "no predicted_ARG-class")
            continue

        # One DeepARG result per read. If duplicates exist, keep strongest hit.
        if "read_id" in df.columns:
            sort_cols = []
            ascending = []
            if "probability" in df.columns:
                df["probability"] = pd.to_numeric(df["probability"], errors="coerce")
                sort_cols.append("probability")
                ascending.append(False)
            if "alignment-bitscore" in df.columns:
                df["alignment-bitscore"] = pd.to_numeric(df["alignment-bitscore"], errors="coerce")
                sort_cols.append("alignment-bitscore")
                ascending.append(False)
            if sort_cols:
                df = df.sort_values(sort_cols, ascending=ascending)
            df = df.drop_duplicates(subset=["read_id"], keep="first").copy()

        df["Type"] = df["predicted_ARG-class"].map(canonical_deeparg_type)
        excluded = df[df["Type"].isna()][["predicted_ARG-class"]].copy()
        excluded["sample"] = sample
        diagnostics.append(excluded)

        df = df[df["Type"].notna()].copy()

        if "counts" in df.columns:
            df["_count"] = pd.to_numeric(df["counts"], errors="coerce").fillna(1.0)
        else:
            df["_count"] = 1.0

        g = df.groupby("Type", as_index=False)["_count"].sum().rename(columns={"_count": "Count"})
        g["sample"] = sample
        g["model"] = "DeepARG"
        parts.append(g)

    if not parts:
        raise RuntimeError("No usable DeepARG results were parsed.")

    out = pd.concat(parts, ignore_index=True)
    out = out[["sample", "Type", "Count", "model"]]

    if diagnostics:
        pd.concat(diagnostics, ignore_index=True).to_csv(
            TABLE_DIR / "DeepARG_excluded_classes.csv",
            index=False, encoding="utf-8-sig"
        )

    out.to_csv(
        TABLE_DIR / "DeepARG_type_counts.csv",
        index=False, encoding="utf-8-sig"
    )
    return out


# =============================================================================
# 6. UNIFIED DATA PREPARATION
# =============================================================================

def preferred_sample_order(all_samples):
    all_samples = list(dict.fromkeys(str(x) for x in all_samples))
    ordered = [x for x in PREFERRED_SAMPLES if x in all_samples]
    ordered.extend(sorted(x for x in all_samples if x not in ordered))
    return ordered


def available_argscope_configs(argscope_df):
    configs = (
        argscope_df[["gate", "diamond"]]
        .drop_duplicates()
        .sort_values(["gate", "diamond"])
    )
    return [(float(r.gate), float(r.diamond)) for r in configs.itertuples(index=False)]


def fmt_config(gate, diamond):
    return "ARGScope\ng%.2f / d%.1f" % (float(gate), float(diamond))


def safe_name(s):
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(s))
    return s.strip("_")


def build_parameter_groups(configs):
    config_set = set((round(g, 6), round(d, 6)) for g, d in configs)
    groups = []

    if AUTO_GROUP_MODE == "custom":
        for group_name, requested in CUSTOM_GROUPS.items():
            valid = []
            for gate, diamond in requested:
                key = (round(float(gate), 6), round(float(diamond), 6))
                if key in config_set:
                    valid.append((float(gate), float(diamond)))
                else:
                    print("[WARN] custom config not found:", gate, diamond)
            if valid:
                groups.append((group_name, valid))

    elif AUTO_GROUP_MODE == "by_gate":
        gates = sorted(set(g for g, _ in configs))
        for gate in gates:
            ds = sorted(d for g, d in configs if np.isclose(g, gate))
            for chunk_i in range(0, len(ds), CONFIGS_PER_GROUP):
                chunk = ds[chunk_i:chunk_i + CONFIGS_PER_GROUP]
                valid = [(gate, d) for d in chunk]
                group_name = "gate%.2f_set%d" % (gate, chunk_i // CONFIGS_PER_GROUP + 1)
                groups.append((group_name, valid))

    elif AUTO_GROUP_MODE == "by_diamond":
        diamonds = sorted(set(d for _, d in configs))
        for diamond in diamonds:
            gs = sorted(g for g, d in configs if np.isclose(d, diamond))
            for chunk_i in range(0, len(gs), CONFIGS_PER_GROUP):
                chunk = gs[chunk_i:chunk_i + CONFIGS_PER_GROUP]
                valid = [(g, diamond) for g in chunk]
                group_name = "diamond%.1f_set%d" % (diamond, chunk_i // CONFIGS_PER_GROUP + 1)
                groups.append((group_name, valid))
    else:
        raise ValueError("Unknown AUTO_GROUP_MODE: %s" % AUTO_GROUP_MODE)

    if not groups:
        raise RuntimeError("No parameter groups were constructed.")

    manifest_rows = []
    for group_name, group_configs in groups:
        for order, (g, d) in enumerate(group_configs, start=1):
            manifest_rows.append({
                "group": group_name,
                "order": order,
                "gate": g,
                "diamond": d,
                "label": fmt_config(g, d).replace("\n", " "),
            })
    pd.DataFrame(manifest_rows).to_csv(
        TABLE_DIR / "parameter_group_manifest.csv",
        index=False, encoding="utf-8-sig"
    )
    return groups


def choose_types(argscope_df, argoap_df, deeparg_df):
    a = set(argscope_df["Type"].dropna().astype(str))
    o = set(argoap_df["Type"].dropna().astype(str))
    d = set(deeparg_df["Type"].dropna().astype(str))

    if TYPE_SELECTION_MODE == "shared_all_three":
        selected = a & o & d
    elif TYPE_SELECTION_MODE == "union":
        selected = a | o | d
    else:
        raise ValueError("Unknown TYPE_SELECTION_MODE: %s" % TYPE_SELECTION_MODE)

    if not selected:
        raise RuntimeError("No Types selected after cross-tool harmonization.")
    return sorted(selected)


def complete_model_type_table(df, samples, types, model_name):
    base_idx = pd.MultiIndex.from_product([samples, types], names=["sample", "Type"])
    x = df[["sample", "Type", "Count"]].copy()
    x["sample"] = x["sample"].astype(str)
    x["Type"] = x["Type"].astype(str)
    x = x.groupby(["sample", "Type"], as_index=True)["Count"].sum()
    x = x.reindex(base_idx, fill_value=0.0).reset_index()
    x["model"] = model_name
    return x


def make_relative_abundance(df):
    out = df.copy()
    totals = out.groupby(["category", "sample"])["Count"].transform("sum")
    out["Relative_abundance_pct"] = np.where(totals > 0, 100.0 * out["Count"] / totals, 0.0)
    return out


def build_group_long_table(argscope_df, argoap_df, deeparg_df, group_name, group_configs, types, samples):
    parts = []

    for gate, diamond in group_configs:
        sub = argscope_df[
            np.isclose(argscope_df["gate"].astype(float), float(gate)) &
            np.isclose(argscope_df["diamond"].astype(float), float(diamond))
        ].copy()
        completed = complete_model_type_table(sub, samples, types, "ARGScope")
        completed["gate"] = float(gate)
        completed["diamond"] = float(diamond)
        completed["category"] = fmt_config(gate, diamond)
        completed["category_family"] = "ARGScope"
        parts.append(completed)

    oap = complete_model_type_table(argoap_df, samples, types, "ARG-OAP")
    oap["gate"] = np.nan
    oap["diamond"] = np.nan
    oap["category"] = "ARG-OAP"
    oap["category_family"] = "ARG-OAP"
    parts.append(oap)

    deep = complete_model_type_table(deeparg_df, samples, types, "DeepARG")
    deep["gate"] = np.nan
    deep["diamond"] = np.nan
    deep["category"] = "DeepARG"
    deep["category_family"] = "DeepARG"
    parts.append(deep)

    out = pd.concat(parts, ignore_index=True)
    out["group"] = group_name
    out = make_relative_abundance(out)
    out["log10_Count_plus1"] = np.log10(out["Count"].astype(float) + 1.0)
    return out


def rank_types(all_group_df, types):
    if TYPE_ORDER_MODE == "alphabetical":
        ordered = sorted(types)
    else:
        score = (
            all_group_df.groupby("Type")["Relative_abundance_pct"]
            .mean()
            .sort_values(ascending=False)
        )
        ordered = [t for t in score.index if t in set(types)]
        ordered.extend([t for t in types if t not in ordered])

    if TOP_N_TYPES is not None:
        ordered = ordered[:int(TOP_N_TYPES)]
    return ordered



# =============================================================================
# 7. AUTOMATIC BEST GATE + DIAMOND SELECTION
# =============================================================================

# IMPORTANT:
# Real-data samples do not provide per-read ground truth here, so "best" cannot
# mean highest true ACC/Precision.  In this script, "best" means the ARGScope
# parameter setting whose Type-level abundance pattern agrees most strongly
# with the two external pipelines across the common samples.
#
# ARG-OAP is given slightly more weight because it is the primary abundance
# reference in this real-data comparison.
REFERENCE_WEIGHT_ARGOAP = 0.60
REFERENCE_WEIGHT_DEEPARG = 0.40

# Pairwise score components (must sum to 1.0):
#   Spearman: similarity of Type abundance ranking
#   Bray-Curtis similarity: similarity of Type abundance composition
#   Detection Jaccard: overlap of detected/non-detected Types
PAIR_WEIGHT_SPEARMAN = 0.45
PAIR_WEIGHT_BRAY = 0.45
PAIR_WEIGHT_JACCARD = 0.10

# Use relative abundance for parameter selection so that pipelines with
# different absolute ARG yield can still be compared at the Type-composition
# level. Raw counts are still plotted after the best setting is selected.
SELECTION_METRIC = "Relative_abundance_pct"

# Faceted figure layout for the one selected configuration.
BEST_FACET_NCOLS = 5
BEST_PANEL_WIDTH = 3.0
BEST_PANEL_HEIGHT = 2.55
ARGSCOPE_MAIN_COLOR = "#C73535"


def spearman_no_scipy(a, b):
    """Spearman correlation implemented using pandas ranks; no scipy needed."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]
    b = b[mask]
    if len(a) < 2:
        return np.nan
    ra = pd.Series(a).rank(method="average").to_numpy(dtype=float)
    rb = pd.Series(b).rank(method="average").to_numpy(dtype=float)
    if np.nanstd(ra) == 0 or np.nanstd(rb) == 0:
        # If both profiles are constant and identical, treat as perfect agreement.
        return 1.0 if np.allclose(a, b) else 0.0
    return float(np.corrcoef(ra, rb)[0, 1])


def bray_curtis_similarity(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]
    b = b[mask]
    if len(a) == 0:
        return np.nan
    denom = float(np.sum(np.abs(a) + np.abs(b)))
    if denom <= 0:
        return 1.0
    dist = float(np.sum(np.abs(a - b)) / denom)
    return max(0.0, min(1.0, 1.0 - dist))


def detection_jaccard(a_counts, b_counts):
    a = np.asarray(a_counts, dtype=float) > 0
    b = np.asarray(b_counts, dtype=float) > 0
    union = np.logical_or(a, b).sum()
    if union == 0:
        return 1.0
    inter = np.logical_and(a, b).sum()
    return float(inter / union)


def scale_spearman_to_01(rho):
    if not np.isfinite(rho):
        return np.nan
    return float((rho + 1.0) / 2.0)


def pair_agreement_for_sample(arg_rel, ref_rel, arg_count, ref_count):
    rho = spearman_no_scipy(arg_rel, ref_rel)
    rho01 = scale_spearman_to_01(rho)
    bray = bray_curtis_similarity(arg_rel, ref_rel)
    jac = detection_jaccard(arg_count, ref_count)

    comps = np.asarray([rho01, bray, jac], dtype=float)
    weights = np.asarray([
        PAIR_WEIGHT_SPEARMAN,
        PAIR_WEIGHT_BRAY,
        PAIR_WEIGHT_JACCARD,
    ], dtype=float)
    valid = np.isfinite(comps)
    if not np.any(valid):
        pair_score = np.nan
    else:
        pair_score = float(np.sum(comps[valid] * weights[valid]) / np.sum(weights[valid]))

    return {
        "spearman_rho": rho,
        "spearman_scaled_01": rho01,
        "bray_curtis_similarity": bray,
        "detection_jaccard": jac,
        "pair_score": pair_score,
    }


def get_category_matrix(gdf, category, samples, types, value_col):
    x = gdf[gdf["category"] == category].copy()
    pivot = x.pivot_table(
        index="sample",
        columns="Type",
        values=value_col,
        aggfunc="sum",
        fill_value=0.0,
    )
    pivot = pivot.reindex(index=samples, columns=types, fill_value=0.0)
    return pivot.astype(float)


def score_one_config(argscope_df, argoap_df, deeparg_df, gate, diamond, types, samples):
    group_name = "candidate_g%.2f_d%.1f" % (gate, diamond)
    gdf = build_group_long_table(
        argscope_df=argscope_df,
        argoap_df=argoap_df,
        deeparg_df=deeparg_df,
        group_name=group_name,
        group_configs=[(gate, diamond)],
        types=types,
        samples=samples,
    )

    arg_cat = fmt_config(gate, diamond)

    rel_arg = get_category_matrix(gdf, arg_cat, samples, types, "Relative_abundance_pct")
    rel_oap = get_category_matrix(gdf, "ARG-OAP", samples, types, "Relative_abundance_pct")
    rel_deep = get_category_matrix(gdf, "DeepARG", samples, types, "Relative_abundance_pct")

    cnt_arg = get_category_matrix(gdf, arg_cat, samples, types, "Count")
    cnt_oap = get_category_matrix(gdf, "ARG-OAP", samples, types, "Count")
    cnt_deep = get_category_matrix(gdf, "DeepARG", samples, types, "Count")

    per_sample_rows = []
    for sample in samples:
        a_rel = rel_arg.loc[sample].to_numpy(dtype=float)
        a_cnt = cnt_arg.loc[sample].to_numpy(dtype=float)

        o = pair_agreement_for_sample(
            a_rel,
            rel_oap.loc[sample].to_numpy(dtype=float),
            a_cnt,
            cnt_oap.loc[sample].to_numpy(dtype=float),
        )
        d = pair_agreement_for_sample(
            a_rel,
            rel_deep.loc[sample].to_numpy(dtype=float),
            a_cnt,
            cnt_deep.loc[sample].to_numpy(dtype=float),
        )

        o_score = float(o["pair_score"]) if np.isfinite(o["pair_score"]) else np.nan
        d_score = float(d["pair_score"]) if np.isfinite(d["pair_score"]) else np.nan

        if np.isfinite(o_score) and np.isfinite(d_score):
            consensus = (
                REFERENCE_WEIGHT_ARGOAP * o_score +
                REFERENCE_WEIGHT_DEEPARG * d_score
            )
        elif np.isfinite(o_score):
            consensus = o_score
        elif np.isfinite(d_score):
            consensus = d_score
        else:
            consensus = np.nan

        per_sample_rows.append({
            "gate": gate,
            "diamond": diamond,
            "sample": sample,
            "ARGOAP_spearman_rho": o["spearman_rho"],
            "ARGOAP_bray_curtis_similarity": o["bray_curtis_similarity"],
            "ARGOAP_detection_jaccard": o["detection_jaccard"],
            "ARGOAP_pair_score": o_score,
            "DeepARG_spearman_rho": d["spearman_rho"],
            "DeepARG_bray_curtis_similarity": d["bray_curtis_similarity"],
            "DeepARG_detection_jaccard": d["detection_jaccard"],
            "DeepARG_pair_score": d_score,
            "consensus_score": consensus,
        })

    per_sample = pd.DataFrame(per_sample_rows)

    summary = {
        "gate": float(gate),
        "diamond": float(diamond),
        "n_samples": len(samples),
        "n_types": len(types),
        "ARGOAP_mean_spearman_rho": per_sample["ARGOAP_spearman_rho"].mean(),
        "ARGOAP_mean_bray_similarity": per_sample["ARGOAP_bray_curtis_similarity"].mean(),
        "ARGOAP_mean_jaccard": per_sample["ARGOAP_detection_jaccard"].mean(),
        "ARGOAP_mean_pair_score": per_sample["ARGOAP_pair_score"].mean(),
        "DeepARG_mean_spearman_rho": per_sample["DeepARG_spearman_rho"].mean(),
        "DeepARG_mean_bray_similarity": per_sample["DeepARG_bray_curtis_similarity"].mean(),
        "DeepARG_mean_jaccard": per_sample["DeepARG_detection_jaccard"].mean(),
        "DeepARG_mean_pair_score": per_sample["DeepARG_pair_score"].mean(),
        "consensus_score": per_sample["consensus_score"].mean(),
    }
    return summary, per_sample, gdf


def select_best_configuration(argscope_df, argoap_df, deeparg_df, configs, types, samples):
    print("\n" + "=" * 90)
    print("Selecting the best gate + DIAMOND configuration BEFORE plotting")
    print("Definition of best: Type-level abundance agreement with ARG-OAP and DeepARG")
    print("Reference weights: ARG-OAP=%.2f, DeepARG=%.2f" % (
        REFERENCE_WEIGHT_ARGOAP, REFERENCE_WEIGHT_DEEPARG
    ))
    print("Pair score weights: Spearman=%.2f, Bray-Curtis=%.2f, Jaccard=%.2f" % (
        PAIR_WEIGHT_SPEARMAN, PAIR_WEIGHT_BRAY, PAIR_WEIGHT_JACCARD
    ))
    print("=" * 90)

    summaries = []
    sample_parts = []
    config_tables = {}

    for i, (gate, diamond) in enumerate(configs, start=1):
        summary, per_sample, gdf = score_one_config(
            argscope_df, argoap_df, deeparg_df,
            gate, diamond, types, samples
        )
        summaries.append(summary)
        sample_parts.append(per_sample)
        config_tables[(round(gate, 6), round(diamond, 6))] = gdf
        print(
            "[%02d/%02d] gate=%.2f diamond=%.1f | consensus=%.4f | "
            "ARG-OAP=%.4f | DeepARG=%.4f"
            % (
                i, len(configs), gate, diamond,
                summary["consensus_score"],
                summary["ARGOAP_mean_pair_score"],
                summary["DeepARG_mean_pair_score"],
            )
        )

    ranking = pd.DataFrame(summaries)
    ranking = ranking.sort_values(
        ["consensus_score", "ARGOAP_mean_pair_score", "DeepARG_mean_pair_score"],
        ascending=[False, False, False],
    ).reset_index(drop=True)
    ranking.insert(0, "rank", np.arange(1, len(ranking) + 1))

    ranking.to_csv(
        TABLE_DIR / "gate_diamond_configuration_ranking.csv",
        index=False, encoding="utf-8-sig", float_format="%.6f"
    )
    pd.concat(sample_parts, ignore_index=True).to_csv(
        TABLE_DIR / "gate_diamond_configuration_scores_per_sample.csv",
        index=False, encoding="utf-8-sig", float_format="%.6f"
    )

    best = ranking.iloc[0].to_dict()
    best_gate = float(best["gate"])
    best_diamond = float(best["diamond"])
    best_key = (round(best_gate, 6), round(best_diamond, 6))
    best_gdf = config_tables[best_key]

    pd.DataFrame([best]).to_csv(
        TABLE_DIR / "SELECTED_best_gate_diamond.csv",
        index=False, encoding="utf-8-sig", float_format="%.6f"
    )
    best_gdf.to_csv(
        TABLE_DIR / "SELECTED_best_configuration_sample_type_values_long.csv",
        index=False, encoding="utf-8-sig", float_format="%.6f"
    )

    print("\n*** SELECTED BEST CONFIGURATION ***")
    print("gate        = %.2f" % best_gate)
    print("DIAMOND     = %.1f" % best_diamond)
    print("consensus   = %.4f" % float(best["consensus_score"]))
    print("ARG-OAP     = %.4f" % float(best["ARGOAP_mean_pair_score"]))
    print("DeepARG     = %.4f" % float(best["DeepARG_mean_pair_score"]))
    print("***********************************\n")

    return best_gate, best_diamond, best_gdf, ranking


# =============================================================================
# 8. PLOT ONLY THE SELECTED BEST CONFIGURATION
# =============================================================================

def metric_info(metric):
    if metric == "Count":
        return "Count", "raw_count"
    if metric == "Relative_abundance_pct":
        return "Relative abundance (%)", "relative_abundance"
    if metric == "log10_Count_plus1":
        return "log10(Count + 1)", "log10_count"
    return metric, safe_name(metric)


def get_sample_order_from_type_df(type_df):
    present = list(dict.fromkeys(type_df["sample"].astype(str).tolist()))
    ordered = [s for s in PREFERRED_SAMPLES if s in present]
    ordered.extend(sorted(s for s in present if s not in ordered))
    return ordered


def sample_color(sample_name):
    # Stable fallback color for any unexpected extra sample.
    if sample_name in SAMPLE_COLORS:
        return SAMPLE_COLORS[sample_name]
    fallback = plt.get_cmap("tab20")
    idx = abs(hash(str(sample_name))) % 20
    return fallback(idx)


def plot_one_type_panel(ax, type_df, metric, rng=None, show_xlabel=True):
    categories = ["ARGScope", "ARG-OAP", "DeepARG"]
    box_colors = [ARGSCOPE_MAIN_COLOR, ARG_OAP_COLOR, DEEPARG_COLOR]
    sample_order = get_sample_order_from_type_df(type_df)

    # Boxplots still summarize the 9 real-data samples for each tool.
    arrays = []
    for cat in categories:
        vals = type_df[type_df["plot_category"] == cat][metric].astype(float).to_numpy()
        arrays.append(vals)

    bp = ax.boxplot(
        arrays,
        positions=np.arange(3),
        widths=BOX_WIDTH,
        patch_artist=True,
        showfliers=False,
        medianprops=dict(color="#222222", linewidth=1.10),
        whiskerprops=dict(color="#666666", linewidth=0.75),
        capprops=dict(color="#666666", linewidth=0.75),
        boxprops=dict(linewidth=0.85, edgecolor="#555555"),
    )
    for box, color in zip(bp["boxes"], box_colors):
        box.set_facecolor(color)
        box.set_alpha(0.62 if color == ARGSCOPE_MAIN_COLOR else 0.36)

    # The 9 points are the 9 common real-data samples.
    # Each sample gets one fixed color and one fixed x-offset across all tools.
    if SHOW_SCATTER and sample_order:
        if len(sample_order) == 1:
            offsets = {sample_order[0]: 0.0}
        else:
            vals = np.linspace(-SAMPLE_JITTER_MAX, SAMPLE_JITTER_MAX, len(sample_order))
            offsets = dict(zip(sample_order, vals))

        for x_i, cat in enumerate(categories):
            sub = type_df[type_df["plot_category"] == cat].copy()
            if sub.empty:
                continue
            sub["sample"] = sub["sample"].astype(str)

            for sample in sample_order:
                row = sub[sub["sample"] == sample]
                if row.empty:
                    continue
                y = pd.to_numeric(row.iloc[0][metric], errors="coerce")
                if not np.isfinite(y):
                    continue
                ax.scatter(
                    x_i + offsets[sample],
                    float(y),
                    s=POINT_SIZE + 5,
                    c=[sample_color(sample)],
                    alpha=0.92,
                    edgecolors="white",
                    linewidths=0.55,
                    zorder=4,
                )

    ax.set_xticks(np.arange(3))
    if show_xlabel:
        ax.set_xticklabels(categories, rotation=42, ha="right", rotation_mode="anchor")
    else:
        ax.set_xticklabels([])
        ax.tick_params(axis="x", length=0)

    ax.grid(axis="y", linestyle=":", linewidth=0.45, alpha=0.30)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def plot_best_config_facets(best_gdf, best_gate, best_diamond, ordered_types, metric):
    ylabel, metric_tag = metric_info(metric)

    arg_cat = fmt_config(best_gate, best_diamond)
    plot_df = best_gdf.copy()
    plot_df["plot_category"] = plot_df["category"].replace({arg_cat: "ARGScope"})

    ntypes = len(ordered_types)
    ncols = min(BEST_FACET_NCOLS, max(1, ntypes))
    nrows = int(math.ceil(float(ntypes) / float(ncols)))

    fig_w = BEST_PANEL_WIDTH * ncols
    fig_h = BEST_PANEL_HEIGHT * nrows + 1.65
    fig, axes = plt.subplots(nrows, ncols, figsize=(fig_w, fig_h), squeeze=False, dpi=180)
    axes = axes.flatten()
    rng = np.random.RandomState(2026 + int(round(best_gate * 100)) + int(round(best_diamond * 10)))

    for i, type_name in enumerate(ordered_types):
        ax = axes[i]
        tdf = plot_df[plot_df["Type"] == type_name].copy()
        plot_one_type_panel(ax, tdf, metric, rng, show_xlabel=True)
        ax.set_title(type_name, fontsize=9.4, pad=5)
        if i % ncols == 0:
            ax.set_ylabel(ylabel)

    for j in range(ntypes, len(axes)):
        axes[j].axis("off")

    # Model legend describes BOX colors.
    model_handles = [
        plt.Rectangle((0, 0), 1, 1, facecolor=ARGSCOPE_MAIN_COLOR, edgecolor="#555555", alpha=0.62),
        plt.Rectangle((0, 0), 1, 1, facecolor=ARG_OAP_COLOR, edgecolor="#555555", alpha=0.36),
        plt.Rectangle((0, 0), 1, 1, facecolor=DEEPARG_COLOR, edgecolor="#555555", alpha=0.36),
    ]
    fig.legend(
        model_handles, ["ARGScope", "ARG-OAP", "DeepARG"],
        loc="upper center", bbox_to_anchor=(0.5, 0.952),
        ncol=3, frameon=False, fontsize=9.7,
        handletextpad=0.45, columnspacing=1.5,
        title="Boxplots: models", title_fontsize=8.7,
    )

    # Sample legend describes POINT colors.
    sample_names = [s for s in PREFERRED_SAMPLES if s in set(plot_df["sample"].astype(str))]
    sample_names.extend(sorted(
        s for s in set(plot_df["sample"].astype(str))
        if s not in sample_names
    ))
    sample_handles = [
        plt.Line2D([], [], linestyle="none", marker="o", markersize=6.0,
                   markerfacecolor=sample_color(s), markeredgecolor="white", markeredgewidth=0.55)
        for s in sample_names
    ]
    fig.legend(
        sample_handles, sample_names,
        loc="upper center", bbox_to_anchor=(0.5, 0.905),
        ncol=min(9, max(1, len(sample_names))), frameon=False, fontsize=8.2,
        handletextpad=0.30, columnspacing=0.85,
        title="Points: real-data samples", title_fontsize=8.5,
    )

    fig.suptitle(
        "ARGScope configuration: gate %.2f + DIAMOND %.1f | Type-level %s"
        % (best_gate, best_diamond, ylabel),
        fontsize=15.0, fontweight="bold", y=0.992,
    )
    fig.text(
        0.5, 0.018,
        "Only the fixed ARGScope gate+DIAMOND setting is plotted; point color identifies each of the 9 common real-data samples.",
        ha="center", va="bottom", fontsize=8.7, color="#4B4B4B",
    )

    fig.subplots_adjust(
        left=0.055,
        right=0.985,
        top=0.845,
        bottom=0.085,
        wspace=0.30,
        hspace=0.55,
    )

    stem = "FIXED_g%.2f_d%.1f_type_boxscatter_sample_colors_%s" % (best_gate, best_diamond, metric_tag)
    png = FIG_DIR / (stem + ".png")
    pdf = FIG_DIR / (stem + ".pdf")
    svg = FIG_DIR / (stem + ".svg")

    fig.savefig(png, dpi=DPI, bbox_inches="tight", facecolor="white")
    if SAVE_PDF:
        fig.savefig(pdf, bbox_inches="tight", facecolor="white")
    if SAVE_SVG:
        fig.savefig(svg, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("[FIGURE]", png)


def plot_best_config(best_gdf, best_gate, best_diamond, ordered_types):
    metrics = []
    if MAKE_RAW_COUNT:
        metrics.append("Count")
    if MAKE_RELATIVE_ABUNDANCE:
        metrics.append("Relative_abundance_pct")
    if MAKE_LOG10_COUNT:
        metrics.append("log10_Count_plus1")

    for metric in metrics:
        plot_best_config_facets(
            best_gdf=best_gdf,
            best_gate=best_gate,
            best_diamond=best_diamond,
            ordered_types=ordered_types,
            metric=metric,
        )


# =============================================================================
# 9. MAIN
# =============================================================================

def main():
    print("=" * 90)
    print("ARGScope / ARG-OAP / DeepARG Type-level comparison")
    print("Plot ONLY the fixed ARGScope configuration: gate=%.2f, DIAMOND=%.1f" % (FIXED_GATE, FIXED_DIAMOND))
    print("=" * 90)
    print("ROOT_DIR:", ROOT_DIR)
    print("OUT_DIR :", OUT_DIR)
    print()

    argscope = load_argscope_counts()
    argoap = load_argoap_counts()
    deeparg = load_deeparg_counts()

    configs = available_argscope_configs(argscope)
    config_keys = set((round(float(g), 6), round(float(d), 6)) for g, d in configs)
    fixed_key = (round(float(FIXED_GATE), 6), round(float(FIXED_DIAMOND), 6))

    print("\nAvailable ARGScope configurations (%d):" % len(configs))
    for g, d in configs:
        print("  gate=%.2f  diamond=%.1f" % (g, d))

    if fixed_key not in config_keys:
        raise RuntimeError(
            "Requested fixed configuration was not found: gate=%.2f, DIAMOND=%.1f" %
            (FIXED_GATE, FIXED_DIAMOND)
        )

    selected_types = choose_types(argscope, argoap, deeparg)
    print("\nSelected cross-tool Types:", len(selected_types))
    print(selected_types)

    samples = set(argscope["sample"].astype(str))
    samples &= set(argoap["sample"].astype(str))
    samples &= set(deeparg["sample"].astype(str))
    samples = preferred_sample_order(samples)
    if not samples:
        raise RuntimeError("No common sample names across ARGScope, ARG-OAP and DeepARG.")

    print("\nCommon samples (%d):" % len(samples))
    for s in samples:
        print(" ", s)

    pd.DataFrame([
        {"sample": s, "color": SAMPLE_COLORS.get(s, "fallback_tab20")}
        for s in samples
    ]).to_csv(
        TABLE_DIR / "realdata_sample_color_mapping.csv",
        index=False, encoding="utf-8-sig"
    )

    # Build ONLY the requested gate=0.20 + DIAMOND=0.50 configuration.
    fixed_gdf = build_group_long_table(
        argscope_df=argscope,
        argoap_df=argoap,
        deeparg_df=deeparg,
        group_name="fixed_g%.2f_d%.1f" % (FIXED_GATE, FIXED_DIAMOND),
        group_configs=[(FIXED_GATE, FIXED_DIAMOND)],
        types=selected_types,
        samples=samples,
    )

    fixed_gdf.to_csv(
        TABLE_DIR / "FIXED_g020_d05_sample_type_values_long.csv",
        index=False, encoding="utf-8-sig"
    )

    pd.DataFrame([{
        "gate": FIXED_GATE,
        "diamond": FIXED_DIAMOND,
        "n_common_samples": len(samples),
        "n_selected_types": len(selected_types),
    }]).to_csv(
        TABLE_DIR / "FIXED_configuration_info.csv",
        index=False, encoding="utf-8-sig"
    )

    # Order Types using only this fixed configuration.
    ordered_types = rank_types(fixed_gdf, selected_types)
    pd.DataFrame({
        "Type": ordered_types,
        "plot_order": range(1, len(ordered_types) + 1),
    }).to_csv(
        TABLE_DIR / "FIXED_g020_d05_Type_plot_order.csv",
        index=False, encoding="utf-8-sig"
    )

    # Plot ONLY gate 0.20 + DIAMOND 0.50.
    plot_best_config(
        best_gdf=fixed_gdf,
        best_gate=FIXED_GATE,
        best_diamond=FIXED_DIAMOND,
        ordered_types=ordered_types,
    )

    print("\n" + "=" * 90)
    print("Done.")
    print("Fixed setting: gate=%.2f, DIAMOND=%.1f" % (FIXED_GATE, FIXED_DIAMOND))
    print("Figures:", FIG_DIR)
    print("Tables :", TABLE_DIR)
    print("=" * 90)


if __name__ == "__main__":
    main()
