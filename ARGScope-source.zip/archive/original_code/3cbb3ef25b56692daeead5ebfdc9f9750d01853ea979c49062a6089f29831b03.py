"""VF/BGC revision: type-count bars only in A/B; unchanged C-H performance."""
from pathlib import Path
import json
import shutil
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
import redraw_vf_bgc_datasets_no_umap_20260925 as base

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/vf_bgc_typebars_only_20260925'
base.OUT = OUT
old = base.old


def type_bars(fig, domain, data, box, label_size=10.2, number_size=9.6):
    ax = base.axes(fig, *box)
    d = data[domain]
    labels = d['type_order']
    cursor, ys = -.5, []
    for label in labels:
        height = 1.62 if '\n' in old.wrapped(label) else 1.0
        ys.append(cursor + height / 2)
        cursor += height + .18
    values = d['counts'].reindex(labels)[base.SPLITS].to_numpy(int)
    totals = values.sum(axis=1)
    left = np.zeros(len(labels))
    # Same physical bar thickness for the paired panels.
    thickness = .105 / box[3] * (cursor + .65)
    for j, split in enumerate(base.SPLITS):
        bars = ax.barh(ys, values[:, j], left=left, height=thickness,
                       color=base.SPLIT_COLORS[split], edgecolor='none', zorder=3)
        np.testing.assert_array_equal([p.get_width() for p in bars], values[:, j])
        left += values[:, j]
    assert int(totals.sum()) == d['positive_N']
    ax.set_xlim(0, 11000)
    ax.set_ylim(cursor, -.65)
    ax.set_yticks(ys, [old.wrapped(label) for label in labels], fontsize=label_size)
    ax.tick_params(axis='y', length=0, pad=5)
    for tick in ax.get_yticklabels():
        tick.set_linespacing(1.0)
    ax.set_xticks([0, 4000, 8000], ['0', '4,000', '8,000'], fontsize=label_size)
    ax.set_xlabel('Number of sequences', fontsize=label_size + .3, labelpad=5)
    ax.tick_params(axis='x', length=3, pad=3, width=.6)
    ax.grid(axis='x', color='#E2E7EA', lw=.6, zorder=0)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#84949F')
    ax.spines['bottom'].set_linewidth(.65)
    for y, total in zip(ys, totals):
        ax.text(total + 170, y, f'{total:,}', ha='left', va='center', fontsize=number_size)
    return ax


def combined(data):
    fig = plt.figure(figsize=(2480 / 300, 3508 / 300), dpi=160, facecolor='none')
    fig.set_label('VF_BGC_typebars_only_A4_300DPI')
    base.base_canvas(fig)
    for panel, domain, lx, cx in [('A', 'VF', .07, 2.10), ('B', 'BGC', 4.26, 6.30)]:
        base.letter(fig, lx, .13, panel)
        base.text(fig, cx, .18, f'{domain} sequences by functional type', size=10.8,
                  weight='bold', ha='center')
    base.split_legend(fig, .51, 10.4)
    type_bars(fig, 'VF', data, [1.72, .93, 2.24, 3.32], label_size=10.2)
    type_bars(fig, 'BGC', data, [5.13, .93, 2.90, 3.32], label_size=10.2)
    old.modality_legend(fig, old.W / 2, 4.66, 10.5)
    for domain, lx, rx, bx, a, b in [('VF', .04, .52, 2.24, 'C', 'D'),
                                    ('BGC', 4.19, 4.67, 6.39, 'E', 'F')]:
        base.letter(fig, lx, 5.00, a)
        base.text(fig, rx + .64, 5.06, f'{domain}/non-{domain}', size=10.7, ha='center')
        ax = old.radar(fig, domain, data[domain], [rx - .03, 5.65, 1.23, 1.23], small=True)
        for tick in ax.get_xticklabels():
            tick.set_fontsize(9.4)
        base.letter(fig, bx - .14, 5.00, b)
        base.text(fig, bx + .82, 5.05, f'{domain} · Subtype\n(weighted)',
                  size=10.4, ha='center', linespacing=1.03)
        ax = old.bars(fig, domain, data[domain], [bx + .10, 5.47, 1.61, 1.63], small=True)
        ax.tick_params(axis='both', labelsize=9.4)
    base.text(fig, old.W / 2, 7.34,
              'P = precision; R = recall. Binary: positive class. Subtype: weighted P/R/F1.',
              size=9.1, ha='center')
    base.letter(fig, .06, 7.75, 'G')
    base.letter(fig, 4.46, 7.75, 'H')
    base.text(fig, 2.80, 7.78, 'VF type-level performance', size=11, weight='bold', ha='center')
    base.text(fig, 6.60, 7.78, 'BGC type-level performance', size=11, weight='bold', ha='center')
    base.adjusted_heatmap(fig, 'VF', data['VF'], [1.51, 8.21, 2.62, 3.05])
    base.adjusted_heatmap(fig, 'BGC', data['BGC'], [5.20, 8.21, 2.63, 2.51])
    base.text(fig, 6.49, 11.01, 'Average: macro across all types\nand the non-target class',
              size=9.3, ha='center', linespacing=1.28)
    base.text(fig, old.W / 2, 11.49, 'A–B: target sequences only; AA and NT use the same sequence records.',
              size=8.8, ha='center')
    return fig


def individual_dataset(domain, data):
    height = 5.8 if domain == 'VF' else 4.8
    fig = plt.figure(figsize=(7.4, height), dpi=160, facecolor='none')
    panel = 'A' if domain == 'VF' else 'B'
    fig.set_label(f'{panel}_{domain}_dataset_types')
    base.letter(fig, .15, .14, panel)
    base.text(fig, 3.85, .19, f'{domain} sequences by functional type',
              size=14, weight='bold', ha='center')
    base.split_legend(fig, .57, 12)
    left = 2.78 if domain == 'VF' else 1.05
    type_bars(fig, domain, data, [left, 1.02, 7.05 - left, height - 1.64],
              label_size=12.3, number_size=12.0)
    return fig


def pair(data):
    fig = plt.figure(figsize=(12.0, 5.4), dpi=160, facecolor='none')
    fig.set_label('AB_VF_BGC_dataset_types')
    base.letter(fig, .10, .12, 'A')
    base.letter(fig, 6.20, .12, 'B')
    for domain, x in [('VF', 3.0), ('BGC', 9.15)]:
        base.text(fig, x, .15, f'{domain} sequences by functional type',
                  size=13, weight='bold', ha='center')
    base.split_legend(fig, .52, 11.5)
    type_bars(fig, 'VF', data, [2.57, 1.00, 3.14, 3.80], label_size=12, number_size=11.5)
    type_bars(fig, 'BGC', data, [7.15, 1.00, 4.45, 3.80], label_size=12, number_size=11.5)
    return fig


def main():
    for subdir in ['', 'data', 'previews', 'svg', 'editable_svg', 'pdf', 'code']:
        (OUT / subdir).mkdir(parents=True, exist_ok=True)
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10, 'text.color': base.INK,
                         'axes.labelcolor': base.INK, 'xtick.color': base.INK, 'ytick.color': base.INK,
                         'hatch.linewidth': .4, 'svg.hashsalt': 'vf-bgc-typebars-only-20260925',
                         'pdf.fonttype': 42})
    data = base.load_data()
    base.export(combined(data))
    base.export(pair(data))
    for domain in ['VF', 'BGC']:
        base.export(individual_dataset(domain, data))
    for domain, kind, panel in [('VF', 'binary', 'C'), ('VF', 'subtype', 'D'),
                                ('BGC', 'binary', 'E'), ('BGC', 'subtype', 'F'),
                                ('VF', 'type', 'G'), ('BGC', 'type', 'H')]:
        base.export(base.individual_result(domain, data, kind, panel))
    assert all(base.sha(Path(p)) == digest for p, digest in base.HASHES.items())
    base.AUDIT.update({'source_files_unmodified': True, 'source_sha256': base.HASHES,
                       'all_original_results_preserved': True,
                       'AB_contains_only_functional_type_count_bars': True,
                       'AB_shared_x_scale': [0, 11000],
                       'binary_average': 'positive class', 'subtype_average': 'weighted',
                       'type_heatmap_average': 'macro', 'original_files_preserved': True,
                       'panels': {'A': 'VF type sequence counts', 'B': 'BGC type sequence counts',
                                  'C': 'VF binary', 'D': 'VF weighted subtype', 'E': 'BGC binary',
                                  'F': 'BGC weighted subtype', 'G': 'VF type', 'H': 'BGC type'}})
    (OUT / 'verification.json').write_text(json.dumps(base.AUDIT, indent=2, ensure_ascii=False), encoding='utf-8')
    for name in ['redraw_vf_bgc_typebars_only_20260925.py', 'redraw_vf_bgc_datasets_no_umap_20260925.py',
                 'redraw_vf_bgc_weighted_a4_20260925.py']:
        shutil.copy2(ROOT / name, OUT / 'code' / name)


if __name__ == '__main__':
    main()
