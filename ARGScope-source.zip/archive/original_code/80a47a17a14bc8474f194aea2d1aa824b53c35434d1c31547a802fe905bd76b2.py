# -*- coding: utf-8 -*-
"""
Infer type-level predictions from subtype-level prediction results,
then calculate type-level ACC, Precision, Recall, F1, MCC.

Input:
    subtype_predictions_all_DNA.csv

Required columns:
    Type
    Subtype
    Pred_Subtype

Output:
    DNA_type_overall_metrics_from_subtype.csv
    DNA_type_metrics_by_class_from_subtype.csv
    DNA_type_predictions_from_subtype.csv
    DNA_subtype_to_type_mapping.csv
    DNA_ambiguous_subtype_type_mapping.csv
"""

import os
import re
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    confusion_matrix,
)


# =========================================================
# 1. CONFIG
# =========================================================

INPUT_FILE = "subtype_predictions_all_DNA.csv"

OUT_OVERALL = "DNA_type_overall_metrics_from_subtype.csv"
OUT_BY_CLASS = "DNA_type_metrics_by_class_from_subtype.csv"
OUT_PRED = "DNA_type_predictions_from_subtype.csv"
OUT_MAPPING = "DNA_subtype_to_type_mapping.csv"
OUT_AMBIGUOUS = "DNA_ambiguous_subtype_type_mapping.csv"

ROUND_N = 4


# =========================================================
# 2. NORMALIZATION
# =========================================================

def normalize_label(x):
    if pd.isna(x):
        return np.nan

    s = str(x).strip()

    if s == "":
        return np.nan

    s_low = s.lower()
    s_low = s_low.replace("-", "_").replace(" ", "_")
    s_low = re.sub(r"__+", "_", s_low)

    alias_map = {
        "non_arg": "nonARG",
        "nonarg": "nonARG",
        "non_arg_": "nonARG",
        "non-arg": "nonARG",

        "mls": "MLS",
        "macrolide_lincosamide_streptogramin": "MLS",
        "macrolides_lincosamides_streptogramines": "MLS",

        "beta_lactam": "beta_lactam",
        "betalactam": "beta_lactam",
        "betalactams": "beta_lactam",
        "beta_lactams": "beta_lactam",

        "multi_drug": "multidrug",
        "multi_drug_resistance": "multidrug",
        "multidrug": "multidrug",

        "aminoglycosides": "aminoglycoside",
        "aminoglycoside": "aminoglycoside",

        "aminocoumarins": "aminocoumarin",
        "aminocoumarin": "aminocoumarin",

        "quinolones": "quinolone",
        "quinolone": "quinolone",

        "polymyxins": "polymyxin",
        "polymyxin": "polymyxin",

        "trimethoprims": "trimethoprim",
        "trimethoprim": "trimethoprim",

        "glycopeptide": "glycopeptide",
        "glycopeptides": "glycopeptide",
        "vancomycin": "glycopeptide",
    }

    return alias_map.get(s_low, s_low)


# =========================================================
# 3. READ DATA
# =========================================================

df = pd.read_csv(INPUT_FILE, encoding="utf-8-sig")
df.columns = [str(c).replace("\ufeff", "").strip() for c in df.columns]

required_cols = ["Type", "Subtype", "Pred_Subtype"]
missing = [c for c in required_cols if c not in df.columns]

if missing:
    raise ValueError(
        f"输入文件缺少必要列: {missing}\n"
        f"当前列名: {list(df.columns)}"
    )

df = df.copy()

df["True_Type"] = df["Type"].apply(normalize_label)
df["True_Subtype"] = df["Subtype"].apply(normalize_label)
df["Pred_Subtype_norm"] = df["Pred_Subtype"].apply(normalize_label)

df = df.dropna(subset=["True_Type", "True_Subtype", "Pred_Subtype_norm"]).copy()

print("============================================================")
print("Input summary")
print("============================================================")
print(f"Rows after removing NA: {len(df)}")
print(f"True type count:        {df['True_Type'].nunique()}")
print(f"True subtype count:     {df['True_Subtype'].nunique()}")
print(f"Pred subtype count:     {df['Pred_Subtype_norm'].nunique()}")


# =========================================================
# 4. BUILD SUBTYPE -> TYPE MAPPING
# =========================================================
# 如果一个 subtype 对应多个 type，取出现次数最多的 type。

mapping_counts = (
    df.groupby(["True_Subtype", "True_Type"])
    .size()
    .reset_index(name="count")
)

mapping_counts = mapping_counts.sort_values(
    by=["True_Subtype", "count"],
    ascending=[True, False]
)

subtype_to_type = (
    mapping_counts
    .drop_duplicates(subset=["True_Subtype"], keep="first")
    .rename(columns={"True_Subtype": "Subtype", "True_Type": "Mapped_Type"})
    [["Subtype", "Mapped_Type", "count"]]
)

# 统计一个 subtype 是否对应多个 type
ambiguous = (
    mapping_counts
    .groupby("True_Subtype")["True_Type"]
    .nunique()
    .reset_index(name="n_types")
)

ambiguous = ambiguous[ambiguous["n_types"] > 1].copy()

ambiguous_detail = mapping_counts[
    mapping_counts["True_Subtype"].isin(ambiguous["True_Subtype"])
].copy()

subtype_to_type.to_csv(OUT_MAPPING, index=False, encoding="utf-8-sig")
ambiguous_detail.to_csv(OUT_AMBIGUOUS, index=False, encoding="utf-8-sig")

print("\n============================================================")
print("Subtype-to-type mapping")
print("============================================================")
print(f"Mapping rows: {len(subtype_to_type)}")
print(f"Ambiguous subtype count: {ambiguous['True_Subtype'].nunique()}")

if len(ambiguous_detail) > 0:
    print(f"Ambiguous mapping saved to: {OUT_AMBIGUOUS}")


# =========================================================
# 5. INFER PREDICTED TYPE
# =========================================================

map_dict = dict(zip(subtype_to_type["Subtype"], subtype_to_type["Mapped_Type"]))

df["Pred_Type"] = df["Pred_Subtype_norm"].map(map_dict)

unmapped = df[df["Pred_Type"].isna()].copy()

print("\n============================================================")
print("Predicted type inference")
print("============================================================")
print(f"Rows with unmapped Pred_Subtype: {len(unmapped)}")

if len(unmapped) > 0:
    print("Warning: some Pred_Subtype values cannot be mapped to Type.")
    print("They will be removed before metric calculation.")
    print(unmapped["Pred_Subtype_norm"].value_counts().head(20))

df_eval = df.dropna(subset=["Pred_Type"]).copy()

print(f"Rows used for type-level evaluation: {len(df_eval)}")


# =========================================================
# 6. OVERALL TYPE-LEVEL METRICS
# =========================================================

y_true = df_eval["True_Type"].astype(str).values
y_pred = df_eval["Pred_Type"].astype(str).values

overall_metrics = {
    "n_samples": len(df_eval),
    "n_true_types": len(set(y_true)),
    "n_pred_types": len(set(y_pred)),
    "acc": accuracy_score(y_true, y_pred),
    "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
    "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
    "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
    "precision_weighted": precision_score(y_true, y_pred, average="weighted", zero_division=0),
    "recall_weighted": recall_score(y_true, y_pred, average="weighted", zero_division=0),
    "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
    "mcc": matthews_corrcoef(y_true, y_pred),
}

overall_df = pd.DataFrame([overall_metrics])

metric_cols_overall = [
    "acc",
    "precision_macro",
    "recall_macro",
    "f1_macro",
    "precision_weighted",
    "recall_weighted",
    "f1_weighted",
    "mcc",
]

overall_df[metric_cols_overall] = overall_df[metric_cols_overall].round(ROUND_N)


# =========================================================
# 7. TYPE-LEVEL ONE-VS-REST METRICS
# =========================================================

all_types = sorted(set(y_true) | set(y_pred))

rows = []

for label in all_types:
    y_true_bin = (y_true == label).astype(int)
    y_pred_bin = (y_pred == label).astype(int)

    support = int(y_true_bin.sum())
    pred_count = int(y_pred_bin.sum())
    correct = int(((y_true == label) & (y_pred == label)).sum())

    acc = accuracy_score(y_true_bin, y_pred_bin)
    precision = precision_score(y_true_bin, y_pred_bin, zero_division=0)
    recall = recall_score(y_true_bin, y_pred_bin, zero_division=0)
    f1 = f1_score(y_true_bin, y_pred_bin, zero_division=0)
    mcc = matthews_corrcoef(y_true_bin, y_pred_bin)

    rows.append({
        "label": label,
        "support": support,
        "pred_count": pred_count,
        "correct": correct,
        "acc": acc,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "mcc": mcc,
    })

type_metrics_df = pd.DataFrame(rows)

metric_cols_type = ["acc", "precision", "recall", "f1", "mcc"]
type_metrics_df[metric_cols_type] = type_metrics_df[metric_cols_type].round(ROUND_N)

type_metrics_df = type_metrics_df.sort_values(
    by=["support", "label"],
    ascending=[False, True]
).reset_index(drop=True)


# =========================================================
# 8. SAVE PREDICTIONS
# =========================================================

save_cols = [
    "KEY",
    "True_Type",
    "True_Subtype",
    "Pred_Subtype_norm",
    "Pred_Type",
]

for optional_col in ["subtype_confidence", "subtype_margin", "Subtype_correct"]:
    if optional_col in df_eval.columns:
        save_cols.append(optional_col)

save_cols = [c for c in save_cols if c in df_eval.columns]

pred_out = df_eval[save_cols].copy()
pred_out["Type_correct"] = pred_out["True_Type"] == pred_out["Pred_Type"]


# =========================================================
# 9. SAVE OUTPUTS
# =========================================================

overall_df.to_csv(OUT_OVERALL, index=False, encoding="utf-8-sig")
type_metrics_df.to_csv(OUT_BY_CLASS, index=False, encoding="utf-8-sig")
pred_out.to_csv(OUT_PRED, index=False, encoding="utf-8-sig")

print("\n============================================================")
print("Overall type-level metrics")
print("============================================================")
print(overall_df.to_string(index=False))

print("\n============================================================")
print("Type-level metrics by class")
print("============================================================")
print(type_metrics_df.to_string(index=False))

print("\n============================================================")
print("Saved files")
print("============================================================")
print(OUT_OVERALL)
print(OUT_BY_CLASS)
print(OUT_PRED)
print(OUT_MAPPING)
print(OUT_AMBIGUOUS)