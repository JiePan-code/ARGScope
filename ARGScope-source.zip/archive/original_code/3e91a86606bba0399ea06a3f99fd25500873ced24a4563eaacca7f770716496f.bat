@echo off
setlocal
chcp 65001 >nul
set "PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
pushd "%~dp0"
if not exist "%PY%" goto missing_python

"%PY%" -u "ablations\wo_gate\01_fusion_wo_gate.py"
if errorlevel 1 goto failed
"%PY%" -u "ablations\wo_gate\02_raw_prototypes_wo_gate.py"
if errorlevel 1 goto failed
"%PY%" -u "ablations\wo_gate\03_refine_gat_wo_gate.py"
if errorlevel 1 goto failed
"%PY%" -u "ablations\wo_gate\04_protein_student_wo_gate.py"
if errorlevel 1 goto failed
"%PY%" -u "ablations\wo_gate\05_dna_student_wo_gate.py"
if errorlevel 1 goto failed

echo.
echo W/O ADAPTIVE GATING COMPLETED.
pause
exit /b 0

:missing_python
echo Python not found: %PY%
pause
exit /b 2

:failed
echo.
echo W/O ADAPTIVE GATING STOPPED AFTER AN ERROR.
pause
exit /b 1
