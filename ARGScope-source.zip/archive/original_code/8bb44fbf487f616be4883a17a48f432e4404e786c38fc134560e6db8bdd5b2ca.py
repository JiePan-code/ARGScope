#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Supervised gated fusion of paired 50-aa protein and 150-nt DNA embeddings.

The external train/test assignment is read from
``all_arg_nonarg_train_test_split.csv``. The test split is never used for
normalization, optimization, early stopping, or model selection. A grouped
validation subset is derived only from the external training originals.

Supervision target: Subtype (``nonARG`` is one Subtype class).

The five simulated fragments originating from one full-length sequence always
inherit the same split through ``Original.SARG.Seq.ID``. Exactly one final PT
is written. No checkpoint, CSV, JSON, prediction table, or plot is produced.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
import os
import random
import re
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset


SCRIPT_DIR = Path(__file__).resolve().parent

# =============================================================================
# ARG:nonARG = 1:30, 50aa/150nt paths
#
# Expected layout:
#
# noveldataset130/
# ├── 1.train_supervised_gated_fusion_50aa_150nt_ARG1_nonARG30_GPU.py
# ├── ARG1_nonARG30/
# │   ├── all_arg_nonarg_train_test_split.csv
# │   └── paired_simulated_fragments_5parts/
# │       └── fixed_50aa_150nt/
# │           └── structure_50aa_150nt_5parts.txt
# ├── ESM2_650M_official_mean_protein_embeddings/
# │   └── fixed_50aa_150nt/
# │       └── fixed_50aa_150nt_protein_esm2_t33_650M_official_mean.pt
# └── DNABERT2_CLS_768_embeddings/
#     └── fixed_50aa_150nt/
#         └── fixed_50aa_150nt_chunk_000001_dnabert2_CLS.pt
# =============================================================================

DEFAULT_PROTEIN_PT = (
    SCRIPT_DIR
    / "ESM2_650M_official_mean_protein_embeddings"
    / "fixed_50aa_150nt"
    / "fixed_50aa_150nt_protein_esm2_t33_650M_official_mean.pt"
)

DEFAULT_DNA_PT = (
    SCRIPT_DIR
    / "DNABERT2_CLS_768_embeddings"
    / "fixed_50aa_150nt"
)

DEFAULT_FRAGMENT_STRUCTURE = (
    SCRIPT_DIR
    / "ARG1_nonARG30"
    / "paired_simulated_fragments_5parts"
    / "fixed_50aa_150nt"
    / "structure_50aa_150nt_5parts.txt"
)

DEFAULT_BASE_SPLIT = (
    SCRIPT_DIR
    / "ARG1_nonARG30"
    / "all_arg_nonarg_train_test_split.csv"
)

DEFAULT_OUTPUT_PT = (
    SCRIPT_DIR
    / "Gated_fusion_ARG1_nonARG30_50aa_150nt_supervised"
    / "all_50aa_150nt_supervised_gated_fused_embeddings.pt"
)

SCRIPT_VERSION = "2026-08-20-supervised-subtype-gated-fusion-ARG1-nonARG30-GPU-multichunk-v2"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Subtype-supervised gated fusion of ESM-2 and DNABERT-2 PTs."
    )
    parser.add_argument("--protein-pt", type=Path, default=DEFAULT_PROTEIN_PT)
    parser.add_argument("--dna-pt", type=Path, default=DEFAULT_DNA_PT)
    parser.add_argument(
        "--fragment-structure", type=Path, default=DEFAULT_FRAGMENT_STRUCTURE
    )
    parser.add_argument("--base-split", type=Path, default=DEFAULT_BASE_SPLIT)
    parser.add_argument("--output-pt", type=Path, default=DEFAULT_OUTPUT_PT)
    parser.add_argument("--fusion-dim", type=int, default=512)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--dropout", type=float, default=0.20)
    parser.add_argument("--label-smoothing", type=float, default=0.05)
    parser.add_argument(
        "--validation-fraction",
        type=float,
        default=0.15,
        help="Fraction taken from external train originals within each Subtype.",
    )
    parser.add_argument("--seed", type=int, default=20260817)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def canonical_id(value: object) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def normalized_label(value: object) -> str:
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return "nonARG"
    compact = re.sub(r"[^a-z0-9]", "", text.lower())
    if compact in {"nonarg", "nonresistance", "negative", "nonresistant"}:
        return "nonARG"
    return text


def stable_seed(seed: int, label: str) -> int:
    payload = f"{seed}\0{label}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def torch_load_cpu(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def _load_one_embedding_pt(path: Path, expected_dim: int):
    obj = torch_load_cpu(path)

    if not isinstance(obj, dict) or "ids" not in obj or "embeddings" not in obj:
        raise KeyError(
            f"PT must contain 'ids' and 'embeddings': {path}"
        )

    ids = [
        canonical_id(value)
        for value
        in obj["ids"]
    ]

    embeddings = obj["embeddings"]

    if any(not value for value in ids):
        raise ValueError(
            f"Empty ID found in PT: {path}"
        )

    duplicate_count = len(ids) - len(set(ids))

    if duplicate_count:
        raise ValueError(
            f"Duplicate IDs inside {path}: {duplicate_count}"
        )

    if not isinstance(embeddings, torch.Tensor) or embeddings.ndim != 2:
        raise ValueError(
            f"Embeddings must be a 2D tensor: {path}"
        )

    if tuple(embeddings.shape) != (len(ids), expected_dim):
        raise ValueError(
            f"Unexpected embedding shape in {path}: "
            f"{tuple(embeddings.shape)}; "
            f"expected ({len(ids)}, {expected_dim})"
        )

    embeddings = (
        embeddings
        .detach()
        .cpu()
        .float()
        .contiguous()
    )

    if not bool(torch.isfinite(embeddings).all()):
        raise ValueError(
            f"Non-finite values detected in embeddings: {path}"
        )

    return ids, embeddings


def load_embedding_pt(path: Path, expected_dim: int):
    """
    Load either:
      1) one embedding PT, or
      2) a directory containing DNABERT-2 CLS chunk PTs.

    For the current 150nt ARG1:nonARG30 dataset, the expected files are:
        dna_150nt_5parts_chunk_000001_dnabert2_CLS.pt
        dna_150nt_5parts_chunk_000002_dnabert2_CLS.pt

    All chunks are concatenated in filename-sorted order.
    IDs must be globally unique.
    """

    if path.is_file():
        print(
            f"Loading one DNA embedding PT: {path}",
            flush=True,
        )
        return _load_one_embedding_pt(
            path,
            expected_dim,
        )

    if not path.is_dir():
        raise FileNotFoundError(
            f"Embedding input is neither a file nor directory: {path}"
        )

    preferred_pattern = "dna_150nt_5parts_chunk_*_dnabert2_CLS.pt"

    chunk_paths = sorted(
        p
        for p
        in path.glob(preferred_pattern)
        if p.is_file()
    )

    if not chunk_paths:
        # Defensive fallback in case the prefix changes but the extraction
        # format remains the same.
        chunk_paths = sorted(
            p
            for p
            in path.glob("*_dnabert2_CLS.pt")
            if p.is_file()
        )

    if not chunk_paths:
        raise FileNotFoundError(
            f"No DNABERT-2 CLS PT chunks found in: {path}"
        )

    print(
        f"DNA embedding directory : {path}",
        flush=True,
    )
    print(
        f"DNA PT chunks discovered: {len(chunk_paths):,}",
        flush=True,
    )

    all_ids = []
    embedding_parts = []
    seen_ids = set()

    for index, chunk_path in enumerate(
        chunk_paths,
        start=1,
    ):
        ids, embeddings = _load_one_embedding_pt(
            chunk_path,
            expected_dim,
        )

        duplicate_across_chunks = [
            seq_id
            for seq_id
            in ids
            if seq_id
            in seen_ids
        ]

        if duplicate_across_chunks:
            raise ValueError(
                "Duplicate DNA IDs across embedding chunks. "
                f"Chunk={chunk_path}; "
                f"examples={duplicate_across_chunks[:10]}"
            )

        seen_ids.update(ids)
        all_ids.extend(ids)
        embedding_parts.append(embeddings)

        print(
            f"  [{index}/{len(chunk_paths)}] "
            f"{chunk_path.name} | "
            f"rows={len(ids):,} | "
            f"shape={tuple(embeddings.shape)}",
            flush=True,
        )

    combined = torch.cat(
        embedding_parts,
        dim=0,
    ).contiguous()

    if combined.shape != (
        len(all_ids),
        expected_dim,
    ):
        raise RuntimeError(
            "Combined DNA embedding shape mismatch: "
            f"{tuple(combined.shape)} vs "
            f"({len(all_ids)}, {expected_dim})"
        )

    print(
        f"Combined DNA embeddings: {tuple(combined.shape)}",
        flush=True,
    )

    return all_ids, combined


def read_fragment_structure(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames:
            raise ValueError(f"Fragment structure has no header: {path}")
        required = {"SARG.Seq.ID", "Subtype"}
        missing = sorted(required - set(reader.fieldnames))
        if missing:
            raise ValueError(f"Fragment structure missing columns: {missing}")
        original_column = (
            "Original.SARG.Seq.ID"
            if "Original.SARG.Seq.ID" in reader.fieldnames
            else None
        )
        rows: dict[str, dict[str, str]] = {}
        for line_number, raw in enumerate(reader, start=2):
            fragment_id = canonical_id(raw.get("SARG.Seq.ID", ""))
            if not fragment_id:
                raise ValueError(f"Empty fragment ID at line {line_number}")
            if fragment_id in rows:
                raise ValueError(f"Duplicate fragment ID: {fragment_id}")
            original_id = (
                canonical_id(raw.get(original_column, ""))
                if original_column
                else ""
            )
            if not original_id:
                original_id = re.sub(r"__SIM_.*$", "", fragment_id)
            subtype = normalized_label(raw.get("Subtype", ""))
            rows[fragment_id] = {
                "original_id": original_id,
                "subtype": subtype,
            }
    if not rows:
        raise ValueError(f"Fragment structure contains no rows: {path}")
    return rows


def read_base_split(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"Base split file has no header: {path}")
        required = {"SARG.Seq.ID", "Subtype", "Split"}
        missing = sorted(required - set(reader.fieldnames))
        if missing:
            raise ValueError(f"Base split file missing columns: {missing}")
        result: dict[str, dict[str, str]] = {}
        for line_number, raw in enumerate(reader, start=2):
            original_id = canonical_id(raw.get("SARG.Seq.ID", ""))
            subtype = normalized_label(raw.get("Subtype", ""))
            split = str(raw.get("Split", "")).strip().lower()
            if split not in {"train", "test"}:
                raise ValueError(
                    f"Invalid Split at line {line_number}: {split!r}; "
                    "expected train or test"
                )
            if not original_id:
                raise ValueError(f"Empty base ID at line {line_number}")
            if original_id in result:
                raise ValueError(f"Duplicate base ID in split file: {original_id}")
            result[original_id] = {"subtype": subtype, "split": split}
    if not result:
        raise ValueError(f"Base split file contains no rows: {path}")
    return result


def align_all_inputs(
    protein_pt: Path,
    dna_pt: Path,
    fragment_structure_path: Path,
    base_split_path: Path,
):
    protein_ids, protein = load_embedding_pt(protein_pt, expected_dim=1280)
    dna_ids, dna_raw = load_embedding_pt(dna_pt, expected_dim=768)
    fragment_rows = read_fragment_structure(fragment_structure_path)
    base_split = read_base_split(base_split_path)

    protein_set = set(protein_ids)
    dna_set = set(dna_ids)
    structure_set = set(fragment_rows)
    if protein_set != dna_set or protein_set != structure_set:
        raise ValueError(
            "Protein/DNA/fragment-structure ID sets differ: "
            f"protein={len(protein_set)}, DNA={len(dna_set)}, "
            f"structure={len(structure_set)}, "
            f"protein_without_DNA={len(protein_set-dna_set)}, "
            f"protein_without_structure={len(protein_set-structure_set)}"
        )

    dna_index = {seq_id: index for index, seq_id in enumerate(dna_ids)}
    dna_order = torch.tensor([dna_index[seq_id] for seq_id in protein_ids])
    dna = dna_raw.index_select(0, dna_order).contiguous()

    original_ids: list[str] = []
    subtypes: list[str] = []
    external_splits: list[str] = []
    missing_base_ids = []
    subtype_mismatches = []
    for fragment_id in protein_ids:
        fragment = fragment_rows[fragment_id]
        original_id = fragment["original_id"]
        split_record = base_split.get(original_id)
        if split_record is None:
            missing_base_ids.append(original_id)
            continue
        if fragment["subtype"] != split_record["subtype"]:
            subtype_mismatches.append(
                (original_id, fragment["subtype"], split_record["subtype"])
            )
        original_ids.append(original_id)
        subtypes.append(split_record["subtype"])
        external_splits.append(split_record["split"])

    if missing_base_ids:
        unique = sorted(set(missing_base_ids))
        raise ValueError(
            f"{len(unique)} original IDs are absent from base split; examples={unique[:10]}"
        )
    if subtype_mismatches:
        raise ValueError(
            f"Subtype mismatch between fragment structure and base split: "
            f"count={len(subtype_mismatches)}, examples={subtype_mismatches[:5]}"
        )

    used_base_ids = set(original_ids)
    extra_split_ids = set(base_split) - used_base_ids
    if extra_split_ids:
        print(
            f"WARNING: {len(extra_split_ids):,} split IDs have no 50aa fragment and "
            "will not be included.",
            flush=True,
        )

    # Every fragment from the same original must have one label and one split.
    original_audit: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for original_id, subtype, split in zip(original_ids, subtypes, external_splits):
        original_audit[original_id].add((subtype, split))
    inconsistent = [key for key, values in original_audit.items() if len(values) != 1]
    if inconsistent:
        raise ValueError(f"Inconsistent fragment metadata: {inconsistent[:10]}")

    del dna_raw
    print(f"Paired fragments       : {len(protein_ids):,}", flush=True)
    print(f"Unique original IDs    : {len(set(original_ids)):,}", flush=True)
    print(f"Unique Subtypes        : {len(set(subtypes)):,}", flush=True)
    print(f"Protein shape          : {tuple(protein.shape)}", flush=True)
    print(f"DNA shape              : {tuple(dna.shape)}", flush=True)
    print("Protein/DNA IDs aligned: True", flush=True)
    print("Base split inherited   : True", flush=True)

    expected_fragments = 1_605_175
    expected_originals = 321_035

    if len(protein_ids) != expected_fragments:
        raise ValueError(
            f"Unexpected 1:30 50aa/150nt fragment count: "
            f"{len(protein_ids):,}; expected {expected_fragments:,}"
        )

    if len(set(original_ids)) != expected_originals:
        raise ValueError(
            f"Unexpected 1:30 original count: "
            f"{len(set(original_ids)):,}; expected {expected_originals:,}"
        )

    print(
        f"ARG1:nonARG30 count audit: "
        f"{expected_originals:,} originals / "
        f"{expected_fragments:,} fragments confirmed",
        flush=True,
    )

    return (
        protein_ids,
        original_ids,
        subtypes,
        external_splits,
        protein,
        dna,
    )


def derive_internal_validation(
    original_ids: list[str],
    subtypes: list[str],
    external_splits: list[str],
    validation_fraction: float,
    seed: int,
) -> list[str]:
    """Derive validation only from external train originals, grouped by ID."""
    original_metadata: dict[str, tuple[str, str]] = {}
    for original_id, subtype, split in zip(original_ids, subtypes, external_splits):
        current = (subtype, split)
        previous = original_metadata.setdefault(original_id, current)
        if previous != current:
            raise ValueError(f"Conflicting metadata for Original_ID={original_id}")

    train_groups: dict[str, list[str]] = defaultdict(list)
    for original_id, (subtype, split) in original_metadata.items():
        if split == "train":
            train_groups[subtype].append(original_id)

    all_subtypes = sorted(set(subtypes))
    missing_train = sorted(set(all_subtypes) - set(train_groups))
    if missing_train:
        raise ValueError(f"Subtypes absent from external train: {missing_train[:20]}")

    validation_ids: set[str] = set()
    for subtype in sorted(train_groups):
        group_ids = list(train_groups[subtype])
        if len(group_ids) < 2:
            raise ValueError(
                f"Subtype {subtype!r} has only {len(group_ids)} external train "
                "original(s); at least 2 are required for train/validation."
            )
        # Preserve the user's 2-train/1-test rule for Subtypes with only three
        # originals: when external train contains exactly two originals, both
        # remain optimization-training samples and none is taken for validation.
        if len(group_ids) == 2:
            continue
        rng = random.Random(stable_seed(seed, subtype))
        rng.shuffle(group_ids)
        number_validation = int(
            math.floor(len(group_ids) * validation_fraction + 0.5)
        )
        number_validation = max(1, min(number_validation, len(group_ids) - 2))
        validation_ids.update(group_ids[:number_validation])

    model_splits = []
    for original_id, external_split in zip(original_ids, external_splits):
        if external_split == "test":
            model_splits.append("test")
        elif original_id in validation_ids:
            model_splits.append("validation")
        else:
            model_splits.append("train")

    # Leakage checks at original-ID level.
    split_to_originals = {
        name: {
            original_id
            for original_id, split in zip(original_ids, model_splits)
            if split == name
        }
        for name in ("train", "validation", "test")
    }
    if (
        split_to_originals["train"] & split_to_originals["validation"]
        or split_to_originals["train"] & split_to_originals["test"]
        or split_to_originals["validation"] & split_to_originals["test"]
    ):
        raise RuntimeError("Original-ID leakage detected across model splits")

    for name in ("train", "test"):
        observed = {
            subtype
            for subtype, split in zip(subtypes, model_splits)
            if split == name
        }
        missing = set(all_subtypes) - observed
        if missing:
            raise ValueError(f"Subtypes absent from {name}: {sorted(missing)[:20]}")
    if "validation" not in model_splits:
        raise ValueError("No validation originals could be derived from external train")
    return model_splits


class PairedDataset(Dataset):
    def __init__(self, protein, dna, targets, indices):
        self.protein = protein
        self.dna = dna
        self.targets = targets
        self.indices = torch.as_tensor(indices, dtype=torch.long)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, item):
        index = self.indices[item]
        return self.protein[index], self.dna[index], self.targets[index]


class SupervisedGatedFusion(nn.Module):
    def __init__(
        self,
        protein_dim: int,
        dna_dim: int,
        fusion_dim: int,
        number_subtypes: int,
        dropout: float,
        protein_mean: torch.Tensor,
        protein_std: torch.Tensor,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
    ):
        super().__init__()
        self.register_buffer("protein_mean", protein_mean)
        self.register_buffer("protein_std", protein_std)
        self.register_buffer("dna_mean", dna_mean)
        self.register_buffer("dna_std", dna_std)
        self.protein_projection = nn.Sequential(
            nn.Linear(protein_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.dna_projection = nn.Sequential(
            nn.Linear(dna_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.gate = nn.Sequential(
            nn.Linear(fusion_dim * 2, fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_dim, fusion_dim),
            nn.Sigmoid(),
        )
        self.fusion_norm = nn.LayerNorm(fusion_dim)
        self.subtype_classifier = nn.Linear(fusion_dim, number_subtypes)

    def standardize(self, protein, dna):
        return (
            (protein - self.protein_mean) / self.protein_std,
            (dna - self.dna_mean) / self.dna_std,
        )

    def encode(self, protein, dna):
        protein, dna = self.standardize(protein, dna)
        protein_projected = self.protein_projection(protein)
        dna_projected = self.dna_projection(dna)
        gate = self.gate(torch.cat([protein_projected, dna_projected], dim=1))
        fused = self.fusion_norm(
            gate * protein_projected + (1.0 - gate) * dna_projected
        )
        return fused, gate

    def forward(self, protein, dna):
        fused, gate = self.encode(protein, dna)
        return self.subtype_classifier(fused), fused, gate


def make_loader(dataset, batch_size, shuffle, num_workers, pin_memory):
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=False,
    )


def calculate_class_weights(targets: torch.Tensor, number_classes: int):
    counts = torch.bincount(targets, minlength=number_classes).float()
    if bool((counts == 0).any()):
        missing = torch.where(counts == 0)[0].tolist()
        raise ValueError(f"Classes absent from model train: {missing[:20]}")
    # Inverse square-root weighting limits domination by the very large nonARG class.
    weights = counts.rsqrt()
    return weights / weights.mean()


def classification_metrics(
    true_values: np.ndarray,
    predicted_values: np.ndarray,
    number_classes: int,
) -> dict[str, float | int]:
    confusion = np.zeros((number_classes, number_classes), dtype=np.int64)
    np.add.at(confusion, (true_values, predicted_values), 1)
    tp = np.diag(confusion).astype(np.float64)
    support = confusion.sum(axis=1).astype(np.float64)
    predicted_count = confusion.sum(axis=0).astype(np.float64)
    precision = np.divide(
        tp, predicted_count, out=np.zeros_like(tp), where=predicted_count != 0
    )
    recall = np.divide(tp, support, out=np.zeros_like(tp), where=support != 0)
    f1 = np.divide(
        2.0 * precision * recall,
        precision + recall,
        out=np.zeros_like(tp),
        where=(precision + recall) != 0,
    )
    total = float(confusion.sum())
    accuracy = float(tp.sum() / total) if total else 0.0
    weights = support / total if total else np.zeros_like(support)

    # Multiclass Matthews correlation coefficient from the confusion matrix.
    correct = float(np.trace(confusion))
    predicted_marginal = confusion.sum(axis=0).astype(np.float64)
    true_marginal = confusion.sum(axis=1).astype(np.float64)
    numerator = correct * total - float(np.dot(predicted_marginal, true_marginal))
    denominator = math.sqrt(
        max(total * total - float(np.dot(predicted_marginal, predicted_marginal)), 0.0)
        * max(total * total - float(np.dot(true_marginal, true_marginal)), 0.0)
    )
    mcc = numerator / denominator if denominator > 0 else 0.0
    active = support > 0
    return {
        "accuracy": accuracy,
        "macro_precision": float(precision[active].mean()),
        "macro_recall": float(recall[active].mean()),
        "macro_f1": float(f1[active].mean()),
        "weighted_precision": float(np.sum(precision * weights)),
        "weighted_recall": float(np.sum(recall * weights)),
        "weighted_f1": float(np.sum(f1 * weights)),
        "mcc": float(mcc),
        "support": int(total),
    }


@torch.no_grad()
def evaluate(model, loader, criterion, device, use_amp, number_classes):
    model.eval()
    total_loss = 0.0
    total_count = 0
    all_true = []
    all_predicted = []
    for protein, dna, target in loader:
        protein = protein.to(device, non_blocking=True)
        dna = dna.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        with torch.autocast(
            device_type=device.type, dtype=torch.float16, enabled=use_amp
        ):
            logits, _, _ = model(protein, dna)
            loss = criterion(logits, target)
        count = target.shape[0]
        total_loss += float(loss.item()) * count
        total_count += count
        all_true.extend(target.cpu().tolist())
        all_predicted.extend(logits.argmax(dim=1).cpu().tolist())
    result = classification_metrics(
        np.asarray(all_true, dtype=np.int64),
        np.asarray(all_predicted, dtype=np.int64),
        number_classes,
    )
    result["loss"] = total_loss / max(total_count, 1)
    return result


@torch.no_grad()
def generate_all_fused(model, protein, dna, device, batch_size, use_amp):
    model.eval()
    number = protein.shape[0]
    fusion_dim = model.subtype_classifier.in_features
    fused_all = torch.empty((number, fusion_dim), dtype=torch.float32)
    protein_gate_mean = torch.empty(number, dtype=torch.float32)
    for start in range(0, number, batch_size):
        end = min(start + batch_size, number)
        protein_batch = protein[start:end].to(device, non_blocking=True)
        dna_batch = dna[start:end].to(device, non_blocking=True)
        with torch.autocast(
            device_type=device.type, dtype=torch.float16, enabled=use_amp
        ):
            fused, gate = model.encode(protein_batch, dna_batch)
        fused_all[start:end] = fused.float().cpu()
        protein_gate_mean[start:end] = gate.float().mean(dim=1).cpu()
    return fused_all.contiguous(), protein_gate_mean


def main() -> None:
    args = parse_args()
    required_file_inputs = (
        (args.protein_pt, "Protein PT"),
        (args.fragment_structure, "Fragment structure"),
        (args.base_split, "Base train/test split"),
    )

    missing_inputs = [
        (description, path)
        for path, description
        in required_file_inputs
        if not path.is_file()
    ]

    if not (
        args.dna_pt.is_file()
        or args.dna_pt.is_dir()
    ):
        missing_inputs.append(
            ("DNA PT / DNA chunk directory", args.dna_pt)
        )

    if missing_inputs:
        lines = ["Required ARG1:nonARG30 Fusion input(s) are missing:"]
        for description, path in missing_inputs:
            lines.append(f"  - {description}: {path}")

        if any(
            description == "Base train/test split"
            for description, _ in missing_inputs
        ):
            lines.extend(
                [
                    "",
                    "The Fusion step requires the ORIGINAL-SEQUENCE train/test split file:",
                    f"  {DEFAULT_BASE_SPLIT}",
                    "",
                    "Do not split the 5 simulated fragments directly.",
                    "All fragments from the same Original.SARG.Seq.ID must inherit the same split.",
                ]
            )

        raise FileNotFoundError("\n".join(lines))
    if args.output_pt.exists() and not args.overwrite:
        raise FileExistsError(
            f"Output already exists: {args.output_pt}\nUse --overwrite to replace it."
        )
    if not 0.0 < args.validation_fraction < 0.5:
        raise ValueError("--validation-fraction must be between 0 and 0.5")
    if args.fusion_dim < 1 or args.batch_size < 1 or args.epochs < 1:
        raise ValueError("Fusion dimension, batch size and epochs must be positive")

    set_seed(args.seed)

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU is unavailable. CPU fallback is disabled for this ARGScope Fusion training script."
        )

    device = torch.device("cuda:0")
    use_amp = not args.no_amp
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    args.output_pt.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 110, flush=True)
    print("ARG1:nonARG30 Subtype-supervised gated fusion: ESM-2 50aa + DNABERT-2 150nt CLS", flush=True)
    print("=" * 110, flush=True)
    print(f"Script version     : {SCRIPT_VERSION}", flush=True)
    print(f"Protein PT         : {args.protein_pt}", flush=True)
    print(f"DNA PT/dir         : {args.dna_pt}", flush=True)
    print(f"Fragment structure : {args.fragment_structure}", flush=True)
    print(f"Base train/test    : {args.base_split}", flush=True)
    print(f"Output PT          : {args.output_pt}", flush=True)
    print("ARG:nonARG dataset : 1:30", flush=True)
    print("Protein input      : ESM-2 official mean, 1280D", flush=True)
    print("DNA input          : DNABERT-2 first_token_CLS, 768D", flush=True)
    print("Fusion output      : 512D (default)", flush=True)
    print(f"Device             : {device}", flush=True)
    print(f"GPU                : {torch.cuda.get_device_name(0)}", flush=True)
    print(f"CUDA version       : {torch.version.cuda}", flush=True)
    print(f"AMP                : {use_amp}", flush=True)
    print("CPU fallback       : disabled", flush=True)

    (
        ids,
        original_ids,
        subtypes,
        external_splits,
        protein,
        dna,
    ) = align_all_inputs(
        args.protein_pt,
        args.dna_pt,
        args.fragment_structure,
        args.base_split,
    )

    model_splits = derive_internal_validation(
        original_ids,
        subtypes,
        external_splits,
        args.validation_fraction,
        args.seed,
    )
    split_indices = {
        name: np.flatnonzero(np.asarray(model_splits, dtype=object) == name)
        for name in ("train", "validation", "test")
    }
    print("\n===== LEAKAGE-FREE SPLITS =====", flush=True)
    for name, indices in split_indices.items():
        unique_originals = len({original_ids[i] for i in indices})
        unique_subtypes = len({subtypes[i] for i in indices})
        print(
            f"{name:10s}: fragments={len(indices):,}, "
            f"originals={unique_originals:,}, Subtypes={unique_subtypes:,}",
            flush=True,
        )

    # Build the label map from model train only. Test labels cannot create classes.
    train_subtypes = sorted({subtypes[i] for i in split_indices["train"]})
    if "nonARG" in train_subtypes:
        train_subtypes.remove("nonARG")
        train_subtypes.insert(0, "nonARG")
    subtype_to_index = {label: index for index, label in enumerate(train_subtypes)}
    unseen = sorted(set(subtypes) - set(subtype_to_index))
    if unseen:
        raise ValueError(f"Validation/test contain unseen Subtypes: {unseen[:20]}")
    targets = torch.tensor(
        [subtype_to_index[label] for label in subtypes], dtype=torch.long
    )

    # Fit normalization only on model-train fragments.
    train_tensor = torch.as_tensor(split_indices["train"], dtype=torch.long)
    protein_train = protein.index_select(0, train_tensor)
    dna_train = dna.index_select(0, train_tensor)
    protein_mean = protein_train.mean(dim=0)
    protein_std = protein_train.std(dim=0, unbiased=False).clamp_min(1e-6)
    dna_mean = dna_train.mean(dim=0)
    dna_std = dna_train.std(dim=0, unbiased=False).clamp_min(1e-6)
    del protein_train, dna_train

    datasets = {
        name: PairedDataset(protein, dna, targets, indices)
        for name, indices in split_indices.items()
    }
    loaders = {
        name: make_loader(
            dataset,
            batch_size=args.batch_size,
            shuffle=(name == "train"),
            num_workers=args.num_workers,
            pin_memory=device.type == "cuda",
        )
        for name, dataset in datasets.items()
    }

    model = SupervisedGatedFusion(
        protein_dim=protein.shape[1],
        dna_dim=dna.shape[1],
        fusion_dim=args.fusion_dim,
        number_subtypes=len(subtype_to_index),
        dropout=args.dropout,
        protein_mean=protein_mean,
        protein_std=protein_std,
        dna_mean=dna_mean,
        dna_std=dna_std,
    ).to(device)
    train_targets = targets.index_select(0, train_tensor)
    class_weights = calculate_class_weights(
        train_targets, len(subtype_to_index)
    ).to(device)
    criterion = nn.CrossEntropyLoss(
        weight=class_weights,
        label_smoothing=args.label_smoothing,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=4, min_lr=1e-6
    )
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

    best_score = -math.inf
    best_epoch = -1
    best_state = None
    epochs_without_improvement = 0
    started = time.time()

    print("\n===== TRAIN SUBTYPE-SUPERVISED GATE =====", flush=True)
    for epoch in range(1, args.epochs + 1):
        model.train()
        train_loss_sum = 0.0
        train_count = 0
        for protein_batch, dna_batch, target_batch in loaders["train"]:
            protein_batch = protein_batch.to(device, non_blocking=True)
            dna_batch = dna_batch.to(device, non_blocking=True)
            target_batch = target_batch.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(
                device_type=device.type, dtype=torch.float16, enabled=use_amp
            ):
                logits, _, _ = model(protein_batch, dna_batch)
                loss = criterion(logits, target_batch)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            count = target_batch.shape[0]
            train_loss_sum += float(loss.item()) * count
            train_count += count

        validation_metrics = evaluate(
            model,
            loaders["validation"],
            criterion,
            device,
            use_amp,
            len(subtype_to_index),
        )
        train_loss = train_loss_sum / max(train_count, 1)
        validation_score = float(validation_metrics["macro_f1"])
        scheduler.step(validation_score)
        current_lr = optimizer.param_groups[0]["lr"]
        print(
            f"Epoch {epoch:03d} | train_loss={train_loss:.6f} | "
            f"val_loss={validation_metrics['loss']:.6f} | "
            f"val_ACC={validation_metrics['accuracy']:.4f} | "
            f"val_macro_F1={validation_score:.4f} | lr={current_lr:.2e}",
            flush=True,
        )
        if validation_score > best_score + 1e-6:
            best_score = validation_score
            best_epoch = epoch
            epochs_without_improvement = 0
            best_state = {
                name: tensor.detach().cpu().clone()
                for name, tensor in model.state_dict().items()
            }
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.patience:
                print(f"Early stopping at epoch {epoch}", flush=True)
                break

    if best_state is None:
        raise RuntimeError("Training did not produce a valid best model")
    model.load_state_dict(best_state)
    model.to(device)

    # The external test is evaluated only after training/model selection is complete.
    final_metrics = {
        name: evaluate(
            model,
            loaders[name],
            criterion,
            device,
            use_amp,
            len(subtype_to_index),
        )
        for name in ("train", "validation", "test")
    }
    fused_embeddings, protein_gate_mean = generate_all_fused(
        model,
        protein,
        dna,
        device,
        args.batch_size,
        use_amp,
    )

    output = {
        "ids": ids,
        "original_ids": original_ids,
        "embeddings": fused_embeddings,
        "splits": external_splits,
        "model_splits": model_splits,
        "subtypes": subtypes,
        "subtype_to_index": subtype_to_index,
        "gate_mean_protein_weight": protein_gate_mean,
        "gate_mean_DNA_weight": 1.0 - protein_gate_mean,
        "fusion_method": "Subtype-supervised gated fusion",
        "fusion_formula": "gate*protein_projection + (1-gate)*DNA_projection",
        "protein_input_dimension": int(protein.shape[1]),
        "DNA_input_dimension": int(dna.shape[1]),
        "embedding_dimension": int(fused_embeddings.shape[1]),
        "num_fragments": len(ids),
        "num_original_sequences": len(set(original_ids)),
        "num_subtypes": len(subtype_to_index),
        "best_epoch": int(best_epoch),
        "best_validation_macro_f1": float(best_score),
        "metrics": final_metrics,
        "source_protein_pt": str(args.protein_pt),
        "source_DNA_pt": str(args.dna_pt),
        "source_fragment_structure": str(args.fragment_structure),
        "source_base_split": str(args.base_split),
        "script_version": SCRIPT_VERSION,
        "ARG_nonARG_dataset_ratio": "1:30",
    }
    temporary_path = args.output_pt.with_suffix(args.output_pt.suffix + ".tmp")
    torch.save(output, temporary_path)
    os.replace(temporary_path, args.output_pt)

    print("\n" + "=" * 110, flush=True)
    print("SUPERVISED GATED FUSION COMPLETED", flush=True)
    print("=" * 110, flush=True)
    print(f"Best epoch                  : {best_epoch}", flush=True)
    print(f"Best validation macro F1    : {best_score:.6f}", flush=True)
    print(f"Test accuracy               : {final_metrics['test']['accuracy']:.6f}", flush=True)
    print(f"Test macro F1               : {final_metrics['test']['macro_f1']:.6f}", flush=True)
    print(f"Test MCC                    : {final_metrics['test']['mcc']:.6f}", flush=True)
    print(f"Fused embedding shape       : {tuple(fused_embeddings.shape)}", flush=True)
    print(f"Mean protein gate weight    : {protein_gate_mean.mean().item():.6f}", flush=True)
    print(f"Mean DNA gate weight        : {(1.0-protein_gate_mean.mean()).item():.6f}", flush=True)
    print(f"Only output file            : {args.output_pt}", flush=True)
    print(f"Elapsed minutes             : {(time.time()-started)/60.0:.3f}", flush=True)


if __name__ == "__main__":
    main()
