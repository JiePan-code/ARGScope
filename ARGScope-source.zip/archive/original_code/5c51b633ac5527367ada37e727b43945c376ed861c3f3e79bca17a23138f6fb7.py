#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查 NCBI 补齐后仍缺少 DNA 的 protein 对各 subtype 的影响。

输入：
1. 筛选后的 protein structure（默认 10,779 条、492 个 subtype）。
2. SARG_still_missing_DNA_proteins.csv（默认 315 条）。
3. 可选的 SARG_still_missing_DNA_proteins.fasta。

输出：
- 每个 subtype 的天然 DNA protein 覆盖情况；
- 完全没有 DNA 的 subtype；
- 有 DNA 但少于指定最低数量的 subtype；
- 需要继续 tblastn/人工处理的关键 protein CSV 和 FASTA。

只使用 Python 标准库，可直接在 PyCharm 运行。
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


# =============================================================================
# 只需要修改这里
# =============================================================================
# 如果脚本放在 SARG_missing_DNA_NCBI_retrieval 文件夹内，structure 通常在上一级。
PROTEIN_STRUCTURE = "../SARG_protein_subtype_ge3_structure.txt"
STILL_MISSING_CSV = "SARG_still_missing_DNA_proteins.csv"
STILL_MISSING_FASTA = "SARG_still_missing_DNA_proteins.fasta"

# 判断某个 subtype 剩余天然 DNA 是否足够的最低 protein 数。
MIN_DNA_PROTEINS_PER_SUBTYPE = 3

OUTPUT_DIR = "remaining_DNA_subtype_coverage"


SCRIPT_DIR = Path(__file__).resolve().parent


def resolve_required_file(value: str, description: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(
            f"找不到 {description}：\n{path}\n"
            "请修改代码顶部对应的文件路径。"
        )
    return path


def resolve_optional_file(value: str) -> Path | None:
    value = value.strip()
    if not value:
        return None
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    return path if path.is_file() else None


def read_tsv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        required = {"SARG.Seq.ID", "Type", "Subtype"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{path.name} 缺少列：{sorted(missing)}")
        rows = list(reader)
    return rows


def read_missing_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        required = {"protein_id", "Type", "Subtype", "status", "failure_reason"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{path.name} 缺少列：{sorted(missing)}")
        rows = list(reader)
    return rows


def read_fasta(path: Path):
    order = []
    records = {}
    current_id = None
    header = ""
    chunks = []

    def save():
        nonlocal current_id, header, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"FASTA 存在重复 ID：{current_id}")
        records[current_id] = (header, "".join(chunks).replace(" ", ""))
        order.append(current_id)

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_no, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                save()
                header = line[1:].strip()
                if not header:
                    raise ValueError(f"{path.name} 第 {line_no} 行 FASTA 标题为空")
                current_id = header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(f"{path.name} 第 {line_no} 行在标题前出现序列")
                chunks.append(line)
        save()
    return order, records


def wrap_sequence(sequence: str, width: int = 80):
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def write_csv(path: Path, fieldnames, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main():
    if MIN_DNA_PROTEINS_PER_SUBTYPE < 1:
        raise ValueError("MIN_DNA_PROTEINS_PER_SUBTYPE 必须大于等于 1")

    structure_path = resolve_required_file(PROTEIN_STRUCTURE, "筛选后的 protein structure")
    missing_csv_path = resolve_required_file(STILL_MISSING_CSV, "仍缺少 DNA 的 CSV")
    missing_fasta_path = resolve_optional_file(STILL_MISSING_FASTA)

    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    coverage_path = output_dir / "SARG_subtype_DNA_coverage_after_NCBI.csv"
    zero_path = output_dir / "SARG_subtypes_without_any_DNA.csv"
    below_path = output_dir / f"SARG_subtypes_with_fewer_than{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_proteins.csv"
    critical_csv_path = output_dir / "SARG_missing_proteins_in_critical_subtypes.csv"
    critical_fasta_path = output_dir / "SARG_missing_proteins_in_critical_subtypes.fasta"
    summary_path = output_dir / "SARG_remaining_DNA_subtype_coverage_summary.txt"

    print("=" * 100)
    print("Check subtype coverage after NCBI natural-CDS retrieval")
    print("=" * 100)
    print(f"Protein structure : {structure_path}")
    print(f"Still-missing CSV : {missing_csv_path}")
    print(f"Still-missing FASTA: {missing_fasta_path or 'Not provided'}")
    print(f"Output directory  : {output_dir}")

    structure_rows = read_tsv(structure_path)
    missing_rows = read_missing_csv(missing_csv_path)

    structure_by_id = {}
    subtype_total_ids = defaultdict(list)
    subtype_to_type = {}
    for row in structure_rows:
        protein_id = row["SARG.Seq.ID"].strip()
        type_name = row["Type"].strip()
        subtype = row["Subtype"].strip()
        if not protein_id or not subtype:
            raise ValueError("Protein structure 存在空 ID 或空 Subtype")
        if protein_id in structure_by_id:
            raise ValueError(f"Protein structure 存在重复 ID：{protein_id}")
        if subtype in subtype_to_type and subtype_to_type[subtype] != type_name:
            raise ValueError(
                f"同一 Subtype 对应多个 Type：{subtype} -> "
                f"{subtype_to_type[subtype]} / {type_name}"
            )
        structure_by_id[protein_id] = row
        subtype_total_ids[subtype].append(protein_id)
        subtype_to_type[subtype] = type_name

    missing_by_id = {}
    label_mismatches = []
    missing_not_in_structure = []
    for row in missing_rows:
        protein_id = row["protein_id"].strip()
        if not protein_id:
            raise ValueError("Still-missing CSV 存在空 protein_id")
        if protein_id in missing_by_id:
            raise ValueError(f"Still-missing CSV 存在重复 protein_id：{protein_id}")
        missing_by_id[protein_id] = row
        structure_row = structure_by_id.get(protein_id)
        if structure_row is None:
            missing_not_in_structure.append(protein_id)
            continue
        if (row["Type"].strip() != structure_row["Type"].strip()
                or row["Subtype"].strip() != structure_row["Subtype"].strip()):
            label_mismatches.append(protein_id)

    if missing_not_in_structure:
        raise ValueError(
            f"有 {len(missing_not_in_structure)} 个缺失 protein 不在 structure 中，例如："
            f"{missing_not_in_structure[:5]}"
        )
    if label_mismatches:
        raise ValueError(
            f"有 {len(label_mismatches)} 个 protein 的 Type/Subtype 与 structure 不一致，例如："
            f"{label_mismatches[:5]}"
        )

    missing_id_set = set(missing_by_id)
    coverage_rows = []
    for subtype, total_ids in subtype_total_ids.items():
        total_count = len(total_ids)
        missing_ids = [protein_id for protein_id in total_ids if protein_id in missing_id_set]
        missing_count = len(missing_ids)
        available_count = total_count - missing_count
        coverage_fraction = available_count / total_count if total_count else 0.0

        if available_count == 0:
            dna_status = "NO_DNA_FOR_SUBTYPE"
        elif available_count < MIN_DNA_PROTEINS_PER_SUBTYPE:
            dna_status = f"BELOW_{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_PROTEINS"
        elif missing_count == 0:
            dna_status = "COMPLETE_DNA_COVERAGE"
        else:
            dna_status = "PARTIAL_BUT_SUFFICIENT"

        failure_counts = Counter(
            missing_by_id[protein_id]["status"].strip() for protein_id in missing_ids
        )
        coverage_rows.append({
            "Type": subtype_to_type[subtype],
            "Subtype": subtype,
            "total_proteins": total_count,
            "proteins_with_natural_DNA": available_count,
            "proteins_still_missing_DNA": missing_count,
            "natural_DNA_coverage_percent": round(coverage_fraction * 100, 4),
            "DNA_status": dna_status,
            "missing_failure_status_counts": ";".join(
                f"{status}:{count}" for status, count in sorted(failure_counts.items())
            ),
            "missing_protein_ids": ";".join(missing_ids),
        })

    coverage_rows.sort(
        key=lambda row: (
            row["proteins_with_natural_DNA"],
            row["natural_DNA_coverage_percent"],
            row["Type"],
            row["Subtype"],
        )
    )
    zero_rows = [row for row in coverage_rows if row["proteins_with_natural_DNA"] == 0]
    below_rows = [
        row for row in coverage_rows
        if row["proteins_with_natural_DNA"] < MIN_DNA_PROTEINS_PER_SUBTYPE
    ]
    critical_subtypes = {row["Subtype"] for row in below_rows}
    critical_missing_rows = [
        row for row in missing_rows if row["Subtype"].strip() in critical_subtypes
    ]

    coverage_fields = [
        "Type", "Subtype", "total_proteins", "proteins_with_natural_DNA",
        "proteins_still_missing_DNA", "natural_DNA_coverage_percent",
        "DNA_status", "missing_failure_status_counts", "missing_protein_ids",
    ]
    write_csv(coverage_path, coverage_fields, coverage_rows)
    write_csv(zero_path, coverage_fields, zero_rows)
    write_csv(below_path, coverage_fields, below_rows)
    write_csv(
        critical_csv_path,
        ["protein_id", "Type", "Subtype", "status", "failure_reason"],
        critical_missing_rows,
    )

    fasta_status = "Not provided"
    critical_fasta_count = 0
    if missing_fasta_path is not None:
        fasta_order, fasta_records = read_fasta(missing_fasta_path)
        fasta_ids = set(fasta_records)
        if fasta_ids != missing_id_set:
            raise ValueError(
                "Still-missing FASTA 与 CSV ID 不一致："
                f"仅 FASTA={len(fasta_ids - missing_id_set)}，"
                f"仅 CSV={len(missing_id_set - fasta_ids)}"
            )
        critical_ids = {row["protein_id"].strip() for row in critical_missing_rows}
        with critical_fasta_path.open("w", encoding="utf-8", newline="\n") as handle:
            for protein_id in fasta_order:
                if protein_id not in critical_ids:
                    continue
                header, sequence = fasta_records[protein_id]
                handle.write(f">{header}\n{wrap_sequence(sequence)}\n")
                critical_fasta_count += 1
        if critical_fasta_count != len(critical_ids):
            raise RuntimeError("关键 subtype FASTA 写出数量与 CSV 不一致")
        fasta_status = "IDs identical"

    reason_counts = Counter(row["status"].strip() for row in missing_rows)
    subtypes_with_any_missing = sum(
        row["proteins_still_missing_DNA"] > 0 for row in coverage_rows
    )
    sufficient_subtypes = sum(
        row["proteins_with_natural_DNA"] >= MIN_DNA_PROTEINS_PER_SUBTYPE
        for row in coverage_rows
    )
    summary_lines = [
        f"retained_proteins_total\t{len(structure_rows)}",
        f"retained_subtypes_total\t{len(coverage_rows)}",
        f"proteins_with_natural_DNA\t{len(structure_rows) - len(missing_rows)}",
        f"proteins_still_missing_DNA\t{len(missing_rows)}",
        f"overall_protein_DNA_coverage_percent\t{100.0 * (len(structure_rows) - len(missing_rows)) / len(structure_rows):.4f}",
        f"subtypes_with_any_missing_protein\t{subtypes_with_any_missing}",
        f"subtypes_without_any_DNA\t{len(zero_rows)}",
        f"subtypes_with_fewer_than_{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_proteins\t{len(below_rows)}",
        f"subtypes_with_at_least_{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_proteins\t{sufficient_subtypes}",
        f"missing_proteins_in_critical_subtypes\t{len(critical_missing_rows)}",
        f"critical_subtype_FASTA_records\t{critical_fasta_count}",
        f"missing_CSV_FASTA_status\t{fasta_status}",
        "Type_Subtype_label_mismatches\t0",
    ]
    for status, count in sorted(reason_counts.items()):
        summary_lines.append(f"failure_status::{status}\t{count}")
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n" + "=" * 100)
    print("CHECK COMPLETED")
    print("=" * 100)
    print(f"Retained proteins                         : {len(structure_rows)}")
    print(f"Retained subtypes                         : {len(coverage_rows)}")
    print(f"Proteins with natural DNA                 : {len(structure_rows) - len(missing_rows)}")
    print(f"Proteins still missing DNA                : {len(missing_rows)}")
    print(f"Subtypes with no DNA                      : {len(zero_rows)}")
    print(f"Subtypes with <{MIN_DNA_PROTEINS_PER_SUBTYPE} DNA proteins             : {len(below_rows)}")
    print(f"Missing proteins in critical subtypes     : {len(critical_missing_rows)}")
    print(f"Critical-subtype FASTA records            : {critical_fasta_count}")
    print("\nOutput files:")
    for path in [coverage_path, zero_path, below_path, critical_csv_path, summary_path]:
        print(f"  {path}")
    if missing_fasta_path is not None:
        print(f"  {critical_fasta_path}")


if __name__ == "__main__":
    main()
