#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Clean publication-style Type-level grouped bar plots using ONLY 100% data.

Expected directory structure
----------------------------
script_folder/
├── plot_Type_bars_100pct_only_CLEAN.py
├── longaa/
│   ├── argnet/ARGnet_longaa.csv
│   ├── DeepARG/DeepARG_longaa.csv
│   ├── PLM-ARG/PLMARG_longaa.csv
│   ├── Fungenetyper/Fungenetyper_longaa.csv
│   └── argscope/ARGscope_longaa.csv
└── longnt/
    ├── argnet/ARGnet_longnt.csv
    ├── DeepARG/DeepARG_longnt.csv
    └── argscope/ARGscope_longnt.csv

Only the full-length row (Long AA / Long NT / 100%) is used.

Instead of five vertically stacked panels, each modality is drawn as ONE
clean grouped bar chart:
    x-axis = Accuracy, Precision, Recall, F1, MCC
    bars   = models

Outputs
-------
type_barplots_100pct_clean/
    LongAA_100pct_Type_metrics_clean.png/.tif/.pdf/.svg
    LongNT_100pct_Type_metrics_clean.png/.tif/.pdf/.svg
    Type_plot_data_100pct.csv
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm


# =============================================================================
# 1. Paths
# =============================================================================

ROOT = Path(__file__).resolve().parent
OUTDIR = ROOT / "type_barplots_100pct_clean"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODALITY_DIRS = {
    "LongAA": ROOT / "longaa",
    "LongNT": ROOT / "longnt",
}

MODEL_ORDER = {
    "LongAA": ["ARGNet", "DeepARG", "PLM-ARG", "Fungenetyper", "ARGScope"],
    "LongNT": ["ARGNet", "DeepARG", "ARGScope"],
}

MODEL_ALIASES = {
    "ARGNet": {"argnet", "argnetmodel"},
    "DeepARG": {"deeparg"},
    "PLM-ARG": {"plmarg"},
    "Fungenetyper": {"fungenetyper", "fungentyper", "fungenetypermodel"},
    "ARGScope": {"argscope"},
}

PREFERRED_FILES = {
    ("LongAA", "ARGNet"): "ARGnet_longaa.csv",
    ("LongAA", "DeepARG"): "DeepARG_longaa.csv",
    ("LongAA", "PLM-ARG"): "PLMARG_longaa.csv",
    ("LongAA", "Fungenetyper"): "Fungenetyper_longaa.csv",
    ("LongAA", "ARGScope"): "ARGscope_longaa.csv",

    ("LongNT", "ARGNet"): "ARGnet_longnt.csv",
    ("LongNT", "DeepARG"): "DeepARG_longnt.csv",
    ("LongNT", "ARGScope"): "ARGscope_longnt.csv",
}


# =============================================================================
# 2. Metrics
# =============================================================================

PLOT_METRICS = [
    ("ACC", "Accuracy"),
    ("Precision", "Precision"),
    ("Recall", "Recall"),
    ("F1", "F1"),
    ("MCC", "MCC"),
]

COLUMN_ALIASES = {
    "Class": {"class", "level", "task", "classificationlevel"},
    "ACC": {"acc", "accuracy"},
    "Precision": {
        "precision", "weightedprecision", "precisionweighted",
        "wprecision", "weightedp",
    },
    "Recall": {
        "recall", "weightedrecall", "recallweighted",
        "wrecall", "weightedr",
    },
    "F1": {
        "f1", "f1score", "weightedf1", "f1weighted",
        "wf1", "weightedf1score",
    },
    "MCC": {"mcc", "matthewscorrelationcoefficient"},
}


# =============================================================================
# 3. Visual style
# =============================================================================

FONT_FAMILY = "Arial"
FONT_BASE = 9.0
FONT_AXIS = 10.5
FONT_TICK = 9.2
FONT_LEGEND = 8.6
FONT_VALUE = 7.2

# Clean solid colors. These keep the same general model identity as your
# previous figure, but remove the visually heavy hatch patterns by default.
MODEL_FACE = {
    "ARGNet": "#E9E1D2",       # warm beige
    "DeepARG": "#E97A63",      # coral
    "PLM-ARG": "#6E6E6E",      # neutral gray
    "Fungenetyper": "#70A9D8", # blue
    "ARGScope": "#7DBF9D",     # green
}

# Optional hatch patterns. Keep False for the cleaner version.
USE_HATCH = False
MODEL_HATCH = {
    "ARGNet": "xx",
    "DeepARG": "//",
    "PLM-ARG": "\\",
    "Fungenetyper": "++",
    "ARGScope": "...",
}

BAR_EDGE = "#404040"
BAR_EDGE_WIDTH = 0.65

# Width of all bars within one metric group.
GROUP_TOTAL_WIDTH = 0.78

# Figure size for each modality.
FIG_WIDTH = 5.0
FIG_HEIGHT = 4.5

# Bar charts should normally start at zero.
YMIN = 0.0
YMAX = 1.03
YTICKS = np.arange(0.0, 1.01, 0.2)

GRID_COLOR = "#D9D9D9"
GRID_WIDTH = 0.55

# No title by default. Set True if desired.
SHOW_TITLE = False
TITLE_MAP = {
    "LongAA": "Protein (100%)",
    "LongNT": "DNA (100%)",
}

# Exact values above bars can become cluttered with 25 bars.
# Keep False for the cleanest paper figure.
SHOW_VALUES = False

# Output requirements
DPI = 600
TRANSPARENT_BG = True
SAVE_PNG = True
SAVE_TIF = True
SAVE_PDF = True
SAVE_SVG = True


# =============================================================================
# 4. Global Matplotlib settings
# =============================================================================

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": [FONT_FAMILY, "DejaVu Sans", "Liberation Sans"],
    "font.size": FONT_BASE,
    "axes.labelsize": FONT_AXIS,
    "xtick.labelsize": FONT_TICK,
    "ytick.labelsize": FONT_TICK,
    "legend.fontsize": FONT_LEGEND,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "axes.unicode_minus": False,
    "savefig.facecolor": "none" if TRANSPARENT_BG else "white",
    "savefig.edgecolor": "none" if TRANSPARENT_BG else "white",
})


def report_arial_status() -> None:
    try:
        path = fm.findfont(FONT_FAMILY, fallback_to_default=False)
        print(f"[FONT] Arial detected: {path}", flush=True)
    except Exception:
        print(
            "[FONT WARNING] Arial was not found; Matplotlib will use a fallback sans-serif font.",
            flush=True,
        )


# =============================================================================
# 5. File / column helpers
# =============================================================================

def normalized_name(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(text).lower())


def find_model_folder(base_dir: Path, model: str) -> Path | None:
    if not base_dir.is_dir():
        return None

    aliases = MODEL_ALIASES[model]
    for child in base_dir.iterdir():
        if child.is_dir() and normalized_name(child.name) in aliases:
            return child
    return None


def find_csv(modality: str, model: str, folder: Path) -> Path:
    preferred = folder / PREFERRED_FILES[(modality, model)]
    if preferred.is_file():
        return preferred

    csvs = sorted(folder.glob("*.csv"))
    if not csvs:
        raise FileNotFoundError(f"No CSV found for {modality}/{model}: {folder}")

    key = "longaa" if modality == "LongAA" else "longnt"
    matching = [p for p in csvs if key in normalized_name(p.stem)]

    if len(matching) == 1:
        return matching[0]
    if len(csvs) == 1:
        return csvs[0]

    raise RuntimeError(
        f"Cannot uniquely identify CSV for {modality}/{model}.\n"
        f"Folder: {folder}\nFiles: {[p.name for p in csvs]}"
    )


def detect_columns(df: pd.DataFrame) -> dict[str, str]:
    normalized = {normalized_name(col): col for col in df.columns}
    detected = {}

    for target, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in normalized:
                detected[target] = normalized[alias]
                break

    required = ["ACC", "Precision", "Recall", "F1", "MCC"]
    missing = [x for x in required if x not in detected]
    if missing:
        raise ValueError(
            f"Missing metric columns {missing}; found columns={list(df.columns)}"
        )

    return detected


def parse_condition(value) -> str | None:
    text = str(value).strip().lower()
    if not text or text == "nan":
        return None

    compact = normalized_name(text)

    full_tokens = {
        "longaa", "longprotein", "fulllengthaa", "fullaa",
        "longnt", "longdna", "fulllengthnt", "fullnt",
        "100", "100p", "100pct", "100percent",
    }
    if compact in full_tokens:
        return "100%"

    if re.search(r"100\s*%", text):
        return "100%"

    if (
        compact == "100"
        or compact.startswith("100pct")
        or compact.startswith("100percent")
        or compact == "100p"
        or compact.startswith("pct100")
        or compact.startswith("percent100")
    ):
        return "100%"

    return None


def detect_condition_column(df: pd.DataFrame, metric_columns: dict[str, str]) -> str:
    excluded = set(metric_columns.values())

    for col in df.columns:
        key = normalized_name(col)
        if col not in excluded and (
            key.startswith("unnamed")
            or key in {"dataset", "condition", "length", "completeness", "percent"}
        ):
            return col

    for col in df.columns:
        if col in excluded:
            continue
        if any(parse_condition(v) is not None for v in df[col].astype(str).tolist()):
            return col

    raise ValueError(f"Could not identify the 100% condition column. Columns={list(df.columns)}")


# =============================================================================
# 6. Read ONLY 100% / full-length data
# =============================================================================

def read_one_model_100pct(modality: str, model: str) -> dict:
    base_dir = MODALITY_DIRS[modality]
    folder = find_model_folder(base_dir, model)

    if folder is None:
        raise FileNotFoundError(
            f"Model folder not found: {modality}/{model}\nExpected under: {base_dir}"
        )

    csv_path = find_csv(modality, model, folder)
    df = pd.read_csv(csv_path).dropna(axis=0, how="all").copy()

    columns = detect_columns(df)
    condition_col = detect_condition_column(df, columns)

    # If a Class column exists and contains Type rows, retain only Type.
    if "Class" in columns:
        class_col = columns["Class"]
        class_text = df[class_col].astype(str).str.strip().str.lower()
        type_mask = class_text.isin({"type", "type_level", "type-level", "arg type"})
        if bool(type_mask.any()):
            df = df.loc[type_mask].copy()

    df["__condition__"] = df[condition_col].map(parse_condition)
    selected = df[df["__condition__"] == "100%"].copy()

    if selected.empty:
        raise ValueError(f"No usable 100% / full-length Type row found in {csv_path}")
    if len(selected) > 1:
        raise ValueError(f"Multiple 100% rows found in {csv_path}; please keep one Type row.")

    row = selected.iloc[0]

    record = {
        "modality": modality,
        "model": model,
        "condition": "100%",
        "source_file": str(csv_path),
    }

    for internal_name, _display_name in PLOT_METRICS:
        value = float(row[columns[internal_name]])
        if not np.isfinite(value):
            raise ValueError(f"Non-finite {internal_name} in {csv_path}")
        record[internal_name] = value

    return record


def collect_100pct_data() -> pd.DataFrame:
    rows = []

    for modality in ("LongAA", "LongNT"):
        for model in MODEL_ORDER[modality]:
            print(f"[READ] {modality:6s} | {model:12s}", flush=True)
            record = read_one_model_100pct(modality, model)
            print(f"       file={Path(record['source_file']).name}", flush=True)
            rows.append(record)

    return pd.DataFrame(rows)


# =============================================================================
# 7. Clean grouped bar chart
# =============================================================================

def add_value_label(ax, rect, value: float, color: str = "#303030") -> None:
    ax.text(
        rect.get_x() + rect.get_width() / 2,
        value + 0.012,
        f"{value:.3f}",
        ha="center",
        va="bottom",
        fontsize=FONT_VALUE,
        color=color,
        rotation=90 if value > 0.95 else 0,
        clip_on=False,
    )


def plot_clean_grouped_bars(data: pd.DataFrame, modality: str) -> None:
    models = MODEL_ORDER[modality]
    metric_keys = [x[0] for x in PLOT_METRICS]
    metric_labels = [x[1] for x in PLOT_METRICS]

    subset = data[data["modality"] == modality].copy()

    fig, ax = plt.subplots(
        figsize=(FIG_WIDTH, FIG_HEIGHT),
        facecolor="none" if TRANSPARENT_BG else "white",
    )
    ax.set_facecolor("none" if TRANSPARENT_BG else "white")

    x = np.arange(len(metric_keys), dtype=float)
    n_models = len(models)
    bar_width = GROUP_TOTAL_WIDTH / n_models
    offsets = (np.arange(n_models) - (n_models - 1) / 2.0) * bar_width

    for model_index, model in enumerate(models):
        row = subset[subset["model"] == model]
        if len(row) != 1:
            raise RuntimeError(f"Expected exactly one 100% row for {modality}/{model}; found {len(row)}")

        values = [float(row.iloc[0][metric]) for metric in metric_keys]

        bars = ax.bar(
            x + offsets[model_index],
            values,
            width=bar_width * 0.90,
            label=model,
            facecolor=MODEL_FACE[model],
            edgecolor=BAR_EDGE,
            linewidth=BAR_EDGE_WIDTH,
            hatch=MODEL_HATCH[model] if USE_HATCH else None,
            zorder=3,
        )

        if SHOW_VALUES:
            for rect, value in zip(bars, values):
                add_value_label(ax, rect, value)

    # Axes
    ax.set_xlim(-0.55, len(metric_keys) - 0.45)
    ax.set_ylim(YMIN, YMAX)
    ax.set_yticks(YTICKS)
    ax.set_ylabel("Score", fontsize=FONT_AXIS, labelpad=7)

    ax.set_xticks(x)
    ax.set_xticklabels(metric_labels, fontsize=FONT_TICK)

    # Clean Nature-style axes
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.8)
    ax.spines["bottom"].set_linewidth(0.8)
    ax.spines["left"].set_color("#555555")
    ax.spines["bottom"].set_color("#555555")

    ax.tick_params(
        axis="both",
        which="major",
        width=0.8,
        length=3.2,
        color="#555555",
        labelsize=FONT_TICK,
    )

    ax.yaxis.grid(
        True,
        color=GRID_COLOR,
        linewidth=GRID_WIDTH,
        alpha=0.65,
        zorder=0,
    )
    ax.xaxis.grid(False)
    ax.set_axisbelow(True)

    if SHOW_TITLE:
        ax.set_title(
            TITLE_MAP[modality],
            fontsize=11.5,
            fontweight="normal",
            pad=10,
        )

    # One compact legend above the plot.
    legend = ax.legend(
        loc="lower center",
        bbox_to_anchor=(0.5, 1.015),
        ncol=len(models),
        frameon=False,
        fontsize=FONT_LEGEND,
        columnspacing=1.15,
        handlelength=1.25,
        handleheight=0.8,
        handletextpad=0.42,
        borderaxespad=0.0,
    )

    for text in legend.get_texts():
        text.set_fontfamily(FONT_FAMILY)

    # Force font family on axis text for editable SVG/PDF.
    ax.xaxis.label.set_fontfamily(FONT_FAMILY)
    ax.yaxis.label.set_fontfamily(FONT_FAMILY)
    for text in ax.get_xticklabels() + ax.get_yticklabels():
        text.set_fontfamily(FONT_FAMILY)

    fig.subplots_adjust(
        left=0.105,
        right=0.985,
        bottom=0.17,
        top=0.84,
    )

    stem = OUTDIR / f"{modality}_100pct_Type_metrics_clean"

    if SAVE_PNG:
        fig.savefig(
            stem.with_suffix(".png"),
            dpi=DPI,
            transparent=TRANSPARENT_BG,
        )

    if SAVE_TIF:
        fig.savefig(
            stem.with_suffix(".tif"),
            dpi=DPI,
            transparent=TRANSPARENT_BG,
        )

    if SAVE_PDF:
        fig.savefig(
            stem.with_suffix(".pdf"),
            transparent=TRANSPARENT_BG,
        )

    if SAVE_SVG:
        fig.savefig(
            stem.with_suffix(".svg"),
            transparent=TRANSPARENT_BG,
        )

    plt.close(fig)
    print(f"[SAVE] {stem.name}.[png/tif/pdf/svg]", flush=True)


# =============================================================================
# 8. Main
# =============================================================================

def main() -> None:
    print("=" * 92)
    print("100% Type-level grouped bar plots — clean publication layout")
    print("=" * 92)
    print("Root   :", ROOT)
    print("Output :", OUTDIR)
    print("Font   :", FONT_FAMILY)
    report_arial_status()

    data = collect_100pct_data()

    # Stable output order.
    modality_rank = {"LongAA": 0, "LongNT": 1}
    model_rank = {
        modality: {model: i for i, model in enumerate(MODEL_ORDER[modality])}
        for modality in MODEL_ORDER
    }

    data["__modality_rank__"] = data["modality"].map(modality_rank)
    data["__model_rank__"] = data.apply(
        lambda row: model_rank[row["modality"]][row["model"]], axis=1
    )
    data = data.sort_values(["__modality_rank__", "__model_rank__"]).drop(
        columns=["__modality_rank__", "__model_rank__"]
    )

    data.to_csv(
        OUTDIR / "Type_plot_data_100pct.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n[100% values]")
    print(
        data[["modality", "model", "ACC", "Precision", "Recall", "F1", "MCC"]]
        .to_string(index=False)
    )

    plot_clean_grouped_bars(data, "LongAA")
    plot_clean_grouped_bars(data, "LongNT")

    print("\nDone.")


if __name__ == "__main__":
    main()
