from __future__ import annotations

import copy
import json
import math
import multiprocessing as mp
import os
import random
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset


# ============================================================================
# 1. Local configuration
# ============================================================================
BASE_DIR = Path(__file__).resolve().parent
UPSTREAM_DIR = (
    BASE_DIR
    / "ARGScope_end_to_end_fusion_refined_user_train_test_DNABERT2_ESM2"
)
OUTPUT_DIR = (
    BASE_DIR
    / "ARGScope_final_longAA_fusion_refined_user_train_test_DNABERT2_ESM2"
)

# Sequence-level trained Fusion embeddings from the upstream pipeline.
FUSION_FILE = UPSTREAM_DIR / "sequence_fusion_embeddings_512.csv"

# Verified ESM-2 protein embeddings:
# first column = id, remaining columns = exactly 1280 dimensions.
# A labelled CSV is also supported.
LONGAA_FILE = BASE_DIR / "all_arg_nonarg_protein_embeddings.txt"

# Canonical id/type/subtype table containing all reference sequences.
LABEL_FILE = BASE_DIR / "all_arg_nonarg_id_label.csv"

# The fixed user split. These files are audited against the unified split
# before any embedding is loaded or any model is trained.
TRAIN_SET_FILE = BASE_DIR / "train_set.csv"
TEST_SET_FILE = BASE_DIR / "test_set.csv"

# Unique per-ID split created from TRAIN_SET_FILE and TEST_SET_FILE by
# build_official_splits_from_user_train_test.py.
# Singleton references are assigned to train here because one ID can only have
# one official split. Their intentional train/test duplication is represented
# separately in ALL_SUBTYPE_TEST_FILE.
SPLIT_FILE = BASE_DIR / "official_data_splits.csv"

# Coverage-oriented test containing all 2,825 Subtypes. For a Subtype with
# exactly one reference sequence, the same ID is intentionally present in the
# training pool and this test file. This is the user-specified rule.
ALL_SUBTYPE_TEST_FILE = BASE_DIR / "all_subtype_test_set.csv"

# Train-core-only refined prototypes for development/early stopping.
DEV_REFINED_PROTO_FILE = (
    UPSTREAM_DIR / "evaluation_train_only_refined_subtype_prototypes_512.csv"
)

# Full adjusted-training-pool refined prototypes for final fitting.
FINAL_REFINED_PROTO_FILE = (
    UPSTREAM_DIR / "official_train_reference" / "refined_subtype_prototypes_512.csv"
)

# Hard project constraints.
EXPECTED_ROWS = 26878
EXPECTED_LONGAA_DIM = 1280
EXPECTED_SUBTYPE_COUNT = 2825
EXPECTED_TYPE_COUNT = 31
EXPECTED_FUSION_DIM = 512
EXPECTED_PROTO_DIM = 512

SEED = 42
DEVICE_MODE = "auto"  # auto / cuda / cpu

# RTX 5060 8 GB: deliberately aggressive but still conservative enough for Windows.
CLASSIFIER_BATCH_SIZE = 1536
MAPPER_BATCH_SIZE = 1024
EVAL_BATCH_SIZE = 2048
NUM_WORKERS = 0  # Windows/PyCharm stability
PIN_MEMORY = True

# Development phase: train-core -> validation early stopping.
MAX_CLASSIFIER_EPOCHS = 160
CLASSIFIER_PATIENCE = 18
CLASSIFIER_LR = 8.0e-4

MAX_MAPPER_EPOCHS = 180
MAPPER_PATIENCE = 22
MAPPER_LR = 1.2e-3

MAX_JOINT_EPOCHS = 60
JOINT_PATIENCE = 12
JOINT_LR_MAPPER = 2.5e-4
JOINT_LR_CLASSIFIER = 1.0e-4

WEIGHT_DECAY = 1.0e-4
MAX_GRAD_NORM = 2.0
LABEL_SMOOTHING = 0.02

# Loss weights.
LAMBDA_CLASSIFIER_ANCHOR = 0.35
LAMBDA_CLASSIFIER_PROTO_DELTA = 0.02

LAMBDA_MAPPER_CE = 1.00
LAMBDA_MAPPER_COSINE = 0.55
LAMBDA_MAPPER_ANCHOR = 0.35
LAMBDA_MAPPER_KL = 0.25

LAMBDA_JOINT_CE = 1.00
LAMBDA_JOINT_COSINE = 0.45
LAMBDA_JOINT_ANCHOR = 0.30
LAMBDA_JOINT_KL = 0.20
LAMBDA_JOINT_PROTO_DELTA = 0.02

# Architecture.
CLASSIFIER_ADAPTER_HIDDEN = 768
CLASSIFIER_DROPOUT = 0.12
MAX_ADAPTER_RESIDUAL = 0.50
MAX_PROTOTYPE_RESIDUAL = 0.15
LOGIT_SCALE_INIT = 30.0

MAPPER_HIDDEN_1 = 1536
MAPPER_HIDDEN_2 = 1024
MAPPER_DROPOUT = 0.12

# Runtime controls.
USE_AMP = True
USE_TORCH_COMPILE = False  # Windows torch.compile can be unstable; enable manually.
SAVE_DEVELOPMENT_CHECKPOINT = True


# ============================================================================
# 2. Utilities
# ============================================================================
@dataclass
class EpochRecord:
    stage: str
    phase: str
    epoch: int
    train_loss: float
    val_acc: float
    val_macro_f1: float
    val_weighted_f1: float
    val_mcc: float
    selection_score: float
    learning_rate: float
    elapsed_seconds: float


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = True
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = True
    torch.set_float32_matmul_precision("high")


def resolve_device(mode: str) -> torch.device:
    mode = mode.lower().strip()
    if mode == "cpu":
        return torch.device("cpu")
    if mode == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("DEVICE_MODE='cuda' but CUDA is unavailable.")
        return torch.device("cuda")
    if mode != "auto":
        raise ValueError(f"Unsupported DEVICE_MODE: {mode}")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def autocast_context(device: torch.device, amp_enabled: bool, amp_dtype: torch.dtype):
    return torch.amp.autocast(
        device_type=device.type,
        dtype=amp_dtype,
        enabled=amp_enabled and device.type == "cuda",
    )


def make_grad_scaler(device: torch.device, amp_enabled: bool, amp_dtype: torch.dtype):
    enabled = amp_enabled and device.type == "cuda" and amp_dtype == torch.float16
    return torch.amp.GradScaler("cuda", enabled=enabled)


def choose_amp_dtype(device: torch.device) -> torch.dtype:
    if device.type != "cuda":
        return torch.float32
    if hasattr(torch.cuda, "is_bf16_supported") and torch.cuda.is_bf16_supported():
        return torch.bfloat16
    return torch.float16


def get_fused_adamw_supported() -> bool:
    if not torch.cuda.is_available():
        return False
    try:
        p = torch.nn.Parameter(torch.zeros(1, device="cuda"))
        _ = torch.optim.AdamW([p], lr=1e-3, fused=True)
        return True
    except Exception:
        return False


def make_adamw(params, lr: float, weight_decay: float):
    kwargs = dict(lr=lr, weight_decay=weight_decay)
    if get_fused_adamw_supported():
        kwargs["fused"] = True
    return torch.optim.AdamW(params, **kwargs)


def canonicalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    rename = {c: str(c).replace("\ufeff", "").strip() for c in df.columns}
    return df.rename(columns=rename)


def resolve_column(df: pd.DataFrame, requested: Sequence[str], context: str) -> str:
    exact = {str(c): str(c) for c in df.columns}
    lower = {str(c).strip().lower(): str(c) for c in df.columns}
    for name in requested:
        if name in exact:
            return exact[name]
        key = str(name).strip().lower()
        if key in lower:
            return lower[key]
    raise ValueError(
        f"Cannot find any of columns {list(requested)} in {context}. "
        f"Available columns: {list(df.columns)[:20]}"
    )


def clean_text_series(series: pd.Series, name: str) -> pd.Series:
    if series.isna().any():
        raise ValueError(f"Column '{name}' contains missing values.")
    out = series.astype(str).str.strip()
    invalid = out.isin(["", "nan", "None", "NAN", "NA", "null", "NULL"])
    if invalid.any():
        examples = out[invalid].head(10).tolist()
        raise ValueError(f"Column '{name}' contains invalid labels: {examples}")
    return out


def ensure_unique(df: pd.DataFrame, key_col: str, context: str) -> None:
    dup = df[key_col].duplicated(keep=False)
    if dup.any():
        examples = df.loc[dup, key_col].head(20).tolist()
        raise ValueError(
            f"{context} contains duplicated IDs in '{key_col}'. Examples: {examples}"
        )


def natural_key(text: str):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", str(text))]


def validate_numeric_matrix(df: pd.DataFrame, cols: Sequence[str], context: str) -> np.ndarray:
    if len(cols) == 0:
        raise ValueError(f"No feature columns found in {context}.")
    numeric = df.loc[:, list(cols)].apply(pd.to_numeric, errors="coerce")
    arr = numeric.to_numpy(dtype=np.float32, copy=True)
    finite = np.isfinite(arr)
    if not finite.all():
        bad_rows, bad_cols = np.where(~finite)
        examples = [
            (int(r), str(cols[int(c)]), numeric.iloc[int(r), int(c)])
            for r, c in zip(bad_rows[:10], bad_cols[:10])
        ]
        raise ValueError(f"Invalid numeric values in {context}. Examples: {examples}")
    return arr


def l2_normalize_np(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    if np.any(norms < eps):
        bad = np.where(norms[:, 0] < eps)[0][:20].tolist()
        raise ValueError(f"Found zero-norm embeddings at rows: {bad}")
    return (x / np.maximum(norms, eps)).astype(np.float32)


def selection_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    macro = f1_score(y_true, y_pred, average="macro", zero_division=0)
    weighted = f1_score(y_true, y_pred, average="weighted", zero_division=0)
    return 0.5 * macro + 0.5 * weighted


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    result: Dict[str, float] = {
        "ACC": float(accuracy_score(y_true, y_pred)),
        "MCC": float(matthews_corrcoef(y_true, y_pred)),
        "sample_count": int(len(y_true)),
        "observed_class_count": int(len(np.unique(y_true))),
        "predicted_class_count": int(len(np.unique(y_pred))),
    }
    for average in ["micro", "macro", "weighted"]:
        result[f"{average.upper()}_PRECISION"] = float(
            precision_score(y_true, y_pred, average=average, zero_division=0)
        )
        result[f"{average.upper()}_RECALL"] = float(
            recall_score(y_true, y_pred, average=average, zero_division=0)
        )
        result[f"{average.upper()}_F1"] = float(
            f1_score(y_true, y_pred, average=average, zero_division=0)
        )
    return result


def binary_mcc(y_true: np.ndarray, y_pred: np.ndarray, class_id: int) -> float:
    yt = (y_true == class_id).astype(np.int8)
    yp = (y_pred == class_id).astype(np.int8)
    if len(np.unique(yt)) == 1 and len(np.unique(yp)) == 1:
        return 0.0
    return float(matthews_corrcoef(yt, yp))


def per_class_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
    level: str,
    split_name: str,
) -> pd.DataFrame:
    labels = np.arange(len(class_names), dtype=np.int64)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=labels,
        zero_division=0,
    )
    rows = []
    for class_id, class_name in enumerate(class_names):
        pred_count = int((y_pred == class_id).sum())
        correct_count = int(((y_true == class_id) & (y_pred == class_id)).sum())
        rows.append(
            {
                "split": split_name,
                "level": level,
                "class_id": int(class_id),
                "class_name": str(class_name),
                "support": int(support[class_id]),
                "pred_count": pred_count,
                "correct_count": correct_count,
                "PRECISION": float(precision[class_id]),
                "RECALL": float(recall[class_id]),
                "F1": float(f1[class_id]),
                "MCC_OVR": binary_mcc(y_true, y_pred, class_id),
            }
        )
    return pd.DataFrame(rows)


def save_json(obj: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def print_banner(title: str) -> None:
    print("\n" + "=" * 88)
    print(title)
    print("=" * 88)


# ============================================================================
# 3. Input loading and validation
# ============================================================================
def load_label_table(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path))
    id_col = resolve_column(df, ["id", "Geneid", "geneid"], str(path))
    type_col = resolve_column(df, ["Type", "type"], str(path))
    subtype_col = resolve_column(df, ["Subtype", "subtype"], str(path))
    out = df[[id_col, type_col, subtype_col]].copy()
    out.columns = ["id", "Type", "Subtype"]
    out["id"] = clean_text_series(out["id"], "label.id")
    out["Type"] = clean_text_series(out["Type"], "label.Type")
    out["Subtype"] = clean_text_series(out["Subtype"], "label.Subtype")
    ensure_unique(out, "id", "Label table")

    mapping_counts = out.groupby("Subtype")["Type"].nunique()
    conflicts = mapping_counts[mapping_counts > 1]
    if len(conflicts) > 0:
        raise ValueError(
            f"Found {len(conflicts)} Subtype->Type conflicts. "
            f"Examples: {conflicts.index[:20].tolist()}"
        )

    if len(out) != EXPECTED_ROWS:
        raise ValueError(
            f"Label row-count error: expected {EXPECTED_ROWS}, got {len(out)}"
        )
    if out["Subtype"].nunique() != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Subtype-count error: expected {EXPECTED_SUBTYPE_COUNT}, "
            f"got {out['Subtype'].nunique()}"
        )
    if out["Type"].nunique() != EXPECTED_TYPE_COUNT:
        raise ValueError(
            f"Type-count error: expected {EXPECTED_TYPE_COUNT}, "
            f"got {out['Type'].nunique()}"
        )

    return out


def load_split_table(path: Path, labels: pd.DataFrame) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path))
    id_col = resolve_column(df, ["id", "Geneid", "geneid"], str(path))
    split_col = resolve_column(df, ["split", "Split"], str(path))
    keep_cols = [id_col, split_col]
    for candidate in ["Type", "type", "Subtype", "subtype"]:
        if candidate in df.columns and candidate not in keep_cols:
            keep_cols.append(candidate)
    out = df[keep_cols].copy()
    out = out.rename(columns={id_col: "id", split_col: "split"})
    out["id"] = clean_text_series(out["id"], "split.id")
    out["split"] = clean_text_series(out["split"], "split.split").str.lower()
    ensure_unique(out, "id", "Split table")
    allowed = {"train", "val", "test"}
    unknown = sorted(set(out["split"]) - allowed)
    if unknown:
        raise ValueError(f"Unsupported split values: {unknown}")

    label_ids = set(labels["id"])
    split_ids = set(out["id"])
    if split_ids != label_ids:
        missing = sorted(label_ids - split_ids)
        extra = sorted(split_ids - label_ids)
        raise ValueError(
            f"Split table does not exactly cover label IDs. "
            f"Missing={len(missing)}, extra={len(extra)}. "
            f"Missing examples={missing[:10]}, extra examples={extra[:10]}"
        )

    out = out[["id", "split"]].merge(labels, on="id", how="left", validate="one_to_one")
    return out


def load_id_set(path: Path, context: str) -> set[str]:
    """Load and validate the ID column of a user-provided split file."""
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path, low_memory=False))
    id_col = resolve_column(df, ["id", "Geneid", "geneid", "KEY"], context)
    out = pd.DataFrame({"id": clean_text_series(df[id_col], f"{context}.id")})
    ensure_unique(out, "id", context)
    return set(out["id"])


def audit_fixed_user_split(
    splits: pd.DataFrame,
    coverage_test: pd.DataFrame,
    labels: pd.DataFrame,
) -> Dict[str, int]:
    """Prove that the unified split was built from the fixed train/test files.

    The complete user train set must equal unified ``train + val``. The
    unified ``test`` must contain exactly the test-only IDs. IDs intentionally
    shared by train/test must remain in ``train`` and may occur only for a
    canonically singleton Subtype.
    """
    user_train_ids = load_id_set(TRAIN_SET_FILE, "train_set.csv")
    user_test_ids = load_id_set(TEST_SET_FILE, "test_set.csv")
    overlap_ids = user_train_ids & user_test_ids
    expected_independent_ids = user_test_ids - user_train_ids

    unified_train_pool_ids = set(
        splits.loc[splits["split"].isin(["train", "val"]), "id"]
    )
    unified_test_ids = set(splits.loc[splits["split"].eq("test"), "id"])
    unified_train_core_ids = set(splits.loc[splits["split"].eq("train"), "id"])
    unified_val_ids = set(splits.loc[splits["split"].eq("val"), "id"])
    coverage_ids = set(coverage_test["id"])

    if unified_train_pool_ids != user_train_ids:
        missing = sorted(user_train_ids - unified_train_pool_ids)
        extra = sorted(unified_train_pool_ids - user_train_ids)
        raise ValueError(
            "Unified train+val does not exactly equal train_set.csv. "
            f"Missing={len(missing)}, extra={len(extra)}. "
            f"Missing examples={missing[:20]}, extra examples={extra[:20]}"
        )
    if unified_test_ids != expected_independent_ids:
        missing = sorted(expected_independent_ids - unified_test_ids)
        extra = sorted(unified_test_ids - expected_independent_ids)
        raise ValueError(
            "Unified test is not exactly the independent test-only subset. "
            f"Missing={len(missing)}, extra={len(extra)}. "
            f"Missing examples={missing[:20]}, extra examples={extra[:20]}"
        )
    if coverage_ids != user_test_ids:
        missing = sorted(user_test_ids - coverage_ids)
        extra = sorted(coverage_ids - user_test_ids)
        raise ValueError(
            "all_subtype_test_set.csv does not exactly equal test_set.csv. "
            f"Missing={len(missing)}, extra={len(extra)}. "
            f"Missing examples={missing[:20]}, extra examples={extra[:20]}"
        )
    if overlap_ids - unified_train_core_ids:
        examples = sorted(overlap_ids - unified_train_core_ids)[:20]
        raise ValueError(
            "Train/test-overlap IDs must remain in development train and must "
            f"not enter validation. Examples: {examples}"
        )
    if unified_val_ids - user_train_ids:
        examples = sorted(unified_val_ids - user_train_ids)[:20]
        raise ValueError(
            f"Validation contains IDs outside train_set.csv. Examples: {examples}"
        )

    label_index = labels.set_index("id")
    subtype_total_counts = labels.groupby("Subtype")["id"].size()
    overlap_subtypes = label_index.loc[sorted(overlap_ids), "Subtype"] if overlap_ids else []
    bad_overlap_subtypes = sorted(
        {
            subtype
            for subtype in overlap_subtypes
            if int(subtype_total_counts.loc[subtype]) != 1
        }
    )
    if bad_overlap_subtypes:
        raise ValueError(
            "Train/test overlap is allowed only for canonically singleton "
            f"Subtypes. Invalid Subtypes={len(bad_overlap_subtypes)}; "
            f"examples={bad_overlap_subtypes[:20]}"
        )

    return {
        "user_train_rows": len(user_train_ids),
        "development_train_rows": len(unified_train_core_ids),
        "internal_validation_rows": len(unified_val_ids),
        "user_test_rows": len(user_test_ids),
        "independent_test_rows": len(unified_test_ids),
        "train_test_overlap_rows": len(overlap_ids),
    }


def load_coverage_test_table(path: Path, labels: pd.DataFrame) -> pd.DataFrame:
    """Load the all-Subtype coverage test.

    The file may overlap the training pool only for singleton Subtypes. The
    overlap is intentional and is reported separately from the independent
    test metrics.
    """
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path, low_memory=False))
    id_col = resolve_column(df, ["id", "Geneid", "geneid"], str(path))
    out = df[[id_col]].copy().rename(columns={id_col: "id"})
    out["id"] = clean_text_series(out["id"], "coverage_test.id")
    ensure_unique(out, "id", "All-Subtype coverage test")

    label_ids = set(labels["id"])
    unknown = sorted(set(out["id"]) - label_ids)
    if unknown:
        raise ValueError(
            f"Coverage test contains {len(unknown)} IDs absent from labels. "
            f"Examples: {unknown[:20]}"
        )

    out = out.merge(labels, on="id", how="left", validate="one_to_one")
    if out["Subtype"].nunique() != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Coverage test contains {out['Subtype'].nunique()} Subtypes; "
            f"expected {EXPECTED_SUBTYPE_COUNT}."
        )
    return out


def load_fusion_embeddings(path: Path) -> Tuple[pd.DataFrame, List[str]]:
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path))
    id_col = resolve_column(df, ["id", "Geneid", "geneid"], str(path))
    if id_col != "id":
        df = df.rename(columns={id_col: "id"})
    df["id"] = clean_text_series(df["id"], "fusion.id")
    ensure_unique(df, "id", "Fusion embedding file")

    feature_cols = [f"fusion_{i}" for i in range(EXPECTED_FUSION_DIM)]
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Fusion file is missing {len(missing)} expected columns: {missing[:20]}")
    matrix = validate_numeric_matrix(df, feature_cols, "Fusion embeddings")

    if len(df) != EXPECTED_ROWS:
        raise ValueError(
            f"Fusion row-count error: expected {EXPECTED_ROWS}, got {len(df)}"
        )
    if matrix.shape[1] != EXPECTED_FUSION_DIM:
        raise ValueError(
            f"Fusion dimension error: expected {EXPECTED_FUSION_DIM}, "
            f"got {matrix.shape[1]}"
        )
    if np.any(np.linalg.norm(matrix, axis=1) <= 1e-12):
        raise ValueError("Fusion embeddings contain all-zero vectors")

    print(
        f"Fusion embeddings: rows={len(df)}, dim={matrix.shape[1]} "
        "[STRICT CHECK PASSED]"
    )
    return df, feature_cols


def load_longaa_embeddings(path: Path) -> Tuple[pd.DataFrame, List[str]]:
    if not path.exists():
        raise FileNotFoundError(path)

    suffix = path.suffix.lower()
    if suffix in {".txt", ".tsv"}:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            first_line = handle.readline().strip()

        if "\t" in first_line:
            separator = "\t"
            engine = "c"
            separator_name = "TAB"
        elif "," in first_line:
            separator = ","
            engine = "c"
            separator_name = "COMMA"
        else:
            separator = r"\s+"
            engine = "python"
            separator_name = "WHITESPACE"

        print(
            f"Reading verified ESM-2 protein embeddings: {path} "
            f"(separator={separator_name})"
        )
        raw = pd.read_csv(
            path,
            sep=separator,
            header=None,
            engine=engine,
        )
        if raw.shape[1] < 2:
            raise ValueError(
                f"ESM-2 protein file must contain ID + features, got {raw.shape}"
            )
        feature_cols = [f"aa_{i}" for i in range(raw.shape[1] - 1)]
        raw.columns = ["id"] + feature_cols
        df = raw
    else:
        df = canonicalize_columns(pd.read_csv(path, low_memory=False))
        id_col = resolve_column(
            df,
            ["id", "Geneid", "geneid", "ProteinID", "NucleotideID"],
            str(path),
        )
        if id_col != "id":
            df = df.rename(columns={id_col: "id"})
        excluded = {
            "id",
            "Type",
            "type",
            "Subtype",
            "subtype",
            "split",
            "Split",
            "Count",
            "subtype_index",
            "type_index",
        }
        feature_cols = [c for c in df.columns if c not in excluded]
        feature_cols = sorted(feature_cols, key=natural_key)

    df["id"] = clean_text_series(df["id"], "ESM2_protein.id")
    ensure_unique(df, "id", "ESM-2 protein embedding file")

    matrix = validate_numeric_matrix(
        df,
        feature_cols,
        "ESM-2 protein embeddings",
    )

    if len(df) != EXPECTED_ROWS:
        raise ValueError(
            f"ESM-2 protein row-count error: expected {EXPECTED_ROWS}, got {len(df)}"
        )
    if len(feature_cols) != EXPECTED_LONGAA_DIM:
        raise ValueError(
            f"ESM-2 protein dimension error: expected {EXPECTED_LONGAA_DIM}, "
            f"got {len(feature_cols)}"
        )
    if np.any(np.linalg.norm(matrix, axis=1) <= 1e-12):
        raise ValueError("ESM-2 protein embeddings contain all-zero vectors")

    print(
        f"ESM-2 protein embeddings: rows={len(df)}, "
        f"dim={len(feature_cols)} [STRICT CHECK PASSED]"
    )
    return df, feature_cols


def load_refined_prototypes(
    path: Path,
    canonical_classes: Sequence[str],
    subtype_to_type: Dict[str, str],
) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(path)
    df = canonicalize_columns(pd.read_csv(path))
    subtype_col = resolve_column(df, ["Subtype", "subtype"], str(path))
    if subtype_col != "Subtype":
        df = df.rename(columns={subtype_col: "Subtype"})
    df["Subtype"] = clean_text_series(df["Subtype"], f"{path.name}.Subtype")
    ensure_unique(df, "Subtype", f"Prototype file {path}")

    proto_cols = [f"g{i}" for i in range(EXPECTED_PROTO_DIM)]
    missing_cols = [c for c in proto_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(
            f"Prototype file {path} is missing {len(missing_cols)} g-columns: "
            f"{missing_cols[:20]}"
        )

    available = set(df["Subtype"])
    required = set(canonical_classes)
    missing_classes = sorted(required - available)
    extra_classes = sorted(available - required)
    if missing_classes or extra_classes:
        raise ValueError(
            f"Prototype class mismatch for {path}. Missing={len(missing_classes)}, "
            f"extra={len(extra_classes)}. Missing examples={missing_classes[:20]}, "
            f"extra examples={extra_classes[:20]}"
        )

    if "Type" in df.columns:
        df["Type"] = clean_text_series(df["Type"], f"{path.name}.Type")
        wrong = df[df.apply(lambda r: subtype_to_type[r["Subtype"]] != r["Type"], axis=1)]
        if len(wrong) > 0:
            raise ValueError(
                f"Prototype Type labels conflict with canonical mapping in {path}. "
                f"Examples: {wrong[['Subtype', 'Type']].head(20).to_dict('records')}"
            )

    indexed = df.set_index("Subtype").loc[list(canonical_classes)]
    matrix = validate_numeric_matrix(indexed.reset_index(), proto_cols, str(path))
    return l2_normalize_np(matrix)


def build_aligned_dataset(
    labels: pd.DataFrame,
    splits: pd.DataFrame,
    fusion_df: pd.DataFrame,
    fusion_cols: Sequence[str],
    longaa_df: pd.DataFrame,
    longaa_cols: Sequence[str],
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    base = splits[["id", "Type", "Subtype", "split"]].copy()

    fusion_ids = set(fusion_df["id"])
    longaa_ids = set(longaa_df["id"])
    required_ids = set(base["id"])
    missing_fusion = sorted(required_ids - fusion_ids)
    missing_longaa = sorted(required_ids - longaa_ids)
    extra_fusion = sorted(fusion_ids - required_ids)
    extra_longaa = sorted(longaa_ids - required_ids)

    if missing_fusion or missing_longaa or extra_fusion or extra_longaa:
        raise ValueError(
            "Embedding ID sets must exactly match the canonical split/label IDs. "
            f"Missing Fusion={len(missing_fusion)}, "
            f"missing ESM-2 protein={len(missing_longaa)}, "
            f"extra Fusion={len(extra_fusion)}, "
            f"extra ESM-2 protein={len(extra_longaa)}. "
            f"Missing Fusion examples={missing_fusion[:10]}, "
            f"missing protein examples={missing_longaa[:10]}, "
            f"extra Fusion examples={extra_fusion[:10]}, "
            f"extra protein examples={extra_longaa[:10]}"
        )

    fusion_indexed = fusion_df.set_index("id").loc[base["id"], list(fusion_cols)]
    longaa_indexed = longaa_df.set_index("id").loc[base["id"], list(longaa_cols)]

    fusion_x = validate_numeric_matrix(
        fusion_indexed.reset_index(drop=True), fusion_cols, "Aligned Fusion matrix"
    )
    longaa_x = validate_numeric_matrix(
        longaa_indexed.reset_index(drop=True), longaa_cols, "Aligned LongAA matrix"
    )
    fusion_x = l2_normalize_np(fusion_x)

    if len(base) != fusion_x.shape[0] or len(base) != longaa_x.shape[0]:
        raise RuntimeError("Aligned metadata and feature matrices have inconsistent row counts.")
    return base.reset_index(drop=True), fusion_x, longaa_x


# ============================================================================
# 4. Model definitions
# ============================================================================
class ResidualPrototypeClassifier(nn.Module):
    def __init__(
        self,
        dim: int,
        prototype_prior: np.ndarray,
        hidden_dim: int = 768,
        dropout: float = 0.12,
        max_adapter_residual: float = 0.50,
        max_prototype_residual: float = 0.15,
        logit_scale_init: float = 30.0,
    ):
        super().__init__()
        prior = torch.tensor(prototype_prior, dtype=torch.float32)
        self.register_buffer("prototype_prior", prior)
        self.prototype_delta = nn.Parameter(torch.zeros_like(prior))

        self.input_norm = nn.LayerNorm(dim)
        self.adapter = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
        )
        self.adapter_gate_raw = nn.Parameter(torch.tensor(-1.4, dtype=torch.float32))
        self.max_adapter_residual = float(max_adapter_residual)
        self.max_prototype_residual = float(max_prototype_residual)
        self.logit_scale_log = nn.Parameter(
            torch.tensor(math.log(float(logit_scale_init)), dtype=torch.float32)
        )

    def effective_prototypes(self) -> torch.Tensor:
        residual = self.max_prototype_residual * torch.tanh(self.prototype_delta)
        return F.normalize(self.prototype_prior + residual, p=2, dim=1)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        x = F.normalize(x, p=2, dim=1)
        h = self.input_norm(x)
        delta = self.adapter(h)
        gate = self.max_adapter_residual * torch.sigmoid(self.adapter_gate_raw)
        return F.normalize(x + gate * delta, p=2, dim=1)

    def forward(
        self,
        x: torch.Tensor,
        return_embedding: bool = False,
    ):
        z = self.encode(x)
        p = self.effective_prototypes()
        scale = self.logit_scale_log.exp().clamp(1.0, 100.0)
        logits = scale * (z @ p.t())
        if return_embedding:
            return logits, z, p
        return logits


class LongAAToFusionMapper(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden1: int = 1536,
        hidden2: int = 1024,
        dropout: float = 0.12,
    ):
        super().__init__()
        self.input_norm = nn.LayerNorm(input_dim)
        self.main = nn.Sequential(
            nn.Linear(input_dim, hidden1),
            nn.LayerNorm(hidden1),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2),
            nn.LayerNorm(hidden2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden2, output_dim),
        )
        self.skip = nn.Linear(input_dim, output_dim)
        self.output_norm = nn.LayerNorm(output_dim)
        self.skip_gate_raw = nn.Parameter(torch.tensor(0.0, dtype=torch.float32))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.input_norm(x)
        main = self.main(h)
        skip = self.skip(h)
        gate = torch.sigmoid(self.skip_gate_raw)
        out = self.output_norm(main + gate * skip)
        return F.normalize(out, p=2, dim=1)


# ============================================================================
# 5. Data preparation
# ============================================================================
def make_class_weights(y: np.ndarray, num_classes: int, device: torch.device) -> torch.Tensor:
    counts = np.bincount(y, minlength=num_classes).astype(np.float64)
    if np.any(counts <= 0):
        missing = np.where(counts <= 0)[0][:20].tolist()
        raise ValueError(f"Training labels do not cover all classes. Missing class IDs: {missing}")
    weights = 1.0 / np.sqrt(counts + 1.0)
    weights = weights / weights.mean()
    weights = np.clip(weights, 0.25, 4.0)
    return torch.tensor(weights, dtype=torch.float32, device=device)


def make_classifier_loader(
    fusion_x: np.ndarray,
    y: np.ndarray,
    batch_size: int,
    shuffle: bool,
) -> DataLoader:
    ds = TensorDataset(
        torch.from_numpy(fusion_x.astype(np.float32, copy=False)),
        torch.from_numpy(y.astype(np.int64, copy=False)),
    )
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY,
        persistent_workers=NUM_WORKERS > 0,
        drop_last=False,
    )


def make_mapper_loader(
    longaa_x: np.ndarray,
    fusion_x: np.ndarray,
    y: np.ndarray,
    batch_size: int,
    shuffle: bool,
) -> DataLoader:
    ds = TensorDataset(
        torch.from_numpy(longaa_x.astype(np.float32, copy=False)),
        torch.from_numpy(fusion_x.astype(np.float32, copy=False)),
        torch.from_numpy(y.astype(np.int64, copy=False)),
    )
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY,
        persistent_workers=NUM_WORKERS > 0,
        drop_last=False,
    )


# ============================================================================
# 6. Evaluation helpers
# ============================================================================
@torch.inference_mode()
def predict_classifier(
    classifier: nn.Module,
    fusion_x: np.ndarray,
    batch_size: int,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> np.ndarray:
    classifier.eval()
    loader = make_classifier_loader(
        fusion_x,
        np.zeros(len(fusion_x), dtype=np.int64),
        batch_size=batch_size,
        shuffle=False,
    )
    preds: List[np.ndarray] = []
    for xb, _ in loader:
        xb = xb.to(device, non_blocking=True)
        with autocast_context(device, amp_enabled, amp_dtype):
            logits = classifier(xb)
        preds.append(logits.argmax(dim=1).cpu().numpy())
    return np.concatenate(preds, axis=0)


@torch.inference_mode()
def predict_mapper(
    mapper: nn.Module,
    classifier: nn.Module,
    longaa_x: np.ndarray,
    batch_size: int,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
    return_mapped: bool = False,
):
    mapper.eval()
    classifier.eval()
    ds = TensorDataset(torch.from_numpy(longaa_x.astype(np.float32, copy=False)))
    loader = DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY,
        persistent_workers=NUM_WORKERS > 0,
    )
    preds: List[np.ndarray] = []
    mapped_all: List[np.ndarray] = []
    top1_all: List[np.ndarray] = []
    top2_all: List[np.ndarray] = []
    margin_all: List[np.ndarray] = []

    for (xb,) in loader:
        xb = xb.to(device, non_blocking=True)
        with autocast_context(device, amp_enabled, amp_dtype):
            mapped = mapper(xb)
            logits, z, p = classifier(mapped, return_embedding=True)
            cosine = z @ p.t()
            top2 = torch.topk(cosine, k=2, dim=1)
        preds.append(logits.argmax(dim=1).cpu().numpy())
        top1_all.append(top2.values[:, 0].float().cpu().numpy())
        top2_all.append(top2.values[:, 1].float().cpu().numpy())
        margin_all.append((top2.values[:, 0] - top2.values[:, 1]).float().cpu().numpy())
        if return_mapped:
            mapped_all.append(mapped.float().cpu().numpy())

    result = {
        "pred": np.concatenate(preds),
        "top1_cosine": np.concatenate(top1_all),
        "top2_cosine": np.concatenate(top2_all),
        "margin": np.concatenate(margin_all),
    }
    if return_mapped:
        result["mapped_fusion"] = np.concatenate(mapped_all)
    return result


def val_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    return {
        "acc": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "score": float(selection_score(y_true, y_pred)),
    }


# ============================================================================
# 7. Development training with validation
# ============================================================================
def train_classifier_dev(
    train_x: np.ndarray,
    train_y: np.ndarray,
    val_x: np.ndarray,
    val_y: np.ndarray,
    prior: np.ndarray,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> Tuple[ResidualPrototypeClassifier, int, List[EpochRecord]]:
    model = ResidualPrototypeClassifier(
        dim=train_x.shape[1],
        prototype_prior=prior,
        hidden_dim=CLASSIFIER_ADAPTER_HIDDEN,
        dropout=CLASSIFIER_DROPOUT,
        max_adapter_residual=MAX_ADAPTER_RESIDUAL,
        max_prototype_residual=MAX_PROTOTYPE_RESIDUAL,
        logit_scale_init=LOGIT_SCALE_INIT,
    ).to(device)

    if USE_TORCH_COMPILE and hasattr(torch, "compile"):
        model = torch.compile(model)

    loader = make_classifier_loader(
        train_x, train_y, CLASSIFIER_BATCH_SIZE, shuffle=True
    )
    class_weights = make_class_weights(train_y, prior.shape[0], device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = make_adamw(model.parameters(), CLASSIFIER_LR, WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=5, min_lr=1e-6
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)

    best_score = -np.inf
    best_epoch = 0
    best_state = None
    no_improve = 0
    history: List[EpochRecord] = []

    print_banner("Stage A: development Fusion classifier")
    for epoch in range(1, MAX_CLASSIFIER_EPOCHS + 1):
        start = time.time()
        model.train()
        total_loss = 0.0
        seen = 0

        for xb, yb in loader:
            xb = xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)

            with autocast_context(device, amp_enabled, amp_dtype):
                logits, z, p = model(xb, return_embedding=True)
                loss_ce = ce(logits.float(), yb)
                anchor = 1.0 - (z * model.prototype_prior[yb]).sum(dim=1)
                loss_anchor = anchor.mean()
                loss_delta = model.prototype_delta.float().pow(2).mean()
                loss = (
                    loss_ce
                    + LAMBDA_CLASSIFIER_ANCHOR * loss_anchor
                    + LAMBDA_CLASSIFIER_PROTO_DELTA * loss_delta
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), MAX_GRAD_NORM)
            scaler.step(optimizer)
            scaler.update()

            total_loss += float(loss.detach().item()) * xb.size(0)
            seen += xb.size(0)

        val_pred = predict_classifier(
            model, val_x, EVAL_BATCH_SIZE, device, amp_enabled, amp_dtype
        )
        vm = val_metrics(val_y, val_pred)
        scheduler.step(vm["score"])
        lr = float(optimizer.param_groups[0]["lr"])
        elapsed = time.time() - start
        record = EpochRecord(
            stage="classifier",
            phase="development",
            epoch=epoch,
            train_loss=total_loss / max(seen, 1),
            val_acc=vm["acc"],
            val_macro_f1=vm["macro_f1"],
            val_weighted_f1=vm["weighted_f1"],
            val_mcc=vm["mcc"],
            selection_score=vm["score"],
            learning_rate=lr,
            elapsed_seconds=elapsed,
        )
        history.append(record)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Classifier] epoch={epoch:03d} loss={record.train_loss:.4f} "
                f"val_acc={vm['acc']:.4f} val_macroF1={vm['macro_f1']:.4f} "
                f"val_weightedF1={vm['weighted_f1']:.4f} score={vm['score']:.4f} "
                f"lr={lr:.2e} time={elapsed:.1f}s"
            )

        if vm["score"] > best_score + 1e-7:
            best_score = vm["score"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= CLASSIFIER_PATIENCE:
                print(
                    f"Classifier early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, best score={best_score:.4f}"
                )
                break

    if best_state is None:
        raise RuntimeError("Classifier did not produce a valid checkpoint.")
    model.load_state_dict(best_state)
    return model, best_epoch, history


def mapper_loss_components(
    mapper: nn.Module,
    classifier: ResidualPrototypeClassifier,
    longaa: torch.Tensor,
    target_fusion: torch.Tensor,
    y: torch.Tensor,
    ce: nn.Module,
    lambda_ce: float,
    lambda_cosine: float,
    lambda_anchor: float,
    lambda_kl: float,
):
    mapped = mapper(longaa)
    logits_student, z_student, _ = classifier(mapped, return_embedding=True)
    with torch.no_grad():
        logits_teacher, _, _ = classifier(target_fusion, return_embedding=True)

    loss_ce = ce(logits_student.float(), y)
    loss_cosine = (1.0 - (mapped * target_fusion).sum(dim=1)).mean()
    prior_y = classifier.prototype_prior[y]
    loss_anchor = (1.0 - (z_student * prior_y).sum(dim=1)).mean()

    temperature = 2.0
    teacher_prob = F.softmax(logits_teacher.float() / temperature, dim=1)
    student_log_prob = F.log_softmax(logits_student.float() / temperature, dim=1)
    loss_kl = F.kl_div(student_log_prob, teacher_prob, reduction="batchmean") * (
        temperature * temperature
    )

    loss = (
        lambda_ce * loss_ce
        + lambda_cosine * loss_cosine
        + lambda_anchor * loss_anchor
        + lambda_kl * loss_kl
    )
    return loss, mapped


def train_mapper_dev(
    classifier: ResidualPrototypeClassifier,
    train_longaa: np.ndarray,
    train_fusion: np.ndarray,
    train_y: np.ndarray,
    val_longaa: np.ndarray,
    val_y: np.ndarray,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> Tuple[LongAAToFusionMapper, int, List[EpochRecord]]:
    for p in classifier.parameters():
        p.requires_grad_(False)
    classifier.eval()

    mapper = LongAAToFusionMapper(
        input_dim=train_longaa.shape[1],
        output_dim=train_fusion.shape[1],
        hidden1=MAPPER_HIDDEN_1,
        hidden2=MAPPER_HIDDEN_2,
        dropout=MAPPER_DROPOUT,
    ).to(device)

    loader = make_mapper_loader(
        train_longaa,
        train_fusion,
        train_y,
        MAPPER_BATCH_SIZE,
        shuffle=True,
    )
    class_weights = make_class_weights(train_y, classifier.prototype_prior.size(0), device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = make_adamw(mapper.parameters(), MAPPER_LR, WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=6, min_lr=1e-6
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)

    best_score = -np.inf
    best_epoch = 0
    best_state = None
    no_improve = 0
    history: List[EpochRecord] = []

    print_banner("Stage B: development LongAA -> Fusion mapper")
    for epoch in range(1, MAX_MAPPER_EPOCHS + 1):
        start = time.time()
        mapper.train()
        total_loss = 0.0
        seen = 0

        for xa, xf, yb in loader:
            xa = xa.to(device, non_blocking=True)
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)

            with autocast_context(device, amp_enabled, amp_dtype):
                loss, _ = mapper_loss_components(
                    mapper,
                    classifier,
                    xa,
                    xf,
                    yb,
                    ce,
                    LAMBDA_MAPPER_CE,
                    LAMBDA_MAPPER_COSINE,
                    LAMBDA_MAPPER_ANCHOR,
                    LAMBDA_MAPPER_KL,
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(mapper.parameters(), MAX_GRAD_NORM)
            scaler.step(optimizer)
            scaler.update()

            total_loss += float(loss.detach().item()) * xa.size(0)
            seen += xa.size(0)

        val_result = predict_mapper(
            mapper,
            classifier,
            val_longaa,
            EVAL_BATCH_SIZE,
            device,
            amp_enabled,
            amp_dtype,
        )
        vm = val_metrics(val_y, val_result["pred"])
        scheduler.step(vm["score"])
        lr = float(optimizer.param_groups[0]["lr"])
        elapsed = time.time() - start
        record = EpochRecord(
            stage="mapper",
            phase="development",
            epoch=epoch,
            train_loss=total_loss / max(seen, 1),
            val_acc=vm["acc"],
            val_macro_f1=vm["macro_f1"],
            val_weighted_f1=vm["weighted_f1"],
            val_mcc=vm["mcc"],
            selection_score=vm["score"],
            learning_rate=lr,
            elapsed_seconds=elapsed,
        )
        history.append(record)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Mapper] epoch={epoch:03d} loss={record.train_loss:.4f} "
                f"val_acc={vm['acc']:.4f} val_macroF1={vm['macro_f1']:.4f} "
                f"val_weightedF1={vm['weighted_f1']:.4f} score={vm['score']:.4f} "
                f"lr={lr:.2e} time={elapsed:.1f}s"
            )

        if vm["score"] > best_score + 1e-7:
            best_score = vm["score"]
            best_epoch = epoch
            best_state = copy.deepcopy(mapper.state_dict())
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= MAPPER_PATIENCE:
                print(
                    f"Mapper early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, best score={best_score:.4f}"
                )
                break

    if best_state is None:
        raise RuntimeError("Mapper did not produce a valid checkpoint.")
    mapper.load_state_dict(best_state)
    return mapper, best_epoch, history


def train_joint_dev(
    classifier: ResidualPrototypeClassifier,
    mapper: LongAAToFusionMapper,
    train_longaa: np.ndarray,
    train_fusion: np.ndarray,
    train_y: np.ndarray,
    val_longaa: np.ndarray,
    val_y: np.ndarray,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> Tuple[ResidualPrototypeClassifier, LongAAToFusionMapper, int, List[EpochRecord]]:
    for p in classifier.parameters():
        p.requires_grad_(True)
    classifier.train()
    mapper.train()

    loader = make_mapper_loader(
        train_longaa,
        train_fusion,
        train_y,
        MAPPER_BATCH_SIZE,
        shuffle=True,
    )
    class_weights = make_class_weights(train_y, classifier.prototype_prior.size(0), device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = torch.optim.AdamW(
        [
            {"params": mapper.parameters(), "lr": JOINT_LR_MAPPER},
            {"params": classifier.parameters(), "lr": JOINT_LR_CLASSIFIER},
        ],
        weight_decay=WEIGHT_DECAY,
        fused=get_fused_adamw_supported(),
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=4, min_lr=5e-7
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)

    best_score = -np.inf
    best_epoch = 0
    best_classifier = None
    best_mapper = None
    no_improve = 0
    history: List[EpochRecord] = []

    print_banner("Stage C: development joint fine-tuning")
    for epoch in range(1, MAX_JOINT_EPOCHS + 1):
        start = time.time()
        classifier.train()
        mapper.train()
        total_loss = 0.0
        seen = 0

        for xa, xf, yb in loader:
            xa = xa.to(device, non_blocking=True)
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)

            with autocast_context(device, amp_enabled, amp_dtype):
                loss_core, _ = mapper_loss_components(
                    mapper,
                    classifier,
                    xa,
                    xf,
                    yb,
                    ce,
                    LAMBDA_JOINT_CE,
                    LAMBDA_JOINT_COSINE,
                    LAMBDA_JOINT_ANCHOR,
                    LAMBDA_JOINT_KL,
                )
                delta_reg = classifier.prototype_delta.float().pow(2).mean()
                loss = loss_core + LAMBDA_JOINT_PROTO_DELTA * delta_reg

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                list(mapper.parameters()) + list(classifier.parameters()),
                MAX_GRAD_NORM,
            )
            scaler.step(optimizer)
            scaler.update()

            total_loss += float(loss.detach().item()) * xa.size(0)
            seen += xa.size(0)

        val_result = predict_mapper(
            mapper,
            classifier,
            val_longaa,
            EVAL_BATCH_SIZE,
            device,
            amp_enabled,
            amp_dtype,
        )
        vm = val_metrics(val_y, val_result["pred"])
        scheduler.step(vm["score"])
        lr = float(optimizer.param_groups[0]["lr"])
        elapsed = time.time() - start
        record = EpochRecord(
            stage="joint",
            phase="development",
            epoch=epoch,
            train_loss=total_loss / max(seen, 1),
            val_acc=vm["acc"],
            val_macro_f1=vm["macro_f1"],
            val_weighted_f1=vm["weighted_f1"],
            val_mcc=vm["mcc"],
            selection_score=vm["score"],
            learning_rate=lr,
            elapsed_seconds=elapsed,
        )
        history.append(record)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Joint] epoch={epoch:03d} loss={record.train_loss:.4f} "
                f"val_acc={vm['acc']:.4f} val_macroF1={vm['macro_f1']:.4f} "
                f"val_weightedF1={vm['weighted_f1']:.4f} score={vm['score']:.4f} "
                f"lr={lr:.2e} time={elapsed:.1f}s"
            )

        if vm["score"] > best_score + 1e-7:
            best_score = vm["score"]
            best_epoch = epoch
            best_classifier = copy.deepcopy(classifier.state_dict())
            best_mapper = copy.deepcopy(mapper.state_dict())
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= JOINT_PATIENCE:
                print(
                    f"Joint early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, best score={best_score:.4f}"
                )
                break

    if best_classifier is None or best_mapper is None:
        raise RuntimeError("Joint fine-tuning did not produce a valid checkpoint.")
    classifier.load_state_dict(best_classifier)
    mapper.load_state_dict(best_mapper)
    return classifier, mapper, best_epoch, history


# ============================================================================
# 8. Final fitting on train + validation using selected epochs
# ============================================================================
def train_classifier_fixed_epochs(
    train_x: np.ndarray,
    train_y: np.ndarray,
    prior: np.ndarray,
    epochs: int,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> Tuple[ResidualPrototypeClassifier, List[dict]]:
    model = ResidualPrototypeClassifier(
        dim=train_x.shape[1],
        prototype_prior=prior,
        hidden_dim=CLASSIFIER_ADAPTER_HIDDEN,
        dropout=CLASSIFIER_DROPOUT,
        max_adapter_residual=MAX_ADAPTER_RESIDUAL,
        max_prototype_residual=MAX_PROTOTYPE_RESIDUAL,
        logit_scale_init=LOGIT_SCALE_INIT,
    ).to(device)
    loader = make_classifier_loader(
        train_x, train_y, CLASSIFIER_BATCH_SIZE, shuffle=True
    )
    class_weights = make_class_weights(train_y, prior.shape[0], device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = make_adamw(model.parameters(), CLASSIFIER_LR, WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(epochs, 1), eta_min=1e-6
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)
    history: List[dict] = []

    print_banner(f"Stage D: final classifier fit on train+val for {epochs} epochs")
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        seen = 0
        for xb, yb in loader:
            xb = xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast_context(device, amp_enabled, amp_dtype):
                logits, z, _ = model(xb, return_embedding=True)
                loss_ce = ce(logits.float(), yb)
                loss_anchor = (1.0 - (z * model.prototype_prior[yb]).sum(dim=1)).mean()
                loss_delta = model.prototype_delta.float().pow(2).mean()
                loss = (
                    loss_ce
                    + LAMBDA_CLASSIFIER_ANCHOR * loss_anchor
                    + LAMBDA_CLASSIFIER_PROTO_DELTA * loss_delta
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), MAX_GRAD_NORM)
            scaler.step(optimizer)
            scaler.update()
            total_loss += float(loss.detach().item()) * xb.size(0)
            seen += xb.size(0)
        scheduler.step()
        history.append(
            {
                "stage": "classifier",
                "phase": "final_fit",
                "epoch": epoch,
                "train_loss": total_loss / max(seen, 1),
                "learning_rate": optimizer.param_groups[0]["lr"],
            }
        )
        if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
            print(
                f"[Final classifier] epoch={epoch:03d}/{epochs:03d} "
                f"loss={history[-1]['train_loss']:.4f} "
                f"lr={history[-1]['learning_rate']:.2e}"
            )
    return model, history


def train_mapper_fixed_epochs(
    classifier: ResidualPrototypeClassifier,
    train_longaa: np.ndarray,
    train_fusion: np.ndarray,
    train_y: np.ndarray,
    epochs: int,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> Tuple[LongAAToFusionMapper, List[dict]]:
    for p in classifier.parameters():
        p.requires_grad_(False)
    classifier.eval()
    mapper = LongAAToFusionMapper(
        input_dim=train_longaa.shape[1],
        output_dim=train_fusion.shape[1],
        hidden1=MAPPER_HIDDEN_1,
        hidden2=MAPPER_HIDDEN_2,
        dropout=MAPPER_DROPOUT,
    ).to(device)
    loader = make_mapper_loader(
        train_longaa,
        train_fusion,
        train_y,
        MAPPER_BATCH_SIZE,
        shuffle=True,
    )
    class_weights = make_class_weights(train_y, classifier.prototype_prior.size(0), device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = make_adamw(mapper.parameters(), MAPPER_LR, WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(epochs, 1), eta_min=1e-6
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)
    history: List[dict] = []

    print_banner(f"Stage E: final mapper fit on train+val for {epochs} epochs")
    for epoch in range(1, epochs + 1):
        mapper.train()
        total_loss = 0.0
        seen = 0
        for xa, xf, yb in loader:
            xa = xa.to(device, non_blocking=True)
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast_context(device, amp_enabled, amp_dtype):
                loss, _ = mapper_loss_components(
                    mapper,
                    classifier,
                    xa,
                    xf,
                    yb,
                    ce,
                    LAMBDA_MAPPER_CE,
                    LAMBDA_MAPPER_COSINE,
                    LAMBDA_MAPPER_ANCHOR,
                    LAMBDA_MAPPER_KL,
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(mapper.parameters(), MAX_GRAD_NORM)
            scaler.step(optimizer)
            scaler.update()
            total_loss += float(loss.detach().item()) * xa.size(0)
            seen += xa.size(0)
        scheduler.step()
        history.append(
            {
                "stage": "mapper",
                "phase": "final_fit",
                "epoch": epoch,
                "train_loss": total_loss / max(seen, 1),
                "learning_rate": optimizer.param_groups[0]["lr"],
            }
        )
        if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
            print(
                f"[Final mapper] epoch={epoch:03d}/{epochs:03d} "
                f"loss={history[-1]['train_loss']:.4f} "
                f"lr={history[-1]['learning_rate']:.2e}"
            )
    return mapper, history


def train_joint_fixed_epochs(
    classifier: ResidualPrototypeClassifier,
    mapper: LongAAToFusionMapper,
    train_longaa: np.ndarray,
    train_fusion: np.ndarray,
    train_y: np.ndarray,
    epochs: int,
    device: torch.device,
    amp_enabled: bool,
    amp_dtype: torch.dtype,
) -> List[dict]:
    if epochs <= 0:
        return []
    for p in classifier.parameters():
        p.requires_grad_(True)
    loader = make_mapper_loader(
        train_longaa,
        train_fusion,
        train_y,
        MAPPER_BATCH_SIZE,
        shuffle=True,
    )
    class_weights = make_class_weights(train_y, classifier.prototype_prior.size(0), device)
    ce = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=LABEL_SMOOTHING)
    optimizer = torch.optim.AdamW(
        [
            {"params": mapper.parameters(), "lr": JOINT_LR_MAPPER},
            {"params": classifier.parameters(), "lr": JOINT_LR_CLASSIFIER},
        ],
        weight_decay=WEIGHT_DECAY,
        fused=get_fused_adamw_supported(),
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(epochs, 1), eta_min=5e-7
    )
    scaler = make_grad_scaler(device, amp_enabled, amp_dtype)
    history: List[dict] = []

    print_banner(f"Stage F: final joint fit on train+val for {epochs} epochs")
    for epoch in range(1, epochs + 1):
        classifier.train()
        mapper.train()
        total_loss = 0.0
        seen = 0
        for xa, xf, yb in loader:
            xa = xa.to(device, non_blocking=True)
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast_context(device, amp_enabled, amp_dtype):
                loss_core, _ = mapper_loss_components(
                    mapper,
                    classifier,
                    xa,
                    xf,
                    yb,
                    ce,
                    LAMBDA_JOINT_CE,
                    LAMBDA_JOINT_COSINE,
                    LAMBDA_JOINT_ANCHOR,
                    LAMBDA_JOINT_KL,
                )
                loss = loss_core + LAMBDA_JOINT_PROTO_DELTA * (
                    classifier.prototype_delta.float().pow(2).mean()
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                list(mapper.parameters()) + list(classifier.parameters()),
                MAX_GRAD_NORM,
            )
            scaler.step(optimizer)
            scaler.update()
            total_loss += float(loss.detach().item()) * xa.size(0)
            seen += xa.size(0)
        scheduler.step()
        history.append(
            {
                "stage": "joint",
                "phase": "final_fit",
                "epoch": epoch,
                "train_loss": total_loss / max(seen, 1),
                "learning_rate_mapper": optimizer.param_groups[0]["lr"],
                "learning_rate_classifier": optimizer.param_groups[1]["lr"],
            }
        )
        if epoch == 1 or epoch % 5 == 0 or epoch == epochs:
            print(
                f"[Final joint] epoch={epoch:03d}/{epochs:03d} "
                f"loss={history[-1]['train_loss']:.4f}"
            )
    return history


# ============================================================================
# 9. Output generation
# ============================================================================
def save_adapted_prototypes(
    classifier: ResidualPrototypeClassifier,
    classes: Sequence[str],
    subtype_to_type: Dict[str, str],
    output_path: Path,
) -> None:
    classifier.eval()
    with torch.no_grad():
        matrix = classifier.effective_prototypes().float().cpu().numpy()
    df = pd.DataFrame(matrix, columns=[f"g{i}" for i in range(matrix.shape[1])])
    df.insert(0, "Type", [subtype_to_type[s] for s in classes])
    df.insert(0, "Subtype", list(classes))
    df.insert(0, "subtype_index", np.arange(len(classes), dtype=np.int64))
    df.to_csv(output_path, index=False, encoding="utf-8-sig")


def save_final_checkpoint(
    path: Path,
    classifier: ResidualPrototypeClassifier,
    mapper: LongAAToFusionMapper,
    classes: Sequence[str],
    type_classes: Sequence[str],
    subtype_to_type: Dict[str, str],
    fusion_feature_cols: Sequence[str],
    longaa_feature_cols: Sequence[str],
    longaa_scaler: StandardScaler,
    selected_epochs: Dict[str, int],
    source_files: Dict[str, str],
) -> None:
    checkpoint = {
        "format_version": 1,
        "model_name": "ARGScope_ESM2_1280_to_DNABERT2_ESM2_Fusion_with_new_Refined",
        "classifier_state_dict": classifier.state_dict(),
        "mapper_state_dict": mapper.state_dict(),
        "classes": list(classes),
        "type_classes": list(type_classes),
        "subtype_to_type": dict(subtype_to_type),
        "fusion_feature_cols": list(fusion_feature_cols),
        "longaa_feature_cols": list(longaa_feature_cols),
        "longaa_scaler_mean": longaa_scaler.mean_.astype(np.float32),
        "longaa_scaler_scale": longaa_scaler.scale_.astype(np.float32),
        "longaa_scaler_var": longaa_scaler.var_.astype(np.float32),
        "longaa_scaler_n_samples_seen": int(longaa_scaler.n_samples_seen_),
        "selected_epochs": selected_epochs,
        "source_files": source_files,
        "architecture": {
            "fusion_dim": EXPECTED_FUSION_DIM,
            "prototype_dim": EXPECTED_PROTO_DIM,
            "classifier_adapter_hidden": CLASSIFIER_ADAPTER_HIDDEN,
            "classifier_dropout": CLASSIFIER_DROPOUT,
            "max_adapter_residual": MAX_ADAPTER_RESIDUAL,
            "max_prototype_residual": MAX_PROTOTYPE_RESIDUAL,
            "mapper_input_dim": len(longaa_feature_cols),
            "verified_esm2_protein_dim": EXPECTED_LONGAA_DIM,
            "mapper_hidden_1": MAPPER_HIDDEN_1,
            "mapper_hidden_2": MAPPER_HIDDEN_2,
            "mapper_dropout": MAPPER_DROPOUT,
        },
        "training_config": {
            "seed": SEED,
            "class_count": len(classes),
            "expected_subtype_count": EXPECTED_SUBTYPE_COUNT,
            "expected_type_count": EXPECTED_TYPE_COUNT,
            "label_smoothing": LABEL_SMOOTHING,
            "weight_decay": WEIGHT_DECAY,
        },
    }
    torch.save(checkpoint, path)


# ============================================================================
# 10. Main
# ============================================================================
def main() -> None:
    seed_everything(SEED)
    device = resolve_device(DEVICE_MODE)
    amp_dtype = choose_amp_dtype(device)
    amp_enabled = bool(USE_AMP and device.type == "cuda")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print_banner("ARGScope Protein model: ESM-2 -> Fusion/Refined -> Subtype")
    print(f"Python working directory: {Path.cwd()}")
    print(f"Script directory:         {BASE_DIR}")
    print(f"Output directory:         {OUTPUT_DIR}")
    print(f"Upstream Fusion/Refined:  {UPSTREAM_DIR}")
    print(f"ESM-2 protein file:       {LONGAA_FILE}")
    print(f"Expected protein dim:     {EXPECTED_LONGAA_DIM}")
    print("Final inference input:    ESM-2 protein embedding only")
    print(f"Device:                   {device}")
    print(f"PyTorch:                  {torch.__version__}")
    print(f"AMP enabled:              {amp_enabled}")
    print(f"AMP dtype:                {amp_dtype}")
    if device.type == "cuda":
        print(f"GPU:                      {torch.cuda.get_device_name(0)}")
        print(f"CUDA:                     {torch.version.cuda}")
        props = torch.cuda.get_device_properties(0)
        print(f"GPU memory:               {props.total_memory / 1024**3:.2f} GB")

    required_upstream_files = [
        FUSION_FILE,
        DEV_REFINED_PROTO_FILE,
        FINAL_REFINED_PROTO_FILE,
    ]
    for required_path in required_upstream_files:
        if not required_path.is_file():
            raise FileNotFoundError(
                "The newly rebuilt DNABERT-2 + ESM-2 Fusion/Refined result "
                f"is incomplete. Missing: {required_path}"
            )

    required_local_files = [
        LONGAA_FILE,
        LABEL_FILE,
        TRAIN_SET_FILE,
        TEST_SET_FILE,
        SPLIT_FILE,
        ALL_SUBTYPE_TEST_FILE,
    ]
    for required_path in required_local_files:
        if not required_path.is_file():
            raise FileNotFoundError(f"Required local input is missing: {required_path}")

    labels = load_label_table(LABEL_FILE)
    splits = load_split_table(SPLIT_FILE, labels)
    coverage_test_table = load_coverage_test_table(ALL_SUBTYPE_TEST_FILE, labels)
    split_audit = audit_fixed_user_split(splits, coverage_test_table, labels)

    print_banner("Fixed user train/test split audit passed")
    for key, value in split_audit.items():
        print(f"{key:30s}: {value}")

    fusion_df, fusion_cols = load_fusion_embeddings(FUSION_FILE)
    longaa_df, longaa_cols = load_longaa_embeddings(LONGAA_FILE)

    canonical_classes = sorted(labels["Subtype"].unique().tolist())
    type_classes = sorted(labels["Type"].unique().tolist())
    subtype_to_type = (
        labels[["Subtype", "Type"]]
        .drop_duplicates()
        .set_index("Subtype")["Type"]
        .to_dict()
    )

    if len(canonical_classes) != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Canonical subtype count is {len(canonical_classes)}, expected "
            f"{EXPECTED_SUBTYPE_COUNT}."
        )
    if len(type_classes) != EXPECTED_TYPE_COUNT:
        raise ValueError(
            f"Canonical type count is {len(type_classes)}, expected {EXPECTED_TYPE_COUNT}."
        )

    class_to_id = {name: idx for idx, name in enumerate(canonical_classes)}
    type_to_id = {name: idx for idx, name in enumerate(type_classes)}

    metadata, fusion_x, longaa_x_raw = build_aligned_dataset(
        labels,
        splits,
        fusion_df,
        fusion_cols,
        longaa_df,
        longaa_cols,
    )
    y = metadata["Subtype"].map(class_to_id).to_numpy(dtype=np.int64)

    train_mask = metadata["split"].eq("train").to_numpy()
    val_mask = metadata["split"].eq("val").to_numpy()
    test_mask = metadata["split"].eq("test").to_numpy()
    full_train_mask = train_mask | val_mask

    for name, mask in [
        ("train_core", train_mask),
        ("validation", val_mask),
        ("test", test_mask),
        ("full_train_pool", full_train_mask),
    ]:
        print(
            f"{name:16s}: rows={int(mask.sum()):6d}, "
            f"Types={metadata.loc[mask, 'Type'].nunique():2d}, "
            f"Subtypes={metadata.loc[mask, 'Subtype'].nunique():4d}"
        )

    train_classes = set(metadata.loc[train_mask, "Subtype"])
    full_train_classes = set(metadata.loc[full_train_mask, "Subtype"])
    all_classes = set(canonical_classes)
    if train_classes != all_classes:
        missing = sorted(all_classes - train_classes)
        raise ValueError(
            f"train-core does not cover all {EXPECTED_SUBTYPE_COUNT} subtypes. "
            f"Missing={len(missing)}. Examples={missing[:30]}"
        )
    if full_train_classes != all_classes:
        missing = sorted(all_classes - full_train_classes)
        raise ValueError(
            f"Full adjusted training pool does not cover all subtypes. "
            f"Missing={len(missing)}. Examples={missing[:30]}"
        )

    # Neither test set is used to define model classes.
    test_unseen = set(metadata.loc[test_mask, "Subtype"]) - all_classes
    if test_unseen:
        raise ValueError(f"Test contains unknown canonical subtypes: {sorted(test_unseen)[:20]}")

    id_to_position = {seq_id: i for i, seq_id in enumerate(metadata["id"].tolist())}
    coverage_idx = np.asarray(
        [id_to_position[seq_id] for seq_id in coverage_test_table["id"].tolist()],
        dtype=np.int64,
    )
    coverage_y = y[coverage_idx]
    coverage_subtypes = set(metadata.iloc[coverage_idx]["Subtype"])
    if coverage_subtypes != all_classes:
        missing = sorted(all_classes - coverage_subtypes)
        raise ValueError(
            f"All-Subtype coverage test misses {len(missing)} classes. "
            f"Examples={missing[:20]}"
        )

    full_train_ids = set(metadata.loc[full_train_mask, "id"])
    coverage_overlap_mask = np.asarray(
        [seq_id in full_train_ids for seq_id in coverage_test_table["id"]],
        dtype=bool,
    )
    if int(coverage_overlap_mask.sum()) != split_audit["train_test_overlap_rows"]:
        raise RuntimeError(
            "Coverage-test overlap count changed after embedding alignment: "
            f"expected {split_audit['train_test_overlap_rows']}, "
            f"got {int(coverage_overlap_mask.sum())}."
        )

    print(
        f"all_subtype_test : rows={len(coverage_idx):6d}, "
        f"Types={metadata.iloc[coverage_idx]['Type'].nunique():2d}, "
        f"Subtypes={metadata.iloc[coverage_idx]['Subtype'].nunique():4d}, "
        f"train-overlap IDs={int(coverage_overlap_mask.sum()):4d}"
    )

    dev_prior = load_refined_prototypes(
        DEV_REFINED_PROTO_FILE, canonical_classes, subtype_to_type
    )
    final_prior = load_refined_prototypes(
        FINAL_REFINED_PROTO_FILE, canonical_classes, subtype_to_type
    )
    if dev_prior.shape != (EXPECTED_SUBTYPE_COUNT, EXPECTED_PROTO_DIM):
        raise ValueError(f"Unexpected development prototype shape: {dev_prior.shape}")
    if final_prior.shape != (EXPECTED_SUBTYPE_COUNT, EXPECTED_PROTO_DIM):
        raise ValueError(f"Unexpected final prototype shape: {final_prior.shape}")

    # Development scaler: train-core only.
    dev_scaler = StandardScaler()
    dev_train_longaa = dev_scaler.fit_transform(longaa_x_raw[train_mask]).astype(np.float32)
    dev_val_longaa = dev_scaler.transform(longaa_x_raw[val_mask]).astype(np.float32)

    train_fusion = fusion_x[train_mask]
    val_fusion = fusion_x[val_mask]
    train_y = y[train_mask]
    val_y = y[val_mask]

    # Development model selection.
    dev_classifier, best_classifier_epoch, history_a = train_classifier_dev(
        train_fusion,
        train_y,
        val_fusion,
        val_y,
        dev_prior,
        device,
        amp_enabled,
        amp_dtype,
    )
    dev_mapper, best_mapper_epoch, history_b = train_mapper_dev(
        dev_classifier,
        dev_train_longaa,
        train_fusion,
        train_y,
        dev_val_longaa,
        val_y,
        device,
        amp_enabled,
        amp_dtype,
    )
    dev_classifier, dev_mapper, best_joint_epoch, history_c = train_joint_dev(
        dev_classifier,
        dev_mapper,
        dev_train_longaa,
        train_fusion,
        train_y,
        dev_val_longaa,
        val_y,
        device,
        amp_enabled,
        amp_dtype,
    )

    selected_epochs = {
        "classifier": int(best_classifier_epoch),
        "mapper": int(best_mapper_epoch),
        "joint": int(best_joint_epoch),
    }
    save_json(selected_epochs, OUTPUT_DIR / "selected_epochs.json")

    dev_val_result = predict_mapper(
        dev_mapper,
        dev_classifier,
        dev_val_longaa,
        EVAL_BATCH_SIZE,
        device,
        amp_enabled,
        amp_dtype,
    )
    dev_val_metrics = compute_metrics(val_y, dev_val_result["pred"])
    print_banner("Development validation result")
    for key in ["ACC", "MACRO_F1", "WEIGHTED_F1", "MCC"]:
        print(f"{key}: {dev_val_metrics[key]:.6f}")

    if SAVE_DEVELOPMENT_CHECKPOINT:
        torch.save(
            {
                "classifier_state_dict": dev_classifier.state_dict(),
                "mapper_state_dict": dev_mapper.state_dict(),
                "longaa_scaler_mean": dev_scaler.mean_.astype(np.float32),
                "longaa_scaler_scale": dev_scaler.scale_.astype(np.float32),
                "classes": canonical_classes,
                "selected_epochs": selected_epochs,
            },
            OUTPUT_DIR / "development_best_checkpoint.pt",
        )

    # Final scaler and final fit: adjusted train pool = train + validation.
    final_scaler = StandardScaler()
    final_train_longaa = final_scaler.fit_transform(
        longaa_x_raw[full_train_mask]
    ).astype(np.float32)
    final_test_longaa = final_scaler.transform(longaa_x_raw[test_mask]).astype(np.float32)
    final_coverage_longaa = final_scaler.transform(
        longaa_x_raw[coverage_idx]
    ).astype(np.float32)
    final_train_fusion = fusion_x[full_train_mask]
    final_train_y = y[full_train_mask]
    test_y = y[test_mask]

    final_classifier, history_d = train_classifier_fixed_epochs(
        final_train_fusion,
        final_train_y,
        final_prior,
        best_classifier_epoch,
        device,
        amp_enabled,
        amp_dtype,
    )
    final_mapper, history_e = train_mapper_fixed_epochs(
        final_classifier,
        final_train_longaa,
        final_train_fusion,
        final_train_y,
        best_mapper_epoch,
        device,
        amp_enabled,
        amp_dtype,
    )
    history_f = train_joint_fixed_epochs(
        final_classifier,
        final_mapper,
        final_train_longaa,
        final_train_fusion,
        final_train_y,
        best_joint_epoch,
        device,
        amp_enabled,
        amp_dtype,
    )

    # Final evaluations: the independent non-overlap test is used for
    # generalization claims. The all-Subtype coverage test follows the
    # user-specified singleton duplication rule and demonstrates that every
    # one of the 2,825 model outputs can be evaluated.
    print_banner("Final independent non-overlap test")
    independent_result = predict_mapper(
        final_mapper,
        final_classifier,
        final_test_longaa,
        EVAL_BATCH_SIZE,
        device,
        amp_enabled,
        amp_dtype,
        return_mapped=False,
    )
    independent_pred = independent_result["pred"]

    print_banner("Final all-Subtype coverage test")
    coverage_result = predict_mapper(
        final_mapper,
        final_classifier,
        final_coverage_longaa,
        EVAL_BATCH_SIZE,
        device,
        amp_enabled,
        amp_dtype,
        return_mapped=False,
    )
    coverage_pred = coverage_result["pred"]

    def decode_evaluation(
        true_y: np.ndarray,
        pred_y: np.ndarray,
        row_positions: np.ndarray,
    ):
        subtype_metrics_local = compute_metrics(true_y, pred_y)
        pred_subtypes_local = np.array(
            [canonical_classes[i] for i in pred_y], dtype=object
        )
        true_subtypes_local = metadata.iloc[row_positions]["Subtype"].to_numpy(
            dtype=object
        )
        true_types_local = metadata.iloc[row_positions]["Type"].to_numpy(dtype=object)
        pred_types_local = np.array(
            [subtype_to_type[s] for s in pred_subtypes_local], dtype=object
        )
        true_type_ids_local = np.array(
            [type_to_id[x] for x in true_types_local], dtype=np.int64
        )
        pred_type_ids_local = np.array(
            [type_to_id[x] for x in pred_types_local], dtype=np.int64
        )
        type_metrics_local = compute_metrics(
            true_type_ids_local, pred_type_ids_local
        )
        return {
            "subtype_metrics": subtype_metrics_local,
            "type_metrics": type_metrics_local,
            "pred_subtypes": pred_subtypes_local,
            "true_subtypes": true_subtypes_local,
            "true_types": true_types_local,
            "pred_types": pred_types_local,
            "true_type_ids": true_type_ids_local,
            "pred_type_ids": pred_type_ids_local,
        }

    independent_decoded = decode_evaluation(
        test_y, independent_pred, np.where(test_mask)[0].astype(np.int64)
    )
    coverage_decoded = decode_evaluation(
        coverage_y, coverage_pred, coverage_idx
    )

    # Singleton-only metrics are explicitly labelled as non-independent.
    singleton_metrics = None
    if bool(coverage_overlap_mask.any()):
        singleton_metrics = compute_metrics(
            coverage_y[coverage_overlap_mask],
            coverage_pred[coverage_overlap_mask],
        )

    for title, decoded in [
        ("Independent", independent_decoded),
        ("All-Subtype coverage", coverage_decoded),
    ]:
        print(f"\n[{title}]")
        for key in ["ACC", "MACRO_F1", "WEIGHTED_F1", "MCC"]:
            print(f"Subtype {key}: {decoded['subtype_metrics'][key]:.6f}")
        for key in ["ACC", "MACRO_F1", "WEIGHTED_F1", "MCC"]:
            print(f"Type    {key}: {decoded['type_metrics'][key]:.6f}")
    if singleton_metrics is not None:
        print("\n[Singleton overlap subset: not independent]")
        for key in ["ACC", "MACRO_F1", "WEIGHTED_F1", "MCC"]:
            print(f"Subtype {key}: {singleton_metrics[key]:.6f}")

    def save_prediction_table(
        filename: str,
        row_positions: np.ndarray,
        result: dict,
        decoded: dict,
        overlap_flags: np.ndarray,
        evaluation_name: str,
    ) -> pd.DataFrame:
        pred_df_local = metadata.iloc[row_positions][
            ["id", "Type", "Subtype", "split"]
        ].copy()
        pred_df_local = pred_df_local.rename(
            columns={"Type": "True_Type", "Subtype": "True_Subtype"}
        )
        pred_df_local["Pred_Subtype"] = decoded["pred_subtypes"]
        pred_df_local["Pred_Type"] = decoded["pred_types"]
        pred_df_local["Subtype_Correct"] = pred_df_local["True_Subtype"].eq(
            pred_df_local["Pred_Subtype"]
        )
        pred_df_local["Type_Correct"] = pred_df_local["True_Type"].eq(
            pred_df_local["Pred_Type"]
        )
        pred_df_local["top1_cosine"] = result["top1_cosine"]
        pred_df_local["top2_cosine"] = result["top2_cosine"]
        pred_df_local["margin"] = result["margin"]
        pred_df_local["is_train_test_overlap"] = overlap_flags.astype(bool)
        pred_df_local["evaluation_name"] = evaluation_name
        pred_df_local.to_csv(
            OUTPUT_DIR / filename, index=False, encoding="utf-8-sig"
        )
        return pred_df_local

    independent_positions = np.where(test_mask)[0].astype(np.int64)
    independent_pred_df = save_prediction_table(
        "independent_test_predictions_longAA_to_fusion_refined.csv",
        independent_positions,
        independent_result,
        independent_decoded,
        np.zeros(len(independent_positions), dtype=bool),
        "independent_nonoverlap_test",
    )
    coverage_pred_df = save_prediction_table(
        "all_subtype_test_predictions_longAA_to_fusion_refined.csv",
        coverage_idx,
        coverage_result,
        coverage_decoded,
        coverage_overlap_mask,
        "all_subtype_coverage_test",
    )
    # Keep the historical filename, now pointing to the requested all-Subtype
    # coverage test rather than the smaller independent subset.
    coverage_pred_df.to_csv(
        OUTPUT_DIR / "test_predictions_longAA_to_fusion_refined.csv",
        index=False,
        encoding="utf-8-sig",
    )

    overall_rows = []
    dev_row = {"split": "validation", "level": "Subtype", "is_independent": True}
    dev_row.update(dev_val_metrics)
    overall_rows.append(dev_row)
    for split_name, decoded, independent_flag in [
        ("independent_test", independent_decoded, True),
        ("all_subtype_coverage_test", coverage_decoded, False),
    ]:
        for level, metrics in [
            ("Subtype", decoded["subtype_metrics"]),
            ("Type", decoded["type_metrics"]),
        ]:
            row = {
                "split": split_name,
                "level": level,
                "is_independent": independent_flag,
            }
            row.update(metrics)
            overall_rows.append(row)
    if singleton_metrics is not None:
        row = {
            "split": "singleton_overlap_subset",
            "level": "Subtype",
            "is_independent": False,
        }
        row.update(singleton_metrics)
        overall_rows.append(row)
    pd.DataFrame(overall_rows).to_csv(
        OUTPUT_DIR / "overall_metrics.csv", index=False, encoding="utf-8-sig"
    )

    independent_subtype_per_class = per_class_metrics(
        test_y,
        independent_pred,
        canonical_classes,
        "Subtype",
        "independent_test",
    )
    independent_subtype_per_class["Type"] = independent_subtype_per_class[
        "class_name"
    ].map(subtype_to_type)
    independent_subtype_per_class.to_csv(
        OUTPUT_DIR / "subtype_metrics_independent_test_all_2825_classes.csv",
        index=False,
        encoding="utf-8-sig",
    )

    coverage_subtype_per_class = per_class_metrics(
        coverage_y,
        coverage_pred,
        canonical_classes,
        "Subtype",
        "all_subtype_coverage_test",
    )
    coverage_subtype_per_class["Type"] = coverage_subtype_per_class[
        "class_name"
    ].map(subtype_to_type)
    coverage_subtype_per_class.to_csv(
        OUTPUT_DIR / "subtype_metrics_all_2825_classes.csv",
        index=False,
        encoding="utf-8-sig",
    )

    independent_type_per_class = per_class_metrics(
        independent_decoded["true_type_ids"],
        independent_decoded["pred_type_ids"],
        type_classes,
        "Type",
        "independent_test",
    )
    independent_type_per_class.to_csv(
        OUTPUT_DIR / "type_metrics_independent_test_all_31_classes.csv",
        index=False,
        encoding="utf-8-sig",
    )
    coverage_type_per_class = per_class_metrics(
        coverage_decoded["true_type_ids"],
        coverage_decoded["pred_type_ids"],
        type_classes,
        "Type",
        "all_subtype_coverage_test",
    )
    coverage_type_per_class.to_csv(
        OUTPUT_DIR / "type_metrics_all_31_classes.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Save histories.
    dev_history_df = pd.DataFrame([asdict(x) for x in (history_a + history_b + history_c)])
    dev_history_df.to_csv(
        OUTPUT_DIR / "development_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(history_d + history_e + history_f).to_csv(
        OUTPUT_DIR / "final_fit_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Save exact data split and class mapping used.
    metadata.to_csv(
        OUTPUT_DIR / "data_splits_used.csv", index=False, encoding="utf-8-sig"
    )
    mapping_df = pd.DataFrame(
        {
            "subtype_index": np.arange(len(canonical_classes), dtype=np.int64),
            "Subtype": canonical_classes,
            "Type": [subtype_to_type[s] for s in canonical_classes],
            "type_index": [type_to_id[subtype_to_type[s]] for s in canonical_classes],
        }
    )
    mapping_df.to_csv(
        OUTPUT_DIR / "subtype_type_label_map.csv",
        index=False,
        encoding="utf-8-sig",
    )

    save_adapted_prototypes(
        final_classifier,
        canonical_classes,
        subtype_to_type,
        OUTPUT_DIR / "final_adapted_refined_subtype_prototypes_512.csv",
    )

    source_files = {
        "fusion_file": str(FUSION_FILE.resolve()),
        "esm2_protein_file": str(LONGAA_FILE.resolve()),
        "label_file": str(LABEL_FILE.resolve()),
        "user_train_file": str(TRAIN_SET_FILE.resolve()),
        "user_test_file": str(TEST_SET_FILE.resolve()),
        "split_file": str(SPLIT_FILE.resolve()),
        "all_subtype_test_file": str(ALL_SUBTYPE_TEST_FILE.resolve()),
        "development_refined_prototype": str(DEV_REFINED_PROTO_FILE.resolve()),
        "final_refined_prototype": str(FINAL_REFINED_PROTO_FILE.resolve()),
    }
    save_final_checkpoint(
        OUTPUT_DIR / "ARGScope_final_longAA_fusion_refined_model.pt",
        final_classifier,
        final_mapper,
        canonical_classes,
        type_classes,
        subtype_to_type,
        fusion_cols,
        longaa_cols,
        final_scaler,
        selected_epochs,
        source_files,
    )

    run_manifest = {
        "completed": True,
        "model_modality": "protein_only_at_inference",
        "protein_embedding": "ESM-2_1280D",
        "privileged_training_target": "Fusion_512D_and_Refined_prototypes",
        "device": str(device),
        "torch_version": torch.__version__,
        "amp_enabled": amp_enabled,
        "amp_dtype": str(amp_dtype),
        "rows": {
            "train_core": int(train_mask.sum()),
            "validation": int(val_mask.sum()),
            "full_train_pool": int(full_train_mask.sum()),
            "independent_test": int(test_mask.sum()),
            "all_subtype_coverage_test": int(len(coverage_idx)),
            "singleton_train_test_overlap": int(coverage_overlap_mask.sum()),
        },
        "classes": {
            "subtypes": len(canonical_classes),
            "types": len(type_classes),
        },
        "selected_epochs": selected_epochs,
        "fixed_user_split_audit": split_audit,
        "independent_test_subtype_metrics": independent_decoded["subtype_metrics"],
        "independent_test_type_metrics": independent_decoded["type_metrics"],
        "all_subtype_coverage_test_subtype_metrics": coverage_decoded["subtype_metrics"],
        "all_subtype_coverage_test_type_metrics": coverage_decoded["type_metrics"],
        "singleton_overlap_subtype_metrics_not_independent": singleton_metrics,
        "evaluation_warning": (
            "Singleton Subtypes use the same reference ID in training and in the "
            "all-Subtype coverage test. Use independent-test metrics for "
            "generalization claims."
        ),
        "source_files": source_files,
    }
    save_json(run_manifest, OUTPUT_DIR / "run_manifest.json")

    print_banner("Completed")
    print(f"Final checkpoint: {OUTPUT_DIR / 'ARGScope_final_longAA_fusion_refined_model.pt'}")
    print(f"Overall metrics:  {OUTPUT_DIR / 'overall_metrics.csv'}")
    print(
        f"Independent predictions: {OUTPUT_DIR / 'independent_test_predictions_longAA_to_fusion_refined.csv'}"
    )
    print(
        f"All-Subtype predictions: {OUTPUT_DIR / 'all_subtype_test_predictions_longAA_to_fusion_refined.csv'}"
    )
    print(
        f"All-Subtype report:      {OUTPUT_DIR / 'subtype_metrics_all_2825_classes.csv'}"
    )
    print(
        f"Adapted prototypes: {OUTPUT_DIR / 'final_adapted_refined_subtype_prototypes_512.csv'}"
    )


if __name__ == "__main__":
    mp.freeze_support()
    main()
