#!/usr/bin/env python3
"""Source-backed descriptive boxplots; all baseline distributions are empirical.

The model cohorts differ. DeepARG is conditional on archived selected ARG hits.
Boxes: Q1-Q3; line: median; whiskers: 1.5 IQR; outliers shown; diamond: observed.
"""
from pathlib import Path
import importlib.util
import hashlib
import json
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.cbook import boxplot_stats
from matplotlib.ticker import FormatStrFormatter

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent
DATA = ROOT/'data'
FIG = ROOT/'final_figures'
spec = importlib.util.spec_from_file_location('network_style', SOURCE/'type_level_revision/plot_type_network_revision.py')
net = importlib.util.module_from_spec(spec)
spec.loader.exec_module(net)
base = net.base
base.FIG = FIG
base.exports.clear()
base.LAYOUT_QA.clear()
boot = pd.read_csv(DATA/'all_model_parent_bootstrap.csv')
summary = pd.read_csv(DATA/'all_model_points_and_intervals.csv')
network_data = SOURCE/'violin_revision/data'
display_filter = pd.read_csv(network_data/'network_Type_display_filter.csv')
net.ORDER = display_filter.loc[display_filter.Keep,'Type'].tolist()
matrix = pd.read_csv(network_data/'displayed_Type_profile_spearman.csv',index_col=0).loc[net.ORDER,net.ORDER].to_numpy()
arcs = pd.read_csv(network_data/'displayed_model_Type_arcs.csv')
PCTS = [60,70,80,90]
METRICS = ['Accuracy','Precision','Recall','F1','MCC']
BOX_AUDIT = []


def draw_box(ax, values, x, color, width, hatched=False, point=None):
    assert len(values)==2000 and np.isfinite(values).all()
    stat = boxplot_stats(values,whis=1.5)[0]
    artist = ax.bxp([stat],positions=[x],widths=[width],showfliers=True,patch_artist=True,manage_ticks=False,
                    boxprops=dict(facecolor='white' if hatched else color,edgecolor=color,linewidth=.65,alpha=.82),
                    medianprops=dict(color='#24282B',linewidth=.65),
                    whiskerprops=dict(color=color,linewidth=.6),capprops=dict(color=color,linewidth=.6),
                    flierprops=dict(marker='.',markersize=.7,markerfacecolor=color,markeredgecolor='none',alpha=.3))
    if hatched:
        artist['boxes'][0].set_hatch('///')
    if point is not None:
        ax.scatter(x,point,marker='D',s=7,facecolor=color,edgecolor='white',linewidth=.3,zorder=5)
    return {k:float(stat[k]) for k in ['q1','med','q3','whislo','whishi']} | {'N_fliers':len(stat['fliers'])}


def panel(ax,mod,level,metric,focus=False,modality_colors=False):
    models = base.MODELS[mod] if level=='Type' else ['ARGScope']
    offsets = np.linspace(-.32,.32,len(models)) if len(models)>1 else [0]
    width = .13 if len(models)==5 else (.20 if len(models)==3 else .40)
    extrema = []
    for i,pct in enumerate(PCTS):
        for model,offset in zip(models,offsets):
            chosen = boot[(boot.Modality==mod)&(boot.Model==model)&(boot.Level==level)&(boot.Completeness==pct)]
            values = chosen[metric].to_numpy()
            row = summary[(summary.Modality==mod)&(summary.Model==model)&(summary.Level==level)&(summary.Completeness==pct)&(summary.Metric==metric)].iloc[0]
            color = base.MODCOL[mod] if modality_colors else base.COLORS[model]
            stat = draw_box(ax,values,i+offset,color,width,hatched=model=='DeepARG',point=row.Point_estimate)
            BOX_AUDIT.append(dict(Modality=mod,Model=model,Completeness=pct,Level=level,Metric=metric,
                                  N=2000,Point_estimate=row.Point_estimate,Population=row.Population,**stat))
            extrema.extend([values.min(),values.max(),row.Point_estimate])
    if focus:
        lo,hi=min(extrema),max(extrema)
        margin=max((hi-lo)*.07,.005)
        lower=max(-1 if metric=='MCC' else 0,np.floor((lo-margin)*20)/20)
        upper=min(1,np.ceil((hi+margin)*20)/20)
        if upper-lower<.06: lower=max(0,upper-.06)
        ax.set_ylim(lower-.003,upper+.003)
    else:
        ax.set_ylim(-.02 if min(extrema)>=0 else -.1,1.025)
        ax.set_yticks([0,.25,.5,.75,1])
    ax.set_xlim(-.55,3.55)
    ax.set_xticks(range(4),[f'{p}%' for p in PCTS])
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_title(metric,pad=4,fontsize=8.5)
    base.clean(ax)


def legend(fig,y=.995):
    handles=[]
    for model in base.MODELS['protein']:
        handles.append(Patch(facecolor='white' if model=='DeepARG' else base.COLORS[model],
                             edgecolor=base.COLORS[model],hatch='///' if model=='DeepARG' else None,
                             alpha=.82,label='DeepARG (selected ARG hits)' if model=='DeepARG' else model))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,y),ncol=5,frameon=False,fontsize=8,columnspacing=1.8)


def footnote(fig,y,w=320):
    base.text_mm(fig,w/2,y,'Descriptive only: different model cohorts; DeepARG excludes nonARG and non-hit sequences.',ha='center',fontsize=7,color='#62686D')
    base.text_mm(fig,w/2,y+4.5,'2,000 parent bootstraps; boxes: IQR; line: median; whiskers: 1.5 IQR; diamond: observed score.',ha='center',fontsize=7,color='#62686D')


def combined():
    fig=base.canvas(320,402)
    legend(fig)
    for mod,top in [('protein',22),('dna',76)]:
        for j,metric in enumerate(METRICS):
            panel(base.ax_mm(fig,20+j*60,top,50,37),mod,'Type',metric)
        base.text_mm(fig,4,top+18.5,('Protein' if mod=='protein' else 'DNA')+' · Type',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,160,126,'Different model cohorts; hatched DeepARG boxes describe selected ARG hits only.',ha='center',fontsize=7,color='#62686D')
    sm,_=net.network(base.ax_mm(fig,17,133,287,147),matrix,arcs,fontsize=6.8)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,307,170,2.4,59))
    cb.set_ticks([-1,-.5,0,.5,1]);cb.ax.tick_params(labelsize=6,length=2)
    cb.set_label('Profile correlation (ρ)',fontsize=7)
    for mod,top in [('protein',306),('dna',354)]:
        for j,metric in enumerate(METRICS):
            panel(base.ax_mm(fig,20+j*60,top,50,30),mod,'Subtype',metric,focus=True,modality_colors=True)
        base.text_mm(fig,4,top+15,('Protein' if mod=='protein' else 'DNA')+' · Subtype',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,160,398,'Subtype: ARGScope only. Boxes: IQR; line: median; whiskers: 1.5 IQR; diamond: observed score.',ha='center',fontsize=7,color='#62686D')
    base.save(fig,'all_models_boxplot_and_Type_network_main')


def type_only():
    fig=base.canvas(320,154)
    legend(fig)
    for mod,top in [('protein',25),('dna',83)]:
        for j,metric in enumerate(METRICS):panel(base.ax_mm(fig,20+j*60,top,50,39),mod,'Type',metric)
        base.text_mm(fig,4,top+19.5,'Protein' if mod=='protein' else 'DNA',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    footnote(fig,140)
    base.save(fig,'all_models_Type_five_metrics_boxplot')


def subtype_only():
    fig=base.canvas(320,143)
    fig.legend(handles=[Patch(facecolor=base.MODCOL[m],edgecolor=base.MODCOL[m],alpha=.82,label='Protein' if m=='protein' else 'DNA') for m in ['protein','dna']],
               loc='upper center',bbox_to_anchor=(.5,.995),ncol=2,frameon=False,fontsize=8)
    for mod,top in [('protein',24),('dna',81)]:
        for j,metric in enumerate(METRICS):panel(base.ax_mm(fig,20+j*60,top,50,36),mod,'Subtype',metric,focus=True,modality_colors=True)
        base.text_mm(fig,4,top+18,'Protein' if mod=='protein' else 'DNA',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,160,134,'ARGScope only; 2,000 parent bootstraps. Boxes: IQR; line: median; whiskers: 1.5 IQR; diamond: observed score.',ha='center',fontsize=7,color='#62686D')
    base.save(fig,'ARGScope_Subtype_five_metrics_boxplot')


def centered_type_uncertainty():
    """A supplement for reading very narrow boxes, not absolute performance."""
    fig=base.canvas(320,154)
    legend(fig)
    for mod,top in [('protein',25),('dna',83)]:
        models=base.MODELS[mod]
        offsets=np.linspace(-.32,.32,len(models))
        for j,metric in enumerate(METRICS):
            ax=base.ax_mm(fig,20+j*60,top,50,39)
            limit=0
            for i,pct in enumerate(PCTS):
                for model,offset in zip(models,offsets):
                    values=boot[(boot.Modality==mod)&(boot.Model==model)&boot.Level.eq('Type')&(boot.Completeness==pct)][metric].to_numpy()
                    row=summary[(summary.Modality==mod)&(summary.Model==model)&summary.Level.eq('Type')&(summary.Completeness==pct)&(summary.Metric==metric)].iloc[0]
                    delta=values-row.Point_estimate
                    draw_box(ax,delta,i+offset,base.COLORS[model],.13 if len(models)==5 else .20,hatched=model=='DeepARG')
                    limit=max(limit,float(np.abs(delta).max()))
            limit=np.ceil((limit+.001)/.005)*.005
            ax.set(xlim=(-.55,3.55),ylim=(-limit,limit),xticks=range(4),xticklabels=[f'{p}%' for p in PCTS],yticks=[-limit,0,limit])
            ax.yaxis.set_major_formatter(FormatStrFormatter('%+.3f'))
            ax.axhline(0,color='#777D83',linestyle='--',linewidth=.5)
            ax.set_title(metric,pad=4,fontsize=8.5)
            base.clean(ax)
        base.text_mm(fig,4,top+19.5,('Protein' if mod=='protein' else 'DNA')+' · Δ score',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,160,140,'Δ score = bootstrap score − observed score. Uncertainty only, NOT absolute model performance.',ha='center',fontsize=7,color='#62686D')
    base.text_mm(fig,160,144.5,'Different model cohorts; DeepARG represents selected ARG hits only. Boxes: IQR; whiskers: 1.5 IQR.',ha='center',fontsize=7,color='#62686D')
    base.save(fig,'Type_uncertainty_boxplot')


if __name__=='__main__':
    render_start=time.time()
    (ROOT/'render_status.json').write_text(json.dumps(dict(status='RUNNING',started=render_start)),encoding='utf-8')
    combined()
    type_only()
    subtype_only()
    centered_type_uncertainty()
    pd.DataFrame(BOX_AUDIT).to_csv(DATA/'plotted_box_statistics.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    (ROOT/'figure_manifest.json').write_text(json.dumps(base.exports,indent=2),encoding='utf-8')
    (ROOT/'layout_validation.json').write_text(json.dumps(base.LAYOUT_QA,indent=2),encoding='utf-8')
    (ROOT/'render_status.json').write_text(json.dumps(dict(status='COMPLETE',started=render_start,finished=time.time(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),figure_directory=FIG.name)),encoding='utf-8')
    print('Saved boxplots: all 5 Protein / 3 DNA models at Type level; ARGScope only at Subtype level.',flush=True)
