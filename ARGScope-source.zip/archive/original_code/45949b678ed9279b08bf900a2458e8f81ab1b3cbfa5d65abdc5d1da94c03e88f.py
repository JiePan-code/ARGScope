"""Verify final, unlettered plot exports and catalogue every standalone panel."""
from pathlib import Path
import csv
import json
import hashlib
import xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'/'vf_bgc_merged_20260922_v2'
OLD=HERE/'outputs'/'vf_bgc_merged_20260922'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    audit=json.loads((OUT/'verification.json').read_text(encoding='utf-8'))
    with (OUT/'individual_panels'/'子图索引.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==40
    composites=list(OUT.glob('*.svg'))+list((OUT/'supplementary').glob('*.svg'))
    assert len(composites)==6
    singles=sorted((OUT/'individual_panels').rglob('*.svg'))
    assert len(singles)==40
    checks=[]
    for path in composites+singles:
        root=ET.parse(path).getroot()
        texts=[''.join(t.itertext()).strip() for t in root.iter('{http://www.w3.org/2000/svg}text')]
        assert texts and not any(t in list('ABCDEFGH') for t in texts),(path,texts)
        if path.name=='VF_BGC_main_combined.svg':
            assert sum('Best epoch' in t for t in texts)==4
            assert not any('epoch ' in t and any(c.isdigit() for c in t) for t in texts)
            assert not any('Subtype' in t for t in texts)
        for suffix in ['.png','.pdf','.svg']:
            artifact=path.with_suffix(suffix)
            assert artifact.is_file() and artifact.stat().st_size>1000,artifact
            checks.append({'File':str(artifact.relative_to(OUT)),'SHA256':digest(artifact),
                           'Bytes':artifact.stat().st_size})
        with Image.open(path.with_suffix('.png')) as im:
            assert min(im.size)>950
            assert all(abs(v-300)<.1 for v in im.info['dpi'])
            im.verify()
    for source in (OLD/'plot_data').rglob('*'):
        if source.is_file():
            copied=OUT/'plot_data'/source.relative_to(OLD/'plot_data')
            assert digest(source)==digest(copied),(source,copied)
    with (OUT/'file_checksums.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['File','SHA256','Bytes'])
        writer.writeheader(); writer.writerows(checks)
    review=OUT/'review_contact_sheets'; review.mkdir(exist_ok=True)
    font=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',17)
    for start in range(0,len(rows),8):
        sheet=Image.new('RGB',(1840,1340),'#D8DCDF')
        draw=ImageDraw.Draw(sheet)
        for j,row in enumerate(rows[start:start+8]):
            source=OUT/(row['Panel_file']+'.png')
            with Image.open(source) as im:
                im=im.convert('RGB'); im.thumbnail((446,603))
                x=(j%4)*460+(460-im.width)//2; y=(j//4)*670+34+(603-im.height)//2
                sheet.paste(im,(x,y))
            label=f'{start+j+1:02d} '+source.stem
            draw.text(((j%4)*460+8,(j//4)*670+7),label[:47],font=font,fill='black')
        sheet.save(review/f'panels_{start+1:02d}_{min(start+8,len(rows)):02d}.jpg',quality=92)
    audit['export_checks']={'composite_figures':6,'individual_panels':40,
        'total_png_pdf_svg_files':len(checks),'all_svg_labels_checked':True,
        'no_panel_letters_in_any_figure':True,'main_best_epoch_titles_verified':True,
        'all_plot_data_identical_to_previous_version':True,'all_pngs_300dpi':True}
    (OUT/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print('VERIFIED: 6 composites + 40 individual panels, 138 PNG/PDF/SVG files. Source plot data unchanged.')

if __name__=='__main__':
    main()
