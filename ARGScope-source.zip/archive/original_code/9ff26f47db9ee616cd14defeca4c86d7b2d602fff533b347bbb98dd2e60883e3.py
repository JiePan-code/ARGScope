from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

CSV_FILE = BASE_DIR / "all_dataset_summary.csv"

OUTPUT_DIR = BASE_DIR / "heatmap_LongNT_90NT_120NT_150NT"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "LongNT_90NT_120NT_150NT_metrics_heatmap.pdf"
OUTPUT_TIF = OUTPUT_DIR / "LongNT_90NT_120NT_150NT_metrics_heatmap.tif"
OUTPUT_DATA = OUTPUT_DIR / "LongNT_90NT_120NT_150NT_metrics_heatmap_data.csv"


# =========================================================
# 2. 参数设置
# =========================================================

DATASET_ORDER = [
    "LongNT",
    "30aa",
    "40aa",
    "50aa",
]

DATASET_LABELS = {
    "LongNT": "Long NT",
    "30aa": "90 bp",
    "40aa": "120 bp",
    "50aa": "150 bp",
}

DATASET_NAME_MAP = {
    "longnt": "LongNT",
    "long nt": "LongNT",
    "long_nt": "LongNT",
    "longdna": "LongNT",
    "long dna": "LongNT",
    "long_dna": "LongNT",

    "30aa": "30aa",
    "30 aa": "30aa",
    "30_aa": "30aa",
    "90bp": "30aa",
    "90 bp": "30aa",
    "90_bp": "30aa",

    "40aa": "40aa",
    "40 aa": "40aa",
    "40_aa": "40aa",
    "120bp": "40aa",
    "120 bp": "40aa",
    "120_bp": "40aa",

    "50aa": "50aa",
    "50 aa": "50aa",
    "50_aa": "50aa",
    "150bp": "50aa",
    "150 bp": "50aa",
    "150_bp": "50aa",
}

METRICS = [
    "test_ACC",
    "test_WEIGHTED_PRECISION",
    "test_WEIGHTED_RECALL",
    "test_WEIGHTED_F1",
    "test_MCC",
]

METRIC_LABELS = {
    "test_ACC": "Accuracy",
    "test_WEIGHTED_PRECISION": "Precision",
    "test_WEIGHTED_RECALL": "Recall",
    "test_WEIGHTED_F1": "F1-score",
    "test_MCC": "MCC",
}

# 根据你的结果范围调整
VMIN = 0.70
VMAX = 0.85

TIF_DPI = 300

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取数据
# =========================================================

if not CSV_FILE.exists():
    raise FileNotFoundError(f"找不到文件: {CSV_FILE}")

df = pd.read_csv(CSV_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["dataset"] + METRICS
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"CSV 文件缺少这些列: {missing_cols}")

df["dataset"] = df["dataset"].astype(str).str.strip()


# =========================================================
# 4. 标准化 dataset 名称
# =========================================================

def normalize_dataset_name(x):
    x_raw = str(x).strip()
    x_key = x_raw.lower().replace("-", " ").replace("_", " ")
    x_key = " ".join(x_key.split())
    x_key_no_space = x_key.replace(" ", "")

    if x_key in DATASET_NAME_MAP:
        return DATASET_NAME_MAP[x_key]

    if x_key_no_space in DATASET_NAME_MAP:
        return DATASET_NAME_MAP[x_key_no_space]

    return x_raw


df["dataset_original"] = df["dataset"]
df["dataset"] = df["dataset"].map(normalize_dataset_name)

print("\nCSV 中识别到的 dataset 名称:")
print(sorted(df["dataset"].unique().tolist()))


# =========================================================
# 5. 筛选目标 dataset
# =========================================================

df = df[df["dataset"].isin(DATASET_ORDER)].copy()

if len(df) == 0:
    raise ValueError(
        "没有匹配到 LongNT, 90NT, 120NT, 150NT。\n"
        "请检查 all_dataset_summary.csv 中 dataset 列的实际名称。\n"
        "上方已打印 CSV 中识别到的 dataset 名称。"
    )

missing_datasets = [x for x in DATASET_ORDER if x not in df["dataset"].tolist()]
if missing_datasets:
    raise ValueError(
        f"CSV 中缺少这些 dataset: {missing_datasets}\n"
        f"当前识别到的 dataset: {sorted(df['dataset'].astype(str).unique().tolist())}"
    )

df["dataset"] = pd.Categorical(
    df["dataset"],
    categories=DATASET_ORDER,
    ordered=True,
)

df = df.sort_values("dataset").reset_index(drop=True)

for metric in METRICS:
    df[metric] = pd.to_numeric(df[metric], errors="coerce")

if df[METRICS].isna().any().any():
    raise ValueError("指标列中存在无法转换为数值的内容，请检查 CSV。")


# =========================================================
# 6. 整理 heatmap 数据
# =========================================================

heatmap_df = df.set_index("dataset")[METRICS].copy()
heatmap_df.index = [DATASET_LABELS[x] for x in heatmap_df.index]
heatmap_df.columns = [METRIC_LABELS[x] for x in METRICS]

heatmap_df.to_csv(OUTPUT_DATA, encoding="utf-8-sig")

values = heatmap_df.values


# =========================================================
# 7. 绘制 heatmap
# =========================================================

fig, ax = plt.subplots(figsize=(5.8, 3.4), dpi=600)

im = ax.imshow(
    values,
    cmap="YlGnBu",
    vmin=VMIN,
    vmax=VMAX,
    aspect="auto",
)

ax.set_xticks(np.arange(len(heatmap_df.columns)))
ax.set_xticklabels(heatmap_df.columns, fontsize=9)

ax.set_yticks(np.arange(len(heatmap_df.index)))
ax.set_yticklabels(heatmap_df.index, fontsize=9)

ax.set_xlabel("")
ax.set_ylabel("")

ax.set_title(
    "Subtype-level performance of DNA short-read sequences",
    fontsize=11,
    pad=12,
)

# 在每个格子中标注数值
for i in range(values.shape[0]):
    for j in range(values.shape[1]):
        value = values[i, j]

        text_color = "white" if value >= (VMIN + VMAX) / 2 else "black"

        ax.text(
            j,
            i,
            f"{value:.3f}",
            ha="center",
            va="center",
            fontsize=8,
            color=text_color,
        )

# 添加网格线
ax.set_xticks(np.arange(values.shape[1] + 1) - 0.5, minor=True)
ax.set_yticks(np.arange(values.shape[0] + 1) - 0.5, minor=True)

ax.grid(
    which="minor",
    color="white",
    linestyle="-",
    linewidth=1.0,
)

ax.tick_params(which="minor", bottom=False, left=False)

# colorbar
cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label("Metric value", fontsize=9)
cbar.ax.tick_params(labelsize=8)

plt.tight_layout()


# =========================================================
# 8. 保存
# =========================================================

fig.savefig(OUTPUT_PDF, bbox_inches="tight")

fig.savefig(
    OUTPUT_TIF,
    dpi=TIF_DPI,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 9. 输出
# =========================================================

print("\nHeatmap data:")
print(heatmap_df)

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_DATA)