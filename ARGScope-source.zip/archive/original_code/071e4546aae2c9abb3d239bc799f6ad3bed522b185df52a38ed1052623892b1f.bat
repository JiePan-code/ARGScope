@echo off
setlocal
if exist "D:\Anaconda\envs\dnabert2_5060\python.exe" (
  "D:\Anaconda\envs\dnabert2_5060\python.exe" "%~dp0rebuild_split_80_20_grouped.py" %*
) else (
  py -3 "%~dp0rebuild_split_80_20_grouped.py" %*
)
if errorlevel 1 (
  echo Split generation failed. Existing data and results were not overwritten.
) else (
  echo Done. This only creates split files. It does not start model training.
)
pause
endlocal
