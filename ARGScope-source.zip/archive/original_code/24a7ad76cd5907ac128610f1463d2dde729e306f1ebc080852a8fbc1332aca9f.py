# -*- coding: utf-8 -*-
"""
Protein/AA type-level heatmaps.

Models:
    ARGNet
    DeepARG
    FunGeneTyper
    PLM-ARG
    ARGScope

Group 1:
    30aa, 40aa, 50aa, 100pct
    注意：这一组不加入 PLM-ARG

Group 2:
    60pct, 70pct, 80pct, 90pct, 100pct
    注意：这一组加入 PLM-ARG

Metrics:
    ACC, Precision, Recall, F1, MCC

Color:
    light blue

Output:
    protein_heatmap_outputs_5metrics_blue_fixed/
"""

import os
import re
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


# =========================================================
# 1. CONFIG
# =========================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
print("Current working directory:", os.getcwd())

AA_MODEL_ORDER = [
    "ARGNet",
    "DeepARG",
    "FunGeneTyper",
    "ARGScope",
]

PCT_MODEL_ORDER = [
    "ARGNet",
    "DeepARG",
    "FunGeneTyper",
    "PLM-ARG",
    "ARGScope",
]

AA_GROUP_ORDER = ["30aa", "40aa", "50aa", "100pct"]
PCT_GROUP_ORDER = ["60pct", "70pct", "80pct", "90pct", "100pct"]

METRICS = ["ACC", "Precision", "Recall", "F1", "MCC"]

SHOW_VALUES = True

REFERENCE_GROUP_FOR_TYPES = "100pct"
REFERENCE_MODEL_FOR_TYPES = "ARGScope"
REFERENCE_METRIC_FOR_TYPES = "F1"
SORT_DESCENDING = True

DPI = 600

OUTDIR = "protein_heatmap_outputs_5metrics_blue_fixed"
os.makedirs(OUTDIR, exist_ok=True)

OUT_MATRIX_XLSX = os.path.join(
    OUTDIR,
    "protein_type_heatmap_matrices_5metrics.xlsx"
)

plt.rcParams["font.family"] = "Arial"


# =========================================================
# 2. FILE MAP
# =========================================================

FILE_MAP = {
    "ARGNet": {
        "30aa": ["ARGNet/ARGNET_30aa_aa_type_metrics_by_class.csv"],
        "40aa": ["ARGNet/ARGNET_40aa_aa_type_metrics_by_class.csv"],
        "50aa": ["ARGNet/ARGNET_50aa_aa_type_metrics_by_class.csv"],
        "60pct": ["ARGNet/ARGNET_60pct_aa_type_metrics_by_class.csv"],
        "70pct": ["ARGNet/ARGNET_70pct_aa_type_metrics_by_class.csv"],
        "80pct": ["ARGNet/ARGNET_80pct_aa_type_metrics_by_class.csv"],
        "90pct": ["ARGNet/ARGNET_90pct_aa_type_metrics_by_class.csv"],
        "100pct": ["ARGNet/ARGNET_100pct_aa_type_metrics_by_class.csv"],
    },

    "ARGScope": {
        "30aa": ["ARGScope/30aa_type_metrics_by_class_from_subtype.csv"],
        "40aa": ["ARGScope/40aa_type_metrics_by_class_from_subtype.csv"],
        "50aa": ["ARGScope/50aa_type_metrics_by_class_from_subtype.csv"],
        "60pct": ["ARGScope/60p_type_metrics_by_class_from_subtype.csv"],
        "70pct": ["ARGScope/70p_type_metrics_by_class_from_subtype.csv"],
        "80pct": ["ARGScope/80p_type_metrics_by_class_from_subtype.csv"],
        "90pct": ["ARGScope/90p_type_metrics_by_class_from_subtype.csv"],
        "100pct": ["ARGScope/100p_type_metrics_by_class_from_subtype.csv"],
    },

    "DeepARG": {
        "30aa": ["Deeparg/deeparg_type_30aa_classification_report.csv"],
        "40aa": ["Deeparg/deeparg_type_40aa_classification_report.csv"],
        "50aa": ["Deeparg/deeparg_type_50aa_classification_report.csv"],
        "60pct": ["Deeparg/deeparg_type_60pct_classification_report.csv"],
        "70pct": ["Deeparg/deeparg_type_70pct_classification_report.csv"],
        "80pct": ["Deeparg/deeparg_type_80pct_classification_report.csv"],
        "90pct": ["Deeparg/deeparg_type_90pct_classification_report.csv"],
        "100pct": ["Deeparg/deeparg_type_100pct_classification_report.csv"],
    },

    "FunGeneTyper": {
        "30aa": ["Fungenetype/30aa_type_classification_report.csv"],
        "40aa": ["Fungenetype/40aa_type_classification_report.csv"],
        "50aa": ["Fungenetype/50aa_type_classification_report.csv"],
        "60pct": ["Fungenetype/60p_type_classification_report.csv"],
        "70pct": ["Fungenetype/70p_type_classification_report.csv"],
        "80pct": ["Fungenetype/80p_type_classification_report.csv"],
        "90pct": ["Fungenetype/90p_type_classification_report.csv"],
        "100pct": ["Fungenetype/100p_type_classification_report.csv"],
    },

    "PLM-ARG": {
        "60pct": ["PLM-ARG/PLMARG_TYPE_60PCT_by_class_hit_rate_ARG_only.csv"],
        "70pct": ["PLM-ARG/PLMARG_TYPE_70PCT_by_class_hit_rate_ARG_only.csv"],
        "80pct": ["PLM-ARG/PLMARG_TYPE_80PCT_by_class_hit_rate_ARG_only.csv"],
        "90pct": ["PLM-ARG/PLMARG_TYPE_90PCT_by_class_hit_rate_ARG_only.csv"],
        "100pct": ["PLM-ARG/PLMARG_TYPE_100_by_class_hit_rate_ARG_only.csv"],
    },
}


# =========================================================
# 3. LIGHT BLUE COLOR MAP
# =========================================================

HEATMAP_CMAP = LinearSegmentedColormap.from_list(
    "custom_light_blue_heatmap",
    [
        "#F7FBFF",
        "#DEEBF7",
        "#C6DBEF",
        "#9ECAE1",
        "#6BAED6",
        "#3182BD",
        "#08519C",
    ],
    N=256
)

NAN_COLOR = "#D9D9D9"


# =========================================================
# 4. FILE IO
# =========================================================

def resolve_file(candidate_paths):
    if isinstance(candidate_paths, str):
        candidate_paths = [candidate_paths]

    for path in candidate_paths:
        if os.path.exists(path):
            return path

    return None


def read_table_auto(file_path):
    lower = file_path.lower()

    if lower.endswith(".xlsx") or lower.endswith(".xls"):
        return pd.read_excel(file_path)

    encodings = ["utf-8-sig", "utf-8", "gbk", "gb18030", "latin1"]
    last_error = None

    for enc in encodings:
        try:
            return pd.read_csv(file_path, encoding=enc)
        except Exception as e:
            last_error = e

    raise RuntimeError(f"Cannot read file: {file_path}\nLast error: {last_error}")


# =========================================================
# 5. TYPE NORMALIZATION
# =========================================================

def normalize_type_name(x):
    if pd.isna(x):
        return np.nan

    s = str(x).strip()

    if s == "":
        return np.nan

    s_low = s.lower()
    s_low = s_low.replace("-", "_").replace(" ", "_")
    s_low = re.sub(r"__+", "_", s_low)

    alias_map = {
        "macrolide_lincosamide_streptogramin": "MLS",
        "macrolides_lincosamides_streptogramines": "MLS",
        "macrolide_lincosamide_streptogramin_b": "MLS",
        "mls": "MLS",

        "betalactams": "beta_lactam",
        "beta_lactams": "beta_lactam",
        "beta_lactam": "beta_lactam",
        "beta_lactams_resistance": "beta_lactam",

        "multi_drug": "multidrug",
        "multi_drug_resistance": "multidrug",
        "multidrug": "multidrug",

        "aminoglycosides": "aminoglycoside",
        "aminoglycoside": "aminoglycoside",

        "aminocoumarins": "aminocoumarin",
        "aminocoumarin": "aminocoumarin",

        "quinolones": "quinolone",
        "quinolone": "quinolone",

        "polymyxins": "polymyxin",
        "polymyxin": "polymyxin",

        "trimethoprims": "trimethoprim",
        "trimethoprim": "trimethoprim",

        "glycopeptide": "glycopeptide",
        "glycopeptides": "glycopeptide",
        "vancomycin": "glycopeptide",

        "chloramphenicol": "chloramphenicol",
        "bacitracin": "bacitracin",
        "bleomycin": "bleomycin",
        "rifamycin": "rifamycin",
        "rifampin": "rifamycin",
        "sulfonamide": "sulfonamide",
        "sulfonamides": "sulfonamide",
        "tetracycline": "tetracycline",
        "tetracyclines": "tetracycline",
        "fosfomycin": "fosfomycin",
        "fosmidomycin": "fosmidomycin",
        "fusidic_acid": "fusidic_acid",
        "fusidicacid": "fusidic_acid",
        "novobiocin": "novobiocin",
        "streptothricin": "streptothricin",

        "tetracenomycin": "tetracenomycin",
        "tetracenomycin_c": "tetracenomycin",
        "triclosan": "triclosan",
        "ethambutol": "ethambutol",
        "isoniazid": "isoniazid",
        "kasugamycin": "kasugamycin",
        "mupirocin": "mupirocin",
        "nitrofurantoin": "nitrofurantoin",
        "nitroimidazole": "nitroimidazole",
        "peptide": "peptide",
        "other_peptide_antibiotics": "other_peptide_antibiotics",
        "qa_compound": "qa_compound",
        "puromycin": "puromycin",
        "elfamycin": "elfamycin",
        "edeine": "edeine",
        "defensin": "defensin",
        "bicyclomycin": "bicyclomycin",
        "pleuromutilin": "pleuromutilin",
        "pleuromutilin_tiamulin": "pleuromutilin",
        "thiostrepton": "thiostrepton",
        "tunicamycin": "tunicamycin",
        "factumycin": "factumycin",
        "antibacterial_fatty_acid": "antibacterial_fatty_acid",

        "nonarg": "nonarg",
        "non_arg": "nonarg",
        "non-arg": "nonarg",
        "non arg": "nonarg",

        "macro_avg": np.nan,
        "weighted_avg": np.nan,
        "accuracy": np.nan,
    }

    return alias_map.get(s_low, s_low)


def pretty_type_name(x):
    if x == "MLS":
        return "MLS"
    return x


def is_nonarg_type(x):
    s = str(x).strip().lower()
    return s in ["nonarg", "non_arg", "non-arg", "non arg", "nan"]


# =========================================================
# 6. COLUMN NORMALIZATION
# =========================================================

def clean_column_name(c):
    c = str(c).replace("\ufeff", "").strip()
    return c


def standardize_columns(df):
    df = df.copy()
    df.columns = [clean_column_name(c) for c in df.columns]

    col_map = {}

    for c in df.columns:
        c_low = str(c).strip().lower()
        c_low_norm = c_low.replace("-", "_").replace(" ", "_")

        if (
            c_low_norm in [
                "type",
                "arg_type",
                "label",
                "class",
                "class_category",
                "name",
                "drug_class",
                "resistance_category",
                "unnamed:_0",
                "unnamed_0",
                "unnamed:0",
                "",
            ]
            or c_low.startswith("unnamed")
        ):
            col_map[c] = "Type"

        elif c_low_norm in [
            "acc",
            "accuracy",
            "acc_one_vs_rest",
        ]:
            col_map[c] = "ACC"

        elif c_low_norm in [
            "precision",
            "prec",
            "weighted_precision",
        ]:
            col_map[c] = "Precision"

        elif c_low_norm in [
            "recall",
            "sensitivity",
        ]:
            col_map[c] = "Recall"

        elif c_low_norm in [
            "f1",
            "f1_score",
            "f1score",
        ]:
            col_map[c] = "F1"

        elif c_low_norm in [
            "mcc",
        ]:
            col_map[c] = "MCC"

        elif c_low_norm in [
            "support",
            "support_true",
        ]:
            col_map[c] = "Support"

        elif c_low_norm in [
            "hit_rate",
            "hitrate",
            "hit_rate_arg_only",
            "by_class_hit_rate",
        ]:
            col_map[c] = "Recall"

    df = df.rename(columns=col_map)
    df.columns = [clean_column_name(c) for c in df.columns]

    return df


def ensure_metric_columns(df):
    for m in METRICS:
        if m not in df.columns:
            df[m] = np.nan
    return df


# =========================================================
# 7. LOAD MODEL METRICS
# =========================================================

def load_model_metrics(model_name, file_path):
    df = read_table_auto(file_path)
    df = standardize_columns(df)

    if "Type" not in df.columns:
        raise ValueError(
            f"{file_path} missing Type column. Current columns: {list(df.columns)}"
        )

    df = ensure_metric_columns(df)

    df["Type"] = df["Type"].apply(normalize_type_name)
    df = df.dropna(subset=["Type"]).copy()
    df = df[~df["Type"].apply(is_nonarg_type)].copy()

    keep_cols = ["Type"] + METRICS
    if "Support" in df.columns:
        keep_cols.append("Support")

    df = df[keep_cols].copy()

    for c in METRICS + ["Support"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    metric_cols = [c for c in METRICS + ["Support"] if c in df.columns]
    df = df.groupby("Type", as_index=False)[metric_cols].mean()
    df["Model"] = model_name

    return df


# =========================================================
# 8. LOAD ALL DATA
# =========================================================

ALL_GROUPS = []
for g in AA_GROUP_ORDER + PCT_GROUP_ORDER:
    if g not in ALL_GROUPS:
        ALL_GROUPS.append(g)

group_model_data = {}
missing_files = []
read_errors = []

for group in ALL_GROUPS:
    group_model_data[group] = {}

    if group in AA_GROUP_ORDER:
        model_order = AA_MODEL_ORDER
    else:
        model_order = PCT_MODEL_ORDER

    for model in model_order:
        candidates = FILE_MAP.get(model, {}).get(group)
        real_path = resolve_file(candidates) if candidates else None

        if real_path is None:
            group_model_data[group][model] = None
            missing_files.append((group, model, candidates))
            print(f"[MISSING] {group} | {model} | {candidates}")
            continue

        try:
            one_df = load_model_metrics(model, real_path)
            group_model_data[group][model] = one_df
            print(
                f"[OK] {group} | {model} -> {real_path} | "
                f"type_count={one_df['Type'].nunique()}"
            )

        except Exception as e:
            group_model_data[group][model] = None
            read_errors.append((group, model, real_path, repr(e)))
            print(f"[ERROR] {group} | {model} -> {real_path} | {repr(e)}")


# =========================================================
# 9. TYPE ORDER
# =========================================================

def get_reference_type_order():
    ref_df = group_model_data.get(
        REFERENCE_GROUP_FOR_TYPES, {}
    ).get(
        REFERENCE_MODEL_FOR_TYPES, None
    )

    if ref_df is not None and REFERENCE_METRIC_FOR_TYPES in ref_df.columns:
        tmp = ref_df[["Type", REFERENCE_METRIC_FOR_TYPES]].drop_duplicates().copy()
        tmp = tmp.sort_values(
            REFERENCE_METRIC_FOR_TYPES,
            ascending=not SORT_DESCENDING
        )
        return [t for t in tmp["Type"].tolist() if not is_nonarg_type(t)]

    type_union = set()
    metric_map = {}

    for group in ALL_GROUPS:
        model_order = AA_MODEL_ORDER if group in AA_GROUP_ORDER else PCT_MODEL_ORDER

        for model in model_order:
            df_m = group_model_data.get(group, {}).get(model, None)
            if df_m is None:
                continue

            for _, row in df_m.iterrows():
                t = row["Type"]

                if is_nonarg_type(t):
                    continue

                type_union.add(t)
                metric_map.setdefault(t, [])

                if REFERENCE_METRIC_FOR_TYPES in row and pd.notna(row[REFERENCE_METRIC_FOR_TYPES]):
                    metric_map[t].append(float(row[REFERENCE_METRIC_FOR_TYPES]))

    if len(type_union) == 0:
        raise ValueError("No valid types were loaded.")

    return sorted(
        list(type_union),
        key=lambda x: np.nanmean(metric_map.get(x, [np.nan])),
        reverse=True
    )


all_types = get_reference_type_order()
display_types = [pretty_type_name(t) for t in all_types]

print("\nFinal type count:", len(all_types))
print("Final type list:")
print(all_types)


# =========================================================
# 10. BUILD MATRICES
# =========================================================

def build_group_matrices(group_order, model_order, metric):
    group_mats = {}

    for group in group_order:
        rows = []

        for t in all_types:
            row = []

            for model in model_order:
                df_m = group_model_data.get(group, {}).get(model, None)

                if df_m is None:
                    row.append(np.nan)
                    continue

                sub = df_m[df_m["Type"] == t]

                if len(sub) == 0:
                    row.append(np.nan)
                else:
                    row.append(sub.iloc[0][metric])

            rows.append(row)

        mat = pd.DataFrame(rows, index=display_types, columns=model_order)
        group_mats[group] = mat

    return group_mats


# =========================================================
# 11. SAVE MATRICES
# =========================================================

with pd.ExcelWriter(OUT_MATRIX_XLSX) as writer:
    for metric in METRICS:
        aa_group_mats = build_group_matrices(AA_GROUP_ORDER, AA_MODEL_ORDER, metric)
        pct_group_mats = build_group_matrices(PCT_GROUP_ORDER, PCT_MODEL_ORDER, metric)

        metric_tag = metric.lower()

        for group in AA_GROUP_ORDER:
            sheet = f"{metric_tag}_aa_{group}"
            aa_group_mats[group].to_excel(writer, sheet_name=sheet[:31])

        for group in PCT_GROUP_ORDER:
            sheet = f"{metric_tag}_pct_{group}"
            pct_group_mats[group].to_excel(writer, sheet_name=sheet[:31])

print(f"\nSaved: {OUT_MATRIX_XLSX}")


# =========================================================
# 12. DRAW HEATMAP
# =========================================================

def group_title(group):
    if group.endswith("pct"):
        return group.replace("pct", "%")
    return group


def draw_heatmap(ax, data, title, metric, show_ylabels=False):
    arr = data.values.astype(float)

    cmap = HEATMAP_CMAP.copy()
    cmap.set_bad(color=NAN_COLOR)

    if metric == "MCC":
        vmin, vmax = -1, 1
    else:
        vmin, vmax = 0, 1

    im = ax.imshow(arr, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)

    ax.set_title(title, fontsize=16, fontweight="bold", pad=10)

    ax.set_xticks(np.arange(data.shape[1]))
    ax.set_xticklabels(
        data.columns,
        rotation=45,
        ha="right",
        rotation_mode="anchor",
        fontsize=11,
        fontweight="bold"
    )

    for label in ax.get_xticklabels():
        if label.get_text() == "ARGScope":
            label.set_color("#08519C")
        if label.get_text() == "PLM-ARG":
            label.set_color("#005B96")

    ax.set_yticks(np.arange(data.shape[0]))

    if show_ylabels:
        ax.set_yticklabels(data.index, fontsize=10)
    else:
        ax.set_yticklabels([])

    ax.tick_params(axis="both", length=0)

    ax.set_xticks(np.arange(-0.5, data.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, data.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linestyle="-", linewidth=1)
    ax.tick_params(which="minor", bottom=False, left=False)

    if SHOW_VALUES:
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                val = arr[i, j]

                if np.isnan(val):
                    continue

                if abs(val) < 1e-12:
                    continue

                text = f"{val:.2f}".rstrip("0").rstrip(".")

                if metric == "MCC":
                    color = "white" if val >= 0.35 else "black"
                else:
                    color = "white" if val >= 0.65 else "black"

                ax.text(
                    j,
                    i,
                    text,
                    ha="center",
                    va="center",
                    fontsize=8,
                    color=color
                )

    for spine in ax.spines.values():
        spine.set_visible(False)

    return im


def plot_heatmap_figure(group_order, model_order, group_mats, metric, out_prefix, main_title):
    n_panels = len(group_order)

    fig, axes = plt.subplots(
        1,
        n_panels,
        figsize=(3.7 * n_panels + 2.4, max(7, len(all_types) * 0.34)),
        constrained_layout=False
    )

    if n_panels == 1:
        axes = [axes]

    last_im = None

    for idx, group in enumerate(group_order):
        last_im = draw_heatmap(
            ax=axes[idx],
            data=group_mats[group],
            title=f"{metric} ({group_title(group)})",
            metric=metric,
            show_ylabels=(idx == 0)
        )

    axes[0].set_ylabel("ARG Types", fontsize=14, fontweight="bold")

    fig.suptitle(
        main_title,
        fontsize=18,
        fontweight="bold",
        y=0.98
    )

    plt.subplots_adjust(
        left=0.22,
        right=0.88,
        top=0.88,
        bottom=0.20,
        wspace=0.12
    )

    fig.canvas.draw()

    ref_ax = axes[-1]
    pos = ref_ax.get_position()

    cbar_ax = fig.add_axes([
        pos.x1 + 0.012,
        pos.y0,
        0.015,
        pos.y1 - pos.y0
    ])

    cbar = fig.colorbar(last_im, cax=cbar_ax)
    cbar.set_label(metric, fontsize=12, fontweight="bold")
    cbar.ax.tick_params(labelsize=10)

    out_png = out_prefix + ".png"
    out_pdf = out_prefix + ".pdf"
    out_tif = out_prefix + ".tif"

    plt.savefig(out_png, dpi=DPI, bbox_inches="tight")
    plt.savefig(out_pdf, dpi=DPI, bbox_inches="tight")
    plt.savefig(out_tif, dpi=DPI, bbox_inches="tight")
    plt.close(fig)

    print(f"Saved: {out_png}")
    print(f"Saved: {out_pdf}")
    print(f"Saved: {out_tif}")


# =========================================================
# 13. SAVE FIGURES
# =========================================================

for metric in METRICS:
    metric_tag = metric.lower()

    aa_group_mats = build_group_matrices(AA_GROUP_ORDER, AA_MODEL_ORDER, metric)
    pct_group_mats = build_group_matrices(PCT_GROUP_ORDER, PCT_MODEL_ORDER, metric)

    out_aa_prefix = os.path.join(
        OUTDIR,
        f"protein_type_{metric_tag}_heatmap_aa_100"
    )

    out_pct_prefix = os.path.join(
        OUTDIR,
        f"protein_type_{metric_tag}_heatmap_pct_60_100_with_plmarg"
    )

    plot_heatmap_figure(
        group_order=AA_GROUP_ORDER,
        model_order=AA_MODEL_ORDER,
        group_mats=aa_group_mats,
        metric=metric,
        out_prefix=out_aa_prefix,
        main_title=f"Protein Type-level {metric}: 30aa, 40aa, 50aa and 100%"
    )

    plot_heatmap_figure(
        group_order=PCT_GROUP_ORDER,
        model_order=PCT_MODEL_ORDER,
        group_mats=pct_group_mats,
        metric=metric,
        out_prefix=out_pct_prefix,
        main_title=f"Protein Type-level {metric}: 60%-100%"
    )


# =========================================================
# 14. REPORT
# =========================================================

if missing_files:
    print("\nMissing files:")
    for group, model, candidates in missing_files:
        print(f"  {group} | {model} | {candidates}")

if read_errors:
    print("\nRead errors:")
    for group, model, path, err in read_errors:
        print(f"  {group} | {model} | {path} | {err}")