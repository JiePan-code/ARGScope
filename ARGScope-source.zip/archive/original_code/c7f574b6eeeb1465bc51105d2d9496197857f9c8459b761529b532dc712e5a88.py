"""Local right-click launcher for Full train-only raw subtype prototypes."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ablation_runtime import data_root_from_launcher, load_base, reject_overwrite_argument

DATA = data_root_from_launcher(__file__)
m = load_base("02_raw_prototypes.py", "raw_full_local_base")
m.ROOT = DATA
m.DEFAULT_INPUT_PT = (
    DATA / "Long_fusion_subtype2_newsplit" / "long_fusion_subtype2_newsplit.pt"
)
m.DEFAULT_OUTPUT_PT = (
    DATA
    / "Raw_subtype_prototypes_subtype2_newsplit"
    / "raw_ARG_subtype_prototypes_and_baseline.pt"
)
reject_overwrite_argument()
m.main()
