const fs=require('fs');
const path=require('path');
const sharp=require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve('outputs/figure4_60_90_including_nonARG_20260922');
const qa=path.join(root,'qa');
fs.mkdirSync(qa,{recursive:true});
(async()=>{
 const report=[];
 for(const variant of ['','editable_text']){
  const folder=path.join(root,variant);
  const files=fs.readdirSync(folder).filter(n=>n.endsWith('.svg')).sort();
  if(files.length!==2)throw Error('Expected two SVG panels');
  for(const file of files){
   const svg=fs.readFileSync(path.join(folder,file));
   const text=svg.toString();
   if(/<image\b/.test(text))throw Error('Embedded bitmap');
   if(!/viewBox="0 0 /.test(text))throw Error('Nonzero origin');
   const rendered=await sharp(svg,{density:160}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
   const {width,height,channels}=rendered.info;
   let xmin=width,ymin=height,xmax=-1,ymax=-1,transparent=0;
   for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const a=rendered.data[(y*width+x)*channels+channels-1];
    if(a===0)transparent++;
    if(a>4){xmin=Math.min(xmin,x);xmax=Math.max(xmax,x);ymin=Math.min(ymin,y);ymax=Math.max(ymax,y);}
   }
   if(!transparent)throw Error('Opaque figure');
   const margins=[xmin,ymin,width-1-xmax,height-1-ymax];
   if(Math.min(...margins)<1)throw Error('Clipping risk '+file+' '+margins);
   if(!variant){
    await sharp(rendered.data,{raw:rendered.info}).flatten({background:'#ffffff'}).resize({width:2400,withoutEnlargement:true}).png().toFile(path.join(qa,file.replace('.svg','.png')));
    await sharp(rendered.data,{raw:rendered.info}).flatten({background:'#ffffff'}).resize({width:1800,withoutEnlargement:true}).grayscale().png().toFile(path.join(qa,file.replace('.svg','_grayscale.png')));
   }
   report.push({file,variant:variant||'outlined',width,height,edge_clearance_px:margins,transparent_pixels:transparent,pure_vector:true,origin_zero:true});
  }
 }
 fs.writeFileSync(path.join(qa,'svg_verification.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
