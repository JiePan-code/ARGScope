"""Publication SVG subpanels with nonARG included in annotation evaluation."""
from pathlib import Path
import json
import shutil
import xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch, Rectangle
from matplotlib.text import Text
from matplotlib.transforms import Bbox
from matplotlib.ticker import MaxNLocator, PercentFormatter, FormatStrFormatter
import numpy as np
import pandas as pd
import plot_argscope_all_panels_transparent as previous
from recalculate_argscope_including_nonarg import OUT, DATA, ROOT, ORDER, LABELS, FIELDS

FIGURES = OUT / 'Figure2_Figure3_SVG'
OLD_SOURCE = previous.source
PALETTE_PATH = previous.PUBLICATION / 'umap_reference_palette.csv'
AUDIT = []
TYPE_METRICS = ['Precision', 'Recall', 'F1']


def source(path, **kwargs):
    # Only the binary source binding changes. Its numerical equality was checked.
    if Path(path).name == '06_ARG_nonARG_macro_weighted_micro.csv':
        path = DATA / Path(path).parent.name / 'ARG_nonARG_all_averages_60_100.csv'
        frame = OLD_SOURCE(path, **kwargs)
        return frame[frame.Average.ne('ARG_positive')]
    return OLD_SOURCE(path, **kwargs)


def save(fig, modality, letter, suffix, info):
    target = FIGURES / f'Figure{2 if modality == "Protein" else 3}_{modality}'
    stem = f'Figure{2 if modality == "Protein" else 3}{letter}_{modality}_{suffix}'
    target.mkdir(parents=True, exist_ok=True)
    fig.patch.set_alpha(0)
    for ax in fig.axes:
        ax.patch.set_alpha(0)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    tight = fig.get_tightbbox(renderer)
    # Origin-zero canvas and outlined glyphs prevent the earlier Word cropping.
    # A minimal 1.8 pt guard retains descenders across SVG importers without a broad blank margin.
    pad = .025
    crop = Bbox.from_extents(tight.x0-pad, tight.y0-pad, tight.x1+pad, tight.y1+pad)
    inactive_ticks = set()
    for ax in fig.axes:
        for axis, limits in [(ax.xaxis, ax.get_xlim()), (ax.yaxis, ax.get_ylim())]:
            lo, hi = sorted(limits)
            for tick in axis.get_major_ticks():
                if not lo-1e-9 <= tick.get_loc() <= hi+1e-9:
                    inactive_ticks.update([id(tick.label1),id(tick.label2)])
    for artist in fig.findobj(match=Text):
        if artist.get_visible() and artist.get_text() and id(artist) not in inactive_ticks:
            assert artist.get_fontfamily() == ['Arial']
            bb = artist.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())
            # Some invisible axis-offset text is not part of the rendered view.
            if bb.width and bb.height:
                assert bb.x0 >= crop.x0-1e-6 and bb.x1 <= crop.x1+1e-6, (stem,artist.get_text(),bb.bounds,crop.bounds)
                assert bb.y0 >= crop.y0-1e-6 and bb.y1 <= crop.y1+1e-6, (stem,artist.get_text(),bb.bounds,crop.bounds)
    for fonttype, folder in [('path', target), ('none', FIGURES/'editable_text'/target.name)]:
        folder.mkdir(parents=True, exist_ok=True)
        with plt.rc_context({'svg.fonttype':fonttype}):
            fig.savefig(folder/f'{stem}.svg', transparent=True, facecolor='none', edgecolor='none', bbox_inches=crop)
        svg = ET.parse(folder/f'{stem}.svg').getroot()
        assert not svg.findall('.//{http://www.w3.org/2000/svg}image')
        assert list(map(float, svg.attrib['viewBox'].split()))[:2] == [0, 0]
        if fonttype == 'path':
            assert not svg.findall('.//{http://www.w3.org/2000/svg}text')
    preview = FIGURES/'previews'/target.name
    preview.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview/f'{stem}.png', dpi=180, transparent=True, facecolor='none', edgecolor='none', bbox_inches=crop)
    AUDIT.append(dict(panel=stem, outlined_svg=str(target/f'{stem}.svg'), editable_svg=str(FIGURES/'editable_text'/target.name/f'{stem}.svg'),
                      font='Arial', transparent=True, vector_only=True, viewBox_origin=[0,0], pad_pt=pad*72, **info))
    plt.close(fig)
    print('SAVED '+stem, flush=True)


def bars(mod, metrics):
    row = metrics[metrics.Modality.eq(mod) & metrics.Model.eq('ARGScope') & metrics.Level.eq('Subtype')
                  & metrics.Completeness.eq(100) & metrics.Average.eq('macro')].iloc[0]
    assert row.N_labels_averaged == 821
    values = row[FIELDS].to_numpy(float)
    color = '#8FC4BC' if mod == 'Protein' else '#BDD8EB'
    hatch = '--' if mod == 'Protein' else '//'
    fig, ax = plt.subplots(figsize=(4.6,4.0))
    fig.subplots_adjust(left=.145, right=.98, bottom=.225, top=.90)
    x = np.arange(5)
    marks = ax.bar(x, values, width=.44, color=color, edgecolor='#6B858A', linewidth=.65, hatch=hatch, zorder=3)
    ax.set_xlim(-.58,4.58)
    ax.set_ylim(0,1.055)
    ax.set_xticks(x, ['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC'], fontsize=11)
    ax.set_yticks(np.linspace(0,1,6),[f'{v:.1f}' for v in np.linspace(0,1,6)])
    ax.set_ylabel('Score',fontsize=12,labelpad=6)
    ax.tick_params(axis='x', length=0,pad=7)
    ax.tick_params(axis='y', length=3.2,width=.7,labelsize=10.5)
    ax.set_axisbelow(True)
    ax.grid(axis='y',color='#E9EDF0',linewidth=.65)
    ax.spines[['top','right']].set_visible(False)
    for side in ['left','bottom']:
        ax.spines[side].set_linewidth(.75)
        ax.spines[side].set_color('#626B70')
    for bar, value in zip(marks, values):
        assert bar.get_height() == value
        ax.text(bar.get_x()+bar.get_width()/2,value+.018,f'{value:.4f}',ha='center',va='bottom',fontsize=10,clip_on=False)
    name = 'ARGScope-AA' if mod == 'Protein' else 'ARGScope-NT'
    ax.legend(handles=[Patch(facecolor=color, edgecolor='#6B858A', linewidth=.65,hatch=hatch,label=f'{name} (Subtype)')],
              loc='lower center',bbox_to_anchor=(.5,1.005),frameon=False,fontsize=11.5,
              handlelength=1.7,handletextpad=.6,borderaxespad=0)
    row.to_frame().T.to_csv(FIGURES/'plot_data'/mod/'B_subtype_macro_values.csv',index=False)
    save(fig,mod,'B','100pct_Subtype_including_nonARG',dict(n_labels=821,nonARG_included=True,values=dict(zip(FIELDS,values))))


def heatmap(mod, metrics, per, display):
    models = previous.MODELS[mod]
    part = per[per.Modality.eq(mod) & per.Completeness.eq(100) & per.Included_in_average].copy()
    assert len(part) == 24*len(models)
    own = part[part.Model.eq('ARGScope')].set_index('Type')
    shown = []
    for typ in ORDER:
        other = part[part.Type.eq(typ) & part.Model.ne('ARGScope')]
        # Preserve the previous display-only suppression of zero profiles.
        if own.loc[typ,TYPE_METRICS].sum() == 0 or other[TYPE_METRICS].to_numpy().sum() == 0:
            continue
        shown.append(typ)
    shown.append('nonARG')
    averages = metrics[metrics.Modality.eq(mod) & metrics.Completeness.eq(100) & metrics.Level.eq('Type')
                       & metrics.Average.eq('macro')].set_index('Model')
    assert averages.N_labels_averaged.eq(24).all()
    for model in models:
        np.testing.assert_allclose(part[part.Model.eq(model)][TYPE_METRICS].mean(),averages.loc[model,TYPE_METRICS].to_numpy(float),atol=1e-12,rtol=0)
    n, nm = len(shown), len(models)
    cw, ch, left, bottom, top = .55,.30,1.79,1.22,.34
    gap, avg_gap, color_gap, color_w, right = .135,.20,.14,.10,.49
    pw, hh = nm*cw, n*ch
    total_h = hh+avg_gap+ch
    width = left+3*pw+2*gap+color_gap+color_w+right
    height = bottom+total_h+top
    fig = plt.figure(figsize=(width,height))
    cmap = plt.get_cmap('Blues' if mod=='Protein' else 'Oranges')
    artists, rows = [], []
    for k, metric in enumerate(TYPE_METRICS):
        px = left+k*(pw+gap)
        ax = fig.add_axes([px/width,bottom/height,pw/width,hh/height])
        av = fig.add_axes([px/width,(bottom+hh+avg_gap)/height,pw/width,ch/height])
        vals = np.array([[part[(part.Type==typ)&(part.Model==model)].iloc[0][metric] for model in models] for typ in shown])
        avg = np.array([[averages.loc[model,metric] for model in models]])
        for a, arr, is_avg in [(ax,vals,False),(av,avg,True)]:
            for (i,j),v in np.ndenumerate(arr):
                a.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=cmap(float(v)),edgecolor='white',lw=.8,zorder=0))
                rgb=np.array(cmap(v)[:3])
                linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
                color='white' if float(linear@np.array([.2126,.7152,.0722]))<.20 else '#20282E'
                text=a.text(j,i,f'{v:.4f}',ha='center',va='center',fontsize=10.5,color=color)
                artists.append((a,text,j,i))
                rows.append(dict(Modality=mod,Metric=metric,Type='Average' if is_avg else shown[i],Model=models[j],Value=float(v)))
            a.set_xlim(-.5,nm-.5)
            a.set_ylim(arr.shape[0]-.5,-.5)
            a.tick_params(which='both',length=0)
            for spine in a.spines.values(): spine.set_visible(False)
        av.set_title(metric,fontsize=15,pad=7)
        av.set_xticks([])
        av.set_yticks([0],['Average'] if k==0 else [''],fontsize=13)
        ax.set_yticks(range(n),[display[t] for t in shown] if k==0 else ['']*n,fontsize=13)
        ax.tick_params(axis='y',pad=6)
        ax.set_xticks(range(nm),models,rotation=55,ha='right',rotation_mode='anchor',fontsize=12)
        ax.tick_params(axis='x',pad=4)
        for tick in ax.get_xticklabels():
            if tick.get_text()=='ARGScope': tick.set_color('#AD4635'); tick.set_fontweight('bold')
    cax=fig.add_axes([(left+3*pw+2*gap+color_gap)/width,bottom/height,color_w/width,total_h/height])
    scalar=matplotlib.cm.ScalarMappable(norm=matplotlib.colors.Normalize(0,1),cmap=cmap)
    cb=fig.colorbar(scalar,cax=cax,ticks=[0,.25,.5,.75,1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=10.5,length=2,width=.5,pad=3)
    cb.outline.set_linewidth(.5)
    cb.solids.set_rasterized(False)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for a,text,j,i in artists:
        b=text.get_window_extent(renderer)
        c=a.transData.transform([[j-.5,i-.5],[j+.5,i+.5]])
        assert b.x0>c[:,0].min() and b.x1<c[:,0].max()
        assert b.y0>c[:,1].min() and b.y1<c[:,1].max()
    pd.DataFrame(rows).to_csv(FIGURES/'plot_data'/mod/'C_heatmap_values.csv',index=False)
    save(fig,mod,'C','100pct_Type_heatmap_including_nonARG',dict(shown_types=shown,n_averaged_labels=24,
             nonARG_row_displayed=True,average_includes_nonARG=True,cell_font_pt=10.5,type_font_pt=13))


def errors(mod):
    raw = pd.read_csv(DATA/mod/'ARGScope_100pct_sequence_evaluation.csv',keep_default_na=False)
    counts=pd.crosstab(raw.true_type,raw.predicted_type).reindex(index=LABELS,columns=LABELS,fill_value=0)
    assert counts.to_numpy().sum()==len(raw)==4574
    den=counts.sum(axis=1).to_numpy()
    norm=np.divide(counts.to_numpy(float),den[:,None],out=np.zeros_like(counts.to_numpy(float)),where=den[:,None]!=0)
    wrong=counts.to_numpy().copy()
    np.fill_diagonal(wrong,0)
    norm=pd.DataFrame(norm,index=LABELS,columns=LABELS)
    wrong=pd.DataFrame(wrong,index=LABELS,columns=LABELS)
    root=FIGURES/'plot_data'/mod
    counts.to_csv(root/'E_full_24class_confusion_counts.csv')
    norm.to_csv(root/'E_row_normalized_24classes.csv')
    wrong.to_csv(root/'F_off_diagonal_24classes.csv')
    error=raw[raw.true_subtype.ne(raw.predicted_subtype)].copy()
    error['Type_correct_count']=error.true_type.eq(error.predicted_type).astype(int)
    keys=['true_subtype','predicted_subtype','true_type','predicted_type']
    pairs=error.groupby(keys).agg(Count=('sequence_id','size'),Type_correct_count=('Type_correct_count','sum')).reset_index()
    pairs['Type_correct_percent']=pairs.Type_correct_count/pairs.Count*100
    pairs=pairs.sort_values(['Count']+keys,ascending=[False,True,True,True,True],kind='stable').reset_index(drop=True)
    assert pairs.Count.sum()==len(error)
    pairs.to_csv(root/'G_all_subtype_error_pairs_including_nonARG.csv',index=False)
    pairs.head(20).to_csv(root/'G_top20_subtype_error_pairs.csv',index=False)
    return raw,norm,wrong,pairs.head(20)


def matrix(mod,frame,kind,display):
    is_error=kind=='errors'
    n=len(LABELS)
    array=frame.to_numpy(float)
    vmax=max(1,float(array.max())) if is_error else 1
    cmap=plt.get_cmap('Blues' if mod=='Protein' else 'Oranges').copy()
    if is_error:
        array=np.ma.array(array,mask=np.eye(n,dtype=bool)); cmap.set_bad('#eeeeee')
    fig=plt.figure(figsize=(7.7,7.6))
    ax=fig.add_axes([.245,.26,.66,.669])
    im=ax.pcolormesh(np.arange(n+1)-.5,np.arange(n+1)-.5,array,cmap=cmap,vmin=0,vmax=vmax,
                    rasterized=False,shading='flat',linewidth=0)
    ax.set_xlim(-.5,n-.5); ax.set_ylim(n-.5,-.5); ax.set_aspect('equal')
    ax.set_xticks(range(n),[display[t] for t in LABELS],rotation=58,ha='right',rotation_mode='anchor',fontsize=10.5)
    ax.set_yticks(range(n),[display[t] for t in LABELS],fontsize=10.5)
    ax.tick_params(length=2,pad=2)
    ax.set_xlabel('Predicted Type',fontsize=13,labelpad=5)
    ax.set_ylabel('True Type',fontsize=13,labelpad=5)
    cax=fig.add_axes([.923,.26,.019,.669])
    cb=fig.colorbar(im,cax=cax)
    cb.solids.set_rasterized(False); cb.ax.tick_params(labelsize=10,length=2); cb.outline.set_linewidth(.6)
    if is_error:
        cb.locator=MaxNLocator(nbins=5,integer=True); cb.update_ticks(); cb.set_label('Count',fontsize=12,labelpad=5)
    else:
        cb.set_ticks([0,.25,.5,.75,1]); cb.ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
        cb.set_label('Proportion',fontsize=12,labelpad=5)
    fig.canvas.draw()
    previous.no_overlap(ax.get_yticklabels(),fig.canvas.get_renderer(),'Matrix label collision')
    save(fig,mod,'F' if is_error else 'E','100pct_Type_'+kind+'_including_nonARG',dict(n_labels=24,
         nonARG_row_and_column_displayed=True,computed_from_all_4574_test_sequences=True))


def main():
    font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':11,'svg.fonttype':'path','pdf.fonttype':42,
        'axes.linewidth':.75,'hatch.linewidth':.55,'figure.facecolor':'none','axes.facecolor':'none',
        'savefig.facecolor':'none','savefig.transparent':True,'text.color':'#20282E'})
    FIGURES.mkdir(parents=True,exist_ok=True)
    metrics=pd.read_csv(DATA/'all_metrics_including_nonARG.csv')
    per=pd.read_csv(DATA/'per_type_including_nonARG.csv')
    palette=pd.read_csv(PALETTE_PATH)
    display=dict(zip(palette.Type,palette.Display)); display['nonARG']='Non-ARG'
    previous.OUT=FIGURES
    previous.source=source
    previous.save=save
    for mod in ['Protein','DNA']:
        (FIGURES/'plot_data'/mod).mkdir(parents=True,exist_ok=True)
        previous.radar(mod)
        bars(mod,metrics)
        heatmap(mod,metrics,per,display)
        raw,norm,wrong,top=errors(mod)
        matrix(mod,norm,'confusion',display)
        matrix(mod,wrong,'errors',display)
        before=len(AUDIT)
        previous.subtype_errors(mod,top)
        AUDIT[before].update(values_unchanged=False,reference_ARG_only=False,reference_nonARG_included=True)
        previous.umap(mod,palette,raw[raw.true_type.ne('nonARG')])
        AUDIT[-1]['scope']='ARG-only UMAP visualization. Existing coordinates retained, not a metric calculation.'
        assert len(list((FIGURES/f'Figure{2 if mod=="Protein" else 3}_{mod}').glob('*.svg')))==7
    (FIGURES/'plot_data/panel_verification.json').write_text(json.dumps(AUDIT,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS: 14 outlined SVG panels and 14 editable-text alternatives.',flush=True)


if __name__=='__main__':
    main()
