@echo off
setlocal
chcp 65001 >nul
set "PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
pushd "%~dp0"
if not exist "%PY%" goto missing_python

"%PY%" -u "full\01_gated_fusion_full.py"
if errorlevel 1 goto failed
"%PY%" -u "full\02_raw_prototypes_full.py"
if errorlevel 1 goto failed
"%PY%" -u "full\03_refine_gat_full.py"
if errorlevel 1 goto failed
"%PY%" -u "full\04_protein_student_full.py"
if errorlevel 1 goto failed
"%PY%" -u "full\05_dna_student_full.py"
if errorlevel 1 goto failed

echo.
echo FULL PIPELINE COMPLETED.
pause
exit /b 0

:missing_python
echo Python not found: %PY%
pause
exit /b 2

:failed
echo.
echo FULL PIPELINE STOPPED AFTER AN ERROR.
pause
exit /b 1
