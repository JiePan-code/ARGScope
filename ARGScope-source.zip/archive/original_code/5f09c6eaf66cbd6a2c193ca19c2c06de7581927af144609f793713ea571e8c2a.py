#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Rebuild a leakage-aware BGC/nonBGC dataset from authoritative MIBiG v4 fields.

The source files are read-only. Outputs are written under ``BGC_corrected_files``
next to this script.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


SOURCE_ROOT = Path(r"E:\1. ARGmodel\BGC数据处理")
FINAL_ROOT = SOURCE_ROOT / "BGC数据" / "BGC最终数据"
DNA_INPUT = FINAL_ROOT / "final_equal_BGC_nonBGC_dna.fasta"
PROTEIN_INPUT = FINAL_ROOT / "final_equal_BGC_nonBGC_protein.fasta"
LABEL_INPUT = FINAL_ROOT / "final_equal_BGC_nonBGC_id_type_subtype.csv"
PROTEIN_TO_BGC_INPUT = FINAL_ROOT / "mibig_id_type_subtype.csv"
MIBIG_JSON_DIR = SOURCE_ROOT / "mibig_json_4.0"

OUTPUT_DIR = Path(__file__).with_name("BGC_corrected_files")
DNA_OUTPUT = OUTPUT_DIR / "corrected_BGC_nonBGC_dna.fasta"
PROTEIN_OUTPUT = OUTPUT_DIR / "corrected_BGC_nonBGC_protein.fasta"
LABEL_OUTPUT = OUTPUT_DIR / "corrected_BGC_nonBGC_id_type_subtype.csv"
SUMMARY_OUTPUT = OUTPUT_DIR / "corrected_BGC_nonBGC_summary.json"

MIN_TRANSLATION_IDENTITY = 0.99
MIN_BGC_GROUPS_PER_SUBTYPE = 2
NONBGC_SELECTION_SEED = "20260915"

DNA_ALLOWED = set("ACGTUNRYKMSWBDHV-")
PROTEIN_ALLOWED = set("ABCDEFGHIKLMNPQRSTVWXYZJUO*-")
CLASS_ORDER = {name: index for index, name in enumerate(
    ["PKS", "NRPS", "RiPP", "Terpene", "Saccharide", "Other"]
)}

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L","TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*","TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L","CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q","CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M","ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K","AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V","GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E","GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}


@dataclass(frozen=True)
class Record:
    seq_id: str
    dna: str
    protein: str
    type_name: str
    subtype: str
    source: str
    group_id: str
    input_order: int

    @property
    def label(self) -> tuple[str, str, str]:
        return self.type_name, self.subtype, self.source


def clean_text(value: object) -> str:
    return " ".join(str(value or "").replace("_", " ").split()).strip()


def clean_subclass(value: object) -> str:
    text = clean_text(value)
    if not text or text.lower() == "unknown":
        return "Unclassified"
    if text.lower() == "other":
        return "Other"
    return text


def normalize_class(value: object) -> str:
    text = clean_text(value).lower()
    mapping = {
        "pks": "PKS",
        "polyketide": "PKS",
        "nrps": "NRPS",
        "nrp": "NRPS",
        "ribosomal": "RiPP",
        "ripp": "RiPP",
        "terpene": "Terpene",
        "saccharide": "Saccharide",
        "other": "Other",
        "alkaloid": "Other",
    }
    return mapping.get(text, "")


def make_taxonomy(data: dict) -> tuple[str, str] | None:
    raw_classes = data.get("biosynthesis", {}).get("classes", [])
    if not isinstance(raw_classes, list):
        return None
    components: set[tuple[str, str]] = set()
    for item in raw_classes:
        if not isinstance(item, dict):
            continue
        major = normalize_class(item.get("class"))
        if not major:
            continue
        components.add((major, clean_subclass(item.get("subclass"))))
    if not components:
        return None

    ordered = sorted(components, key=lambda item: (CLASS_ORDER.get(item[0], 99), item[1].lower()))
    majors = sorted({major for major, _ in ordered}, key=lambda name: CLASS_ORDER.get(name, 99))
    if len(majors) == 1:
        major = majors[0]
        subclasses = sorted({sub for _, sub in ordered}, key=str.lower)
        subtype = f"{major} | {' + '.join(subclasses)}"
        return major, subtype

    component_text = " + ".join(f"{major}:{subclass}" for major, subclass in ordered)
    return "Hybrid", f"Hybrid | {component_text}"


def load_mibig_taxonomy() -> tuple[dict[str, tuple[str, str]], dict[str, dict[str, str]], Counter]:
    active_taxonomy: dict[str, tuple[str, str]] = {}
    metadata: dict[str, dict[str, str]] = {}
    status_counts = Counter()
    for path in sorted(MIBIG_JSON_DIR.glob("BGC*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        bgc_id = clean_text(data.get("accession")) or path.stem
        status = clean_text(data.get("status")) or "missing"
        quality = clean_text(data.get("quality")) or "missing"
        completeness = clean_text(data.get("completeness")) or "missing"
        status_counts[status] += 1
        metadata[bgc_id] = {
            "status": status,
            "quality": quality,
            "completeness": completeness,
        }
        taxonomy = make_taxonomy(data)
        if status.lower() == "active" and taxonomy is not None:
            active_taxonomy[bgc_id] = taxonomy
    return active_taxonomy, metadata, status_counts


def read_fasta(path: Path) -> tuple[dict[str, str], list[str]]:
    records: dict[str, str] = {}
    order: list[str] = []
    header: str | None = None
    chunks: list[str] = []

    def commit() -> None:
        nonlocal header, chunks
        if header is None:
            return
        seq_id = header.split()[0]
        if seq_id in records:
            raise ValueError(f"Duplicate FASTA ID in {path}: {seq_id}")
        records[seq_id] = "".join(chunks).replace(" ", "").upper()
        order.append(seq_id)

    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith(">"):
                commit()
                header = line[1:].strip()
                chunks = []
            else:
                if header is None:
                    raise ValueError(f"Sequence before first FASTA header in {path}")
                chunks.append(line)
        commit()
    return records, order


def translate(dna: str) -> str:
    dna = dna.upper().replace("U", "T").replace("-", "")
    return "".join(CODON_TABLE.get(dna[index:index+3], "X") for index in range(0, len(dna) - 2, 3))


def translation_identity(dna: str, protein: str) -> float:
    predicted = translate(dna).rstrip("*")
    observed = protein.upper().replace("-", "").rstrip("*")
    denominator = max(len(predicted), len(observed))
    if denominator == 0:
        return 0.0
    comparable = min(len(predicted), len(observed))
    matches = 0
    for index in range(comparable):
        expected = predicted[index]
        actual = observed[index]
        if index == 0 and actual == "M" and expected in {"M", "V", "L", "I"}:
            matches += 1
        elif expected == actual or expected == "X" or actual == "X":
            matches += 1
    return matches / denominator


def load_labels() -> list[dict[str, str]]:
    with LABEL_INPUT.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = []
        for row in csv.DictReader(handle):
            rows.append({str(key).strip().lower(): (value or "").strip() for key, value in row.items()})
    return rows


def load_protein_to_bgc(final_bgc_ids: set[str]) -> tuple[dict[str, str], set[str]]:
    candidates: dict[str, set[str]] = defaultdict(set)
    with PROTEIN_TO_BGC_INPUT.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            protein_id = (row.get("protein_id") or "").strip()
            if protein_id not in final_bgc_ids:
                continue
            bgc_id = (row.get("bgc_base") or "").strip()
            if not bgc_id:
                bgc_id = (row.get("bgc_id") or "").split(".")[0].strip()
            if bgc_id:
                candidates[protein_id].add(bgc_id)
    ambiguous = {protein_id for protein_id, values in candidates.items() if len(values) != 1}
    mapping = {protein_id: next(iter(values)) for protein_id, values in candidates.items() if len(values) == 1}
    return mapping, ambiguous


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))
        self.rank = [0] * size

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root == right_root:
            return
        if self.rank[left_root] < self.rank[right_root]:
            left_root, right_root = right_root, left_root
        self.parent[right_root] = left_root
        if self.rank[left_root] == self.rank[right_root]:
            self.rank[left_root] += 1


def deduplicate(records: list[Record]) -> tuple[list[Record], dict[str, int]]:
    union_find = UnionFind(len(records))
    seen_dna: dict[str, int] = {}
    seen_protein: dict[str, int] = {}
    for index, record in enumerate(records):
        dna_hash = hashlib.sha256(record.dna.encode("ascii", errors="replace")).hexdigest()
        protein_hash = hashlib.sha256(record.protein.encode("ascii", errors="replace")).hexdigest()
        if dna_hash in seen_dna:
            union_find.union(index, seen_dna[dna_hash])
        else:
            seen_dna[dna_hash] = index
        if protein_hash in seen_protein:
            union_find.union(index, seen_protein[protein_hash])
        else:
            seen_protein[protein_hash] = index

    components: dict[int, list[int]] = defaultdict(list)
    for index in range(len(records)):
        components[union_find.find(index)].append(index)

    keep_indices = []
    conflicting_components = 0
    conflicting_records = 0
    same_label_duplicate_components = 0
    same_label_duplicate_records_removed = 0
    for indices in components.values():
        labels = {records[index].label for index in indices}
        if len(labels) > 1:
            conflicting_components += 1
            conflicting_records += len(indices)
            continue
        representative = min(indices, key=lambda index: (records[index].input_order, records[index].seq_id))
        keep_indices.append(representative)
        if len(indices) > 1:
            same_label_duplicate_components += 1
            same_label_duplicate_records_removed += len(indices) - 1

    deduplicated = [records[index] for index in sorted(keep_indices, key=lambda i: records[i].input_order)]
    return deduplicated, {
        "conflicting_duplicate_components_removed": conflicting_components,
        "records_removed_in_conflicting_components": conflicting_records,
        "same_label_duplicate_components_collapsed": same_label_duplicate_components,
        "same_label_duplicate_records_removed": same_label_duplicate_records_removed,
    }


def deterministic_key(record: Record) -> str:
    text = f"{NONBGC_SELECTION_SEED}|{record.seq_id}"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_fasta(records: list[Record], path: Path, attribute: str) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            sequence = getattr(record, attribute)
            handle.write(f">{record.seq_id}\n")
            for index in range(0, len(sequence), 80):
                handle.write(sequence[index:index+80] + "\n")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    labels = load_labels()
    label_ids = [row["id"] for row in labels]
    if len(label_ids) != len(set(label_ids)):
        raise ValueError("Input label CSV contains duplicate IDs")

    dna, dna_order = read_fasta(DNA_INPUT)
    protein, protein_order = read_fasta(PROTEIN_INPUT)
    if label_ids != dna_order or label_ids != protein_order:
        raise ValueError("Input DNA, protein, and label IDs are not in identical order")

    final_bgc_ids = {row["id"] for row in labels if row["source"].lower() == "bgc"}
    protein_to_bgc, ambiguous_mapping_ids = load_protein_to_bgc(final_bgc_ids)
    active_taxonomy, mibig_metadata, mibig_status_counts = load_mibig_taxonomy()

    drop_reasons = Counter()
    status_of_mapped_bgc_records = Counter()
    quality_of_kept_bgc_records = Counter()
    candidates: list[Record] = []

    for input_order, row in enumerate(labels):
        seq_id = row["id"]
        dna_sequence = dna[seq_id]
        protein_sequence = protein[seq_id]
        if not dna_sequence or not protein_sequence:
            drop_reasons["empty_sequence"] += 1
            continue
        if set(dna_sequence) - DNA_ALLOWED or set(protein_sequence) - PROTEIN_ALLOWED:
            drop_reasons["illegal_sequence_character"] += 1
            continue
        identity = translation_identity(dna_sequence, protein_sequence)
        if identity < MIN_TRANSLATION_IDENTITY:
            drop_reasons["dna_protein_translation_identity_below_0.99"] += 1
            continue

        if row["source"].lower() == "bgc":
            if seq_id in ambiguous_mapping_ids:
                drop_reasons["ambiguous_protein_to_bgc_mapping"] += 1
                continue
            bgc_id = protein_to_bgc.get(seq_id)
            if not bgc_id:
                drop_reasons["missing_protein_to_bgc_mapping"] += 1
                continue
            metadata = mibig_metadata.get(bgc_id)
            if metadata is None:
                drop_reasons["missing_mibig_json"] += 1
                continue
            status_of_mapped_bgc_records[metadata["status"]] += 1
            taxonomy = active_taxonomy.get(bgc_id)
            if taxonomy is None:
                if metadata["status"].lower() != "active":
                    drop_reasons[f"mibig_status_{metadata['status'].lower()}"] += 1
                else:
                    drop_reasons["missing_authoritative_biosynthesis_class"] += 1
                continue
            type_name, subtype = taxonomy
            quality_of_kept_bgc_records[metadata["quality"]] += 1
            group_id = bgc_id
            source = "BGC"
        else:
            type_name = "nonBGC"
            subtype = "nonBGC"
            source = "nonBGC"
            group_id = f"nonBGC:{seq_id}"

        candidates.append(Record(
            seq_id=seq_id,
            dna=dna_sequence,
            protein=protein_sequence,
            type_name=type_name,
            subtype=subtype,
            source=source,
            group_id=group_id,
            input_order=input_order,
        ))

    deduplicated, duplicate_stats = deduplicate(candidates)

    bgc_groups_by_subtype: dict[str, set[str]] = defaultdict(set)
    for record in deduplicated:
        if record.source == "BGC":
            bgc_groups_by_subtype[record.subtype].add(record.group_id)
    eligible_bgc_subtypes = {
        subtype for subtype, groups in bgc_groups_by_subtype.items()
        if len(groups) >= MIN_BGC_GROUPS_PER_SUBTYPE
    }
    rare_subtype_records_removed = sum(
        1 for record in deduplicated
        if record.source == "BGC" and record.subtype not in eligible_bgc_subtypes
    )

    bgc_records = [
        record for record in deduplicated
        if record.source == "BGC" and record.subtype in eligible_bgc_subtypes
    ]
    nonbgc_records = [record for record in deduplicated if record.source == "nonBGC"]
    if len(nonbgc_records) < len(bgc_records):
        raise ValueError(
            f"Only {len(nonbgc_records)} clean nonBGC records for {len(bgc_records)} clean BGC records"
        )
    selected_nonbgc_ids = {
        record.seq_id for record in sorted(nonbgc_records, key=deterministic_key)[:len(bgc_records)]
    }
    selected_nonbgc = [record for record in nonbgc_records if record.seq_id in selected_nonbgc_ids]

    final_records = sorted(bgc_records + selected_nonbgc, key=lambda record: record.input_order)
    write_fasta(final_records, DNA_OUTPUT, "dna")
    write_fasta(final_records, PROTEIN_OUTPUT, "protein")
    with LABEL_OUTPUT.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "type", "subtype", "source", "group_id"])
        writer.writeheader()
        for record in final_records:
            writer.writerow({
                "id": record.seq_id,
                "type": record.type_name,
                "subtype": record.subtype,
                "source": record.source,
                "group_id": record.group_id,
            })

    type_counts = Counter(record.type_name for record in final_records)
    subtype_counts = Counter(record.subtype for record in final_records)
    final_group_counts: dict[str, set[str]] = defaultdict(set)
    subtype_to_types: dict[str, set[str]] = defaultdict(set)
    for record in final_records:
        final_group_counts[record.subtype].add(record.group_id)
        subtype_to_types[record.subtype].add(record.type_name)

    summary = {
        "source_files_unchanged": True,
        "input": {
            "total_records": len(labels),
            "BGC_records": sum(row["source"].lower() == "bgc" for row in labels),
            "nonBGC_records": sum(row["source"].lower() == "nonbgc" for row in labels),
        },
        "rules": {
            "taxonomy_source": "MIBiG v4 biosynthesis.classes[].class/subclass only",
            "MIBiG_status": "active only",
            "minimum_translation_identity": MIN_TRANSLATION_IDENTITY,
            "duplicate_rule": "identical DNA or protein: remove all cross-label components; collapse same-label components",
            "minimum_distinct_BGC_groups_per_subtype": MIN_BGC_GROUPS_PER_SUBTYPE,
            "nonBGC_selection_seed": NONBGC_SELECTION_SEED,
            "split_guidance": "split by group_id, never by individual sequence ID",
        },
        "mapped_MIBiG_status_counts_before_status_filter": dict(status_of_mapped_bgc_records.most_common()),
        "kept_BGC_quality_counts_before_later_filters": dict(quality_of_kept_bgc_records.most_common()),
        "all_local_MIBiG_status_counts": dict(mibig_status_counts.most_common()),
        "drop_reasons_before_deduplication": dict(drop_reasons.most_common()),
        "deduplication": duplicate_stats,
        "rare_subtype_records_removed": rare_subtype_records_removed,
        "eligible_BGC_subtype_count": len(eligible_bgc_subtypes),
        "output": {
            "total_records": len(final_records),
            "BGC_records": len(bgc_records),
            "nonBGC_records": len(selected_nonbgc),
            "balanced_BGC_nonBGC": len(bgc_records) == len(selected_nonbgc),
            "type_count": len(type_counts),
            "type_counts": dict(type_counts.most_common()),
            "subtype_count": len(subtype_counts),
            "subtype_counts": dict(subtype_counts.most_common()),
            "distinct_group_counts_by_subtype": {
                subtype: len(groups) for subtype, groups in sorted(final_group_counts.items())
            },
            "subtype_to_type_conflict_count": sum(len(types) > 1 for types in subtype_to_types.values()),
            "DNA_path": str(DNA_OUTPUT),
            "protein_path": str(PROTEIN_OUTPUT),
            "label_path": str(LABEL_OUTPUT),
        },
    }
    SUMMARY_OUTPUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
