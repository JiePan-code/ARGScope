"""Draw the two binary radar panels using only the supplied DOCX table values.

The reported values are retained exactly. No recalculation or averaging
harmonization is performed. Output SVG text is editable Arial text.
"""

from pathlib import Path
import csv
import hashlib
import json
import math
import re
import zipfile
import xml.etree.ElementTree as ET

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
DOCX = Path(r"C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/Supplementary_materials.docx")
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
FIELDS = ["ACC", "Precision", "Recall", "F1", "MCC"]
MODELS = {
    "Protein": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
    "DNA": ["ARGNet", "DeepARG", "ARGScope"],
}
TABLES = {
    ("Protein", "ARGNet"): 7,
    ("Protein", "DeepARG"): 15,
    ("Protein", "PLM-ARG"): 13,
    ("Protein", "FunGeneTyper"): 11,
    ("Protein", "ARGScope"): 1,
    ("DNA", "ARGNet"): 9,
    ("DNA", "DeepARG"): 17,
    ("DNA", "ARGScope"): 4,
}
# These are the colors and line styles of the supplied, previous radar panels.
STYLES = {
    "ARGNet": ("#89949E", "--", "s"),
    "DeepARG": ("#8472B0", "-.", "D"),
    "PLM-ARG": ("#BDA364", ":", "^"),
    "FunGeneTyper": ("#64A598", "--", "v"),
    "ARGScope": ("#CF4877", "-", "o"),
}
NAMES = {
    "Protein": "Figure3A_ARGScope_AA_binary",
    "DNA": "Figure4A_ARGScope_NT_binary",
}


def text_of(element):
    return "".join(node.text or "" for node in element.findall(".//w:t", NS)).strip()


def read_reported_tables():
    with zipfile.ZipFile(DOCX) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    body = root.find("w:body", NS)
    result = {}
    caption = ""
    for element in body:
        if element.tag == f"{{{NS['w']}}}p":
            paragraph = text_of(element)
            if re.match(r"Table S\d+\.", paragraph):
                caption = paragraph
        elif element.tag == f"{{{NS['w']}}}tbl":
            match = re.match(r"Table S(\d+)\.", caption)
            if not match:
                continue
            number = int(match.group(1))
            if number not in TABLES.values():
                continue
            rows = [
                [text_of(cell) for cell in row.findall("w:tc", NS)]
                for row in element.findall("w:tr", NS)
            ]
            headers = rows[0]
            full_length = [row for row in rows[1:] if row[0].strip() == "100%"]
            if len(full_length) != 1:
                raise ValueError(f"Table S{number} has no unique 100% row")
            row = dict(zip(headers, full_length[0]))
            result[number] = {
                "caption": caption,
                "values": [float(row[field]) for field in FIELDS],
                "reported_strings": [row[field].strip() for field in FIELDS],
            }
    if set(result) != set(TABLES.values()):
        raise ValueError("Not all eight required supplementary tables were found")
    return result


def overlap_area(a, b):
    return max(0.0, min(a.x1, b.x1) - max(a.x0, b.x0)) * max(
        0.0, min(a.y1, b.y1) - max(a.y0, b.y0)
    )


def draw_panel(modality, reported):
    # Exactly the same canvas proportions as the previous standalone panel.
    width, height = 439.0, 373.0
    fig = plt.figure(figsize=(width / 72, height / 72), dpi=180)
    center_x, center_y, radius = width / 2, 207.0, 104.0
    ax = fig.add_axes(
        [
            (center_x - radius) / width,
            (center_y - radius) / height,
            2 * radius / width,
            2 * radius / height,
        ],
        projection="polar",
    )
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    theta = np.linspace(0, 2 * np.pi, len(FIELDS), endpoint=False)
    closed_theta = np.r_[theta, theta[0]]
    ax.set_ylim(0, 1)
    ax.set_xticks(theta)
    ax.set_xticklabels([])
    ax.tick_params(axis="x", length=0)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(["0.2", "0.4", "0.6", "0.8", "1.0"], fontsize=10.5, color="black")
    ax.set_rlabel_position(20)
    ax.grid(color="#DEE6EB", linewidth=0.8)
    ax.spines["polar"].set_color("#ADB9C2")
    ax.spines["polar"].set_linewidth(0.9)
    ax.patch.set_alpha(0)

    texts = [
        fig.text(
            0.5,
            351.0 / height,
            "ARG/non-ARG classification",
            ha="center",
            va="center",
            fontsize=18,
            fontweight="bold",
            color="black",
        )
    ]
    labels = ["ACC", "Precision", "Recall", "F1", "MCC"]
    alignments = ["center", "left", "left", "right", "right"]
    for angle, label, alignment in zip(theta, labels, alignments):
        x = center_x + 126.0 * math.sin(angle)
        y = center_y + 126.0 * math.cos(angle)
        texts.append(
            fig.text(
                x / width,
                y / height,
                label,
                ha=alignment,
                va="center",
                fontsize=17,
                color="black",
            )
        )

    checks = []
    for model in MODELS[modality]:
        source = reported[TABLES[(modality, model)]]
        values = np.array(source["values"], dtype=float)
        color, style, marker = STYLES[model]
        line, = ax.plot(
            closed_theta,
            np.r_[values, values[0]],
            color=color,
            linestyle=style,
            marker=marker,
            linewidth=2.1 if model == "ARGScope" else 1.45,
            markersize=4.5 if model == "ARGScope" else 4,
            markeredgewidth=0.5,
            label=model,
            clip_on=False,
            zorder=5 if model == "ARGScope" else 3,
        )
        if model == "ARGScope":
            ax.fill(closed_theta, np.r_[values, values[0]], color=color, alpha=0.055, zorder=1)
        assert np.array_equal(line.get_ydata()[:-1], values)
        checks.append(
            {
                "model": model,
                "table": f"S{TABLES[(modality, model)]}",
                "values": dict(zip(FIELDS, source["reported_strings"])),
                "curve_matches_reported_values": True,
            }
        )

    legend = fig.legend(
        *ax.get_legend_handles_labels(),
        loc="upper center",
        bbox_to_anchor=(0.5, 65.0 / height),
        ncol=3,
        fontsize=14,
        frameon=False,
        handlelength=1.4,
        handletextpad=0.35,
        columnspacing=0.9,
        labelspacing=0.6,
        borderaxespad=0,
    )
    for text in legend.get_texts():
        text.set_color("black")
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    checked_artists = texts + [legend]
    for artist in checked_artists:
        box = artist.get_window_extent(renderer)
        if not (
            box.x0 >= bounds.x0 - 0.5
            and box.y0 >= bounds.y0 - 0.5
            and box.x1 <= bounds.x1 + 0.5
            and box.y1 <= bounds.y1 + 0.5
        ):
            raise ValueError(f"Clipped text: {getattr(artist, 'get_text', lambda: 'legend')()}")
    for i, first in enumerate(checked_artists):
        for second in checked_artists[i + 1:]:
            if overlap_area(first.get_window_extent(renderer), second.get_window_extent(renderer)) > 0.5:
                raise ValueError("Overlapping title, axis labels or legend")

    basename = NAMES[modality]
    svg = HERE / f"{basename}.svg"
    preview = HERE / f"{basename}.png"
    description = (
        f"{modality} binary ARG/non-ARG comparison. Values transcribed exactly "
        "from the supplied Supplementary_materials.docx 100% rows. "
        "No recalculation or harmonization of reported averaging conventions. "
        + json.dumps(checks, ensure_ascii=False)
    )
    fig.savefig(
        svg,
        transparent=True,
        metadata={"Title": "ARG/non-ARG classification", "Description": description},
    )
    fig.savefig(preview, dpi=180, facecolor="white", transparent=False)
    plt.close(fig)

    root = ET.parse(svg).getroot()
    strings = " ".join(element.text or "" for element in root.iter() if element.tag.endswith("}text"))
    assert "Macro" not in strings
    assert all(label in strings for label in labels)
    assert not any(element.tag.endswith("}image") for element in root.iter())
    assert root.attrib["viewBox"] == "0 0 439 373"
    return {
        "modality": modality,
        "svg": str(svg),
        "canvas_points": [width, height],
        "editable_text": True,
        "font": "Arial",
        "no_panel_letter": True,
        "label_and_legend_bounds_verified": True,
        "checks": checks,
    }


def main():
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "text.color": "black",
            "axes.labelcolor": "black",
            "xtick.color": "black",
            "ytick.color": "black",
            "svg.fonttype": "none",
            "svg.hashsalt": "ARGScope_reported_binary_20261005",
        }
    )
    reported = read_reported_tables()
    rows = []
    for modality, models in MODELS.items():
        for model in models:
            number = TABLES[(modality, model)]
            source = reported[number]
            rows.append(
                {
                    "Figure": "3A" if modality == "Protein" else "4A",
                    "Modality": modality,
                    "Model": model,
                    "Supplementary_table": f"S{number}",
                    "Condition": "100%",
                    **dict(zip(FIELDS, source["reported_strings"])),
                    "Source_caption": source["caption"],
                }
            )
    with (HERE / "plotted_values_from_supplementary_tables.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    verification = {
        "source_docx": str(DOCX),
        "source_sha256": hashlib.sha256(DOCX.read_bytes()).hexdigest(),
        "policy": "Use the reported supplementary 100% rows exactly; no metric recalculation.",
        "averaging_caution": "S7, S9 and S13 retain reported, non-harmonized binary P/R/F1. The diagrams do not label these as macro or as uniformly ARG-positive.",
        "panels": [draw_panel(modality, reported) for modality in MODELS],
    }
    (HERE / "verification.json").write_text(json.dumps(verification, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(verification, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
