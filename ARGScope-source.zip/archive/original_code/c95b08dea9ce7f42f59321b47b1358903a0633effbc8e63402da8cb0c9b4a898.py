"""Colors-only vector tracing; original pixel-coordinate geometry is unchanged.

Page 1 is a vector-contour facsimile. Its text is outlines. Page 2 is the
independently editable text/shape reconstruction. No bitmap is embedded in either
page. The mapping changes pixel colors only, without resizing/repositioning.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
import json
import copy
from exact_reference import SOURCE, trace_rings, encoded_shape

OUT=Path(__file__).resolve().parent
S=1.5
im=np.asarray(Image.open(SOURCE).convert('RGB')).astype(np.float64)
H,W=im.shape[:2]
lo=im.min(axis=2); hi=im.max(axis=2); sat=hi-lo
lum=im@np.array([.2126,.7152,.0722])
# Training/teacher/student silhouettes and supervision routes share purple.
purple=np.zeros((H,W),bool)
for x1,y1,x2,y2 in [(560,154,650,249),(721,200,842,376),(839,110,1004,383),
                   (1003,64,1149,447),(602,645,799,852),(594,419,795,540)]:
    purple[y1:y2,x1:x2]=True
chromatic=(sat>17)&(lo<247)
neutral=~chromatic | (hi<110) | (lum<75)
alpha=np.clip((255-lo)/190,0,1)
gray_alpha=np.clip((255-lum)/220,0,1)
# 32 luminance levels per family preserve faint connections and antialiasing.
levels=32
alpha=np.rint(alpha*levels)/levels
gray_alpha=np.rint(gray_alpha*levels)/levels
base=np.where(purple[...,None],np.array([150.,115.,166.]),np.array([108.,142.,191.]))
mapped=np.rint(255-(255-base)*alpha[...,None]).clip(0,255).astype(np.uint8)
gray=np.rint(255-255*gray_alpha).clip(0,255).astype(np.uint8)
mapped[neutral]=np.repeat(gray[...,None],3,axis=2)[neutral]
mapped[lo>250]=255

# Tiles follow logical modules while using nonoverlapping source-coordinate
# boundaries. All pixels are represented exactly once; there is no resampling.
regions=[
 ('A_title',0,0,W,55),
 ('paired_sequences',0,55,204,354),
 ('encoders_and_representations',204,55,445,354),
 ('shared_representation',445,55,720,354),
 ('teacher',720,55,842,384),
 ('knowledge_transfer',842,55,1003,446),
 ('training_students',1003,55,W,446),
 ('prototype_title_and_input',0,354,720,386),
 ('prototype_learning',0,386,359,606),
 ('mutual_knn',359,386,590,606),
 ('residual_gat',590,386,801,606),
 ('teacher_graph_return',801,384,842,606),
 ('prototype_notch',720,384,801,386),
 ('A_right_whitespace',842,446,W,606),
 ('A_lower_right_gap',720,354,720,384),
 ('B_title',0,606,W,645),
 ('B_inputs',0,645,241,H),
 ('B_encoders',241,645,406,H),
 ('B_embeddings',406,645,601,H),
 ('B_students',601,645,800,H),
 ('B_annotation',800,645,W,H),
]
# The source's tiny white corridor between 354 and 384 at x720..842 is already
# contained in teacher; check every pixel for duplicate/missing coverage.
cover=np.zeros((H,W),np.uint8)
for _,x1,y1,x2,y2 in regions:cover[y1:y2,x1:x2]+=1
missing=cover==0
if missing.any():
    ys,xs=np.where(missing)
    regions.append(('remaining_canvas',int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)))

src=ET.parse(OUT/'ARGScope_overview_recreated.drawio').getroot()
reconstruction=src.find('diagram')
reconstruction.set('name','2 · Editable text reconstruction')
facsimile=ET.Element('diagram',id='reference-vector-facsimile',name='1 · Faithful vector trace')
model=ET.SubElement(facsimile,'mxGraphModel',dx=str(W*S),dy=str(H*S),grid='0',gridSize='10',guides='1',
    page='1',pageScale='1',pageWidth=str(W*S),pageHeight=str(H*S),background='#FFFFFF',math='0',shadow='0')
root=ET.SubElement(model,'root');ET.SubElement(root,'mxCell',id='0');ET.SubElement(root,'mxCell',id='1',parent='0')
bg=ET.SubElement(root,'mxCell',id='canvas',value='',style='fillColor=#FFFFFF;strokeColor=none;',vertex='1',parent='1')
ET.SubElement(bg,'mxGeometry',x='0',y='0',width=str(W*S),height=str(H*S),attrib={'as':'geometry'})
shape_count=0;contours=0
for name,x1,y1,x2,y2 in regions:
    if x1==x2 or y1==y2:continue
    rgb=mapped[y1:y2,x1:x2]
    packed=rgb[:,:,0].astype(np.int32)*65536+rgb[:,:,1].astype(np.int32)*256+rgb[:,:,2]
    fg=ET.Element('foreground')
    for code in np.unique(packed):
        if code==0xFFFFFF:continue
        mask=packed==code
        if name=='remaining_canvas':mask&=missing[y1:y2,x1:x2]
        if not mask.any():continue
        ET.SubElement(fg,'fillcolor',color=f'#{code:06X}')
        path=ET.SubElement(fg,'path')
        for ring in trace_rings(mask):
            contours+=1
            for i,(x,y) in enumerate(ring):ET.SubElement(path,'move' if i==0 else 'line',x=str(x),y=str(y))
            ET.SubElement(path,'close')
        ET.SubElement(fg,'fill')
    shape=ET.SubElement(root,'mxCell',id=name,value='',style=encoded_shape(name,fg,x2-x1,y2-y1)+'strokeColor=none;fillColor=none;',vertex='1',parent='1')
    ET.SubElement(shape,'mxGeometry',x=str(x1*S),y=str(y1*S),width=str((x2-x1)*S),height=str((y2-y1)*S),attrib={'as':'geometry'})
    shape_count+=1
src.insert(0,facsimile)
ET.indent(src,space='  ')
file=OUT/'ARGScope_reference_exact.drawio'
ET.ElementTree(src).write(file,encoding='utf-8',xml_declaration=True)
single=ET.Element('mxfile',host='Electron',version='30.0.0')
single.append(copy.deepcopy(facsimile))
ET.ElementTree(single).write(OUT/'ARGScope_reference_vector.drawio',encoding='utf-8',xml_declaration=True)
# The pixel-coordinate color-mapping proof is kept for direct visual comparison.
Image.fromarray(mapped).save(OUT/'reference_color_mapping_preview.png')
report={'source_size':[W,H],'geometry_resampled':False,'spatial_color_mapping_only':True,
        'native_vector_regions':shape_count,'outline_contours':contours,
        'embedded_raster_images':0,'pages':['Faithful vector trace (text outlines)','Editable text reconstruction'],
        'color_families':['blue','purple','neutral gray'],'overlap_pixels':int((cover>1).sum()),
        'gap_pixels_filled':int(missing.sum()),'important_note':'Text on page 1 is vector outlines, not editable text strings.'}
(OUT/'faithful_trace_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
