# -*- coding: utf-8 -*-
"""
Read-based FASTQ processing for real data V3.

Function:
1. Recursively find all FASTQ files under RAW_ROOT.
2. Convert each FASTQ to FASTA.
3. Merge R1/R2 FASTA files into one sample-level all_reads.fasta.
4. Keep reads independent. R1 and R2 are NOT concatenated sequence-wise.

Expected input structure:

真实数据V3/
    argbert_1_1.fastq/
        argbert_1_1_kneaddata_paired_1.fastq
    argbert_1_2.fastq/
        argbert_1_1_kneaddata_paired_2.fastq
    argbert_2_1.fastq/
        argbert_2_1_kneaddata_paired_1.fastq
    argbert_2_2.fastq/
        argbert_2_1_kneaddata_paired_2.fastq
    ...
    argscope_6_1.fastq/
        argscope_6_1_kneaddata_paired_1.fastq
    argscope_6_2.fastq/
        argscope_6_1_kneaddata_paired_2.fastq

Main output:

processed_read_based/
    single_fasta/
        argbert_1_1.fasta
        argbert_1_2.fasta
        ...
    merged_fasta/
        argbert_1_all_reads.fasta
        argbert_2_all_reads.fasta
        argbert_3_all_reads.fasta
        argscope_1_all_reads.fasta
        ...
        argscope_6_all_reads.fasta
    logs/
        fastq_file_table.tsv
        single_fasta_read_counts.tsv
        merge_summary.tsv
        merged_fasta_read_counts.tsv
"""

import os
import re
import gzip
import shutil
from pathlib import Path
from collections import defaultdict


# =========================================================
# 1. 修改这里
# =========================================================

# =========================================================
# 1. 修改这里
# =========================================================

RAW_ROOT = r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3"

OUT_ROOT = r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed"


# =========================================================
# 2. 不需要改下面
# =========================================================

FASTQ_SUFFIXES = (".fastq", ".fq", ".fastq.gz", ".fq.gz")

RAW_ROOT = Path(RAW_ROOT)
OUT_ROOT = Path(OUT_ROOT)

SINGLE_FASTA_DIR = OUT_ROOT / "single_fasta"
MERGED_FASTA_DIR = OUT_ROOT / "merged_fasta"
LOG_DIR = OUT_ROOT / "logs"

SINGLE_FASTA_DIR.mkdir(parents=True, exist_ok=True)
MERGED_FASTA_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)


def open_text_maybe_gzip(path: Path):
    if str(path).lower().endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "r", encoding="utf-8", errors="replace")


def sanitize_name(name: str) -> str:
    name = name.strip()
    name = re.sub(r"\.fastq\.gz$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\.fq\.gz$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\.fastq$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\.fq$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"[^\w.\-]+", "_", name)
    return name


def find_fastq_files(raw_root: Path):
    files = []
    for path in raw_root.rglob("*"):
        if path.is_file() and str(path).lower().endswith(FASTQ_SUFFIXES):
            files.append(path)
    return sorted(files, key=lambda p: str(p).lower())


def get_unit_name_from_path(fq_path: Path) -> str:
    """
    优先用外层文件夹名作为单个 read 文件名。

    例如：
    E:/真实数据V3/argbert_1_1.fastq/xxx_paired_1.fastq
    -> unit_name = argbert_1_1

    E:/真实数据V3/argscope_6_2.fastq/xxx_paired_2.fastq
    -> unit_name = argscope_6_2

    这样可以避免里面 fastq 文件名混乱导致样品名错误。
    """
    parent_name = fq_path.parent.name

    if parent_name.lower().endswith((".fastq", ".fq", ".fastq.gz", ".fq.gz")):
        return sanitize_name(parent_name)

    return sanitize_name(fq_path.name)


def infer_sample_name(unit_name: str) -> str:
    """
    从 unit_name 推断样品名。

    argbert_1_1 -> argbert_1
    argbert_1_2 -> argbert_1

    argscope_6_1 -> argscope_6
    argscope_6_2 -> argscope_6
    """
    return re.sub(r"_[12]$", "", unit_name)


def fastq_to_fasta(fq_path: Path, fa_path: Path) -> int:
    """
    FASTQ -> FASTA。
    每 4 行一个 read：
        @header
        sequence
        +
        quality

    输出：
        >header
        sequence
    """
    read_count = 0

    with open_text_maybe_gzip(fq_path) as fin, open(fa_path, "w", encoding="utf-8") as fout:
        while True:
            header = fin.readline()
            if not header:
                break

            seq = fin.readline()
            plus = fin.readline()
            qual = fin.readline()

            if not seq or not plus or not qual:
                raise ValueError(f"Incomplete FASTQ record in file: {fq_path}")

            header = header.rstrip("\n\r")
            seq = seq.rstrip("\n\r")
            plus = plus.rstrip("\n\r")

            if not header.startswith("@"):
                raise ValueError(f"Invalid FASTQ header in {fq_path}: {header[:100]}")

            if not plus.startswith("+"):
                raise ValueError(f"Invalid FASTQ plus line in {fq_path}: {plus[:100]}")

            fout.write(">" + header[1:] + "\n")
            fout.write(seq + "\n")

            read_count += 1

    return read_count


def count_fasta_records(fa_path: Path) -> int:
    n = 0
    with open(fa_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith(">"):
                n += 1
    return n


def main():
    print("=" * 80)
    print("Read-based FASTQ processing")
    print("=" * 80)
    print(f"RAW_ROOT         = {RAW_ROOT}")
    print(f"OUT_ROOT         = {OUT_ROOT}")
    print(f"SINGLE_FASTA_DIR = {SINGLE_FASTA_DIR}")
    print(f"MERGED_FASTA_DIR = {MERGED_FASTA_DIR}")
    print(f"LOG_DIR          = {LOG_DIR}")
    print("=" * 80)

    if not RAW_ROOT.exists():
        raise FileNotFoundError(f"RAW_ROOT does not exist: {RAW_ROOT}")

    fastq_files = find_fastq_files(RAW_ROOT)

    print(f"FASTQ files found: {len(fastq_files)}")

    if len(fastq_files) == 0:
        raise RuntimeError(f"No FASTQ files found under: {RAW_ROOT}")

    fastq_table_path = LOG_DIR / "fastq_file_table.tsv"

    with open(fastq_table_path, "w", encoding="utf-8") as w:
        w.write("unit_name\tsample_name\tfastq_path\tparent_folder\n")

        for fq in fastq_files:
            unit_name = get_unit_name_from_path(fq)
            sample_name = infer_sample_name(unit_name)
            w.write(f"{unit_name}\t{sample_name}\t{fq}\t{fq.parent.name}\n")

    print(f"FASTQ file table saved to: {fastq_table_path}")

    print("=" * 80)
    print("Step 1. Convert FASTQ to FASTA")
    print("=" * 80)

    single_count_path = LOG_DIR / "single_fasta_read_counts.tsv"

    unit_to_fasta = {}
    unit_to_sample = {}

    with open(single_count_path, "w", encoding="utf-8") as w:
        w.write("unit_name\tsample_name\tread_count\tfastq_path\tfasta_path\n")

        for idx, fq in enumerate(fastq_files, start=1):
            unit_name = get_unit_name_from_path(fq)
            sample_name = infer_sample_name(unit_name)

            out_fasta = SINGLE_FASTA_DIR / f"{unit_name}.fasta"

            print(f"[{idx}/{len(fastq_files)}]")
            print(f"  FASTQ : {fq}")
            print(f"  FASTA : {out_fasta}")
            print(f"  Sample: {sample_name}")

            n_reads = fastq_to_fasta(fq, out_fasta)

            unit_to_fasta[unit_name] = out_fasta
            unit_to_sample[unit_name] = sample_name

            w.write(f"{unit_name}\t{sample_name}\t{n_reads}\t{fq}\t{out_fasta}\n")

            print(f"  Reads : {n_reads}")

    print(f"Single FASTA count table saved to: {single_count_path}")

    print("=" * 80)
    print("Step 2. Merge R1/R2 by sample")
    print("=" * 80)

    sample_to_units = defaultdict(list)

    for unit_name in unit_to_fasta:
        sample_name = unit_to_sample[unit_name]
        sample_to_units[sample_name].append(unit_name)

    merge_summary_path = LOG_DIR / "merge_summary.tsv"
    merged_count_path = LOG_DIR / "merged_fasta_read_counts.tsv"

    with open(merge_summary_path, "w", encoding="utf-8") as ms, \
         open(merged_count_path, "w", encoding="utf-8") as mc:

        ms.write("sample_name\tn_units\tunits\tmerged_fasta\n")
        mc.write("sample_name\tread_count\tmerged_fasta\n")

        for sample_name in sorted(sample_to_units.keys()):
            units = sorted(sample_to_units[sample_name])
            merged_fasta = MERGED_FASTA_DIR / f"{sample_name}_all_reads.fasta"

            print(f"[Merge] {sample_name}")
            print(f"  Units : {units}")
            print(f"  Output: {merged_fasta}")

            with open(merged_fasta, "wb") as fout:
                for unit in units:
                    in_fasta = unit_to_fasta[unit]
                    with open(in_fasta, "rb") as fin:
                        shutil.copyfileobj(fin, fout, length=1024 * 1024)

            n_merged_reads = count_fasta_records(merged_fasta)

            ms.write(f"{sample_name}\t{len(units)}\t{';'.join(units)}\t{merged_fasta}\n")
            mc.write(f"{sample_name}\t{n_merged_reads}\t{merged_fasta}\n")

            print(f"  Merged reads: {n_merged_reads}")

    print("=" * 80)
    print("Finished")
    print("=" * 80)
    print("Main outputs:")
    print(f"  Single FASTA directory : {SINGLE_FASTA_DIR}")
    print(f"  Merged FASTA directory : {MERGED_FASTA_DIR}")
    print(f"  Log directory          : {LOG_DIR}")
    print("=" * 80)

    print("Expected merged files:")
    for fa in sorted(MERGED_FASTA_DIR.glob("*.fasta")):
        print(f"  {fa.name}")


if __name__ == "__main__":
    main()