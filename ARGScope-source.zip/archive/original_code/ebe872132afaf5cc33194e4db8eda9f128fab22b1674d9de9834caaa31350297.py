#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compute the NEW Full + three ablations, for DNA and Protein.

Put this file next to DNA_full_test_sequence_predictions.csv,
protein_full_test_sequence_predictions.csv, wo_gate/, wo_graph/, wo_transfer/.
The original full/dna/, full/protein/, wo_gate/dna/ layout also works.
Run with Python 3.9+. Only the Python standard library is required.

Main Type/Subtype tables INCLUDE nonARG and use final, binary-gated labels.
ARG_only/ contains a separate analysis of true ARGs, still counting predicted
nonARG as an error. It is NOT the training script's oracle ARG_Subtype metric.
No threshold is changed and no training/prototype files are loaded.
"""
import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

NONARG = "nonARG"
OUTPUT_PREFIX = "new_ablation_metrics_"
VARIANTS = ("full", "wo_gate", "wo_graph", "wo_transfer")
MODALITIES = ("DNA", "Protein")
AVERAGES = ("macro", "weighted", "micro")
METRICS = ("Accuracy", "Precision", "Recall", "F1", "MCC")
MODEL_NAMES = {"full": "Full", "wo_gate": "w/o Gate", "wo_graph": "w/o Graph", "wo_transfer": "w/o Transfer"}


def normalized_label(value):
    text = str(value).strip()
    if not text:
        raise ValueError("Empty true/predicted label")
    key = re.sub(r"[^a-z0-9]", "", text.lower())
    return NONARG if key in {"nonarg", "nonargs", "negative", "nonresistant", "nonresistance"} else text


def parse_binary(value):
    text = str(value).strip().lower()
    if text in {"1", "1.0", "true", "arg"}:
        return 1
    if text in {"0", "0.0", "false", "nonarg", "non-arg", "non_arg"}:
        return 0
    raise ValueError("Binary labels must be 0/1 (nonARG/ARG), got: " + repr(value))


def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def infer_run(relative_path):
    text = relative_path.as_posix().lower()
    modalities = []
    for token, name in (("dna", "DNA"), ("protein", "Protein")):
        if re.search(r"(?<![a-z])" + token + r"(?![a-z])", text):
            modalities.append(name)
    if len(modalities) != 1:
        raise ValueError(f"Cannot identify one DNA/Protein modality: {relative_path}")
    compact = re.sub(r"[^a-z0-9]", "", text)
    found = []
    patterns = {"wo_gate": ("wogate", "woadaptivegating", "withoutgate"),
                "wo_graph": ("wograph", "withoutgraph"),
                "wo_transfer": ("wotransfer", "woknowledgetransfer", "withouttransfer")}
    for variant, aliases in patterns.items():
        if any(alias in compact for alias in aliases):
            found.append(variant)
    if len(found) > 1:
        raise ValueError(f"Conflicting ablation names: {relative_path}")
    return (found[0] if found else "full", modalities[0])


def discover_files(root):
    found = {}
    for folder, directories, files in os.walk(root):
        directories[:] = sorted(d for d in directories
                                if not d.lower().startswith(OUTPUT_PREFIX)
                                and d not in {".git", "__pycache__"})
        for name in sorted(files):
            if not name.lower().endswith("test_sequence_predictions.csv"):
                continue
            path = Path(folder) / name
            key = infer_run(path.relative_to(root))
            if key in found:
                raise ValueError(f"Duplicate input for {key}:\n  {found[key]}\n  {path}\n"
                                 "Keep exactly one test prediction file per model/modality.")
            found[key] = path
    expected = {(v, m) for v in VARIANTS for m in MODALITIES}
    missing = expected - set(found)
    if missing:
        raise ValueError("Missing model results: " + ", ".join(f"{v}/{m}" for v, m in sorted(missing))
                         + "\nPut this script in the common parent folder of all eight results.")
    return {key: found[key] for key in [(v, m) for v in VARIANTS for m in MODALITIES]}


def read_predictions(path):
    # Read completely before calculating; a malformed or inconsistent file fails.
    text = None
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            text = path.read_text(encoding=encoding)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError(f"Unsupported text encoding: {path}")
    import io
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
        raise ValueError(f"Missing/duplicate CSV headers: {path}")
    required = {"sequence_id", "true_subtype", "predicted_subtype", "true_type", "predicted_type", "true_ARG", "predicted_ARG"}
    missing = required - set(reader.fieldnames)
    if missing:
        raise ValueError(f"Missing columns in {path.name}: {sorted(missing)}")
    records = {}
    subtype_types = {}
    for row in reader:
        if all(not str(v or "").strip() for v in row.values()):
            continue
        try:
            if None in row or any(row[k] is None for k in required):
                raise ValueError("CSV row has the wrong number of fields")
            if "split" in row and row["split"].strip().lower() != "test":
                raise ValueError("Non-test row found in a test prediction file")
            sid = row["sequence_id"].strip()
            if not sid or sid in records:
                raise ValueError(f"Empty/duplicate sequence_id: {sid!r}")
            clean = {"sequence_id": sid}
            for prefix in ("true", "predicted"):
                subtype = normalized_label(row[f"{prefix}_subtype"])
                typ = normalized_label(row[f"{prefix}_type"])
                binary = parse_binary(row[f"{prefix}_ARG"])
                if binary != int(subtype != NONARG) or binary != int(typ != NONARG):
                    raise ValueError(f"{prefix} binary/type/subtype labels disagree for {sid}")
                if subtype_types.setdefault(subtype, typ) != typ:
                    raise ValueError(f"Conflicting Type mapping for subtype {subtype!r}")
                clean.update({f"{prefix}_subtype": subtype, f"{prefix}_type": typ, f"{prefix}_ARG": binary})
            records[sid] = clean
        except (ValueError, AttributeError) as exc:
            raise ValueError(f"{path.name}, CSV line {reader.line_num}: {exc}") from exc
    if not records:
        raise ValueError(f"No test predictions: {path}")
    return records


def validate_runs(runs, expected_n=4574, expected_subtypes=820, expected_types=23):
    baseline = runs[("full", "DNA")]
    ids = set(baseline)
    if expected_n is not None and len(ids) != expected_n:
        raise ValueError(f"Expected the NEW {expected_n}-sequence test set; found {len(ids)}. Do not mix old results.")
    true_subtypes = {r["true_subtype"] for r in baseline.values()} - {NONARG}
    true_types = {r["true_type"] for r in baseline.values()} - {NONARG}
    for label, count, expected in (("ARG subtypes", len(true_subtypes), expected_subtypes), ("ARG Types", len(true_types), expected_types)):
        if expected is not None and count != expected:
            raise ValueError(f"Expected {expected} {label}; found {count}")
    if {r["true_ARG"] for r in baseline.values()} != {0, 1}:
        raise ValueError("The test set must contain both ARG and nonARG")
    mapping = {}
    for key, records in runs.items():
        if set(records) != ids:
            raise ValueError(f"Different test IDs for {key}: missing={len(ids-set(records))}, extra={len(set(records)-ids)}. No intersection filtering is performed.")
        for sid, row in records.items():
            if any(row[f] != baseline[sid][f] for f in ("true_ARG", "true_type", "true_subtype")):
                raise ValueError(f"Ground-truth mismatch for {key}, sequence {sid}")
            for prefix in ("true", "predicted"):
                s, t = row[f"{prefix}_subtype"], row[f"{prefix}_type"]
                if mapping.setdefault(s, t) != t:
                    raise ValueError(f"Subtype/Type mapping conflict across runs: {s}")
    return sorted(ids)


def divide(numerator, denominator):
    return numerator / denominator if denominator else 0.0


def label_counts(truth, predicted):
    if not truth or len(truth) != len(predicted):
        raise ValueError("Metrics require equal, nonempty true/predicted arrays")
    true_counts, pred_counts = Counter(truth), Counter(predicted)
    correct_counts = Counter(t for t, p in zip(truth, predicted) if t == p)
    return true_counts, pred_counts, correct_counts


def global_accuracy_mcc(truth, predicted):
    true_counts, pred_counts, correct = label_counts(truth, predicted)
    n, c = len(truth), sum(correct.values())
    numerator = c * n - sum(count * pred_counts[label] for label, count in true_counts.items())
    denominator_squared = (n*n - sum(v*v for v in true_counts.values())) * (n*n - sum(v*v for v in pred_counts.values()))
    return c/n, numerator/math.sqrt(denominator_squared) if denominator_squared > 0 else 0.0


def per_label_metrics(truth, predicted, labels):
    true_counts, pred_counts, correct = label_counts(truth, predicted)
    n = len(truth)
    result = []
    for label in labels:
        tp = correct[label]
        fn, fp = true_counts[label]-tp, pred_counts[label]-tp
        tn = n-tp-fn-fp
        denominator_squared = (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
        result.append({"Label": label, "Support": true_counts[label], "Predicted_count": pred_counts[label],
                       "TP": tp, "FP": fp, "FN": fn, "TN": tn,
                       "Accuracy": (tp+tn)/n, "Precision": divide(tp, tp+fp), "Recall": divide(tp, tp+fn),
                       "F1": divide(2*tp, 2*tp+fp+fn),
                       "MCC": (tp*tn-fp*fn)/math.sqrt(denominator_squared) if denominator_squared > 0 else 0.0})
    return result


def overall_metrics(truth, predicted, average, labels=None):
    labels = sorted(set(truth) | set(predicted)) if labels is None else list(labels)
    if not labels:
        raise ValueError("Empty averaging label set")
    rows = per_label_metrics(truth, predicted, labels)
    accuracy, mcc = global_accuracy_mcc(truth, predicted)
    if average == "micro":
        tp, fp, fn = (sum(r[k] for r in rows) for k in ("TP", "FP", "FN"))
        p, r, f = divide(tp, tp+fp), divide(tp, tp+fn), divide(2*tp, 2*tp+fp+fn)
    elif average in {"macro", "weighted"}:
        weights = [1 if average == "macro" else r["Support"] for r in rows]
        p, r, f = (divide(sum(row[k]*w for row, w in zip(rows, weights)), sum(weights)) for k in ("Precision", "Recall", "F1"))
    else:
        raise ValueError(f"Unsupported average: {average}")
    return {"Accuracy": accuracy, "Precision": p, "Recall": r, "F1": f, "MCC": mcc}


def write_csv(path, rows):
    if not rows:
        raise ValueError(f"Refusing to write an empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: format(v, ".12g") if isinstance(v, float) else v for k, v in row.items()})


def safe_type_filename(label, number):
    slug = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(label)).strip(" .")[:65] or "type"
    suffix = hashlib.sha256(str(label).encode("utf-8")).hexdigest()[:8]
    return f"{number:02d}_{slug}_{suffix}.csv"


def calculate(root, output=None, expected_n=4574, expected_subtypes=820, expected_types=23):
    files = discover_files(root)
    hashes = {key: file_hash(path) for key, path in files.items()}
    runs = {key: read_predictions(path) for key, path in files.items()}
    ids = validate_runs(runs, expected_n, expected_subtypes, expected_types)
    if any(file_hash(path) != hashes[key] for key, path in files.items()):
        raise ValueError("An input file changed while it was being read; rerun after writing finishes")
    labels = {level: sorted({r[f"{side}_{level}"] for records in runs.values() for r in records.values() for side in ("true", "predicted")}) for level in ("type", "subtype")}
    baseline = runs[("full", "DNA")]
    true_arg_n = sum(r["true_ARG"] for r in baseline.values())
    id_hash = hashlib.sha256(json.dumps(ids, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    truths = [(sid, baseline[sid]["true_ARG"], baseline[sid]["true_type"], baseline[sid]["true_subtype"]) for sid in ids]
    truth_hash = hashlib.sha256(json.dumps(truths, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    binary, binary_averages, type_rows, subtype_rows, combined, audits = [], [], [], [], [], []
    arg_type_rows, arg_subtype_rows, per_type, arg_per_type = [], [], [], []
    for (variant, modality), records in runs.items():
        rows = [records[sid] for sid in ids]
        info = {"Variant": variant, "Model": MODEL_NAMES[variant], "Modality": modality, "N_test": len(ids)}
        y, p = [r["true_ARG"] for r in rows], [r["predicted_ARG"] for r in rows]
        b = per_label_metrics(y, p, [1])[0]
        binary_row = {**info, "Level": "ARG_nonARG", "Evaluation_scope": "all_test_sequences", "Average": "binary_ARG_positive", **{k: b[k] for k in METRICS}, **{k: b[k] for k in ("TP", "FP", "FN", "TN")}}
        binary.append(binary_row)
        combined.append({k: v for k, v in binary_row.items() if k not in {"TP", "FP", "FN", "TN"}})
        for average in AVERAGES:
            binary_averages.append({**info, "Average": average, **overall_metrics(y, p, average, [0, 1])})
        for level, main_destination, arg_destination in (("type", type_rows, arg_type_rows), ("subtype", subtype_rows, arg_subtype_rows)):
            truth = [r[f"true_{level}"] for r in rows]
            prediction = [r[f"predicted_{level}"] for r in rows]
            for average in AVERAGES:
                value = {**info, "Level": level, "Evaluation_scope": "all_test_sequences_including_nonARG", "Average": average, **overall_metrics(truth, prediction, average, labels[level])}
                main_destination.append(value)
                combined.append(value)
            arg_rows = [r for r in rows if r["true_ARG"] == 1]
            arg_truth = [r[f"true_{level}"] for r in arg_rows]
            arg_prediction = [r[f"predicted_{level}"] for r in arg_rows]
            arg_labels = [s for s in labels[level] if s != NONARG]
            for average in AVERAGES:
                arg_destination.append({**info, "N_evaluated": len(arg_rows), "Level": level, "Evaluation_scope": "true_ARG_only_final_predictions", "Average": average, **overall_metrics(arg_truth, arg_prediction, average, arg_labels)})
            if level == "type":
                per_type.extend({**info, "Evaluation_scope": "all_test_sequences_including_nonARG", "Accuracy_definition": "one_vs_rest", **m} for m in per_label_metrics(truth, prediction, labels[level]))
                arg_per_type.extend({**info, "N_evaluated": len(arg_rows), "Evaluation_scope": "true_ARG_only_final_predictions", "Accuracy_definition": "one_vs_rest", **m} for m in per_label_metrics(arg_truth, arg_prediction, arg_labels))
        audits.append({**info, "ARG_n": true_arg_n, "nonARG_n": len(ids)-true_arg_n,
                       "True_ARG_subtypes": len({r["true_subtype"] for r in rows if r["true_ARG"]}),
                       "True_ARG_types": len({r["true_type"] for r in rows if r["true_ARG"]}),
                       "IDs_match_Full": True, "Ground_truth_match_Full": True, "Test_ID_SHA256": id_hash,
                       "Test_truth_SHA256": truth_hash, "Input_SHA256": hashes[(variant, modality)],
                       "Source_file": files[(variant, modality)].relative_to(root).as_posix()})
        print(f"OK: {modality:7s} {MODEL_NAMES[variant]:15s} N={len(ids)} ARG={true_arg_n}", flush=True)
    # Do not create a result folder until ALL eight inputs have passed validation.
    output = output or root / (OUTPUT_PREFIX + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    if output.exists():
        raise FileExistsError(f"Output already exists; nothing will be overwritten: {output}")
    output.mkdir(parents=True, exist_ok=False)
    for name, values in (("00_all_models_summary.csv", combined), ("00_input_audit.csv", audits),
                         ("01_ARG_nonARG_ARG_positive_five_metrics.csv", binary),
                         ("02_Type_overall_macro_weighted_micro.csv", type_rows),
                         ("03_Subtype_overall_macro_weighted_micro.csv", subtype_rows),
                         ("04_Per_type_five_metrics.csv", per_type),
                         ("05_ARG_nonARG_macro_weighted_micro_optional.csv", binary_averages),
                         ("ARG_only/02_Type_macro_weighted_micro.csv", arg_type_rows),
                         ("ARG_only/03_Subtype_macro_weighted_micro.csv", arg_subtype_rows),
                         ("ARG_only/04_Per_type_five_metrics.csv", arg_per_type)):
        write_csv(output / name, values)
    for index, typ in enumerate(labels["type"], 1):
        write_csv(output / "per_type" / safe_type_filename(typ, index), [r for r in per_type if r["Label"] == typ])
        if typ != NONARG:
            write_csv(output / "ARG_only/per_type" / safe_type_filename(typ, index), [r for r in arg_per_type if r["Label"] == typ])
    notes = {
        "input_models": 8, "N_test_per_model": len(ids), "ARG_n": true_arg_n, "nonARG_n": len(ids)-true_arg_n,
        "metrics": list(METRICS), "ARG_is_positive": True,
        "main_type_and_subtype_include_nonARG": True,
        "averaging_labels": labels, "averages": list(AVERAGES), "undefined_precision_recall_f1_or_mcc": 0,
        "overall_accuracy_and_mcc": "Global single-label metrics; NOT averages of per-class Accuracy or MCC. Identical across averaging rows.",
        "per_type_accuracy_and_mcc": "One-versus-rest for that Type on the stated population. Accuracy=(TP+TN)/N.",
        "ARG_only": "Keep ALL true ARG rows, including those predicted nonARG. Average P/R/F1 over ARG class labels only. Accuracy/MCC still include wrong nonARG predictions. This is NOT oracle-subtype evaluation.",
        "ARG_only_micro": "nonARG is an abstention outside the averaged ARG label set; micro precision, recall and F1 need not equal Accuracy.",
        "main_macro_label_set": "Common union of true/predicted labels across all eight runs, including nonARG, for comparable macro denominators.",
        "audit_limit": "Checks prediction file consistency, not train/validation/prototype leakage or sequence homology.",
        "test_id_sha256": id_hash, "test_truth_sha256": truth_hash,
        "source_file_sha256": {p.relative_to(root).as_posix(): hashes[key] for key, p in files.items()},
        "no_rows_dropped_for_prediction_errors": True, "thresholds_changed": False,
    }
    (output / "calculation_notes.json").write_text(json.dumps(notes, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "README_统计口径.txt").write_text(
        "本次共8组模型，全部使用相同测试ID和真实标签。指标使用0-1小数；MCC范围为-1到1。\n"
        "01：ARG为阳性的二分类五指标，附TP/FP/FN/TN。\n"
        "02和03：包含nonARG的端到端Type/Subtype，macro/weighted/micro各一行。\n"
        "同一模型同一任务的总体Accuracy和MCC在三种平均方式中相同，不计算所谓macro-MCC。\n"
        "04与per_type：每个Type的one-vs-rest五指标。per_type每个文件汇总该Type的全部8组模型。\n"
        "05：二分类的macro/weighted/micro补充表，不替代01的ARG阳性结果。\n"
        "ARG_only：仅真实ARG的额外分析。预测成nonARG仍然算错，绝不只保留预测正确为ARG的样本。\n"
        "ARG_only的P/R/F1仅平均ARG类别；nonARG预测是拒识错误，micro P/R/F1因此不一定相等。\n"
        "ARG_only不是训练脚本中的ARG_Subtype（oracle binary）结果，无法从最终标签CSV恢复被二分类覆盖的subtype预测。\n"
        "00_input_audit记录样本数与哈希。这里只核对预测文件，不重新验证上游训练的数据泄漏。\n"
        "源文件、模型、阈值均未修改。每次运行新建结果文件夹，保留已有结果。\n", encoding="utf-8-sig")
    print(f"\nDONE. Results: {output}", flush=True)
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent, help="Parent folder of all eight result files")
    parser.add_argument("--output", type=Path, help="Optional NEW output folder; existing folders are never overwritten")
    parser.add_argument("--expected-n", type=int, default=4574, help="New fixed-split test size (default 4574)")
    parser.add_argument("--expected-subtypes", type=int, default=820, help="True ARG subtype count")
    parser.add_argument("--expected-types", type=int, default=23, help="True ARG Type count")
    parser.add_argument("--no-pause", action="store_true", help="Do not pause after execution on Windows")
    args = parser.parse_args(argv)
    code = 0
    try:
        root = args.root.expanduser().resolve()
        if not root.is_dir():
            raise NotADirectoryError(root)
        calculate(root, args.output.expanduser().resolve() if args.output else None,
                  args.expected_n, args.expected_subtypes, args.expected_types)
    except Exception as exc:
        print(f"\nERROR: {exc}\nNo input/training files were changed.", file=sys.stderr)
        code = 1
    if os.name == "nt" and not args.no_pause:
        try:
            input("\nPress Enter to close / 按回车关闭...")
        except (EOFError, OSError):
            pass
    return code


if __name__ == "__main__":
    raise SystemExit(main())
