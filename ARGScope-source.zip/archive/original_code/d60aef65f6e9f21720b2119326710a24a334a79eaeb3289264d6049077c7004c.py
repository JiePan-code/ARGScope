"""Native, editable draw.io reconstructions of the audited ARGScope schematics.

Only authored outputs are written. Existing research data and synced sources are
read-only. All texts/shapes/connectors are native mxCells; small pictograms are
self-contained vector image cells from the three-colour icon kit.
"""
from pathlib import Path
import base64
import copy
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs' / 'ARGScope_drawio_20260930'
ICONS = ROOT / 'outputs' / 'ARGScope_iconkit_3color_20260929' / 'SVG'
BLUE, TEAL, INK = '#3478AE', '#259B91', '#283743'


class Diagram:
    def __init__(self, name, width, height):
        self.name, self.width, self.height = name, width, height
        self.model = ET.Element('mxGraphModel', dict(dx='1600', dy='1000', grid='0',
            gridSize='10', guides='1', tooltips='1', connect='1', arrows='1', fold='1',
            page='1', pageScale='1', pageWidth=str(width), pageHeight=str(height),
            math='0', shadow='0', background='#FFFFFF'))
        self.root = ET.SubElement(self.model, 'root')
        ET.SubElement(self.root, 'mxCell', id='0')
        ET.SubElement(self.root, 'mxCell', id='1', parent='0')
        self.counter = 0
        self.bounds = {}
        self.texts = []

    def cell(self, value, x, y, w, h, style, ident=None):
        self.counter += 1
        ident = ident or f'v{self.counter}'
        c = ET.SubElement(self.root, 'mxCell', id=ident, value=value,
                          style=style, vertex='1', parent='1')
        ET.SubElement(c, 'mxGeometry', x=str(x), y=str(y), width=str(w), height=str(h), **{'as': 'geometry'})
        self.bounds[ident] = (x, y, w, h)
        return ident

    def text(self, value, x, y, w, h, size=24, bold=False, color=INK, align='center', ident=None):
        self.texts.append(dict(value=value, x=x, y=y, width=w, height=h, size=size, bold=bold))
        return self.cell(value, x, y, w, h,
            f'text;html=0;whiteSpace=wrap;overflow=visible;rounded=0;strokeColor=none;fillColor=none;'
            f'fontFamily=Arial;fontSize={size};fontColor={color};fontStyle={1 if bold else 0};'
            f'align={align};verticalAlign=middle;spacing=0;', ident)

    def box(self, label, x, y, w, h, color=INK, size=24, bold=False, fill=6, ident=None):
        return self.cell(label, x, y, w, h,
            f'rounded=1;arcSize=12;absoluteArcSize=1;whiteSpace=wrap;html=0;'
            f'fillColor={color};fillOpacity={fill};strokeColor={color};strokeWidth=1.8;'
            f'fontFamily=Arial;fontSize={size};fontColor={INK};fontStyle={1 if bold else 0};'
            'spacing=10;align=center;verticalAlign=middle;', ident)

    def panel(self, title, x, y, w, h, color=INK, size=29):
        self.box('', x,y,w,h,color,fill=2)
        self.text(title, x+20,y+16,w-40,42,size,True,color,align='left')

    def icon(self, n, x, y, w, h=None, ident=None):
        p = next(ICONS.glob(f'{n:02d}_*.svg'))
        svg = p.read_bytes()
        # mxGraph image styles use a comma before the base64 body (not ;base64).
        uri = 'data:image/svg+xml,' + base64.b64encode(svg).decode('ascii')
        return self.cell('', x,y,w,h or w*224/256,
            f'shape=image;verticalLabelPosition=bottom;verticalAlign=top;imageAspect=1;aspect=fixed;'
            f'image={uri};', ident)

    def edge(self, start=None, end=None, points=None, color=INK, dashed=False,
             source=None, target=None, exit_xy=(1,.5), entry_xy=(0,.5), label='', width=2.5, arrow=True):
        self.counter += 1
        style = (f'edgeStyle=none;rounded=0;html=0;endArrow={"block" if arrow else "none"};endFill=1;'
                 f'strokeColor={color};strokeWidth={width};endSize=9;'
                 f'dashed={int(dashed)};dashPattern=7 5;fontFamily=Arial;fontSize=21;fontColor={INK};'
                 'labelBackgroundColor=#FFFFFF;')
        attrs = dict(id=f'e{self.counter}', value=label, edge='1', parent='1', style=style)
        if source:
            attrs['source'] = source
            attrs['style'] += f'exitX={exit_xy[0]};exitY={exit_xy[1]};exitDx=0;exitDy=0;'
        if target:
            attrs['target'] = target
            attrs['style'] += f'entryX={entry_xy[0]};entryY={entry_xy[1]};entryDx=0;entryDy=0;'
        c = ET.SubElement(self.root, 'mxCell', attrs)
        g = ET.SubElement(c,'mxGeometry',relative='1', **{'as':'geometry'})
        for p,k in [(start,'sourcePoint'),(end,'targetPoint')]:
            if p: ET.SubElement(g,'mxPoint',x=str(p[0]),y=str(p[1]),**{'as':k})
        if points:
            a=ET.SubElement(g,'Array',**{'as':'points'})
            for px,py in points: ET.SubElement(a,'mxPoint',x=str(px),y=str(py))
        return c

    def tag(self, s,x,y,w,color=INK):
        return self.box(s,x,y,w,38,color,20,True,8)

    def write(self, path):
        save([self],path)


def save(diagrams,path):
    doc = ET.Element('mxfile',host='Electron',agent='ARGScope native diagram authoring',
                     version='31.4.5',type='device',pages=str(len(diagrams)))
    for i,d in enumerate(diagrams):
        page=ET.SubElement(doc,'diagram',id=f'argscope-{i+1}',name=d.name)
        page.append(copy.deepcopy(d.model))
    ET.indent(doc)
    ET.ElementTree(doc).write(path,encoding='utf-8',xml_declaration=True)


def overview():
    d=Diagram('Figure 1 · Framework overview',2080,1460)
    d.text('ARGScope framework',40,22,2000,64,48,True)
    d.text('A   Staged multimodal training',40,105,1050,50,34,True,align='left')
    d.text('Paired inputs during training · independent single-modality deployment',1080,110,960,42,23,align='right')

    d.panel('Paired training inputs',40,175,360,415,size=27)
    d.text('ARG and non-ARG',60,232,320,34,23)
    for yy,n,c,enc,dim in [(290,1,BLUE,'ESM-2','1280D'),(435,2,TEAL,'DNABERT-2','768D')]:
        d.icon(n,60,yy,92,95)
        a=d.box(enc,172,yy+13,145,48,c,22,True)
        d.edge((151,yy+38),(171,yy+38),color=c)
        d.text(dim,175,yy+65,140,30,22,True,c)
        d.edge((318,yy+38),(463,yy+38),color=c)
    d.text('Fixed encoders; precomputed features',55,548,330,30,20)

    d.panel('1  Adaptive fusion learning',440,175,490,415)
    d.text('Independent projections',459,239,215,36,23,True)
    p=d.box('Protein\n512D',463,287,172,82,BLUE,25)
    n=d.box('Nucleotide\n512D',463,432,172,82,TEAL,25)
    gate=d.box('Adaptive\nfeature-wise gate',687,295,210,90,INK,25,True)
    d.edge(source=p,target=gate,points=[(659,335),(659,322)],entry_xy=(0,.3),color=BLUE)
    d.edge(source=n,target=gate,points=[(666,479),(666,359)],entry_xy=(0,.7),color=TEAL)
    d.text('g, 1 − g',801,395,116,30,21,True)
    mix=d.box('Weighted sum\n+ LayerNorm',687,437,210,86,INK,25)
    d.edge(source=gate,target=mix,exit_xy=(.5,1),entry_xy=(.5,0))
    fused=d.box('Fused features · 512D',658,544,252,34,INK,22,True,9,'fused-overview')
    d.edge(source=mix,target=fused,exit_xy=(.5,1),entry_xy=(.5,0))

    d.panel('2  Subtype-prototype graph',970,175,1070,415)
    d.text('Constructed from ARG model-training samples only',993,239,1010,38,24)
    for xx,num,title,desc in [
        (996,16,'Subtype prototypes','L2 samples → mean\n→ L2 prototype'),
        (1255,22,'Mutual kNN','Cosine similarity\n+ self-loops'),
        (1514,23,'Residual GAT','Auxiliary type\nsupervision'),
        (1773,17,'Refined prototypes','L2-normalized\nARG prototypes')]:
        d.text(title,xx,286,240,38,25,True)
        d.icon(num,xx+49,333,142,128)
        d.text(desc,xx,476,240,64,22)
    for xx in [1200,1459,1718]: d.edge((xx,397),(xx+54,397))
    d.edge(source=fused,end=(1015,400),exit_xy=(1,.5),points=[(951,561),(951,400)])
    d.text('The non-ARG center is constructed separately, outside the subtype graph.',993,548,1010,30,22)

    # Fused representations feed teachers directly, not through the graph.
    d.edge(source=fused,end=(312,655),exit_xy=(.5,1),points=[(784,617),(312,617)],label='Fused representations')
    d.panel('3  Branch-specific fusion teachers',40,655,540,350)
    d.text('Train separately, then fix',60,714,500,32,24)
    for xx,name,c in [(65,'AA teacher',BLUE),(325,'NT teacher',TEAL)]:
        d.box('',xx,762,230,173,c,fill=3)
        d.text(name,xx+10,774,210,34,25,True,c)
        norm=d.box('L2-normalized fusion',xx+15,814,200,38,c,19)
        b=d.box('Binary',xx+14,878,90,38,c,20,True)
        s=d.box('Subtype',xx+124,878,92,38,c,20,True)
        d.edge(source=norm,target=b,exit_xy=(.25,1),entry_xy=(.5,0),width=2)
        d.edge(source=norm,target=s,exit_xy=(.75,1),entry_xy=(.5,0),width=2)
    d.text('Binary: class centers\nSubtype: prototype initialization + anchoring',61,941,500,57,20)

    d.panel('Knowledge transfer to both students',620,655,760,350)
    transfers=[(645,737,35,'Teacher predictions','Prediction distillation'),
               (1010,737,7,'Fixed fused features','Feature alignment'),
               (645,868,17,'Prototypes + non-ARG center','Prototype alignment'),
               (1010,868,42,'Teacher head weights','Head anchoring')]
    for xx,yy,ico,source,loss in transfers:
        d.icon(ico,xx,yy+12,82,77)
        d.text(source,xx+91,yy,245,48,21)
        d.text(loss,xx+91,yy+53,245,48,24,True)
    d.edge((580,830),(620,830),dashed=True)

    d.panel('4  Single-modality students',1420,655,620,350)
    for yy,n,name,c,sub in [(742,24,'ARGScope-AA',BLUE,'Protein features · 1280D'),
                           (867,25,'ARGScope-NT',TEAL,'Nucleotide features · 768D')]:
        d.icon(5 if n==24 else 6,1440,yy+7,90,89)
        d.edge((1535,yy+52),(1577,yy+52),color=c)
        d.icon(n,1580,yy+2,115,101)
        d.text(name,1702,yy+5,302,42,29,True,c)
        d.text(sub,1702,yy+52,302,35,23)
        d.edge((1380,yy+52),(1637,yy+5),points=[(1400,yy+52),(1400,yy-10),(1637,yy-10)],dashed=True)

    d.text('B   Single-modality inference',40,1043,1120,50,34,True,align='left')
    d.text('Choose the matching encoder and student only',1160,1048,880,42,24,align='right')
    d.box('',40,1110,1110,254,INK,fill=2)
    for yy,n,c,enc,student in [(1121,1,BLUE,'ESM-2','ARGScope-AA'),(1242,2,TEAL,'DNABERT-2','ARGScope-NT')]:
        d.icon(n,58,yy+4,88,85)
        d.text('Protein only' if n==1 else 'Nucleotide only',147,yy+24,190,43,24,True)
        e=d.box(enc,355,yy+15,177,63,c,25,True)
        st=d.box(student,591,yy+15,233,63,c,26,True)
        h=d.box('Parallel binary\nand subtype heads',885,yy+9,235,77,c,23)
        d.edge((334,yy+47),(355,yy+47),color=c)
        d.edge(source=e,target=st,color=c)
        d.edge(source=st,target=h,color=c)

    d.panel('Reported annotation',1200,1110,840,254)
    gate=d.cell('ARG /\nnon-ARG',1248,1193,172,114,
        f'rhombus;whiteSpace=wrap;html=0;fillColor={INK};fillOpacity=4;strokeColor={INK};strokeWidth=2;'
        f'fontFamily=Arial;fontSize=23;fontColor={INK};fontStyle=1;', 'reporting-gate')
    d.edge((1120,1171),(1248,1250),points=[(1176,1171),(1176,1250)])
    d.edge((1120,1292),(1248,1250),points=[(1176,1292),(1176,1250)])
    sub=d.box('Predicted subtype',1482,1175,240,61,INK,25,True)
    typ=d.box('Resistance type',1790,1175,221,61,INK,25,True)
    no=d.box('non-ARG',1482,1280,240,54,INK,25)
    d.edge(source=gate,target=sub,exit_xy=(1,.4),points=[(1447,1239),(1447,1205)],label='ARG')
    d.edge(source=gate,target=no,exit_xy=(1,.65),points=[(1447,1267),(1447,1307)],label='non-ARG')
    d.edge(source=sub,target=typ)
    d.text('Predefined mapping',1728,1244,295,37,20)
    d.text('Binary decision gates subtype reporting; no sequence-level type classifier.',1230,1334,775,25,19)

    d.edge((65,1411),(140,1411))
    d.text('Forward / data flow',154,1392,277,37,22,align='left')
    d.edge((468,1411),(544,1411),dashed=True)
    d.text('Training supervision',558,1392,296,37,22,align='left')
    d.text('No fusion teacher or subtype graph is required at inference.',920,1392,1120,37,23,align='right')
    return d


def teacher_preparation(d,x,y,w,c,name):
    d.panel(name+' fusion teacher',x,y,w,294,c,28)
    d.icon(37,x+w-61,y+15,38,37)
    d.text('Fused input',x+18,y+79,128,29,22,True)
    inp=d.icon(7,x+35,y+111,94,84)
    norm=d.box('L2 norm\n512D',x+170,y+115,142,76,c,24)
    d.edge((x+135,y+153),(x+169,y+153))
    b=d.box('Binary',x+361,y+77,174,51,c,23,True)
    s=d.box('Subtype',x+361,y+179,174,51,c,23,True)
    d.edge(source=norm,target=b,points=[(x+335,y+153),(x+335,y+102)])
    d.edge(source=norm,target=s,points=[(x+335,y+153),(x+335,y+204)])
    d.text('Class centers',x+538,y+51,148,34,20)
    d.icon(21,x+582,y+93,58,50)
    d.edge((x+580,y+103),(x+536,y+103),dashed=True,width=2)
    d.text('Refined prototypes',x+530,y+149,164,35,20)
    d.icon(17,x+569,y+190,80,55)
    d.edge((x+567,y+204),(x+536,y+204),dashed=True,width=2)
    d.text('Parallel cosine heads; subtype initialized + anchored to prototypes',x+14,y+244,w-28,42,19)


def detailed():
    d=Diagram('Figure 2 · AA and NT training',2080,2000)
    d.text('Branch-specific teacher–student training',40,20,2000,64,46,True)
    d.text('Prepared fusion and graph → train teachers → fix teachers → train students',40,94,2000,42,27)
    d.panel('Prepared beforehand',40,158,485,312,INK,29)
    d.icon(7,63,234,119,100)
    d.text('Fused features\n512D',201,234,294,79,25,True)
    d.icon(17,61,355,120,75)
    d.text('Refined subtype prototypes\n+ separate non-ARG center',197,344,300,80,23)
    teacher_preparation(d,551,158,721,BLUE,'AA')
    teacher_preparation(d,1296,158,744,TEAL,'NT')
    d.text('Binary CE: all training samples    |    Subtype CE: reference ARG only    |    Teachers fixed during student training',540,460,1500,38,22,True)

    for ox,c,name,ico,encoder,dim,mlp in [
        (40,BLUE,'ARGScope-AA',1,'ESM-2','1280D','1536 → 1024'),
        (1060,TEAL,'ARGScope-NT',2,'DNABERT-2','768D','1024')]:
        d.panel(name,ox,529,980,1035,c,38)
        d.text('Protein student' if ico==1 else 'Nucleotide student',ox+565,548,391,42,27,True,c,align='right')
        d.text('Student forward path',ox+26,609,500,34,24,True)
        d.text('Fixed multimodal targets',ox+553,609,395,34,24,True)

        # Input: encoder features are precomputed, never updated by these losses.
        d.icon(ico,ox+24,665,100,91)
        e=d.box(encoder,ox+147,675,175,56,c,25,True)
        emb=d.icon(5 if ico==1 else 6,ox+369,661,115,83)
        d.text(dim,ox+370,747,113,32,23,True,c)
        d.edge((ox+124,703),(ox+147,703),color=c)
        d.edge((ox+322,703),(ox+367,703),color=c)
        st=d.box('Standardize\ntraining statistics only',ox+134,805,313,69,c,24)
        d.edge((ox+426,771),(ox+291,804),points=[(ox+426,789),(ox+291,789)],color=c)

        dense=d.box('Hidden layers: '+mlp if ico==1 else 'Hidden layer: 1024',ox+109,915,361,62,c,25,True)
        d.edge(source=st,target=dense,exit_xy=(.5,1),entry_xy=(.5,0),color=c)
        d.text('Linear · LayerNorm · GELU · dropout',ox+79,981,423,33,20)

        d.text('Two residual blocks · 1024D',ox+51,1041,470,36,25,True)
        d.icon(29 if ico==1 else 30,ox+73,1080,168,104)
        d.icon(29 if ico==1 else 30,ox+322,1080,168,104)
        d.edge(source=dense,end=(ox+75,1130),exit_xy=(0,.5),points=[(ox+42,946),(ox+42,1130)],color=c)
        d.edge((ox+244,1130),(ox+321,1130),color=c)
        proj=d.box('Linear 512 + LayerNorm',ox+109,1220,361,60,c,25,True)
        d.edge((ox+407,1187),(ox+291,1220),points=[(ox+407,1203),(ox+291,1203)],color=c)
        norm=d.box('L2 normalization\nParallel cosine heads',ox+99,1311,380,77,c,24)
        d.edge(source=proj,target=norm,exit_xy=(.5,1),entry_xy=(.5,0),color=c)
        b=d.box('Binary',ox+61,1437,190,54,c,26,True,7,'aa-binary' if ico==1 else 'nt-binary')
        s=d.box('Subtype',ox+335,1437,192,54,c,26,True,7,'aa-subtype' if ico==1 else 'nt-subtype')
        d.edge(source=norm,target=b,exit_xy=(.25,1),entry_xy=(.5,0),points=[(ox+216,1424),(ox+156,1424)],color=c)
        d.edge(source=norm,target=s,exit_xy=(.75,1),entry_xy=(.5,0),points=[(ox+363,1424),(ox+431,1424)],color=c)
        d.text('CE: all samples',ox+45,1514,220,31,23,True)
        d.text('CE: ARG only',ox+317,1514,229,31,23,True)
        d.edge((ox+156,1492),(ox+156,1510),color=c)
        d.edge((ox+431,1492),(ox+431,1510),color=c)

        # Right-hand target path is independent of the student's hidden layers.
        d.box('',ox+575,665,375,448,INK,fill=3)
        d.text('Fused representation · 512D',ox+593,677,339,40,24,True)
        d.icon(7,ox+693,722,136,85)
        t=d.box(('AA' if ico==1 else 'NT')+' teacher (fixed)\nL2 norm + cosine heads',ox+609,849,302,93,c,23,True)
        d.icon(37,ox+904,865,34,35)
        d.edge((ox+761,809),(ox+761,849))
        bp=d.box('Binary\nprobabilities',ox+593,1006,163,77,c,22,True)
        sp=d.box('Subtype\nprobabilities',ox+778,1006,157,77,c,22,True)
        d.edge(source=t,target=bp,exit_xy=(.25,1),entry_xy=(.5,0),points=[(ox+690,992),(ox+674,992)],width=2)
        d.edge(source=t,target=sp,exit_xy=(.75,1),entry_xy=(.5,0),points=[(ox+832,992),(ox+856,992)],width=2)

        d.box('',ox+575,1166,375,359,INK,fill=3)
        d.text('Distillation targets',ox+590,1180,342,40,27,True)
        if ico==1:
            d.box('Binary KD weight = 0\n(no binary distillation)',ox+591,1240,343,91,INK,24,True,4)
        else:
            d.text('Binary KD · all samples',ox+591,1237,343,38,23,True)
            tb=d.box('Teacher\nbinary',ox+590,1294,142,64,INK,22)
            sb=d.box('Student\nbinary',ox+793,1294,142,64,c,22,True)
            d.edge(source=tb,target=sb,dashed=True)
        d.text('Subtype KD · ARG only',ox+591,1376,343,36,23,True)
        ts=d.box('Teacher\nsubtype',ox+590,1438,142,65,INK,22)
        ss=d.box('Student\nsubtype',ox+793,1438,142,65,c,22,True)
        d.edge(source=ts,target=ss,dashed=True)
        d.edge((ox+761,1114),(ox+761,1165),dashed=True)

    d.text('Precomputed encoder features are fixed; standardization is fitted on the model-training subset only.',42,1590,1998,42,26,True)
    d.text('Shared alignment and classifier constraints',40,1656,2000,43,32,True,align='left')
    for xx,ww,title in [(40,621,'Feature alignment'),(690,675,'Prototype alignment'),(1394,646,'Head initialization + anchoring')]:
        d.panel(title,xx,1720,ww,199,INK,27)
    d.icon(39,64,1785,200,110)
    d.text('Student feature (512D)\n↔ fixed normalized\nfused feature (512D)',280,1789,353,105,24)
    d.icon(40,710,1785,170,112)
    d.text('ARG → true refined subtype prototype\nnon-ARG → separate non-ARG center',893,1789,449,105,22)
    d.icon(42,1414,1785,174,106)
    d.text('Both binary and subtype heads\nTeacher weights → student weights',1600,1789,415,105,23)
    d.edge((61,1956),(132,1956))
    d.text('Forward flow',145,1939,229,34,22,align='left')
    d.edge((410,1956),(481,1956),dashed=True)
    d.text('Training target / constraint',495,1939,367,34,22,align='left')
    d.icon(37,928,1935,38,37)
    d.text('Fixed during student learning',980,1939,470,34,22,align='left')
    d.text('CE: cross-entropy  ·  KD: knowledge distillation',1467,1939,573,34,21,align='right')
    return d


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    figs=[overview(), detailed()]
    names=['Figure1_ARGScope_overview','Figure2_AA_NT_training']
    for d,n in zip(figs,names): d.write(OUT/(n+'.drawio'))
    save(figs,OUT/'ARGScope_Figure1_Figure2_editable.drawio')
    report=[]
    for d in figs:
        cells=d.root.findall('mxCell')
        report.append(dict(name=d.name,dimensions=[d.width,d.height],
            cells=len(cells),native_text_cells=sum(bool(c.get('value')) for c in cells),
            vector_icon_cells=sum('shape=image;' in c.get('style','') for c in cells),
            connectors=sum(c.get('edge')=='1' for c in cells)))
        assert all(x>=0 and y>=0 and x+w<=d.width and y+h<=d.height for x,y,w,h in d.bounds.values())
    (OUT/'structure_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'README_使用说明.md').write_text('''# ARGScope · draw.io 可编辑流程图

## 打开与编辑

- `ARGScope_Figure1_Figure2_editable.drawio`：两页合并源文件，底部页面标签切换 Figure 1 / Figure 2。
- `Figure1_ARGScope_overview.drawio`、`Figure2_AA_NT_training.drawio`：独立源文件。
- 文字、模块框、箭头均为 draw.io 原生对象，可双击改文字、拖动位置、修改样式。
- 小图标是嵌入的独立 SVG 对象，可移动、缩放、替换；不是把整张旧图当作背景。
- 图标已嵌入，无需依赖外部路径。图标内部路径需用矢量编辑器修改；draw.io 中可独立选中图标。
- Arial 字体；蓝色 #3478AE、青绿色 #259B91、深灰 #283743 三种主色；浅底是同色透明度变化。
- Figure 2 的局部蒸馏框用明确的 Teacher → Student 对应关系说明目标，避免长连线穿过主干。

## 结构依据

沿用 2026-09-29 的代码核验记录，未重新训练或改变实验结果：
`outputs/argscope_manuscript_aligned_figures_20260929/code_figure_audit_20260929.md`。

已保留分阶段训练、预计算固定编码器、512D 融合、ARG-only 原型图、独立 non-ARG 中心、
无隐藏 MLP 的双头融合教师、AA/NT 不同输入层、两个残差块、AA 关闭 binary KD、NT 开启 binary KD、
两分支的 ARG-only subtype KD，以及仅单模态推理和预定义 subtype-to-type 映射。

这是方法示意，不是实验数据图；没有替换或覆盖原论文及此前图像。
''',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
