"""Source-verified novel-gene P/R/F1 panels with shared AA-based selection."""
from pathlib import Path
import hashlib
import io
import json
import re
import shutil
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib.colors import to_hex
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/novel_gene_type_heatmaps_20260923/data/Novel_gene_per_type_precision_recall_F1.csv'
RAW_ROOT = Path('E:/1. ARGmodel/1. NonARG_training/new model result8.24/5. novel gene')
OUT = ROOT / 'outputs/novel_gene_paired_horizontal_20260926'
PANEL_MM = (140, 160)
GAP_MM = 4
DPI = 254  # Exact 10 pixels/mm, used only for QA PNGs; SVG is resolution independent.
METRICS = [('Precision', '#4F86AD', ''), ('Recall', '#6AA995', '//'), ('F1', '#E8B677', '..')]
SVGNS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', SVGNS)
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_data():
    frame = pd.read_csv(SOURCE, keep_default_na=False)
    hashes = {str(SOURCE): sha(SOURCE)}
    references = {}
    for modality, folder in [('AA', '1.Protein_novel_gene_100pct'), ('NT', '2.DNA_novel_gene_100pct')]:
        path = RAW_ROOT / folder / 'test_sequence_predictions.csv'
        hashes[str(path)] = sha(path)
        raw = pd.read_csv(path, keep_default_na=False)
        assert raw.sequence_id.is_unique and len(raw) == 4494
        ref = raw.loc[raw.true_ARG.eq(1)].copy()
        assert len(ref) == 2247 and ref.novel_ARG_subtype.eq(1).all() and ref.split.eq('test').all()
        references[modality] = ref.set_index('sequence_id').sort_index()
        for row in frame.loc[frame.Modality.eq(modality)].itertuples():
            true, pred = ref.true_type.eq(row.Type), ref.predicted_type.eq(row.Type)
            tp, support, calls = int((true & pred).sum()), int(true.sum()), int(pred.sum())
            assert (tp, support, calls, calls-tp, support-tp) == (row.TP, row.Support, row.Predicted, row.FP, row.FN)
            values = [tp/calls if calls else 0, tp/support if support else 0,
                      2*tp/(support+calls) if support+calls else 0]
            assert np.allclose(values, [row.Precision, row.Recall, row.F1], rtol=0, atol=1e-12)
    pd.testing.assert_series_equal(references['AA'].true_type, references['NT'].true_type)
    aa = frame.loc[frame.Modality.eq('AA') & frame.Support.gt(0) & frame.Precision.ge(.95)]
    aa = aa.sort_values(['Precision', 'F1', 'Support', 'Type_display'], ascending=[False, False, False, True])
    order = aa.Type.tolist()
    assert len(order) == 6
    selected = frame.loc[frame.Type.isin(order)].copy()
    selected['Display_order'] = selected.Type.map({t: i+1 for i, t in enumerate(order)})
    selected = selected.sort_values(['Modality', 'Display_order'])
    assert selected.groupby('Modality').size().to_dict() == {'AA': 6, 'NT': 6}
    assert selected.loc[selected.Modality.eq('AA'), 'Support'].tolist() == selected.loc[selected.Modality.eq('NT'), 'Support'].tolist()
    return selected, frame, hashes


def draw_panel(modality, rows):
    fig = plt.figure(figsize=(PANEL_MM[0]/25.4, PANEL_MM[1]/25.4), dpi=DPI, facecolor='none')
    name = f'Novel_gene_ARGScope_{modality}'
    fig.set_label(name)
    modality_name = 'protein' if modality == 'AA' else 'nucleotide'
    fig.text(.51, .965, f'ARGScope-{modality} ({modality_name})', ha='center', va='top', fontsize=14.5, weight='bold')
    fig.legend(handles=[Patch(facecolor=c, edgecolor=c, hatch=h, label=m) for m, c, h in METRICS],
               ncol=3, frameon=False, loc='upper center', bbox_to_anchor=(.52, .915),
               fontsize=10.5, handlelength=1.65, handleheight=.9, columnspacing=1.25, handletextpad=.45,
               borderaxespad=0)
    fig.text(.52, .865, 'Types selected by AA precision ≥ 0.95', ha='center', va='center', fontsize=9.5)
    ax = fig.add_axes([34/140, .13, 86/140, .675], facecolor='none')
    ax.set_xlim(0, 1)
    ax.set_ylim(len(rows)-.5, -.5)
    ax.set_yticks([])
    ax.set_xticks([0, .2, .4, .6, .8, 1], ['0.0', '0.2', '0.4', '0.6', '0.8', '1.0'])
    ax.tick_params(axis='x', labelsize=10.5, length=3.3, width=.7, pad=5)
    ax.set_xlabel('Score', fontsize=11.5, labelpad=6)
    ax.grid(axis='x', color='#E4E7E9', linewidth=.6)
    ax.set_axisbelow(True)
    ax.spines[['top', 'right']].set_visible(False)
    for key in ['left', 'bottom']:
        ax.spines[key].set_linewidth(.7)
        ax.spines[key].set_color('#000000')
    nums, bars = [], []
    for i, row in enumerate(rows):
        ax.text(-.045, i-.085, row.Type_display, transform=ax.get_yaxis_transform(),
                ha='right', va='center', fontsize=11.2, clip_on=False)
        ax.text(-.045, i+.13, f'n = {row.Support:,}', transform=ax.get_yaxis_transform(),
                ha='right', va='center', fontsize=9.6, clip_on=False)
        for j, (metric, color, hatch) in enumerate(METRICS):
            value = float(getattr(row, metric))
            y = i+(j-1)*.23
            patch = ax.barh(y, value, height=.195, facecolor=color, edgecolor=color,
                            hatch=hatch, linewidth=.5, zorder=3).patches[0]
            bars.append((patch, value))
            label = ax.text(value+.015, y, f'{value:.4f}', ha='left', va='center',
                            fontsize=10.3, clip_on=False, zorder=4)
            nums.append(label)
    fig.text(.51, .022, 'n = reference test sequences; evaluation restricted to ARGs.',
             ha='center', va='bottom', fontsize=9.0)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    w, h = fig.canvas.get_width_height()
    text_items = [t for t in fig.findobj(match=Text) if t.get_visible() and t.get_text()]
    outside = []
    for label in text_items:
        assert to_hex(label.get_color()) == '#000000', label.get_text()
        bb = label.get_window_extent(renderer)
        if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > w+1 or bb.y1 > h+1:
            outside.append(label.get_text())
    assert not outside, outside
    for i, a in enumerate(nums):
        for b in nums[i+1:]:
            assert not a.get_window_extent(renderer).overlaps(b.get_window_extent(renderer)), (a.get_text(), b.get_text())
    assert len(bars) == 18 and all(abs(p.get_width()-v) < 1e-14 for p, v in bars)
    for folder, mode in [('svg', 'path'), ('editable_svg', 'none')]:
        with plt.rc_context({'svg.fonttype': mode, 'svg.hashsalt': name}):
            fig.savefig(OUT/folder/f'{name}.svg', transparent=True)
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png', dpi=DPI, transparent=True)
    buffer.seek(0)
    rgba = Image.open(buffer).convert('RGBA')
    assert rgba.size == (1400, 1600)
    white = Image.new('RGBA', rgba.size, 'white')
    white.alpha_composite(rgba)
    white.convert('RGB').save(OUT/'previews'/f'{name}.png')
    plt.close(fig)
    return rgba, {'name': name, 'bars': 18, 'out_of_canvas_text': [], 'numeric_label_overlaps': [],
                  'peripheral_text': '#000000', 'axis_range': [0, 1], 'size_mm': PANEL_MM,
                  'types_in_order': [r.Type_display for r in rows]}


def assemble_svg(folder, names):
    width = (2*PANEL_MM[0]+GAP_MM)*72/25.4
    height = PANEL_MM[1]*72/25.4
    root = ET.Element(f'{{{SVGNS}}}svg', {'width': f'{width:g}pt', 'height': f'{height:g}pt',
                     'viewBox': f'0 0 {width:g} {height:g}', 'version': '1.1'})
    title = ET.SubElement(root, f'{{{SVGNS}}}title')
    title.text = 'Selected resistance types in subtype-disjoint evaluation: ARGScope-AA and ARGScope-NT'
    for i, name in enumerate(names):
        source = ET.parse(OUT/folder/f'{name}.svg').getroot()
        mapping = {node.attrib['id']: f'panel{i}_{node.attrib["id"]}' for node in source.iter() if 'id' in node.attrib}
        for node in source.iter():
            for attr, value in list(node.attrib.items()):
                if attr == 'id':
                    node.set(attr, mapping[value])
                else:
                    value = re.sub(r'url\(#([^)]*)\)', lambda m: f'url(#{mapping.get(m.group(1), m.group(1))})', value)
                    if value.startswith('#') and value[1:] in mapping:
                        value = '#'+mapping[value[1:]]
                    node.set(attr, value)
        source.set('x', f'{i*(PANEL_MM[0]+GAP_MM)*72/25.4:g}')
        source.set('y', '0')
        # Nested SVG dimensions are parent user units, not CSS pt lengths.
        # Retaining the exported 'pt' suffix would add a second 96/72 scale.
        viewport = source.attrib['viewBox'].split()
        source.set('width', viewport[2])
        source.set('height', viewport[3])
        root.append(source)
    ids = [n.attrib['id'] for n in root.iter() if 'id' in n.attrib]
    assert len(ids) == len(set(ids))
    assert not any(n.tag.endswith('image') for n in root.iter())
    for node in root.iter():
        for attr, value in node.attrib.items():
            for match in re.findall(r'url\(#([^)]*)\)', value):
                assert match in ids
            if attr.endswith('href') and value.startswith('#'):
                assert value[1:] in ids
    ET.ElementTree(root).write(OUT/folder/'Novel_gene_AA_NT_combined.svg', encoding='utf-8', xml_declaration=True)


def main():
    for folder in ['svg', 'editable_svg', 'previews', 'data', 'code']:
        (OUT/folder).mkdir(parents=True, exist_ok=True)
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10.5, 'text.color': '#000000',
                         'axes.labelcolor': '#000000', 'xtick.color': '#000000', 'ytick.color': '#000000',
                         'hatch.linewidth': .55})
    selected, full, hashes = checked_data()
    selected.to_csv(OUT/'data/Selected_types_AA_precision_ge_095.csv', index=False, encoding='utf-8-sig')
    full.to_csv(OUT/'data/Complete_per_type_results_unchanged.csv', index=False, encoding='utf-8-sig')
    images, audit = [], []
    for modality in ['AA', 'NT']:
        rows = list(selected.loc[selected.Modality.eq(modality)].itertuples())
        im, report = draw_panel(modality, rows)
        images.append(im)
        audit.append(report)
    names = [a['name'] for a in audit]
    for folder in ['svg', 'editable_svg']:
        assemble_svg(folder, names)
    combined = Image.new('RGBA', (2840, 1600), (0, 0, 0, 0))
    for i, im in enumerate(images):
        x = i*1440
        combined.paste(im, (x, 0))
        assert np.array_equal(np.asarray(combined.crop((x, 0, x+1400, 1600))), np.asarray(im))
    white = Image.new('RGBA', combined.size, 'white')
    white.alpha_composite(combined)
    preview = white.convert('RGB')
    preview.save(OUT/'previews/Novel_gene_AA_NT_combined_full.png')
    preview.thumbnail((1704, 960), Image.Resampling.LANCZOS)
    preview.save(OUT/'previews/Novel_gene_AA_NT_combined.png')
    preview.convert('L').save(OUT/'previews/QA_grayscale.png')
    assert all(sha(Path(p)) == digest for p, digest in hashes.items())
    report = {'selection': 'AA Precision >= 0.95 and reference Support > 0',
              'selection_applied_to': 'ARGScope-AA only; same six types displayed for both models',
              'sort': 'AA precision descending, then AA F1 descending, then support descending',
              'scope': '2247 reference ARG test sequences; non-ARG predictions remain errors',
              'zero_division_convention': '0, unchanged from original evaluation; NT Fosfomycin has no predictions',
              'not_a_summary_of_all_types': True, 'complete_results_retained': True,
              'raw_predictions_recomputed': True, 'source_files_unchanged': True,
              'source_sha256': hashes, 'panels': audit, 'transparent_vector_SVG': True,
              'combined_uses_exact_panel_SVG_nodes_without_rescaling': True,
              'combined_preview_pixels_match_panels': True, 'combined_size_mm': [284, 160]}
    (OUT/'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(ROOT/'novel_gene_paired_horizontal_notes_20260926.md', OUT/'Figure_caption_and_notes.md')
    shutil.copy2(Path(__file__), OUT/'code'/Path(__file__).name)
    print(json.dumps({'output': str(OUT), 'selected_types': audit[0]['types_in_order'], 'SVG_count': 6,
                      'raw_results_verified': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
