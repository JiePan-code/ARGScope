#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
合并 SARG 天然 DNA 第一轮和第二轮 NCBI 检索结果，并生成最终数据集。

建议把本脚本放在第一轮输出文件夹：
SARG_missing_DNA_NCBI_retrieval/

脚本完成：
1. 第一轮结果 + 第二轮结果合并，第二轮记录覆盖对应的第一轮失败记录。
2. 合并两轮成功 DNA FASTA，检查重复 ID 和结果表一致性。
3. 从第一轮315条缺失清单中删除第二轮成功记录，生成最终缺失清单/FASTA。
4. 根据筛选后的 protein structure 重新计算每个 subtype 的天然 DNA 覆盖。
5. 输出最终仍不足3个天然 DNA protein 的关键 subtype 和 protein。
6. 如果上一级原始 SARG DNA FASTA/structure 存在，进一步合并为完整天然 DNA
   FASTA，并生成统一 DNA-protein-Type-Subtype 映射表。

只使用 Python 标准库，可直接在 PyCharm 运行。
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


# =============================================================================
# 只需要修改这里（按推荐目录放置时通常无需修改）
# =============================================================================
FIRST_ROUND_DIR = "."
ROUND2_DIR = "SARG_critical_DNA_round2_retrieval"

PROTEIN_STRUCTURE = "../SARG_protein_subtype_ge3_structure.txt"

# 可选：存在时额外生成“原始DNA + 两轮新找回DNA”的完整 FASTA 和统一映射表。
ORIGINAL_FILTERED_DNA_FASTA = "../SARG_DNA_for_protein_subtype_ge3.fasta"
ORIGINAL_FILTERED_DNA_STRUCTURE = "../SARG_DNA_for_protein_subtype_ge3_structure.txt"

MIN_DNA_PROTEINS_PER_SUBTYPE = 3
OUTPUT_DIR = "SARG_final_merged_DNA_results"


SCRIPT_DIR = Path(__file__).resolve().parent
SUCCESS_STATUS = "EXACT_NATURAL_CDS"


def resolve_dir(value: str, description: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_dir():
        raise FileNotFoundError(f"找不到 {description}：{path}")
    return path


def resolve_required_file(value: str | Path, description: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(f"找不到 {description}：{path}")
    return path


def resolve_optional_file(value: str) -> Path | None:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    return path if path.is_file() else None


def read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        return list(reader.fieldnames), list(reader)


def read_tsv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        return list(reader.fieldnames), list(reader)


def read_fasta(path: Path):
    order = []
    records = {}
    current_id = None
    header = ""
    chunks = []

    def save():
        nonlocal current_id, header, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"{path.name} 存在重复 FASTA ID：{current_id}")
        records[current_id] = (header, "".join(chunks).replace(" ", ""))
        order.append(current_id)

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_no, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                save()
                header = line[1:].strip()
                if not header:
                    raise ValueError(f"{path.name} 第 {line_no} 行 FASTA 标题为空")
                current_id = header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(f"{path.name} 第 {line_no} 行在标题前出现序列")
                chunks.append(line)
        save()
    return order, records


def write_csv(path: Path, fieldnames, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def wrap_sequence(sequence: str, width: int = 80):
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def write_fasta(path: Path, order, records, retained_ids: set[str] | None = None):
    written = set()
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record_id in order:
            if retained_ids is not None and record_id not in retained_ids:
                continue
            header, sequence = records[record_id]
            handle.write(f">{header}\n{wrap_sequence(sequence)}\n")
            written.add(record_id)
    if retained_ids is not None and written != retained_ids:
        raise RuntimeError(
            f"写出 {path.name} 时ID不一致：缺少 {len(retained_ids - written)}，"
            f"多出 {len(written - retained_ids)}"
        )
    return written


def rows_by_unique_id(rows, id_column: str, description: str):
    result = {}
    order = []
    for row in rows:
        record_id = row.get(id_column, "").strip()
        if not record_id:
            raise ValueError(f"{description} 存在空 {id_column}")
        if record_id in result:
            raise ValueError(f"{description} 存在重复 {id_column}：{record_id}")
        result[record_id] = row
        order.append(record_id)
    return order, result


def merge_result_fields(first_fields, second_fields):
    fields = []
    for field in list(first_fields) + list(second_fields):
        if field not in fields:
            fields.append(field)
    required_front = ["protein_id", "Type", "Subtype", "status"]
    return required_front + [field for field in fields if field not in required_front]


def main():
    if MIN_DNA_PROTEINS_PER_SUBTYPE < 1:
        raise ValueError("MIN_DNA_PROTEINS_PER_SUBTYPE 必须大于等于1")

    first_dir = resolve_dir(FIRST_ROUND_DIR, "第一轮结果目录")
    round2_dir = resolve_dir(ROUND2_DIR, "第二轮结果目录")
    protein_structure_path = resolve_required_file(PROTEIN_STRUCTURE, "筛选后 protein structure")

    first_results_path = resolve_required_file(
        first_dir / "SARG_NCBI_DNA_retrieval_results.csv", "第一轮结果CSV"
    )
    first_success_fasta_path = resolve_required_file(
        first_dir / "SARG_retrieved_exact_natural_DNA.fasta", "第一轮成功DNA FASTA"
    )
    first_missing_csv_path = resolve_required_file(
        first_dir / "SARG_still_missing_DNA_proteins.csv", "第一轮缺失CSV"
    )
    first_missing_fasta_path = resolve_required_file(
        first_dir / "SARG_still_missing_DNA_proteins.fasta", "第一轮缺失FASTA"
    )

    round2_results_path = resolve_required_file(
        round2_dir / "SARG_NCBI_DNA_retrieval_results.csv", "第二轮结果CSV"
    )
    round2_success_fasta_path = resolve_required_file(
        round2_dir / "SARG_retrieved_exact_natural_DNA.fasta", "第二轮成功DNA FASTA"
    )

    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 100)
    print("Merge SARG NCBI DNA retrieval round 1 + round 2")
    print("=" * 100)
    print(f"First round : {first_dir}")
    print(f"Second round: {round2_dir}")
    print(f"Structure   : {protein_structure_path}")
    print(f"Output      : {output_dir}")

    first_fields, first_rows = read_csv(first_results_path)
    second_fields, second_rows = read_csv(round2_results_path)
    first_order, first_by_id = rows_by_unique_id(first_rows, "protein_id", "第一轮结果")
    second_order, second_by_id = rows_by_unique_id(second_rows, "protein_id", "第二轮结果")

    first_failed_ids = {
        protein_id for protein_id, row in first_by_id.items()
        if row.get("status", "").strip() != SUCCESS_STATUS
    }
    if not set(second_by_id).issubset(first_failed_ids):
        invalid = sorted(set(second_by_id) - first_failed_ids)
        raise ValueError(
            f"第二轮包含 {len(invalid)} 个不属于第一轮失败集的ID，例如：{invalid[:5]}"
        )

    # 第二轮对其22条目标记录拥有更高优先级；其他记录沿用第一轮。
    final_by_id = dict(first_by_id)
    for protein_id, row in second_by_id.items():
        final_by_id[protein_id] = row

    final_fields = merge_result_fields(first_fields, second_fields)
    final_rows = [final_by_id[protein_id] for protein_id in first_order]
    final_results_path = output_dir / "SARG_final_NCBI_DNA_retrieval_results.csv"
    write_csv(final_results_path, final_fields, final_rows)

    first_success_order, first_success_records = read_fasta(first_success_fasta_path)
    second_success_order, second_success_records = read_fasta(round2_success_fasta_path)
    first_success_ids = {
        protein_id for protein_id, row in first_by_id.items()
        if row.get("status", "").strip() == SUCCESS_STATUS
    }
    second_success_ids = {
        protein_id for protein_id, row in second_by_id.items()
        if row.get("status", "").strip() == SUCCESS_STATUS
    }
    if set(first_success_records) != first_success_ids:
        raise ValueError("第一轮成功 FASTA ID 与第一轮结果CSV中的成功ID不一致")
    if set(second_success_records) != second_success_ids:
        raise ValueError("第二轮成功 FASTA ID 与第二轮结果CSV中的成功ID不一致")
    overlap = set(first_success_records) & set(second_success_records)
    if overlap:
        raise ValueError(f"两轮成功 FASTA 存在重复 protein ID，例如：{sorted(overlap)[:5]}")

    combined_success_order = first_success_order + second_success_order
    combined_success_records = dict(first_success_records)
    combined_success_records.update(second_success_records)
    combined_success_path = output_dir / "SARG_round1_round2_retrieved_exact_natural_DNA.fasta"
    write_fasta(combined_success_path, combined_success_order, combined_success_records)

    # 最终缺失 = 第一轮7198条输入中，合并后仍未成功的记录。
    final_missing_ids = {
        protein_id for protein_id, row in final_by_id.items()
        if row.get("status", "").strip() != SUCCESS_STATUS
    }
    _, first_missing_rows = read_csv(first_missing_csv_path)
    _, first_missing_by_id = rows_by_unique_id(
        first_missing_rows, "protein_id", "第一轮缺失CSV"
    )
    first_missing_fasta_order, first_missing_fasta_records = read_fasta(first_missing_fasta_path)
    if set(first_missing_by_id) != set(first_missing_fasta_records):
        raise ValueError("第一轮缺失 CSV 与 FASTA ID 不一致")
    if not final_missing_ids.issubset(set(first_missing_by_id)):
        raise ValueError("最终缺失ID不是第一轮缺失ID的子集")

    final_missing_rows = []
    for protein_id in first_order:
        if protein_id not in final_missing_ids:
            continue
        row = final_by_id[protein_id]
        final_missing_rows.append({
            "protein_id": protein_id,
            "Type": row.get("Type", ""),
            "Subtype": row.get("Subtype", ""),
            "status": row.get("status", ""),
            "failure_reason": row.get("failure_reason", ""),
        })

    final_missing_csv_path = output_dir / "SARG_final_proteins_without_DNA.csv"
    final_missing_fasta_path = output_dir / "SARG_final_proteins_without_DNA.fasta"
    write_csv(
        final_missing_csv_path,
        ["protein_id", "Type", "Subtype", "status", "failure_reason"],
        final_missing_rows,
    )
    write_fasta(
        final_missing_fasta_path,
        first_missing_fasta_order,
        first_missing_fasta_records,
        final_missing_ids,
    )

    # 重新计算492个 subtype 的天然 DNA protein 覆盖。
    _, protein_structure_rows = read_tsv(protein_structure_path)
    structure_by_id = {}
    subtype_ids = defaultdict(list)
    subtype_type = {}
    for row in protein_structure_rows:
        protein_id = row.get("SARG.Seq.ID", "").strip()
        type_name = row.get("Type", "").strip()
        subtype = row.get("Subtype", "").strip()
        if not protein_id or not subtype:
            raise ValueError("Protein structure 存在空 SARG.Seq.ID 或 Subtype")
        if protein_id in structure_by_id:
            raise ValueError(f"Protein structure 存在重复ID：{protein_id}")
        structure_by_id[protein_id] = row
        subtype_ids[subtype].append(protein_id)
        subtype_type[subtype] = type_name
    if not final_missing_ids.issubset(set(structure_by_id)):
        raise ValueError("最终缺失ID中存在不属于筛选后 protein structure 的记录")

    coverage_rows = []
    for subtype, protein_ids in subtype_ids.items():
        total = len(protein_ids)
        missing = [protein_id for protein_id in protein_ids if protein_id in final_missing_ids]
        available = total - len(missing)
        if available == 0:
            dna_status = "NO_DNA_FOR_SUBTYPE"
        elif available < MIN_DNA_PROTEINS_PER_SUBTYPE:
            dna_status = f"BELOW_{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_PROTEINS"
        elif not missing:
            dna_status = "COMPLETE_DNA_COVERAGE"
        else:
            dna_status = "PARTIAL_BUT_SUFFICIENT"
        failure_counts = Counter(final_by_id[p]["status"] for p in missing)
        coverage_rows.append({
            "Type": subtype_type[subtype],
            "Subtype": subtype,
            "total_proteins": total,
            "proteins_with_natural_DNA": available,
            "proteins_still_missing_DNA": len(missing),
            "natural_DNA_coverage_percent": round(100.0 * available / total, 4),
            "DNA_status": dna_status,
            "missing_failure_status_counts": ";".join(
                f"{status}:{count}" for status, count in sorted(failure_counts.items())
            ),
            "missing_protein_ids": ";".join(missing),
        })
    coverage_rows.sort(key=lambda row: (
        row["proteins_with_natural_DNA"],
        row["natural_DNA_coverage_percent"],
        row["Type"], row["Subtype"],
    ))
    coverage_fields = [
        "Type", "Subtype", "total_proteins", "proteins_with_natural_DNA",
        "proteins_still_missing_DNA", "natural_DNA_coverage_percent",
        "DNA_status", "missing_failure_status_counts", "missing_protein_ids",
    ]
    coverage_path = output_dir / "SARG_final_subtype_DNA_coverage.csv"
    zero_path = output_dir / "SARG_final_subtypes_without_any_DNA.csv"
    below_path = output_dir / f"SARG_final_subtypes_with_fewer_than{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_proteins.csv"
    write_csv(coverage_path, coverage_fields, coverage_rows)
    zero_rows = [row for row in coverage_rows if row["proteins_with_natural_DNA"] == 0]
    below_rows = [
        row for row in coverage_rows
        if row["proteins_with_natural_DNA"] < MIN_DNA_PROTEINS_PER_SUBTYPE
    ]
    write_csv(zero_path, coverage_fields, zero_rows)
    write_csv(below_path, coverage_fields, below_rows)

    final_critical_subtypes = {row["Subtype"] for row in below_rows}
    final_critical_missing_ids = {
        protein_id for protein_id in final_missing_ids
        if structure_by_id[protein_id]["Subtype"].strip() in final_critical_subtypes
    }
    final_critical_rows = [
        row for row in final_missing_rows if row["protein_id"] in final_critical_missing_ids
    ]
    final_critical_csv_path = output_dir / "SARG_final_missing_proteins_in_critical_subtypes.csv"
    final_critical_fasta_path = output_dir / "SARG_final_missing_proteins_in_critical_subtypes.fasta"
    write_csv(
        final_critical_csv_path,
        ["protein_id", "Type", "Subtype", "status", "failure_reason"],
        final_critical_rows,
    )
    write_fasta(
        final_critical_fasta_path,
        first_missing_fasta_order,
        first_missing_fasta_records,
        final_critical_missing_ids,
    )

    # 可选：合并原始11,149条天然DNA，得到全部可用天然DNA及统一映射表。
    original_dna_fasta_path = resolve_optional_file(ORIGINAL_FILTERED_DNA_FASTA)
    original_dna_structure_path = resolve_optional_file(ORIGINAL_FILTERED_DNA_STRUCTURE)
    all_natural_dna_count = "Not generated"
    unified_mapping_count = "Not generated"
    all_natural_fasta_path = output_dir / "SARG_all_available_natural_DNA.fasta"
    unified_mapping_path = output_dir / "SARG_all_available_natural_DNA_mapping.csv"

    if (original_dna_fasta_path is None) != (original_dna_structure_path is None):
        raise FileNotFoundError(
            "原始筛选后 DNA FASTA 和 structure 必须同时存在，或同时留空。"
        )
    if original_dna_fasta_path is not None:
        original_dna_order, original_dna_records = read_fasta(original_dna_fasta_path)
        original_dna_fields, original_dna_rows = read_tsv(original_dna_structure_path)
        required = {"NucleotideID", "AminoAcidID", "Type", "Subtype"}
        if not required.issubset(set(original_dna_fields)):
            raise ValueError(
                f"原始 DNA structure 缺少列：{sorted(required - set(original_dna_fields))}"
            )
        original_mapping_ids = [row["NucleotideID"].strip() for row in original_dna_rows]
        if len(original_mapping_ids) != len(set(original_mapping_ids)):
            raise ValueError("原始 DNA structure 存在重复 NucleotideID")
        if set(original_mapping_ids) != set(original_dna_records):
            raise ValueError("原始 DNA FASTA 与 structure ID 不一致")
        dna_id_overlap = set(original_dna_records) & set(combined_success_records)
        if dna_id_overlap:
            raise ValueError(
                f"原始DNA与新找回DNA存在重复FASTA ID，例如：{sorted(dna_id_overlap)[:5]}"
            )

        all_order = original_dna_order + combined_success_order
        all_records = dict(original_dna_records)
        all_records.update(combined_success_records)
        write_fasta(all_natural_fasta_path, all_order, all_records)
        all_natural_dna_count = len(all_records)

        unified_rows = []
        for row in original_dna_rows:
            unified_rows.append({
                "DNA_id": row["NucleotideID"].strip(),
                "protein_id": row["AminoAcidID"].strip(),
                "Type": row["Type"].strip(),
                "Subtype": row["Subtype"].strip(),
                "DNA_source": "original_SARG_nucleotide_database",
                "nucleotide_accession": row["NucleotideID"].strip(),
                "retrieval_round": "original",
                "strict_translation_validated": "Yes",
            })
        for protein_id in combined_success_order:
            row = final_by_id[protein_id]
            unified_rows.append({
                "DNA_id": protein_id,
                "protein_id": protein_id,
                "Type": row.get("Type", ""),
                "Subtype": row.get("Subtype", ""),
                "DNA_source": "NCBI_retrieved_exact_CDS",
                "nucleotide_accession": row.get("nucleotide_accession", ""),
                "retrieval_round": "round2" if protein_id in second_success_ids else "round1",
                "strict_translation_validated": "Yes",
            })
        write_csv(
            unified_mapping_path,
            ["DNA_id", "protein_id", "Type", "Subtype", "DNA_source",
             "nucleotide_accession", "retrieval_round", "strict_translation_validated"],
            unified_rows,
        )
        unified_mapping_count = len(unified_rows)

    final_status_counts = Counter(row.get("status", "") for row in final_rows)
    total_proteins = len(protein_structure_rows)
    proteins_with_dna = total_proteins - len(final_missing_ids)
    summary_lines = [
        f"first_round_success_DNA\t{len(first_success_ids)}",
        f"second_round_success_DNA\t{len(second_success_ids)}",
        f"combined_new_NCBI_DNA\t{len(combined_success_records)}",
        f"first_round_missing_proteins\t{len(first_missing_by_id)}",
        f"final_missing_proteins\t{len(final_missing_ids)}",
        f"retained_proteins_total\t{total_proteins}",
        f"proteins_with_natural_DNA\t{proteins_with_dna}",
        f"protein_natural_DNA_coverage_percent\t{100.0 * proteins_with_dna / total_proteins:.4f}",
        f"retained_subtypes_total\t{len(coverage_rows)}",
        f"subtypes_without_any_DNA\t{len(zero_rows)}",
        f"subtypes_with_fewer_than_{MIN_DNA_PROTEINS_PER_SUBTYPE}_DNA_proteins\t{len(below_rows)}",
        f"final_missing_proteins_in_critical_subtypes\t{len(final_critical_missing_ids)}",
        f"all_available_natural_DNA_FASTA_records\t{all_natural_dna_count}",
        f"unified_DNA_mapping_rows\t{unified_mapping_count}",
    ]
    for status, count in sorted(final_status_counts.items()):
        summary_lines.append(f"final_status::{status}\t{count}")
    summary_path = output_dir / "SARG_final_merged_DNA_summary.txt"
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n" + "=" * 100)
    print("MERGE COMPLETED")
    print("=" * 100)
    print(f"First-round exact DNA              : {len(first_success_ids)}")
    print(f"Second-round exact DNA             : {len(second_success_ids)}")
    print(f"Combined new NCBI DNA              : {len(combined_success_records)}")
    print(f"Final missing proteins             : {len(final_missing_ids)}")
    print(f"Proteins with natural DNA          : {proteins_with_dna}/{total_proteins}")
    print(f"Protein natural-DNA coverage       : {100.0 * proteins_with_dna / total_proteins:.4f}%")
    print(f"Subtypes without any DNA           : {len(zero_rows)}")
    print(f"Subtypes with <{MIN_DNA_PROTEINS_PER_SUBTYPE} DNA proteins          : {len(below_rows)}")
    print(f"Critical missing proteins          : {len(final_critical_missing_ids)}")
    print(f"All available natural DNA records  : {all_natural_dna_count}")
    print("\nOutput directory:")
    print(f"  {output_dir}")
    print("\nKey output files:")
    for path in [
        combined_success_path, final_missing_csv_path, final_missing_fasta_path,
        coverage_path, below_path, final_critical_csv_path,
        final_critical_fasta_path, summary_path,
    ]:
        print(f"  {path}")
    if original_dna_fasta_path is not None:
        print(f"  {all_natural_fasta_path}")
        print(f"  {unified_mapping_path}")


if __name__ == "__main__":
    main()
