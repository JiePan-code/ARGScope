"""Verify figure data and export completeness; generate internal visual-QA sheets."""
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    manifest = json.loads((HERE / "PLOT_MANIFEST.json").read_text(encoding="utf-8"))
    for name, value in manifest["sources_sha256"].items():
        require(hashlib.sha256(Path(name).read_bytes()).hexdigest() == value, f"Source changed: {name}")
    order = pd.read_csv(HERE / "data/type_display_mapping.csv").Type.tolist()
    require(len(order) == len(set(order)) == 23 and "nonARG" not in order, "Not exactly 23 ARG types")
    index = pd.read_csv(HERE / "PANEL_INDEX.csv")
    require(len(index) == 70 and not index.duplicated(["panel", "modality", "completeness_percent"]).any(), "Wrong panel count")
    require(set(index.panel) == {"A", "B_Precision", "B_Recall", "B_F1", "D", "E", "F"}, "Missing/extra panels")
    checks = []
    for modality in ("protein", "dna"):
        for pct in (100, 60, 70, 80, 90):
            data_root = HERE / "data" / modality / f"{pct}pct"
            name = "100%_test_sequence_predictions.csv" if pct == 100 else f"{pct}%_fragment_predictions_test.csv"
            pred = pd.read_csv(ROOT / modality / name)
            actual = pd.crosstab(pred.true_type, pred.predicted_type).reindex(index=order+["nonARG"], columns=order+["nonARG"], fill_value=0)
            full = pd.read_csv(data_root / "full_confusion_counts_audit.csv", index_col=0)
            require(np.array_equal(actual.to_numpy(), full.to_numpy()), "Full matrix disagrees with independent crosstab")
            norm = pd.read_csv(data_root / "D_row_normalized_23types.csv", index_col=0)
            expected = actual.iloc[:-1, :-1].to_numpy() / actual.iloc[:-1].sum(axis=1).to_numpy()[:, None]
            require(list(norm.index) == order and list(norm.columns) == order, "Wrong D labels")
            require(np.allclose(norm, expected, rtol=0, atol=1e-12), "D normalization mismatch")
            errors = pd.read_csv(data_root / "E_off_diagonal_counts_23types.csv", index_col=0)
            expected_errors = actual.iloc[:-1, :-1].to_numpy().copy()
            np.fill_diagonal(expected_errors, 0)
            require(np.array_equal(errors, expected_errors), "E counts mismatch")
            grouped = pd.read_csv(data_root / "F_all_subtype_error_pairs.csv")
            mask = pred.true_type.isin(order) & (pred.true_subtype != pred.predicted_subtype)
            require(int(grouped.Count.sum()) == int(mask.sum()), "F error total mismatch")
            wrong = pred.loc[mask]
            expected_pairs = Counter(zip(wrong.true_subtype, wrong.predicted_subtype, wrong.true_type, wrong.predicted_type))
            for row in grouped.itertuples():
                key = (row.true_subtype, row.predicted_subtype, row.true_type, row.predicted_type)
                require(expected_pairs[key] == row.Count, "F pair count mismatch")
                require(np.isclose(100 * int(row.true_type == row.predicted_type), row.Type_correct_percent), "F type-retention mismatch")
            top = pd.read_csv(data_root / "F_displayed_top20.csv")
            require(top.equals(grouped.head(20)), "F top20 rank mismatch")
            srcs = pd.read_csv(data_root / "B_sources.csv")
            heatmap_checks = []
            for metric in ("Precision", "Recall", "F1"):
                values = pd.read_csv(data_root / f"B_{metric}_values.csv", index_col=0)
                source_columns = {}
                for item in srcs.itertuples():
                    source = pd.read_csv(item.source)
                    cols = {k.lower(): k for k in source.columns}
                    if item.Model == "ARGScope":
                        source = source[(source.Modality == ("Protein" if modality == "protein" else "DNA")) & (source.Completeness_percent == pct)]
                    lookup = {}
                    for row in source.to_dict("records"):
                        typ = row[cols["type"]]
                        if typ == "MLS":
                            typ = "macrolide-lincosamide-streptogramin"
                        if typ in order:
                            require(typ not in lookup, "Duplicate B source Type")
                            lookup[typ] = float(row[cols[metric.lower()]])
                    source_columns[item.Model] = [lookup.get(t, np.nan) for t in order]
                original = pd.DataFrame(source_columns, index=order)
                reference_models = [model for model in original.columns if model != "ARGScope"]
                retained = [typ for typ in order if any(
                    pd.notna(original.loc[typ, model]) and original.loc[typ, model] != 0
                    for model in reference_models)]
                require(bool(retained), "No eligible B Types")
                require(values.index.tolist() == [f"Average_{len(retained)}_types"]+retained, "B row-filter mismatch")
                require(values.columns.tolist() == original.columns.tolist(), "B model order changed")
                expected_display = original.loc[retained].fillna(0)
                require(np.isfinite(values.to_numpy()).all(), "B displayed values still contain missing/infinite scores")
                require(np.allclose(values.iloc[1:], expected_display, rtol=0, atol=1e-12), "B displayed score mismatch")
                require(np.allclose(values.iloc[0], expected_display.mean(axis=0), rtol=0, atol=1e-12), "B displayed Average mismatch")
                raw = pd.read_csv(data_root / f"B_{metric}_source_values.csv", index_col=0)
                require(raw.index.tolist() == order and raw.columns.tolist() == original.columns.tolist(), "B original-source labels changed")
                require(np.allclose(raw, original, equal_nan=True, rtol=0, atol=1e-12), "B original source values/missingness not preserved")
                audit = pd.read_csv(data_root / f"B_{metric}_row_filter_audit.csv")
                require(audit.Type.tolist() == order, "B filter audit incomplete")
                require(audit.loc[audit.kept, "Type"].tolist() == retained, "B filter audit retained rows mismatch")
                require(audit.source_missing_cells.tolist() == original.isna().sum(axis=1).tolist(), "B missing-source audit mismatch")
                require(audit.reference_nonzero_count.tolist() == original[reference_models].fillna(0).ne(0).sum(axis=1).tolist(), "B nonzero reference counts mismatch")
                expected_missing = int(original.loc[retained].isna().to_numpy().sum())
                require(int(audit.missing_cells_displayed_as_zero.sum()) == expected_missing, "B zero-substitution audit mismatch")
                policy = json.loads((data_root / f"B_{metric}_display_policy.json").read_text(encoding="utf-8"))
                require(policy["retained_types"] == retained and policy["removed_types"] == [typ for typ in order if typ not in retained], "B display policy row mismatch")
                require(policy["displayed_type_count"] == len(retained) and policy["missing_cells_displayed_as_zero"] == expected_missing, "B display policy counts mismatch")
                require(np.allclose(policy["heatmap_y_bounds"], policy["colorbar_y_bounds"], rtol=0, atol=1e-12), "B colorbar not full heatmap height")
                require(policy["average_label"] == "Average", "B Average label not simplified")
                require(policy["value_unit"] == "fraction" and policy["annotation_decimal_places"] == 4, "B numeric format mismatch")
                average_bottom, average_top = policy["average_y_bounds"]
                type_bottom, type_top = policy["type_y_bounds"]
                row_height = average_top - average_bottom
                require(row_height > 0 and average_bottom > type_top, "B Average has no blank separation")
                require(np.isclose((average_bottom-type_top)/row_height, .65, rtol=0, atol=1e-10), "B Average gap has wrong size")
                require(np.isclose((type_top-type_bottom)/len(retained), row_height, rtol=0, atol=1e-12), "B Average cell height differs from main rows")
                require(np.allclose([type_bottom, average_top], policy["heatmap_y_bounds"], rtol=0, atol=1e-12), "B complete heatmap height mismatch")
                heatmap_checks.append({"metric": metric, "retained_types": len(retained), "removed_types": len(order)-len(retained),
                                       "missing_cells_displayed_as_zero": expected_missing, "full_height_colorbar": "PASS",
                                       "separated_average_four_decimals": "PASS"})
            summary = pd.read_csv(data_root / "A_overall_values_and_sources.csv")
            for row in summary.to_dict("records"):
                source = pd.read_csv(row["source"])
                if row["Model"] == "ARGScope":
                    selected = source[(source.Modality == ("Protein" if modality == "protein" else "DNA")) & (source.Completeness_percent == pct) & (source.Average == "weighted")]
                else:
                    key = source.iloc[:, 0].astype(str).str.strip()
                    selected = source[key.str.startswith("Long") if pct == 100 else key == f"{pct}%"]
                require(len(selected) == 1, "Ambiguous A source")
                s = selected.iloc[0]
                for metric in ("Accuracy", "Precision", "Recall", "F1", "MCC"):
                    col = "ACC" if metric == "Accuracy" and "ACC" in s else metric
                    require(abs(float(row[metric]) - float(s[col])) < 1e-12, "A source value mismatch")
            checks.append({"modality": modality, "pct": pct, "A_B_source_values": "PASS", "D_E_F_recalculation": "PASS", "B_display_checks": heatmap_checks})
    image_records = []
    for row in index.itertuples():
        path = HERE / row.PNG
        with Image.open(path) as image:
            require(image.width > 1000 and image.height > 1000, "Insufficient PNG resolution")
            require(abs(image.info["dpi"][0] - 600) < 1, "Wrong DPI")
            require(np.array(image.resize((96,96)).convert("RGB")).std() > 5, "Blank PNG")
            image_records.append({"file": row.PNG, "width": image.width, "height": image.height})
        require(path.with_suffix(".pdf").read_bytes().startswith(b"%PDF-"), "Invalid PDF")
        root = ET.parse(path.with_suffix(".svg")).getroot()
        require(root.tag.endswith("svg"), "Invalid SVG")
        texts = ["".join(node.itertext()).strip() for node in root.iter() if node.tag.endswith("}text")]
        require(not set(texts).intersection({"A", "B", "C", "D", "E", "F"}), f"Panel letter still visible: {row.PNG}")
        old_footers = ("Reported Type-level performance", "Reference-model scores as supplied",
                       "Scores: 0-1.", "Values in %.", "23 ARG Types; true ARG n",
                       "ARG → nonARG outcomes not displayed", "True ARG only;", "Bar label: error count")
        require(not any(text.startswith(old_footers) for text in texts), f"Bottom explanatory footnote still visible: {row.PNG}")
        require(any("completeness" in text for text in texts), f"Modality/completeness title missing: {row.PNG}")
        if row.panel.startswith("B_"):
            require("NA" not in texts and "nan" not in texts, "NA still visible in a B heatmap")
            require(texts.count("Average") == 1 and not any(text.startswith("Average (") for text in texts), "Wrong B Average label in export")
            metric = row.panel.split("_", 1)[1]
            data_folder = HERE / "data" / row.modality / f"{row.completeness_percent}pct"
            # Restore the exact serialized floats at four-decimal rounding ties.
            # The default CSV parser can move e.g. 0.07225000000000001 below its tie.
            displayed = pd.read_csv(data_folder / f"B_{metric}_values.csv", index_col=0,
                                    float_precision="round_trip").to_numpy()
            annotations = {node.attrib["id"]: "".join(child.itertext()).strip()
                           for node in root.iter() if node.attrib.get("id", "").startswith("heatmap-value-")
                           for child in node.iter() if child.tag.endswith("}text")}
            require(len(annotations) == displayed.size, "B exported cell-label count mismatch")
            for i, scores in enumerate(displayed):
                for j, value in enumerate(scores):
                    require(annotations[f"heatmap-value-{i}-{j}"] == f"{value:.4f}",
                            f"B exported cell rounding mismatch: {row.PNG}, row {i}, column {j}")
    for modality in ("protein", "dna"):
        rows = []
        for pct in (100, 60, 70, 80, 90):
            for panel in ("A", "B_Precision", "B_Recall", "B_F1", "D", "E", "F"):
                row = index[(index.modality == modality) & (index.completeness_percent == pct) & (index.panel == panel)].iloc[0]
                rows.append(row)
        sheet = Image.new("RGB", (2100, 1750), "white")
        draw = ImageDraw.Draw(sheet)
        for n, row in enumerate(rows):
            with Image.open(HERE / "_visual_QA" / row.PNG) as image:
                image.thumbnail((296, 325))
                x, y = (n % 7) * 300, (n // 7) * 350
                sheet.paste(image, (x+(300-image.width)//2, y+22))
                draw.text((x+6, y+5), f"{modality} {row.completeness_percent}% {row.panel}", fill="black")
        sheet.save(HERE / "_visual_QA" / f"{modality}_all_panels_contact.png")
    report = {"status": "PASS", "panel_count": 70, "export_count": 210, "type_count": 23,
              "no_panel_letter_labels": True, "no_bottom_explanatory_footnotes": True,
              "source_hashes_verified": len(manifest["sources_sha256"]), "conditions": checks,
              "images": image_records, "no_UMAP": True}
    (HERE / "FIGURE_DATA_VALIDATION.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k:v for k,v in report.items() if k != "images"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
