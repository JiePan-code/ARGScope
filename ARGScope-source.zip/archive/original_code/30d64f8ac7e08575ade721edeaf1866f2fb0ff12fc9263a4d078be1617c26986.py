"""Apply narrow geometric repairs without recreating the user's current drawing."""
from pathlib import Path
import xml.etree.ElementTree as E
import re, json

base=Path(__file__).resolve().parent
p=base/'ARGScope_Figure1.drawio'
t=E.parse(p)
cells={c.get('id'):c for c in t.findall('.//mxCell')}

def style(c,key,value):
    s=c.get('style','')
    s=re.sub(rf'(?<![A-Za-z]){key}=[^;]*;',f'{key}={value};',s)
    c.set('style',s)

g=cells['gate-1-g'].find('mxGeometry');g.set('x','77')
c=cells['subtype-anchor-label'];c.set('value','Subtype-head initialization &amp; anchoring')
g=c.find('mxGeometry')
for k,v in dict(x=1095,y=516,width=330,height=25).items():g.set(k,str(v))
for branch in ['aa','nt']:
    c=cells[branch+'-binary-edge'];style(c,'exitX',24/111)
    c.find('.//Array/mxPoint').set('x','36')
    style(cells[branch+'-subtype-edge'],'exitX',89/111)
t.write(p,encoding='utf-8',xml_declaration=True)

# Check invariants against the actual editable file, including live user edits.
allowed={'#DAE8FC','#E1D5E7','#F5F5F5'}
fills=set()
edges=[]
for id,c in cells.items():
    for f in re.findall(r'fillColor=(#[A-Fa-f0-9]+)',c.get('style','')):fills.add(f.upper())
    if c.get('edge')=='1':
        assert c.find('mxGeometry') is not None,id
        assert 'edgeStyle=orthogonalEdgeStyle' in c.get('style',''),id
        for side in ['source','target']:
            if c.get(side):assert c.get(side) in cells,(id,side)
        edges.append(id)
assert fills<=allowed,fills
report={'unique_cells':len(cells),'connector_count':len(edges),'fill_colors':sorted(fills),'all_connectors_use_orthogonal_routing':True,'all_referenced_endpoints_resolve':True,'preserved_user_title_removal':'title' not in cells}
(base/'quality_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
