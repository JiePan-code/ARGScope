#!/usr/bin/env python3
"""Descriptive parent bootstrap on each archived baseline evaluation population.

NOT a matched-cohort benchmark. DeepARG sources are selected ARG-only hit tables.
No missing calls are imputed; no noise is added to aggregate scores. Baseline
P/R/F1 are newly recomputed with weighted averaging, ACC/MCC are global.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import time
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, matthews_corrcoef
from audit_boxplot_sources import source_list

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
VIOLIN = ROOT.parent / 'violin_revision'
B = 2000
SEED = 20260919
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']
spec = importlib.util.spec_from_file_location('existing_bootstrap', VIOLIN/'bootstrap_overall_metrics.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
score_counts = original.score_counts


def sklearn_scores(y, p, weights=None):
    pr, re, f1, _ = precision_recall_fscore_support(y, p, average='weighted', zero_division=0, sample_weight=weights)
    return np.array([accuracy_score(y, p, sample_weight=weights), pr, re, f1, matthews_corrcoef(y, p, sample_weight=weights)])


def main():
    DATA.mkdir(parents=True, exist_ok=True)
    source_hashes = {}
    def read(path):
        source_hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        return pd.read_csv(path)
    own = read(VIOLIN/'data/ARGScope_parent_bootstrap_five_metrics.csv')
    own.insert(1, 'Model', 'ARGScope')
    own['Population'] = 'new_test_all_including_nonARG'
    own['Comparability'] = 'different_model_cohorts_NOT_matched'
    frames = [own]
    sums = []
    ownsum = read(VIOLIN/'data/ARGScope_point_and_95CI.csv')
    for row in ownsum.itertuples():
        vals = own[(own.Modality==row.Modality)&(own.Completeness==row.Completeness)&(own.Level==row.Level)][row.Metric]
        sums.append(dict(Modality=row.Modality, Model='ARGScope', Completeness=row.Completeness, Level=row.Level, Metric=row.Metric,
                         Point_estimate=row.Point_estimate, Bootstrap_mean=vals.mean(),
                         Q1=vals.quantile(.25), Median=vals.median(), Q3=vals.quantile(.75),
                         CI_low=row.CI_low, CI_high=row.CI_high, N_bootstrap=B,
                         N_parents=row.N_parents, N_rows=row.N_fragments, Population='new_test_all_including_nonARG'))
    audit = []
    checks = []
    for mod, model, pct, path, idcol, parentcol, truth, pred in source_list():
        start = time.monotonic()
        df = read(path)
        assert df[idcol].is_unique and df[[truth,pred]].notna().all().all()
        parent = df[parentcol].astype(str) if parentcol else df[idcol].astype(str).str.replace(r'_[1-5]$', '', regex=True)
        assert df[idcol].astype(str).str.contains(r'_[1-5]$').all()
        assert df.assign(parent_id=parent).groupby('parent_id')[truth].nunique().eq(1).all()
        ids = np.array(sorted(parent.unique()))
        index = pd.Index(ids).get_indexer(parent)
        parent_truth = df.assign(parent_id=parent).drop_duplicates('parent_id').set_index('parent_id')[truth].reindex(ids)
        strata = np.array(parent_truth.ne('nonARG'), dtype=np.int8)
        cohort_hash = hashlib.sha256(('\n'.join(ids)+'\n'+''.join(strata.astype(str))).encode()).hexdigest()
        # Identical parent sets/strata share weights, but fragment identity is NOT inferred.
        seed = (SEED + int(cohort_hash[:8],16)) % (2**32)
        rng = np.random.default_rng(seed)
        weights = np.zeros((B,len(ids)),dtype=np.uint16)
        for s in np.unique(strata):
            positions = np.flatnonzero(strata==s)
            weights[:,positions] = rng.multinomial(len(positions),np.full(len(positions),1/len(positions)),size=B)
        labels = sorted(set(df[truth].astype(str)) | set(df[pred].astype(str)))
        lookup = {name:i for i,name in enumerate(labels)}
        y = df[truth].map(lookup).to_numpy()
        p = df[pred].map(lookup).to_numpy()
        point = score_counts(y,p,np.ones(len(df)),len(labels))
        assert np.allclose(point,sklearn_scores(y,p),rtol=0,atol=1e-12)
        boot = np.empty((B,5))
        for b in range(B):
            boot[b] = score_counts(y,p,weights[b,index],len(labels))
        for b in [0,999,1999]:
            err = np.max(np.abs(boot[b]-sklearn_scores(y,p,weights[b,index])))
            assert err<1e-10
            checks.append(dict(Modality=mod,Model=model,Completeness=pct,Bootstrap=b+1,Max_abs_error=float(err)))
        population = 'archived_selected_ARG_hits_17_true_types_NO_nonARG' if model=='DeepARG' else 'archived_available_rows_30_ARG_types_plus_nonARG'
        part = pd.DataFrame(boot,columns=METRICS)
        part.insert(0,'Bootstrap',np.arange(1,B+1))
        part.insert(0,'Level','Type')
        part.insert(0,'Completeness',pct)
        part.insert(0,'Model',model)
        part.insert(0,'Modality',mod)
        part['Population'] = population
        part['Comparability'] = 'different_model_cohorts_NOT_matched'
        frames.append(part)
        for j, metric in enumerate(METRICS):
            sums.append(dict(Modality=mod,Model=model,Completeness=pct,Level='Type',Metric=metric,
                             Point_estimate=point[j],Bootstrap_mean=boot[:,j].mean(),
                             Q1=np.quantile(boot[:,j],.25),Median=np.median(boot[:,j]),Q3=np.quantile(boot[:,j],.75),
                             CI_low=np.quantile(boot[:,j],.025),CI_high=np.quantile(boot[:,j],.975),
                             N_bootstrap=B,N_parents=len(ids),N_rows=len(df),Population=population))
        audit.append(dict(Modality=mod,Model=model,Completeness=pct,Path=str(path),Seed=seed,
                          Parent_set_hash=cohort_hash,Parent_weights_hash=hashlib.sha256(weights.tobytes()).hexdigest(),
                          N_parents=len(ids),N_ARG_parents=int(strata.sum()),N_nonARG_parents=int((strata==0).sum()),
                          N_rows=len(df),Minimum_fragments_per_parent=int(parent.value_counts().min()),
                          Maximum_fragments_per_parent=int(parent.value_counts().max()),
                          Population=population,Missing_predictions_imputed=False,Same_test_set_as_ARGScope=False))
        print(f'{mod} {model} {pct}%: {len(ids)} parents / {len(df)} rows, {time.monotonic()-start:.1f}s',flush=True)
    pd.concat(frames,ignore_index=True).to_csv(DATA/'all_model_parent_bootstrap.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    summed = pd.DataFrame(sums)
    summed.to_csv(DATA/'all_model_points_and_intervals.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    pd.DataFrame(audit).to_csv(DATA/'baseline_bootstrap_plan.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(DATA/'baseline_independent_sklearn_checks.csv',index=False,encoding='utf-8-sig')
    old = read(ROOT.parent/'data/reported_overall_NOT_matched.csv')
    changes = []
    for row in summed[summed.Level.eq('Type') & summed.Model.ne('ARGScope')].itertuples():
        ref = old[(old.modality==row.Modality)&(old.Model==row.Model)&(old.pct==row.Completeness)].iloc[0]
        changes.append(dict(Modality=row.Modality,Model=row.Model,Completeness=row.Completeness,Metric=row.Metric,
                            Previous_reported_value=ref[row.Metric],Recomputed_weighted_global=row.Point_estimate,
                            Difference=row.Point_estimate-ref[row.Metric],
                            Reason='Recomputed from named archived row table with weighted P/R/F1 and global ACC/MCC; original report used model-specific cohorts/aggregation'))
    pd.DataFrame(changes).to_csv(DATA/'previous_report_vs_recomputed.csv',index=False,encoding='utf-8-sig')
    (DATA/'input_hashes.json').write_text(json.dumps(source_hashes,indent=2),encoding='utf-8')
    for path, h in source_hashes.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
    print('PASS: all 8 modality-model combinations; 2000 parent bootstraps; no input changes.',flush=True)


if __name__=='__main__':
    main()
