"""Raw prototypes for the fixed-equal-weight fusion ablation."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import load_base

DATA = Path(__file__).resolve().parents[3]
m = load_base("02_raw_prototypes.py", "raw_wo_gate_base")
m.ROOT = DATA
m.DEFAULT_INPUT_PT = DATA / "Long_fusion_subtype2_nogate" / "long_fusion_subtype2_nogate.pt"
m.DEFAULT_OUTPUT_PT = DATA / "Raw_subtype_prototypes_subtype2_nogate" / "raw_ARG_subtype_prototypes_and_baseline.pt"
m.main()
