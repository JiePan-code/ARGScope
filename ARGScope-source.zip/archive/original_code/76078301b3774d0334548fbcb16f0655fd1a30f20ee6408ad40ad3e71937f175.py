# -*- coding: utf-8 -*-
"""
Apply DNA_model_818 to LOCAL DNABERT-2 CLS embeddings generated from
Diamond0.2 candidate reads.

Expected folder layout
----------------------
DNABERT2_Diamond0.2_candidate_CLS_embeddings/
|
|-- apply_DNA_model_818_to_Diamond0.2_embeddings_LOCAL.py
|
|-- argbert_1_diamond0.2_candidate_reads/
|-- argbert_2_diamond0.2_candidate_reads/
|-- argbert_3_diamond0.2_candidate_reads/
|-- argscope_1_diamond0.2_candidate_reads/
|-- argscope_2_diamond0.2_candidate_reads/
|-- argscope_3_diamond0.2_candidate_reads/
|-- argscope_4_diamond0.2_candidate_reads/
|-- argscope_5_diamond0.2_candidate_reads/
|-- argscope_6_diamond0.2_candidate_reads/
|
|-- DNA_model_818/
|   |-- DNA_student_fusion_refined_model.pt
|   `-- structure_50aa_150nt_5parts.txt
|
|-- all_Diamond0.2_candidate_CLS_embedding_summary.json
`-- DNABERT2_CLS_environment_manifest.json

Prediction logic
----------------
DNABERT-2 CLS embedding
    -> DNAStudent
    -> binary ARG/nonARG head
    -> ARG subtype head
    -> final predicted_subtype
    -> Subtype -> Type mapping from structure_50aa_150nt_5parts.txt

Important
---------
1. The model uses the binary ARG threshold stored in the checkpoint.
2. Type is NOT a learned model head; Type is derived from predicted Subtype.
3. Per-read output keeps:
       ARG_probability
       ARG_subtype_max_probability
   so later gate recalibration can be done without rerunning the model.
4. CUDA AMP is enabled by default when CUDA is available.
5. One PT chunk is loaded at a time.
6. Completed chunks support resume via *.complete.json.
"""

from __future__ import annotations

import csv
import gc
import gzip
import hashlib
import json
import os
import time
from collections import Counter
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


# =============================================================================
# 1. PATHS / PARAMETERS
# =============================================================================

HERE = Path(__file__).resolve().parent
ROOT = HERE

SAMPLES = [
    "argbert_1_diamond0.2_candidate_reads",
    "argbert_2_diamond0.2_candidate_reads",
    "argbert_3_diamond0.2_candidate_reads",
    "argscope_1_diamond0.2_candidate_reads",
    "argscope_2_diamond0.2_candidate_reads",
    "argscope_3_diamond0.2_candidate_reads",
    "argscope_4_diamond0.2_candidate_reads",
    "argscope_5_diamond0.2_candidate_reads",
    "argscope_6_diamond0.2_candidate_reads",
]

MODEL_DIR = ROOT / "DNA_model_818"
MODEL_PATH = MODEL_DIR / "DNA_student_fusion_refined_model.pt"
STRUCTURE_PATH = MODEL_DIR / "structure_50aa_150nt_5parts.txt"

OUTPUT_ROOT = ROOT / "DNA_model_818_Diamond0.2_predictions"

BATCH_SIZE = 1024
PRINT_EVERY = 100_000

USE_AMP = True
OVERWRITE = False
WRITE_PER_READ_PREDICTIONS = True

SCRIPT_VERSION = "2026-08-18-local-DNA818-Diamond0.2-candidate-v2-shortpath"
NONARG = "nonARG"


# =============================================================================
# 2. MODEL
# =============================================================================

class CosineHead(nn.Module):
    def __init__(
        self,
        number_classes: int,
        dimension: int,
        scale: float,
    ):
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(
                number_classes,
                dimension,
            )
        )

        nn.init.xavier_uniform_(
            self.weight
        )

        self.scale = float(scale)

    def forward(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:

        return self.scale * F.linear(
            F.normalize(
                features,
                p=2,
                dim=1,
            ),
            F.normalize(
                self.weight,
                p=2,
                dim=1,
            ),
        )


class ResidualBlock(nn.Module):
    def __init__(
        self,
        dimension: int,
        dropout: float,
    ):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
            nn.GELU(),
            nn.Dropout(
                dropout
            ),
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:

        return F.gelu(
            x + self.net(x)
        )


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        hidden_dimension: int,
        embedding_dimension: int,
        dropout: float,
        binary_scale: float,
        subtype_scale: float,
    ):
        super().__init__()

        self.register_buffer(
            "dna_mean",
            dna_mean.clone().float(),
        )

        self.register_buffer(
            "dna_std",
            dna_std.clone().float(),
        )

        self.input = nn.Sequential(
            nn.Linear(
                dna_dimension,
                hidden_dimension,
            ),
            nn.LayerNorm(
                hidden_dimension
            ),
            nn.GELU(),
            nn.Dropout(
                dropout
            ),
        )

        self.blocks = nn.Sequential(
            ResidualBlock(
                hidden_dimension,
                dropout,
            ),
            ResidualBlock(
                hidden_dimension,
                dropout,
            ),
        )

        self.output = nn.Sequential(
            nn.Linear(
                hidden_dimension,
                embedding_dimension,
            ),
            nn.LayerNorm(
                embedding_dimension
            ),
        )

        self.binary_head = CosineHead(
            2,
            embedding_dimension,
            binary_scale,
        )

        self.arg_head = CosineHead(
            number_arg_subtypes,
            embedding_dimension,
            subtype_scale,
        )

    def encode(
        self,
        dna: torch.Tensor,
    ) -> torch.Tensor:

        dna = (
            dna - self.dna_mean
        ) / self.dna_std

        hidden = self.blocks(
            self.input(dna)
        )

        return F.normalize(
            self.output(hidden),
            p=2,
            dim=1,
        )

    def forward(
        self,
        dna: torch.Tensor,
    ):
        features = self.encode(dna)

        return (
            self.binary_head(features),
            self.arg_head(features),
            features,
        )


# =============================================================================
# 3. HELPERS
# =============================================================================

def canonical_id(
    value: Any,
) -> str:
    return str(value).strip().split()[0]


def canonical_subtype(
    value: Any,
) -> str:
    text = str(value).strip()
    return NONARG if text.lower() == "nonarg" else text


def canonical_type(
    value: Any,
) -> str:
    text = str(value).strip()
    return NONARG if text.lower() == "nonarg" else text


def load_pt(
    path: Path,
) -> Any:
    try:
        return torch.load(
            path,
            map_location="cpu",
            weights_only=False,
        )
    except TypeError:
        return torch.load(
            path,
            map_location="cpu",
        )


def sha256_file(
    path: Path,
    block_size: int = 8 * 1024 * 1024,
) -> str:

    digest = hashlib.sha256()

    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)

            if not block:
                break

            digest.update(block)

    return digest.hexdigest()


def atomic_json(
    path: Path,
    payload: dict[str, Any],
) -> None:

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def write_csv(
    path: Path,
    rows: list[dict[str, Any]],
) -> None:

    if not rows:
        return

    fields = []
    seen = set()

    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
        )

        writer.writeheader()
        writer.writerows(rows)

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def counter_from_dict(
    value: Any,
) -> Counter[str]:

    if not isinstance(
        value,
        dict,
    ):
        return Counter()

    return Counter(
        {
            str(k): int(v)
            for k, v
            in value.items()
        }
    )


# =============================================================================
# 4. LOAD MODEL
# =============================================================================

def load_model(
    checkpoint_path: Path,
    device: torch.device,
):

    checkpoint = load_pt(
        checkpoint_path
    )

    if not isinstance(
        checkpoint,
        dict,
    ):
        raise TypeError(
            f"Checkpoint must contain a dict: {checkpoint_path}"
        )

    required = {
        "student_state_dict",
        "dna_input_dimension",
        "embedding_dimension",
        "arg_subtype_names",
        "dna_train_mean",
        "dna_train_std",
        "configuration",
    }

    missing = sorted(
        required - set(checkpoint)
    )

    if missing:
        raise KeyError(
            f"Checkpoint missing fields: {missing}"
        )

    config = checkpoint[
        "configuration"
    ]

    arg_names = [
        canonical_subtype(value)
        for value
        in checkpoint[
            "arg_subtype_names"
        ]
    ]

    if NONARG in arg_names:
        raise ValueError(
            "arg_subtype_names unexpectedly contains nonARG."
        )

    dna_dimension = int(
        checkpoint[
            "dna_input_dimension"
        ]
    )

    embedding_dimension = int(
        checkpoint[
            "embedding_dimension"
        ]
    )

    model = DNAStudent(
        dna_dimension=dna_dimension,
        dna_mean=checkpoint[
            "dna_train_mean"
        ],
        dna_std=checkpoint[
            "dna_train_std"
        ],
        number_arg_subtypes=len(
            arg_names
        ),
        hidden_dimension=int(
            config.get(
                "hidden_dim",
                1024,
            )
        ),
        embedding_dimension=embedding_dimension,
        dropout=float(
            config.get(
                "dropout",
                0.18,
            )
        ),
        binary_scale=float(
            config.get(
                "logit_scale_binary",
                16.0,
            )
        ),
        subtype_scale=float(
            config.get(
                "logit_scale_subtype",
                24.0,
            )
        ),
    )

    model.load_state_dict(
        checkpoint[
            "student_state_dict"
        ],
        strict=True,
    )

    model.to(
        device
    ).eval()

    threshold = float(
        checkpoint.get(
            "selected_binary_ARG_probability_threshold",
            0.50,
        )
    )

    if not (
        0.0 < threshold < 1.0
    ):
        raise ValueError(
            f"Invalid saved binary threshold: {threshold}"
        )

    return (
        model,
        checkpoint,
        threshold,
        arg_names,
    )


# =============================================================================
# 5. SUBTYPE -> TYPE
# =============================================================================

def load_subtype_to_type(
    structure_path: Path,
    arg_names: list[str],
) -> dict[str, str]:

    mapping = {
        NONARG: NONARG
    }

    with structure_path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                f"Structure file has no header: {structure_path}"
            )

        required = {
            "Subtype",
            "Type",
        }

        missing = sorted(
            required - set(reader.fieldnames)
        )

        if missing:
            raise ValueError(
                f"Structure file missing columns {missing}. "
                f"Columns={reader.fieldnames}"
            )

        for line_number, row in enumerate(
            reader,
            start=2,
        ):

            subtype = canonical_subtype(
                row["Subtype"]
            )

            type_name = canonical_type(
                row["Type"]
            )

            if subtype == NONARG:
                type_name = NONARG

            if (
                subtype in mapping
                and mapping[
                    subtype
                ]
                != type_name
            ):
                raise ValueError(
                    "Subtype -> Type conflict: "
                    f"{subtype}: "
                    f"{mapping[subtype]} vs {type_name} "
                    f"(line {line_number})"
                )

            mapping[
                subtype
            ] = type_name

    missing_model_subtypes = sorted(
        set(arg_names)
        - set(mapping)
    )

    if missing_model_subtypes:
        raise ValueError(
            f"{len(missing_model_subtypes)} model ARG subtype(s) "
            "have no Type mapping. Examples: "
            f"{missing_model_subtypes[:20]}"
        )

    return mapping


# =============================================================================
# 6. EMBEDDING INPUT
# =============================================================================

def discover_embedding_files(
    sample_dir: Path,
) -> list[Path]:

    files = sorted(
        path
        for path
        in sample_dir.glob(
            "*_dnabert2_CLS.pt"
        )
        if path.is_file()
    )

    if not files:
        raise FileNotFoundError(
            "No *_dnabert2_CLS.pt files found in:\n"
            f"{sample_dir}"
        )

    return files


def load_embedding_chunk(
    path: Path,
    expected_dimension: int,
):

    obj = load_pt(
        path
    )

    if not isinstance(
        obj,
        dict,
    ):
        raise TypeError(
            f"Embedding PT must contain a dict: {path}"
        )

    id_key = next(
        (
            key
            for key in (
                "ids",
                "fragment_ids",
                "sequence_ids",
            )
            if key in obj
        ),
        None,
    )

    embedding_key = next(
        (
            key
            for key in (
                "embeddings",
                "features",
                "mean_embeddings",
            )
            if key in obj
        ),
        None,
    )

    if (
        id_key is None
        or embedding_key is None
    ):
        raise KeyError(
            f"Cannot find IDs/embeddings in {path}. "
            f"Keys={sorted(obj.keys())}"
        )

    ids = [
        canonical_id(value)
        for value
        in obj[id_key]
    ]

    embeddings = obj[
        embedding_key
    ]

    if not isinstance(
        embeddings,
        torch.Tensor,
    ):
        raise TypeError(
            f"Embeddings are not torch.Tensor: {path}"
        )

    embeddings = (
        embeddings
        .detach()
        .cpu()
        .float()
        .contiguous()
    )

    if embeddings.ndim != 2:
        raise ValueError(
            f"Embedding tensor must be 2D: "
            f"{path}, shape={tuple(embeddings.shape)}"
        )

    expected_shape = (
        len(ids),
        expected_dimension,
    )

    if tuple(
        embeddings.shape
    ) != expected_shape:
        raise ValueError(
            f"Unexpected embedding shape "
            f"{tuple(embeddings.shape)}; "
            f"expected {expected_shape}; file={path}"
        )

    if not bool(
        torch.isfinite(
            embeddings
        ).all()
    ):
        raise ValueError(
            f"NaN/Inf detected in embeddings: {path}"
        )

    pooling = str(
        obj.get(
            "pooling",
            "",
        )
    ).strip()

    if pooling:
        pooling_lower = (
            pooling.lower()
        )

        if (
            "cls"
            not in pooling_lower
            and "first_token"
            not in pooling_lower
        ):
            raise ValueError(
                "Embedding pooling is not CLS/first-token: "
                f"{path} -> {pooling!r}"
            )

    if (
        "truncation" in obj
        and obj[
            "truncation"
        ] is not True
    ):
        raise ValueError(
            f"Embedding metadata says truncation != True: {path}"
        )

    if (
        "max_token_length" in obj
        and int(
            obj[
                "max_token_length"
            ]
        )
        != 512
    ):
        raise ValueError(
            f"Embedding max_token_length != 512: "
            f"{path} -> {obj['max_token_length']}"
        )

    metadata = {
        "pooling": obj.get(
            "pooling"
        ),
        "truncation": obj.get(
            "truncation"
        ),
        "max_token_length": obj.get(
            "max_token_length"
        ),
        "num_sequences": len(
            ids
        ),
        "embedding_dim": int(
            embeddings.shape[1]
        ),
    }

    return (
        ids,
        embeddings,
        metadata,
    )


# =============================================================================
# 7. OUTPUT PATHS / RESUME
# =============================================================================

def chunk_output_paths(
    output_dir: Path,
    input_pt: Path,
) -> tuple[
    Path,
    Path,
]:
    """
    Use deliberately SHORT output filenames.

    The previous filename repeated the full sample/chunk stem and pushed
    Windows paths to the legacy MAX_PATH boundary (260 characters).
    Example of the new names:
        chunk_000001_pred.csv.gz
        chunk_000001.complete.json
    """

    stem = input_pt.stem

    if "_chunk_" in stem:
        chunk_part = stem.split("_chunk_", 1)[1]
        chunk_id = chunk_part.split("_", 1)[0]
    else:
        chunk_id = "000001"

    prediction_path = (
        output_dir
        / f"chunk_{chunk_id}_pred.csv.gz"
    )

    completion_path = (
        output_dir
        / f"chunk_{chunk_id}.complete.json"
    )

    return (
        prediction_path,
        completion_path,
    )


def completion_is_valid(
    completion_path: Path,
    prediction_path: Path,
    input_pt: Path,
    model_sha256: str,
    structure_sha256: str,
    write_predictions: bool,
) -> dict[str, Any] | None:

    if not completion_path.is_file():
        return None

    if (
        write_predictions
        and not prediction_path.is_file()
    ):
        return None

    try:

        with completion_path.open(
            "r",
            encoding="utf-8",
        ) as handle:

            completion = json.load(handle)

        valid = (
            completion.get(
                "status"
            )
            == "COMPLETED"
            and completion.get(
                "script_version"
            )
            == SCRIPT_VERSION
            and completion.get(
                "input_pt"
            )
            == str(input_pt)
            and int(
                completion.get(
                    "input_size_bytes",
                    -1,
                )
            )
            == input_pt.stat().st_size
            and int(
                completion.get(
                    "input_mtime_ns",
                    -1,
                )
            )
            == input_pt.stat().st_mtime_ns
            and completion.get(
                "model_sha256"
            )
            == model_sha256
            and completion.get(
                "structure_sha256"
            )
            == structure_sha256
            and completion.get(
                "write_predictions"
            )
            == write_predictions
        )

        if (
            valid
            and write_predictions
            and int(
                completion.get(
                    "prediction_size_bytes",
                    -1,
                )
            )
            != prediction_path.stat().st_size
        ):
            valid = False

        return (
            completion
            if valid
            else None
        )

    except Exception:
        return None


# =============================================================================
# 8. INFERENCE
# =============================================================================

@torch.no_grad()
def infer_chunk(
    ids: list[str],
    embeddings: torch.Tensor,
    input_pt: Path,
    output_dir: Path,
    model: DNAStudent,
    arg_names: list[str],
    subtype_to_type: dict[str, str],
    threshold: float,
    device: torch.device,
    use_amp: bool,
):

    prediction_path, _ = chunk_output_paths(
        output_dir,
        input_pt,
    )

    temp_path = prediction_path.with_suffix(
        prediction_path.suffix
        + ".tmp"
    )

    binary_counts = Counter()
    subtype_counts = Counter()
    type_counts = Counter()

    total_reads = len(ids)
    predicted_arg_count = 0

    sum_arg_probability = 0.0
    sum_subtype_probability_arg = 0.0

    started = time.time()
    next_print = PRINT_EVERY

    gzip_handle = None
    writer = None

    if WRITE_PER_READ_PREDICTIONS:

        # Windows safety check. The new compact filename should stay well
        # below the legacy 260-character path limit.
        if os.name == "nt":
            print(
                f"    output path length={len(str(temp_path))} | "
                f"{temp_path.name}",
                flush=True,
            )

        gzip_handle = gzip.open(
            temp_path,
            "wt",
            encoding="utf-8",
            newline="",
            compresslevel=3,
        )

        writer = csv.writer(
            gzip_handle,
            lineterminator="\n",
        )

        writer.writerow(
            [
                "read_id",
                "predicted_ARG",
                "ARG_probability",
                "predicted_subtype",
                "ARG_head_predicted_subtype",
                "predicted_type",
                "ARG_subtype_max_probability",
                "binary_threshold",
                "coverage",
            ]
        )

    try:

        for start in range(
            0,
            total_reads,
            BATCH_SIZE,
        ):

            end = min(
                start + BATCH_SIZE,
                total_reads,
            )

            batch = (
                embeddings[
                    start:end
                ]
                .to(
                    device,
                    non_blocking=True,
                )
            )

            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=(
                    use_amp
                    and device.type == "cuda"
                ),
            ):

                (
                    binary_logits,
                    subtype_logits,
                    _,
                ) = model(
                    batch
                )

            arg_probability = (
                torch.softmax(
                    binary_logits.float(),
                    dim=1,
                )[:, 1]
            )

            subtype_softmax = (
                torch.softmax(
                    subtype_logits.float(),
                    dim=1,
                )
            )

            (
                subtype_probability,
                subtype_index,
            ) = torch.max(
                subtype_softmax,
                dim=1,
            )

            predicted_arg = (
                arg_probability
                >= threshold
            )

            arg_probability_cpu = (
                arg_probability
                .cpu()
                .tolist()
            )

            subtype_probability_cpu = (
                subtype_probability
                .cpu()
                .tolist()
            )

            subtype_index_cpu = (
                subtype_index
                .cpu()
                .tolist()
            )

            predicted_arg_cpu = (
                predicted_arg
                .cpu()
                .tolist()
            )

            rows = []

            for local_index in range(
                end - start
            ):

                is_arg = bool(
                    predicted_arg_cpu[
                        local_index
                    ]
                )

                arg_head_subtype = arg_names[
                    int(
                        subtype_index_cpu[
                            local_index
                        ]
                    )
                ]

                final_subtype = (
                    arg_head_subtype
                    if is_arg
                    else NONARG
                )

                final_type = (
                    subtype_to_type[
                        final_subtype
                    ]
                )

                arg_p = float(
                    arg_probability_cpu[
                        local_index
                    ]
                )

                subtype_p = float(
                    subtype_probability_cpu[
                        local_index
                    ]
                )

                if is_arg:
                    predicted_arg_count += 1
                    sum_subtype_probability_arg += subtype_p

                sum_arg_probability += arg_p

                binary_counts[
                    "ARG"
                    if is_arg
                    else NONARG
                ] += 1

                subtype_counts[
                    final_subtype
                ] += 1

                type_counts[
                    final_type
                ] += 1

                if writer is not None:

                    rows.append(
                        [
                            ids[
                                start
                                + local_index
                            ],
                            int(is_arg),
                            f"{arg_p:.8f}",
                            final_subtype,
                            arg_head_subtype,
                            final_type,
                            f"{subtype_p:.8f}",
                            f"{threshold:.8f}",
                            "1.0",
                        ]
                    )

            if (
                writer is not None
                and rows
            ):
                writer.writerows(rows)

            processed = end

            if (
                processed >= next_print
                or processed == total_reads
            ):

                elapsed = (
                    time.time()
                    - started
                )

                speed = (
                    processed / elapsed
                    if elapsed > 0
                    else 0.0
                )

                print(
                    f"    predicted={processed:,}/{total_reads:,} | "
                    f"ARG={predicted_arg_count:,} | "
                    f"speed={speed:,.1f} reads/s",
                    flush=True,
                )

                next_print = (
                    (
                        processed
                        // PRINT_EVERY
                    )
                    + 1
                ) * PRINT_EVERY

            del (
                batch,
                binary_logits,
                subtype_logits,
                arg_probability,
                subtype_softmax,
                subtype_probability,
                subtype_index,
                predicted_arg,
            )

        if gzip_handle is not None:

            gzip_handle.close()
            gzip_handle = None

            os.replace(
                temp_path,
                prediction_path,
            )

    except Exception:

        if gzip_handle is not None:
            gzip_handle.close()

        if temp_path.exists():
            temp_path.unlink()

        raise

    elapsed = (
        time.time()
        - started
    )

    return {
        "num_sequences": total_reads,
        "predicted_ARG_count": predicted_arg_count,
        "predicted_nonARG_count": (
            total_reads
            - predicted_arg_count
        ),
        "predicted_ARG_fraction": (
            predicted_arg_count
            / total_reads
            if total_reads
            else 0.0
        ),
        "mean_ARG_probability": (
            sum_arg_probability
            / total_reads
            if total_reads
            else 0.0
        ),
        "mean_subtype_max_probability_among_predicted_ARG": (
            sum_subtype_probability_arg
            / predicted_arg_count
            if predicted_arg_count
            else 0.0
        ),
        "binary_counts": dict(
            binary_counts
        ),
        "subtype_counts": dict(
            subtype_counts
        ),
        "type_counts": dict(
            type_counts
        ),
        "elapsed_seconds": elapsed,
        "prediction_file": (
            str(prediction_path)
            if WRITE_PER_READ_PREDICTIONS
            else None
        ),
    }


# =============================================================================
# 9. COUNT TABLE
# =============================================================================

def write_count_table(
    path: Path,
    sample: str,
    counter: Counter,
    label_name: str,
    total_reads: int,
) -> None:

    rows = []

    for label, count in sorted(
        counter.items(),
        key=lambda item: (
            -item[1],
            item[0].lower(),
        ),
    ):

        rows.append(
            {
                label_name: label,
                "sample": sample,
                "count": int(count),
                "fraction_of_candidate_reads": (
                    count / total_reads
                    if total_reads
                    else 0.0
                ),
            }
        )

    write_csv(
        path,
        rows,
    )


# =============================================================================
# 10. PROCESS ONE SAMPLE
# =============================================================================

def process_sample(
    sample: str,
    model: DNAStudent,
    checkpoint: dict,
    arg_names: list[str],
    subtype_to_type: dict[str, str],
    threshold: float,
    model_sha256: str,
    structure_sha256: str,
    device: torch.device,
    use_amp: bool,
):

    sample_dir = (
        ROOT / sample
    )

    if not sample_dir.is_dir():
        raise FileNotFoundError(
            f"Sample directory not found:\n{sample_dir}"
        )

    pt_files = discover_embedding_files(
        sample_dir
    )

    output_dir = (
        OUTPUT_ROOT / sample
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Whole-sample resume:
    # If this sample already finished successfully in a previous run
    # (e.g. argbert_1/2/3 from v1), reuse its summary and do not rerun it.
    sample_summary_path = (
        output_dir
        / "ARGScope_prediction_summary.json"
    )

    if (
        not OVERWRITE
        and sample_summary_path.is_file()
    ):
        try:
            with sample_summary_path.open(
                "r",
                encoding="utf-8",
            ) as handle:
                existing_sample_summary = json.load(handle)

            same_sample = (
                existing_sample_summary.get("sample")
                == sample
            )

            same_threshold = (
                abs(
                    float(
                        existing_sample_summary.get(
                            "binary_threshold",
                            -1.0,
                        )
                    )
                    - float(threshold)
                )
                < 1e-12
            )

            if same_sample and same_threshold:
                print()
                print("=" * 120)
                print(f"SAMPLE: {sample}")
                print("=" * 120)
                print(
                    "WHOLE-SAMPLE RESUME: existing completed summary found; "
                    "this sample will NOT be rerun.",
                    flush=True,
                )
                print(
                    f"Summary: {sample_summary_path}",
                    flush=True,
                )
                return existing_sample_summary

        except Exception as exc:
            print(
                f"Existing sample summary could not be reused: {exc}",
                flush=True,
            )

    print()
    print("=" * 120)
    print(f"SAMPLE: {sample}")
    print("=" * 120)
    print(f"Embedding directory : {sample_dir}")
    print(f"Embedding chunks    : {len(pt_files):,}")
    print(f"Output directory    : {output_dir}")
    print("=" * 120)

    global_binary = Counter()
    global_subtype = Counter()
    global_type = Counter()

    total_reads = 0
    total_arg = 0

    manifest_rows = []

    sample_started = time.time()

    for chunk_number, pt_path in enumerate(
        pt_files,
        start=1,
    ):

        (
            prediction_path,
            completion_path,
        ) = chunk_output_paths(
            output_dir,
            pt_path,
        )

        print()
        print(
            f"[{chunk_number}/{len(pt_files)}] "
            f"{pt_path.name}",
            flush=True,
        )

        result = None
        metadata = {}

        if not OVERWRITE:

            existing = completion_is_valid(
                completion_path=completion_path,
                prediction_path=prediction_path,
                input_pt=pt_path,
                model_sha256=model_sha256,
                structure_sha256=structure_sha256,
                write_predictions=WRITE_PER_READ_PREDICTIONS,
            )

            if existing is not None:

                print(
                    "  RESUME: valid completed chunk",
                    flush=True,
                )

                result = existing
                metadata = existing.get(
                    "embedding_metadata",
                    {},
                )

        if result is None:

            (
                ids,
                embeddings,
                metadata,
            ) = load_embedding_chunk(
                pt_path,
                int(
                    checkpoint[
                        "dna_input_dimension"
                    ]
                ),
            )

            print(
                f"  shape            : {tuple(embeddings.shape)}",
                flush=True,
            )
            print(
                f"  pooling          : {metadata.get('pooling')}",
                flush=True,
            )
            print(
                f"  truncation       : {metadata.get('truncation')}",
                flush=True,
            )
            print(
                f"  max_token_length : {metadata.get('max_token_length')}",
                flush=True,
            )

            inference_result = infer_chunk(
                ids=ids,
                embeddings=embeddings,
                input_pt=pt_path,
                output_dir=output_dir,
                model=model,
                arg_names=arg_names,
                subtype_to_type=subtype_to_type,
                threshold=threshold,
                device=device,
                use_amp=use_amp,
            )

            completion = {
                "status": "COMPLETED",
                "script_version": SCRIPT_VERSION,
                "sample": sample,
                "input_pt": str(pt_path),
                "input_size_bytes": pt_path.stat().st_size,
                "input_mtime_ns": pt_path.stat().st_mtime_ns,
                "model": str(MODEL_PATH),
                "model_sha256": model_sha256,
                "structure": str(STRUCTURE_PATH),
                "structure_sha256": structure_sha256,
                "binary_threshold": threshold,
                "batch_size": BATCH_SIZE,
                "amp": use_amp,
                "write_predictions": WRITE_PER_READ_PREDICTIONS,
                "prediction_file": (
                    str(prediction_path)
                    if WRITE_PER_READ_PREDICTIONS
                    else None
                ),
                "prediction_size_bytes": (
                    prediction_path.stat().st_size
                    if WRITE_PER_READ_PREDICTIONS
                    else 0
                ),
                "embedding_metadata": metadata,
                **inference_result,
            }

            atomic_json(
                completion_path,
                completion,
            )

            result = completion

            del (
                ids,
                embeddings,
            )

            gc.collect()

            if device.type == "cuda":
                torch.cuda.empty_cache()

        global_binary.update(
            counter_from_dict(
                result[
                    "binary_counts"
                ]
            )
        )

        global_subtype.update(
            counter_from_dict(
                result[
                    "subtype_counts"
                ]
            )
        )

        global_type.update(
            counter_from_dict(
                result[
                    "type_counts"
                ]
            )
        )

        total_reads += int(
            result[
                "num_sequences"
            ]
        )

        total_arg += int(
            result[
                "predicted_ARG_count"
            ]
        )

        manifest_rows.append(
            {
                "chunk_number": chunk_number,
                "input_pt": pt_path.name,
                "num_candidate_reads": int(
                    result[
                        "num_sequences"
                    ]
                ),
                "predicted_ARG_count": int(
                    result[
                        "predicted_ARG_count"
                    ]
                ),
                "predicted_nonARG_count": int(
                    result[
                        "predicted_nonARG_count"
                    ]
                ),
                "predicted_ARG_fraction": float(
                    result[
                        "predicted_ARG_fraction"
                    ]
                ),
                "prediction_file": (
                    prediction_path.name
                    if WRITE_PER_READ_PREDICTIONS
                    else ""
                ),
            }
        )

        write_csv(
            output_dir
            / "ARGScope_prediction_manifest.csv",
            manifest_rows,
        )

    write_count_table(
        output_dir
        / "ARGScope_ARG_nonARG_counts.csv",
        sample,
        global_binary,
        "Class",
        total_reads,
    )

    write_count_table(
        output_dir
        / "ARGScope_subtype_counts.csv",
        sample,
        global_subtype,
        "Subtype",
        total_reads,
    )

    write_count_table(
        output_dir
        / "ARGScope_type_counts.csv",
        sample,
        global_type,
        "Type",
        total_reads,
    )

    summary = {
        "sample": sample,
        "candidate_reads_input": total_reads,
        "predicted_ARG_count": total_arg,
        "predicted_nonARG_count": (
            total_reads - total_arg
        ),
        "predicted_ARG_fraction_of_candidate_reads": (
            total_arg / total_reads
            if total_reads
            else 0.0
        ),
        "binary_threshold": threshold,
        "embedding_chunks": len(pt_files),
        "elapsed_minutes": round(
            (
                time.time()
                - sample_started
            )
            / 60.0,
            4,
        ),
    }

    atomic_json(
        output_dir
        / "ARGScope_prediction_summary.json",
        summary,
    )

    print()
    print(
        f"{sample} COMPLETED | "
        f"candidate reads={total_reads:,} | "
        f"predicted ARG={total_arg:,} | "
        f"ARG fraction="
        f"{summary['predicted_ARG_fraction_of_candidate_reads']:.8f}",
        flush=True,
    )

    return summary


# =============================================================================
# 11. MAIN
# =============================================================================

def main() -> None:

    print("=" * 120)
    print("DNA_model_818 -> Diamond0.2 candidate CLS embeddings")
    print("=" * 120)
    print(f"Root               : {ROOT}")
    print(f"Samples            : {len(SAMPLES)}")
    print(f"Model              : {MODEL_PATH}")
    print(f"Structure          : {STRUCTURE_PATH}")
    print(f"Output root        : {OUTPUT_ROOT}")
    print(f"Batch size         : {BATCH_SIZE:,}")
    print(f"Write predictions  : {WRITE_PER_READ_PREDICTIONS}")
    print("=" * 120)

    if not MODEL_PATH.is_file():
        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    if not STRUCTURE_PATH.is_file():
        raise FileNotFoundError(
            f"Structure mapping not found:\n{STRUCTURE_PATH}"
        )

    missing_sample_dirs = [
        ROOT / sample
        for sample in SAMPLES
        if not (
            ROOT / sample
        ).is_dir()
    ]

    if missing_sample_dirs:
        raise FileNotFoundError(
            "Missing embedding sample folder(s):\n"
            + "\n".join(
                str(path)
                for path
                in missing_sample_dirs
            )
        )

    device = torch.device(
        "cuda:0"
        if torch.cuda.is_available()
        else "cpu"
    )

    use_amp = (
        USE_AMP
        and device.type == "cuda"
    )

    print(
        f"Device             : {device}"
    )

    if device.type == "cuda":
        print(
            f"GPU                : "
            f"{torch.cuda.get_device_name(0)}"
        )

    print(
        f"AMP                : {use_amp}"
    )

    model_sha256 = sha256_file(
        MODEL_PATH
    )

    structure_sha256 = sha256_file(
        STRUCTURE_PATH
    )

    (
        model,
        checkpoint,
        threshold,
        arg_names,
    ) = load_model(
        MODEL_PATH,
        device,
    )

    subtype_to_type = load_subtype_to_type(
        STRUCTURE_PATH,
        arg_names,
    )

    print()
    print(
        "DNA input dimension: "
        f"{checkpoint['dna_input_dimension']}"
    )
    print(
        f"ARG subtype count  : {len(arg_names):,}"
    )
    print(
        f"Saved ARG threshold: {threshold:.8f}"
    )
    print(
        f"Mapped subtype     : "
        f"{len(arg_names):,}/{len(arg_names):,}"
    )

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    summaries = []

    all_started = time.time()

    for index, sample in enumerate(
        SAMPLES,
        start=1,
    ):

        print()
        print(
            "#" * 120
        )
        print(
            f"DATASET {index}/{len(SAMPLES)}: {sample}"
        )
        print(
            "#" * 120
        )

        summary = process_sample(
            sample=sample,
            model=model,
            checkpoint=checkpoint,
            arg_names=arg_names,
            subtype_to_type=subtype_to_type,
            threshold=threshold,
            model_sha256=model_sha256,
            structure_sha256=structure_sha256,
            device=device,
            use_amp=use_amp,
        )

        summaries.append(summary)

        write_csv(
            OUTPUT_ROOT
            / "ALL_Diamond0.2_samples_overall_summary.csv",
            summaries,
        )

    overall_json = {
        "status": "COMPLETED",
        "script_version": SCRIPT_VERSION,
        "sample_count": len(SAMPLES),
        "samples_processed": SAMPLES,
        "model": str(MODEL_PATH),
        "model_sha256": model_sha256,
        "structure": str(STRUCTURE_PATH),
        "structure_sha256": structure_sha256,
        "binary_threshold": threshold,
        "dna_input_dimension": int(
            checkpoint[
                "dna_input_dimension"
            ]
        ),
        "ARG_subtype_count": len(
            arg_names
        ),
        "elapsed_minutes": round(
            (
                time.time()
                - all_started
            )
            / 60.0,
            4,
        ),
        "summaries": summaries,
    }

    atomic_json(
        OUTPUT_ROOT
        / "ALL_Diamond0.2_samples_overall_summary.json",
        overall_json,
    )

    print()
    print("=" * 120)
    print("ALL 9 DIAMOND0.2 DATASETS COMPLETED")
    print("=" * 120)

    for summary in summaries:

        print(
            f"{summary['sample']:<42} | "
            f"candidates={summary['candidate_reads_input']:>12,} | "
            f"ARG={summary['predicted_ARG_count']:>10,} | "
            f"fraction="
            f"{summary['predicted_ARG_fraction_of_candidate_reads']:.8f}"
        )

    print()
    print(
        "Overall CSV  : "
        f"{OUTPUT_ROOT / 'ALL_Diamond0.2_samples_overall_summary.csv'}"
    )
    print(
        "Overall JSON : "
        f"{OUTPUT_ROOT / 'ALL_Diamond0.2_samples_overall_summary.json'}"
    )
    print("=" * 120)


if __name__ == "__main__":
    main()
