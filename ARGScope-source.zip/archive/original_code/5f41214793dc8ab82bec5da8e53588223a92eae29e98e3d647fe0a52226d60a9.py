"""Figure 2/3 remaining panels, using verified existing data and UMAP coordinates."""
from pathlib import Path
import hashlib
import json
import shutil
import textwrap
import xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator, PercentFormatter
import numpy as np
import pandas as pd
from PIL import Image

HERE = Path(__file__).resolve().parent
TASK = HERE/'outputs/argscope_subtype_argonly_20260922'
OUT = TASK/'Figure2_Figure3_transparent_SVG'
ROOT = Path(r'E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW')
APP = ROOT.parent/'ARGScope_80_20_results/apply_argscope_protein_and_DNA'
PUBLICATION = APP/'ARGScope_publication_layout_panels'
MODELS = {'Protein':['ARGNet','DeepARG','PLM-ARG','FunGeneTyper','ARGScope'],
          'DNA':['ARGNet','DeepARG','ARGScope']}
COLORS = {'ARGNet':'#9c8756','DeepARG':'#d36652','PLM-ARG':'#62666c',
          'FunGeneTyper':'#4b90c2','ARGScope':'#2a9478'}
STYLES = {'ARGNet':('--','s'),'DeepARG':('-.','D'),'PLM-ARG':(':','^'),
          'FunGeneTyper':('--','v'),'ARGScope':('-','o')}
METRICS = ['Accuracy','Precision','Recall','F1','MCC']
AUDIT = []
INPUTS = {}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def source(path, **kwargs):
    INPUTS[str(path)] = sha(path)
    return pd.read_csv(path, **kwargs)


def no_overlap(texts, renderer, description):
    boxes = [t.get_window_extent(renderer) for t in texts if t.get_text()]
    for i, a in enumerate(boxes):
        for b in boxes[i+1:]:
            assert not a.overlaps(b), description


def save(fig, modality, letter, suffix, info):
    target = OUT/f'Figure{2 if modality=="Protein" else 3}_{modality}'
    target.mkdir(parents=True, exist_ok=True)
    stem = f'Figure{2 if modality=="Protein" else 3}{letter}_{modality}_{suffix}'
    fig.patch.set_alpha(0)
    for ax in fig.axes:
        ax.patch.set_alpha(0)
    fig.canvas.draw()
    for ext, dpi in [('svg',300),('png',200)]:
        folder = target if ext=='svg' else OUT/'previews'/target.name
        folder.mkdir(parents=True, exist_ok=True)
        fig.savefig(folder/f'{stem}.{ext}', dpi=dpi, transparent=True,
                    facecolor='none',edgecolor='none',bbox_inches='tight',pad_inches=0)
    svg = ET.parse(target/f'{stem}.svg').getroot()
    assert not svg.findall('.//{http://www.w3.org/2000/svg}image'), stem+' contains bitmap'
    bg = svg.find('.//{http://www.w3.org/2000/svg}g[@id="patch_1"]/{http://www.w3.org/2000/svg}path')
    assert bg is not None and 'fill: none' in bg.attrib.get('style',''), stem+' opaque background'
    png = Image.open(OUT/'previews'/target.name/f'{stem}.png').convert('RGBA')
    assert png.getchannel('A').getextrema()[0]==0
    info.update(panel=stem, svg=str(target/f'{stem}.svg'),transparent=True,
                bitmap_elements=0,pad_inches=0,svg_sha256=sha(target/f'{stem}.svg'))
    AUDIT.append(info)
    plt.close(fig)
    print('SAVED '+stem,flush=True)


def radar(modality):
    path = ROOT/modality/'06_ARG_nonARG_macro_weighted_micro.csv'
    all_rows = source(path)
    rows = all_rows[all_rows.Completeness.eq(100)&all_rows.Average.eq('macro')].set_index('Model')
    assert len(rows)==len(MODELS[modality])
    assert rows.Scope.eq('ARG_and_nonARG').all() and rows.N_labels_averaged.eq(2).all()
    theta = np.linspace(0,2*np.pi,5,endpoint=False)
    closed = np.r_[theta,theta[0]]
    fig = plt.figure(figsize=(5.4,5.5))
    ax = fig.add_axes([.17,.23,.68,.68],projection='polar')
    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    ax.set_xticks(theta,['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC'],fontsize=12)
    ax.tick_params(axis='x',pad=10)
    for label,align in zip(ax.get_xticklabels(),['center','left','left','right','right']):
        label.set_horizontalalignment(align)
    ax.set_ylim(0,1)
    ax.set_yticks([.2,.4,.6,.8,1],['0.2','0.4','0.6','0.8','1.0'],fontsize=9,color='#687680')
    ax.set_rlabel_position(22)
    ax.grid(color='#dce3e6',linewidth=.65)
    ax.spines['polar'].set_color('#afbbc2')
    ax.spines['polar'].set_linewidth(.8)
    for model in MODELS[modality]:
        vals = rows.loc[model,METRICS].to_numpy(dtype=float)
        assert np.isfinite(vals).all() and (vals>=0).all() and (vals<=1).all()
        ls, marker = STYLES[model]
        ln, = ax.plot(closed,np.r_[vals,vals[0]],color=COLORS[model],ls=ls,marker=marker,
                      lw=1.65 if model=='ARGScope' else 1.25,markersize=4.2,label=model,clip_on=False)
        np.testing.assert_array_equal(ln.get_ydata()[:-1],vals)
        if model=='ARGScope':
            ax.fill(closed,np.r_[vals,vals[0]],color=COLORS[model],alpha=.055)
    leg = ax.legend(loc='upper center',bbox_to_anchor=(.5,-.10),ncol=3,
                    fontsize=10,frameon=False,handlelength=1.8,columnspacing=1.1,
                    handletextpad=.5,borderaxespad=0,labelspacing=.55)
    fig.canvas.draw()
    no_overlap(leg.get_texts(),fig.canvas.get_renderer(),'Radar legend collision')
    d = OUT/'plot_data'/modality
    d.mkdir(parents=True,exist_ok=True)
    rows.loc[MODELS[modality]].to_csv(d/'A_binary_macro_source.csv',encoding='utf-8-sig')
    save(fig,modality,'A','100pct_ARG_nonARG_radar',dict(source=str(path),values_unchanged=True))


def verified_error_data(modality):
    mod = modality.lower()
    path = APP/mod/'100%_test_sequence_predictions.csv'
    raw = source(path,keep_default_na=False)
    manifest = source(ROOT/'input_file_manifest.csv')
    assert sha(path)==manifest.loc[manifest.Path.eq(str(path)),'SHA256'].item()
    raw = raw[raw['split'].eq('test')]
    assert len(raw)==4574 and raw.sequence_id.is_unique
    base = ROOT/'figures_error_analysis_100pct/data'/mod
    full = source(base/'full_confusion_counts_audit.csv',index_col=0)
    assert full.index[-1]=='nonARG'
    order = full.index[:-1].tolist()
    actual = pd.crosstab(raw.true_type,raw.predicted_type).reindex(index=full.index,columns=full.columns,fill_value=0)
    np.testing.assert_array_equal(actual.to_numpy(),full.to_numpy())
    core = actual.iloc[:-1,:-1].to_numpy()
    denom = actual.iloc[:-1,:].sum(axis=1).to_numpy()
    norm = source(base/'D_row_normalized_23types.csv',index_col=0)
    np.testing.assert_allclose(norm.to_numpy(),core/denom[:,None],atol=1e-14,rtol=0)
    errors = source(base/'E_off_diagonal_counts_23types.csv',index_col=0)
    independent = core.copy()
    np.fill_diagonal(independent,0)
    np.testing.assert_array_equal(errors.to_numpy(),independent)
    arg = raw[raw.true_type.ne('nonARG')].copy()
    err = arg[arg.true_subtype.ne(arg.predicted_subtype)].copy()
    err['Type_correct_count'] = err.true_type.eq(err.predicted_type).astype(int)
    keys = ['true_subtype','predicted_subtype','true_type','predicted_type']
    pairs = err.groupby(keys).agg(Count=('sequence_id','size'),Type_correct_count=('Type_correct_count','sum')).reset_index()
    pairs['Type_correct_percent'] = pairs.Type_correct_count/pairs.Count*100
    original = source(base/'F_all_subtype_error_pairs.csv',keep_default_na=False)
    pd.testing.assert_frame_equal(pairs.sort_values(keys).reset_index(drop=True),
                                 original.sort_values(keys).reset_index(drop=True),check_dtype=False)
    top = source(base/'F_displayed_top20.csv',keep_default_na=False)
    pd.testing.assert_frame_equal(top,original.head(20),check_dtype=False)
    for filename in ['full_confusion_counts_audit.csv','D_row_normalized_23types.csv',
                     'E_off_diagonal_counts_23types.csv','F_all_subtype_error_pairs.csv','F_displayed_top20.csv']:
        shutil.copy2(base/filename,OUT/'plot_data'/modality/filename)
    return order,norm,errors,top,arg


def matrix(modality,order,frame,kind,display):
    errors = kind=='errors'
    array = frame.to_numpy(dtype=float)
    vmax = max(1,float(array.max())) if errors else 1
    cmap = plt.get_cmap('Blues' if modality=='Protein' else 'Oranges').copy()
    if errors:
        array = np.ma.array(array,mask=np.eye(23,dtype=bool))
        cmap.set_bad('#eeeeee')
    fig = plt.figure(figsize=(7.4,7.3))
    ax = fig.add_axes([.245,.26,.66,.669])
    im = ax.pcolormesh(np.arange(24)-.5,np.arange(24)-.5,array,
                       cmap=cmap,vmin=0,vmax=vmax,rasterized=False,shading='flat',linewidth=0)
    ax.set_xlim(-.5,22.5)
    ax.set_ylim(22.5,-.5)
    ax.set_aspect('equal')
    ax.set_xticks(range(23),[display[t] for t in order],rotation=58,ha='right',rotation_mode='anchor',fontsize=10.5)
    ax.set_yticks(range(23),[display[t] for t in order],fontsize=10.5)
    ax.tick_params(length=2,pad=2)
    ax.set_xlabel('Predicted Type',fontsize=13,labelpad=5)
    ax.set_ylabel('True Type',fontsize=13,labelpad=5)
    cax = fig.add_axes([.923,.26,.019,.669])
    cb = fig.colorbar(im,cax=cax)
    cb.solids.set_rasterized(False)
    cb.ax.tick_params(labelsize=10,length=2)
    cb.outline.set_linewidth(.6)
    if errors:
        cb.locator = MaxNLocator(nbins=5,integer=True)
        cb.update_ticks()
        cb.set_label('Count',fontsize=12,labelpad=5)
    else:
        cb.set_ticks([0,.25,.5,.75,1])
        cb.ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
        cb.set_label('Proportion',fontsize=12,labelpad=5)
    fig.canvas.draw()
    no_overlap(ax.get_yticklabels(),fig.canvas.get_renderer(),'Matrix labels collision')
    save(fig,modality,'F' if errors else 'E','100pct_Type_'+kind,
         dict(values_unchanged=True,verified_from_sequence_predictions=True,n_types=23,
              nonARG_not_displayed=True,row_denominator_includes_ARG_missed_as_nonARG=not errors))


def subtype_errors(modality,rows):
    labels = [textwrap.fill(f'{r.true_subtype.split("__",1)[-1]} → {r.predicted_subtype.split("__",1)[-1]}',
                            width=38,break_long_words=True,break_on_hyphens=False) for r in rows.itertuples()]
    heights = np.array([1+.7*s.count('\n') for s in labels])
    ys = np.cumsum(heights)-heights/2
    fig = plt.figure(figsize=(8,7.6))
    ax = fig.add_axes([.47,.155,.48,.825])
    colors = ['#329A89' if p==100 else '#E98562' for p in rows.Type_correct_percent]
    bars = ax.barh(ys,rows.Count,height=.7,color=colors,edgecolor='#4b5858',linewidth=.55)
    max_count = float(rows.Count.max())
    for bar,row in zip(bars,rows.itertuples()):
        if row.Type_correct_percent!=100:
            bar.set_hatch('///')
        ax.text(row.Count+max_count*.025,bar.get_y()+bar.get_height()/2,
                f'{row.Count} ({row.Type_correct_percent:.0f}%)',va='center',fontsize=10.5)
    ax.set_yticks(ys,labels,fontsize=10.5,linespacing=1.0)
    ax.set_ylim(heights.sum()+.2,-.2)
    ax.set_xlim(0,max_count*1.47)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5,integer=True))
    ax.set_xlabel('Count',fontsize=13,labelpad=4)
    ax.tick_params(length=2,pad=3,labelsize=10.5)
    ax.spines[['right','top']].set_visible(False)
    ax.grid(axis='x',color='#e3e8eb',linewidth=.55)
    ax.set_axisbelow(True)
    handles = [Patch(facecolor='#329A89',edgecolor='#4b5858',linewidth=.55,label='Subtype wrong, Type correct'),
               Patch(facecolor='#E98562',edgecolor='#4b5858',linewidth=.55,hatch='///',label='Subtype wrong, Type incorrect')]
    ax.legend(handles=handles,loc='upper left',bbox_to_anchor=(0,-.085),fontsize=10.5,
              frameon=False,borderaxespad=0,handlelength=1.3,labelspacing=.3)
    fig.canvas.draw()
    no_overlap(ax.get_yticklabels(),fig.canvas.get_renderer(),'Subtype error labels collision')
    save(fig,modality,'G','100pct_Subtype_error_pairs',dict(n_pairs=20,values_unchanged=True,
         verified_from_sequence_predictions=True,reference_ARG_only=True,ARG_predicted_nonARG_retained=True))


def umap(modality,palette,arg):
    mod = modality.lower()
    epochs = [0,50,100,135 if modality=='Protein' else 132]
    order = palette.Type.tolist()
    colors = dict(zip(palette.Type,palette.reference_style_color))
    display = dict(zip(palette.Type,palette.Display))
    fig = plt.figure(figsize=(17.2,4.9))
    left,right,gap,bottom = .27,.07,.52,1.22
    width = (17.2-left-right-3*gap)/4
    height = width/1.2
    frames = []
    hashes = []
    axes = []
    for i,ep in enumerate(epochs):
        path = PUBLICATION/'data/umap_reference_refit/coordinates'/f'{mod}_epoch_{ep:03d}.csv'
        frame = source(path,float_precision='round_trip')
        meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        assert meta['coordinates_sha256']==sha(path)
        assert meta['identity']['profile']=='reference_n50_min050' and not meta['labels_used_in_fit']
        assert len(frame)==2287 and frame.sequence_id.is_unique
        assert set(frame.sequence_id)==set(arg.sequence_id)
        labels = arg.set_index('sequence_id').reindex(frame.sequence_id)
        np.testing.assert_array_equal(frame.Type.to_numpy(),labels.true_type.to_numpy())
        if frames:
            pd.testing.assert_frame_equal(frame[['sequence_id','Type','Subtype']],frames[0][['sequence_id','Type','Subtype']])
        frames.append(frame)
        hashes.append(sha(path))
        dest = OUT/'plot_data'/modality/'umap_coordinates'
        dest.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,dest/path.name)
        shutil.copy2(path.with_suffix('.json'),dest/path.with_suffix('.json').name)
        ax = fig.add_axes([(left+i*(width+gap))/17.2,bottom/4.9,width/17.2,height/4.9])
        xy = frame[['UMAP1','UMAP2']].to_numpy()
        perm = np.random.default_rng(42).permutation(len(frame))
        point_colors = np.array([colors[t] for t in frame.Type])
        scatter = ax.scatter(xy[perm,0],xy[perm,1],c=point_colors[perm],s=8.3,
                             alpha=.90,edgecolors='none',linewidths=0,rasterized=False)
        np.testing.assert_array_equal(scatter.get_offsets(),xy[perm])
        lo,hi = xy.min(axis=0),xy.max(axis=0)
        center = (lo+hi)/2
        yspan = max(float(hi[1]-lo[1]),float(hi[0]-lo[0])/1.2,1e-6)*1.08
        xspan = yspan*1.2
        ax.set_xlim(center[0]-xspan/2,center[0]+xspan/2)
        ax.set_ylim(center[1]-yspan/2,center[1]+yspan/2)
        ax.set_aspect('equal',adjustable='box')
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel('UMAP1',fontsize=12,labelpad=3)
        if i==0:
            ax.set_ylabel('UMAP2',fontsize=12,labelpad=3)
        ax.set_title(f'Best model (epoch {ep})' if i==3 else f'Epoch {ep}',
                     fontsize=13,fontweight='bold' if i==3 else 'normal',pad=6)
        axes.append(ax)
    handles = [Line2D([],[],color=colors[t],marker='o',ls='none',markersize=5,
                      markeredgewidth=0,label=display[t]) for t in order]
    leg = fig.legend(handles=handles,ncol=6,loc='upper left',mode='expand',
                     bbox_to_anchor=(left/17.2,.185,(17.2-left-right)/17.2,0),
                     bbox_transform=fig.transFigure,frameon=False,borderaxespad=0,
                     borderpad=0,handlelength=1,handletextpad=.4,labelspacing=.42,fontsize=12)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    no_overlap(leg.get_texts(),renderer,'UMAP legend collision')
    assert leg.get_window_extent(renderer).y1 < min(ax.xaxis.label.get_window_extent(renderer).y0 for ax in axes)
    for ax in axes:
        box = ax.get_window_extent(renderer)
        np.testing.assert_allclose(box.width/np.diff(ax.get_xlim()),box.height/np.diff(ax.get_ylim()),rtol=1e-12)
    save(fig,modality,'D','UMAP_4epochs',dict(epochs=epochs,n_per_epoch=2287,
         coordinates_sha256=hashes,coordinates_unchanged=True,UMAP_refit=False,points_removed=0,
         all_23_types_in_legend=True,same_limits_and_aspect_as_previous=True))


def main():
    plt.rcParams.update({'font.family':'Arial','font.size':11,'svg.fonttype':'none',
                         'pdf.fonttype':42,'axes.linewidth':.75,'hatch.linewidth':.55,
                         'figure.facecolor':'none','axes.facecolor':'none','savefig.facecolor':'none',
                         'savefig.transparent':True})
    OUT.mkdir(parents=True,exist_ok=True)
    palette = source(PUBLICATION/'umap_reference_palette.csv')
    display = dict(zip(palette.Type,palette.Display))
    for modality in ['Protein','DNA']:
        radar(modality)
        order,norm,errors,top,arg = verified_error_data(modality)
        matrix(modality,order,norm,'confusion',display)
        matrix(modality,order,errors,'errors',display)
        subtype_errors(modality,top)
        umap(modality,palette,arg)
        number = 2 if modality=='Protein' else 3
        folder = OUT/f'Figure{number}_{modality}'
        for letter,subdir,pattern in [('B','figures',f'Figure{number}B*.svg'),('C','heatmaps',f'Figure{number}C*.svg')]:
            files = list((TASK/subdir).glob(pattern))
            assert len(files)==1
            svg = files[0]
            shutil.copy2(svg,folder/svg.name)
            shutil.copy2(svg.with_suffix('.png'),OUT/'previews'/folder.name/svg.with_suffix('.png').name)
            source_data = TASK/subdir/'plot_data'
            shutil.copytree(source_data,OUT/'plot_data'/f'{letter}_verification',dirs_exist_ok=True)
        assert len(list(folder.glob('*.svg')))==7
    for path,expected in INPUTS.items():
        assert sha(path)==expected,'Source modified during plotting'
    (OUT/'plot_data/source_hashes.json').write_text(json.dumps(INPUTS,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'plot_data/remaining_panels_verification.json').write_text(json.dumps(AUDIT,ensure_ascii=False,indent=2),encoding='utf-8')
    shutil.copy2(__file__,OUT/'plot_data'/Path(__file__).name)
    print('PASS: 14 panels; source data unchanged, UMAP coordinates unchanged, SVG canvas transparent.',flush=True)


if __name__=='__main__':
    main()
