#!/usr/bin/env python3
"""Recompute PLM-ARG global metrics using the archived manuscript mapping.

Raw predictions and label/mapping sources are read-only. All three averaging
methods are exported. The default plot update uses macro P/R/F1 and global
Accuracy/MCC for every Protein model, as requested on 2026-09-21.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT = Path(__file__).resolve().parent
TRAIN = ROOT.parent.parent
CANONICAL = TRAIN / 'ARGscope_result_9.16/PLMARG/Protein'
MAPPING_SCRIPT = CANONICAL / 'calculate_PLMARG_Protein_metrics.py'
MAPPED = CANONICAL / 'PLMARG_Protein_metrics_results'
OUT = ROOT / 'PLMARG_overall_corrected'
BAR = TRAIN / '柱状图结果/柱状图结果/longaa/PLM-ARG'
APP = TRAIN / 'new model result8.24/1.training dataset/ARGScope_80_20_results/apply_argscope_protein_and_DNA'
PUB = APP / 'ARGScope_publication_layout_panels'
REF = APP / 'reference_style_small_panels_23types'
PCTS = (60, 70, 80, 90, 100)
AVERAGES = ('macro', 'weighted', 'micro')
METRICS = ('Accuracy', 'Precision', 'Recall', 'F1', 'MCC')
STAMP = datetime.now().strftime('%Y%m%d_%H%M%S')
INPUTS, BACKUPS, CHECKS = {}, [], []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path, **kwargs):
    INPUTS[str(path)] = digest(path)
    return pd.read_csv(path, keep_default_na=False, low_memory=False, **kwargs)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def backup(path):
    if path.exists() and not any(x['path'] == str(path) for x in BACKUPS):
        target = OUT / 'backup' / STAMP / f'{len(BACKUPS):03d}_{path.name}'
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        assert digest(path) == digest(target)
        BACKUPS.append({'path': str(path), 'backup': str(target), 'sha256': digest(path)})


def save_csv(frame, path, replace=False):
    if replace:
        backup(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.15g')


def scores(y, p, pct, scope, level, model='PLM-ARG'):
    """Validate sklearn against an independent count-based implementation."""
    y, p = np.asarray(y, dtype=str), np.asarray(p, dtype=str)
    assert len(y) == len(p) and len(y) > 0
    labels = np.union1d(y, p)
    yi, pi = np.searchsorted(labels, y), np.searchsorted(labels, p)
    support = np.bincount(yi, minlength=len(labels)).astype(float)
    predicted = np.bincount(pi, minlength=len(labels)).astype(float)
    tp = np.bincount(yi[yi == pi], minlength=len(labels)).astype(float)
    fn, fp = support - tp, predicted - tp
    divide = lambda a, b: np.divide(a, b, out=np.zeros_like(a, dtype=float), where=b != 0)
    precision, recall = divide(tp, predicted), divide(tp, support)
    f1 = divide(2 * tp, 2 * tp + fp + fn)
    n, correct = float(len(y)), float(tp.sum())
    denom = np.sqrt((n * n - np.dot(support, support)) * (n * n - np.dot(predicted, predicted)))
    mcc = (correct * n - np.dot(support, predicted)) / denom if denom else 0.0
    acc = correct / n
    assert abs(acc - accuracy_score(y, p)) < 1e-12
    assert abs(mcc - matthews_corrcoef(y, p)) < 1e-12
    rows = []
    for avg in AVERAGES:
        actual = np.array(precision_recall_fscore_support(y, p, labels=labels, average=avg, zero_division=0)[:3])
        if avg == 'macro':
            independent = np.array([v.mean() for v in (precision, recall, f1)])
        elif avg == 'weighted':
            independent = np.array([np.dot(v, support) / n for v in (precision, recall, f1)])
        else:
            independent = np.repeat(acc, 3)
        np.testing.assert_allclose(actual, independent, rtol=0, atol=1e-12)
        rows.append(dict(Model=model, Completeness=pct, Level=level, Scope=scope,
                         Average=avg, N=int(n), N_true_labels=int(np.count_nonzero(support)),
                         N_labels_union=len(labels), Accuracy=acc, Precision=actual[0],
                         Recall=actual[1], F1=actual[2], MCC=mcc))
        CHECKS.append(dict(Model=model, Completeness=pct, Scope=scope, Level=level, Average=avg,
                           Max_absolute_error=float(np.max(np.abs(actual - independent)))))
    counts = pd.DataFrame(dict(Label=labels, TP=tp.astype(int), FP=fp.astype(int),
                              FN=fn.astype(int), TN=(n - tp - fp - fn).astype(int),
                              Support=support.astype(int), Precision=precision, Recall=recall, F1=f1))
    for key, value in [('Scope', scope), ('Level', level), ('Completeness', pct)]:
        counts.insert(0, key, value)
    return pd.DataFrame(rows), counts


def calculate():
    INPUTS[str(MAPPING_SCRIPT)] = digest(MAPPING_SCRIPT)
    mapping = load_module('manuscript_plm_mapping', MAPPING_SCRIPT)
    overall, count_tables, audit = [], [], []
    reference_parents = None
    for pct in (100, 60, 70, 80, 90):
        source = ROOT / f'plmarg_eval_outputs_{pct}p/merged_plmarg_predictions_with_labels.csv'
        suffix = f'{pct}pct' if pct == 100 else f'{pct}pct_5parts'
        mapped_path = MAPPED / f'mapped_predictions/protein_{suffix}_plmarg_result_mapped_type_predictions.csv'
        raw = read(source)
        archived = read(mapped_path)
        assert raw.seq_id.is_unique and archived.test_id.is_unique
        assert set(raw.seq_id) == set(archived.test_id)
        archived = archived.set_index('test_id').loc[raw.seq_id].reset_index()
        assert raw.type.ne('').all() and raw.seq_id.ne('').all()
        np.testing.assert_array_equal(raw.type, archived.true_type)
        np.testing.assert_array_equal(raw.pred, archived.raw_pred)
        np.testing.assert_allclose(raw.ARG.astype(float), archived.ARG_score.astype(float), rtol=0, atol=1e-12)
        probability = raw.ARG.astype(float)
        assert probability.between(0, 1).all()
        arg_prediction = np.where(probability >= mapping.ARG_THRESHOLD, 'ARG', 'nonARG')
        np.testing.assert_array_equal(arg_prediction, archived.ARG_prediction)
        pairs = list(zip(arg_prediction, raw.pred.astype(str)))
        lookup = {pair: mapping.map_plmarg_prediction(*pair)[0] for pair in set(pairs)}
        predicted_type = np.array([lookup[pair] for pair in pairs])
        # Mapping has no access to the true label, and must reproduce the archive.
        np.testing.assert_array_equal(predicted_type, archived.predicted_type)
        truth = raw.type.astype(str).to_numpy()
        arg_mask = truth != 'nonARG'
        np.testing.assert_array_equal(np.where(arg_mask, 'ARG', 'nonARG'), raw.true_ARG_binary)
        # Full-length IDs can naturally end in _1.._5; the older mapper stripped
        # four such suffixes from base_id. Use exact full sequence IDs, not that
        # derived field, to audit correspondence with fragment parents.
        parents = raw.seq_id.astype(str) if pct == 100 else archived.base_id.astype(str)
        if pct == 100:
            reference_parents = set(parents)
            assert parents.is_unique
        else:
            assert set(parents) == reference_parents and parents.value_counts().eq(5).all()
        assert archived.assign(_truth=truth).groupby('base_id')._truth.nunique().eq(1).all()
        for scope, mask in [('including_nonARG', np.ones(len(raw), dtype=bool)), ('ARG_only', arg_mask)]:
            result, counts = scores(truth[mask], predicted_type[mask], pct, scope, 'Type')
            overall.append(result)
            count_tables.append(counts)
        result, counts = scores(np.where(arg_mask, 'ARG', 'nonARG'), arg_prediction,
                                pct, 'including_nonARG', 'ARG_nonARG')
        overall.append(result)
        count_tables.append(counts)
        audit.append(dict(Completeness=pct, N=len(raw), N_parents=parents.nunique(),
                          ARG_rows=int(arg_mask.sum()), NonARG_rows=int((~arg_mask).sum()),
                          Original_source=str(source), Archived_mapping_source=str(mapped_path),
                          IDs_and_truth_match=True, Raw_predictions_match=True,
                          Probabilities_match=True, Mapping_reproduced_without_truth=True,
                          Full_ID_base_ID_difference=int((raw.seq_id.to_numpy() != archived.base_id.to_numpy()).sum()) if pct == 100 else 0,
                          Unmapped_predictions=int((predicted_type == mapping.UNMAPPED_LABEL).sum())))
        print(f'{pct}%: verified {len(raw):,} sequences; all three averaging methods recomputed.', flush=True)
    all_scores = pd.concat(overall).sort_values(['Level', 'Scope', 'Completeness', 'Average'],
                                                key=lambda col: col.map({a: i for i, a in enumerate(AVERAGES)}) if col.name == 'Average' else col)
    expected = read(MAPPED / '02_type_overall_five_metrics.csv')
    for old in expected.itertuples():
        found = all_scores[(all_scores.Level == 'Type') & (all_scores.Scope == 'including_nonARG') &
                           (all_scores.Completeness == int(old.condition.rstrip('%'))) & (all_scores.Average == old.average)].iloc[0]
        for metric in METRICS:
            assert abs(found[metric] - getattr(old, metric.lower())) <= 0.00000050001
    for filename, level, scope in [
        ('01_Type_overall_macro_weighted_micro.csv', 'Type', 'including_nonARG'),
        ('02_Type_ARG_only_macro_weighted_micro.csv', 'Type', 'ARG_only'),
        ('03_ARG_nonARG_macro_weighted_micro.csv', 'ARG_nonARG', 'including_nonARG')]:
        save_csv(all_scores[(all_scores.Level == level) & (all_scores.Scope == scope)], OUT / filename)
    save_csv(pd.concat(count_tables), OUT / '04_per_label_counts_for_verification.csv')
    save_csv(pd.DataFrame(audit), OUT / '05_source_and_mapping_audit.csv')
    save_csv(pd.DataFrame(CHECKS), OUT / '06_independent_metric_checks.csv')
    return all_scores


def update_bar_inputs(result):
    overall = result[(result.Level == 'Type') & (result.Scope == 'including_nonARG')]
    old_bar = pd.read_csv(BAR / 'PLMARG_longaa.csv')
    backup(BAR / 'PLMARG_longaa.csv')
    save_csv(overall, BAR / 'PLMARG_longaa_all_averages.csv', replace=True)
    changes = []
    for avg in AVERAGES:
        current = overall[overall.Average == avg].set_index('Completeness').loc[list(PCTS)]
        current = current[list(METRICS)].rename(columns={'Accuracy': 'ACC'}).reset_index(drop=True)
        current.insert(0, 'Class', 'Type')
        current.insert(0, 'Condition', [f'{p}%' if p != 100 else 'Long AA' for p in PCTS])
        save_csv(current, BAR / f'PLMARG_longaa_{avg}.csv', replace=True)
        if avg == 'weighted':
            save_csv(current, BAR / 'PLMARG_longaa.csv', replace=True)
            for pct in PCTS:
                cond = old_bar.iloc[:, 0].astype(str).str.strip()
                old = old_bar[cond.str.startswith('Long') if pct == 100 else cond.eq(f'{pct}%')].iloc[0]
                new = current.iloc[list(PCTS).index(pct)]
                for metric in METRICS:
                    name = 'ACC' if metric == 'Accuracy' else metric
                    changes.append(dict(Completeness=pct, Metric=metric, Previous=float(old[name]),
                                        Recomputed=float(new[name]), Difference=float(new[name])-float(old[name])))
    save_csv(pd.DataFrame(changes), OUT / '07_previous_plot_vs_corrected_weighted.csv')
    definition = 'global Accuracy/MCC; weighted P/R/F1; including nonARG; archived manuscript mapping; cohort NOT matched to ARGScope'
    for folder in (REF, PUB):
        for pct in PCTS:
            target = folder / f'data/protein/{pct}pct/A_overall_values_and_sources.csv'
            frame = pd.read_csv(target)
            row = overall[(overall.Completeness == pct) & (overall.Average == 'weighted')].iloc[0]
            selection = frame.Model.eq('PLM-ARG')
            assert selection.sum() == 1
            frame.loc[selection, list(METRICS)] = row[list(METRICS)].to_numpy(dtype=float)
            frame.loc[selection, 'source'] = str(OUT / '01_Type_overall_macro_weighted_micro.csv')
            frame.loc[selection, 'definition'] = definition
            save_csv(frame, target, replace=True)
    return overall


def update_figures(overall):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from types import SimpleNamespace
    pub = load_module('reviewed_publication_plotter', PUB / 'plot_publication_panels.py')
    pub.prepare(cached=True)
    args = SimpleNamespace(preview_only=False, dpi=600)
    # The same reviewed layout is reused with macro P/R/F1 for all models.
    for pct in PCTS:
        frame = pd.read_csv(PUB / f'data/protein/{pct}pct/A_overall_values_and_sources.csv')
        for ext in ('png', 'svg', 'pdf'):
            backup(PUB / f'Protein/{pct}pct/overall_protein_{pct}pct.{ext}')
        fig = pub.canvas('overall')
        pub.draw_overall(fig, (0, 0, *pub.SIZES['overall']), 'protein', {'a': frame})
        pub.save(fig, f'Protein/{pct}pct/overall_protein_{pct}pct', 'overall', 'protein', pct, args)
        # Update the earlier small-panel outputs too, so their revised source
        # cache and image cannot disagree. Other panels are left untouched.
        for ext in ('png', 'svg', 'pdf'):
            src = PUB / f'Protein/{pct}pct/overall_protein_{pct}pct.{ext}'
            dst = REF / f'Protein/{pct}pct/A_protein_{pct}pct_overall_comparison.{ext}'
            backup(dst)
            shutil.copy2(src, dst)
    full = pub.condition_data('protein', 100)
    fig = pub.canvas('assembled')
    pub.draw_overall(fig, pub.COMPOSITE_BOXES['overall'], 'protein', full)
    pub.draw_heatmaps(fig, pub.COMPOSITE_BOXES['heatmaps'], 'protein', full)
    pub.draw_umap(fig, pub.COMPOSITE_BOXES['umap'], 'protein', pub.umap_data('protein'))
    for kind in ('confusion', 'errors'):
        pub.draw_matrix(fig, pub.COMPOSITE_BOXES[kind], 'protein', full, kind)
    pub.draw_subtype(fig, pub.COMPOSITE_BOXES['subtype'], 'protein', full)
    for ext in ('png', 'svg', 'pdf'):
        backup(PUB / f'Protein/Protein_100pct_assembled.{ext}')
    pub.save(fig, 'Protein/Protein_100pct_assembled', 'assembled', 'protein', 100, args)
    # Standalone PLM-ARG panels explicitly display the three averaging choices.
    colors = ['#D8E8F2', '#AACDDF', '#76A9C9', '#487C9C', '#204965']
    for avg in AVERAGES:
        selected = overall[overall.Average == avg].set_index('Completeness').loc[list(PCTS)]
        fig, ax = plt.subplots(figsize=(6.1, 3.6))
        fig.subplots_adjust(left=.11, right=.98, bottom=.15, top=.83)
        x = np.arange(5)
        for i, pct in enumerate(PCTS):
            values = selected.loc[pct, list(METRICS)].to_numpy(dtype=float)
            bars = ax.bar(x + (i - 2) * .16, values, width=.145, color=colors[i],
                          edgecolor='#52606A', linewidth=.4, label=f'{pct}%')
            np.testing.assert_array_equal([b.get_height() for b in bars], values)
        ax.set_xticks(x, METRICS)
        ax.set_ylim(0, 1.04)
        ax.set_ylabel(f'Score ({avg})')
        ax.spines[['top', 'right']].set_visible(False)
        ax.legend(ncol=5, loc='lower center', bbox_to_anchor=(.5, 1.01), frameon=False)
        ax.grid(axis='y', color='#E7E7E7', linewidth=.4)
        ax.set_axisbelow(True)
        pub.check_geometry(fig, avg)
        for ext in ('png', 'pdf', 'svg'):
            target = OUT / 'figures' / f'PLMARG_Type_{avg}.{ext}'
            target.parent.mkdir(exist_ok=True)
            fig.savefig(target, dpi=600 if ext == 'png' else 150)
        plt.close(fig)
    (OUT / '08_plot_validation.json').write_text(json.dumps(pub.PANELS, indent=2), encoding='utf-8')
    # Preserve the old complete validation record and explicitly supersede the
    # affected entries; do not assert that any other model was re-evaluated.
    report_path = PUB / 'LAYOUT_VALIDATION.json'
    backup(report_path)
    report = json.loads(report_path.read_text(encoding='utf-8'))
    replacements = {(p['modality'], p['completeness_percent'], p['panel']): p for p in pub.PANELS}
    report['panels'] = [replacements.pop((p['modality'], p['completeness_percent'], p['panel']), p)
                        for p in report['panels']] + list(replacements.values())
    report['metrics_unchanged'] = False
    report['PLMARG_correction'] = dict(date=STAMP, models=['ARGNet', 'DeepARG', 'PLM-ARG', 'FunGeneTyper', 'ARGScope'], default_average='macro',
                                      fresh_figures=6, audit=str(OUT / '05_source_and_mapping_audit.csv'),
                                      other_models_not_recomputed=False, heatmaps_unchanged=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    fingerprint_path = PUB / 'source_fingerprints.json'
    backup(fingerprint_path)
    fingerprints = json.loads(fingerprint_path.read_text(encoding='utf-8'))
    for pct in PCTS:
        target = REF / f'data/protein/{pct}pct/A_overall_values_and_sources.csv'
        fingerprints[str(target)] = digest(target)
    fingerprint_path.write_text(json.dumps(fingerprints, indent=2, ensure_ascii=False), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--metrics-only', action='store_true', help='Only recompute PLM-ARG; do not change plot inputs or images')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    result = calculate()
    try:
        if not args.metrics_only:
            from update_protein_macro_bars import update_all_models
            update_all_models(result, sys.modules[__name__])
    finally:
        (OUT / 'backup_manifest.json').write_text(json.dumps(BACKUPS, ensure_ascii=False, indent=2), encoding='utf-8')
    assert all(digest(Path(path)) == sha for path, sha in INPUTS.items())
    (OUT / 'input_sha256.json').write_text(json.dumps(INPUTS, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'backup_manifest.json').write_text(json.dumps(BACKUPS, ensure_ascii=False, indent=2), encoding='utf-8')
    print('PASS: raw sources unchanged; sklearn and independent formulas agree.', flush=True)
    print(result[(result.Completeness == 100) & (result.Level == 'Type') &
                 (result.Scope == 'including_nonARG')][['Average', *METRICS]].to_string(index=False), flush=True)
    print(f'Output: {OUT}', flush=True)


if __name__ == '__main__':
    main()
