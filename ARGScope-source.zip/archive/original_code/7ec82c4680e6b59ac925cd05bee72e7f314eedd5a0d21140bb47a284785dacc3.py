# -*- coding: utf-8 -*-

import os
import re
import glob
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    matthews_corrcoef,
    classification_report,
    confusion_matrix,
)


# ============================================================
# 1. Input settings
# ============================================================

ID_TABLE_FILE = "expanded_id_table_5x2.csv"

# 扫描当前文件夹下所有 DeepARG mapping.ARG 结果
# 兼容 protein 和 DNA 的 DeepARG 输出文件
DEEPARG_PATTERNS = [
    "protein_*_5parts_deeparg_SS_prot.mapping.ARG",
    "dna_*_5parts_deeparg_SS_nucl.mapping.ARG",
]

OUT_ROOT = "deeparg_batch_eval_outputs"
os.makedirs(OUT_ROOT, exist_ok=True)

# 汇总每一组 deeparg_type_classification_report 的文件夹
TYPE_REPORT_SUMMARY_DIR = os.path.join(
    OUT_ROOT,
    "deeparg_type_classification_reports_for_plot"
)
os.makedirs(TYPE_REPORT_SUMMARY_DIR, exist_ok=True)


# ============================================================
# 2. Helper functions
# ============================================================

def normalize_text(x):
    if pd.isna(x):
        return np.nan
    return str(x).strip()


def round_float_columns(df, ndigits=4):
    df = df.copy()
    float_cols = df.select_dtypes(include=["float", "float32", "float64"]).columns
    df[float_cols] = df[float_cols].round(ndigits)
    return df


def make_safe_name(name):
    name = str(name)
    name = name.replace(".mapping.ARG", "")
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    return name


def extract_dataset_name(filepath):
    base = os.path.basename(filepath)

    # protein_30aa_5parts_deeparg_SS_prot.mapping.ARG -> 30aa
    # protein_30pct_5parts_deeparg_SS_prot.mapping.ARG -> 30pct
    # dna_90nt_5parts_deeparg_SS_nucl.mapping.ARG -> 90nt
    # dna_30pct_5parts_deeparg_SS_nucl.mapping.ARG -> 30pct
    m = re.match(
        r"(?:protein|dna)_(.+?)_5parts_deeparg_SS_(?:prot|nucl)\.mapping\.ARG$",
        base
    )
    if m:
        return m.group(1)

    return make_safe_name(base)


def make_deeparg_type_prefix(dataset_name):
    """
    生成 type 结果文件前缀。
    例如：
        30aa  -> deeparg_type_30aa
        90pct -> deeparg_type_90pct
        100   -> deeparg_type_100
    """
    return "deeparg_type_" + make_safe_name(dataset_name)


def make_overall_metrics(y_true, y_pred, level_name, dataset_name):
    acc = accuracy_score(y_true, y_pred)
    mcc = matthews_corrcoef(y_true, y_pred)

    rows = []

    for avg in ["micro", "macro", "weighted"]:
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            average=avg,
            zero_division=0,
        )

        rows.append({
            "dataset": dataset_name,
            "level": level_name,
            "average": avg,
            "accuracy": acc,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "mcc": mcc,
            "support": len(y_true),
        })

    return pd.DataFrame(rows)


def make_per_class_metrics(y_true, y_pred, labels, dataset_name):
    """
    每个类别按照 one-vs-rest 方式计算：
        acc, precision, recall, f1, mcc

    对于某一个 type：
        positive = 当前 type
        negative = 其他所有 type
    """

    rows = []

    y_true = pd.Series(y_true).astype(str)
    y_pred = pd.Series(y_pred).astype(str)

    for label in labels:
        true_bin = (y_true == label).astype(int)
        pred_bin = (y_pred == label).astype(int)

        acc = accuracy_score(true_bin, pred_bin)

        precision, recall, f1, _ = precision_recall_fscore_support(
            true_bin,
            pred_bin,
            average="binary",
            zero_division=0,
        )

        mcc = matthews_corrcoef(true_bin, pred_bin)

        support = int((y_true == label).sum())
        pred_count = int((y_pred == label).sum())
        correct = int(((y_true == label) & (y_pred == label)).sum())

        rows.append({
            "dataset": dataset_name,
            "type": label,
            "support": support,
            "pred_count": pred_count,
            "correct": correct,
            "acc": acc,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "mcc": mcc,
        })

    return pd.DataFrame(rows)


def make_type_report_with_acc_mcc(y_true, y_pred, labels, dataset_name):
    """
    生成最终每个 type 的结果表。
    输出列：
        dataset, type, support, pred_count, correct,
        acc, precision, recall, f1, mcc
    """

    df_metrics = make_per_class_metrics(
        y_true=y_true,
        y_pred=y_pred,
        labels=labels,
        dataset_name=dataset_name,
    )

    df_metrics = df_metrics[
        [
            "dataset",
            "type",
            "support",
            "pred_count",
            "correct",
            "acc",
            "precision",
            "recall",
            "f1",
            "mcc",
        ]
    ].copy()

    return df_metrics


def read_deeparg_mapping_arg(file_path):
    """
    读取 DeepARG mapping.ARG 文件。

    正常情况下有表头：
        read_id, predicted_ARG-class, probability 等

    如果文件为空，返回空表。
    """
    if os.path.getsize(file_path) == 0:
        return pd.DataFrame()

    try:
        df = pd.read_csv(file_path, sep="\t")
    except pd.errors.EmptyDataError:
        return pd.DataFrame()

    return df


# ============================================================
# 3. Type mapping
# ============================================================

TRUE_TYPE_TO_DEEPARG_TYPE = {
    "nonARG": "nonARG",

    "aminoglycoside": "aminoglycoside",
    "bacitracin": "bacitracin",
    "beta_lactam": "beta-lactam",
    "bleomycin": "bleomycin",
    "chloramphenicol": "chloramphenicol",
    "florfenicol": "chloramphenicol",
    "fosfomycin": "fosfomycin",
    "fusidic_acid": "fusidic_acid",
    "macrolide-lincosamide-streptogramin": "MLS",
    "multidrug": "multidrug",
    "mupirocin": "mupirocin",
    "other_peptide_antibiotics": "peptide",
    "pleuromutilin_tiamulin": "pleuromutilin",
    "polymyxin": "polymyxin",
    "quinolone": "quinolone",
    "rifamycin": "rifamycin",
    "streptothricin": "streptothricin",
    "sulfonamide": "sulfonamide",
    "tetracenomycin_C": "tetracenomycin",
    "tetracycline": "tetracycline",
    "trimethoprim": "trimethoprim",
    "tunicamycin": "tunicamycin",
    "vancomycin": "glycopeptide",

    "antibacterial_fatty_acid": "antibacterial_fatty_acid",
    "bicyclomycin": "bicyclomycin",
    "defensin": "defensin",
    "edeine": "edeine",
    "factumycin": "factumycin",
    "novobiocin": "novobiocin",
    "puromycin": "puromycin",
}


# ============================================================
# 4. Read label table
# ============================================================

label_df = pd.read_csv(ID_TABLE_FILE, encoding="utf-8-sig")

required_label_cols = {"id", "type", "subtype"}
missing_label = required_label_cols - set(label_df.columns)

if missing_label:
    raise ValueError(f"ID table file missing columns: {missing_label}")

label_df["id"] = label_df["id"].apply(normalize_text)
label_df["type"] = label_df["type"].apply(normalize_text)
label_df["subtype"] = label_df["subtype"].apply(normalize_text)

print("ID table shape:", label_df.shape)


# ============================================================
# 5. Find all DeepARG files
# ============================================================

deeparg_files = []

for pattern in DEEPARG_PATTERNS:
    deeparg_files.extend(glob.glob(pattern))

deeparg_files = sorted(set(deeparg_files))

if not deeparg_files:
    raise FileNotFoundError(
        "No DeepARG mapping.ARG files found by patterns: "
        + ", ".join(DEEPARG_PATTERNS)
    )

print("\nFound DeepARG files:")
for f in deeparg_files:
    print("  ", f)


# ============================================================
# 6. Evaluate one dataset
# ============================================================

def evaluate_one_deeparg_file(deeparg_file, label_df):
    dataset_name = extract_dataset_name(deeparg_file)
    type_prefix = make_deeparg_type_prefix(dataset_name)

    out_dir = os.path.join(OUT_ROOT, dataset_name)
    os.makedirs(out_dir, exist_ok=True)

    print("\n============================================================")
    print("Evaluating:", deeparg_file)
    print("Dataset:", dataset_name)
    print("Type output prefix:", type_prefix)
    print("Output:", out_dir)
    print("============================================================")

    deeparg = read_deeparg_mapping_arg(deeparg_file)

    if deeparg.empty:
        print("Warning: mapping.ARG file is empty. All samples will be treated as nonARG.")
        deeparg_best = pd.DataFrame(
            columns=[
                "id",
                "deeparg_pred_type",
                "deeparg_probability",
            ]
        )
    else:
        required_deeparg_cols = {
            "read_id",
            "predicted_ARG-class",
            "probability",
        }

        missing_deeparg = required_deeparg_cols - set(deeparg.columns)
        if missing_deeparg:
            raise ValueError(
                f"{deeparg_file} missing columns: {missing_deeparg}"
            )

        deeparg["read_id"] = deeparg["read_id"].apply(normalize_text)
        deeparg["predicted_ARG-class"] = deeparg["predicted_ARG-class"].apply(normalize_text)
        deeparg["probability"] = pd.to_numeric(deeparg["probability"], errors="coerce")

        if "alignment-bitscore" in deeparg.columns:
            deeparg["alignment-bitscore"] = pd.to_numeric(
                deeparg["alignment-bitscore"],
                errors="coerce",
            )

            deeparg_best = (
                deeparg
                .sort_values(
                    by=["read_id", "probability", "alignment-bitscore"],
                    ascending=[True, False, False],
                )
                .drop_duplicates(subset=["read_id"], keep="first")
                .copy()
            )
        else:
            deeparg_best = (
                deeparg
                .sort_values(
                    by=["read_id", "probability"],
                    ascending=[True, False],
                )
                .drop_duplicates(subset=["read_id"], keep="first")
                .copy()
            )

        deeparg_best = deeparg_best.rename(
            columns={
                "read_id": "id",
                "predicted_ARG-class": "deeparg_pred_type",
                "probability": "deeparg_probability",
            }
        )

    print("DeepARG mapping.ARG rows:", deeparg.shape[0])
    print("DeepARG unique predicted IDs:", deeparg_best.shape[0])

    # ========================================================
    # Merge with label table
    # ========================================================

    df = label_df.merge(
        deeparg_best,
        on="id",
        how="left",
    )

    if df.shape[0] != label_df.shape[0]:
        raise ValueError(
            f"Dataset {dataset_name}: merged rows are not equal to label table rows."
        )

    # ========================================================
    # Build binary and type labels
    # ========================================================

    df["true_ARG_binary"] = np.where(df["type"] == "nonARG", "nonARG", "ARG")

    df["pred_ARG_binary"] = np.where(
        df["deeparg_pred_type"].isna(),
        "nonARG",
        "ARG",
    )

    df["raw_pred_type"] = np.where(
        df["pred_ARG_binary"] == "nonARG",
        "nonARG",
        df["deeparg_pred_type"],
    )

    df["true_type_for_eval"] = df["type"].map(TRUE_TYPE_TO_DEEPARG_TYPE)

    missing_mapped_types = sorted(
        df.loc[df["true_type_for_eval"].isna(), "type"].dropna().unique()
    )

    if missing_mapped_types:
        print("Warning: these true types are not in TRUE_TYPE_TO_DEEPARG_TYPE:")
        for x in missing_mapped_types:
            print("  ", x)

        df["true_type_for_eval"] = df["true_type_for_eval"].fillna(df["type"])

    df["pred_type_for_eval"] = df["raw_pred_type"].fillna("nonARG")

    # ========================================================
    # ARG / nonARG evaluation
    # ========================================================

    binary_labels = ["ARG", "nonARG"]

    binary_overall_metrics = make_overall_metrics(
        df["true_ARG_binary"],
        df["pred_ARG_binary"],
        level_name="ARG_nonARG",
        dataset_name=dataset_name,
    )

    binary_per_class_metrics = make_per_class_metrics(
        df["true_ARG_binary"],
        df["pred_ARG_binary"],
        labels=binary_labels,
        dataset_name=dataset_name,
    )

    binary_report = pd.DataFrame(
        classification_report(
            df["true_ARG_binary"],
            df["pred_ARG_binary"],
            labels=binary_labels,
            output_dict=True,
            zero_division=0,
        )
    ).T

    binary_cm = pd.DataFrame(
        confusion_matrix(
            df["true_ARG_binary"],
            df["pred_ARG_binary"],
            labels=binary_labels,
        ),
        index=[f"true_{x}" for x in binary_labels],
        columns=[f"pred_{x}" for x in binary_labels],
    )

    round_float_columns(binary_overall_metrics).to_csv(
        os.path.join(out_dir, "ARG_nonARG_overall_metrics.csv"),
        index=False,
    )

    round_float_columns(binary_per_class_metrics).to_csv(
        os.path.join(out_dir, "ARG_nonARG_per_class_metrics.csv"),
        index=False,
    )

    round_float_columns(binary_report).to_csv(
        os.path.join(out_dir, "ARG_nonARG_classification_report.csv"),
    )

    binary_cm.to_csv(
        os.path.join(out_dir, "ARG_nonARG_confusion_matrix.csv"),
    )

    # ========================================================
    # Type-level evaluation
    # ========================================================

    all_type_labels = sorted(
        set(df["true_type_for_eval"].astype(str).unique())
        | set(df["pred_type_for_eval"].astype(str).unique())
    )

    type_overall_metrics = make_overall_metrics(
        df["true_type_for_eval"],
        df["pred_type_for_eval"],
        level_name="type",
        dataset_name=dataset_name,
    )

    # 每个 type 的完整结果：acc, precision, recall, f1, mcc
    type_per_class_metrics = make_type_report_with_acc_mcc(
        df["true_type_for_eval"],
        df["pred_type_for_eval"],
        labels=all_type_labels,
        dataset_name=dataset_name,
    )

    # 原始 sklearn classification_report，额外保留
    type_report_original = pd.DataFrame(
        classification_report(
            df["true_type_for_eval"],
            df["pred_type_for_eval"],
            labels=all_type_labels,
            output_dict=True,
            zero_division=0,
        )
    ).T

    type_cm = pd.DataFrame(
        confusion_matrix(
            df["true_type_for_eval"],
            df["pred_type_for_eval"],
            labels=all_type_labels,
        ),
        index=[f"true_{x}" for x in all_type_labels],
        columns=[f"pred_{x}" for x in all_type_labels],
    )

    round_float_columns(type_overall_metrics).to_csv(
        os.path.join(out_dir, f"{type_prefix}_overall_metrics.csv"),
        index=False,
    )

    # 保存每个数据集自己的 classification_report
    type_classification_report_df = round_float_columns(type_per_class_metrics)

    type_classification_report_file = os.path.join(
        out_dir,
        f"{type_prefix}_classification_report.csv"
    )

    type_classification_report_df.to_csv(
        type_classification_report_file,
        index=False,
    )

    # 同时保存到统一汇总文件夹，方便后续画图
    summary_type_classification_report_file = os.path.join(
        TYPE_REPORT_SUMMARY_DIR,
        f"{type_prefix}_classification_report.csv"
    )

    type_classification_report_df.to_csv(
        summary_type_classification_report_file,
        index=False,
    )

    # 额外保留原始 sklearn classification_report
    round_float_columns(type_report_original).to_csv(
        os.path.join(out_dir, f"{type_prefix}_classification_report_original.csv"),
    )

    # per_class_metrics 内容与 classification_report 一致
    round_float_columns(type_per_class_metrics).to_csv(
        os.path.join(out_dir, f"{type_prefix}_per_class_metrics.csv"),
        index=False,
    )

    type_cm.to_csv(
        os.path.join(out_dir, f"{type_prefix}_confusion_matrix.csv"),
    )

    # ========================================================
    # Accuracy and metrics inside each true type
    # ========================================================

    df["type_correct"] = df["true_type_for_eval"] == df["pred_type_for_eval"]

    true_type_group_accuracy = (
        df
        .groupby(["type", "true_type_for_eval"])
        .agg(
            support=("id", "size"),
            correct=("type_correct", "sum"),
            accuracy=("type_correct", "mean"),
        )
        .reset_index()
        .sort_values(["support", "accuracy"], ascending=[False, False])
    )

    # 把 acc/precision/recall/f1/mcc 合并到原来的 true_type_group_accuracy 后面
    true_type_group_metrics = type_per_class_metrics.rename(
        columns={
            "type": "true_type_for_eval",
            "acc": "acc_one_vs_rest",
        }
    )

    true_type_group_accuracy = true_type_group_accuracy.merge(
        true_type_group_metrics[
            [
                "true_type_for_eval",
                "pred_count",
                "acc_one_vs_rest",
                "precision",
                "recall",
                "f1",
                "mcc",
            ]
        ],
        on="true_type_for_eval",
        how="left",
    )

    round_float_columns(true_type_group_accuracy).to_csv(
        os.path.join(out_dir, f"{type_prefix}_true_type_group_accuracy.csv"),
        index=False,
    )

    # ========================================================
    # Save merged prediction table
    # ========================================================

    save_cols = [
        "id",
        "type",
        "subtype",
        "true_ARG_binary",
        "pred_ARG_binary",
        "deeparg_pred_type",
        "deeparg_probability",
        "true_type_for_eval",
        "pred_type_for_eval",
        "type_correct",
    ]

    optional_cols = [
        "#ARG",
        "query-start",
        "query-end",
        "best-hit",
        "identity",
        "alignment-length",
        "alignment-bitscore",
        "alignment-evalue",
        "counts",
    ]

    for col in optional_cols:
        if col in df.columns and col not in save_cols:
            save_cols.append(col)

    existing_save_cols = [col for col in save_cols if col in df.columns]

    round_float_columns(df[existing_save_cols]).to_csv(
        os.path.join(out_dir, f"{type_prefix}_merged_predictions_with_labels.csv"),
        index=False,
    )

    # ========================================================
    # Save prediction summary
    # ========================================================

    predicted_ids = set(deeparg_best["id"].astype(str))
    label_ids = set(label_df["id"].astype(str))

    unmatched_deeparg_df = deeparg_best[
        ~deeparg_best["id"].astype(str).isin(label_ids)
    ].copy()

    not_predicted_label_df = label_df[
        ~label_df["id"].astype(str).isin(predicted_ids)
    ].copy()

    round_float_columns(unmatched_deeparg_df).to_csv(
        os.path.join(out_dir, "deeparg_predicted_ids_not_in_label_table.csv"),
        index=False,
    )

    round_float_columns(not_predicted_label_df).to_csv(
        os.path.join(out_dir, "label_ids_not_predicted_by_deeparg.csv"),
        index=False,
    )

    # ========================================================
    # Print short summary
    # ========================================================

    print("\nType overall metrics:")
    print(round_float_columns(type_overall_metrics))

    print("\nType per-class metrics:")
    print(round_float_columns(type_per_class_metrics))

    print("\nARG / nonARG overall metrics:")
    print(round_float_columns(binary_overall_metrics))

    print("\nMatching summary:")
    print("Label table rows:", label_df.shape[0])
    print("DeepARG mapping.ARG rows:", deeparg.shape[0])
    print("DeepARG unique predicted IDs:", deeparg_best.shape[0])
    print("DeepARG predicted IDs not in label table:", unmatched_deeparg_df.shape[0])
    print("Label IDs not predicted by DeepARG:", not_predicted_label_df.shape[0])

    return {
        "dataset": dataset_name,
        "type_overall_metrics": type_overall_metrics,
        "type_per_class_metrics": type_per_class_metrics,
        "ARG_nonARG_overall_metrics": binary_overall_metrics,
        "ARG_nonARG_per_class_metrics": binary_per_class_metrics,
        "true_type_group_accuracy": true_type_group_accuracy,
        "n_label": label_df.shape[0],
        "n_deeparg_rows": deeparg.shape[0],
        "n_deeparg_unique_predicted_ids": deeparg_best.shape[0],
        "n_unmatched_deeparg": unmatched_deeparg_df.shape[0],
        "n_not_predicted_label": not_predicted_label_df.shape[0],
    }


# ============================================================
# 7. Batch run
# ============================================================

all_type_overall = []
all_type_per_class = []
all_binary_overall = []
all_binary_per_class = []
all_true_type_group_accuracy = []
all_matching_summary = []

for deeparg_file in deeparg_files:
    result = evaluate_one_deeparg_file(deeparg_file, label_df)

    all_type_overall.append(result["type_overall_metrics"])
    all_type_per_class.append(result["type_per_class_metrics"])
    all_binary_overall.append(result["ARG_nonARG_overall_metrics"])
    all_binary_per_class.append(result["ARG_nonARG_per_class_metrics"])

    temp_acc = result["true_type_group_accuracy"].copy()
    temp_acc.insert(0, "dataset", result["dataset"])
    all_true_type_group_accuracy.append(temp_acc)

    all_matching_summary.append({
        "dataset": result["dataset"],
        "n_label": result["n_label"],
        "n_deeparg_rows": result["n_deeparg_rows"],
        "n_deeparg_unique_predicted_ids": result["n_deeparg_unique_predicted_ids"],
        "n_unmatched_deeparg": result["n_unmatched_deeparg"],
        "n_not_predicted_label": result["n_not_predicted_label"],
    })


# ============================================================
# 8. Save batch summary files
# ============================================================

batch_type_overall = pd.concat(all_type_overall, ignore_index=True)
batch_type_per_class = pd.concat(all_type_per_class, ignore_index=True)
batch_binary_overall = pd.concat(all_binary_overall, ignore_index=True)
batch_binary_per_class = pd.concat(all_binary_per_class, ignore_index=True)
batch_true_type_group_accuracy = pd.concat(all_true_type_group_accuracy, ignore_index=True)
batch_matching_summary = pd.DataFrame(all_matching_summary)

round_float_columns(batch_type_overall).to_csv(
    os.path.join(OUT_ROOT, "deeparg_type_batch_overall_summary.csv"),
    index=False,
)

round_float_columns(batch_type_per_class).to_csv(
    os.path.join(OUT_ROOT, "deeparg_type_batch_per_class_summary.csv"),
    index=False,
)

round_float_columns(batch_binary_overall).to_csv(
    os.path.join(OUT_ROOT, "batch_ARG_nonARG_overall_summary.csv"),
    index=False,
)

round_float_columns(batch_binary_per_class).to_csv(
    os.path.join(OUT_ROOT, "batch_ARG_nonARG_per_class_summary.csv"),
    index=False,
)

round_float_columns(batch_true_type_group_accuracy).to_csv(
    os.path.join(OUT_ROOT, "deeparg_type_batch_true_type_group_accuracy_summary.csv"),
    index=False,
)

batch_matching_summary.to_csv(
    os.path.join(OUT_ROOT, "batch_matching_summary.csv"),
    index=False,
)


# ============================================================
# 9. Save all type classification reports into one plot folder
# ============================================================

round_float_columns(batch_type_per_class).to_csv(
    os.path.join(
        TYPE_REPORT_SUMMARY_DIR,
        "all_deeparg_type_classification_reports_for_plot.csv"
    ),
    index=False,
)


# ============================================================
# 10. Print final summary
# ============================================================

print("\n============================================================")
print("Batch evaluation finished.")
print("============================================================")
print("Total datasets:", len(deeparg_files))
print("Output root:", OUT_ROOT)
print("Type classification report summary folder:", TYPE_REPORT_SUMMARY_DIR)

print("\nBatch type overall summary:")
print(round_float_columns(batch_type_overall))

print("\nBatch type per-class summary:")
print(round_float_columns(batch_type_per_class))

print("\nBatch ARG / nonARG overall summary:")
print(round_float_columns(batch_binary_overall))