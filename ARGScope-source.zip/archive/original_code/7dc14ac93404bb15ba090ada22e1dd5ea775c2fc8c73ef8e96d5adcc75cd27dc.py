"""Two standalone 2x4 publication panels from the validated nonARG-inclusive results."""
from pathlib import Path
import hashlib
import json
import shutil
import importlib.util
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Patch
from matplotlib.text import Text
from matplotlib.transforms import Bbox, Affine2D

HERE=Path(__file__).resolve().parent
ROOT=Path(r'E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW')
SOURCE=ROOT/'Including_nonARG_20260922/data'
OUT=HERE/'outputs/figure4_60_90_including_nonARG_20260922'
OLD=ROOT/'figures_60_90_circular_radar/plot_latest_circular_radar.py'
spec=importlib.util.spec_from_file_location('previous_figure4',OLD)
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
PCTS=prior.PCTS
MODELS=prior.MODELS
COLORS=prior.COLORS
SHORT=prior.SHORT
FIELDS=prior.METRICS
ORDER=prior.ORDER+['nonARG']
BAR_RECORDS=[]
RADAR_RECORDS=[]
FILTER_RECORDS=[]
EXPORTS=[]

CONTEXT=('60-90% sequence completeness, Protein and DNA. Type metrics include the fixed 23 ARG '
 'types plus nonARG. A: ACC, macro precision, macro recall, macro F1 and MCC. B: per-Type precision. '
 'All calculations use the previously verified nonARG-inclusive results. Model-specific existing '
 'input cohorts differ, so these are descriptive rather than matched-cohort comparisons. '
 'No confidence intervals are plotted. Only confirmed name correspondences are used. '
 'NonARG is displayed in every radar. Display filtering never changes aggregate metrics.')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def data():
    paths=[SOURCE/'all_metrics_including_nonARG.csv',SOURCE/'per_type_including_nonARG.csv',ROOT/'ARGScope_23_types.csv']
    summary=pd.read_csv(paths[0])
    per_all=pd.read_csv(paths[1])
    summary=summary[summary.Level.eq('Type') & summary.Average.eq('macro') & summary.Completeness.isin(PCTS)].copy()
    per_all=per_all[per_all.Completeness.isin(PCTS)].copy()
    assert summary.N_labels_averaged.eq(24).all()
    assert summary.Scope.eq('including_nonARG_fixed24').all()
    assert not summary.duplicated(['Modality','Model','Completeness']).any()
    assert len(summary)==32
    assert np.isfinite(summary[FIELDS].to_numpy()).all()
    assert summary[FIELDS].ge(0).all().all() and summary[FIELDS].le(1).all().all()
    display=pd.read_csv(paths[2]).set_index('Type').Type_display.to_dict()
    display.update(aminoglycoside='Aminoglycosides',tetracycline='Tetracyclines',nonARG='Non-ARG')
    # Independent count-based reconciliation, including unmatched predictions for MCC.
    for key,group in per_all.groupby(['Modality','Model','Completeness']):
        mod,model,pct=key
        row=summary[summary.Modality.eq(mod)&summary.Model.eq(model)&summary.Completeness.eq(pct)].iloc[0]
        selected=group[group.Included_in_average]
        assert set(selected.Type)==set(ORDER) and len(selected)==24
        assert selected.Support.sum()==row.N
        n=float(row.N)
        correct=float(group.TP.sum())
        actual=group.Support.to_numpy(float)
        predicted=group.Predicted_count.to_numpy(float)
        assert actual.sum()==predicted.sum()==n
        denominator=np.sqrt((n*n-np.dot(actual,actual))*(n*n-np.dot(predicted,predicted)))
        mcc=(correct*n-np.dot(actual,predicted))/denominator if denominator else 0.
        np.testing.assert_allclose([correct/n,mcc],[row.Accuracy,row.MCC],rtol=0,atol=2e-14)
        for metric in ['Precision','Recall','F1']:
            assert abs(selected[metric].mean()-row[metric])<2e-14
        den=selected.TP.to_numpy(float)+selected.FP.to_numpy(float)
        precision=np.divide(selected.TP.to_numpy(float),den,out=np.zeros(24),where=den>0)
        np.testing.assert_allclose(precision,selected.Precision,atol=2e-14,rtol=0)
    tables={}
    per=per_all[per_all.Included_in_average].copy()
    for mod,models in MODELS.items():
        for pct in PCTS:
            part=per[per.Modality.eq(mod)&per.Completeness.eq(pct)]
            table=part.pivot(index='Type',columns='Model',values='Precision').reindex(index=ORDER,columns=models)
            assert table.notna().all().all()
            keep=table.ARGScope.gt(0)&table.drop(columns='ARGScope').gt(0).any(axis=1)
            keep.loc['nonARG']=True
            for typ in ORDER:
                FILTER_RECORDS.append({'Modality':mod,'Completeness':pct,'Type':typ,'Shown':bool(keep.loc[typ]),
                    'ARGScope_precision':float(table.loc[typ,'ARGScope']),
                    'Reason':'always_include_nonARG' if typ=='nonARG' else 'displayed' if keep.loc[typ] else
                    'ARGScope_precision_zero' if table.loc[typ,'ARGScope']==0 else 'all_comparators_precision_zero'})
            tables[mod,pct]=table.loc[keep]
            assert 'nonARG' in tables[mod,pct].index
    return summary,per,tables,display,{str(p):sha(p) for p in paths+[OLD]}

def axes_mm(fig,x,top,w,h,polar=False):
    fw,fh=fig.get_size_inches()*25.4
    return fig.add_axes([x/fw,1-(top+h)/fh,w/fw,h/fh],projection='polar' if polar else None)

def text_mm(fig,x,top,text,**kwargs):
    fw,fh=fig.get_size_inches()*25.4
    return fig.text(x/fw,1-top/fh,text,**kwargs)

def sector(ax,mod,pct,summary):
    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0,1.95)
    ax.set_xticks([]);ax.set_yticks([])
    ax.grid(False);ax.spines['polar'].set_visible(False)
    rows=summary[summary.Modality.eq(mod)&summary.Completeness.eq(pct)].set_index('Model')
    numeric=[]
    labels=[]
    for k,metric in enumerate(FIELDS):
        center=k*2*np.pi/5
        span=np.deg2rad(57)
        left,right=center-span/2,center+span/2
        ax.bar(center,1,bottom=prior.R0,width=span,facecolor=prior.SECTOR_BG[k],edgecolor='#727B83',lw=.7,zorder=0)
        theta=np.linspace(left,right,100)
        for tick in [0,.25,.5,.75,1]:
            ax.plot(theta,np.full_like(theta,prior.R0+tick),color='#ACB4BA',lw=.45,zorder=1)
        for tick in [0,.5,1]:
            ax.text(left-.067,prior.R0+tick,f'{tick:.1f}',ha='center',va='center',fontsize=8.5,
                rotation=prior.rotation(left),rotation_mode='anchor',color='#525B64')
        step=span/len(MODELS[mod])
        for j,model in enumerate(MODELS[mod]):
            t=left+(j+.5)*step
            value=float(rows.loc[model,metric])
            mark=ax.bar(t,value,bottom=prior.R0,width=.8*step,color=COLORS[model],edgecolor='#525A61',
                lw=.65,hatch='///' if model=='DeepARG' else None,zorder=3)[0]
            radius=prior.R0+(.32 if j%2 else .76)
            txt=ax.text(t,radius,f'{value:.4f}',ha='center',va='center',fontsize=10.5,
                rotation=prior.rotation(t),rotation_mode='anchor',color='#131B20',zorder=5)
            numeric.append(txt)
            labels.append(ax.text(t,1.55,SHORT[model],ha='center',va='center',fontsize=9.2,
                rotation=prior.rotation(t),rotation_mode='anchor',color='#303A42'))
            BAR_RECORDS.append(dict(Modality=mod,Completeness=pct,Model=model,Metric=metric,Value=value,
                Label=f'{value:.4f}',Bar_height=float(mark.get_height()),Baseline=prior.R0,N=int(rows.loc[model,'N'])))
        metric_radius=2.055 if k in (1,2) else 1.86
        labels.append(ax.text(center,metric_radius,prior.METRIC_LABELS[k],ha='center',va='center',fontsize=12.3,
            fontweight='bold',linespacing=1.02,clip_on=False))
    ax.text(0,0,f'{pct}%\n{mod}',ha='center',va='center',fontsize=12.5,fontweight='bold',linespacing=1.15)
    return numeric,labels

def legend(fig,radar=False):
    if radar:
        handles=[Line2D([0],[0],color=COLORS[m],ls=prior.STYLES[m],marker=prior.MARKERS[m],lw=1.25,ms=4.1,
            mfc=COLORS[m] if m=='ARGScope' else 'none',label=m) for m in MODELS['Protein']]
    else:
        handles=[Patch(facecolor=COLORS[m],edgecolor='#5B6268',hatch='///' if m=='DeepARG' else None,
            label=f'{SHORT[m]}  {m}') for m in MODELS['Protein']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.51,.998),ncol=5,frameon=False,
        fontsize=12.5,columnspacing=2.0,handlelength=2.6 if radar else 1.8,handletextpad=.6,borderaxespad=0)

def radar(ax,mod,pct,table,display):
    types=list(table.index)
    angles=np.pi/2-(np.arange(len(types))+.5)*2*np.pi/len(types)
    ux,uy=np.cos(angles),np.sin(angles)
    texts=[]
    for r in [.2,.4,.6,.8,1]:
        ax.add_patch(Circle((0,0),r,facecolor='none',edgecolor='#D8DEE3' if r<1 else '#73808B',lw=.6 if r<1 else .8,zorder=0))
    for x,y in zip(ux,uy):
        ax.plot([0,x],[0,y],lw=.45,color='#DFE5E9',zorder=0)
    for side in [-1,1]:
        indexes=[i for i in range(len(types)) if (ux[i]<0)==(side<0)]
        ys=prior.spread(uy[indexes]*1.14,spacing=.16)
        for i,y in zip(indexes,ys):
            x=ux[i]*1.065+side*.026
            ax.plot([ux[i]*1.012,x-side*.018],[uy[i]*1.012,y],color='#BAC3CB',lw=.45)
            texts.append(ax.text(x,y,display[types[i]],ha='left' if side>0 else 'right',va='center',
                fontsize=9.9,fontweight='bold' if types[i]=='nonARG' else 'normal',clip_on=False))
    for model in MODELS[mod]:
        values=table[model].to_numpy(float)
        xs=np.r_[ux*values,ux[0]*values[0]]
        ys=np.r_[uy*values,uy[0]*values[0]]
        line,=ax.plot(xs,ys,color=COLORS[model],ls=prior.STYLES[model],lw=1.25 if model=='ARGScope' else 1.0,
            marker=prior.MARKERS[model],ms=3.2,mew=.7,mfc=COLORS[model] if model=='ARGScope' else 'none',zorder=5 if model=='ARGScope' else 3)
        for i,typ in enumerate(types):
            RADAR_RECORDS.append(dict(Modality=mod,Completeness=pct,Model=model,Type=typ,
                Precision=float(values[i]),X=float(line.get_xdata()[i]),Y=float(line.get_ydata()[i])))
    for r in [.2,.4,.6,.8,1]:
        a=np.deg2rad(83)
        ax.text(r*np.cos(a)+.022,r*np.sin(a)-.01,f'{r:.1f}',fontsize=7.5,ha='left',va='center',color='#65717A',zorder=9)
    ax.set(xlim=(-2.02,2.02),ylim=(-1.29,1.29),aspect='equal')
    ax.axis('off')
    return texts

def no_overlap(texts,renderer,label):
    def polygon(t):
        # Rotated radial labels require oriented boxes. Axis-aligned bounds falsely
        # overlap in their empty corners even when glyph rectangles are separated.
        layout,info,descent=t._get_layout(renderer)
        if len(info)!=1:
            b=t.get_window_extent(renderer)
            return np.array([[b.x0,b.y0],[b.x1,b.y0],[b.x1,b.y1],[b.x0,b.y1]])
        _,(w,h),x,y=info[0]
        anchor=t.get_transform().transform(t.get_position())
        return Affine2D().rotate_deg(t.get_rotation()).transform([[0,-descent],[w,-descent],[w,h-descent],[0,h-descent]])+anchor+[x,y]
    def overlaps(a,b):
        for p in [a,b]:
            for edge in np.roll(p,-1,axis=0)-p:
                normal=np.array([-edge[1],edge[0]])
                proj_a=a@normal;proj_b=b@normal
                if proj_a.max()<=proj_b.min() or proj_b.max()<=proj_a.min():return False
        return True
    for i,t in enumerate(texts):
        a=polygon(t)
        for other in texts[i+1:]:
            b=polygon(other)
            assert not overlaps(a,b),(label,t.get_text(),other.get_text(),a.tolist(),b.tolist())

def save(fig,name,groups):
    fig.patch.set_alpha(0)
    for ax in fig.axes:ax.patch.set_alpha(0)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for group in groups:no_overlap(group,renderer,name)
    tight=fig.get_tightbbox(renderer)
    box=Bbox.from_extents(tight.x0-.025,tight.y0-.025,tight.x1+.025,tight.y1+.025)
    for text in fig.findobj(Text):
        if text.get_visible() and text.get_text().strip():
            assert text.get_fontfamily()==['Arial']
            b=text.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())
            if b.width and b.height:
                assert b.x0>=box.x0 and b.x1<=box.x1 and b.y0>=box.y0 and b.y1<=box.y1
    for fonttype,subfolder in [('path',''),('none','editable_text')]:
        folder=OUT/subfolder;folder.mkdir(parents=True,exist_ok=True)
        with plt.rc_context({'svg.fonttype':fonttype}):
            fig.savefig(folder/f'{name}.svg',transparent=True,facecolor='none',edgecolor='none',bbox_inches=box,metadata={'Description':CONTEXT})
        svg=ET.parse(folder/f'{name}.svg').getroot()
        assert not svg.findall('.//{http://www.w3.org/2000/svg}image')
        assert list(map(float,svg.attrib['viewBox'].split()))[:2]==[0,0]
        if fonttype=='path':assert not svg.findall('.//{http://www.w3.org/2000/svg}text')
        EXPORTS.append(dict(file=str(folder/f'{name}.svg'),sha256=sha(folder/f'{name}.svg'),pure_vector=True,
            transparent=True,font='Arial',outlined=fonttype=='path',viewBox_origin=[0,0],pad_pt=1.8))
    (OUT/'previews').mkdir(exist_ok=True)
    fig.savefig(OUT/'previews'/f'{name}.png',dpi=180,transparent=True,facecolor='none',bbox_inches=box)
    plt.close(fig)
    print('SAVED '+name,flush=True)

def main():
    font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':11,'svg.fonttype':'path','pdf.fonttype':42,
        'text.color':'#24292D','hatch.linewidth':.45,'figure.facecolor':'none','axes.facecolor':'none',
        'savefig.facecolor':'none','savefig.transparent':True})
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'data').mkdir(exist_ok=True)
    summary,per,tables,display,hashes=data()
    fig=plt.figure(figsize=(464/25.4,212/25.4))
    legend(fig)
    number_groups=[];outer=[]
    for row,mod in enumerate(MODELS):
        for col,pct in enumerate(PCTS):
            ax=axes_mm(fig,2+116*col,7+102*row,104,104,polar=True)
            numbers,labels=sector(ax,mod,pct,summary)
            number_groups.append(numbers);outer.extend(labels)
    save(fig,'Figure4A_Type_five_metrics_60_90_including_nonARG',number_groups+[outer])
    fig=plt.figure(figsize=(456/25.4,165/25.4))
    legend(fig,radar=True)
    groups=[]
    for row,mod in enumerate(MODELS):
        for col,pct in enumerate(PCTS):
            ax=axes_mm(fig,17+110*col,13+77*row,101,64.5)
            groups.append(radar(ax,mod,pct,tables[mod,pct],display))
            if row==0:text_mm(fig,67.5+110*col,11,f'{pct}%',ha='center',va='center',fontsize=13.3,fontweight='bold')
        text_mm(fig,4,45.25+77*row,mod,rotation=90,ha='center',va='center',fontsize=13.5,fontweight='bold')
    save(fig,'Figure4B_Type_precision_60_90_including_nonARG',[sum(groups,[])])
    bars=pd.DataFrame(BAR_RECORDS);points=pd.DataFrame(RADAR_RECORDS)
    assert len(bars)==160
    for row in bars.itertuples():
        original=summary[summary.Modality.eq(row.Modality)&summary.Model.eq(row.Model)&summary.Completeness.eq(row.Completeness)].iloc[0][row.Metric]
        assert abs(row.Bar_height-original)<1e-14 and row.Value==original and row.Label==f'{original:.4f}'
    for row in points.itertuples():
        original=float(tables[row.Modality,row.Completeness].loc[row.Type,row.Model])
        assert row.Precision==original and abs(np.hypot(row.X,row.Y)-original)<1e-14
    assert len(points[points.Type.eq('nonARG')])==32
    for path,value in hashes.items():assert sha(path)==value
    for name,frame in [('A_five_metric_values',bars),('B_precision_values',points),
                       ('radar_display_filter',pd.DataFrame(FILTER_RECORDS)),('source_overall_macro',summary),('source_per_type',per)]:
        frame.to_csv(OUT/'data'/f'{name}.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    report={'status':'PASS','source_hashes':hashes,'exports':EXPORTS,'type_labels_averaged':24,
        'NonARG_in_both_figures':True,'NonARG_radar_points':32,'A_values':160,'B_values':len(points),
        'A_fonts_pt':{'numbers':10.5,'model_abbreviations':9.2,'metric_names':12.3,'center':12.5,'legend':12.5},
        'previous_A_fonts_pt':{'numbers':6.6,'model_abbreviations':6.0,'metric_names':7.3,'center':9,'legend':9.4},
        'radar_types':{f'{mod}_{pct}':list(table.index) for (mod,pct),table in tables.items()},
        'all_plotted_values_match_source':True,'count_formula_crosscheck':True,'source_files_unchanged':True,
        'same_test_cohort_across_models':False,'old_confidence_intervals_reused':False}
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS: two 2x4 panels, 160 circular bar values, and Non-ARG on all eight radars.',flush=True)

if __name__=='__main__':main()
