# -*- coding: utf-8 -*-
"""
NT type-level heatmaps.

Models:
    ARGNet
    DeepARG
    ARGScope

Group 1:
    90nt, 120nt, 150nt, 100pct

Group 2:
    60pct, 70pct, 80pct, 90pct, 100pct

Metrics:
    ACC, Precision, Recall, F1, MCC

Color:
    blue

Important:
    Type order is fixed according to the provided protein heatmap PDF.
    Values are not shown.
    Only Precision > 0.90 cells are marked with "*".
    No white grid lines between cells.

Output:
    nt_heatmap_outputs_5metrics_blue_fixed_type_order/
"""

import os
import re
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


# =========================================================
# 1. CONFIG
# =========================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
print("Current working directory:", os.getcwd())

MODEL_ORDER = [
    "ARGNet",
    "DeepARG",
    "ARGScope",
]

# 第一组：90nt, 120nt, 150nt, 100pct
NT_GROUP_ORDER = [
    "90nt",
    "120nt",
    "150nt",
    "100pct",
]

# 第二组：60-100pct
PCT_GROUP_ORDER = [
    "60pct",
    "70pct",
    "80pct",
    "90pct",
    "100pct",
]

METRICS = ["ACC", "Precision", "Recall", "F1", "MCC"]

# 不显示具体数字
SHOW_VALUES = True

# 只在 Precision > 0.90 的方框中显示星号
SHOW_PRECISION_STAR = False
PRECISION_STAR_THRESHOLD = 0.90

DPI = 600

OUTDIR = "nt_heatmap_outputs_5metrics_blue_fixed_type_order"
os.makedirs(OUTDIR, exist_ok=True)

OUT_MATRIX_XLSX = os.path.join(
    OUTDIR,
    "nt_type_heatmap_matrices_5metrics_fixed_type_order.xlsx"
)

plt.rcParams["font.family"] = "Arial"


# =========================================================
# 2. FIXED TYPE ORDER
# =========================================================

FIXED_TYPE_ORDER_RAW = [
    "MLS",
    "aminoglycoside",
    "trimethoprim",
    "tetracycline",
    "tetracenomycin",
    "sulfonamide",
    "streptothricin",
    "rifamycin",
    "puromycin",
    "polymyxin",
    "pleuromutilin",
    "other_peptide_antibiotics",
    "novobiocin",
    "mupirocin",
    "tunicamycin",
    "glycopeptide",
    "fusidic_acid",
    "fosfomycin",
    "florfenicol",
    "factumycin",
    "edeine",
    "defensin",
    "chloramphenicol",
    "bleomycin",
    "bicyclomycin",
    "beta_lactam",
    "bacitracin",
    "antibacterial_fatty_acid",
    "multidrug",
    "quinolone",
]


# =========================================================
# 3. FILE MAP
# =========================================================

FILE_MAP = {
    "ARGNet": {
        "60pct": ["ARGNET/argnet_type_60pct_metrics_by_class.csv"],
        "70pct": ["ARGNET/argnet_type_70pct_metrics_by_class.csv"],
        "80pct": ["ARGNET/argnet_type_80pct_metrics_by_class.csv"],
        "90pct": ["ARGNET/argnet_type_90pct_metrics_by_class.csv"],
        "100pct": ["ARGNET/argnet_type_100pct_metrics_by_class.csv"],

        "90nt": ["ARGNET/argnet_type_90nt_metrics_by_class.csv"],
        "120nt": ["ARGNET/argnet_type_120nt_metrics_by_class.csv"],
        "150nt": ["ARGNET/argnet_type_150nt_metrics_by_class.csv"],
    },

    "ARGScope": {
        "60pct": ["ARGScope/60p_type_metrics_by_class_from_subtype.csv"],
        "70pct": ["ARGScope/70p_type_metrics_by_class_from_subtype.csv"],
        "80pct": ["ARGScope/80p_type_metrics_by_class_from_subtype.csv"],
        "90pct": ["ARGScope/90p_type_metrics_by_class_from_subtype.csv"],
        "100pct": ["ARGScope/100p_type_metrics_by_class_from_subtype.csv"],

        "90nt": ["ARGScope/90nt_type_metrics_by_class_from_subtype.csv"],
        "120nt": ["ARGScope/120nt_type_metrics_by_class_from_subtype.csv"],
        "150nt": ["ARGScope/150nt_type_metrics_by_class_from_subtype.csv"],
    },

    "DeepARG": {
        "60pct": ["DeepARG/deeparg_type_60pct_classification_report.csv"],
        "70pct": ["DeepARG/deeparg_type_70pct_classification_report.csv"],
        "80pct": ["DeepARG/deeparg_type_80pct_classification_report.csv"],
        "90pct": ["DeepARG/deeparg_type_90pct_classification_report.csv"],
        "100pct": ["DeepARG/deeparg_type_100pct_classification_report.csv"],

        "90nt": ["DeepARG/deeparg_type_90nt_classification_report.csv"],
        "120nt": ["DeepARG/deeparg_type_120nt_classification_report.csv"],
        "150nt": ["DeepARG/deeparg_type_150nt_classification_report.csv"],
    },
}


# =========================================================
# 4. BLUE COLOR MAP
# =========================================================

HEATMAP_CMAP = LinearSegmentedColormap.from_list(
    "custom_blue_heatmap",
    [
        "#F7FBFF",
        "#DEEBF7",
        "#C6DBEF",
        "#9ECAE1",
        "#6BAED6",
        "#3182BD",
        "#08519C",
    ],
    N=256
)

NAN_COLOR = "#D9D9D9"


# =========================================================
# 5. FILE IO
# =========================================================

def resolve_file(candidate_paths):
    if isinstance(candidate_paths, str):
        candidate_paths = [candidate_paths]

    for path in candidate_paths:
        if os.path.exists(path):
            return path

    return None


def read_table_auto(file_path):
    lower = file_path.lower()

    if lower.endswith(".xlsx") or lower.endswith(".xls"):
        return pd.read_excel(file_path)

    encodings = ["utf-8-sig", "utf-8", "gbk", "gb18030", "latin1"]
    last_error = None

    for enc in encodings:
        try:
            return pd.read_csv(file_path, encoding=enc)
        except Exception as e:
            last_error = e

    raise RuntimeError(f"Cannot read file: {file_path}\nLast error: {last_error}")


def safe_filename(name):
    """
    Windows-safe filename.
    避免保存 png/pdf/tif 时因为特殊字符报错。
    """
    name = str(name)
    name = name.replace("%", "pct")
    name = re.sub(r'[<>:"/\\|?*]+', "_", name)
    name = re.sub(r"\s+", "_", name)
    return name


# =========================================================
# 6. TYPE NORMALIZATION
# =========================================================

def normalize_type_name(x):
    if pd.isna(x):
        return np.nan

    s = str(x).strip()

    if s == "":
        return np.nan

    s_low = s.lower()
    s_low = s_low.replace("-", "_").replace(" ", "_")
    s_low = re.sub(r"__+", "_", s_low)

    alias_map = {
        "macrolide_lincosamide_streptogramin": "MLS",
        "macrolides_lincosamides_streptogramines": "MLS",
        "macrolide_lincosamide_streptogramin_b": "MLS",
        "mls": "MLS",

        "betalactams": "beta_lactam",
        "beta_lactams": "beta_lactam",
        "beta_lactam": "beta_lactam",
        "beta_lactams_resistance": "beta_lactam",
        "beta_lactamase": "beta_lactam",

        "multi_drug": "multidrug",
        "multi_drug_resistance": "multidrug",
        "multidrug": "multidrug",

        "aminoglycosides": "aminoglycoside",
        "aminoglycoside": "aminoglycoside",

        "aminocoumarins": "aminocoumarin",
        "aminocoumarin": "aminocoumarin",
        "novobiocin": "novobiocin",

        "quinolones": "quinolone",
        "quinolone": "quinolone",
        "fluoroquinolone": "quinolone",
        "fluoroquinolones": "quinolone",

        "polymyxins": "polymyxin",
        "polymyxin": "polymyxin",

        "trimethoprims": "trimethoprim",
        "trimethoprim": "trimethoprim",
        "diaminopyrimidine": "trimethoprim",

        "glycopeptide": "glycopeptide",
        "glycopeptides": "glycopeptide",
        "vancomycin": "glycopeptide",

        "chloramphenicol": "chloramphenicol",
        "florfenicol": "florfenicol",
        "phenicol": "chloramphenicol",

        "bacitracin": "bacitracin",
        "bleomycin": "bleomycin",
        "rifamycin": "rifamycin",
        "rifampin": "rifamycin",
        "sulfonamide": "sulfonamide",
        "sulfonamides": "sulfonamide",
        "tetracycline": "tetracycline",
        "tetracyclines": "tetracycline",
        "fosfomycin": "fosfomycin",
        "fusidic_acid": "fusidic_acid",
        "fusidicacid": "fusidic_acid",
        "fusaric_acid": "fusidic_acid",
        "streptothricin": "streptothricin",

        "tetracenomycin": "tetracenomycin",
        "tetracenomycin_c": "tetracenomycin",

        "triclosan": "antibacterial_fatty_acid",
        "antibacterial_fatty_acid": "antibacterial_fatty_acid",
        "antibacterial_free_fatty_acids": "antibacterial_fatty_acid",

        "ethambutol": "ethambutol",
        "isoniazid": "isoniazid",
        "kasugamycin": "kasugamycin",
        "mupirocin": "mupirocin",
        "nitrofurantoin": "nitrofurantoin",
        "nitroimidazole": "nitroimidazole",

        "peptide": "other_peptide_antibiotics",
        "polyamine_peptide": "other_peptide_antibiotics",
        "polyamine:peptide": "other_peptide_antibiotics",
        "other_peptide_antibiotics": "other_peptide_antibiotics",

        "qa_compound": "qa_compound",
        "puromycin": "puromycin",
        "elfamycin": "elfamycin",
        "edeine": "edeine",
        "defensin": "defensin",
        "bicyclomycin": "bicyclomycin",
        "pleuromutilin": "pleuromutilin",
        "pleuromutilin_tiamulin": "pleuromutilin",
        "thiostrepton": "thiostrepton",
        "tunicamycin": "tunicamycin",
        "nucleoside": "tunicamycin",
        "factumycin": "factumycin",

        "nonarg": "nonarg",
        "non_arg": "nonarg",
        "non-arg": "nonarg",
        "non arg": "nonarg",

        "macro_avg": np.nan,
        "weighted_avg": np.nan,
        "micro_avg": np.nan,
        "accuracy": np.nan,
        "unclassified": np.nan,
    }

    return alias_map.get(s_low, s_low)


def pretty_type_name(x):
    if x == "MLS":
        return "MLS"
    return x


def is_nonarg_type(x):
    s = str(x).strip().lower()
    return s in ["nonarg", "non_arg", "non-arg", "non arg", "nan"]


FIXED_TYPE_ORDER = [
    normalize_type_name(x)
    for x in FIXED_TYPE_ORDER_RAW
]

DISPLAY_TYPE_ORDER = [
    pretty_type_name(x)
    for x in FIXED_TYPE_ORDER
]


# =========================================================
# 7. COLUMN NORMALIZATION
# =========================================================

def clean_column_name(c):
    c = str(c).replace("\ufeff", "").strip()
    return c


def standardize_columns(df):
    df = df.copy()
    df.columns = [clean_column_name(c) for c in df.columns]

    col_map = {}

    for c in df.columns:
        c_low = str(c).strip().lower()
        c_low_norm = c_low.replace("-", "_").replace(" ", "_")

        if (
            c_low_norm in [
                "type",
                "arg_type",
                "label",
                "class",
                "class_category",
                "name",
                "drug_class",
                "resistance_category",
                "unnamed:_0",
                "unnamed_0",
                "unnamed:0",
                "",
            ]
            or c_low.startswith("unnamed")
        ):
            col_map[c] = "Type"

        elif c_low_norm in [
            "acc",
            "accuracy",
            "acc_one_vs_rest",
        ]:
            col_map[c] = "ACC"

        elif c_low_norm in [
            "precision",
            "prec",
            "weighted_precision",
        ]:
            col_map[c] = "Precision"

        elif c_low_norm in [
            "recall",
            "sensitivity",
        ]:
            col_map[c] = "Recall"

        elif c_low_norm in [
            "f1",
            "f1_score",
            "f1score",
        ]:
            col_map[c] = "F1"

        elif c_low_norm in [
            "mcc",
        ]:
            col_map[c] = "MCC"

        elif c_low_norm in [
            "support",
            "support_true",
        ]:
            col_map[c] = "Support"

        elif c_low_norm in [
            "hit_rate",
            "hitrate",
            "hit_rate_arg_only",
            "by_class_hit_rate",
        ]:
            col_map[c] = "Recall"

    df = df.rename(columns=col_map)
    df.columns = [clean_column_name(c) for c in df.columns]

    return df


def ensure_metric_columns(df):
    for m in METRICS:
        if m not in df.columns:
            df[m] = np.nan
    return df


# =========================================================
# 8. LOAD MODEL METRICS
# =========================================================

def load_model_metrics(model_name, file_path):
    df = read_table_auto(file_path)
    df = standardize_columns(df)

    if "Type" not in df.columns:
        raise ValueError(
            f"{file_path} missing Type column. Current columns: {list(df.columns)}"
        )

    df = ensure_metric_columns(df)

    df["Type"] = df["Type"].apply(normalize_type_name)
    df = df.dropna(subset=["Type"]).copy()
    df = df[~df["Type"].apply(is_nonarg_type)].copy()

    keep_cols = ["Type"] + METRICS
    if "Support" in df.columns:
        keep_cols.append("Support")

    df = df[keep_cols].copy()

    for c in METRICS + ["Support"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    metric_cols = [c for c in METRICS + ["Support"] if c in df.columns]
    df = df.groupby("Type", as_index=False)[metric_cols].mean()
    df["Model"] = model_name

    return df


# =========================================================
# 9. LOAD ALL DATA
# =========================================================

ALL_GROUPS = []
for g in NT_GROUP_ORDER + PCT_GROUP_ORDER:
    if g not in ALL_GROUPS:
        ALL_GROUPS.append(g)

group_model_data = {}
missing_files = []
read_errors = []

for group in ALL_GROUPS:
    group_model_data[group] = {}

    for model in MODEL_ORDER:
        candidates = FILE_MAP.get(model, {}).get(group)
        real_path = resolve_file(candidates) if candidates else None

        if real_path is None:
            group_model_data[group][model] = None
            missing_files.append((group, model, candidates))
            print(f"[MISSING] {group} | {model} | {candidates}")
            continue

        try:
            one_df = load_model_metrics(model, real_path)
            group_model_data[group][model] = one_df
            print(
                f"[OK] {group} | {model} -> {real_path} | "
                f"type_count={one_df['Type'].nunique()}"
            )

        except Exception as e:
            group_model_data[group][model] = None
            read_errors.append((group, model, real_path, repr(e)))
            print(f"[ERROR] {group} | {model} -> {real_path} | {repr(e)}")


# =========================================================
# 10. TYPE ORDER CHECK
# =========================================================

def collect_loaded_types():
    loaded_types = set()

    for group in ALL_GROUPS:
        for model in MODEL_ORDER:
            df_m = group_model_data.get(group, {}).get(model, None)
            if df_m is None:
                continue

            for t in df_m["Type"].dropna().unique():
                if not is_nonarg_type(t):
                    loaded_types.add(t)

    return loaded_types


loaded_types = collect_loaded_types()

fixed_types_missing = [
    t for t in FIXED_TYPE_ORDER
    if t not in loaded_types
]

extra_loaded_types = sorted([
    t for t in loaded_types
    if t not in set(FIXED_TYPE_ORDER)
])

all_types = FIXED_TYPE_ORDER.copy()
display_types = DISPLAY_TYPE_ORDER.copy()

print("\nFixed type count:", len(all_types))
print("Fixed type order:")
print(all_types)

if fixed_types_missing:
    print("\nTypes in fixed order but not found in loaded data:")
    for t in fixed_types_missing:
        print("  ", t)

if extra_loaded_types:
    print("\nExtra loaded types not included in fixed order, not plotted:")
    for t in extra_loaded_types:
        print("  ", t)


# =========================================================
# 11. BUILD MATRICES
# =========================================================

def build_group_matrices(group_order, model_order, metric):
    group_mats = {}

    for group in group_order:
        rows = []

        for t in all_types:
            row = []

            for model in model_order:
                df_m = group_model_data.get(group, {}).get(model, None)

                if df_m is None:
                    row.append(np.nan)
                    continue

                sub = df_m[df_m["Type"] == t]

                if len(sub) == 0:
                    row.append(np.nan)
                else:
                    row.append(sub.iloc[0][metric])

            rows.append(row)

        mat = pd.DataFrame(rows, index=display_types, columns=model_order)
        group_mats[group] = mat

    return group_mats


# =========================================================
# 12. SAVE MATRICES
# =========================================================

with pd.ExcelWriter(OUT_MATRIX_XLSX) as writer:
    for metric in METRICS:
        nt_group_mats = build_group_matrices(NT_GROUP_ORDER, MODEL_ORDER, metric)
        pct_group_mats = build_group_matrices(PCT_GROUP_ORDER, MODEL_ORDER, metric)

        metric_tag = metric.lower()

        for group in NT_GROUP_ORDER:
            sheet = f"{metric_tag}_nt_{group}"
            nt_group_mats[group].to_excel(writer, sheet_name=sheet[:31])

        for group in PCT_GROUP_ORDER:
            sheet = f"{metric_tag}_pct_{group}"
            pct_group_mats[group].to_excel(writer, sheet_name=sheet[:31])

print(f"\nSaved: {OUT_MATRIX_XLSX}")


# =========================================================
# 13. DRAW HEATMAP
# =========================================================

def group_title(group):
    if group.endswith("pct"):
        return group.replace("pct", "%")
    return group


def draw_heatmap(ax, data, title, metric, show_ylabels=False):
    arr = data.values.astype(float)

    cmap = HEATMAP_CMAP.copy()
    cmap.set_bad(color=NAN_COLOR)

    # 所有指标统一使用 0-1 色柱
    vmin, vmax = 0, 1

    im = ax.imshow(
        arr,
        aspect="auto",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        interpolation="nearest"
    )

    ax.set_title(title, fontsize=16, fontweight="bold", pad=10)

    ax.set_xticks(np.arange(data.shape[1]))
    ax.set_xticklabels(
        data.columns,
        rotation=45,
        ha="right",
        rotation_mode="anchor",
        fontsize=11,
        fontweight="bold"
    )

    for label in ax.get_xticklabels():
        if label.get_text() == "ARGScope":
            label.set_color("#08519C")

    ax.set_yticks(np.arange(data.shape[0]))

    if show_ylabels:
        ax.set_yticklabels(data.index, fontsize=10)
    else:
        ax.set_yticklabels([])

    ax.tick_params(axis="both", length=0)

    # 不画白色网格线，避免格子之间出现空隙

    # 显示具体数值，不显示星号
    if SHOW_VALUES:
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                val = arr[i, j]

                if np.isnan(val):
                    continue

                if abs(val) < 1e-12:
                    continue

                text = f"{val:.2f}".rstrip("0").rstrip(".")

                if metric == "MCC":
                    color = "white" if val >= 0.35 else "black"
                else:
                    color = "white" if val >= 0.65 else "black"

                ax.text(
                    j,
                    i,
                    text,
                    ha="center",
                    va="center",
                    fontsize=8,
                    color=color
                )

    for spine in ax.spines.values():
        spine.set_visible(False)

    return im


def plot_heatmap_figure(group_order, model_order, group_mats, metric, out_prefix, main_title):
    n_panels = len(group_order)

    fig, axes = plt.subplots(
        1,
        n_panels,
        figsize=(3.7 * n_panels + 2.4, max(7, len(all_types) * 0.34)),
        constrained_layout=False
    )

    if n_panels == 1:
        axes = [axes]

    last_im = None

    for idx, group in enumerate(group_order):
        last_im = draw_heatmap(
            ax=axes[idx],
            data=group_mats[group],
            title=f"{metric} ({group_title(group)})",
            metric=metric,
            show_ylabels=(idx == 0)
        )

    axes[0].set_ylabel("ARG Types", fontsize=14, fontweight="bold")

    fig.suptitle(
        main_title,
        fontsize=18,
        fontweight="bold",
        y=0.98
    )

    plt.subplots_adjust(
        left=0.22,
        right=0.88,
        top=0.88,
        bottom=0.20,
        wspace=0.12
    )

    fig.canvas.draw()

    ref_ax = axes[-1]
    pos = ref_ax.get_position()

    cbar_ax = fig.add_axes([
        pos.x1 + 0.012,
        pos.y0,
        0.015,
        pos.y1 - pos.y0
    ])

    cbar = fig.colorbar(last_im, cax=cbar_ax)
    cbar.set_label(metric, fontsize=12, fontweight="bold")
    cbar.ax.tick_params(labelsize=10)

    out_dir = os.path.dirname(out_prefix)
    out_base = os.path.basename(out_prefix)
    out_base = safe_filename(out_base)

    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    out_png = os.path.join(out_dir, out_base + ".png")
    out_pdf = os.path.join(out_dir, out_base + ".pdf")
    out_tif = os.path.join(out_dir, out_base + ".tif")

    plt.savefig(out_png, dpi=DPI, bbox_inches="tight")
    plt.savefig(out_pdf, dpi=DPI, bbox_inches="tight")
    plt.savefig(out_tif, dpi=DPI, bbox_inches="tight")
    plt.close(fig)

    print(f"Saved: {out_png}")
    print(f"Saved: {out_pdf}")
    print(f"Saved: {out_tif}")


# =========================================================
# 14. SAVE FIGURES
# =========================================================

for metric in METRICS:
    metric_tag = metric.lower()

    nt_group_mats = build_group_matrices(NT_GROUP_ORDER, MODEL_ORDER, metric)
    pct_group_mats = build_group_matrices(PCT_GROUP_ORDER, MODEL_ORDER, metric)

    out_nt_prefix = os.path.join(
        OUTDIR,
        f"nt_type_{metric_tag}_heatmap_90nt_120nt_150nt_100pct_fixed_type_order"
    )

    out_pct_prefix = os.path.join(
        OUTDIR,
        f"nt_type_{metric_tag}_heatmap_pct_60_100_fixed_type_order"
    )

    plot_heatmap_figure(
        group_order=NT_GROUP_ORDER,
        model_order=MODEL_ORDER,
        group_mats=nt_group_mats,
        metric=metric,
        out_prefix=out_nt_prefix,
        main_title=f"NT Type-level {metric}: 90nt, 120nt, 150nt and 100%"
    )

    plot_heatmap_figure(
        group_order=PCT_GROUP_ORDER,
        model_order=MODEL_ORDER,
        group_mats=pct_group_mats,
        metric=metric,
        out_prefix=out_pct_prefix,
        main_title=f"NT Type-level {metric}: 60%-100%"
    )


# =========================================================
# 15. REPORT
# =========================================================

if missing_files:
    print("\nMissing files:")
    for group, model, candidates in missing_files:
        print(f"  {group} | {model} | {candidates}")

if read_errors:
    print("\nRead errors:")
    for group, model, path, err in read_errors:
        print(f"  {group} | {model} | {path} | {err}")