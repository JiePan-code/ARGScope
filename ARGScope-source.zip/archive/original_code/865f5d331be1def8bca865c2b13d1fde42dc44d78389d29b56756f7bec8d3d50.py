"""Validate fixed-23 results and document changes from legacy definitions."""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
MODELS={'Protein':['ARGNet','DeepARG','PLM-ARG','FunGeneTyper','ARGScope'],'DNA':['ARGNet','DeepARG','ARGScope']}
METRICS=['Accuracy','Precision','Recall','F1','MCC']
labels=set(pd.read_csv(ROOT/'ARGScope_23_types.csv').Type)
assert len(labels)==23 and 'nonARG' not in labels
books=json.loads((ROOT/'workbook_data.json').read_text(encoding='utf-8'))
summary=pd.read_csv(ROOT/'supplementary_check/03_table_row_status.csv',keep_default_na=False)
comparison=pd.read_csv(ROOT/'supplementary_check/02_cell_by_cell_comparison.csv',keep_default_na=False)
assert len(comparison)==950
matched=comparison[comparison.Matched_original_value.ne('')]
assert np.all(np.abs(matched.Matched_original_value.astype(float)-matched.Document_value.astype(float))<=0.0000500001)
verified={}; changed=[]
baseline=Path(sys.argv[1]) if len(sys.argv)>1 else None
for mod,models in MODELS.items():
    folder=ROOT/mod
    get=lambda name:pd.read_csv(folder/(name+'.csv'),keep_default_na=False)
    bars=get('01_Type_barplot_macro_five_metrics'); types=get('02_Type_overall_macro_weighted_micro')
    per=get('03_Per_Type_fixed23_five_metrics')
    positive=get('05_ARG_nonARG_ARG_positive_five_metrics'); binary=get('06_ARG_nonARG_macro_weighted_micro')
    subtype=get('07_ARGScope_Subtype_ARG_only_macro_weighted_micro')
    assert len(bars)==len(models)*5 and len(types)==len(models)*15
    assert len(per)==len(models)*5*23 and set(per.Type)==labels
    assert set(types.Model)==set(models) and set(types.Completeness)=={60,70,80,90,100}
    assert types.Scope.eq('ARG_only').all() and types.N_labels_averaged.eq(23).all()
    assert types.Averaged_labels.map(lambda x:set(x.split(';'))==labels).all()
    assert not types.duplicated(['Model','Completeness','Average']).any()
    for (model,pct),group in types.groupby(['Model','Completeness']):
        assert len(group)==3 and group.Accuracy.nunique()==group.MCC.nunique()==1
        pc=per[(per.Model==model)&(per.Completeness==pct)]
        assert len(pc)==23 and set(pc.Type)==labels and pc.Support.sum()==group.N.iloc[0]
        assert (pc.TP+pc.FN).eq(pc.Support).all()
        assert (pc.TP+pc.FP+pc.FN+pc.TN).eq(group.N.iloc[0]).all()
        np.testing.assert_allclose(pc.TP.sum()/pc.Support.sum(),group.Accuracy,rtol=0,atol=1e-12)
        np.testing.assert_allclose(pc[['Precision','Recall','F1']].mean(),group[group.Average=='macro'][['Precision','Recall','F1']].to_numpy()[0],rtol=0,atol=1e-12)
        np.testing.assert_allclose(bars[(bars.Model==model)&(bars.Completeness==pct)][METRICS],group[group.Average=='macro'][METRICS],rtol=0,atol=1e-12)
    if baseline:
        for name in ['05_ARG_nonARG_ARG_positive_five_metrics','06_ARG_nonARG_macro_weighted_micro','07_ARGScope_Subtype_ARG_only_macro_weighted_micro']:
            before=pd.read_csv(baseline/mod/(name+'.csv'),keep_default_na=False)
            pd.testing.assert_frame_equal(before,get(name),check_exact=False,rtol=0,atol=1e-13)
        before=pd.read_csv(baseline/mod/'01_Type_barplot_macro_five_metrics.csv')
        delta=bars.merge(before,on=['Modality','Model','Completeness'],suffixes=('_fixed23','_previous'))
        keys=['Modality','Model','Completeness']
        for metric in METRICS:
            delta[metric+'_change']=delta[metric+'_fixed23']-delta[metric+'_previous']
            keys += [metric+'_previous',metric+'_fixed23',metric+'_change']
        changed.append(delta[keys].rename(columns={m+'_fixed23':m+'_strict_names' for m in METRICS}))
    sheets={'Type bars':bars,'Type averages':types,'Per Type':per,
        'ARG nonARG':pd.concat([positive,binary],ignore_index=True),'Subtype':subtype,
        'Supplement check':summary[summary.Modality==mod],'Sources':get('08_source_population_audit')}
    for spec in books[mod]:
        frame=sheets[spec['name']]; spec['columns']=list(frame.columns)
        spec['rows']=json.loads(frame.to_json(orient='values',force_ascii=False,double_precision=15))
    verified[mod]=dict(Models=models,Conditions=5,Type_overall_rows=len(types),Per_type_rows=len(per),
        Type_bar_rows=len(bars),Binary_rows=len(binary)+len(positive),Subtype_ARG_only_rows=len(subtype),
        All_Type_groups_use_fixed_23_labels=True,Binary_and_subtype_unchanged=bool(baseline))
(ROOT/'workbook_data.json').write_text(json.dumps(books,ensure_ascii=False,allow_nan=False),encoding='utf-8')
if changed:
    pd.concat(changed).to_csv(ROOT/'supplementary_check/07_change_from_previous_macro_bars.csv',index=False,encoding='utf-8-sig',float_format='%.15g')
notes='''# 固定23类重算与补充材料核对

本次为严格名称对应版。仅保留同名、大小写/分隔符规范化、明确单复数与MLS缩写；不做大类到小类、小类到大类的映射。PLM-ARG多类别输出不再自动改为multidrug或MLS。
缺少对应名称的预测为unmapped错误；不是根据真实标签选择类别。Type_name_mapping_audit.csv逐项列出原始名称、旧对应、新对应与数量。

所有模型、Protein/DNA、60–100%统一到 ARGScope 的23个 Type，名单见 ARGScope_23_types.csv。
先按真实标签筛选：真实标签不在23类中的样本（含nonARG）不参与Type评价。保留剩余样本的全部预测；预测成nonARG、额外Type、unmapped仍为错误。
macro/weighted/micro均指定同一份23类；零分或无支持类别不从macro中删除。ACC为整体正确率，MCC为保留错误输出的全局多分类MCC。
每类五指标按one-vs-rest计算，每类ACC不能求均值代替总体ACC。

## 原补充材料差异

本次读取的是桌面最新补充材料：18张表、950个数值位置。逐格核对记录在02_cell_by_cell_comparison.csv。能匹配旧映射的数值只解释来源，不代表符合本次统一23类要求；未匹配项另行列明，不强行认为正确。
原先的跨层级映射仅保留在08_PREVIOUS_MAPPING_REFERENCE_ONLY.csv，用于解释旧表，绝不用于主结果和新图。Legacy_mapping_removed_name_only_now表示原表使用了本次取消的映射。
所有Type表均从源预测重新计算。具体涉及类别集、映射或二分类平均方式的哪种变化，以逐格核对Status为准，不沿用旧版本文档的结论。
新补充材料全部Type表改为固定23类严格同名对应，保留DeepARG四张表。原始文档未修改。
二分类保留ARG-positive、macro、weighted、micro各行。Subtype口径不变：补充材料含nonARG，工作簿提供ARG-only，均明确标注。

## 审计文件

- 02_cell_by_cell_comparison.csv：原文档每格与新口径的差异。
- 06_legacy_all_ARG_types_AUDIT_ONLY.csv：仅为解释原表而从源预测重算的旧口径审计记录，不得用于新图或主结果。
- 07_change_from_previous_macro_bars.csv：本次柱高与上次错误汇总的变化。
- 本次柱高变化是在同一23类与同一评估记录上，改用严格名称对应产生的变化。
- 主结果和每类结果中没有额外Type或nonARG类。二分类和Subtype已与替换前结果逐格校验。
- 按要求未进行跨模型样本对齐；DeepARG Type记录与其二分类评估分母不同。
'''
(ROOT/'supplementary_check/核对结论_先看这里.md').write_text(notes,encoding='utf-8')
(ROOT/'export_checks.json').write_text(json.dumps(verified,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(verified,ensure_ascii=False,indent=2))
