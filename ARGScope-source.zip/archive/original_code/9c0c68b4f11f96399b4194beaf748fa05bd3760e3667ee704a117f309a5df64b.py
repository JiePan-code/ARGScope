import pandas as pd
import torch
import torch.nn as nn
import math
from tqdm import tqdm


# ==========================================================
# 1. Strict Cross-Attention module
# ==========================================================

class StrictCrossAttention(nn.Module):
    """
    Strict Cross-Attention:
        Q = AA embedding
        K = NT embedding
        V = NT embedding

    Input:
        aa_feat: [B, dim_aa]
        nt_feat: [B, dim_nt]

    Output:
        fused: [B, d_model]
        attn_weights: [B, n_heads]
    """

    def __init__(self, dim_aa, dim_nt, d_model=512, n_heads=8):
        super().__init__()

        assert d_model % n_heads == 0, "d_model must be divisible by n_heads."

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.q_proj = nn.Linear(dim_aa, d_model)
        self.k_proj = nn.Linear(dim_nt, d_model)
        self.v_proj = nn.Linear(dim_nt, d_model)

        self.out_proj = nn.Linear(d_model, d_model)
        self.layernorm = nn.LayerNorm(d_model)

    def forward(self, aa_feat, nt_feat):
        if aa_feat.size(0) != nt_feat.size(0):
            raise ValueError(
                f"AA and NT batch sizes are different: "
                f"aa_feat={aa_feat.shape}, nt_feat={nt_feat.shape}"
            )

        B = aa_feat.size(0)

        Q = self.q_proj(aa_feat)
        K = self.k_proj(nt_feat)
        V = self.v_proj(nt_feat)

        Q = Q.view(B, self.n_heads, self.head_dim)
        K = K.view(B, self.n_heads, self.head_dim)
        V = V.view(B, self.n_heads, self.head_dim)

        scores = (Q * K).sum(dim=-1) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(scores, dim=-1)

        context = attn_weights.unsqueeze(-1) * V
        context = context.reshape(B, self.d_model)

        fused = self.out_proj(context)
        fused = self.layernorm(fused + self.q_proj(aa_feat))

        return fused, attn_weights


# ==========================================================
# 2. File paths
# ==========================================================

nt_file = "dna_90pct_5parts_dnabert2_768.txt"
aa_file = "protein_90pct_5parts_esm2_1280.txt"
label_file = "expanded_id_table_5x2.csv"

output_file = "1.90p_all_fusion_embedding_512_with_label.csv"
missing_aa_file = "missing_in_aa_ids.csv"
unmatched_label_file = "unmatched_fusion_ids.csv"

label_id_col = "id"
label_type_col = "Type"
label_subtype_col = "Subtype"

D_MODEL = 512
N_HEADS = 8
BATCH_SIZE = 4096


# ==========================================================
# 3. Read embedding TXT files
# ==========================================================

print("============================================================")
print("Reading embedding files")
print("NT file:", nt_file)
print("AA file:", aa_file)
print("============================================================")

nt_df = pd.read_csv(nt_file, sep="\t", header=None)
aa_df = pd.read_csv(aa_file, sep="\t", header=None)

id_col_nt = nt_df.columns[0]
id_col_aa = aa_df.columns[0]

nt_df[id_col_nt] = nt_df[id_col_nt].astype(str).str.strip()
aa_df[id_col_aa] = aa_df[id_col_aa].astype(str).str.strip()

print("NT original rows:", len(nt_df))
print("AA original rows:", len(aa_df))
print("NT unique IDs:", nt_df[id_col_nt].nunique())
print("AA unique IDs:", aa_df[id_col_aa].nunique())
print("NT duplicated rows:", len(nt_df) - nt_df[id_col_nt].nunique())
print("AA duplicated rows:", len(aa_df) - aa_df[id_col_aa].nunique())


# ==========================================================
# 4. Use NT IDs as the reference set
# ==========================================================

print("============================================================")
print("Aligning AA and NT embeddings using NT IDs as reference")
print("============================================================")

# NT is the reference. If NT itself has duplicate IDs, keep the first one.
nt_df = nt_df.drop_duplicates(subset=[id_col_nt], keep="first")

# AA may contain duplicated IDs. Keep the first AA embedding for each ID.
aa_df = aa_df.drop_duplicates(subset=[id_col_aa], keep="first")

target_ids_original = nt_df[id_col_nt].tolist()

nt_indexed = nt_df.set_index(id_col_nt)
aa_indexed = aa_df.set_index(id_col_aa)

missing_in_aa = [seq_id for seq_id in target_ids_original if seq_id not in aa_indexed.index]

print("NT reference ID count:", len(target_ids_original))
print("IDs present in NT but missing in AA:", len(missing_in_aa))

if len(missing_in_aa) > 0:
    pd.DataFrame({"id": missing_in_aa}).to_csv(missing_aa_file, index=False)
    print("Missing AA IDs saved to:", missing_aa_file)

# Final IDs: only keep NT IDs that also exist in AA.
target_ids = [seq_id for seq_id in target_ids_original if seq_id in aa_indexed.index]

nt_aligned = nt_indexed.loc[target_ids]
aa_aligned = aa_indexed.loc[target_ids]

print("Final retained sample count:", len(target_ids))
print("NT aligned shape:", nt_aligned.shape)
print("AA aligned shape:", aa_aligned.shape)

if len(target_ids) != 134390:
    print("WARNING: final retained sample count is not 134390.")
    print("This usually means some NT IDs are missing in the AA embedding file.")

if nt_aligned.shape[0] != aa_aligned.shape[0]:
    raise ValueError(
        f"Aligned row count mismatch: NT={nt_aligned.shape[0]}, AA={aa_aligned.shape[0]}"
    )

if nt_aligned.shape[0] != len(target_ids):
    raise ValueError("NT aligned row count does not match target_ids length.")

if aa_aligned.shape[0] != len(target_ids):
    raise ValueError("AA aligned row count does not match target_ids length.")


# ==========================================================
# 5. Convert to tensors
# ==========================================================

nt_feat_all = torch.tensor(nt_aligned.values, dtype=torch.float32)
aa_feat_all = torch.tensor(aa_aligned.values, dtype=torch.float32)

print("NT tensor shape:", nt_feat_all.shape)
print("AA tensor shape:", aa_feat_all.shape)

if nt_feat_all.shape[1] != 768:
    print("WARNING: NT feature dimension is not 768:", nt_feat_all.shape[1])

if aa_feat_all.shape[1] != 1280:
    print("WARNING: AA feature dimension is not 1280:", aa_feat_all.shape[1])


# ==========================================================
# 6. Device
# ==========================================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("============================================================")
print("Using device:", device)
if device.type == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))
print("============================================================")


# ==========================================================
# 7. Initialize model
# ==========================================================

dim_aa = aa_feat_all.shape[1]
dim_nt = nt_feat_all.shape[1]

model = StrictCrossAttention(
    dim_aa=dim_aa,
    dim_nt=dim_nt,
    d_model=D_MODEL,
    n_heads=N_HEADS
).to(device)

model.eval()


# ==========================================================
# 8. Forward fusion in batches
# ==========================================================

print("============================================================")
print("Start fusion")
print("Batch size:", BATCH_SIZE)
print("============================================================")

all_fused = []
all_attn = []

with torch.no_grad():
    for start in tqdm(range(0, len(target_ids), BATCH_SIZE), desc="Fusing"):
        end = min(start + BATCH_SIZE, len(target_ids))

        aa_batch = aa_feat_all[start:end].to(device)
        nt_batch = nt_feat_all[start:end].to(device)

        fused_batch, attn_batch = model(aa_batch, nt_batch)

        all_fused.append(fused_batch.cpu())
        all_attn.append(attn_batch.cpu())

        del aa_batch, nt_batch, fused_batch, attn_batch

        if device.type == "cuda":
            torch.cuda.empty_cache()

fused_feat = torch.cat(all_fused, dim=0)
attn_weights = torch.cat(all_attn, dim=0)

print("Fusion feature shape:", fused_feat.shape)
print("Attention weight shape:", attn_weights.shape)

if fused_feat.shape[0] != len(target_ids):
    raise ValueError("Fused feature row count does not match target_ids length.")


# ==========================================================
# 9. Save fused features
# ==========================================================

print("============================================================")
print("Building output dataframe")
print("============================================================")

fusion_np = fused_feat.numpy()
feature_cols = [f"fusion_{i}" for i in range(fusion_np.shape[1])]

fusion_df = pd.DataFrame(fusion_np, columns=feature_cols)
fusion_df.insert(0, "id", target_ids)


# ==========================================================
# 10. Read labels and merge Type / Subtype
# ==========================================================

print("============================================================")
print("Reading label file:", label_file)
print("============================================================")

label_df = pd.read_csv(label_file)
label_df[label_id_col] = label_df[label_id_col].astype(str).str.strip()

required_cols = [label_id_col, label_type_col, label_subtype_col]

for col in required_cols:
    if col not in label_df.columns:
        raise ValueError(f"Label file is missing column: {col}")

label_df = label_df[[label_id_col, label_type_col, label_subtype_col]].copy()
label_df.columns = ["id", "type", "subtype"]

# If label file has duplicated IDs, keep the first one.
label_df = label_df.drop_duplicates(subset=["id"], keep="first")

final_df = fusion_df.merge(label_df, on="id", how="left")
final_df = final_df[["id", "type", "subtype"] + feature_cols]

matched_n = final_df["type"].notna().sum()
unmatched_n = final_df["type"].isna().sum()

print("Matched labels:", matched_n)
print("Unmatched labels:", unmatched_n)

if unmatched_n > 0:
    final_df.loc[final_df["type"].isna(), ["id"]].to_csv(unmatched_label_file, index=False)
    print("Unmatched label IDs saved to:", unmatched_label_file)


# ==========================================================
# 11. Output CSV
# ==========================================================

print("============================================================")
print("Saving output")
print("Output file:", output_file)
print("============================================================")

final_df.to_csv(output_file, index=False)

print("Done.")
print("Saved fusion embedding to:", output_file)
print("Final output shape:", final_df.shape)