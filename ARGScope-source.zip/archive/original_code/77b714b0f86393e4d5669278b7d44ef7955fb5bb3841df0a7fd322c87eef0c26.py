#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope vs ARG-OAP vs DeepARG on real metagenomic datasets
============================================================

Expected directory structure
----------------------------
Put this script in the SAME folder as:

    ARGOAP and DeepARG.xls
    ARGScope_DIAMOND_gate010_realdata_predictions/
    ARGScope_DIAMOND_gate020_realdata_predictions/
    ARGScope_DIAMOND_gate030_realdata_predictions/
    ARGScope_DIAMOND_gate040_realdata_predictions/
    ARGScope_DIAMOND_gate050_realdata_predictions/

Each ARGScope gate folder must contain:

    all_thresholds_final_ARG_count_matrix.csv

The ARGScope CSV is expected to look like:

    sample_name,
    final_ARG_count_diamond0.2,
    final_ARG_count_diamond0.5,
    ...

Goal
----
1. Automatically scan all gate x DIAMOND threshold combinations.
2. Use ARG-OAP as the reference and find the ARGScope setting whose sample-level
   total ARG counts are most similar to ARG-OAP.
3. Compare the selected ARGScope setting with ARG-OAP and DeepARG.
4. Export publication-style figures and all intermediate tables.

Parameter-selection metric
--------------------------
Primary score:
    mean(abs(log10(ARGScope_count + 1) - log10(ARG-OAP_count + 1)))

Smaller = closer to ARG-OAP.

The independent sample values are NOT modified; log transformation is used only
for measuring scale-aware similarity and for some plots.

Python 3.8 compatible.
"""

from __future__ import print_function

import math
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =============================================================================
# 1. SETTINGS
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

# Prefer CSV so no xlrd dependency is required. If CSV is absent, xlsx/xls are
# used as fallbacks.
REFERENCE_CANDIDATES = [
    ROOT_DIR / "ARGOAP and DeepARG.csv",
    ROOT_DIR / "ARGOAP and DeepARG.xlsx",
    ROOT_DIR / "ARGOAP and DeepARG.xls",
]


def choose_reference_file():
    for path in REFERENCE_CANDIDATES:
        if path.exists():
            return path
    # Return the preferred filename so the later error message is explicit.
    return REFERENCE_CANDIDATES[0]


REFERENCE_FILE = choose_reference_file()
GATE_GLOB = "ARGScope_DIAMOND_gate*_realdata_predictions"
ARG_SCOPE_MATRIX_NAME = "all_thresholds_final_ARG_count_matrix.csv"

OUTDIR = ROOT_DIR / "ARGScope_centered_realdata_comparison"
FIGDIR = OUTDIR / "figures"
TABLEDIR = OUTDIR / "tables"
PREVIEWDIR = OUTDIR / "reference_workbook_previews"

for d in [OUTDIR, FIGDIR, TABLEDIR, PREVIEWDIR]:
    d.mkdir(parents=True, exist_ok=True)

DPI = 600
SAVE_PDF = True
SAVE_SVG = True

# Reference workbook model-name preferences.
# DeepARG_Count is preferred over DeepARG_short if both exist.
ARGOAP_KEYWORDS = [
    "arg_oap_3",
    "arg_oap",
    "argoap",
]

DEEPARG_KEYWORDS = [
    "deeparg_count",
    "deep_arg_count",
    "deeparg",
]

# If your workbook contains both DeepARG_Count and DeepARG_short, keep this True.
PREFER_DEEPARG_COUNT = True

# Plot colors
MODEL_COLORS = {
    "ARGScope": "#B2182B",
    "ARG-OAP": "#A6A6A6",
    "DeepARG": "#6F8FA6",
}

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 11.5,
    "axes.labelsize": 10.5,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "figure.titlesize": 14,
    "axes.linewidth": 0.9,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 2. GENERAL HELPERS
# =============================================================================


def clean_text(x):
    if pd.isna(x):
        return ""
    return str(x).replace("\ufeff", "").strip()


def token(x):
    s = clean_text(x).lower()
    s = s.replace("%", "pct")
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def natural_sample_key(name):
    s = clean_text(name)
    m = re.match(r"^(.*?)[_\- ]?(\d+)$", s)
    if m:
        return (m.group(1).lower(), int(m.group(2)))
    return (s.lower(), 999999)


def save_figure(fig, base_path):
    png = base_path.with_suffix(".png")
    fig.savefig(png, dpi=DPI, bbox_inches="tight", facecolor="white")
    if SAVE_PDF:
        fig.savefig(base_path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    if SAVE_SVG:
        fig.savefig(base_path.with_suffix(".svg"), bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("[IMAGE SAVED]", png)


def parse_gate_value(folder_name):
    m = re.search(r"gate(\d+)", folder_name, flags=re.I)
    if not m:
        return np.nan
    digits = m.group(1)
    value = int(digits)
    # gate010 -> 0.10, gate020 -> 0.20, gate050 -> 0.50
    if value <= 100:
        return value / 100.0
    return float(value)


def parse_diamond_value(column_name):
    m = re.search(r"diamond\s*([0-9]*\.?[0-9]+)", str(column_name), flags=re.I)
    if not m:
        return np.nan
    return float(m.group(1))


def detect_sample_column(df):
    candidates = ["sample_name", "sample", "dataset", "dataset_name", "name"]
    cmap = {token(c): c for c in df.columns}
    for c in candidates:
        if token(c) in cmap:
            return cmap[token(c)]
    return df.columns[0]


# =============================================================================
# 3. READ ALL ARGScope GATE x DIAMOND RESULTS
# =============================================================================


def read_all_argscope_results():
    gate_dirs = sorted([p for p in ROOT_DIR.glob(GATE_GLOB) if p.is_dir()])

    if not gate_dirs:
        raise FileNotFoundError(
            "No ARGScope gate folders found by pattern: %s" % (ROOT_DIR / GATE_GLOB)
        )

    rows = []
    file_summary = []

    print("\n" + "=" * 92)
    print("Scanning ARGScope gate folders")
    print("=" * 92)

    for gate_dir in gate_dirs:
        gate = parse_gate_value(gate_dir.name)
        path = gate_dir / ARG_SCOPE_MATRIX_NAME

        if not path.exists():
            print("[MISSING]", path)
            continue

        df = pd.read_csv(path, encoding="utf-8-sig")
        sample_col = detect_sample_column(df)

        diamond_cols = []
        for c in df.columns:
            d = parse_diamond_value(c)
            if np.isfinite(d):
                diamond_cols.append((c, d))

        if not diamond_cols:
            print("[SKIP] no diamond columns:", path)
            continue

        print(
            "[READ] gate=%.2f | samples=%d | diamond=%s | %s"
            % (gate, len(df), [x[1] for x in diamond_cols], path.name)
        )

        file_summary.append({
            "gate_folder": gate_dir.name,
            "gate": gate,
            "file": str(path),
            "n_samples": len(df),
            "diamond_thresholds": ",".join(str(x[1]) for x in diamond_cols),
        })

        for _, r in df.iterrows():
            sample = clean_text(r[sample_col])
            if not sample:
                continue
            for col, diamond in diamond_cols:
                count = pd.to_numeric(pd.Series([r[col]]), errors="coerce").iloc[0]
                if pd.isna(count):
                    continue
                rows.append({
                    "sample_name": sample,
                    "gate": float(gate),
                    "diamond": float(diamond),
                    "ARGScope_count": float(count),
                    "source_file": str(path),
                })

    if not rows:
        raise RuntimeError("No usable ARGScope count data found.")

    out = pd.DataFrame(rows)
    out = out.sort_values(["gate", "diamond", "sample_name"]).reset_index(drop=True)

    pd.DataFrame(file_summary).to_csv(
        TABLEDIR / "ARGScope_scanned_gate_files.csv", index=False, encoding="utf-8-sig"
    )
    out.to_csv(
        TABLEDIR / "ARGScope_all_gate_diamond_counts_long.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return out


# =============================================================================
# 4. FLEXIBLE READER FOR "ARGOAP and DeepARG.xls"
# =============================================================================


def read_csv_flexible(path, header=0):
    """Read a CSV robustly across common Windows encodings/delimiters."""
    errors = []
    for encoding in ["utf-8-sig", "utf-8", "gb18030", "cp1252"]:
        try:
            return pd.read_csv(
                path,
                header=header,
                sep=None,
                engine="python",
                encoding=encoding,
                skip_blank_lines=False,
            )
        except Exception as e:
            errors.append("%s: %s" % (encoding, e))

    raise RuntimeError(
        "Could not read reference CSV: %s\nTried encodings: utf-8-sig, utf-8, gb18030, cp1252\n%s"
        % (path, "\n".join(errors[-4:]))
    )


def read_reference_all_sheets(path, header=0):
    """
    Read the reference file and return a dict of table name -> DataFrame.

    CSV is treated as one sheet named 'CSV'. XLSX/XLS keep the original
    multi-sheet behavior.
    """
    suffix = path.suffix.lower()

    if suffix == ".csv":
        return {"CSV": read_csv_flexible(path, header=header)}

    if suffix in {".xlsx", ".xls"}:
        try:
            return pd.read_excel(path, sheet_name=None, header=header)
        except ImportError as e:
            if suffix == ".xls":
                raise ImportError(
                    "Reading .xls requires xlrd. Easiest solution: save the file as\n"
                    "    ARGOAP and DeepARG.csv\n"
                    "in the same folder and rerun this script.\n"
                    "Alternatively install xlrd with: pip install xlrd\n"
                    "Original error: %s" % e
                )
            raise

    raise ValueError("Unsupported reference file type: %s" % path)


def find_keyword_column(columns, keywords):
    cols = list(columns)
    tmap = [(c, token(c)) for c in cols]
    for kw in keywords:
        tkw = token(kw)
        for c, tc in tmap:
            if tkw == tc or tkw in tc:
                return c
    return None


def keyword_score(value, keywords):
    tv = token(value)
    if not tv:
        return -1
    for rank, kw in enumerate(keywords):
        tk = token(kw)
        if tv == tk:
            return 1000 - rank
        if tk in tv:
            return 500 - rank
    return -1


def extract_reference_format_sample_rows(sheets, sample_names):
    """Format: one row per sample, columns contain ARG-OAP and DeepARG."""
    known = {token(s): s for s in sample_names}

    for sheet, df0 in sheets.items():
        df = df0.copy().dropna(how="all").dropna(axis=1, how="all")
        if df.empty:
            continue

        argoap_col = find_keyword_column(df.columns, ARGOAP_KEYWORDS)
        deep_col = find_keyword_column(df.columns, DEEPARG_KEYWORDS)

        if argoap_col is None or deep_col is None:
            continue

        for c in df.columns:
            vals = df[c].map(token)
            nmatch = vals.isin(set(known.keys())).sum()
            if nmatch >= max(3, min(5, len(sample_names))):
                rows = []
                for _, r in df.iterrows():
                    ts = token(r[c])
                    if ts not in known:
                        continue
                    rows.append({
                        "sample_name": known[ts],
                        "ARG-OAP": pd.to_numeric(pd.Series([r[argoap_col]]), errors="coerce").iloc[0],
                        "DeepARG": pd.to_numeric(pd.Series([r[deep_col]]), errors="coerce").iloc[0],
                        "reference_sheet": str(sheet),
                        "reference_format": "sample_rows",
                    })
                res = pd.DataFrame(rows).dropna(subset=["ARG-OAP", "DeepARG"], how="all")
                if len(res) >= 3:
                    return res
    return None


def extract_reference_format_model_rows(sheets, sample_names):
    """Format: samples are columns; ARG-OAP and DeepARG are rows."""
    known = {token(s): s for s in sample_names}

    for sheet, df0 in sheets.items():
        df = df0.copy().dropna(how="all").dropna(axis=1, how="all")
        if df.empty:
            continue

        sample_columns = {}
        for c in df.columns:
            tc = token(c)
            if tc in known:
                sample_columns[c] = known[tc]

        if len(sample_columns) < 3:
            continue

        argoap_candidates = []
        deep_candidates = []

        for idx, r in df.iterrows():
            text_values = [clean_text(v) for v in r.tolist()]
            arg_score = max([keyword_score(v, ARGOAP_KEYWORDS) for v in text_values] + [-1])
            deep_score = max([keyword_score(v, DEEPARG_KEYWORDS) for v in text_values] + [-1])

            # Penalize DeepARG_short when DeepARG_Count is available later.
            if PREFER_DEEPARG_COUNT and any("short" in token(v) for v in text_values):
                deep_score -= 150

            if arg_score >= 0:
                argoap_candidates.append((arg_score, idx))
            if deep_score >= 0:
                deep_candidates.append((deep_score, idx))

        if not argoap_candidates or not deep_candidates:
            continue

        argoap_idx = sorted(argoap_candidates, reverse=True)[0][1]
        deep_idx = sorted(deep_candidates, reverse=True)[0][1]

        rows = []
        for c, sample in sample_columns.items():
            rows.append({
                "sample_name": sample,
                "ARG-OAP": pd.to_numeric(pd.Series([df.loc[argoap_idx, c]]), errors="coerce").iloc[0],
                "DeepARG": pd.to_numeric(pd.Series([df.loc[deep_idx, c]]), errors="coerce").iloc[0],
                "reference_sheet": str(sheet),
                "reference_format": "model_rows",
            })
        res = pd.DataFrame(rows).dropna(subset=["ARG-OAP", "DeepARG"], how="all")
        if len(res) >= 3:
            return res

    return None


def locate_sample_header_row(raw, known_tokens, start_row, max_search=12):
    nrows = len(raw)
    best = None
    for rr in range(start_row, min(nrows, start_row + max_search + 1)):
        vals = [token(v) for v in raw.iloc[rr].tolist()]
        matches = [(cc, known_tokens[t]) for cc, t in enumerate(vals) if t in known_tokens]
        if best is None or len(matches) > len(best[1]):
            best = (rr, matches)
    if best is not None and len(best[1]) >= 3:
        return best
    return None


def extract_section_totals(raw, model_row, header_row, sample_matches, next_model_row):
    start = header_row + 1
    stop = next_model_row if next_model_row is not None else len(raw)

    totals = {sample: 0.0 for _, sample in sample_matches}
    valid_counts = {sample: 0 for _, sample in sample_matches}
    consecutive_blank = 0

    for rr in range(start, stop):
        row = raw.iloc[rr]
        numeric_in_samples = 0
        for cc, sample in sample_matches:
            if cc >= len(row):
                continue
            val = pd.to_numeric(pd.Series([row.iloc[cc]]), errors="coerce").iloc[0]
            if pd.notna(val):
                totals[sample] += float(val)
                valid_counts[sample] += 1
                numeric_in_samples += 1

        if numeric_in_samples == 0:
            consecutive_blank += 1
        else:
            consecutive_blank = 0

        # In stacked tables, two blank/non-numeric lines usually mean section end.
        if consecutive_blank >= 2:
            break

    result = {}
    for sample in totals:
        if valid_counts[sample] > 0:
            result[sample] = totals[sample]
    return result


def extract_reference_format_sections(raw_sheets, sample_names):
    """
    Flexible fallback for stacked tables such as:

        DeepARG_Count
        Type    argbert_1 ... argscope_6
        type1   ...
        type2   ...

        ARG-OAP 3
        Type    argbert_1 ... argscope_6
        ...

    Counts are summed across Type rows for each sample.
    """
    known = {token(s): s for s in sample_names}

    for sheet, raw0 in raw_sheets.items():
        raw = raw0.copy().dropna(how="all").dropna(axis=1, how="all")
        if raw.empty:
            continue

        model_hits = []
        for rr in range(len(raw)):
            values = [clean_text(v) for v in raw.iloc[rr].tolist()]
            arg_score = max([keyword_score(v, ARGOAP_KEYWORDS) for v in values] + [-1])
            deep_score = max([keyword_score(v, DEEPARG_KEYWORDS) for v in values] + [-1])
            if PREFER_DEEPARG_COUNT and any("short" in token(v) for v in values):
                deep_score -= 150
            if arg_score >= 0:
                model_hits.append((rr, "ARG-OAP", arg_score))
            if deep_score >= 0:
                model_hits.append((rr, "DeepARG", deep_score))

        if not model_hits:
            continue

        # Keep best hit per model if multiple title rows exist.
        best_model_hit = {}
        for rr, model, score in model_hits:
            if model not in best_model_hit or score > best_model_hit[model][1]:
                best_model_hit[model] = (rr, score)

        if "ARG-OAP" not in best_model_hit or "DeepARG" not in best_model_hit:
            continue

        section_totals = {}
        all_model_rows = sorted([x[0] for x in model_hits])

        for model in ["ARG-OAP", "DeepARG"]:
            model_row = best_model_hit[model][0]
            header_info = locate_sample_header_row(raw, known, model_row, max_search=10)
            if header_info is None:
                continue
            header_row, matches = header_info

            later_model_rows = [r for r in all_model_rows if r > header_row]
            next_model = min(later_model_rows) if later_model_rows else None

            totals = extract_section_totals(
                raw=raw,
                model_row=model_row,
                header_row=header_row,
                sample_matches=matches,
                next_model_row=next_model,
            )
            section_totals[model] = totals

        if "ARG-OAP" in section_totals and "DeepARG" in section_totals:
            rows = []
            for sample in sample_names:
                a = section_totals["ARG-OAP"].get(sample, np.nan)
                d = section_totals["DeepARG"].get(sample, np.nan)
                if pd.notna(a) or pd.notna(d):
                    rows.append({
                        "sample_name": sample,
                        "ARG-OAP": a,
                        "DeepARG": d,
                        "reference_sheet": str(sheet),
                        "reference_format": "stacked_sections_sum_types",
                    })
            res = pd.DataFrame(rows)
            if len(res) >= 3:
                return res

    return None


def read_reference_counts(sample_names):
    if not REFERENCE_FILE.exists():
        raise FileNotFoundError(
            "Reference file not found. Preferred file is:\n  %s\n"
            "Please save your Excel file as 'ARGOAP and DeepARG.csv' in the same folder as this script."
            % REFERENCE_FILE
        )

    print("\n" + "=" * 92)
    print("Reading ARG-OAP / DeepARG reference file")
    print("=" * 92)
    print("Reference:", REFERENCE_FILE)

    # Save previews to make future troubleshooting easy.
    sheets = read_reference_all_sheets(REFERENCE_FILE, header=0)
    raw_sheets = read_reference_all_sheets(REFERENCE_FILE, header=None)

    for sheet, df in raw_sheets.items():
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(sheet))
        df.head(80).to_csv(
            PREVIEWDIR / (safe + "_first80rows.csv"),
            index=False,
            header=False,
            encoding="utf-8-sig",
        )
        print("[SHEET] %-20s shape=%s" % (sheet, tuple(df.shape)))

    parsers = [
        ("sample_rows", lambda: extract_reference_format_sample_rows(sheets, sample_names)),
        ("model_rows", lambda: extract_reference_format_model_rows(sheets, sample_names)),
        ("stacked_sections", lambda: extract_reference_format_sections(raw_sheets, sample_names)),
    ]

    ref = None
    used = None
    for name, parser in parsers:
        try:
            temp = parser()
        except Exception as e:
            print("[REFERENCE PARSER FAILED] %s: %s" % (name, e))
            continue
        if temp is not None and len(temp) >= 3:
            ref = temp.copy()
            used = name
            break

    if ref is None:
        raise RuntimeError(
            "Could not automatically parse ARG-OAP / DeepARG totals from the workbook.\n"
            "I already exported workbook previews to:\n  %s\n"
            "Send me the first preview CSV and I can adapt the parser exactly."
            % PREVIEWDIR
        )

    ref["sample_name"] = ref["sample_name"].map(clean_text)
    ref["ARG-OAP"] = pd.to_numeric(ref["ARG-OAP"], errors="coerce")
    ref["DeepARG"] = pd.to_numeric(ref["DeepARG"], errors="coerce")
    ref = ref.drop_duplicates("sample_name", keep="first")

    order = {token(s): i for i, s in enumerate(sample_names)}
    ref["_ord"] = ref["sample_name"].map(lambda x: order.get(token(x), 9999))
    ref = ref.sort_values("_ord").drop(columns="_ord").reset_index(drop=True)

    print("Reference parser used:", used)
    print(ref[["sample_name", "ARG-OAP", "DeepARG"]].to_string(index=False))

    ref.to_csv(
        TABLEDIR / "ARGOAP_DeepARG_extracted_total_counts.csv",
        index=False,
        encoding="utf-8-sig",
    )
    return ref


# =============================================================================
# 5. PARAMETER SCREENING AGAINST ARG-OAP
# =============================================================================


def evaluate_parameter_grid(argscope_long, ref):
    merged = argscope_long.merge(
        ref[["sample_name", "ARG-OAP", "DeepARG"]],
        on="sample_name",
        how="inner",
    )

    if merged.empty:
        raise RuntimeError("No matching sample names between ARGScope and ARG-OAP/DeepARG.")

    rows = []
    for (gate, diamond), g in merged.groupby(["gate", "diamond"], sort=True):
        g = g.dropna(subset=["ARGScope_count", "ARG-OAP"]).copy()
        if len(g) == 0:
            continue

        la = np.log10(g["ARGScope_count"].to_numpy(dtype=float) + 1.0)
        lo = np.log10(g["ARG-OAP"].to_numpy(dtype=float) + 1.0)
        diff = la - lo

        abs_log_diff = np.abs(diff)
        mean_abs_log_diff = float(np.mean(abs_log_diff))
        median_abs_log_diff = float(np.median(abs_log_diff))
        rmse_log = float(np.sqrt(np.mean(diff ** 2)))
        mean_signed_log_diff = float(np.mean(diff))

        if len(g) >= 3:
            pearson = float(pd.Series(la).corr(pd.Series(lo), method="pearson"))
            spearman = float(pd.Series(la).corr(pd.Series(lo), method="spearman"))
        else:
            pearson = np.nan
            spearman = np.nan

        fold_errors = np.maximum(
            (g["ARGScope_count"].to_numpy(dtype=float) + 1.0) / (g["ARG-OAP"].to_numpy(dtype=float) + 1.0),
            (g["ARG-OAP"].to_numpy(dtype=float) + 1.0) / (g["ARGScope_count"].to_numpy(dtype=float) + 1.0),
        )

        rows.append({
            "gate": gate,
            "diamond": diamond,
            "n_common_samples": len(g),
            "mean_abs_log10_diff": mean_abs_log_diff,
            "median_abs_log10_diff": median_abs_log_diff,
            "rmse_log10": rmse_log,
            "mean_signed_log10_diff": mean_signed_log_diff,
            "pearson_log10": pearson,
            "spearman_log10": spearman,
            "median_symmetric_fold_error": float(np.median(fold_errors)),
        })

    scores = pd.DataFrame(rows)
    if scores.empty:
        raise RuntimeError("No valid gate x diamond comparison scores were produced.")

    # Primary: smallest scale-aware error. Tie breakers favor correlation.
    scores = scores.sort_values(
        ["mean_abs_log10_diff", "rmse_log10", "spearman_log10"],
        ascending=[True, True, False],
        na_position="last",
    ).reset_index(drop=True)
    scores.insert(0, "rank", np.arange(1, len(scores) + 1))

    scores.to_csv(
        TABLEDIR / "ARGScope_gate_diamond_similarity_to_ARGOAP_ranked.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    best = scores.iloc[0].to_dict()
    print("\n" + "=" * 92)
    print("BEST ARGScope SETTING RELATIVE TO ARG-OAP")
    print("=" * 92)
    print("gate              = %.2f" % best["gate"])
    print("diamond           = %.2f" % best["diamond"])
    print("mean abs log diff = %.6f" % best["mean_abs_log10_diff"])
    print("Spearman(log10)   = %.4f" % best["spearman_log10"])

    return scores, best


# =============================================================================
# 6. FIGURE 1: GATE x DIAMOND HEATMAP
# =============================================================================


def draw_parameter_heatmap(scores, best):
    gates = sorted(scores["gate"].unique())
    diamonds = sorted(scores["diamond"].unique())

    matrix = scores.pivot(index="gate", columns="diamond", values="mean_abs_log10_diff")
    matrix = matrix.reindex(index=gates, columns=diamonds)

    fig, ax = plt.subplots(figsize=(8.5, 5.7), dpi=180)
    values = matrix.to_numpy(dtype=float)
    masked = np.ma.masked_invalid(values)

    im = ax.imshow(masked, aspect="auto", cmap="viridis_r")
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Mean absolute log10 difference vs ARG-OAP", fontsize=10)

    ax.set_xticks(np.arange(len(diamonds)))
    ax.set_xticklabels(["%.1f" % x for x in diamonds])
    ax.set_yticks(np.arange(len(gates)))
    ax.set_yticklabels(["%.2f" % x for x in gates])

    ax.set_xlabel("DIAMOND threshold")
    ax.set_ylabel("ARGScope gate threshold")
    ax.set_title("ARGScope parameter screening against ARG-OAP", fontweight="bold", pad=10)

    finite = values[np.isfinite(values)]
    threshold = np.nanmedian(finite) if finite.size else 0

    for i, gate in enumerate(gates):
        for j, diamond in enumerate(diamonds):
            v = values[i, j]
            if not np.isfinite(v):
                continue
            color = "white" if v >= threshold else "black"
            ax.text(j, i, "%.3f" % v, ha="center", va="center", fontsize=8.5, color=color)

    # Mark selected best setting.
    bi = gates.index(float(best["gate"]))
    bj = diamonds.index(float(best["diamond"]))
    rect = plt.Rectangle((bj - 0.48, bi - 0.48), 0.96, 0.96,
                         fill=False, edgecolor="#D00000", linewidth=2.6)
    ax.add_patch(rect)
    ax.text(bj, bi - 0.37, "BEST", ha="center", va="center",
            fontsize=7.5, fontweight="bold", color="#D00000")

    ax.set_xticks(np.arange(-0.5, len(diamonds), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(gates), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=0.8, alpha=0.6)
    ax.tick_params(which="minor", bottom=False, left=False)

    save_figure(fig, FIGDIR / "Fig1_gate_diamond_similarity_heatmap")


# =============================================================================
# 7. PREPARE BEST SETTING
# =============================================================================


def prepare_best_comparison(argscope_long, ref, best):
    sub = argscope_long[
        np.isclose(argscope_long["gate"], float(best["gate"])) &
        np.isclose(argscope_long["diamond"], float(best["diamond"]))
    ][["sample_name", "ARGScope_count"]].copy()

    merged = ref[["sample_name", "ARG-OAP", "DeepARG"]].merge(
        sub, on="sample_name", how="inner"
    )

    merged = merged.rename(columns={"ARGScope_count": "ARGScope"})
    merged = merged[["sample_name", "ARGScope", "ARG-OAP", "DeepARG"]]
    merged = merged.sort_values("sample_name", key=lambda s: s.map(natural_sample_key)).reset_index(drop=True)

    merged["ARGScope_vs_ARGOAP_log10_diff"] = (
        np.log10(merged["ARGScope"].astype(float) + 1.0)
        - np.log10(merged["ARG-OAP"].astype(float) + 1.0)
    )
    merged["DeepARG_vs_ARGOAP_log10_diff"] = (
        np.log10(merged["DeepARG"].astype(float) + 1.0)
        - np.log10(merged["ARG-OAP"].astype(float) + 1.0)
    )

    merged.to_csv(
        TABLEDIR / "best_setting_ARGScope_ARGOAP_DeepARG_counts.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    return merged


# =============================================================================
# 8. FIGURE 2: GROUPED BARPLOT
# =============================================================================


def draw_best_grouped_bar(df, best):
    samples = df["sample_name"].tolist()
    x = np.arange(len(samples), dtype=float)
    width = 0.24

    fig, ax = plt.subplots(figsize=(11.2, 5.8), dpi=180)

    models = ["ARG-OAP", "ARGScope", "DeepARG"]
    offsets = [-width, 0.0, width]

    for model, offset in zip(models, offsets):
        # +1 permits zeros on log axis.
        ax.bar(
            x + offset,
            df[model].astype(float).to_numpy() + 1.0,
            width=width,
            label=model,
            color=MODEL_COLORS[model],
            edgecolor="white",
            linewidth=0.6,
            alpha=0.90,
        )

    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(samples, rotation=35, ha="right")
    ax.set_ylabel("ARG count + 1 (log scale)")
    ax.set_xlabel("Sample")
    ax.set_title(
        "ARG abundance comparison at selected ARGScope setting\n"
        "gate=%.2f, DIAMOND=%.2f" % (best["gate"], best["diamond"]),
        fontweight="bold",
        pad=10,
    )
    ax.legend(frameon=False, ncol=3, loc="upper left")
    ax.grid(axis="y", linestyle=":", linewidth=0.55, alpha=0.25)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    save_figure(fig, FIGDIR / "Fig2_best_setting_three_model_counts")


# =============================================================================
# 9. FIGURE 3: CORRELATION AGAINST ARG-OAP
# =============================================================================


def one_scatter_panel(ax, x, y, sample_names, model, color):
    x = np.asarray(x, dtype=float) + 1.0
    y = np.asarray(y, dtype=float) + 1.0

    ax.scatter(x, y, s=52, color=color, alpha=0.82,
               edgecolors="white", linewidths=0.6, zorder=3)

    low = max(0.8, min(np.nanmin(x), np.nanmin(y)) * 0.75)
    high = max(np.nanmax(x), np.nanmax(y)) * 1.35
    ax.plot([low, high], [low, high], linestyle="--", color="#555555",
            linewidth=1.0, alpha=0.75, zorder=1)

    for xi, yi, s in zip(x, y, sample_names):
        ax.annotate(str(s), (xi, yi), xytext=(4, 4), textcoords="offset points",
                    fontsize=7.2, color="#444444")

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(low, high)
    ax.set_ylim(low, high)
    ax.set_xlabel("ARG-OAP count + 1")
    ax.set_ylabel("%s count + 1" % model)
    ax.set_title("%s vs ARG-OAP" % model, fontweight="bold")
    ax.grid(True, which="both", linestyle=":", linewidth=0.45, alpha=0.20)

    lx = np.log10(x)
    ly = np.log10(y)
    pearson = pd.Series(lx).corr(pd.Series(ly), method="pearson")
    spearman = pd.Series(lx).corr(pd.Series(ly), method="spearman")
    mad = np.mean(np.abs(lx - ly))

    text = "Pearson r = %.3f\nSpearman rho = %.3f\nMean |log10 diff| = %.3f" % (
        pearson, spearman, mad
    )
    ax.text(0.04, 0.96, text, transform=ax.transAxes,
            ha="left", va="top", fontsize=8.2,
            bbox=dict(boxstyle="round,pad=0.28", facecolor="white",
                      edgecolor="#dddddd", alpha=0.90))


def draw_correlation_scatter(df, best):
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 5.0), dpi=180)

    one_scatter_panel(
        axes[0], df["ARG-OAP"], df["ARGScope"], df["sample_name"],
        "ARGScope", MODEL_COLORS["ARGScope"]
    )
    one_scatter_panel(
        axes[1], df["ARG-OAP"], df["DeepARG"], df["sample_name"],
        "DeepARG", MODEL_COLORS["DeepARG"]
    )

    fig.suptitle(
        "Agreement with ARG-OAP across samples",
        fontsize=14, fontweight="bold", y=1.01
    )
    fig.tight_layout()
    save_figure(fig, FIGDIR / "Fig3_sample_level_agreement_with_ARGOAP")


# =============================================================================
# 10. FIGURE 4: SAMPLE-WISE SIGNED DEVIATION FROM ARG-OAP
# =============================================================================


def draw_log_difference(df):
    samples = df["sample_name"].tolist()
    x = np.arange(len(samples))
    width = 0.34

    a = df["ARGScope_vs_ARGOAP_log10_diff"].to_numpy(dtype=float)
    d = df["DeepARG_vs_ARGOAP_log10_diff"].to_numpy(dtype=float)

    fig, ax = plt.subplots(figsize=(10.8, 5.4), dpi=180)
    ax.bar(x - width / 2, a, width,
           label="ARGScope - ARG-OAP", color=MODEL_COLORS["ARGScope"], alpha=0.88)
    ax.bar(x + width / 2, d, width,
           label="DeepARG - ARG-OAP", color=MODEL_COLORS["DeepARG"], alpha=0.88)

    ax.axhline(0, color="#222222", linewidth=0.9)
    ax.set_xticks(x)
    ax.set_xticklabels(samples, rotation=35, ha="right")
    ax.set_ylabel("log10(count + 1) difference relative to ARG-OAP")
    ax.set_xlabel("Sample")
    ax.set_title("Sample-wise deviation from ARG-OAP", fontweight="bold")
    ax.legend(frameon=False, ncol=2)
    ax.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.25)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    save_figure(fig, FIGDIR / "Fig4_samplewise_log_difference_vs_ARGOAP")


# =============================================================================
# 11. FIGURE 5: PARAMETER CURVES
# =============================================================================


def draw_parameter_curves(scores, best):
    fig, ax = plt.subplots(figsize=(8.8, 5.6), dpi=180)

    for gate in sorted(scores["gate"].unique()):
        sub = scores[np.isclose(scores["gate"], gate)].sort_values("diamond")
        ax.plot(
            sub["diamond"], sub["mean_abs_log10_diff"],
            marker="o", linewidth=1.5, markersize=5,
            label="gate %.2f" % gate,
        )

    ax.scatter(
        [best["diamond"]], [best["mean_abs_log10_diff"]],
        marker="*", s=150, c="#D00000", edgecolors="black", linewidths=0.5,
        zorder=7, label="selected best"
    )

    ax.set_xlabel("DIAMOND threshold")
    ax.set_ylabel("Mean absolute log10 difference vs ARG-OAP")
    ax.set_title("Sensitivity of ARGScope total ARG counts to filtering thresholds",
                 fontweight="bold")
    ax.legend(frameon=False, ncol=2, fontsize=8.5)
    ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.25)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    save_figure(fig, FIGDIR / "Fig5_gate_diamond_parameter_curves")



# =============================================================================
# 11B. ARGScope-CENTERED PUBLICATION FIGURES
# =============================================================================


def _format_count_tick(v):
    try:
        v = float(v)
    except Exception:
        return str(v)
    if v >= 1e6:
        return "%.1fM" % (v / 1e6)
    if v >= 1e3:
        if abs(v / 1e3 - round(v / 1e3)) < 1e-8:
            return "%dk" % int(round(v / 1e3))
        return "%.1fk" % (v / 1e3)
    if v >= 10:
        return "%d" % int(round(v))
    return "%.1f" % v


def _add_row_bands(ax, n_rows):
    for i in range(n_rows):
        if i % 2 == 0:
            ax.axhspan(i - 0.48, i + 0.48, color="#F6F6F6", zorder=0)


def draw_argscope_parameter_landscape(scores, best):
    from matplotlib.colors import LinearSegmentedColormap

    gates = sorted(scores["gate"].unique())
    diamonds = sorted(scores["diamond"].unique())
    matrix = scores.pivot(index="gate", columns="diamond", values="mean_abs_log10_diff")
    matrix = matrix.reindex(index=gates, columns=diamonds)
    values = matrix.to_numpy(dtype=float)
    masked = np.ma.masked_invalid(values)

    cmap = LinearSegmentedColormap.from_list(
        "argscope_calibration",
        ["#B2182B", "#EF8A62", "#F7F7F7", "#D9E5EA", "#86A8B8"]
    )

    fig, ax = plt.subplots(figsize=(9.0, 5.8), dpi=180)
    im = ax.imshow(masked, aspect="auto", cmap=cmap)
    cbar = fig.colorbar(im, ax=ax, fraction=0.042, pad=0.035)
    cbar.set_label("Calibration distance to ARG-OAP\n(mean absolute log10 difference)", fontsize=9.5)

    ax.set_xticks(np.arange(len(diamonds)))
    ax.set_xticklabels(["%.1f" % x for x in diamonds])
    ax.set_yticks(np.arange(len(gates)))
    ax.set_yticklabels(["%.2f" % x for x in gates])
    ax.set_xlabel("DIAMOND threshold")
    ax.set_ylabel("ARGScope gate threshold")
    ax.set_title("ARGScope parameter landscape", fontsize=14, fontweight="bold", pad=12)

    finite = values[np.isfinite(values)]
    mid = np.nanmedian(finite) if finite.size else 0.0
    for i in range(len(gates)):
        for j in range(len(diamonds)):
            v = values[i, j]
            if np.isfinite(v):
                color = "white" if v < mid * 0.75 else "#333333"
                ax.text(j, i, "%.3f" % v, ha="center", va="center", fontsize=8.3,
                        color=color, fontweight="bold" if np.isclose(v, best["mean_abs_log10_diff"]) else "normal")

    bi = gates.index(float(best["gate"]))
    bj = diamonds.index(float(best["diamond"]))
    ax.scatter([bj], [bi], marker="*", s=235, c=MODEL_COLORS["ARGScope"],
               edgecolors="black", linewidths=0.9, zorder=8)
    ax.add_patch(plt.Rectangle((bj - 0.47, bi - 0.47), 0.94, 0.94,
                               fill=False, edgecolor=MODEL_COLORS["ARGScope"], linewidth=2.6))
    ax.text(bj, bi - 0.36, "SELECTED", ha="center", va="center", fontsize=7.3,
            color="white", fontweight="bold")

    ax.set_xticks(np.arange(-0.5, len(diamonds), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(gates), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.0, alpha=0.72)
    ax.tick_params(which="minor", bottom=False, left=False)
    for spine in ax.spines.values():
        spine.set_visible(False)

    fig.text(0.5, 0.018,
             "ARG-OAP is used only for parameter calibration; the selected setting is subsequently evaluated as ARGScope.",
             ha="center", va="bottom", fontsize=8.5, color="#555555")
    fig.subplots_adjust(bottom=0.13)
    save_figure(fig, FIGDIR / "Fig1_ARGScope_parameter_landscape")


def draw_argscope_centered_dumbbell(df, best):
    work = df.copy().reset_index(drop=True)
    n = len(work)
    y = np.arange(n)

    fig, ax = plt.subplots(figsize=(11.4, 6.6), dpi=180)
    _add_row_bands(ax, n)

    a = work["ARGScope"].to_numpy(dtype=float) + 1.0
    o = work["ARG-OAP"].to_numpy(dtype=float) + 1.0
    d = work["DeepARG"].to_numpy(dtype=float) + 1.0

    for i in range(n):
        # Thin connectors originate from ARGScope so the visual center is ARGScope.
        ax.plot([a[i], o[i]], [y[i], y[i]], color=MODEL_COLORS["ARG-OAP"], linewidth=1.2, alpha=0.50, zorder=1)
        ax.plot([a[i], d[i]], [y[i], y[i]], color=MODEL_COLORS["DeepARG"], linewidth=1.2, alpha=0.48, zorder=1)

    ax.scatter(o, y, s=52, marker="o", facecolors="white", edgecolors=MODEL_COLORS["ARG-OAP"],
               linewidths=1.5, label="ARG-OAP", zorder=3)
    ax.scatter(d, y, s=50, marker="s", facecolors="white", edgecolors=MODEL_COLORS["DeepARG"],
               linewidths=1.4, label="DeepARG", zorder=3)
    ax.scatter(a, y, s=105, marker="D", c=MODEL_COLORS["ARGScope"], edgecolors="white",
               linewidths=0.9, label="ARGScope", zorder=6)

    # Only annotate ARGScope values, reinforcing ARGScope as the focal model.
    for xi, yi, raw in zip(a, y, work["ARGScope"].to_numpy(dtype=float)):
        ax.annotate(_format_count_tick(raw), xy=(xi, yi), xytext=(7, 0), textcoords="offset points",
                    ha="left", va="center", fontsize=8.0, color=MODEL_COLORS["ARGScope"], fontweight="bold")

    ax.set_xscale("log")
    ax.set_yticks(y)
    ax.set_yticklabels(work["sample_name"].tolist())
    ax.invert_yaxis()
    ax.set_xlabel("Total ARG count + 1 (log scale)")
    ax.set_ylabel("")
    ax.set_title("ARGScope-centered abundance profile across real metagenomic samples",
                 fontsize=14, fontweight="bold", pad=13)
    ax.text(0.0, 1.015,
            "Selected ARGScope setting: gate=%.2f, DIAMOND=%.2f" % (best["gate"], best["diamond"]),
            transform=ax.transAxes, ha="left", va="bottom", fontsize=9.3, color="#555555")

    # Legend starts with ARGScope even though it was plotted last.
    handles, labels = ax.get_legend_handles_labels()
    order = [labels.index("ARGScope"), labels.index("ARG-OAP"), labels.index("DeepARG")]
    ax.legend([handles[i] for i in order], [labels[i] for i in order],
              frameon=False, ncol=3, loc="upper right", bbox_to_anchor=(1.0, 1.08),
              columnspacing=1.4, handletextpad=0.5)

    ax.grid(axis="x", which="both", linestyle=":", linewidth=0.55, alpha=0.23)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)

    save_figure(fig, FIGDIR / "Fig2_ARGScope_centered_abundance_profile")


def draw_deviation_from_argscope(df):
    work = df.copy().reset_index(drop=True)
    n = len(work)
    y = np.arange(n)

    delta_o = np.log10(work["ARG-OAP"].to_numpy(dtype=float) + 1.0) - np.log10(work["ARGScope"].to_numpy(dtype=float) + 1.0)
    delta_d = np.log10(work["DeepARG"].to_numpy(dtype=float) + 1.0) - np.log10(work["ARGScope"].to_numpy(dtype=float) + 1.0)

    max_abs = max(1.0, float(np.nanmax(np.abs(np.concatenate([delta_o, delta_d])))) * 1.15)

    fig, ax = plt.subplots(figsize=(10.8, 6.4), dpi=180)
    _add_row_bands(ax, n)

    twofold = np.log10(2.0)
    ax.axvspan(-twofold, twofold, color=MODEL_COLORS["ARGScope"], alpha=0.055, zorder=0)
    ax.axvline(0, color=MODEL_COLORS["ARGScope"], linewidth=2.4, zorder=2)
    ax.axvline(-twofold, color="#B8B8B8", linestyle="--", linewidth=0.8, zorder=1)
    ax.axvline(twofold, color="#B8B8B8", linestyle="--", linewidth=0.8, zorder=1)

    for i in range(n):
        ax.plot([0, delta_o[i]], [y[i] - 0.10, y[i] - 0.10], color=MODEL_COLORS["ARG-OAP"], linewidth=1.0, alpha=0.55)
        ax.plot([0, delta_d[i]], [y[i] + 0.10, y[i] + 0.10], color=MODEL_COLORS["DeepARG"], linewidth=1.0, alpha=0.55)

    ax.scatter(delta_o, y - 0.10, s=50, facecolors="white", edgecolors=MODEL_COLORS["ARG-OAP"],
               linewidths=1.5, label="ARG-OAP relative to ARGScope", zorder=4)
    ax.scatter(delta_d, y + 0.10, s=48, marker="s", facecolors="white", edgecolors=MODEL_COLORS["DeepARG"],
               linewidths=1.4, label="DeepARG relative to ARGScope", zorder=4)

    ax.set_yticks(y)
    ax.set_yticklabels(work["sample_name"].tolist())
    ax.invert_yaxis()
    ax.set_xlim(-max_abs, max_abs)
    ax.set_xlabel("log10 fold difference relative to ARGScope")
    ax.set_title("How alternative tools deviate from ARGScope", fontsize=14, fontweight="bold", pad=13)

    # Put interpretable fold labels on the x-axis.
    candidates = np.array([-1.0, -0.699, -0.301, 0.0, 0.301, 0.699, 1.0])
    labels = ["0.1x", "0.2x", "0.5x", "1x", "2x", "5x", "10x"]
    keep = np.abs(candidates) <= max_abs + 1e-9
    ax.set_xticks(candidates[keep])
    ax.set_xticklabels([lab for lab, k in zip(labels, keep) if k])

    ax.text(0, -0.78, "ARGScope", ha="center", va="center", fontsize=9.0,
            color=MODEL_COLORS["ARGScope"], fontweight="bold")
    ax.text(twofold, n - 0.10, "2-fold", ha="left", va="bottom", fontsize=7.6, color="#888888")
    ax.text(-twofold, n - 0.10, "0.5-fold", ha="right", va="bottom", fontsize=7.6, color="#888888")

    med_o = float(np.nanmedian(np.maximum((work["ARG-OAP"].to_numpy(dtype=float) + 1.0) / (work["ARGScope"].to_numpy(dtype=float) + 1.0),
                                      (work["ARGScope"].to_numpy(dtype=float) + 1.0) / (work["ARG-OAP"].to_numpy(dtype=float) + 1.0))))
    med_d = float(np.nanmedian(np.maximum((work["DeepARG"].to_numpy(dtype=float) + 1.0) / (work["ARGScope"].to_numpy(dtype=float) + 1.0),
                                      (work["ARGScope"].to_numpy(dtype=float) + 1.0) / (work["DeepARG"].to_numpy(dtype=float) + 1.0))))
    ax.text(0.985, 0.025,
            "Median symmetric fold difference\nARG-OAP: %.2fx   DeepARG: %.2fx" % (med_o, med_d),
            transform=ax.transAxes, ha="right", va="bottom", fontsize=8.1, color="#555555",
            bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor="#DDDDDD", alpha=0.93))

    ax.legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.04), fontsize=8.8)
    ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.20)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)

    save_figure(fig, FIGDIR / "Fig3_deviation_relative_to_ARGScope")


def _argscope_consistency_panel(ax, x_argscope, y_comp, sample_names, comp_name, comp_color):
    x = np.asarray(x_argscope, dtype=float) + 1.0
    y = np.asarray(y_comp, dtype=float) + 1.0
    low = max(0.8, min(np.nanmin(x), np.nanmin(y)) * 0.70)
    high = max(np.nanmax(x), np.nanmax(y)) * 1.42

    xx = np.logspace(np.log10(low), np.log10(high), 200)
    ax.fill_between(xx, xx / 2.0, xx * 2.0, color=MODEL_COLORS["ARGScope"], alpha=0.055, zorder=0)
    ax.plot(xx, xx, color=MODEL_COLORS["ARGScope"], linewidth=1.9, zorder=1, label="1:1 with ARGScope")
    ax.plot(xx, xx / 2.0, color="#BBBBBB", linestyle="--", linewidth=0.75, zorder=1)
    ax.plot(xx, xx * 2.0, color="#BBBBBB", linestyle="--", linewidth=0.75, zorder=1)

    ax.scatter(x, y, s=58, facecolors=comp_color, edgecolors="white", linewidths=0.7, alpha=0.88, zorder=4)
    for xi, yi, s in zip(x, y, sample_names):
        ax.annotate(str(s), (xi, yi), xytext=(4, 4), textcoords="offset points",
                    fontsize=7.1, color="#555555")

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(low, high)
    ax.set_ylim(low, high)
    ax.set_xlabel("ARGScope count + 1")
    ax.set_ylabel("%s count + 1" % comp_name)
    ax.set_title("%s relative to ARGScope" % comp_name, fontweight="bold", fontsize=11.8)
    ax.grid(True, which="both", linestyle=":", linewidth=0.43, alpha=0.18)

    lx = np.log10(x)
    ly = np.log10(y)
    spearman = pd.Series(lx).corr(pd.Series(ly), method="spearman")
    fold = np.maximum(y / x, x / y)
    med_fold = float(np.nanmedian(fold))
    within2 = float(np.mean(fold <= 2.0) * 100.0)
    ax.text(0.04, 0.96,
            "Spearman rho = %.3f\nMedian fold diff = %.2fx\nWithin 2-fold = %.0f%%" % (spearman, med_fold, within2),
            transform=ax.transAxes, ha="left", va="top", fontsize=8.2,
            bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor="#DDDDDD", alpha=0.92))


def draw_argscope_consistency(df):
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 5.3), dpi=180)
    _argscope_consistency_panel(axes[0], df["ARGScope"], df["ARG-OAP"], df["sample_name"],
                                "ARG-OAP", MODEL_COLORS["ARG-OAP"])
    _argscope_consistency_panel(axes[1], df["ARGScope"], df["DeepARG"], df["sample_name"],
                                "DeepARG", MODEL_COLORS["DeepARG"])
    fig.suptitle("Cross-tool consistency anchored on ARGScope", fontsize=14, fontweight="bold", y=1.01)
    fig.tight_layout()
    save_figure(fig, FIGDIR / "Fig4_cross_tool_consistency_anchored_on_ARGScope")


def draw_argscope_robustness(scores, best):
    fig, ax = plt.subplots(figsize=(9.0, 5.7), dpi=180)
    best_gate = float(best["gate"])

    for gate in sorted(scores["gate"].unique()):
        sub = scores[np.isclose(scores["gate"], gate)].sort_values("diamond")
        if np.isclose(gate, best_gate):
            ax.plot(sub["diamond"], sub["mean_abs_log10_diff"], marker="o",
                    linewidth=2.7, markersize=6.3, color=MODEL_COLORS["ARGScope"],
                    label="Selected ARGScope gate %.2f" % gate, zorder=5)
        else:
            ax.plot(sub["diamond"], sub["mean_abs_log10_diff"], marker="o",
                    linewidth=1.0, markersize=4.0, color="#C9C9C9", alpha=0.85,
                    label=None, zorder=2)

    ax.scatter([best["diamond"]], [best["mean_abs_log10_diff"]], marker="*", s=180,
               c=MODEL_COLORS["ARGScope"], edgecolors="black", linewidths=0.7,
               zorder=7, label="Selected ARGScope setting")
    ax.axvline(float(best["diamond"]), color=MODEL_COLORS["ARGScope"], linestyle="--",
               linewidth=0.9, alpha=0.45)

    ax.set_xlabel("DIAMOND threshold")
    ax.set_ylabel("Calibration distance to ARG-OAP")
    ax.set_title("ARGScope robustness across filtering thresholds", fontsize=14, fontweight="bold", pad=12)
    ax.legend(frameon=False, loc="best", fontsize=8.8)
    ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.22)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    save_figure(fig, FIGDIR / "Fig5_ARGScope_filtering_robustness")

# =============================================================================
# 12. MAIN
# =============================================================================


def main():
    print("=" * 92)
    print("ARGScope vs ARG-OAP vs DeepARG: real-data total ARG count comparison")
    print("=" * 92)
    print("ROOT_DIR      :", ROOT_DIR)
    print("REFERENCE_FILE:", REFERENCE_FILE)
    print("OUTPUT_DIR    :", OUTDIR)

    argscope_long = read_all_argscope_results()
    sample_names = sorted(argscope_long["sample_name"].dropna().unique(), key=natural_sample_key)

    print("\nARGScope samples (%d):" % len(sample_names))
    for x in sample_names:
        print("  ", x)

    ref = read_reference_counts(sample_names)
    scores, best = evaluate_parameter_grid(argscope_long, ref)

    draw_argscope_parameter_landscape(scores, best)

    best_df = prepare_best_comparison(argscope_long, ref, best)
    draw_argscope_centered_dumbbell(best_df, best)
    draw_deviation_from_argscope(best_df)
    draw_argscope_consistency(best_df)
    draw_argscope_robustness(scores, best)

    # Compact best-setting summary.
    summary = pd.DataFrame([{
        "selected_gate": best["gate"],
        "selected_diamond": best["diamond"],
        "mean_abs_log10_diff_vs_ARGOAP": best["mean_abs_log10_diff"],
        "rmse_log10_vs_ARGOAP": best["rmse_log10"],
        "pearson_log10_vs_ARGOAP": best["pearson_log10"],
        "spearman_log10_vs_ARGOAP": best["spearman_log10"],
        "median_symmetric_fold_error": best["median_symmetric_fold_error"],
        "n_common_samples": best["n_common_samples"],
    }])
    summary.to_csv(
        TABLEDIR / "SELECTED_best_ARGScope_setting_summary.csv",
        index=False, encoding="utf-8-sig", float_format="%.6f"
    )

    print("\n" + "=" * 92)
    print("DONE")
    print("=" * 92)
    print("Selected ARGScope setting: gate=%.2f, DIAMOND=%.2f" % (
        best["gate"], best["diamond"]
    ))
    print("Figures:", FIGDIR)
    print("Tables :", TABLEDIR)
    print("\nMain outputs:")
    print("  Fig1_ARGScope_parameter_landscape.png")
    print("  Fig2_ARGScope_centered_abundance_profile.png")
    print("  Fig3_deviation_relative_to_ARGScope.png")
    print("  Fig4_cross_tool_consistency_anchored_on_ARGScope.png")
    print("  Fig5_ARGScope_filtering_robustness.png")
    print("  SELECTED_best_ARGScope_setting_summary.csv")


if __name__ == "__main__":
    main()
