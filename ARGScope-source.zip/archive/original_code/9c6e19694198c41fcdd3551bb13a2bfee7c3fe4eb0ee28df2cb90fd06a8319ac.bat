@echo off
setlocal
set "ARGFIG_PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%ARGFIG_PY%" (
  echo Python not found. Edit ARGFIG_PY in this launcher.
  pause
  exit /b 1
)
"%ARGFIG_PY%" -X utf8 -B -u "%~dp0analyze_fragment_results.py"
if errorlevel 1 goto failed
"%ARGFIG_PY%" -X utf8 -B -u "%~dp0plot_fragment_figure.py"
if errorlevel 1 goto failed
echo Completed. See figures in this folder.
pause
exit /b 0
:failed
echo Failed. Review the error above. Source results were not changed.
pause
exit /b 1
