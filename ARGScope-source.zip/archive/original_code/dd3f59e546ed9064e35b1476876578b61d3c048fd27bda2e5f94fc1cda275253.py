import pandas as pd


# ==========================================================
# 1. 输入输出文件
# ==========================================================

INPUT_FILE = "protein_ID_type_subtype.csv"

OUTPUT_CLEAN_FILE = "protein_ID_列表.csv"
OUTPUT_REMOVED_SAME_FILE = "protein_ID_type_subtype_removed_same_type_subtype.csv"
OUTPUT_REMOVED_BAD_FILE = "protein_ID_type_subtype_removed_bad_subtype.csv"
OUTPUT_INTERMEDIATE_FILE = "protein_ID_type_subtype_type_not_equal_subtype.csv"


# ==========================================================
# 2. 基础函数
# ==========================================================

def clean_text(x):
    if pd.isna(x):
        return ""

    x = str(x).strip()
    x = x.replace("\n", " ")
    x = x.replace("\r", " ")
    x = " ".join(x.split())

    return x


def is_bad_subtype(x):
    """
    判断是否是不适合作为 BGC subtype 的 gene-level 注释。
    """
    s = clean_text(x).lower()

    if s == "":
        return True

    bad_exact = {
        "unknown",
        "none",
        "nan",
        "other",
        "hypothetical protein",
        "putative protein",
        "uncharacterized protein"
    }

    if s in bad_exact:
        return True

    bad_keywords = [
        "similar to",
        "homolog",
        "regulatory protein",
        "transcriptional regulator",
        "amino acid",
        "transport",
        "transporter",
        "permease",
        "dehydrogenase",
        "oxidoreductase",
        "methyltransferase",
        "transferase",
        "synthetase",
        "ligase",
        "kinase",
        "reductase",
        "hydrolase",
        "thioesterase",
        "domain-containing protein",
        "family protein",
        "binding protein",
        "membrane protein",
        "secreted protein"
    ]

    for k in bad_keywords:
        if k in s:
            return True

    # 太长的一般不是 subtype，而是说明性注释
    if len(s) > 60:
        return True

    return False


def normalize_known_subtype(x):
    """
    把常见 BGC subtype 统一成规范写法。
    """
    s = clean_text(x)
    sl = s.lower()

    # PKS
    if "trans-at" in sl or "transat" in sl or "trans at" in sl:
        return "transAT-PKS"

    if "t1pks" in sl or "t1-pks" in sl or "type i pks" in sl or "type 1 pks" in sl or "type-i pks" in sl:
        return "T1PKS"

    if "t2pks" in sl or "t2-pks" in sl or "type ii pks" in sl or "type 2 pks" in sl or "type-ii pks" in sl:
        return "T2PKS"

    if "t3pks" in sl or "t3-pks" in sl or "type iii pks" in sl or "type 3 pks" in sl or "type-iii pks" in sl:
        return "T3PKS"

    if "pks-like" in sl or "pks like" in sl or "pkslike" in sl:
        return "PKS-like"

    if "hgle-ks" in sl or "hgle ks" in sl:
        return "hglE-KS"

    if "pufa" in sl:
        return "PUFA"

    # NRPS
    if "nrps-like" in sl or "nrps like" in sl:
        return "NRPS-like"

    if "siderophore" in sl:
        return "siderophore"

    if "lipopeptide" in sl:
        return "lipopeptide"

    if "depsipeptide" in sl:
        return "depsipeptide"

    if "glycopeptide" in sl:
        return "glycopeptide"

    # RiPP
    if "lanthipeptide" in sl:
        return "lanthipeptide"

    if "lasso" in sl:
        return "lasso peptide"

    if "thiopeptide" in sl:
        return "thiopeptide"

    if "cyanobactin" in sl:
        return "cyanobactin"

    if "sactipeptide" in sl:
        return "sactipeptide"

    if "bottromycin" in sl:
        return "bottromycin"

    if "glycocin" in sl:
        return "glycocin"

    if "microviridin" in sl:
        return "microviridin"

    if "proteusin" in sl:
        return "proteusin"

    if "ranthipeptide" in sl:
        return "ranthipeptide"

    # Terpene
    if "carotenoid" in sl:
        return "carotenoid"

    if "hopene" in sl:
        return "hopene"

    if "meroterpenoid" in sl:
        return "meroterpenoid"

    if "terpene" in sl or "terpenoid" in sl:
        return "terpene"

    # Saccharide
    if "aminoglycoside" in sl:
        return "aminoglycoside"

    if "oligosaccharide" in sl:
        return "oligosaccharide"

    if "polysaccharide" in sl:
        return "polysaccharide"

    if "glycoside" in sl:
        return "glycoside"

    # Other common BGC classes
    other_terms = [
        "arylpolyene",
        "aryl polyene",
        "bacteriocin",
        "beta-lactone",
        "butyrolactone",
        "ectoine",
        "hserlactone",
        "nucleoside",
        "phosphonate",
        "phenazine",
        "resorcinol",
        "ladderane",
        "melanin",
        "fatty acid",
        "aminocoumarin",
        "phosphoglycolipid"
    ]

    for term in other_terms:
        if term in sl:
            return term.replace(" ", "-")

    return s


def choose_single_subtype(type_value, subtype_value):
    """
    从多个 subtype 候选中选择一个最合理的 BGC subtype。
    """
    type_value = clean_text(type_value)
    subtype_value = clean_text(subtype_value)

    if subtype_value == "":
        return ""

    # 用 ; 分割多个候选
    parts = [clean_text(x) for x in subtype_value.split(";")]
    parts = [x for x in parts if x != ""]

    if len(parts) == 0:
        return ""

    # 规范化每个候选
    norm_parts = [normalize_known_subtype(x) for x in parts]

    # 去重
    norm_parts_unique = []
    for x in norm_parts:
        if x not in norm_parts_unique:
            norm_parts_unique.append(x)

    # 过滤掉 gene-level 注释
    good_parts = [x for x in norm_parts_unique if not is_bad_subtype(x)]

    if len(good_parts) == 0:
        return ""

    # 优先选择更具体的 BGC subtype
    priority = [
        "transAT-PKS",
        "T1PKS",
        "T2PKS",
        "T3PKS",
        "PKS-like",
        "hglE-KS",
        "PUFA",

        "NRPS-like",
        "siderophore",
        "lipopeptide",
        "depsipeptide",
        "glycopeptide",

        "lanthipeptide",
        "lasso peptide",
        "thiopeptide",
        "cyanobactin",
        "sactipeptide",
        "bottromycin",
        "glycocin",
        "microviridin",
        "proteusin",
        "ranthipeptide",

        "carotenoid",
        "hopene",
        "meroterpenoid",
        "terpene",

        "aminoglycoside",
        "oligosaccharide",
        "polysaccharide",
        "glycoside",

        "arylpolyene",
        "bacteriocin",
        "beta-lactone",
        "butyrolactone",
        "ectoine",
        "hserlactone",
        "nucleoside",
        "phosphonate",
        "phenazine",
        "resorcinol",
        "ladderane",
        "melanin",
        "fatty-acid",
        "aminocoumarin",
        "phosphoglycolipid"
    ]

    for p in priority:
        if p in good_parts:
            return p

    # 否则返回第一个合格候选
    return good_parts[0]


# ==========================================================
# 3. 读取数据
# ==========================================================

df = pd.read_csv(INPUT_FILE)

required_cols = ["id", "type", "Subtype"]

for col in required_cols:
    if col not in df.columns:
        raise ValueError("输入文件缺少列: {}".format(col))

df["id"] = df["id"].astype(str).str.strip()
df["type"] = df["type"].astype(str).str.strip()
df["Subtype"] = df["Subtype"].astype(str).str.strip()

original_n = len(df)


# ==========================================================
# 4. 第一步：删除 type == Subtype
# ==========================================================

same_mask = df["type"].str.lower() == df["Subtype"].str.lower()

removed_same_df = df[same_mask].copy()
not_same_df = df[~same_mask].copy()

removed_same_df = removed_same_df[["id", "type", "Subtype"]]
not_same_df = not_same_df[["id", "type", "Subtype"]]

removed_same_df.to_csv(
    OUTPUT_REMOVED_SAME_FILE,
    index=False,
    encoding="utf-8-sig"
)

not_same_df.to_csv(
    OUTPUT_INTERMEDIATE_FILE,
    index=False,
    encoding="utf-8-sig"
)


# ==========================================================
# 5. 第二步：清洗多个 subtype 候选，只保留一个
# ==========================================================

not_same_df["Original_Subtype"] = not_same_df["Subtype"]

not_same_df["Subtype"] = not_same_df.apply(
    lambda row: choose_single_subtype(row["type"], row["Subtype"]),
    axis=1
)

bad_mask = (
    (not_same_df["Subtype"].astype(str).str.strip() == "")
    | (not_same_df["Subtype"].astype(str).str.lower().isin(["unknown", "other", "none", "nan"]))
    | (not_same_df["type"].astype(str).str.lower() == not_same_df["Subtype"].astype(str).str.lower())
)

removed_bad_df = not_same_df[bad_mask].copy()
clean_df = not_same_df[~bad_mask].copy()


# ==========================================================
# 6. 输出最终文件
# ==========================================================

clean_df = clean_df[["id", "type", "Subtype"]]
removed_bad_df = removed_bad_df[["id", "type", "Original_Subtype", "Subtype"]]

clean_df.to_csv(
    OUTPUT_CLEAN_FILE,
    index=False,
    encoding="utf-8-sig"
)

removed_bad_df.to_csv(
    OUTPUT_REMOVED_BAD_FILE,
    index=False,
    encoding="utf-8-sig"
)


# ==========================================================
# 7. 打印统计
# ==========================================================

print("=" * 60)
print("清洗完成")
print("=" * 60)

print("原始样本数:", original_n)
print("第一步删除 type == Subtype 的样本数:", len(removed_same_df))
print("第一步保留 type != Subtype 的样本数:", len(not_same_df))
print("第二步删除 bad/multiple/gene-level subtype 的样本数:", len(removed_bad_df))
print("最终保留样本数:", len(clean_df))

print("\n输出最终清洗文件:", OUTPUT_CLEAN_FILE)
print("输出第一步中间文件:", OUTPUT_INTERMEDIATE_FILE)
print("输出删除 type == Subtype 文件:", OUTPUT_REMOVED_SAME_FILE)
print("输出删除 bad subtype 文件:", OUTPUT_REMOVED_BAD_FILE)

print("\n最终 type 分布:")
print(clean_df["type"].value_counts())

print("\n最终 Subtype 前 30:")
print(clean_df["Subtype"].value_counts().head(30))

print("\n检查 type == Subtype 剩余数量:")
remain_same = (
    clean_df["type"].astype(str).str.lower()
    == clean_df["Subtype"].astype(str).str.lower()
).sum()
print(remain_same)

print("\n检查 Subtype 中仍含 ';' 的数量:")
remain_multi = clean_df["Subtype"].astype(str).str.contains(";", regex=False).sum()
print(remain_multi)