"""Read-only exact sequence overlap audit; never changes the authoritative split."""
from pathlib import Path
from collections import defaultdict,Counter
import csv
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT.parent/"BGC_novel dataset"


def sequences(path):
    name=None
    blocks=[]
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            text=line.strip()
            if text.startswith(">"):
                if name is not None:
                    yield name,"".join(blocks).upper()
                name=text[1:].split()[0]
                blocks=[]
            elif text:
                blocks.append(text)
    if name is not None:
        yield name,"".join(blocks).upper()


def main():
    with (ROOT/"Dataset/normalized_BGC_nonBGC_labels_and_fixed_splits.csv").open(encoding="utf-8-sig",newline="") as handle:
        labels={r["id"]:r for r in csv.DictReader(handle)}
    summaries={}
    duplicate_rows=[]
    for modality,filename in (("protein","corrected_BGC_nonBGC_protein.fasta"),("DNA","corrected_BGC_nonBGC_dna.fasta")):
        hashes=defaultdict(list)
        found=set()
        for name,seq in sequences(SOURCE/"BGC_corrected_files"/filename):
            assert name in labels and name not in found
            found.add(name)
            hashes[hashlib.sha256(seq.encode("ascii")).hexdigest()].append(name)
        assert found==set(labels)
        cross_split=[ids for ids in hashes.values() if len({labels[x]["model_split"] for x in ids})>1]
        contradictions=[ids for ids in hashes.values() if len({labels[x]["source"] for x in ids})>1]
        train_hashes={digest for digest,ids in hashes.items() if any(labels[x]["model_split"]=="train" for x in ids)}
        test_duplicates=[x for digest,ids in hashes.items() if digest in train_hashes for x in ids if labels[x]["model_split"]=="test"]
        summaries[modality]={"records":len(found),"distinct_sequences":len(hashes),"duplicate_sequence_groups":sum(len(x)>1 for x in hashes.values()),
                             "cross_split_exact_sequence_groups":len(cross_split),"test_records_identical_to_a_train_sequence":len(test_duplicates),
                             "binary_label_conflicting_sequence_groups":len(contradictions),
                             "binary_label_conflicting_records":sum(map(len,contradictions)),
                             "test_records_identical_to_train_by_source":dict(Counter(labels[x]["source"] for x in test_duplicates))}
        for digest,ids in hashes.items():
            if len({labels[x]["model_split"] for x in ids})>1 or len({labels[x]["source"] for x in ids})>1:
                for x in ids:
                    duplicate_rows.append({"modality":modality,"sequence_sha256":digest,"id":x,"model_split":labels[x]["model_split"],
                                           "source":labels[x]["source"],"group_id":labels[x]["group_id"],"type":labels[x]["type"]})
    folder=ROOT/"Results"
    folder.mkdir(exist_ok=True)
    if duplicate_rows:
        with (folder/"exact_sequence_overlap_records.csv").open("w",encoding="utf-8-sig",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=list(duplicate_rows[0]))
            writer.writeheader()
            writer.writerows(duplicate_rows)
    (folder/"exact_sequence_overlap_audit.json").write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(summaries,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
