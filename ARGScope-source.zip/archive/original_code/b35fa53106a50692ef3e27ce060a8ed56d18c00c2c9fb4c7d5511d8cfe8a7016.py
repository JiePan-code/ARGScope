import random
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score, accuracy_score, matthews_corrcoef

from torch_geometric.data import Data
from torch_geometric.nn import GATConv
from torch_geometric.utils import to_undirected, add_self_loops


# ==========================================================
# 1. Config
# ==========================================================

SEED = 42

PROTO_FILE = "1.all_subtype_prototypes_512.csv"
EDGE_FILE = "2.all_subtype_graph_edges.csv"
OUT_FILE = "3.all_Refined_embeddings_512.csv"

# 轻量 GAT 参数：比原始 GAT 快，比 SAGE 更保留图注意力信息
HIDDEN_DIM = 256
HEADS_1 = 2
DROPOUT = 0.15

LR = 5e-4
WEIGHT_DECAY = 5e-5

MAX_EPOCHS = 180
PATIENCE = 20
EVAL_EVERY = 10

TRAIN_RATIO = 0.70
VAL_RATIO = 0.10
TEST_RATIO = 0.20

# 关键：限制 GAT 对原始 prototype 的修改幅度
RESIDUAL_REG_WEIGHT = 0.30
GATE_INIT = 0.10
GATE_MIN = 0.02
GATE_MAX = 0.25

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# ==========================================================
# 2. Reproducibility
# ==========================================================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    if hasattr(torch, "set_float32_matmul_precision"):
        torch.set_float32_matmul_precision("high")


seed_everything(SEED)


# ==========================================================
# 3. Split function
# ==========================================================

def split_by_type_train_val_test_keep_all(
    y,
    train_ratio=0.70,
    val_ratio=0.10,
    test_ratio=0.20,
    seed=42
):
    """
    按 Type 分层划分 train/val/test。
    小类别优先保证 train。
    """
    rng = np.random.default_rng(seed)
    y = np.asarray(y)

    idx_train = []
    idx_val = []
    idx_test = []

    for c in np.unique(y):
        idx_c = np.where(y == c)[0]
        rng.shuffle(idx_c)

        n = len(idx_c)

        if n == 1:
            idx_train.extend(idx_c.tolist())
            continue

        if n == 2:
            idx_train.extend(idx_c[:1].tolist())
            idx_test.extend(idx_c[1:].tolist())
            continue

        n_test = max(1, int(round(n * test_ratio)))
        n_val = max(1, int(round(n * val_ratio)))

        if n_test + n_val >= n:
            n_test = 1
            n_val = 1

        test_part = idx_c[:n_test]
        val_part = idx_c[n_test:n_test + n_val]
        train_part = idx_c[n_test + n_val:]

        if len(train_part) == 0:
            train_part = idx_c[-1:]
            val_part = idx_c[n_test:-1]

        idx_test.extend(test_part.tolist())
        idx_val.extend(val_part.tolist())
        idx_train.extend(train_part.tolist())

    rng.shuffle(idx_train)
    rng.shuffle(idx_val)
    rng.shuffle(idx_test)

    return (
        np.array(idx_train, dtype=np.int64),
        np.array(idx_val, dtype=np.int64),
        np.array(idx_test, dtype=np.int64)
    )


# ==========================================================
# 4. Load prototypes
# ==========================================================

print("Using device:", DEVICE)

if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
    print("CUDA:", torch.version.cuda)

proto_df = pd.read_csv(PROTO_FILE)

for col in ["Subtype", "Type"]:
    if col not in proto_df.columns:
        raise RuntimeError("{} missing column: {}".format(PROTO_FILE, col))

g_cols = [c for c in proto_df.columns if str(c).startswith("g")]
digit_cols = [c for c in proto_df.columns if str(c).isdigit()]

if len(g_cols) > 0:
    feat_cols = g_cols
elif len(digit_cols) > 0:
    feat_cols = digit_cols
else:
    num_cols = proto_df.select_dtypes(include=[np.number]).columns.tolist()
    feat_cols = [c for c in num_cols if c not in ["Count"]]

X = (
    proto_df[feat_cols]
    .apply(pd.to_numeric, errors="coerce")
    .replace([np.inf, -np.inf], np.nan)
    .fillna(0.0)
    .values
    .astype(np.float32)
)

# L2 normalize 原始 prototype
X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)

type_le = LabelEncoder()
y = type_le.fit_transform(proto_df["Type"].astype(str).values).astype(np.int64)

num_nodes = X.shape[0]
num_classes = len(type_le.classes_)

print("Nodes (subtypes):", num_nodes)
print("Type classes:", num_classes)
print("Feature dim:", X.shape[1])


# ==========================================================
# 5. Load edges
# ==========================================================

edge_df = pd.read_csv(EDGE_FILE)

if not {"source", "target"}.issubset(set(edge_df.columns)):
    raise RuntimeError("{} must have columns: source,target".format(EDGE_FILE))

src = edge_df["source"].to_numpy(np.int64)
dst = edge_df["target"].to_numpy(np.int64)

if src.max() >= num_nodes or dst.max() >= num_nodes or src.min() < 0 or dst.min() < 0:
    raise RuntimeError("Edge node id out of range. Ensure edges align to prototype node_id order.")

edge_index = torch.tensor(np.vstack([src, dst]), dtype=torch.long)

# 转无向图 + self-loop
edge_index = to_undirected(edge_index, num_nodes=num_nodes)
edge_index, _ = add_self_loops(edge_index, num_nodes=num_nodes)

print("Edges after undirected + self-loop:", edge_index.size(1))


# ==========================================================
# 6. Train/Val/Test split
# ==========================================================

idx_train, idx_val, idx_test = split_by_type_train_val_test_keep_all(
    y,
    train_ratio=TRAIN_RATIO,
    val_ratio=VAL_RATIO,
    test_ratio=TEST_RATIO,
    seed=SEED
)

train_mask = torch.zeros(num_nodes, dtype=torch.bool)
val_mask = torch.zeros(num_nodes, dtype=torch.bool)
test_mask = torch.zeros(num_nodes, dtype=torch.bool)

train_mask[idx_train] = True
val_mask[idx_val] = True
test_mask[idx_test] = True

print(
    "Split nodes train/val/test:",
    train_mask.sum().item(),
    val_mask.sum().item(),
    test_mask.sum().item()
)


# ==========================================================
# 7. Build PyG data
# ==========================================================

data = Data(
    x=torch.tensor(X, dtype=torch.float32),
    edge_index=edge_index,
    y=torch.tensor(y, dtype=torch.long),
    train_mask=train_mask,
    val_mask=val_mask,
    test_mask=test_mask
).to(DEVICE)

train_counts = torch.bincount(data.y[data.train_mask], minlength=num_classes).float()
class_weight = train_counts.sum() / (num_classes * (train_counts + 1e-6))
class_weight = class_weight / class_weight.mean()
class_weight = torch.clamp(class_weight, 0.6, 2.5).to(DEVICE)


# ==========================================================
# 8. Residual GAT model
# ==========================================================

class GATResidualRefiner(torch.nn.Module):
    """
    轻量残差 GAT：
    refined embedding = (1 - alpha) * raw prototype + alpha * GAT embedding

    这样可以利用图结构，但不会让 GNN 过度平滑 subtype prototype。
    """

    def __init__(
        self,
        in_dim,
        hid_dim,
        out_dim,
        emb_dim=512,
        heads=2,
        dropout=0.15,
        gate_init=0.10
    ):
        super().__init__()

        self.dropout = dropout

        self.gat1 = GATConv(
            in_channels=in_dim,
            out_channels=hid_dim,
            heads=heads,
            concat=True,
            dropout=dropout,
            add_self_loops=False
        )

        self.norm1 = torch.nn.LayerNorm(hid_dim * heads)

        self.gat2 = GATConv(
            in_channels=hid_dim * heads,
            out_channels=emb_dim,
            heads=1,
            concat=False,
            dropout=dropout,
            add_self_loops=False
        )

        self.norm2 = torch.nn.LayerNorm(emb_dim)

        if in_dim == emb_dim:
            self.res_proj = torch.nn.Identity()
        else:
            self.res_proj = torch.nn.Linear(in_dim, emb_dim)

        self.gate = torch.nn.Parameter(torch.tensor(float(gate_init)))
        self.cls = torch.nn.Linear(emb_dim, out_dim)

    def forward(self, x, edge_index):
        h = F.dropout(x, p=self.dropout, training=self.training)

        h = self.gat1(h, edge_index)
        h = self.norm1(h)
        h = F.elu(h)

        h = F.dropout(h, p=self.dropout, training=self.training)

        gat_emb = self.gat2(h, edge_index)
        gat_emb = self.norm2(gat_emb)

        raw_emb = self.res_proj(x)

        alpha = torch.clamp(self.gate, GATE_MIN, GATE_MAX)

        emb = (1.0 - alpha) * raw_emb + alpha * gat_emb
        emb = F.normalize(emb, p=2, dim=1)

        logits = self.cls(emb)

        return logits, emb, alpha


model = GATResidualRefiner(
    in_dim=data.x.size(1),
    hid_dim=HIDDEN_DIM,
    out_dim=num_classes,
    emb_dim=512,
    heads=HEADS_1,
    dropout=DROPOUT,
    gate_init=GATE_INIT
).to(DEVICE)

opt = torch.optim.AdamW(
    model.parameters(),
    lr=LR,
    weight_decay=WEIGHT_DECAY
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    opt,
    mode="max",
    factor=0.5,
    patience=5
)

scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)


# ==========================================================
# 9. Evaluation
# ==========================================================

def evaluate(mask):
    model.eval()

    with torch.no_grad():
        with torch.amp.autocast("cuda", enabled=USE_AMP):
            logits, _, alpha = model(data.x, data.edge_index)

        pred = logits.argmax(dim=1)

    yt = data.y[mask].detach().cpu().numpy()
    pt = pred[mask].detach().cpu().numpy()

    acc = accuracy_score(yt, pt)
    macro_f1 = f1_score(yt, pt, average="macro", zero_division=0)
    weighted_f1 = f1_score(yt, pt, average="weighted", zero_division=0)
    mcc = matthews_corrcoef(yt, pt)

    return acc, macro_f1, weighted_f1, mcc, float(alpha.detach().cpu())


# ==========================================================
# 10. Train loop
# ==========================================================

best_val = -1.0
best_state = None
no_improve = 0

print("Start training...")

for epoch in range(1, MAX_EPOCHS + 1):
    model.train()
    opt.zero_grad(set_to_none=True)

    with torch.amp.autocast("cuda", enabled=USE_AMP):
        logits, emb, alpha = model(data.x, data.edge_index)

        loss_ce = F.cross_entropy(
            logits[data.train_mask],
            data.y[data.train_mask],
            weight=class_weight,
            label_smoothing=0.02
        )

        # 强残差正则：保证 refined embedding 不明显偏离原始 prototype
        raw_x = F.normalize(data.x[data.train_mask], p=2, dim=1)
        refined_x = F.normalize(emb[data.train_mask], p=2, dim=1)

        loss_reg = F.mse_loss(refined_x, raw_x)

        loss = loss_ce + RESIDUAL_REG_WEIGHT * loss_reg

    scaler_amp.scale(loss).backward()
    scaler_amp.unscale_(opt)

    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

    scaler_amp.step(opt)
    scaler_amp.update()

    if epoch == 1 or epoch % EVAL_EVERY == 0:
        val_acc, val_macro_f1, val_weighted_f1, val_mcc, alpha_val = evaluate(data.val_mask)

        # 仍以 macro-F1 为主，但 weighted-F1 也参与，避免只优化少数类
        val_score = 0.65 * val_macro_f1 + 0.35 * val_weighted_f1

        scheduler.step(val_score)

        lr_now = opt.param_groups[0]["lr"]

        print(
            "Epoch {:03d} | LR {:.2e} | Loss {:.4f} | Alpha {:.4f} | "
            "VAL ACC {:.4f} | VAL macro-F1 {:.4f} | VAL weighted-F1 {:.4f} | VAL MCC {:.4f}".format(
                epoch,
                lr_now,
                loss.item(),
                alpha_val,
                val_acc,
                val_macro_f1,
                val_weighted_f1,
                val_mcc
            )
        )

        if val_score > best_val + 1e-6:
            best_val = val_score
            best_state = {
                k: v.detach().cpu().clone()
                for k, v in model.state_dict().items()
            }
            no_improve = 0
        else:
            no_improve += 1

        if no_improve >= PATIENCE:
            print("Early stopping at epoch {}, best VAL score={:.4f}".format(epoch, best_val))
            break


# ==========================================================
# 11. Load best model and test
# ==========================================================

if best_state is not None:
    model.load_state_dict(best_state)

model = model.to(DEVICE)
model.eval()

test_acc, test_macro_f1, test_weighted_f1, test_mcc, alpha_test = evaluate(data.test_mask)

print(
    "FINAL TEST ACC {:.4f} | FINAL TEST macro-F1 {:.4f} | "
    "FINAL TEST weighted-F1 {:.4f} | FINAL TEST MCC {:.4f} | Alpha {:.4f}".format(
        test_acc,
        test_macro_f1,
        test_weighted_f1,
        test_mcc,
        alpha_test
    )
)


# ==========================================================
# 12. Export refined embeddings
# ==========================================================

print("Exporting refined embeddings...")

with torch.no_grad():
    with torch.amp.autocast("cuda", enabled=USE_AMP):
        logits, emb, alpha = model(data.x, data.edge_index)

emb_np = emb.detach().float().cpu().numpy().astype(np.float32)

out_meta = proto_df[["Subtype", "Type"]].copy()

if "Count" in proto_df.columns:
    out_meta["Count"] = proto_df["Count"].values
else:
    out_meta["Count"] = np.nan

emb_cols = ["g{}".format(j) for j in range(emb_np.shape[1])]
emb_df = pd.DataFrame(emb_np, columns=emb_cols)

out_df = pd.concat(
    [
        out_meta.reset_index(drop=True),
        emb_df.reset_index(drop=True)
    ],
    axis=1
)

out_df.to_csv(
    OUT_FILE,
    index=False,
    encoding="utf-8-sig"
)

print("Saved:", OUT_FILE)
print("Output shape:", out_df.shape)
print("Final alpha:", float(alpha.detach().cpu()))