param([Parameter(Mandatory=$true)][string]$DocumentPath,[Parameter(Mandatory=$true)][string]$PdfPath)
$ErrorActionPreference='Stop'
$taskWord=$null
$taskDocument=$null
try {
    $taskWord=New-Object -ComObject Word.Application
    $taskWord.Visible=$false
    $taskWord.DisplayAlerts=0
    $taskWord.AutomationSecurity=3
    $taskDocument=$taskWord.Documents.Open($DocumentPath,$false,$true,$false)
    $taskDocument.Repaginate()
    $taskDocument.ExportAsFixedFormat($PdfPath,17)
    Write-Output ('Exported PDF: '+$PdfPath)
} finally {
    if ($null -ne $taskDocument) { $taskDocument.Close(0) }
    if ($null -ne $taskWord) { $taskWord.Quit() }
}
