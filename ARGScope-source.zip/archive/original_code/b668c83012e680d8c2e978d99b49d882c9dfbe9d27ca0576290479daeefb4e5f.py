"""Regression checks for ARG-only reporting; no source data are modified."""
import unittest

import numpy as np

from recalculate_PLMARG_overall_metrics import scores


class ARGOnlyMetricTests(unittest.TestCase):
    def test_rejected_predictions_are_errors_not_macro_classes(self):
        rows, counts = scores(['A', 'A', 'B', 'B'],
                              ['A', 'nonARG', 'A', '__MODEL_UNMAPPED__'],
                              100, 'ARG_only', 'Type')
        result = rows.set_index('Average')
        self.assertTrue(result.N.eq(4).all())
        self.assertTrue(result.N_labels_averaged.eq(2).all())
        self.assertTrue(result.Accuracy.eq(.25).all())
        self.assertEqual(result.loc['macro', 'Averaged_labels'], 'A;B')
        np.testing.assert_allclose(result.loc['macro', ['Precision', 'Recall', 'F1']].to_numpy(float), [.25, .25, .25])
        np.testing.assert_allclose(result.loc['micro', ['Precision', 'Recall', 'F1']].to_numpy(float), [.5, .25, 1 / 3])
        self.assertEqual(counts.set_index('Label').loc['B', 'FN'], 2)

    def test_arg_only_rejects_true_nonarg_input(self):
        with self.assertRaises(AssertionError):
            scores(['A', 'nonARG'], ['A', 'nonARG'], 100, 'ARG_only', 'Type')

    def test_ordinary_micro_equals_accuracy_without_rejection(self):
        rows, _ = scores(['A', 'A', 'B', 'B'], ['A', 'B', 'B', 'A'], 100, 'ARG_only', 'Type')
        row = rows.set_index('Average').loc['micro']
        np.testing.assert_allclose(row[['Accuracy', 'Precision', 'Recall', 'F1']].to_numpy(float), .5)

    def test_all_rejected_rows_are_not_dropped(self):
        rows, _ = scores(['A', 'B'], ['nonARG', '__MODEL_UNMAPPED__'], 60, 'ARG_only', 'Type')
        self.assertTrue(rows.N.eq(2).all())
        np.testing.assert_array_equal(rows[['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']].to_numpy(float), np.zeros((3, 5)))


if __name__ == '__main__':
    unittest.main()
