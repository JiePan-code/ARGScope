#!/usr/bin/env python3
"""Count FASTA records in every FASTA file in a local Windows folder.

Default behavior: scan the folder containing this script.  The implementation
streams through files in binary blocks, so FASTA files with tens of millions of
records are not loaded into memory.
"""

from __future__ import annotations

import argparse
import csv
import os
import time
from pathlib import Path


FASTA_SUFFIXES = {".fasta", ".fa", ".fna", ".fas"}
BLOCK_SIZE = 64 * 1024 * 1024  # 64 MiB


def count_fasta_records(path: Path) -> int:
    """Count FASTA headers (lines whose first character is '>')."""
    count = 0
    previous_byte = b"\n"  # lets a header at byte 0 be counted as '\n>'

    with path.open("rb") as handle:
        while True:
            block = handle.read(BLOCK_SIZE)
            if not block:
                breakw
            count += (previous_byte + block).count(b"\n>")
            previous_byte = block[-1:]

    return count


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Count sequences in all FASTA files in a folder."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=script_dir,
        help="FASTA folder (default: the folder containing this script)",
    )
    parser.add_argument(
        "--output-csv",
        type=Path,
        default=None,
        help="Output CSV (default: <input-dir>/fasta_sequence_counts.csv)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.expanduser().resolve()
    output_csv = (
        args.output_csv.expanduser().resolve()
        if args.output_csv is not None
        else input_dir / "fasta_sequence_counts.csv"
    )

    if not input_dir.is_dir():
        raise NotADirectoryError(f"Input folder does not exist: {input_dir}")

    fasta_files = sorted(
        (
            p
            for p in input_dir.iterdir()
            if p.is_file() and p.suffix.lower() in FASTA_SUFFIXES
        ),
        key=lambda p: p.name.lower(),
    )

    if not fasta_files:
        raise FileNotFoundError(f"No FASTA files found in: {input_dir}")

    print("=" * 100)
    print("FASTA sequence-record count")
    print("=" * 100)
    print(f"Input folder : {input_dir}")
    print(f"FASTA files : {len(fasta_files)}")
    print(f"Output CSV  : {output_csv}")
    print()

    rows: list[dict[str, object]] = []
    total_records = 0
    total_bytes = 0
    all_start = time.perf_counter()

    for index, fasta_path in enumerate(fasta_files, start=1):
        start = time.perf_counter()
        file_size = fasta_path.stat().st_size
        record_count = count_fasta_records(fasta_path)
        elapsed = time.perf_counter() - start

        total_records += record_count
        total_bytes += file_size
        rows.append(
            {
                "file_name": fasta_path.name,
                "file_size_bytes": file_size,
                "file_size_GiB": f"{file_size / (1024 ** 3):.6f}",
                "sequence_records": record_count,
                "elapsed_seconds": f"{elapsed:.3f}",
            }
        )

        print(
            f"[{index:>2}/{len(fasta_files)}] "
            f"{fasta_path.name:<35} "
            f"sequences={record_count:>15,}  "
            f"size={file_size / (1024 ** 3):>8.3f} GiB  "
            f"time={elapsed:>8.2f} s"
        )

    total_elapsed = time.perf_counter() - all_start
    rows.append(
        {
            "file_name": "TOTAL",
            "file_size_bytes": total_bytes,
            "file_size_GiB": f"{total_bytes / (1024 ** 3):.6f}",
            "sequence_records": total_records,
            "elapsed_seconds": f"{total_elapsed:.3f}",
        }
    )

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    temp_csv = output_csv.with_name(output_csv.name + ".tmp")
    fieldnames = [
        "file_name",
        "file_size_bytes",
        "file_size_GiB",
        "sequence_records",
        "elapsed_seconds",
    ]
    with temp_csv.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temp_csv, output_csv)

    print()
    print("=" * 100)
    print("COUNT COMPLETED")
    print("=" * 100)
    print(f"Files counted    : {len(fasta_files):,}")
    print(f"Total sequences  : {total_records:,}")
    print(f"Total size       : {total_bytes / (1024 ** 3):.3f} GiB")
    print(f"Elapsed time     : {total_elapsed:.2f} s")
    print(f"Results saved to : {output_csv}")


if __name__ == "__main__":
    main()
