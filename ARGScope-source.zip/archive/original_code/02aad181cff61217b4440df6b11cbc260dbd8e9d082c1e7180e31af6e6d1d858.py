import os
import re
import glob
import pandas as pd
from pathlib import Path
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord


# ==========================================================
# 1. 路径设置：按照你当前截图中的目录结构
# ==========================================================

BASE_DIR = Path(r"E:\1. ARG模型对比\BGC数据处理")

BGC_DATA_DIR = BASE_DIR / "BGC数据"

AA_FASTA = BGC_DATA_DIR / "mibig_prot_seqs_4.0.fasta"

GBK_DIR = BASE_DIR / "mibig_gbk_4.0"
JSON_DIR = BASE_DIR / "mibig_json_4.0"

OUT_DNA_FASTA = BGC_DATA_DIR / "mibig_prot_corresponding_dna.fasta"
OUT_MAP_CSV = BGC_DATA_DIR / "mibig_protein_to_dna_mapping.csv"
OUT_MISSING_CSV = BGC_DATA_DIR / "mibig_missing_dna_records.csv"
OUT_DUPLICATE_CSV = BGC_DATA_DIR / "mibig_duplicate_dna_records.csv"


# ==========================================================
# 2. 检查路径
# ==========================================================

def check_input_paths():
    print("Current working directory:")
    print(os.getcwd())
    print()

    print("BASE_DIR:", BASE_DIR)
    print("BASE_DIR exists:", BASE_DIR.exists())
    print()

    print("BGC_DATA_DIR:", BGC_DATA_DIR)
    print("BGC_DATA_DIR exists:", BGC_DATA_DIR.exists())
    print()

    print("AA_FASTA:", AA_FASTA)
    print("AA_FASTA exists:", AA_FASTA.exists())
    print()

    print("GBK_DIR:", GBK_DIR)
    print("GBK_DIR exists:", GBK_DIR.exists())
    print()

    print("JSON_DIR:", JSON_DIR)
    print("JSON_DIR exists:", JSON_DIR.exists())
    print()

    if not BASE_DIR.exists():
        raise FileNotFoundError(f"找不到 BASE_DIR: {BASE_DIR}")

    if not BGC_DATA_DIR.exists():
        raise FileNotFoundError(f"找不到 BGC_DATA_DIR: {BGC_DATA_DIR}")

    if not AA_FASTA.exists():
        raise FileNotFoundError(f"找不到 AA_FASTA: {AA_FASTA}")

    if not GBK_DIR.is_dir():
        raise NotADirectoryError(f"找不到 GBK_DIR: {GBK_DIR}")

    if not JSON_DIR.is_dir():
        raise NotADirectoryError(f"找不到 JSON_DIR: {JSON_DIR}")

    BGC_DATA_DIR.mkdir(parents=True, exist_ok=True)


# ==========================================================
# 3. 建立 GBK / JSON 索引
# ==========================================================

def build_gbk_index(gbk_dir):
    gbk_files = []
    gbk_files.extend(glob.glob(str(gbk_dir / "*.gbk")))
    gbk_files.extend(glob.glob(str(gbk_dir / "*.gb")))
    gbk_files.extend(glob.glob(str(gbk_dir / "*.genbank")))
    gbk_files.extend(glob.glob(str(gbk_dir / "*.gbff")))

    gbk_files = sorted(set(gbk_files))

    print(f"Detected GBK files: {len(gbk_files)}")
    print("First 5 GBK files:")
    for x in gbk_files[:5]:
        print("  ", x)

    index = {}

    for fp in gbk_files:
        name = os.path.basename(fp)

        m = re.search(r"(BGC\d{7})", name)
        if m is None:
            continue

        bgc_base = m.group(1)
        index[bgc_base] = fp

    return index


def build_json_index(json_dir):
    json_files = []
    json_files.extend(glob.glob(str(json_dir / "*.json")))

    json_files = sorted(set(json_files))

    print(f"Detected JSON files: {len(json_files)}")
    print("First 5 JSON files:")
    for x in json_files[:5]:
        print("  ", x)

    index = {}

    for fp in json_files:
        name = os.path.basename(fp)

        m = re.search(r"(BGC\d{7})", name)
        if m is None:
            continue

        bgc_base = m.group(1)
        index[bgc_base] = fp

    return index


# ==========================================================
# 4. 解析蛋白 FASTA header
# ==========================================================

def parse_aa_header(header):
    """
    FASTA header 示例:

    BGC0000001.5|c1|1-1083|+|AEK75490.1|protein_methyltransferase|AEK75490.1
    """

    parts = header.strip().split("|")

    if len(parts) < 5:
        raise ValueError(f"FASTA header 格式异常: {header}")

    bgc_id = parts[0]
    contig = parts[1]
    coord = parts[2]
    strand = parts[3]
    protein_id = parts[4]
    product = parts[5] if len(parts) > 5 else ""
    protein_id_2 = parts[6] if len(parts) > 6 else ""

    m = re.match(r"^(\d+)-(\d+)$", coord)
    if m is None:
        raise ValueError(f"坐标格式异常: {coord} in {header}")

    start = int(m.group(1))
    end = int(m.group(2))

    bgc_base = bgc_id.split(".")[0]

    return {
        "header": header,
        "bgc_id": bgc_id,
        "bgc_base": bgc_base,
        "contig": contig,
        "start": start,
        "end": end,
        "strand": strand,
        "protein_id": protein_id,
        "product": product,
        "protein_id_2": protein_id_2,
    }


# ==========================================================
# 5. 读取 GBK
# ==========================================================

GBK_CACHE = {}

def load_gbk_records(gbk_file):
    if gbk_file in GBK_CACHE:
        return GBK_CACHE[gbk_file]

    records = list(SeqIO.parse(gbk_file, "genbank"))
    GBK_CACHE[gbk_file] = records

    return records


# ==========================================================
# 6. 根据 protein_id 或坐标提取 DNA
# ==========================================================

def normalize_id(x):
    return str(x).strip()


def find_cds_by_protein_id(records, protein_id):
    """
    优先根据 GBK 中 CDS feature 的 protein_id / locus_tag 等字段匹配。
    如果匹配成功，直接用 feature.extract(record.seq) 提取 DNA。
    """

    protein_id = normalize_id(protein_id)

    for record in records:
        for feature in record.features:
            if feature.type != "CDS":
                continue

            candidate_ids = []

            for key in [
                "protein_id",
                "locus_tag",
                "ID",
                "gene",
                "old_locus_tag",
            ]:
                if key in feature.qualifiers:
                    candidate_ids.extend(
                        [normalize_id(v) for v in feature.qualifiers[key]]
                    )

            if protein_id in candidate_ids:
                dna_seq = feature.extract(record.seq)

                return {
                    "dna_seq": str(dna_seq),
                    "record_id": record.id,
                    "match_method": "gbk_cds_protein_id",
                    "gbk_start": int(feature.location.start) + 1,
                    "gbk_end": int(feature.location.end),
                    "gbk_strand": feature.location.strand,
                }

    return None


def find_record_for_contig(records, contig):
    if len(records) == 1:
        return records[0]

    contig = str(contig).strip()

    for record in records:
        text = " ".join([
            str(record.id),
            str(record.name),
            str(record.description),
        ])

        if contig == record.id or contig == record.name or contig in text:
            return record

    return records[0]


def extract_dna_by_coordinate(records, contig, start, end, strand):
    """
    根据 FASTA header 中的坐标直接提取 DNA。

    header 坐标一般是 1-based inclusive:
        start=1, end=1083

    Python 切片:
        record.seq[start - 1:end]
    """

    record = find_record_for_contig(records, contig)

    seq_len = len(record.seq)

    if start < 1 or end > seq_len or start > end:
        return None

    dna = record.seq[start - 1:end]

    if strand == "-":
        dna = dna.reverse_complement()
    elif strand == "+":
        pass
    else:
        return None

    return {
        "dna_seq": str(dna),
        "record_id": record.id,
        "match_method": "header_coordinate",
        "gbk_start": start,
        "gbk_end": end,
        "gbk_strand": strand,
    }


def extract_dna_for_protein(item, gbk_index):
    """
    单条 protein 记录提取 DNA。

    优先级:
        1. 用 protein_id 匹配 GBK 中的 CDS feature；
        2. 如果匹配不到，用 FASTA header 中的坐标直接截取。
    """

    bgc_base = item["bgc_base"]

    if bgc_base not in gbk_index:
        return None, f"GBK file not found for {item['bgc_id']} / {bgc_base}"

    gbk_file = gbk_index[bgc_base]
    records = load_gbk_records(gbk_file)

    if len(records) == 0:
        return None, f"No GenBank record parsed from {gbk_file}"

    result = find_cds_by_protein_id(records, item["protein_id"])

    if result is not None:
        result["gbk_file"] = gbk_file
        return result, ""

    result = extract_dna_by_coordinate(
        records=records,
        contig=item["contig"],
        start=item["start"],
        end=item["end"],
        strand=item["strand"]
    )

    if result is not None:
        result["gbk_file"] = gbk_file
        return result, ""

    return None, "Cannot match by protein_id or coordinate"


# ==========================================================
# 7. 主程序
# ==========================================================

def main():
    check_input_paths()

    print("Building GBK index...")
    gbk_index = build_gbk_index(GBK_DIR)
    print("GBK index size:", len(gbk_index))
    print()

    print("Building JSON index...")
    json_index = build_json_index(JSON_DIR)
    print("JSON index size:", len(json_index))
    print()

    if len(gbk_index) == 0:
        raise ValueError("没有索引到任何 GBK 文件，请检查 GBK_DIR 路径。")

    records_out = []
    mapping_rows = []
    missing_rows = []
    duplicate_rows = []

    # 按 protein_id 去重：同一个 protein_id 只保留第一次出现的 DNA
    seen_protein_ids = set()

    total = 0
    success = 0
    fail = 0
    duplicate = 0

    print("Processing amino acid FASTA...")

    for rec in SeqIO.parse(str(AA_FASTA), "fasta"):
        total += 1

        item = parse_aa_header(rec.description)
        aa_seq = str(rec.seq)

        # ==================================================
        # 先按 protein_id 检查重复
        # 如果重复，直接跳过，不再提取 DNA
        # ==================================================

        dedup_id = item["protein_id"]

        if dedup_id in seen_protein_ids:
            duplicate += 1

            duplicate_rows.append({
                "aa_header": item["header"],
                "bgc_id": item["bgc_id"],
                "bgc_base": item["bgc_base"],
                "contig": item["contig"],
                "start": item["start"],
                "end": item["end"],
                "strand": item["strand"],
                "protein_id": item["protein_id"],
                "product": item["product"],
                "reason": "duplicated protein_id, skipped",
            })

            continue

        result, error_msg = extract_dna_for_protein(item, gbk_index)

        json_file = json_index.get(item["bgc_base"], "")

        if result is None:
            fail += 1

            missing_rows.append({
                "aa_header": item["header"],
                "bgc_id": item["bgc_id"],
                "bgc_base": item["bgc_base"],
                "contig": item["contig"],
                "start": item["start"],
                "end": item["end"],
                "strand": item["strand"],
                "protein_id": item["protein_id"],
                "product": item["product"],
                "error": error_msg,
                "json_file": json_file,
            })

            continue

        dna_seq = result["dna_seq"]

        dna_header = (
            f"{item['bgc_id']}|{item['contig']}|"
            f"{item['start']}-{item['end']}|{item['strand']}|"
            f"{item['protein_id']}|{item['product']}"
        )

        # 到这里说明该 protein_id 成功提取 DNA，因此加入 seen
        seen_protein_ids.add(dedup_id)
        success += 1

        records_out.append(
            SeqRecord(
                Seq(dna_seq),
                id=dna_header,
                description=""
            )
        )

        mapping_rows.append({
            "aa_header": item["header"],
            "dna_header": dna_header,
            "bgc_id": item["bgc_id"],
            "bgc_base": item["bgc_base"],
            "contig": item["contig"],
            "start": item["start"],
            "end": item["end"],
            "strand": item["strand"],
            "protein_id": item["protein_id"],
            "product": item["product"],
            "aa_length": len(aa_seq),
            "dna_length": len(dna_seq),
            "expected_dna_length_aa_times_3": len(aa_seq) * 3,
            "expected_dna_length_aa_times_3_plus_stop": len(aa_seq) * 3 + 3,
            "length_match_aa_times_3": len(dna_seq) == len(aa_seq) * 3,
            "length_match_aa_times_3_plus_stop": len(dna_seq) == len(aa_seq) * 3 + 3,
            "match_method": result["match_method"],
            "gbk_record_id": result["record_id"],
            "gbk_start": result["gbk_start"],
            "gbk_end": result["gbk_end"],
            "gbk_strand": result["gbk_strand"],
            "gbk_file": result["gbk_file"],
            "json_file": json_file,
        })

        if total % 1000 == 0:
            print(
                f"Processed: {total}, "
                f"success: {success}, "
                f"fail: {fail}, "
                f"duplicate skipped: {duplicate}"
            )

    print("Writing output files...")

    SeqIO.write(records_out, str(OUT_DNA_FASTA), "fasta")

    pd.DataFrame(mapping_rows).to_csv(
        OUT_MAP_CSV,
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(missing_rows).to_csv(
        OUT_MISSING_CSV,
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(duplicate_rows).to_csv(
        OUT_DUPLICATE_CSV,
        index=False,
        encoding="utf-8-sig"
    )

    print()
    print("Done.")
    print(f"Total protein records: {total}")
    print(f"Successfully extracted DNA: {success}")
    print(f"Failed records: {fail}")
    print(f"Duplicated protein IDs skipped: {duplicate}")
    print(f"Unique protein IDs kept: {len(seen_protein_ids)}")
    print(f"DNA FASTA saved to: {OUT_DNA_FASTA}")
    print(f"Mapping table saved to: {OUT_MAP_CSV}")
    print(f"Missing table saved to: {OUT_MISSING_CSV}")
    print(f"Duplicate table saved to: {OUT_DUPLICATE_CSV}")


if __name__ == "__main__":
    main()