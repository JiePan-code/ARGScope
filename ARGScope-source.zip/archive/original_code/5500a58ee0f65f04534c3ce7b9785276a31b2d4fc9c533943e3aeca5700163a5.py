"""Read-only inspection of the supplied Protein hyperparameter-search CSV."""
import csv
import itertools
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

SOURCE = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\2.Protein_student_long_gridsearch\ALL_PARAMETER_RESULTS.csv")


def main():
    with SOURCE.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    stages = defaultdict(list)
    for row in rows:
        stages[row["stage"]].append(row)
    report = {"n": len(rows), "columns": len(rows[0]), "stages": {k: len(v) for k, v in stages.items()}}
    report["grid_checks"] = {}
    for stage, fields in (
        ("student_grid_81", ["student_lr", "dropout", "class_weight_power", "student_prototype_align"]),
        ("student_grid_27", ["student_subtype_ce", "student_binary_kd", "student_feature_align"]),
        ("teacher_grid", ["teacher_lr", "teacher_refined_anchor"]),
    ):
        records = stages[stage]
        observed = Counter(tuple(float(row[f]) for f in fields) for row in records)
        levels = {f: sorted({float(row[f]) for row in records}) for f in fields}
        expected = set(itertools.product(*(levels[f] for f in fields)))
        report["grid_checks"][stage] = {"levels": levels, "missing_combinations": len(expected - set(observed)), "duplicate_combinations": sum(n-1 for n in observed.values())}
    grid = stages["student_grid_81"]
    cells = defaultdict(list)
    for row in grid:
        cells[(float(row["student_lr"]), float(row["dropout"]))].append(row)
    report["heatmap"] = [{"learning_rate": f"{lr:g}", "dropout": f"{drop:g}", "subtype_weighted_precision": statistics.mean(float(r["val_subtype_weighted_precision"]) for r in records), "n_combinations": len(records)} for (lr, drop), records in sorted(cells.items())]
    report["main_effects"] = {}
    for field in ["student_lr", "dropout", "class_weight_power", "student_prototype_align"]:
        report["main_effects"][field] = [{"level": level, "n": len(records), "mean_subtype_weighted_precision": statistics.mean(float(r["val_subtype_weighted_precision"]) for r in records)} for level in sorted({float(r[field]) for r in grid}) for records in [[r for r in grid if float(r[field]) == level]]]
    robust = defaultdict(list)
    for row in stages["robustness"]:
        robust[row["candidate_key"]].append(row)
    report["robustness"] = [{"candidate": key, "seeds": sorted(r["seed"] for r in records), "n": len(records), "mean_score": statistics.mean(float(r["best_validation_score"]) for r in records), "sd_score": statistics.stdev(float(r["best_validation_score"]) for r in records), "mean_subtype_weighted_precision": statistics.mean(float(r["val_subtype_weighted_precision"]) for r in records)} for key, records in robust.items()]
    report["teacher"] = [{k: r[k] for k in ["combo_key", "teacher_best_validation_score", "val_subtype_weighted_precision"]} for r in stages["teacher_grid"]]
    report["missing_metric_cells"] = {f: sum(not r[f] for r in rows) for f in ["val_subtype_weighted_precision", "val_subtype_macro_f1", "val_end_accuracy", "teacher_best_validation_score", "best_validation_score"]}
    report["val_counts"] = {f: sorted({r[f] for r in rows}) for f in ["val_binary_n", "val_subtype_n", "val_end_n"]}
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
