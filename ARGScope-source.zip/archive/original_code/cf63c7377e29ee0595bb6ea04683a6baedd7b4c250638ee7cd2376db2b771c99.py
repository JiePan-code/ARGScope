import pandas as pd

input_file = "merged_shared_mapping_excludeVF.csv"

protein_fasta = "non_vf_protein_29354.fasta"
dna_fasta = "non_vf_dna_29354.fasta"

n_sample = 29354

# 读取
df = pd.read_csv(input_file, on_bad_lines="skip")

# 去重（按 protein_id）
df = df.drop_duplicates(subset="protein_id")

print(f"可用数据量: {len(df)}")

# 采样
sampled = df.sample(n=n_sample, random_state=42)

# ========= 写 protein fasta =========
with open(protein_fasta, "w") as f:
    for _, row in sampled.iterrows():
        pid = row["protein_id"]
        seq = str(row["protein_sequence"]).replace(" ", "").replace("\n", "")
        f.write(f">{pid}\n{seq}\n")

# ========= 写 DNA fasta =========
with open(dna_fasta, "w") as f:
    for _, row in sampled.iterrows():
        pid = row["protein_id"]   # 注意：这里仍然用 protein_id
        seq = str(row["dna_sequence"]).replace(" ", "").replace("\n", "")
        f.write(f">{pid}\n{seq}\n")

print("完成：")
print(protein_fasta)
print(dna_fasta)