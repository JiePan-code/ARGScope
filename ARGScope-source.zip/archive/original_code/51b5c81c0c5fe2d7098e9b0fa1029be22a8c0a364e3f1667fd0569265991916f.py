"""Full-length VF/BGC manuscript figures from fixed test predictions.

Run with D:/Anaconda/envs/dnabert2_5060/python.exe plot_vf_bgc_full_length.py --domain VF
The supplied data and selected checkpoints are never modified.
"""
from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('NUMBA_NUM_THREADS', '2')
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import textwrap
import warnings
warnings.filterwarnings('ignore', message='n_jobs value.*')
import torch
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import FormatStrFormatter, MaxNLocator
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support
from sklearn.decomposition import PCA
import umap

HERE = Path(__file__).resolve().parent
PAPER = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\VF_BGC_100pct_20260921')
WORK = HERE/'outputs'/'vf_bgc_full_length_figures_20260921'
SPECS = {
 'VF': {'root': Path(r'E:\1. ARGmodel\毒力因子数据处理\独立因子新结果'), 'negative': 'non-VF',
        'metadata': 'Dataset_split/VF_nonVF_ID表_test.csv',
        'models': {'AA': '1.result/1Protein_student_VF', 'NT': '1.result/2DNA_student_VF'}},
 'BGC': {'root': Path(r'E:\1. ARGmodel\BGC数据处理\BGC_novel dataset'), 'negative': 'nonBGC',
         'metadata': 'Dataset_split/BGC_nonBGC_id_type_subtype_test.csv',
         'models': {'AA': '1 Result/1.Protein_student_BGC', 'NT': '1 Result/2.DNA_student_BGC'}}}
METRICS = ['ACC','Precision','Recall','F1','MCC']
MODEL_COLORS = {'AA':'#397E9C','NT':'#D69A52'}
TYPE_COLORS = ['#3F568F','#EE758F','#3ABAA8','#E8A23B','#A381C1','#59A3D0',
               '#6EA947','#B26148','#79CBCD','#C69C50','#BB7EB4','#6B8778','#E07852','#9E9E9E']
NEG_COLOR = '#C5C8CB'
PARAMS = {'n_neighbors':25,'min_dist':0.12,'metric':'cosine','random_state':42,
          'n_epochs':400,'n_jobs':1,'low_memory':True}
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.labelsize':9,
 'axes.titlesize':10,'axes.linewidth':0.8,'xtick.labelsize':8,'ytick.labelsize':8,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white',
 'hatch.linewidth':0.45,'axes.spines.top':False,'axes.spines.right':False})

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def csv_read(path):
    return pd.read_csv(path,encoding='utf-8-sig',keep_default_na=False)

def wrapped(value,width=23):
    return '\n'.join(textwrap.wrap(str(value).replace('_',' ').replace('/','/ '),width=width,
                                  break_long_words=False,break_on_hyphens=False))

def calculate(true,pred,labels,average):
    p,r,f,_=precision_recall_fscore_support(true,pred,labels=labels,average=average,zero_division=0)
    return np.array([accuracy_score(true,pred),p,r,f,matthews_corrcoef(true,pred)])

def read_domain(domain):
    spec=SPECS[domain]; root=spec['root']; neg=spec['negative']
    folder=root/'统一口径结果_20260921'
    manifest=csv_read(folder/'08_source_manifest.csv')
    for _,row in manifest.iterrows():
        path=Path(row['Path'])
        assert path.exists(), path
        assert digest(path)==row['SHA256'], f'Source changed since metric reconciliation: {path}'
    meta=csv_read(root/spec['metadata']).set_index('id',verify_integrity=True)
    labels=csv_read(folder/'05_type_label_universe.csv')['Type'].tolist()
    assert neg not in labels
    main=csv_read(folder/'01_main_results.csv')
    all_avg=csv_read(folder/'02_all_averages.csv')
    per=csv_read(folder/'03_per_type_metrics.csv')
    result={'domain':domain,'root':root,'negative':neg,'labels':labels,'main':main,
            'all_avg':all_avg,'per':per,'models':{},'sources':manifest.to_dict('records')}
    for mod,rel in spec['models'].items():
        name=f'{domain}Scope-{mod}'; modeldir=root/rel
        pred=csv_read(modeldir/'test_sequence_predictions.csv').set_index('id',verify_integrity=True)
        assert set(pred.index)==set(meta.index)
        pred=pred.loc[meta.index].reset_index()
        for level in ['type','subtype']:
            assert np.array_equal(pred['true_'+level].values,meta[level].values)
        assert pred['split'].eq('test').all()
        positive=pred.loc[pred.true_type.ne(neg)].copy()
        assert set(positive.true_type)<=set(labels)
        assert set(pred.predicted_type)<=set(labels+[neg])
        for prefix in ['true','predicted']:
            assert np.array_equal(pred[prefix+'_binary'].eq(neg),pred[prefix+'_type'].eq(neg))
            assert np.array_equal(pred[prefix+'_binary'].eq(neg),pred[prefix+'_subtype'].eq(neg))
        model_main=main.loc[main.Model.eq(name)]
        for task,key,cohort,universe,avg in [
          (f'{domain}/non-VF' if domain=='VF' else 'BGC/nonBGC','binary',pred,[domain,neg],'macro'),
          ('Type','type',positive,labels,'macro'),
          ('Subtype','subtype',pred,sorted(set(pred.true_subtype)|set(pred.predicted_subtype)),'weighted')]:
            actual=calculate(cohort['true_'+key],cohort['predicted_'+key],universe,avg)
            expected=model_main.loc[model_main.Task.eq(task),METRICS].iloc[0].to_numpy(float)
            np.testing.assert_allclose(actual,expected,rtol=0,atol=2e-12)
        for _,reported in all_avg.loc[all_avg.Model.eq(name)].iterrows():
            if reported.Task=='Type':
                key,cohort,universe='type',positive,labels
            elif reported.Task=='Subtype':
                key,cohort,universe='subtype',pred,sorted(set(pred.true_subtype)|set(pred.predicted_subtype))
            else:
                key,cohort,universe='binary',pred,[domain,neg]
            actual=calculate(cohort['true_'+key],cohort['predicted_'+key],universe,reported.Average)
            np.testing.assert_allclose(actual,reported[METRICS].to_numpy(float),rtol=0,atol=2e-12)
        cm=np.zeros((len(labels),len(labels)+1),dtype=np.int64)
        index={v:i for i,v in enumerate(labels+[neg])}
        np.add.at(cm,([index[t] for t in positive.true_type],[index[p] for p in positive.predicted_type]),1)
        assert int(cm.sum())==len(positive)
        rows=[]
        for i,label in enumerate(labels):
            tp=cm[i,i]; pp=cm[:,i].sum(); nn=cm[i,:].sum()
            p=tp/pp if pp else 0.; r=tp/nn if nn else 0.; f=2*p*r/(p+r) if p+r else 0.
            expected=per.loc[per.Model.eq(name)&per.Label.eq(label),['Precision','Recall','F1']].iloc[0].to_numpy(float)
            np.testing.assert_allclose([p,r,f],expected,rtol=0,atol=2e-12)
            rows.append({'Type':label,'Support':int(nn),'Precision':p,'Recall':r,'F1':f})
        summary=json.loads((modeldir/'run_summary.json').read_text(encoding='utf-8-sig'))
        epoch=int(summary['student_best_epoch'])
        features=sorted((modeldir/'epoch_features').glob('*.pt'))
        initial=[p for p in features if p.name.startswith('epoch_000_')]
        best=[p for p in features if p.name.startswith(f'run_best_epoch_{epoch:03d}_')]
        assert len(initial)==len(best)==1
        errors=positive.loc[positive.true_subtype.ne(positive.predicted_subtype)].copy()
        errors['Type_correct']=errors.true_type.eq(errors.predicted_type).astype(int)
        grouped=errors.groupby(['true_subtype','predicted_subtype'],sort=True).agg(
            Count=('id','size'),Type_correct=('Type_correct','sum')).reset_index()
        grouped['Type_incorrect']=grouped.Count-grouped.Type_correct
        grouped['Type_correct_fraction']=grouped.Type_correct/grouped.Count
        grouped=grouped.sort_values(['Count','true_subtype','predicted_subtype'],ascending=[False,True,True])
        result['models'][mod]={'name':name,'folder':modeldir,'rows':pred,'positive':positive,
            'cm':cm,'per':pd.DataFrame(rows),'best_epoch':epoch,'features':features,
            'initial':initial[0],'best':best[0],'errors':grouped,'summary':summary}
    result['error_vmax']=int(max(np.max(np.where(np.eye(len(labels),len(labels)+1),0,v['cm']))
                                for v in result['models'].values()))
    return result

def embedding(data,mod,path,cache):
    model=data['models'][mod]
    source_hash=digest(path)
    key={'source_sha256':source_hash,'umap':PARAMS,'pca_components':50,'normalization':'none'}
    target=cache/f'{mod}_{path.stem}_umap.csv'; settings=target.with_suffix('.json')
    if target.exists() and settings.exists() and json.loads(settings.read_text())['configuration']==key:
        return csv_read(target)
    payload=torch.load(path,map_location='cpu',weights_only=False)
    ids=[str(x) for x in payload['ids']]
    assert len(ids)==len(set(ids))==len(model['positive'])
    assert set(ids)==set(model['positive'].id)
    truth=model['positive'].set_index('id')
    assert list(truth.loc[ids,'true_type'])==list(payload['types'])
    assert list(truth.loc[ids,'true_subtype'])==list(payload['subtypes'])
    x=payload['features'].detach().cpu().numpy().astype(np.float32)
    assert x.ndim==2 and x.shape[0]==len(ids) and np.isfinite(x).all()
    components=min(50,x.shape[1],x.shape[0]-1)
    pca=PCA(n_components=components,svd_solver='randomized',random_state=42)
    reduced=pca.fit_transform(x)
    print(f'UMAP {data["domain"]} {mod} epoch={payload["epoch"]} n={len(ids)}',flush=True)
    xy=umap.UMAP(**PARAMS).fit_transform(reduced)
    frame=pd.DataFrame({'id':ids,'Type':payload['types'],'Subtype':payload['subtypes'],
                        'UMAP1':xy[:,0],'UMAP2':xy[:,1],'epoch':int(payload['epoch'])})
    frame.to_csv(target,index=False,encoding='utf-8-sig')
    settings.write_text(json.dumps({'configuration':key,'source':str(path),
       'pca_explained_variance':float(pca.explained_variance_ratio_.sum()),
       'n':len(ids),'all_reference_positive_test_sequences':True},indent=2),encoding='utf-8')
    return frame

def model_legend(data):
    return [Patch(facecolor=MODEL_COLORS[m],edgecolor='#42505A',linewidth=.5,
                  hatch='--' if m=='AA' else '//',label=data['models'][m]['name']) for m in ['AA','NT']]

def letter(ax,value,x=-.14,y=1.12):
    ax.text(x,y,value,transform=ax.transAxes,fontsize=15,fontweight='bold',ha='left',va='bottom')

def radar(ax,data):
    angles=np.linspace(0,2*np.pi,5,endpoint=False); closed=np.r_[angles,angles[0]]
    ax.set_theta_offset(np.pi/2); ax.set_theta_direction(-1)
    for mod in ['AA','NT']:
        name=data['models'][mod]['name']
        values=data['main'].loc[data['main'].Model.eq(name)&~data['main'].Task.isin(['Type','Subtype']),METRICS].iloc[0].to_numpy(float)
        ax.plot(closed,np.r_[values,values[0]],color=MODEL_COLORS[mod],lw=1.6,
                linestyle='-' if mod=='AA' else '--',marker='o' if mod=='AA' else 's',ms=3)
        ax.fill(closed,np.r_[values,values[0]],color=MODEL_COLORS[mod],alpha=.08)
    ax.set_xticks(angles,['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC'])
    ax.tick_params(axis='x',pad=9); ax.set_ylim(0,1)
    ax.set_yticks([.2,.4,.6,.8,1.],['0.2','0.4','0.6','0.8','1.0'],fontsize=7,color='#7E848B')
    ax.set_rlabel_position(78); ax.grid(color='#D8DDE2',lw=.6)
    ax.spines['polar'].set_color('#A6ADB4'); ax.spines['polar'].set_linewidth(.7)
    ax.set_title(f'{data["domain"]}/non-{data["domain"]}',pad=22,fontsize=11)

def grouped_bars(ax,data,task='Type',average=None):
    x=np.arange(5); width=.34
    for j,mod in enumerate(['AA','NT']):
        name=data['models'][mod]['name']
        if average is None:
            values=data['main'].loc[data['main'].Model.eq(name)&data['main'].Task.eq(task),METRICS].iloc[0].to_numpy(float)
        else:
            values=data['all_avg'].loc[data['all_avg'].Model.eq(name)&data['all_avg'].Task.eq(task)&data['all_avg'].Average.eq(average),METRICS].iloc[0].to_numpy(float)
        ax.bar(x+(j-.5)*width,values,width,color=MODEL_COLORS[mod],edgecolor='#59636A',
               lw=.55,hatch='--' if mod=='AA' else '//',zorder=3)
    metric_labels=['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC']
    if average=='weighted': metric_labels=['ACC','Weighted\nprecision','Weighted\nrecall','Weighted F1','MCC']
    ax.set_xticks(x,metric_labels); ax.set_ylim(0,1.06); ax.set_yticks(np.linspace(0,1,6))
    ax.set_ylabel('Score'); ax.set_axisbelow(True); ax.yaxis.grid(color='#E7E9EB',lw=.6)
    ax.set_title(task if average is None else f'{task} · {average}',pad=11)

def type_heatmap(ax,data):
    labels=data['labels']; matrix=np.full((len(labels)+2,6),np.nan)
    for col,metric in enumerate(['Precision','Recall','F1']):
        for j,mod in enumerate(['AA','NT']):
            name=data['models'][mod]['name']; v=data['models'][mod]
            matrix[0,col*2+j]=data['main'].loc[data['main'].Model.eq(name)&data['main'].Task.eq('Type'),metric].iloc[0]
            matrix[2:,col*2+j]=v['per'].set_index('Type').loc[labels,metric]
    cmap=plt.colormaps['Blues'].copy(); cmap.set_bad('white')
    im=ax.imshow(np.ma.masked_invalid(matrix),cmap=cmap,vmin=0,vmax=1,aspect='auto',interpolation='nearest')
    for i in range(matrix.shape[0]):
        if i==1: continue
        for j in range(6):
            ax.text(j,i,f'{matrix[i,j]:.4f}',ha='center',va='center',fontsize=7,
                    color='white' if matrix[i,j]>.60 else '#182C3E')
    ax.set_xticks(range(6),['AA','NT']*3)
    ax.set_yticks(range(len(labels)+2),['Average','']+[wrapped(l,28) for l in labels],fontsize=7.5)
    ax.tick_params(length=0,pad=4)
    ax.set_xticks(np.arange(-.5,6,1),minor=True)
    ax.set_yticks(np.arange(-.5,len(labels)+2,1),minor=True)
    ax.grid(which='minor',color='white',lw=1.1); ax.tick_params(which='minor',length=0)
    for x in [1.5,3.5]: ax.axvline(x,color='white',lw=5)
    for i,label in enumerate(['Precision','Recall','F1']):
        ax.text((2*i+1)/6,1.035,label,transform=ax.transAxes,ha='center',va='bottom',fontsize=9)
    for label in ax.get_xticklabels(): label.set_color(MODEL_COLORS[label.get_text()])
    for spine in ax.spines.values(): spine.set_visible(False)
    cb=ax.figure.colorbar(im,ax=ax,fraction=.035,pad=.025,ticks=[0,.25,.5,.75,1.])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f')); cb.ax.tick_params(labelsize=7,length=2)
    cb.outline.set_linewidth(.5)
    return matrix

def plot_embedding(ax,frame,data,mod,title,ylab=True):
    colors={k:TYPE_COLORS[i] for i,k in enumerate(data['labels'])}
    order=np.random.default_rng(20260921).permutation(len(frame))
    points=frame.iloc[order]
    ax.scatter(points.UMAP1,points.UMAP2,c=[colors[t] for t in points.Type],s=3.2,
               alpha=.78,linewidths=0,rasterized=True)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel('UMAP1',labelpad=3)
    if ylab: ax.set_ylabel('UMAP2',labelpad=4)
    ax.set_title(title,fontsize=9.5,pad=7,color='#25313B')
    for spine in ax.spines.values(): spine.set_visible(True); spine.set_linewidth(.8)
    xmin,xmax=frame.UMAP1.min(),frame.UMAP1.max()
    ymin,ymax=frame.UMAP2.min(),frame.UMAP2.max()
    half=max(xmax-xmin,ymax-ymin)*.555
    ax.set_xlim((xmin+xmax)/2-half,(xmin+xmax)/2+half)
    ax.set_ylim((ymin+ymax)/2-half,(ymin+ymax)/2+half)
    ax.set_aspect('equal',adjustable='box'); ax.set_box_aspect(1)

def type_legend(ax,data):
    ax.axis('off')
    handles=[Line2D([0],[0],marker='o',ls='',ms=5,color=TYPE_COLORS[i],label=wrapped(label,28))
              for i,label in enumerate(data['labels'])]
    ax.legend(handles=handles,loc='center',bbox_to_anchor=(0,0,1,1),mode='expand',
              ncol=4 if len(handles)>8 else 7,frameon=False,fontsize=8,handletextpad=.45,
              borderaxespad=0,columnspacing=1.,labelspacing=.55)

def matrix_panel(ax,data,mod,errors=False):
    model=data['models'][mod]; labels=data['labels']; k=len(labels); cm=model['cm']
    if errors:
        matrix=cm.astype(float).copy(); matrix[np.arange(k),np.arange(k)]=np.nan
        vmax=data['error_vmax']; label='Count'
    else:
        matrix=cm/cm.sum(axis=1,keepdims=True); vmax=1.; label='Proportion'
    cmap=plt.colormaps['Blues' if mod=='AA' else 'Oranges'].copy(); cmap.set_bad('#E9EAEC')
    im=ax.imshow(np.ma.masked_invalid(matrix),cmap=cmap,vmin=0,vmax=vmax,aspect='equal')
    ax.axvline(k-.5,color='#444B50',lw=.8,ls='--')
    ax.set_xticks(range(k+1),[wrapped(x,18) for x in labels]+['Missed'],rotation=55,ha='right',fontsize=6.8)
    ax.set_yticks(range(k),[wrapped(x,26) for x in labels],fontsize=7.1)
    ax.tick_params(length=2,pad=2)
    ax.set_xlabel('Predicted type',labelpad=5); ax.set_ylabel('True type',labelpad=4)
    for spine in ax.spines.values(): spine.set_visible(True); spine.set_linewidth(.55)
    if errors:
        for i in range(k):
            for j in range(k+1):
                if np.isfinite(matrix[i,j]) and matrix[i,j]>0:
                    ax.text(j,i,f'{int(matrix[i,j])}',ha='center',va='center',fontsize=5.5 if k>10 else 7,
                            color='white' if matrix[i,j]>.60*vmax else '#353F47')
    else:
        for i in range(k):
            ax.text(i,i,f'{matrix[i,i]:.2f}',ha='center',va='center',fontsize=5.5 if k>10 else 7,
                    color='white' if matrix[i,i]>.6 else '#353F47')
    title='Type errors' if errors else 'Type confusion matrix'
    ax.set_title(f'{mod} · {title}',pad=9)
    cb=ax.figure.colorbar(im,ax=ax,fraction=.037,pad=.026)
    cb.set_label(label,fontsize=8,labelpad=3); cb.ax.tick_params(labelsize=7,length=2)
    if errors: cb.locator=MaxNLocator(nbins=5,integer=True); cb.update_ticks()
    else: cb.set_ticks([0,.25,.5,.75,1.]); cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    cb.outline.set_linewidth(.5)

def error_pairs(ax,data,mod,top=10,show_legend=True):
    frame=data['models'][mod]['errors'].head(top).iloc[::-1]
    y=np.arange(len(frame)); teal='#389C8E'; orange='#D47D54'
    ax.barh(y,frame.Type_correct,color=teal,edgecolor='#59636A',lw=.45,height=.70)
    ax.barh(y,frame.Type_incorrect,left=frame.Type_correct,color=orange,
            hatch='///',edgecolor='#59636A',lw=.45,height=.70)
    def label(row):
        pred=row.predicted_subtype
        if pred==data['negative']: pred=f'non-{data["domain"]}'
        return wrapped(f'{row.true_subtype} → {pred}',35)
    labels=[label(row) for _,row in frame.iterrows()]
    ax.set_yticks(y,labels,fontsize=7)
    maximum=max(1,int(frame.Count.max()))
    for i,(_,row) in enumerate(frame.iterrows()):
        ax.text(row.Count+maximum*.018,i,f'{row.Count} ({row.Type_correct_fraction:.0%})',
                va='center',ha='left',fontsize=7)
    ax.set_xlim(0,maximum*1.36); ax.set_ylim(-.65,len(frame)-.35)
    ax.set_axisbelow(True); ax.xaxis.grid(color='#E5E8EA',lw=.6)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4,integer=True))
    ax.set_xlabel('Count'); ax.set_title(f'{mod} · Leading subtype errors',pad=9)
    handles=[Patch(facecolor=teal,edgecolor='#59636A',label='Type retained'),
             Patch(facecolor=orange,edgecolor='#59636A',hatch='///',label='Incorrect type or missed')]
    if show_legend:
        ax.legend(handles=handles,loc='upper left',bbox_to_anchor=(0,-.17),frameon=False,fontsize=7,
                  borderaxespad=0,handlelength=1.4,labelspacing=.4)

def save(fig,folder,name):
    folder.mkdir(parents=True,exist_ok=True)
    for ext in ['png','pdf','svg']:
        fig.savefig(folder/f'{name}.{ext}',dpi=300,facecolor='white',bbox_inches='tight',pad_inches=.13)
    fig.savefig(WORK/f'{name}_preview.png',dpi=90,facecolor='white',bbox_inches='tight',pad_inches=.13)
    plt.close(fig)

def build_main(data,emb,out):
    fig=plt.figure(figsize=(20,22))
    row=fig.add_gridspec(1,3,width_ratios=[1,1.12,1.4],wspace=.62,
                         left=.075,right=.967,bottom=.800,top=.965)
    ax=fig.add_subplot(row[0],projection='polar'); radar(ax,data); letter(ax,'A',-.17)
    ax=fig.add_subplot(row[1]); grouped_bars(ax,data); letter(ax,'B',-.12)
    ax=fig.add_subplot(row[2]); matrix=type_heatmap(ax,data); letter(ax,'C',-.47)
    fig.legend(handles=model_legend(data),loc='upper center',bbox_to_anchor=(.46,.994),
                ncol=2,frameon=False,fontsize=11,handlelength=2.,columnspacing=2.5)
    row=fig.add_gridspec(1,4,wspace=.23,left=.075,right=.967,bottom=.590,top=.760)
    for j,(mod,stage) in enumerate([('AA','initial'),('AA','best'),('NT','initial'),('NT','best')]):
        v=data['models'][mod]; title=f'{mod} · Epoch 0' if stage=='initial' else f'{mod} · Best model (epoch {v["best_epoch"]})'
        ax=fig.add_subplot(row[j]); plot_embedding(ax,emb[(mod,stage)],data,mod,title,ylab=j==0)
        if j==0: letter(ax,'D',-.17,1.12)
    type_legend(fig.add_axes([.075,.515,.892,.055]),data)
    for bottom,top,mod,letters in [(.310,.480,'AA','EFG'),(.055,.225,'NT','HIJ')]:
        row=fig.add_gridspec(1,3,width_ratios=[1,1,1.14],wspace=.91,
                             left=.075,right=.967,bottom=bottom,top=top)
        for j,is_error in [(0,False),(1,True)]:
            ax=fig.add_subplot(row[j]); matrix_panel(ax,data,mod,is_error); letter(ax,letters[j],-.42,1.10)
        ax=fig.add_subplot(row[2]); error_pairs(ax,data,mod,show_legend=mod=='NT'); letter(ax,letters[2],-.56,1.10)
    save(fig,out,f'{data["domain"]}_AA_NT_full_length_composite')
    return matrix

def build_components(data,emb,out):
    panel=out/'individual_panels'; panel.mkdir(exist_ok=True)
    fig,ax=plt.subplots(figsize=(5.2,5.2),subplot_kw={'projection':'polar'})
    radar(ax,data); fig.legend(handles=model_legend(data),loc='lower center',ncol=2,frameon=False)
    fig.subplots_adjust(bottom=.16); save(fig,panel,f'{data["domain"]}_binary_radar')
    fig,ax=plt.subplots(figsize=(6.2,4.5)); grouped_bars(ax,data)
    ax.legend(handles=model_legend(data),loc='upper center',bbox_to_anchor=(.5,1.21),ncol=2,frameon=False)
    fig.subplots_adjust(top=.8,bottom=.16); save(fig,panel,f'{data["domain"]}_type_five_metrics')
    fig,ax=plt.subplots(figsize=(7.3,5.4 if data['domain']=='VF' else 4.4))
    type_heatmap(ax,data); fig.subplots_adjust(left=.34,right=.90,top=.87,bottom=.10)
    save(fig,panel,f'{data["domain"]}_type_precision_recall_f1')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5))
    for ax,avg in zip(axes,['macro','weighted']): grouped_bars(ax,data,'Subtype',avg)
    fig.legend(handles=model_legend(data),loc='upper center',ncol=2,frameon=False)
    fig.subplots_adjust(left=.06,right=.98,top=.83,bottom=.17,wspace=.25)
    save(fig,out,f'{data["domain"]}_subtype_five_metrics')
    for mod in ['AA','NT']:
        for error in [False,True]:
            fig,ax=plt.subplots(figsize=(7.3,6.2)); matrix_panel(ax,data,mod,error)
            fig.subplots_adjust(left=.28,right=.90,top=.88,bottom=.28)
            save(fig,panel,f'{data["domain"]}_{mod}_type_{"error_counts" if error else "confusion_matrix"}')
        fig,ax=plt.subplots(figsize=(8.5,6.0)); error_pairs(ax,data,mod,top=12)
        fig.subplots_adjust(left=.50,right=.98,top=.88,bottom=.21)
        save(fig,panel,f'{data["domain"]}_{mod}_subtype_error_pairs')

def build_epoch_figures(data,cache,out):
    trajectories=[]
    for mod in ['AA','NT']:
        model=data['models'][mod]
        regular=sorted([p for p in model['features'] if p.name.startswith('epoch_')])
        files=regular+[model['best']]
        fig=plt.figure(figsize=(20,5.7))
        gs=fig.add_gridspec(2,1,height_ratios=[4.,1.],hspace=.13,left=.035,right=.985,top=.91,bottom=.06)
        row=gs[0].subgridspec(1,len(files),wspace=.20)
        for j,path in enumerate(files):
            frame=embedding(data,mod,path,cache)
            title=f'Epoch {int(frame.epoch.iloc[0])}' if path!=model['best'] else f'Best model (epoch {model["best_epoch"]})'
            ax=fig.add_subplot(row[j]); plot_embedding(ax,frame,data,mod,title,j==0)
            trajectories.append({'Model':model['name'],'Snapshot':path.name,'Epoch':int(frame.epoch.iloc[0]),'N':len(frame)})
        type_legend(fig.add_subplot(gs[1]),data)
        save(fig,out/'individual_panels',f'{data["domain"]}_{mod}_UMAP_epochs')
    return trajectories

def exports(data,out,heatmap):
    dest=out/'plot_data'; dest.mkdir(exist_ok=True)
    data['main'].to_csv(dest/'overall_metrics.csv',index=False,encoding='utf-8-sig')
    data['all_avg'].to_csv(dest/'all_averages.csv',index=False,encoding='utf-8-sig')
    data['per'].to_csv(dest/'per_type_metrics.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame({'Type':data['labels'],'Display':[wrapped(l,24).replace('\n',' ') for l in data['labels']],
                  'Color':TYPE_COLORS[:len(data['labels'])]}).to_csv(dest/'type_palette.csv',index=False,encoding='utf-8-sig')
    for mod,v in data['models'].items():
        pd.DataFrame(v['cm'],index=data['labels'],columns=data['labels']+['Missed']).to_csv(dest/f'{mod}_type_confusion_counts.csv',encoding='utf-8-sig',index_label='True_type')
        pd.DataFrame(v['cm']/v['cm'].sum(axis=1,keepdims=True),index=data['labels'],columns=data['labels']+['Missed']).to_csv(dest/f'{mod}_type_confusion_proportions.csv',encoding='utf-8-sig',index_label='True_type')
        v['errors'].to_csv(dest/f'{mod}_all_subtype_error_pairs.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(data['sources']).to_csv(dest/'source_manifest.csv',index=False,encoding='utf-8-sig')

def captions(data):
    d=data['domain']; best=', '.join(f'{m} epoch {data["models"][m]["best_epoch"]}' for m in ['AA','NT'])
    return f'''# {d} figure notes

Figure. Performance of {d}Scope-AA and {d}Scope-NT on full-length test sequences. (A) Binary classification. (B) Type-level ACC, macro precision, macro recall, macro F1 and MCC. (C) Type-resolved precision, recall and F1. Average denotes the macro average over all {len(data['labels'])} biological types. (D) UMAP projections of test-positive representations before training and at the selected checkpoints ({best}). (E,H) Row-normalized type confusion matrices for AA and NT. (F,I) Type error counts with diagonal cells masked. Missed is a prediction outcome and is not a biological type or a reference-negative cohort. (G,J) The ten most frequent subtype error pairs among reference-positive test sequences. Percentages indicate the fraction retaining the correct type.

## 统计口径

- 雷达图的 Precision、Recall、F1 使用 macro，与最新论文表格一致。
- Type 仅包含真实阳性样本。真实 non-{d} 样本不进入 type 统计。预测为负类的漏检仍保留在 ACC、Recall、F1、MCC 和矩阵分母中。
- 两个模型使用完全相同的真实类别顺序。保留有测试样本的全部类别，AA/NT 某一方为零不删除整行，避免改变比较范围。
- 独立 Subtype 五指标图分别给出 macro 与 weighted。Subtype 使用全部测试样本，包含负类，与论文统计口径一致。
- 混淆矩阵的最后一列 Missed 单独表示漏检，不是新增 type。错误计数图的两种模型使用相同数值上限。
- UMAP 不参与性能计算。所有测试阳性样本均显示，类别不重采样。相同参数用于全部快照。PCA 50 维后使用 cosine UMAP，n_neighbors=25，min_dist=0.12，n_epochs=400，random_state=42。
- UMAP 面板独立拟合，坐标方向和位置不具有跨面板定量含义。选图不依据测试集表现或类别分离程度。
- VF 有 0、20、50 和最佳模型快照。BGC 只有 0、20 和最佳模型快照，最佳模型可能早于 epoch 20。缺失 epoch 不补造。
- 无其他模型结果，因此不加入虚构的对比模型。无重复试验或 bootstrap 置信区间，因此柱状图的纹理仅用于区分 AA/NT，不画虚构误差线。

原始预测和阈值未修改。输入文件哈希、绘图数据和 UMAP 坐标保存在 plot_data 内。
'''

def run(domain):
    WORK.mkdir(parents=True,exist_ok=True)
    data=read_domain(domain)
    out=WORK/domain; out.mkdir(parents=True,exist_ok=True)
    cache=out/'plot_data'/'umap'; cache.mkdir(parents=True,exist_ok=True)
    embeddings={}
    for mod in ['AA','NT']:
        for stage in ['initial','best']:
            embeddings[(mod,stage)]=embedding(data,mod,data['models'][mod][stage],cache)
    matrix=build_main(data,embeddings,out)
    build_components(data,embeddings,out)
    trajectories=build_epoch_figures(data,cache,out)
    exports(data,out,matrix)
    (out/'图注与统计说明.md').write_text(captions(data),encoding='utf-8')
    audit={'domain':domain,'all_saved_source_hashes_match':True,
       'all_main_metrics_independently_recomputed':True,'all_per_type_metrics_independently_recomputed':True,
       'all_averages_independently_recomputed':True,
       'same_test_ids_and_truth_as_authoritative_metadata':True,'reference_negative_excluded_from_type':True,
       'missed_positives_kept_in_denominator':True,'types':data['labels'],'umap_parameters':PARAMS,
       'snapshots':trajectories,'models':{m:{'name':v['name'],'n_test':len(v['rows']),
         'n_type_test':len(v['positive']),'missed':int(v['cm'][:,-1].sum()),
         'selected_epoch':v['best_epoch']} for m,v in data['models'].items()},'visual_review':'pending'}
    (out/'verification.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
    print(f'FIGURES_READY {domain} {out}',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--domain',choices=list(SPECS),required=True)
    parser.add_argument('--output-dir',type=Path,default=WORK)
    args=parser.parse_args(); WORK=args.output_dir.resolve(); run(args.domain)
