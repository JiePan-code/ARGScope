#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Build the ARG1:nonARG30 ORIGINAL-LEVEL train/test split from the
50aa/150nt 5-part simulated dataset.

IMPORTANT
---------
The five fragments from the same Original.SARG.Seq.ID are NEVER split
independently. Train/test assignment is generated once at original-sequence
level, stratified by Subtype, then inherited by all 5 fragments.

Split rule
----------
For every Subtype:
    - approximately 80% originals -> train
    - approximately 20% originals -> test
    - at least 2 train originals
    - at least 1 test original
    - if exactly 3 originals: 2 train + 1 test

The split is deterministic using a fixed seed and stable per-Subtype hashing.

Expected layout
---------------
noveldataset130/
├── 0.split_ARG1_nonARG30_150nt_by_original.py
└── ARG1_nonARG30/
    └── paired_simulated_fragments_5parts/
        └── fixed_50aa_150nt/
            ├── dna_150nt_5parts.fasta
            ├── protein_50aa_5parts.fasta
            ├── structure_50aa_150nt_5parts.txt
            └── simulation_summary.json

Outputs
-------
ARG1_nonARG30/
├── all_arg_nonarg_train_test_split.csv
└── paired_simulated_fragments_5parts/
    └── fixed_50aa_150nt/
        ├── structure_50aa_150nt_5parts_with_split.txt
        ├── split_summary_by_subtype.csv
        └── split_summary.json
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import re
from collections import Counter, defaultdict
from pathlib import Path


SCRIPT_VERSION = "2026-08-20-ARG1-nonARG30-original-level-split-150nt-v1"
SEED = 20260817
TEST_FRACTION = 0.20
EXPECTED_FRAGMENTS_PER_ORIGINAL = 5

SCRIPT_DIR = Path(__file__).resolve().parent

DATASET_ROOT = (
    SCRIPT_DIR
    / "ARG1_nonARG30"
)

FIXED_DIR = (
    DATASET_ROOT
    / "paired_simulated_fragments_5parts"
    / "fixed_50aa_150nt"
)

DNA_FASTA = (
    FIXED_DIR
    / "dna_150nt_5parts.fasta"
)

PROTEIN_FASTA = (
    FIXED_DIR
    / "protein_50aa_5parts.fasta"
)

STRUCTURE_FILE = (
    FIXED_DIR
    / "structure_50aa_150nt_5parts.txt"
)

OUTPUT_ORIGINAL_SPLIT = (
    DATASET_ROOT
    / "all_arg_nonarg_train_test_split.csv"
)

OUTPUT_FRAGMENT_STRUCTURE = (
    FIXED_DIR
    / "structure_50aa_150nt_5parts_with_split.txt"
)

OUTPUT_SUBTYPE_SUMMARY = (
    FIXED_DIR
    / "split_summary_by_subtype.csv"
)

OUTPUT_JSON = (
    FIXED_DIR
    / "split_summary.json"
)


def canonical_id(value: object) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def normalized_label(value: object) -> str:
    text = str(value).strip()

    if not text or text.lower() == "nan":
        return "nonARG"

    compact = re.sub(
        r"[^a-z0-9]",
        "",
        text.lower(),
    )

    if compact in {
        "nonarg",
        "nonresistance",
        "negative",
        "nonresistant",
    }:
        return "nonARG"

    return text


def stable_seed(
    base_seed: int,
    label: str,
) -> int:

    payload = (
        f"{base_seed}\0{label}"
        .encode(
            "utf-8"
        )
    )

    return int.from_bytes(
        hashlib.sha256(
            payload
        ).digest()[:8],
        "big",
    )


def read_fasta_ids(
    path: Path,
) -> list[str]:

    if not path.is_file():
        raise FileNotFoundError(
            f"FASTA not found: {path}"
        )

    ids = []

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line in handle:
            if line.startswith(">"):
                seq_id = canonical_id(
                    line[1:]
                )

                if not seq_id:
                    raise ValueError(
                        f"Empty FASTA ID in {path}"
                    )

                ids.append(
                    seq_id
                )

    if not ids:
        raise ValueError(
            f"No FASTA records found: {path}"
        )

    duplicate_count = (
        len(ids)
        - len(
            set(
                ids
            )
        )
    )

    if duplicate_count:
        raise ValueError(
            f"Duplicate FASTA IDs in {path}: "
            f"{duplicate_count:,}"
        )

    return ids


def read_structure(
    path: Path,
):

    if not path.is_file():
        raise FileNotFoundError(
            f"Structure not found: {path}"
        )

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                f"Structure has no header: {path}"
            )

        required = {
            "SARG.Seq.ID",
            "Subtype",
        }

        missing = sorted(
            required
            - set(
                reader.fieldnames
            )
        )

        if missing:
            raise ValueError(
                f"Structure missing columns: {missing}"
            )

        fieldnames = list(
            reader.fieldnames
        )

        rows = list(
            reader
        )

    if not rows:
        raise ValueError(
            f"Structure contains no rows: {path}"
        )

    return (
        fieldnames,
        rows,
    )


def get_original_id(
    row: dict[str, str],
) -> str:

    if "Original.SARG.Seq.ID" in row:
        value = canonical_id(
            row.get(
                "Original.SARG.Seq.ID",
                "",
            )
        )

        if value:
            return value

    fragment_id = canonical_id(
        row.get(
            "SARG.Seq.ID",
            "",
        )
    )

    # Defensive fallback for older simulated IDs.
    original_id = re.sub(
        r"__SIM_.*$",
        "",
        fragment_id,
    )

    if not original_id:
        raise ValueError(
            f"Cannot derive Original.SARG.Seq.ID from fragment: {fragment_id}"
        )

    return original_id


def choose_test_count(
    number_originals: int,
) -> int:

    if number_originals < 3:
        raise ValueError(
            "Every Subtype must have at least 3 original sequences "
            f"for 2-train/1-test splitting; observed {number_originals}."
        )

    if number_originals == 3:
        return 1

    number_test = int(
        math.floor(
            number_originals
            * TEST_FRACTION
            + 0.5
        )
    )

    number_test = max(
        1,
        number_test,
    )

    # Always retain at least two training originals.
    number_test = min(
        number_test,
        number_originals - 2,
    )

    return number_test


def main() -> None:

    print(
        "=" * 110,
        flush=True,
    )

    print(
        "ARG1:nonARG30 ORIGINAL-LEVEL TRAIN/TEST SPLIT FROM 50aa/150nt",
        flush=True,
    )

    print(
        "=" * 110,
        flush=True,
    )

    print(
        f"Script version : {SCRIPT_VERSION}",
        flush=True,
    )

    print(
        f"DNA FASTA      : {DNA_FASTA}",
        flush=True,
    )

    print(
        f"Protein FASTA  : {PROTEIN_FASTA}",
        flush=True,
    )

    print(
        f"Structure      : {STRUCTURE_FILE}",
        flush=True,
    )

    print(
        f"Output split   : {OUTPUT_ORIGINAL_SPLIT}",
        flush=True,
    )

    print(
        f"Seed           : {SEED}",
        flush=True,
    )

    print(
        f"Target split   : train ~{1.0-TEST_FRACTION:.0%}, "
        f"test ~{TEST_FRACTION:.0%}",
        flush=True,
    )

    # -----------------------------------------------------------------
    # 1. Audit FASTA / structure fragment IDs.
    # -----------------------------------------------------------------

    dna_ids = read_fasta_ids(
        DNA_FASTA
    )

    protein_ids = read_fasta_ids(
        PROTEIN_FASTA
    )

    structure_fields, structure_rows = read_structure(
        STRUCTURE_FILE
    )

    structure_ids = [
        canonical_id(
            row[
                "SARG.Seq.ID"
            ]
        )
        for row
        in structure_rows
    ]

    if len(
        structure_ids
    ) != len(
        set(
            structure_ids
        )
    ):
        raise ValueError(
            "Duplicate SARG.Seq.ID values in fragment structure."
        )

    dna_set = set(
        dna_ids
    )

    protein_set = set(
        protein_ids
    )

    structure_set = set(
        structure_ids
    )

    if not (
        dna_set
        == protein_set
        == structure_set
    ):
        raise ValueError(
            "DNA / Protein / Structure fragment ID sets differ.\n"
            f"DNA={len(dna_set):,}, "
            f"Protein={len(protein_set):,}, "
            f"Structure={len(structure_set):,}\n"
            f"DNA-only={len(dna_set-protein_set-structure_set):,}, "
            f"Protein-only={len(protein_set-dna_set-structure_set):,}, "
            f"Structure-only={len(structure_set-dna_set-protein_set):,}"
        )

    print()
    print(
        "===== FRAGMENT ID AUDIT =====",
        flush=True,
    )

    print(
        f"DNA fragments       : {len(dna_ids):,}",
        flush=True,
    )

    print(
        f"Protein fragments   : {len(protein_ids):,}",
        flush=True,
    )

    print(
        f"Structure fragments : {len(structure_rows):,}",
        flush=True,
    )

    print(
        "Fragment ID sets    : IDENTICAL",
        flush=True,
    )

    # -----------------------------------------------------------------
    # 2. Reconstruct original-level metadata.
    # -----------------------------------------------------------------

    original_metadata: dict[
        str,
        tuple[
            str,
            str,
        ],
    ] = {}

    original_fragment_counts: Counter = Counter()

    for line_number, row in enumerate(
        structure_rows,
        start=2,
    ):

        fragment_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        original_id = get_original_id(
            row
        )

        subtype = normalized_label(
            row.get(
                "Subtype",
                "",
            )
        )

        type_name = normalized_label(
            row.get(
                "Type",
                "",
            )
        ) if "Type" in row else ""

        if not fragment_id:
            raise ValueError(
                f"Empty fragment ID at structure line {line_number}"
            )

        if not subtype:
            raise ValueError(
                f"Empty Subtype at structure line {line_number}"
            )

        metadata = (
            type_name,
            subtype,
        )

        previous = original_metadata.get(
            original_id
        )

        if (
            previous is not None
            and previous != metadata
        ):
            raise ValueError(
                "One Original.SARG.Seq.ID maps to inconsistent Type/Subtype:\n"
                f"Original={original_id}\n"
                f"previous={previous}\n"
                f"current={metadata}"
            )

        original_metadata[
            original_id
        ] = metadata

        original_fragment_counts[
            original_id
        ] += 1

    wrong_fragment_counts = {
        original_id:
            count
        for original_id, count
        in original_fragment_counts.items()
        if count
        != EXPECTED_FRAGMENTS_PER_ORIGINAL
    }

    if wrong_fragment_counts:
        examples = list(
            wrong_fragment_counts.items()
        )[:20]

        raise ValueError(
            "The 5-part simulation is inconsistent: "
            f"{len(wrong_fragment_counts):,} originals do not have exactly "
            f"{EXPECTED_FRAGMENTS_PER_ORIGINAL} fragments. "
            f"Examples={examples}"
        )

    subtype_to_originals: dict[
        str,
        list[
            str
        ],
    ] = defaultdict(
        list
    )

    for original_id, (
        _type_name,
        subtype,
    ) in original_metadata.items():

        subtype_to_originals[
            subtype
        ].append(
            original_id
        )

    print()
    print(
        "===== ORIGINAL-LEVEL DATASET =====",
        flush=True,
    )

    print(
        f"Unique originals     : {len(original_metadata):,}",
        flush=True,
    )

    print(
        f"Unique Subtypes      : {len(subtype_to_originals):,}",
        flush=True,
    )

    print(
        f"Fragments/original   : {EXPECTED_FRAGMENTS_PER_ORIGINAL}",
        flush=True,
    )

    if "nonARG" in subtype_to_originals:
        print(
            f"nonARG originals     : {len(subtype_to_originals['nonARG']):,}",
            flush=True,
        )

    arg_originals = sum(
        len(originals)
        for subtype, originals
        in subtype_to_originals.items()
        if subtype
        != "nonARG"
    )

    nonarg_originals = len(
        subtype_to_originals.get(
            "nonARG",
            [],
        )
    )

    print(
        f"ARG originals        : {arg_originals:,}",
        flush=True,
    )

    print(
        f"nonARG originals     : {nonarg_originals:,}",
        flush=True,
    )

    if arg_originals > 0:
        print(
            f"Observed ARG:nonARG  : 1:{nonarg_originals/arg_originals:.4f}",
            flush=True,
        )

    # -----------------------------------------------------------------
    # 3. Deterministic Subtype-stratified original-level split.
    # -----------------------------------------------------------------

    original_to_split: dict[
        str,
        str,
    ] = {}

    subtype_summary_rows = []

    for subtype in sorted(
        subtype_to_originals
    ):

        originals = sorted(
            subtype_to_originals[
                subtype
            ]
        )

        number_total = len(
            originals
        )

        number_test = choose_test_count(
            number_total
        )

        rng = random.Random(
            stable_seed(
                SEED,
                subtype,
            )
        )

        shuffled = list(
            originals
        )

        rng.shuffle(
            shuffled
        )

        test_ids = set(
            shuffled[
                :number_test
            ]
        )

        train_ids = set(
            shuffled[
                number_test:
            ]
        )

        if len(
            train_ids
        ) < 2:
            raise RuntimeError(
                f"Subtype {subtype!r} has fewer than 2 train originals."
            )

        if len(
            test_ids
        ) < 1:
            raise RuntimeError(
                f"Subtype {subtype!r} has no test original."
            )

        if (
            train_ids
            & test_ids
        ):
            raise RuntimeError(
                f"Train/test leakage inside Subtype {subtype!r}"
            )

        for original_id in train_ids:
            if original_id in original_to_split:
                raise RuntimeError(
                    f"Original ID assigned twice: {original_id}"
                )

            original_to_split[
                original_id
            ] = "train"

        for original_id in test_ids:
            if original_id in original_to_split:
                raise RuntimeError(
                    f"Original ID assigned twice: {original_id}"
                )

            original_to_split[
                original_id
            ] = "test"

        type_names = {
            original_metadata[
                original_id
            ][0]
            for original_id
            in originals
        }

        if len(
            type_names
        ) > 1:
            raise ValueError(
                f"Subtype {subtype!r} maps to multiple Types: "
                f"{sorted(type_names)}"
            )

        type_name = (
            next(
                iter(
                    type_names
                )
            )
            if type_names
            else ""
        )

        subtype_summary_rows.append(
            {
                "Type":
                    type_name,

                "Subtype":
                    subtype,

                "total_originals":
                    number_total,

                "train_originals":
                    len(
                        train_ids
                    ),

                "test_originals":
                    len(
                        test_ids
                    ),

                "train_fragments":
                    len(
                        train_ids
                    )
                    * EXPECTED_FRAGMENTS_PER_ORIGINAL,

                "test_fragments":
                    len(
                        test_ids
                    )
                    * EXPECTED_FRAGMENTS_PER_ORIGINAL,

                "test_fraction":
                    len(
                        test_ids
                    )
                    / number_total,
            }
        )

    if set(
        original_to_split
    ) != set(
        original_metadata
    ):
        raise RuntimeError(
            "Not all originals received a train/test assignment."
        )

    train_originals = {
        original_id
        for original_id, split
        in original_to_split.items()
        if split
        == "train"
    }

    test_originals = {
        original_id
        for original_id, split
        in original_to_split.items()
        if split
        == "test"
    }

    if train_originals & test_originals:
        raise RuntimeError(
            "Original-level train/test leakage detected."
        )

    # Every subtype must exist in both train and test.
    for subtype, originals in subtype_to_originals.items():

        observed_train = sum(
            original_id
            in train_originals
            for original_id
            in originals
        )

        observed_test = sum(
            original_id
            in test_originals
            for original_id
            in originals
        )

        if observed_train < 2:
            raise RuntimeError(
                f"Subtype {subtype!r}: train originals={observed_train}"
            )

        if observed_test < 1:
            raise RuntimeError(
                f"Subtype {subtype!r}: test originals={observed_test}"
            )

    # -----------------------------------------------------------------
    # 4. Write original-level split CSV used by Fusion.
    # -----------------------------------------------------------------

    OUTPUT_ORIGINAL_SPLIT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    original_rows = []

    for original_id in sorted(
        original_metadata
    ):

        type_name, subtype = original_metadata[
            original_id
        ]

        original_rows.append(
            {
                "SARG.Seq.ID":
                    original_id,

                "Type":
                    type_name,

                "Subtype":
                    subtype,

                "Split":
                    original_to_split[
                        original_id
                    ],
            }
        )

    with OUTPUT_ORIGINAL_SPLIT.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        fieldnames = [
            "SARG.Seq.ID",
            "Type",
            "Subtype",
            "Split",
        ]

        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        writer.writerows(
            original_rows
        )

    # -----------------------------------------------------------------
    # 5. Write fragment structure with inherited split for auditing.
    # -----------------------------------------------------------------

    output_fragment_fields = list(
        structure_fields
    )

    if "Split" not in output_fragment_fields:
        output_fragment_fields.append(
            "Split"
        )

    fragment_split_counts = Counter()

    with OUTPUT_FRAGMENT_STRUCTURE.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=output_fragment_fields,
            delimiter="\t",
            lineterminator="\n",
        )

        writer.writeheader()

        for raw in structure_rows:

            row = dict(
                raw
            )

            original_id = get_original_id(
                row
            )

            split = original_to_split[
                original_id
            ]

            row[
                "Split"
            ] = split

            fragment_split_counts[
                split
            ] += 1

            writer.writerow(
                row
            )

    # -----------------------------------------------------------------
    # 6. Write Subtype summary.
    # -----------------------------------------------------------------

    with OUTPUT_SUBTYPE_SUMMARY.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        fieldnames = [
            "Type",
            "Subtype",
            "total_originals",
            "train_originals",
            "test_originals",
            "train_fragments",
            "test_fragments",
            "test_fraction",
        ]

        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        writer.writerows(
            subtype_summary_rows
        )

    summary = {
        "script_version":
            SCRIPT_VERSION,

        "seed":
            SEED,

        "target_test_fraction":
            TEST_FRACTION,

        "expected_fragments_per_original":
            EXPECTED_FRAGMENTS_PER_ORIGINAL,

        "total_fragments":
            len(
                structure_rows
            ),

        "total_originals":
            len(
                original_metadata
            ),

        "ARG_originals":
            arg_originals,

        "nonARG_originals":
            nonarg_originals,

        "ARG_nonARG_ratio":
            (
                f"1:{nonarg_originals/arg_originals:.8f}"
                if arg_originals
                else None
            ),

        "number_subtypes_including_nonARG":
            len(
                subtype_to_originals
            ),

        "number_ARG_subtypes":
            len(
                [
                    subtype
                    for subtype
                    in subtype_to_originals
                    if subtype
                    != "nonARG"
                ]
            ),

        "train_originals":
            len(
                train_originals
            ),

        "test_originals":
            len(
                test_originals
            ),

        "train_fragments":
            int(
                fragment_split_counts[
                    "train"
                ]
            ),

        "test_fragments":
            int(
                fragment_split_counts[
                    "test"
                ]
            ),

        "original_level_leakage":
            False,

        "DNA_Protein_Structure_fragment_ID_sets_identical":
            True,

        "original_split_file":
            str(
                OUTPUT_ORIGINAL_SPLIT
            ),

        "fragment_structure_with_split":
            str(
                OUTPUT_FRAGMENT_STRUCTURE
            ),
    }

    with OUTPUT_JSON.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            summary,
            handle,
            ensure_ascii=False,
            indent=2,
        )

    print()
    print(
        "=" * 110,
        flush=True,
    )

    print(
        "SPLIT COMPLETED",
        flush=True,
    )

    print(
        "=" * 110,
        flush=True,
    )

    print(
        f"Total originals     : {len(original_metadata):,}",
        flush=True,
    )

    print(
        f"Train originals     : {len(train_originals):,}",
        flush=True,
    )

    print(
        f"Test originals      : {len(test_originals):,}",
        flush=True,
    )

    print(
        f"Train fragments     : {fragment_split_counts['train']:,}",
        flush=True,
    )

    print(
        f"Test fragments      : {fragment_split_counts['test']:,}",
        flush=True,
    )

    print(
        f"ARG Subtypes        : "
        f"{len([x for x in subtype_to_originals if x != 'nonARG']):,}",
        flush=True,
    )

    print(
        f"Subtypes + nonARG   : {len(subtype_to_originals):,}",
        flush=True,
    )

    print(
        "Original leakage    : NONE",
        flush=True,
    )

    print()
    print(
        f"Fusion split file   : {OUTPUT_ORIGINAL_SPLIT}",
        flush=True,
    )

    print(
        f"Fragment audit file : {OUTPUT_FRAGMENT_STRUCTURE}",
        flush=True,
    )

    print(
        f"Subtype summary     : {OUTPUT_SUBTYPE_SUMMARY}",
        flush=True,
    )

    print(
        f"JSON summary        : {OUTPUT_JSON}",
        flush=True,
    )


if __name__ == "__main__":
    main()
