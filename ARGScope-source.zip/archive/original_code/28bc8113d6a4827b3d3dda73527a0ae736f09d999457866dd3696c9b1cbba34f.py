#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Calculate overall Type-level metrics from sequence-level predictions.

Place this script beside test_sequence_predictions.csv and run it directly.
The same script works in both DNA_student_VF and Protein_student_VF folders.

The output contains exactly three averaging rows: micro, weighted, and macro.
Accuracy and multiclass MCC are global metrics and therefore have the same
value in all three rows. Precision, recall, and F1 use the requested averaging
method in each row.
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = SCRIPT_DIR / "test_sequence_predictions.csv"

TRUE_COLUMN = "true_type"
PREDICTED_COLUMN = "predicted_type"
AVERAGES = ("micro", "weighted", "macro")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Calculate Type-level Accuracy, Precision, Recall, F1, and MCC "
            "from test_sequence_predictions.csv."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT,
        help="Sequence-level prediction CSV.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help=(
            "Output CSV. By default, type_level_five_metrics.csv is written "
            "beside the input file."
        ),
    )
    parser.add_argument(
        "--split",
        default="test",
        help=(
            "Value retained from the split column. Default: test. "
            "Use 'all' to disable split filtering."
        ),
    )
    return parser.parse_args()


def safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def multiclass_mcc(
    labels: list[str],
    true_counts: Counter,
    predicted_counts: Counter,
    true_positive_counts: dict[str, int],
    total: int,
) -> float:
    """Calculate the standard multiclass Matthews correlation coefficient."""

    correct = sum(true_positive_counts.values())
    predicted_true_product = sum(
        predicted_counts[label] * true_counts[label]
        for label in labels
    )
    predicted_square_sum = sum(
        predicted_counts[label] ** 2
        for label in labels
    )
    true_square_sum = sum(
        true_counts[label] ** 2
        for label in labels
    )

    numerator = correct * total - predicted_true_product
    denominator = math.sqrt(
        (total**2 - predicted_square_sum)
        * (total**2 - true_square_sum)
    )
    return safe_divide(numerator, denominator)


def main() -> None:
    args = parse_args()
    input_csv = args.input.expanduser().resolve()

    if not input_csv.is_file():
        raise FileNotFoundError(f"Input CSV not found: {input_csv}")

    output_csv = (
        args.output.expanduser().resolve()
        if args.output is not None
        else input_csv.with_name("type_level_five_metrics.csv")
    )

    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("The input CSV has no header row.")

        required_columns = {TRUE_COLUMN, PREDICTED_COLUMN}
        missing_columns = sorted(required_columns.difference(reader.fieldnames))
        if missing_columns:
            raise ValueError(
                "Missing required column(s): " + ", ".join(missing_columns)
            )

        if args.split.lower() != "all" and "split" not in reader.fieldnames:
            raise ValueError(
                "--split was requested, but the CSV has no 'split' column. "
                "Use --split all only if every row should be evaluated."
            )

        rows = list(reader)

    available_splits = sorted(
        {
            row.get("split", "").strip()
            for row in rows
            if row.get("split", "").strip()
        }
    )
    if args.split.lower() != "all":
        rows = [
            row
            for row in rows
            if row.get("split", "").strip() == args.split
        ]
        if not rows:
            raise ValueError(
                f"No rows found for split={args.split!r}. "
                f"Available split values: {available_splits}"
            )

    y_true = [row[TRUE_COLUMN].strip() for row in rows]
    y_pred = [row[PREDICTED_COLUMN].strip() for row in rows]

    invalid_label_count = sum(
        not true_label or not predicted_label
        for true_label, predicted_label in zip(y_true, y_pred)
    )
    if invalid_label_count:
        raise ValueError(
            f"Found {invalid_label_count} row(s) with missing Type labels."
        )

    if "id" in reader.fieldnames:
        ids = [row.get("id", "").strip() for row in rows]
        invalid_id_count = sum(not sequence_id for sequence_id in ids)
        if invalid_id_count:
            raise ValueError(
                f"Found {invalid_id_count} row(s) with missing IDs."
            )

        duplicate_count = len(ids) - len(set(ids))
        if duplicate_count:
            raise ValueError(
                f"Found {duplicate_count} duplicated sequence ID row(s)."
            )

    labels = sorted(set(y_true).union(y_pred))

    total = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive_counts = {
        label: sum(
            true_label == label and predicted_label == label
            for true_label, predicted_label in zip(y_true, y_pred)
        )
        for label in labels
    }

    per_class = {}
    for label in labels:
        true_positive = true_positive_counts[label]
        precision = safe_divide(true_positive, predicted_counts[label])
        recall = safe_divide(true_positive, true_counts[label])
        f1 = safe_divide(2.0 * precision * recall, precision + recall)
        per_class[label] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
        }

    correct = sum(true_positive_counts.values())
    accuracy = safe_divide(correct, total)
    mcc = multiclass_mcc(
        labels,
        true_counts,
        predicted_counts,
        true_positive_counts,
        total,
    )

    true_positive_sum = correct
    false_positive_sum = sum(
        predicted_counts[label] - true_positive_counts[label]
        for label in labels
    )
    false_negative_sum = sum(
        true_counts[label] - true_positive_counts[label]
        for label in labels
    )

    micro_precision = safe_divide(
        true_positive_sum,
        true_positive_sum + false_positive_sum,
    )
    micro_recall = safe_divide(
        true_positive_sum,
        true_positive_sum + false_negative_sum,
    )
    micro_f1 = safe_divide(
        2.0 * micro_precision * micro_recall,
        micro_precision + micro_recall,
    )

    result_rows = []
    for average in AVERAGES:
        if average == "micro":
            precision = micro_precision
            recall = micro_recall
            f1 = micro_f1
        elif average == "weighted":
            precision = sum(
                per_class[label]["precision"] * true_counts[label]
                for label in labels
            ) / total
            recall = sum(
                per_class[label]["recall"] * true_counts[label]
                for label in labels
            ) / total
            f1 = sum(
                per_class[label]["f1"] * true_counts[label]
                for label in labels
            ) / total
        else:
            precision = sum(
                per_class[label]["precision"]
                for label in labels
            ) / len(labels)
            recall = sum(
                per_class[label]["recall"]
                for label in labels
            ) / len(labels)
            f1 = sum(
                per_class[label]["f1"]
                for label in labels
            ) / len(labels)

        result_rows.append(
            {
                "level": "Type",
                "average": average,
                "accuracy": f"{accuracy:.8f}",
                "precision": f"{precision:.8f}",
                "recall": f"{recall:.8f}",
                "f1": f"{f1:.8f}",
                "mcc": f"{mcc:.8f}",
                "n_sequences": total,
                "n_classes": len(labels),
            }
        )

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "level",
        "average",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
        "n_sequences",
        "n_classes",
    ]
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(result_rows)

    print("\nType-level metrics")
    print(
        f"{'average':<10} {'accuracy':>10} {'precision':>10} "
        f"{'recall':>10} {'f1':>10} {'mcc':>10}"
    )
    for row in result_rows:
        print(
            f"{row['average']:<10} {row['accuracy']:>10} "
            f"{row['precision']:>10} {row['recall']:>10} "
            f"{row['f1']:>10} {row['mcc']:>10}"
        )

    print(f"\nEvaluated sequences: {total:,}")
    print(f"Type classes: {len(labels)}")
    print("Classes: " + ", ".join(labels))
    print(f"Output: {output_csv}")
    print(
        "Note: Accuracy and multiclass MCC are global metrics, so their "
        "values are repeated across the three averaging rows."
    )


if __name__ == "__main__":
    main()
