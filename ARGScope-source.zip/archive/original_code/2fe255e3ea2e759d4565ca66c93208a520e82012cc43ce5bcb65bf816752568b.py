"""Render canonical panels once and assemble their identical pixels/vectors."""
from pathlib import Path
import copy
import io
import json
import re
import shutil
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import to_hex
from matplotlib.patches import Patch
from matplotlib.text import Text
from PIL import Image
import redraw_vf_bgc_typebars_only_20260925 as previous

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/vf_bgc_unified_black_20260926'
base, old = previous.base, previous.old
base.OUT = OUT
original_wrapped = old.wrapped
old.wrapped = lambda value: 'Effector delivery\nsystem' if value == 'Effector delivery system' else original_wrapped(value)
PANELS = [
    ('VF_dataset_types', 'VF', 'dataset', (30, 30, 1200, 1260)),
    ('BGC_dataset_types', 'BGC', 'dataset', (1250, 30, 1200, 1260)),
    ('VF_binary', 'VF', 'binary', (30, 1320, 590, 780)),
    ('VF_subtype_weighted', 'VF', 'subtype', (640, 1320, 590, 780)),
    ('BGC_binary', 'BGC', 'binary', (1250, 1320, 590, 780)),
    ('BGC_subtype_weighted', 'BGC', 'subtype', (1860, 1320, 590, 780)),
    ('VF_type', 'VF', 'type', (30, 2130, 1275, 1348)),
    ('BGC_type', 'BGC', 'type', (1335, 2130, 1115, 1348)),
]
AUDIT = {'panels': [], 'composition': [], 'no_panel_letters': True}
SVGNS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', SVGNS)
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')


def text(fig, x, y, value, fs=10, **kwargs):
    return base.text(fig, x, y, value, size=fs, color='#000000', **kwargs)


def legend(fig, top, dataset=False):
    w, h = fig.get_size_inches()
    if dataset:
        handles = [Patch(facecolor=base.SPLIT_COLORS[s], label=base.SPLIT_NAMES[s]) for s in base.SPLITS]
    else:
        handles = [Patch(facecolor=old.LIGHT[s], edgecolor=old.COLORS[s],
                         hatch='///' if s == 'NT' else None, label=s) for s in ['AA', 'NT']]
    fig.legend(handles=handles, ncol=len(handles), loc='upper center',
               bbox_to_anchor=(.50, 1-top/h), frameon=False, fontsize=9.3,
               handlelength=1.3, columnspacing=1.0, handletextpad=.4, borderaxespad=0)


def draw_panel(name, domain, kind, dims, data):
    _, _, px, py = dims
    fig = plt.figure(figsize=(px/300, py/300), dpi=160, facecolor='none')
    fig.set_label(name)
    base.base_canvas(fig)
    w, h = fig.get_size_inches()
    if kind == 'dataset':
        text(fig, w/2, .10, f'{domain} sequences by functional type', fs=10.5, ha='center', weight='bold')
        legend(fig, .42, dataset=True)
        left = 1.68 if domain == 'VF' else .83
        previous.type_bars(fig, domain, data, [left, .83, w-left-.12, 2.94],
                           label_size=10, number_size=9.5)
    elif kind in ['binary', 'subtype']:
        title = f'{domain}/non-{domain}\nclassification' if kind == 'binary' else f'{domain} subtype\n(weighted)'
        text(fig, w/2, .07, title, fs=10.5, ha='center', linespacing=1.05)
        legend(fig, .45)
        if kind == 'binary':
            ax = old.radar(fig, domain, data[domain], [.50, .94, 1.16, 1.16], small=True)
            ax.set_rlabel_position(0)
            for label in ax.get_xticklabels():
                label.set_fontsize(9.4)
            text(fig, w/2, 2.41, 'P/R/F1: positive class', fs=8.1, ha='center')
        else:
            ax = old.bars(fig, domain, data[domain], [.34, .81, w-.45, 1.40], small=True)
            ax.tick_params(axis='both', labelsize=9.2)
            text(fig, w/2, 2.47, 'P/R/F1: weighted', fs=8.1, ha='center')
    else:
        text(fig, w/2, .09, f'{domain} type-level performance', fs=11, ha='center', weight='bold')
        left, width = (1.36, 2.50) if domain == 'VF' else (.79, 2.54)
        ax = old.heatmap(fig, domain, data[domain], [left, .62, width, 3.15], small=True)
        for label in ax.texts:
            label.set_fontsize(9.25 if label.get_gid() else 10.5)
        ax.tick_params(axis='y', labelsize=9.2, pad=3)
        ax.tick_params(axis='x', labelsize=9.8)
        text(fig, w/2, 4.05, 'AA: protein; NT: DNA', fs=9.1, ha='center')
        text(fig, w/2, 4.25, 'Average: macro across types\nand the non-target class',
             fs=8.8, ha='center', linespacing=1.05)
    # Heat-cell contrast stays black/white; all other text is pure black.
    for label in fig.findobj(match=Text):
        if not (label.get_gid() and '-heat-' in label.get_gid()):
            label.set_color('#000000')
    for ax in fig.axes:
        for collection in ax.collections:
            collection.set_rasterized(False)
    return fig


def verify_panel(fig):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    w, h = fig.canvas.get_width_height()
    outside, bad_colors, panel_letters = [], [], []
    for label in fig.findobj(match=Text):
        value = label.get_text().strip()
        if not value or not label.get_visible():
            continue
        bb = label.get_window_extent(renderer)
        if bb.width and bb.height and (bb.x0 < -1 or bb.y0 < -1 or bb.x1 > w+1 or bb.y1 > h+1):
            outside.append(value)
        is_heat_value = label.get_gid() and '-heat-' in label.get_gid()
        if not is_heat_value and to_hex(label.get_color()).lower() != '#000000':
            bad_colors.append(value)
        if value in set('ABCDEFGH'):
            panel_letters.append(value)
    assert not outside, (fig.get_label(), 'outside', outside)
    assert not bad_colors, (fig.get_label(), 'nonblack', bad_colors)
    assert not panel_letters
    # Check neighboring four-decimal cell annotations do not touch.
    for ax in fig.axes:
        labels = [t for t in ax.texts if t.get_gid() and '-heat-' in t.get_gid()]
        for a, b in zip(labels, labels[1:]):
            if a.get_position()[1] == b.get_position()[1]:
                assert not a.get_window_extent(renderer).overlaps(b.get_window_extent(renderer)), (fig.get_label(), 'heat text overlap')
    return {'name': fig.get_label(), 'outside_canvas': outside,
            'peripheral_text': '#000000', 'panel_letters_absent': True}


def save_rgba(name, rgba):
    rgba.save(OUT/f'{name}_transparent.tif', dpi=(300, 300), compression='tiff_lzw')
    white = Image.new('RGBA', rgba.size, 'white')
    white.alpha_composite(rgba)
    white.convert('RGB').save(OUT/f'{name}_white.tif', dpi=(300, 300), compression='tiff_lzw')
    preview = white.convert('RGB')
    preview.thumbnail((1488, 2105), Image.Resampling.LANCZOS)
    preview.save(OUT/'previews'/f'{name}.png')


def export_panel(fig):
    audit = verify_panel(fig)
    name = fig.get_label()
    image_buffer = io.BytesIO()
    fig.savefig(image_buffer, format='png', dpi=300, transparent=True)
    image_buffer.seek(0)
    rgba = Image.open(image_buffer).convert('RGBA')
    save_rgba(name, rgba)
    for folder, mode in [('editable_svg', 'none'), ('svg', 'path')]:
        with plt.rc_context({'svg.fonttype': mode, 'svg.hashsalt': name}):
            fig.savefig(OUT/folder/f'{name}.svg', transparent=True)
    fig.savefig(OUT/'pdf'/f'{name}.pdf', transparent=True)
    audit['pixels'] = list(rgba.size)
    AUDIT['panels'].append(audit)
    plt.close(fig)
    print(f'Panel: {name}', flush=True)
    return rgba


def assemble_svg(name, pixels, placements, folder):
    # Embed the exact exported panel vector nodes without replotting/rescaling.
    width, height = [n*.24 for n in pixels]
    root = ET.Element(f'{{{SVGNS}}}svg', {'width':f'{width:g}pt', 'height':f'{height:g}pt',
                                       'viewBox':f'0 0 {width:g} {height:g}', 'version':'1.1'})
    for index, (key, x, y) in enumerate(placements):
        source = ET.parse(OUT/folder/f'{key}.svg').getroot()
        prefix = f'p{index}_{key}_'
        id_map = {node.attrib['id']:prefix+node.attrib['id'] for node in source.iter() if 'id' in node.attrib}
        for node in source.iter():
            for attr, value in list(node.attrib.items()):
                if attr == 'id':
                    node.set(attr, id_map[value])
                else:
                    value = re.sub(r'url\(#([^)]*)\)', lambda m: f'url(#{id_map.get(m.group(1), m.group(1))})', value)
                    if value.startswith('#') and value[1:] in id_map:
                        value = '#'+id_map[value[1:]]
                    node.set(attr, value)
        source.set('x', f'{x*.24:g}')
        source.set('y', f'{y*.24:g}')
        source.set('overflow', 'hidden')
        root.append(source)
    ET.ElementTree(root).write(OUT/folder/f'{name}.svg', encoding='utf-8', xml_declaration=True)
    assert not any(node.tag.endswith('image') for node in root.iter()), 'Combined SVG must remain vector'


def compose(name, size, placements, images):
    canvas = Image.new('RGBA', size, (0,0,0,0))
    for key, x, y in placements:
        canvas.paste(images[key], (x,y))
    for key, x, y in placements:
        im = images[key]
        assert np.array_equal(np.asarray(canvas.crop((x,y,x+im.width,y+im.height))), np.asarray(im)), key
    save_rgba(name, canvas)
    for folder in ['editable_svg', 'svg']:
        assemble_svg(name, size, placements, folder)
    AUDIT['composition'].append({'name':name, 'pixels':list(size),
                                  'all_panel_pixels_identical': True,
                                  'svg_uses_same_panel_nodes': True, 'no_panel_rescaling': True})


def main():
    for subdir in ['', 'data', 'previews', 'editable_svg', 'svg', 'pdf', 'code']:
        (OUT/subdir).mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family':'Arial', 'font.size':10, 'text.color':'#000000',
                         'axes.labelcolor':'#000000', 'xtick.color':'#000000', 'ytick.color':'#000000',
                         'hatch.linewidth':.4, 'pdf.fonttype':42})
    data = base.load_data()
    images = {}
    for name, domain, kind, dims in PANELS:
        images[name] = export_panel(draw_panel(name, domain, kind, dims, data))
        assert images[name].size == dims[2:]
    placements = [(name, dims[0], dims[1]) for name, _, _, dims in PANELS]
    compose('VF_BGC_unified_black_A4_300DPI', (2480,3508), placements, images)
    compose('Dataset_types_VF_BGC', (2480,1320), placements[:2], images)
    for mode in ['white', 'transparent']:
        with Image.open(OUT/f'VF_BGC_unified_black_A4_300DPI_{mode}.tif') as master:
            assert master.size == (2480, 3508) and tuple(master.info['dpi']) == (300, 300)
            for key, x, y in placements:
                with Image.open(OUT/f'{key}_{mode}.tif') as panel:
                    assert tuple(panel.info['dpi']) == (300, 300)
                    np.testing.assert_array_equal(np.asarray(master.crop((x,y,x+panel.width,y+panel.height))),
                                                  np.asarray(panel))
    for folder in ['editable_svg', 'svg']:
        doc = ET.parse(OUT/folder/'VF_BGC_unified_black_A4_300DPI.svg').getroot()
        all_ids = [node.attrib['id'] for node in doc.iter() if 'id' in node.attrib]
        assert len(all_ids) == len(set(all_ids))
        for node in doc.iter():
            for attr, value in node.attrib.items():
                refs = re.findall(r'url\(#([^)]*)\)', value)
                if attr.endswith('href') and value.startswith('#'):
                    refs.append(value[1:])
                assert set(refs) <= set(all_ids), refs
    prior_data = ROOT/'outputs/vf_bgc_no_panel_labels_20260925/data'
    for file in (OUT/'data').glob('*.csv'):
        assert base.sha(file) == base.sha(prior_data/file.name), file.name
    assert all(base.sha(Path(path)) == digest for path,digest in base.HASHES.items())
    AUDIT.update({'datasets':base.AUDIT['datasets'], 'metrics':base.AUDIT['metrics'],
                  'source_sha256':base.HASHES, 'source_files_unmodified':True,
                  'metric_scheme_unchanged':True, 'binary':'positive class',
                  'subtype':'weighted', 'type_heatmap_average':'macro',
                  'saved_TIFF_regions_exactly_match_all_8_panels':True,
                  'saved_TIFF_dpi_verified':300, 'SVG_ids_unique_and_references_valid':True,
                  'all_plot_data_CSVs_match_previous_version':True})
    (OUT/'verification.json').write_text(json.dumps(AUDIT, ensure_ascii=False, indent=2), encoding='utf-8')
    for filename in [Path(__file__).name, 'redraw_vf_bgc_typebars_only_20260925.py',
                     'redraw_vf_bgc_datasets_no_umap_20260925.py', 'redraw_vf_bgc_weighted_a4_20260925.py']:
        shutil.copy2(ROOT/filename, OUT/'code'/filename)


if __name__ == '__main__':
    main()
