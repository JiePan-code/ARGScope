"""Check the final export set, labels, unchanged source rows and stored snapshots."""
from pathlib import Path
import csv
import hashlib
import json
import xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'/'vf_bgc_merged_20260922_v5'
OLD=HERE/'outputs'/'vf_bgc_merged_20260922_v4'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run():
    figures=list(OUT.glob('*.svg'))+list((OUT/'individual_panels').glob('*.svg'))+list((OUT/'epoch_groups').glob('*.svg'))
    assert len(figures)==9,len(figures)
    assert len(list((OUT/'individual_panels').glob('*.svg')))==6
    assert len(list((OUT/'epoch_groups').glob('*.svg')))==1
    checks=[]
    for p in figures:
        root=ET.parse(p).getroot()
        texts=[''.join(t.itertext()).strip() for t in root.iter('{http://www.w3.org/2000/svg}text')]
        assert texts and not any(t in list('ABCDEFGH') for t in texts),p
        if 'main_combined' in p.name or 'metrics_overview' in p.name:
            assert texts.count('Subtype (macro)')==2
            assert 'Type (macro)' not in texts
        if p.name in ['VF_BGC_main_combined.svg','VF_BGC_epochs_2x4.svg']:
            expected_titles=['Protein · Epoch 0','Protein · Best epoch','DNA · Epoch 0','DNA · Best epoch']
            for title in expected_titles: assert texts.count(title)==2
            assert not any('Epoch 20' in t or 'Epoch 50' in t for t in texts)
            label_nodes=[t for t in root.iter('{http://www.w3.org/2000/svg}text')
                         if ''.join(t.itertext()).strip() in expected_titles]
            assert len(label_nodes)==8
            # Inspect rendered SVG positions, not only claimed row/column metadata.
            y_positions={round(float(t.attrib['y']),3) for t in label_nodes}
            x_positions={round(float(t.attrib['x']),3) for t in label_nodes}
            assert len(y_positions)==2 and len(x_positions)==4,(p,y_positions,x_positions)
        for suffix in ['.png','.pdf','.svg']:
            artifact=p.with_suffix(suffix)
            assert artifact.is_file() and artifact.stat().st_size>1000
            checks.append({'File':str(artifact.relative_to(OUT)),'SHA256':digest(artifact),
                           'Bytes':artifact.stat().st_size})
        with Image.open(p.with_suffix('.png')) as im:
            assert min(im.size)>950
            assert all(abs(v-300)<.1 for v in im.info['dpi'])
            im.verify()
        if p.parent.name=='individual_panels' or p.name=='VF_BGC_metrics_overview.svg':
            assert digest(p.with_suffix('.png'))==digest(OLD/p.relative_to(OUT).with_suffix('.png')),p
    sources=0
    for p in (OLD/'plot_data').rglob('*'):
        if p.is_file():
            assert digest(p)==digest(OUT/'plot_data'/p.relative_to(OLD/'plot_data'))
            sources+=1
    manifest=json.loads((OUT/'epoch_manifest.json').read_text(encoding='utf-8'))
    assert len(manifest)==8
    assert [(r['row'],r['column']) for r in manifest]==[(r,c) for r in range(2) for c in range(4)]
    expected={('VF','AA'):[0,69],('VF','NT'):[0,48],
              ('BGC','AA'):[0,10],('BGC','NT'):[0,2]}
    for (domain,variant),epochs in expected.items():
        rows=[r for r in manifest if r['domain']==domain and r['variant']==variant]
        assert [r['epoch'] for r in rows]==epochs
        assert rows[-1]['title'].endswith('Best epoch')
        assert len({r['samples'] for r in rows})==1
    with (OUT/'file_checksums.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['File','SHA256','Bytes'])
        writer.writeheader(); writer.writerows(checks)
    # Contact sheet is for export QA only, never an edited substitute for a figure.
    sheet=Image.new('RGB',(1800,1500),'#E5E8EA')
    draw=ImageDraw.Draw(sheet); font=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',20)
    for i,p in enumerate(sorted((OUT/'individual_panels').glob('*.png'))):
        with Image.open(p) as im:
            im=im.convert('RGB'); im.thumbnail((580,690))
            x=i%3*600+(600-im.width)//2; y=i//3*750+40+(690-im.height)//2
            sheet.paste(im,(x,y))
        draw.text((i%3*600+14,i//3*750+10),p.stem,font=font,fill='black')
    sheet.save(OUT/'previews'/'six_panels_review.jpg',quality=94)
    audit=json.loads((OUT/'verification.json').read_text(encoding='utf-8'))
    audit['export_checks']={'figure_count':9,'file_count_png_pdf_svg':len(checks),
        'all_pngs_300dpi':True,'all_svg_labels_checked':True,'no_panel_letters':True,
        'main_has_two_subtype_macro_bars':True,'snapshots_checked':8,'rendered_epoch_layout_2x4':True,
        'source_files_identical_to_v4':sources,'metric_pngs_identical_to_v4':True,'individual_epoch_files':0}
    (OUT/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'PASS: 9 figures, 27 format exports, rendered 2x4 grid, 8 epoch snapshots, {sources} unchanged source files. Metrics PNGs identical to v4.')

if __name__=='__main__':
    run()
