from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
from sklearn.preprocessing import LabelEncoder

try:
    import umap
except ImportError as e:
    raise ImportError("Please install umap-learn first: pip install umap-learn") from e


# =========================================================
# 1. User settings
# =========================================================

CANDIDATE_INPUT_DIRS = [
    Path("ARGScope_UMAP_embedding_files"),
    Path("."),
]

OUTPUT_DIR = Path("ARGScope_UMAP_type_figures_final_matched_legend")
OUTPUT_DIR.mkdir(exist_ok=True)

EPOCHS = [0, 50, 150, 300]

COLOR_BY = "True_Type"
EXPECTED_TYPE_COUNT = 31

# 只影响 UMAP 画图，不影响模型训练
USE_SUPERVISED_UMAP = True
# 降低 type 标签对 UMAP 的“拉团”作用，避免聚得太紧
TARGET_WEIGHT = 0.04
USE_SHARED_UMAP = True

RANDOM_STATE = 42

# 让点更分散、更铺开
UMAP_PARAMS = dict(
    n_neighbors=18,
    min_dist=0.90,
    spread=3.20,
    metric="cosine",
    random_state=RANDOM_STATE,
)

# 点稍微小一点，图看起来更松散
POINT_SIZE = 5
POINT_ALPHA = 0.62
POINT_LINEWIDTH = 0.0
EDGE_COLOR = "none"

# 子图布局
N_COLS = 4
PANEL_WIDTH = 3.60
PANEL_HEIGHT = 3.00

# 图例布局
# 31 个 type，设置 8 列，会自动排成 4 行：8 + 8 + 8 + 7
LEGEND_NCOL = 8
LEGEND_FONT_SIZE = 7.2

TITLE_FONT_SIZE = 13
PANEL_TITLE_FONT_SIZE = 10.5
AXIS_LABEL_FONT_SIZE = 9.5

SHOW_MAIN_TITLE = True
MAIN_TITLE = "UMAP of learned representations colored by ARG type"

# 不显示 Figure D
PANEL_LETTER = ""

SAVE_DPI = 600

# 关键参数：子图区域和 legend 区域使用相同的左右边界
SUBPLOT_LEFT = 0.045
SUBPLOT_RIGHT = 0.990
SUBPLOT_TOP = 0.845
SUBPLOT_BOTTOM = 0.245

# legend 横向宽度与子图整体宽度一致
LEGEND_X = SUBPLOT_LEFT
LEGEND_WIDTH = SUBPLOT_RIGHT - SUBPLOT_LEFT
LEGEND_Y = 0.055
LEGEND_HEIGHT = 0.115


# =========================================================
# 2. Plot style
# =========================================================

warnings.filterwarnings("ignore", category=UserWarning)

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 8,
    "axes.linewidth": 1.0,
    "axes.titlesize": PANEL_TITLE_FONT_SIZE,
    "axes.labelsize": AXIS_LABEL_FONT_SIZE,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": LEGEND_FONT_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})

# 31 个 type 的颜色
TYPE_COLOR_LIST = [
    "#E64B35", "#1F78B4", "#00A087", "#3C5488", "#F39B7F",
    "#7E6148", "#4DBBD5", "#D00000", "#B09C85", "#91D1C2",
    "#A6CEE3", "#FF7F00", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDB462", "#6A3D9A", "#CAB2D6", "#B15928",
    "#F0E442", "#8C510A", "#80CDC1", "#35978F", "#F781BF",
    "#377EB8", "#FFB000", "#66A61E", "#E7298A", "#984EA3",
    "#A6DBA0",
]


# =========================================================
# 3. Helper functions
# =========================================================

def find_input_dir():
    for d in CANDIDATE_INPUT_DIRS:
        if all((d / f"umap_embedding_epoch_{e:03d}.csv").exists() for e in EPOCHS):
            return d

    for d in CANDIDATE_INPUT_DIRS:
        existing = sorted(d.glob("umap_embedding_epoch_*.csv"))
        if len(existing) > 0:
            return d

    raise FileNotFoundError(
        "No umap_embedding_epoch_*.csv files found. "
        "Put this script in the project root or inside ARGScope_UMAP_embedding_files."
    )


def load_epoch_embeddings(input_dir):
    data = {}

    for epoch in EPOCHS:
        file = input_dir / f"umap_embedding_epoch_{epoch:03d}.csv"

        if not file.exists():
            print(f"[Skip] File not found: {file}")
            continue

        df = pd.read_csv(file)
        embed_cols = [c for c in df.columns if c.startswith("embed_")]

        if len(embed_cols) == 0:
            raise ValueError(f"No embed_* columns found in {file}")

        if COLOR_BY not in df.columns:
            raise ValueError(f"{file} does not contain column: {COLOR_BY}")

        df[COLOR_BY] = df[COLOR_BY].astype(str)
        data[epoch] = (df, embed_cols)

        print(
            f"[Loaded] epoch {epoch:03d}: "
            f"{df.shape[0]} samples, {len(embed_cols)} features, "
            f"{df[COLOR_BY].nunique()} types"
        )

    if len(data) == 0:
        raise FileNotFoundError("No valid epoch embedding files were loaded.")

    return data


def get_all_labels(data):
    labels = []

    for df, _ in data.values():
        labels.extend(df[COLOR_BY].astype(str).tolist())

    return sorted(pd.Series(labels).dropna().astype(str).unique())


def make_color_map(labels):
    if len(labels) > len(TYPE_COLOR_LIST):
        cmap = plt.get_cmap("turbo")
        extra = [
            mpl.colors.to_hex(
                cmap(i / max(1, len(labels) - len(TYPE_COLOR_LIST)))
            )
            for i in range(len(labels) - len(TYPE_COLOR_LIST))
        ]
        colors = TYPE_COLOR_LIST + extra
    else:
        colors = TYPE_COLOR_LIST[:len(labels)]

    return dict(zip(labels, colors))


def encode_umap_labels(labels):
    encoder = LabelEncoder()
    return encoder.fit_transform(pd.Series(labels).astype(str).values).astype(np.int32)


def compute_umap_coordinates(data):
    coordinates = {}

    if USE_SHARED_UMAP:
        X_blocks = []
        y_blocks = []
        index_info = []

        for epoch, (df, embed_cols) in data.items():
            X = df[embed_cols].values.astype(np.float32)
            y = df[COLOR_BY].astype(str).values

            X_blocks.append(X)
            y_blocks.append(y)
            index_info.append((epoch, X.shape[0]))

        X_all = np.vstack(X_blocks)
        y_all = np.concatenate(y_blocks)

        reducer = umap.UMAP(
            **UMAP_PARAMS,
            target_metric="categorical" if USE_SUPERVISED_UMAP else "euclidean",
            target_weight=TARGET_WEIGHT if USE_SUPERVISED_UMAP else 0.0,
        )

        if USE_SUPERVISED_UMAP:
            y_encoded = encode_umap_labels(y_all)
            Z_all = reducer.fit_transform(X_all, y=y_encoded)
        else:
            Z_all = reducer.fit_transform(X_all)

        cursor = 0
        for epoch, n in index_info:
            coordinates[epoch] = Z_all[cursor:cursor + n]
            cursor += n

    else:
        for epoch, (df, embed_cols) in data.items():
            X = df[embed_cols].values.astype(np.float32)
            y = df[COLOR_BY].astype(str).values

            reducer = umap.UMAP(
                **UMAP_PARAMS,
                target_metric="categorical" if USE_SUPERVISED_UMAP else "euclidean",
                target_weight=TARGET_WEIGHT if USE_SUPERVISED_UMAP else 0.0,
            )

            if USE_SUPERVISED_UMAP:
                y_encoded = encode_umap_labels(y)
                coordinates[epoch] = reducer.fit_transform(X, y=y_encoded)
            else:
                coordinates[epoch] = reducer.fit_transform(X)

    return coordinates


def equalize_axes(ax, Z, pad_ratio=0.02):
    x_min, x_max = np.min(Z[:, 0]), np.max(Z[:, 0])
    y_min, y_max = np.min(Z[:, 1]), np.max(Z[:, 1])

    x_mid = (x_min + x_max) / 2
    y_mid = (y_min + y_max) / 2

    max_range = max(x_max - x_min, y_max - y_min)
    pad = max_range * pad_ratio

    ax.set_xlim(x_mid - max_range / 2 - pad, x_mid + max_range / 2 + pad)
    ax.set_ylim(y_mid - max_range / 2 - pad, y_mid + max_range / 2 + pad)


def style_panel(ax, show_ylabel=True):
    ax.set_xticks([])
    ax.set_yticks([])

    ax.set_xlabel("UMAP1", labelpad=1, fontsize=AXIS_LABEL_FONT_SIZE)

    if show_ylabel:
        ax.set_ylabel("UMAP2", labelpad=1, fontsize=AXIS_LABEL_FONT_SIZE)
    else:
        ax.set_ylabel("")

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)
        spine.set_color("black")


def plot_one_axis(ax, df, Z, color_map, show_ylabel=True):
    labels = df[COLOR_BY].astype(str).values

    # 大类先画，小类后画，减少小类被遮挡
    counts = pd.Series(labels).value_counts(ascending=True)

    for label in counts.index:
        idx = labels == label

        ax.scatter(
            Z[idx, 0],
            Z[idx, 1],
            s=POINT_SIZE,
            c=color_map[label],
            alpha=POINT_ALPHA,
            linewidths=POINT_LINEWIDTH,
            edgecolors=EDGE_COLOR,
            rasterized=True,
        )

    equalize_axes(ax, Z)
    style_panel(ax, show_ylabel=show_ylabel)


def make_legend_handles(labels, color_map):
    handles = []

    for label in labels:
        handles.append(
            Line2D(
                [0], [0],
                marker="o",
                color="none",
                markerfacecolor=color_map[label],
                markeredgecolor="none",
                markersize=5.2,
                label=label,
            )
        )

    return handles


def save_coordinate_tables(data, coordinates):
    for epoch, (df, embed_cols) in data.items():
        out = df.drop(columns=embed_cols).copy()

        out.insert(1, "UMAP1", coordinates[epoch][:, 0])
        out.insert(2, "UMAP2", coordinates[epoch][:, 1])

        out.to_csv(
            OUTPUT_DIR / f"umap_{COLOR_BY}_epoch_{epoch:03d}_coordinates.csv",
            index=False,
            encoding="utf-8-sig"
        )


def save_color_mapping(labels, color_map):
    color_df = pd.DataFrame({
        COLOR_BY: labels,
        "color": [color_map[x] for x in labels],
    })

    color_df.to_csv(
        OUTPUT_DIR / "type_color_mapping.csv",
        index=False,
        encoding="utf-8-sig"
    )


def plot_multipanel(data, coordinates, labels, color_map):
    epochs = list(data.keys())
    n = len(epochs)

    ncols = N_COLS
    nrows = math.ceil(n / ncols)

    fig_width = PANEL_WIDTH * ncols
    fig_height = PANEL_HEIGHT * nrows + 1.05

    fig, axes = plt.subplots(
        nrows=nrows,
        ncols=ncols,
        figsize=(fig_width, fig_height),
        dpi=SAVE_DPI,
        constrained_layout=False,
    )

    if not isinstance(axes, np.ndarray):
        axes = np.array([axes])

    axes = axes.flatten()

    for i, epoch in enumerate(epochs):
        ax = axes[i]
        df, _ = data[epoch]
        Z = coordinates[epoch]

        plot_one_axis(
            ax=ax,
            df=df,
            Z=Z,
            color_map=color_map,
            show_ylabel=(i == 0),
        )

        ax.set_title(
            f"epoch {epoch}",
            fontsize=PANEL_TITLE_FONT_SIZE,
            pad=5,
        )

    for j in range(n, len(axes)):
        axes[j].axis("off")

    if PANEL_LETTER:
        fig.text(
            0.012,
            0.965,
            PANEL_LETTER,
            fontsize=18,
            fontweight="bold",
            ha="left",
            va="top",
        )

    if SHOW_MAIN_TITLE:
        fig.suptitle(
            MAIN_TITLE,
            fontsize=TITLE_FONT_SIZE,
            y=0.955,
        )

    handles = make_legend_handles(labels, color_map)

    # 关键：legend 的横向宽度和子图区域完全一致
    fig.legend(
        handles=handles,
        labels=labels,
        loc="upper left",
        bbox_to_anchor=(LEGEND_X, LEGEND_Y, LEGEND_WIDTH, LEGEND_HEIGHT),
        ncol=LEGEND_NCOL,
        mode="expand",
        frameon=False,
        fontsize=LEGEND_FONT_SIZE,
        handlelength=0.70,
        handletextpad=0.22,
        columnspacing=0.75,
        labelspacing=0.38,
        borderaxespad=0.0,
        bbox_transform=fig.transFigure,
    )

    fig.subplots_adjust(
        left=SUBPLOT_LEFT,
        right=SUBPLOT_RIGHT,
        top=SUBPLOT_TOP,
        bottom=SUBPLOT_BOTTOM,
        wspace=0.20,
        hspace=0.22,
    )

    out_png = OUTPUT_DIR / f"umap_{COLOR_BY}_epochs_multipanel_matched_legend.png"
    out_pdf = OUTPUT_DIR / f"umap_{COLOR_BY}_epochs_multipanel_matched_legend.pdf"
    out_svg = OUTPUT_DIR / f"umap_{COLOR_BY}_epochs_multipanel_matched_legend.svg"

    fig.savefig(out_png, dpi=SAVE_DPI)
    fig.savefig(out_pdf)
    fig.savefig(out_svg)
    plt.close(fig)

    print(f"[Saved] {out_png}")
    print(f"[Saved] {out_pdf}")
    print(f"[Saved] {out_svg}")


def plot_single_epoch_figures(data, coordinates, labels, color_map):
    handles = make_legend_handles(labels, color_map)

    for epoch, (df, _) in data.items():
        Z = coordinates[epoch]

        fig, ax = plt.subplots(
            figsize=(4.6, 4.6),
            dpi=SAVE_DPI,
            constrained_layout=False,
        )

        plot_one_axis(
            ax=ax,
            df=df,
            Z=Z,
            color_map=color_map,
            show_ylabel=True,
        )

        ax.set_title(
            f"epoch {epoch}",
            fontsize=PANEL_TITLE_FONT_SIZE,
            pad=5,
        )

        fig.legend(
            handles=handles,
            labels=labels,
            loc="lower center",
            bbox_to_anchor=(0.5, 0.015),
            ncol=4,
            frameon=False,
            fontsize=6.2,
            handlelength=0.70,
            handletextpad=0.22,
            columnspacing=0.65,
            labelspacing=0.36,
        )

        fig.subplots_adjust(
            left=0.12,
            right=0.97,
            top=0.90,
            bottom=0.34,
        )

        out_png = OUTPUT_DIR / f"umap_{COLOR_BY}_epoch_{epoch:03d}_matched_legend.png"
        out_pdf = OUTPUT_DIR / f"umap_{COLOR_BY}_epoch_{epoch:03d}_matched_legend.pdf"

        fig.savefig(out_png, dpi=SAVE_DPI)
        fig.savefig(out_pdf)
        plt.close(fig)

        print(f"[Saved] {out_png}")


def main():
    input_dir = find_input_dir()
    print(f"[Input dir] {input_dir}")

    data = load_epoch_embeddings(input_dir)

    labels = get_all_labels(data)
    print(f"[Detected types] {len(labels)}")

    if len(labels) != EXPECTED_TYPE_COUNT:
        print(
            f"[Warning] Detected {len(labels)} types, "
            f"not expected {EXPECTED_TYPE_COUNT} types."
        )

    color_map = make_color_map(labels)
    save_color_mapping(labels, color_map)

    print(
        "[UMAP] "
        f"use_shared={USE_SHARED_UMAP}, "
        f"use_supervised={USE_SUPERVISED_UMAP}, "
        f"target_weight={TARGET_WEIGHT}"
    )

    coordinates = compute_umap_coordinates(data)

    save_coordinate_tables(data, coordinates)

    plot_multipanel(data, coordinates, labels, color_map)
    plot_single_epoch_figures(data, coordinates, labels, color_map)

    print("Done.")


if __name__ == "__main__":
    main()