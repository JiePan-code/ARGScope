"""Local right-click launcher for Full mutual-KNN residual-GAT refinement."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ablation_runtime import (
    add_default_structure,
    data_root_from_launcher,
    load_base,
    reject_overwrite_argument,
)

DATA = data_root_from_launcher(__file__)
m = load_base("03_refine_gat.py", "gat_full_local_base")
m.ROOT = DATA
m.DEFAULT_RAW_PT = (
    DATA
    / "Raw_subtype_prototypes_subtype2_newsplit"
    / "raw_ARG_subtype_prototypes_and_baseline.pt"
)
m.DEFAULT_FUSED_PT = (
    DATA / "Long_fusion_subtype2_newsplit" / "long_fusion_subtype2_newsplit.pt"
)
m.DEFAULT_OUTPUT_PT = (
    DATA
    / "Refined_subtype_prototypes_subtype2_newsplit"
    / "refined_ARG_subtype_prototypes_residual_GAT.pt"
)
reject_overwrite_argument()
add_default_structure(DATA)
m.main()
