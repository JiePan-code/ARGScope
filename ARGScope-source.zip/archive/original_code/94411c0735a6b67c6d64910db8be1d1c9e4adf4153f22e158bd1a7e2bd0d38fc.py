#!/usr/bin/env python3
"""Use global Accuracy/MCC and macro P/R/F1 for all Protein bar comparisons.

Preserves every source's archived evaluation population and mapping. DeepARG
has selected ARG-hit records only; these are not matched-cohort comparisons.
"""
import json
import shutil
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

MODELS = ['ARGNet', 'DeepARG', 'PLM-ARG', 'FunGeneTyper', 'ARGScope']


def source_list(c, pct):
    raw = c.TRAIN / 'ARGscope_result_9.16'
    yield ('ARGNet', raw / f'ARGnet/protein/ARGNet_type_metrics_results/mapped_predictions/protein_{pct}pct_5parts_argnet-l_aa_result_mapped_type_predictions.csv',
           'test_id', 'base_id', 'true_type', 'predicted_type', 'archived_all_including_nonARG')
    yield ('FunGeneTyper', raw / f'FunGenetyper/Protein/FunGeneTyper_Protein_metrics_results/mapped_predictions/{pct}p_result_mapped_type_predictions.csv',
           'test_id', 'base_id', 'true_type', 'predicted_type', 'archived_all_including_nonARG')
    deep_folder = 'all_arg_nonarg_protein_deeparg_LS_prot' if pct == 100 else f'protein_{pct}pct_5parts_deeparg_SS_prot'
    yield ('DeepARG', c.TRAIN / f'柱状图结果/longaa/Deeparg/{deep_folder}/predictions_used_for_type_evaluation.csv',
           'read_id', None, 'type', 'predicted_type_teacher_system', 'archived_selected_ARG_hits_only')
    own_file = '100%_test_sequence_predictions.csv' if pct == 100 else f'{pct}%_fragment_predictions_test.csv'
    yield ('ARGScope', c.APP / 'protein' / own_file,
           'sequence_id', 'parent_sequence_id', 'true_type', 'predicted_type', 'new_test_all_including_nonARG')


def update_all_models(plm, c):
    out = c.APP / 'Protein_macro_bars'
    out.mkdir(exist_ok=True)
    plm_type = plm[(plm.Level == 'Type') & (plm.Scope == 'including_nonARG')].copy()
    plm_type['Population'] = 'archived_all_including_nonARG'
    plm_type['Source'] = str(c.OUT / '01_Type_overall_macro_weighted_micro.csv')
    frames, audits, reference_checks = [plm_type], [], []
    for pct in c.PCTS:
        for model, path, idcol, parentcol, truth, pred, population in source_list(c, pct):
            df = c.read(path)
            assert df[idcol].is_unique and df[[truth, pred]].ne('').all().all()
            parent = df[parentcol].astype(str) if parentcol else df[idcol].astype(str).str.replace(r'_[1-5]$', '', regex=True)
            assert df.assign(_parent=parent).groupby('_parent')[truth].nunique().eq(1).all()
            scope = 'selected_ARG_hits_only' if model == 'DeepARG' else 'including_nonARG'
            result, _ = c.scores(df[truth], df[pred], pct, scope, 'Type', model=model)
            result['Model'] = model
            result['Population'] = population
            result['Source'] = str(path)
            frames.append(result)
            audits.append(dict(Model=model, Completeness=pct, N=len(df), N_parents=parent.nunique(),
                               NonARG_rows=int(df[truth].eq('nonARG').sum()),
                               N_true_labels=df[truth].nunique(), Source=str(path), Population=population,
                               SHA256=c.digest(path), Missing_predictions_dropped=False,
                               Matched_to_new_ARGScope_test=(model == 'ARGScope')))
            # Archived tables use four OR six decimal places; validate against
            # each stored token's actual precision, not an assumed six places.
            if model in ('ARGNet', 'FunGeneTyper'):
                summary_path = path.parent.parent / '02_type_overall_five_metrics.csv'
                expected = c.read(summary_path, dtype=str)
                for average in c.AVERAGES:
                    expected_row = expected[(expected.condition == f'{pct}%') & (expected.average == average)].iloc[0]
                    actual = result[result.Average == average].iloc[0]
                    for metric in c.METRICS:
                        token = expected_row[metric.lower()].strip()
                        places = len(token.partition('.')[2])
                        error = abs(actual[metric] - float(token))
                        assert error <= .5 * 10 ** (-places) + 1e-12
                        reference_checks.append(dict(Model=model, Completeness=pct, Average=average,
                                                     Metric=metric, Reference=token, Decimal_places=places,
                                                     Recomputed=actual[metric], Absolute_error=error))
            print(f'{pct}% {model}: {len(df):,} observations; macro/weighted/micro checked.', flush=True)
    combined = pd.concat(frames, ignore_index=True)
    combined['_model_order'] = combined.Model.map({m: i for i, m in enumerate(MODELS)})
    combined['_avg_order'] = combined.Average.map({a: i for i, a in enumerate(c.AVERAGES)})
    combined = combined.sort_values(['Completeness', '_model_order', '_avg_order']).drop(columns=['_model_order', '_avg_order'])
    assert len(combined) == 75
    main = combined[combined.Average == 'macro']
    all_path = out / '02_Type_all_conditions_macro_weighted_micro.csv'
    c.save_csv(combined, all_path)
    c.save_csv(main[main.Completeness == 100], out / '01_Protein_100pct_macro_plot_values.csv')
    c.save_csv(pd.DataFrame(audits), out / '03_source_population_audit.csv')
    c.save_csv(pd.DataFrame(c.CHECKS), out / '04_independent_metric_checks.csv')
    c.save_csv(pd.DataFrame(reference_checks), out / '06_archived_summary_rounding_checks.csv')
    for avg in c.AVERAGES:
        c.save_csv(combined[combined.Average == avg], out / f'Protein_Type_{avg}_all_conditions.csv')
    previous = []
    for folder in (c.REF, c.PUB):
        for pct in c.PCTS:
            target = folder / f'data/protein/{pct}pct/A_overall_values_and_sources.csv'
            old = pd.read_csv(target)
            current = main[main.Completeness == pct].set_index('Model').loc[MODELS].reset_index()
            rows = []
            for row in current.to_dict('records'):
                prior = old[old.Model == row['Model']].iloc[0]
                if folder == c.PUB:
                    for metric in c.METRICS:
                        previous.append(dict(Model=row['Model'], Completeness=pct, Metric=metric,
                                             Previous=float(prior[metric]), Corrected_macro=float(row[metric])))
                rows.append(dict(Model=row['Model'], modality='protein', pct=pct,
                                 **{m: row[m] for m in c.METRICS}, Average='macro',
                                 N=row['N'], Population=row['Population'], source=str(all_path),
                                 prediction_source=row['Source'], definition='global Accuracy/MCC; macro Precision/Recall/F1; original populations NOT matched'))
            c.save_csv(pd.DataFrame(rows), target, replace=True)
    c.save_csv(pd.DataFrame(previous), out / '05_previous_vs_macro_plot.csv')
    c.update_figures(plm_type)
    figure_folder = out / 'figures'
    figure_folder.mkdir(exist_ok=True)
    for pct in c.PCTS:
        for ext in ('png', 'pdf', 'svg'):
            shutil.copy2(c.PUB / f'Protein/{pct}pct/overall_protein_{pct}pct.{ext}',
                         figure_folder / f'Protein_{pct}pct_macro_comparison.{ext}')
    for ext in ('png', 'pdf', 'svg'):
        shutil.copy2(c.PUB / f'Protein/Protein_100pct_assembled.{ext}',
                     figure_folder / f'Protein_100pct_assembled_macro.{ext}')
    # Source notes accompany the figures, without changing the user's requested
    # uncluttered image layout or pretending the archived populations are equal.
    (out / 'README_指标口径.md').write_text('''# Protein 总体柱状图更新

图中五项固定为 Accuracy、macro Precision、macro Recall、macro F1、MCC。
Accuracy 是逐序列预测正确率；MCC 是总体多分类 MCC，均不做逐 Type 平均。
macro/weighted/micro 仅改变 Precision、Recall、F1 的汇总；Accuracy 和 MCC 在三种方式中相同。
主结果是 01_Protein_100pct_macro_plot_values.csv；全部模型、全部完整度、三种平均共 75 行在 02_Type_all_conditions_macro_weighted_micro.csv。
零分母沿用 zero_division=0。宏平均标签集合沿用各原评估的真实与预测标签并集，包含预测专用的无法映射类别；不因性能为零而删除类别。

## 必须保留的解释

这次统一的是指标公式和平均方式，不是测试样本。
ARGScope 用新测试集；ARGNet、FunGeneTyper、PLM-ARG 用各自已保存的旧逐序列映射结果（含 nonARG）。
DeepARG 只有现有筛选后的 ARG 命中评估表，不包含完整 nonARG 或未命中样本；不能把其分数解释成完整测试集性能。
各模型的标签覆盖也不同。以上对照不是已验证的同测试集公平基准，不能据此作统计显著性或严格优越性结论。

PLM-ARG 保留原补充材料的既定映射及 0.5 ARG 阈值。共享或不可唯一对应的单标签不根据真实标签分配，计入 __PLMARG_UNMAPPED__。
其原 merged 文件与既定 mapped 文件在 ID、真实 Type、原始预测、ARG 概率上逐条一致，映射已重新执行并复核。
旧 0.9334 是仅支持类别 one-vs-rest Accuracy 的加权平均，不能冒充总体 Accuracy；新全长总体 Accuracy 为 0.766128432175013。

## 更新范围

已更新两个小图目录中的 Protein 总体柱状图及缓存、最新 publication 目录的 Protein 全长拼图。
DNA、Type 热图、UMAP 坐标、混淆矩阵及错误明细不改。
Type 热图仍是原有兼容映射与筛选后的逐类展示，Average 不等于本次全标签 macro 指标。
旧柱状图汇总文件保留为历史档案；绘图程序现在显式读取本次重新计算的 macro 总表。
桌面手工编辑的 drawio 和导出的 Figure1 protein.png 不覆盖；可用本文件夹内的新 A 小图替换，或使用重新生成的全长拼图。
旧图件和旧缓存的备份清单位于 PLM_ARG/PLMARG_overall_corrected/backup_manifest.json。
''', encoding='utf-8')
    (out / 'input_sha256.json').write_text(json.dumps(c.INPUTS, indent=2, ensure_ascii=False), encoding='utf-8')
    archive = out / 'Protein_macro_results_and_figures.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(out.rglob('*')):
            if path.is_file() and path != archive:
                z.write(path, path.relative_to(out))
    print(f'Protein macro figures and all 75 metric rows: {out}', flush=True)


if __name__ == '__main__':
    import recalculate_PLMARG_overall_metrics as core
    core.main()
