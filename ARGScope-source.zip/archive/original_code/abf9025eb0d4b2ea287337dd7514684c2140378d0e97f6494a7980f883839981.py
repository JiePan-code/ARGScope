import csv

# ===== 输入文件 =====
vf_protein = "VFDB_matched_protein.fasta"
vf_dna = "VFDB_matched_dna.fasta"

nonvf_protein = "non_vf_protein_29354.fasta"
nonvf_dna = "non_vf_dna_29354.fasta"

# ===== 输出文件 =====
out_protein = "VF_nonVF_protein.fasta"
out_dna = "VF_nonVF_dna.fasta"
out_csv = "VF_nonVF_annotation.csv"


# ===== 工具函数：读取fasta为 dict =====
def read_fasta_to_dict(fasta_file, is_vf=True):
    seq_dict = {}
    current_id = None

    with open(fasta_file) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                header = line[1:]

                if is_vf:
                    # VF header解析
                    parts = [p.strip() for p in header.split("|")]
                    current_id = parts[0]
                else:
                    # nonVF直接就是ID
                    current_id = header

                seq_dict[current_id] = ""
            else:
                seq_dict[current_id] += line

    return seq_dict


# ===== 1. 读取数据 =====
vf_prot_dict = read_fasta_to_dict(vf_protein, is_vf=True)
vf_dna_dict = read_fasta_to_dict(vf_dna, is_vf=True)

nonvf_prot_dict = read_fasta_to_dict(nonvf_protein, is_vf=False)
nonvf_dna_dict = read_fasta_to_dict(nonvf_dna, is_vf=False)

print("VF protein:", len(vf_prot_dict))
print("nonVF protein:", len(nonvf_prot_dict))


# ===== 2. 合并 =====
all_prot = {**vf_prot_dict, **nonvf_prot_dict}
all_dna = {**vf_dna_dict, **nonvf_dna_dict}

print("总数:", len(all_prot))


# ===== 3. 写合并后的 FASTA =====
with open(out_protein, "w") as f:
    for pid, seq in all_prot.items():
        f.write(f">{pid}\n{seq}\n")

with open(out_dna, "w") as f:
    for pid, seq in all_dna.items():
        f.write(f">{pid}\n{seq}\n")

print("FASTA 合并完成")


# ===== 4. 构建 annotation =====
data = []

# ---- VF ----
with open(vf_protein) as f:
    for line in f:
        if line.startswith(">"):
            header = line.strip()[1:]
            parts = [p.strip() for p in header.split("|")]

            pid = parts[0]
            subtype = ""
            vtype = ""

            for p in parts[1:]:
                if p.startswith("subtype="):
                    subtype = p.replace("subtype=", "").strip()
                elif p.startswith("type="):
                    vtype = p.replace("type=", "").strip()

            data.append([pid, vtype, subtype])

# ---- nonVF ----
for pid in nonvf_prot_dict.keys():
    data.append([pid, "nonVF", "nonVF"])


# ===== 5. 写 CSV =====
with open(out_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["ID", "type", "subtype"])
    writer.writerows(data)

print("CSV 完成:", out_csv)


# ===== 6. 强烈建议的校验 =====
print("检查 protein / dna 是否完全一致：", set(all_prot.keys()) == set(all_dna.keys()))
# ===== 7. 最终一致性检查 =====

prot_ids = set(all_prot.keys())
dna_ids = set(all_dna.keys())
anno_ids = set([row[0] for row in data])

print("\n===== 最终检查 =====")

# 1. 数量检查
print(f"protein数量: {len(prot_ids)}")
print(f"dna数量: {len(dna_ids)}")
print(f"annotation数量: {len(anno_ids)}")

# 2. protein vs dna
if prot_ids == dna_ids:
    print("✅ protein 和 dna 完全一致")
else:
    print("❌ protein 和 dna 不一致")
    print("仅在protein中:", len(prot_ids - dna_ids))
    print("仅在dna中:", len(dna_ids - prot_ids))

# 3. protein vs annotation
if prot_ids == anno_ids:
    print("✅ protein 和 annotation 完全一致")
else:
    print("❌ protein 和 annotation 不一致")
    print("仅在protein中:", len(prot_ids - anno_ids))
    print("仅在annotation中:", len(anno_ids - prot_ids))

# 4. 最终结论
if prot_ids == dna_ids == anno_ids:
    print("🎯 所有数据完全对齐，可以直接用于建模")
else:
    print("⚠️ 存在不一致，建议检查")