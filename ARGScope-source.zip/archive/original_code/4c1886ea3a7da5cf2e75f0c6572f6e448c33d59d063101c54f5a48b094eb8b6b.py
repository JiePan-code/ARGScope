#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ARGScope per-Type Precision/Recall radar figures, 60/70/80/90%.

Main version follows the user's positive-Type display filter. A complete
23-Type version is also exported to make the display selection inspectable.
No baseline-model comparisons, metric recomputation changes, or training.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib.lines import Line2D
from matplotlib.text import Text
from PIL import Image

ROOT = Path(__file__).resolve().parent
FIGROOT = ROOT.parent
APPROOT = FIGROOT.parent
INPUT = ROOT/"inputs"
PCTS = [60, 70, 80, 90]
MODS = ["protein", "dna"]
COLORS = {"Precision": "#CE4669", "Recall": "#3885B5"}
MARKERS = {"Precision": "o", "Recall": "s"}
STYLES = {"Precision": "-", "Recall": "--"}
plt.rcParams.update({"font.family": "Arial", "font.size": 9, "figure.facecolor": "white",
                     "savefig.facecolor": "white", "text.color": "#24292D",
                     "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42})


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.12g")


def load_sources():
    INPUT.mkdir(exist_ok=True)
    originals = {"per_type_counts.csv": FIGROOT/"data/ARGScope_per_type_five_metrics.csv",
                 "type_mapping.csv": FIGROOT/"data/type_display_mapping.csv"}
    manifest_path = INPUT/"source_manifest.json"
    if not manifest_path.exists():
        for name, source in originals.items():
            assert source.is_file(), source
            assert not (INPUT/name).exists(), "Incomplete snapshot: inspect inputs before rerunning."
        metadata = {}
        for name, source in originals.items():
            shutil.copy2(source, INPUT/name)
            metadata[name] = {"original_path": str(source), "sha256": sha(source)}
        dump(manifest_path, metadata)
    metadata = json.loads(manifest_path.read_text(encoding="utf-8"))
    for name, meta in metadata.items():
        assert sha(INPUT/name) == meta["sha256"]
    df = pd.read_csv(INPUT/"per_type_counts.csv")
    df = df[df.Completeness.isin(PCTS) & df.Modality.isin(MODS)].copy()
    mapping = pd.read_csv(INPUT/"type_mapping.csv")
    assert len(df) == 184 and len(mapping) == 23
    assert not df.duplicated(["Modality", "Completeness", "Type"]).any()
    assert df[["Precision", "Recall"]].notna().all().all()
    for column in ["Precision", "Recall"]:
        assert df[column].between(0, 1).all()
    for metric, den in [("Precision", df.TP+df.FP), ("Recall", df.TP+df.FN)]:
        reconstructed = np.divide(df.TP.to_numpy(float), den.to_numpy(float),
                                  out=np.zeros(len(df)), where=den.to_numpy() > 0)
        np.testing.assert_allclose(df[metric], reconstructed, atol=6e-12, rtol=0)
    return df, mapping, metadata


def check_raw_predictions(df, output):
    paths = [APPROOT/mod/f"{pct}%_fragment_predictions_test.csv" for mod in MODS for pct in PCTS]
    if not all(p.exists() for p in paths):
        dump(output/"raw_prediction_check.json", {
            "status": "NOT_RERUN_RAW_FILES_UNAVAILABLE", "cache_confusion_count_check": "PASS",
            "note": "Bundled caches can redraw figures; no new raw-prediction validation claimed."})
        return
    records, sources, cohort_rows = [], {}, []
    parent_reference, fragment_reference, truth_reference = None, {}, None
    for mod in MODS:
        for pct in PCTS:
            path = APPROOT/mod/f"{pct}%_fragment_predictions_test.csv"
            sources[str(path)] = sha(path)
            raw = pd.read_csv(path, usecols=["sequence_id", "parent_sequence_id", "true_type", "predicted_type"])
            assert len(raw) == 22870 and raw.sequence_id.is_unique
            assert raw.notna().all().all()
            counts = raw.groupby("parent_sequence_id").size()
            assert len(counts) == 4574 and counts.eq(5).all()
            parents = set(counts.index)
            if parent_reference is None:
                parent_reference = parents
            assert parents == parent_reference
            ids = set(raw.sequence_id)
            if pct not in fragment_reference:
                fragment_reference[pct] = ids
            assert ids == fragment_reference[pct]
            truths = raw.groupby("parent_sequence_id").true_type.agg(lambda x: tuple(set(x)))
            assert truths.map(len).eq(1).all()
            truth_dict = truths.map(lambda x: x[0]).to_dict()
            if truth_reference is None:
                truth_reference = truth_dict
            assert truth_dict == truth_reference
            true_counts = raw.true_type.value_counts()
            pred_counts = raw.predicted_type.value_counts()
            correct_counts = raw.loc[raw.true_type.eq(raw.predicted_type), "true_type"].value_counts()
            for saved in df[df.Modality.eq(mod) & df.Completeness.eq(pct)].itertuples():
                tp = int(correct_counts.get(saved.Type, 0))
                fp = int(pred_counts.get(saved.Type, 0)) - tp
                fn = int(true_counts.get(saved.Type, 0)) - tp
                tn = len(raw)-tp-fp-fn
                assert (tp, fp, fn, tn) == (saved.TP, saved.FP, saved.FN, saved.TN)
                p = tp/(tp+fp) if tp+fp else 0.
                r = tp/(tp+fn) if tp+fn else 0.
                assert abs(p-saved.Precision) < 6e-12 and abs(r-saved.Recall) < 6e-12
                records.append({"Modality": mod, "Completeness": pct, "Type": saved.Type,
                                "TP": tp, "FP": fp, "FN": fn, "TN": tn,
                                "Precision_from_raw": p, "Recall_from_raw": r})
            cohort_rows.append({"Modality": mod, "Completeness": pct, "Rows": len(raw),
                                "Parents": len(parents), "nonARG_rows": int(raw.true_type.eq("nonARG").sum())})
    write_csv(pd.DataFrame(records), output/"data/raw_prediction_crosscheck.csv")
    write_csv(pd.DataFrame(cohort_rows), output/"data/cohorts.csv")
    dump(output/"raw_prediction_check.json", {"status": "PASS", "checked_type_rows": len(records),
         "checked_metrics": len(records)*2, "common_parents": 4574, "fragment_rows_per_condition": 22870,
         "same_parent_truths": True, "source_sha256": sources})


def spread_labels(y, spacing=.105):
    # Resolve collisions in geometric order, independently of score values.
    order = np.argsort(y)
    positions = np.asarray(y)[order].copy()
    for i in range(1, len(positions)):
        positions[i] = max(positions[i], positions[i-1]+spacing)
    positions -= (positions[0]+positions[-1])/2
    result = np.empty(len(y))
    result[order] = positions
    return result


def radar_panel(ax, part, mapping, positive_only, panel_id, logs, font=8.8):
    lookup = part.set_index("Type")
    full_order = mapping.Type.tolist()
    keep = [typ for typ in full_order if not positive_only or
            (lookup.loc[typ, "Precision"] > 0 and lookup.loc[typ, "Recall"] > 0)]
    assert len(keep) >= 3
    names = mapping.set_index("Type").Display.to_dict()
    names["tetracenomycin_C"] = "Tetracenomycin C"
    n = len(keep)
    # Half-spoke rotation puts no label exactly at the top or bottom seam.
    theta = np.pi/2 - (np.arange(n)+.5)*2*np.pi/n
    x, y = np.cos(theta), np.sin(theta)
    label_artists = []
    for radius in [.2, .4, .6, .8, 1.]:
        ax.add_patch(Circle((0, 0), radius, facecolor="none", edgecolor="#D4D9DF" if radius < 1 else "#626C75",
                            lw=.50 if radius < 1 else .8, zorder=0))
    for xi, yi in zip(x, y):
        ax.plot([0, xi], [0, yi], color="#E2E6EA", lw=.45, zorder=0)
    # Horizontal outward labels with a short leader; no rotated hard-to-read text.
    for side in [-1, 1]:
        indexes = [i for i in range(n) if (x[i] < 0) == (side < 0)]
        new_y = spread_labels(y[indexes]*1.08, spacing=.114)
        for i, yi in zip(indexes, new_y):
            xx = x[i]*1.065 + side*.02
            ax.plot([x[i]*1.01, xx-side*.012], [y[i]*1.01, yi], color="#B1B8BF", lw=.40, zorder=1)
            text = ax.text(xx, yi, names[keep[i]], ha="left" if side > 0 else "right", va="center",
                           fontsize=font, clip_on=False)
            label_artists.append(text)
    for metric in ["Recall", "Precision"]:
        values = lookup.loc[keep, metric].to_numpy(float)
        xx, yy = np.r_[x*values, x[0]*values[0]], np.r_[y*values, y[0]*values[0]]
        ax.fill(xx, yy, color=COLORS[metric], alpha=.055, edgecolor="none", zorder=1)
        line, = ax.plot(xx, yy, color=COLORS[metric], lw=1.15, ls=STYLES[metric],
                        marker=MARKERS[metric], ms=3.0, mew=.7,
                        markerfacecolor=COLORS[metric] if metric == "Precision" else "white", zorder=3)
        for i, typ in enumerate(keep):
            # A no-prediction precision is mathematically undefined. Full audit
            # version retains the source's zero_division=0 score with a hollow dot.
            undefined = metric == "Precision" and lookup.loc[typ, "TP"]+lookup.loc[typ, "FP"] == 0
            if undefined:
                ax.plot(xx[i], yy[i], marker="o", ms=5, mfc="white", mec=COLORS[metric], mew=.9, zorder=4)
            logs.append({"Figure": panel_id[0], "Modality": panel_id[1], "Completeness": panel_id[2],
                         "Type": typ, "Metric": metric, "Score": values[i],
                         "X_drawn": line.get_xdata()[i], "Y_drawn": line.get_ydata()[i],
                         "Angle": theta[i], "No_prediction_precision": bool(undefined)})
    # Same radial ticks in every panel. Backing keeps text legible over fills.
    for radius in [.2, .4, .6, .8, 1.]:
        angle = np.deg2rad(78)
        ax.text(radius*np.cos(angle)+.009, radius*np.sin(angle)-.025, f"{radius:.1f}",
                fontsize=6.7, color="#707A83", ha="left", va="center", zorder=6,
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": .68, "pad": .3})
    ax.set_xlim(-1.94, 1.94)
    ax.set_ylim(-1.18, 1.18)
    ax.set_aspect("equal")
    ax.axis("off")
    return label_artists, keep


def geometry_check(fig, label_groups):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    outside, overlaps = [], []
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        box = text.get_window_extent(renderer)
        if box.width and box.height and (box.x0 < bounds.x0-1 or box.x1 > bounds.x1+1 or
                                        box.y0 < bounds.y0-1 or box.y1 > bounds.y1+1):
            outside.append(text.get_text())
    all_labels = [label for group in label_groups for label in group]
    for i, left in enumerate(all_labels):
        box = left.get_window_extent(renderer)
        for right in all_labels[i+1:]:
            if box.overlaps(right.get_window_extent(renderer)):
                overlaps.append([left.get_text(), right.get_text()])
    assert not outside, f"Outside canvas: {outside}"
    assert not overlaps, f"Overlapping Type labels: {overlaps}"
    return {"outside_canvas_text": 0, "overlapping_type_labels": 0}


def export(fig, name, output, manifest, groups):
    check = geometry_check(fig, groups)
    for ext in ["png", "pdf", "svg"]:
        path = output/f"{name}.{ext}"
        fig.savefig(path, dpi=400)
        manifest.append({"file": path.name, "sha256": sha(path), "width_mm": fig.get_figwidth()*25.4,
                         "height_mm": fig.get_figheight()*25.4, **check})
    fig.savefig(output/f"{name}_preview.png", dpi=100)
    plt.close(fig)


def draw_combined(df, mapping, output, positive_only, manifest, logs):
    name = "01_Type_PR_combined" if positive_only else "02_Type_PR_all23_audit"
    fig = plt.figure(figsize=(360/25.4, 492/25.4))
    gs = fig.add_gridspec(4, 2, left=.038, right=.985, top=.91, bottom=.025,
                         hspace=.23, wspace=.055)
    groups, panel_counts = [], []
    for row, pct in enumerate(PCTS):
        for col, mod in enumerate(MODS):
            ax = fig.add_subplot(gs[row, col])
            part = df[df.Modality.eq(mod) & df.Completeness.eq(pct)]
            labels, keep = radar_panel(ax, part, mapping, positive_only, (name, mod, pct), logs)
            groups.append(labels)
            box = ax.get_position()
            fig.text((box.x0+box.x1)/2, box.y1+.010, f"{pct}%", ha="center", va="bottom", fontsize=11)
            panel_counts.append({"Figure": name, "Modality": mod, "Completeness": pct, "N_types": len(keep)})
            if row == 0:
                fig.text((box.x0+box.x1)/2, .945, "Protein" if mod == "protein" else "DNA", ha="center", fontsize=14, fontweight="bold")
    handles = [Line2D([0], [0], color=COLORS[m], ls=STYLES[m], marker=MARKERS[m], ms=4,
                      mfc=COLORS[m] if m == "Precision" else "white", lw=1.15, label=m)
               for m in ["Precision", "Recall"]]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.52, .994), ncol=2,
               frameon=False, fontsize=11, handlelength=2.8, columnspacing=2)
    export(fig, name, output, manifest, groups)
    return panel_counts


def draw_single(df, mapping, mod, pct, output, manifest, logs):
    name = f"{mod}_{pct}_Type_PR"
    fig = plt.figure(figsize=(190/25.4, 145/25.4))
    ax = fig.add_axes([.025, .06, .95, .80])
    part = df[df.Modality.eq(mod) & df.Completeness.eq(pct)]
    group, _ = radar_panel(ax, part, mapping, True, (name, mod, pct), logs, font=9.5)
    fig.text(.5, .947, f"{'Protein' if mod == 'protein' else 'DNA'} · {pct}%", ha="center", fontsize=12)
    handles = [Line2D([0], [0], color=COLORS[m], marker=MARKERS[m], ls=STYLES[m], lw=1.15,
                      mfc=COLORS[m] if m == "Precision" else "white", label=m)
               for m in ["Precision", "Recall"]]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, .923), frameon=False,
               ncol=2, fontsize=9, handlelength=2.5)
    export(fig, name, output, manifest, [group])


def validate(df, rendered, metadata, output, manifest):
    joined = rendered.merge(df, on=["Modality", "Completeness", "Type"], validate="many_to_one")
    expected = np.where(joined.Metric.eq("Precision"), joined.Precision, joined.Recall)
    np.testing.assert_array_equal(joined.Score, expected)
    np.testing.assert_allclose(np.hypot(joined.X_drawn, joined.Y_drawn), expected, atol=3e-16, rtol=0)
    np.testing.assert_allclose(joined.X_drawn, np.cos(joined.Angle)*expected, atol=0, rtol=0)
    assert len(manifest) == 30
    main = rendered[rendered.Figure.eq("01_Type_PR_combined")]
    assert main.Score.gt(0).all()
    full = rendered[rendered.Figure.eq("02_Type_PR_all23_audit")]
    assert len(full) == 368
    for name, meta in metadata.items():
        assert sha(INPUT/name) == meta["sha256"]
        path = Path(meta["original_path"])
        if path.is_file():
            assert sha(path) == meta["sha256"]
    for entry in manifest:
        path = output/entry["file"]
        assert sha(path) == entry["sha256"]
        if path.suffix == ".png":
            with Image.open(path) as im:
                im.verify()
        elif path.suffix == ".svg":
            ET.parse(path)
        else:
            blob = path.read_bytes()
            assert blob.startswith(b"%PDF-") and b"%%EOF" in blob[-100:]
    return {"status": "PASS", "main_figure_panels": 8, "metrics_per_panel": 2,
            "main_plotted_values": len(main), "full23_plotted_values": len(full),
            "total_checked_drawn_values": len(joined), "exported_designs": 10, "formal_exports": 30,
            "raw_metric_values_unchanged": True, "source_inputs_unchanged": True,
            "outside_canvas_text": 0, "overlapping_type_labels": 0,
            "main_filter": "Precision > 0 AND Recall > 0 per modality/completeness",
            "point_estimates_only": True, "model": "ARGScope_only"}


def package(output):
    path = ROOT/"ARGScope_Type_PR_radar.zip"
    files = [Path(__file__), ROOT/"README_说明.md", ROOT/"双击绘图.bat", ROOT/"render_status.json"]
    files += list(INPUT.glob("*")) + list(output.rglob("*"))
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for file in files:
            if file.is_file():
                z.write(file, Path("ARGScope_Type_PR")/file.relative_to(ROOT))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
    return path


def main():
    df, mapping, metadata = load_sources()
    output = ROOT/("v"+datetime.now().strftime("%y%m%d_%H%M%S"))
    output.mkdir()
    (output/"data").mkdir()
    status = {"status": "RUNNING", "started_utc": datetime.now(timezone.utc).isoformat(),
              "code_sha256": sha(__file__), "figure_directory": str(output)}
    dump(ROOT/"render_status.json", status)
    print("Cross-checking per-Type precision and recall against fragment predictions...", flush=True)
    check_raw_predictions(df, output)
    display = df[["Modality", "Completeness", "Type", "Precision", "Recall", "Support", "Parent_support", "Predicted_positive"]].copy()
    display["Shown_in_main"] = display.Precision.gt(0) & display.Recall.gt(0)
    write_csv(display, output/"data/type_display_filter.csv")
    logs, manifest, counts = [], [], []
    for positive in [True, False]:
        print(f"Rendering combined plot; positive-only={positive}...", flush=True)
        counts += draw_combined(df, mapping, output, positive, manifest, logs)
    for mod in MODS:
        for pct in PCTS:
            print(f"Rendering single panel {mod} {pct}%...", flush=True)
            draw_single(df, mapping, mod, pct, output, manifest, logs)
    rendered = pd.DataFrame(logs)
    write_csv(rendered, output/"data/rendered_points.csv")
    write_csv(pd.DataFrame(counts), output/"data/panel_type_counts.csv")
    report = validate(df, rendered, metadata, output, manifest)
    dump(output/"validation_report.json", report)
    dump(output/"figure_manifest.json", manifest)
    status.update(status="COMPLETE", finished_utc=datetime.now(timezone.utc).isoformat(), validation=report)
    dump(ROOT/"render_status.json", status)
    archive = package(output)
    print(json.dumps({"figures": str(output), "archive": str(archive), "validation": report}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
