#!/usr/bin/env python3
"""Add a full-length Protein binary radar; preserve all 60-90% exports.

Radar: all ARG/nonARG input rows, macro P/R/F1, global Accuracy/MCC.
Bars: the already-reviewed ARG-only Type macro metrics, unchanged numerically.
"""
import argparse
import hashlib
import importlib.util
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
APP = HERE.parent
TRAIN = APP.parents[3]
PUB = APP / 'ARGScope_publication_layout_panels'
REF = APP / 'reference_style_small_panels_23types'
MODELS = ['ARGNet', 'DeepARG', 'PLM-ARG', 'FunGeneTyper', 'ARGScope']
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']
AVERAGES = ['macro', 'weighted', 'micro']
STAMP = datetime.now().strftime('%Y%m%d_%H%M%S')
INPUTS, BACKUPS, AUDIT = {}, [], []
# Extra width preserves heatmap text rather than shrinking all three panels.
CANVAS_MM = (340, 266)
BOXES = {'radar': (0, 182, 74, 84), 'overall': (79, 182, 105, 84),
         'heatmaps': (190, 182, 150, 84), 'umap': (0, 88, 340, 91),
         'confusion': (3, 0, 85, 85), 'errors': (123, 0, 85, 85),
         'subtype': (251, 0, 85, 85)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(path, **kwargs):
    INPUTS[str(path)] = digest(path)
    return pd.read_csv(path, keep_default_na=False, **kwargs)


def backup(path):
    if path.exists() and not any(item['path'] == str(path) for item in BACKUPS):
        target = HERE / 'backup_binary_radar' / STAMP / f'{len(BACKUPS):03d}_{path.name}'
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        BACKUPS.append({'path': str(path), 'backup': str(target), 'sha256': digest(path)})


def binary_scores(model, ids, truth, prediction, path, rule):
    truth, prediction = np.asarray(truth, dtype=int), np.asarray(prediction, dtype=int)
    assert len(ids) == len(truth) == len(prediction) and pd.Series(ids).is_unique
    assert set(truth) == {0, 1} and set(prediction) <= {0, 1}
    tp = int(np.sum((truth == 1) & (prediction == 1)))
    fn = int(np.sum((truth == 1) & (prediction == 0)))
    fp = int(np.sum((truth == 0) & (prediction == 1)))
    tn = int(np.sum((truth == 0) & (prediction == 0)))
    n = len(truth)
    acc = (tp + tn) / n
    denom = np.sqrt(float((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
    mcc = (tp * tn - fp * fn) / denom if denom else 0.0
    assert abs(acc - accuracy_score(truth, prediction)) < 1e-12
    assert abs(mcc - matthews_corrcoef(truth, prediction)) < 1e-12
    div = lambda a, b: a / b if b else 0.0
    cls_p = np.array([div(tn, tn + fn), div(tp, tp + fp)])
    cls_r = np.array([div(tn, tn + fp), div(tp, tp + fn)])
    cls_f = np.array([div(2 * tn, 2 * tn + fn + fp), div(2 * tp, 2 * tp + fn + fp)])
    support = np.array([tn + fp, tp + fn])
    rows = []
    for avg in AVERAGES:
        p, r, f, _ = precision_recall_fscore_support(truth, prediction, labels=[0, 1], average=avg, zero_division=0)
        expected = [values.mean() if avg == 'macro' else np.dot(values, support) / n if avg == 'weighted' else acc
                    for values in (cls_p, cls_r, cls_f)]
        np.testing.assert_allclose([p, r, f], expected, rtol=0, atol=1e-12)
        rows.append(dict(Model=model, Completeness=100, Level='ARG_nonARG', Scope='ARG_and_nonARG',
                         Average=avg, N=n, N_ARG=tp + fn, N_nonARG=tn + fp, TP=tp, FN=fn, FP=fp, TN=tn,
                         Accuracy=acc, Precision=p, Recall=r, F1=f, MCC=mcc, Source=str(path), Decision_rule=rule))
    AUDIT.append(dict(Model=model, N=n, N_ARG=tp + fn, N_nonARG=tn + fp,
                      Source=str(path), Decision_rule=rule, Independent_formula_check=True,
                      Matched_to_new_ARGScope_test=(model == 'ARGScope')))
    return rows


def calculate():
    archived = TRAIN / 'ARGscope_result_9.16'
    paths = {
        'ARGNet': archived / 'ARGnet/protein/ARGNet_type_metrics_results/mapped_predictions/protein_100pct_5parts_argnet-l_aa_result_mapped_type_predictions.csv',
        'FunGeneTyper': archived / 'FunGenetyper/Protein/FunGeneTyper_Protein_metrics_results/mapped_predictions/100p_result_mapped_type_predictions.csv',
        'PLM-ARG': archived / 'PLMARG/Protein/PLMARG_Protein_metrics_results/mapped_predictions/protein_100pct_plmarg_result_mapped_type_predictions.csv',
    }
    rows, reference = [], None
    for model, path in paths.items():
        data = source(path)
        assert data.ARG_prediction.isin(['ARG', 'nonARG']).all()
        current = data.set_index('test_id').true_type
        if reference is None:
            reference = current
        else:
            pd.testing.assert_series_equal(current.sort_index(), reference.sort_index())
        items = binary_scores(model, data.test_id, data.true_type.ne('nonARG'),
                              data.ARG_prediction.eq('ARG'), path, 'Archived ARG_prediction, no threshold change')
        expected = source(path.parent.parent / '01_ARG_nonARG_overall_five_metrics.csv', dtype=str)
        for row in items:
            old = expected[(expected.condition == '100%') & (expected.average == row['Average'])].iloc[0]
            for metric in METRICS:
                token = old[metric.lower()].strip()
                places = len(token.partition('.')[2])
                assert abs(row[metric] - float(token)) <= .5 * 10 ** (-places) + 1e-12
        rows.extend(items)

    # The original full input FASTA establishes the denominator. An ARG call
    # is membership in mapping.ARG; no ARG call is a negative detection outcome,
    # not a deletion from evaluation. potential.ARG is not a final positive.
    fasta = TRAIN / '1. Dataset/最后的数据集/all_arg_nonarg_protein.fasta'
    INPUTS[str(fasta)] = digest(fasta)
    with fasta.open(encoding='utf-8') as stream:
        input_ids = [line[1:].strip().split()[0] for line in stream if line.startswith('>')]
    assert len(input_ids) == len(set(input_ids)) == len(reference)
    assert set(input_ids) == set(reference.index)
    path = archived / 'DeepARG/protein/all_arg_nonarg_protein_deeparg_LS_prot.mapping.ARG'
    calls = source(path, sep='\t')
    assert calls.read_id.is_unique and set(calls.read_id) <= set(input_ids)
    assert calls.probability.between(.8, 1).all()
    potential_path = path.with_name(path.name.replace('.mapping.ARG', '.mapping.potential.ARG'))
    potential = source(potential_path, sep='\t')
    assert set(potential.read_id) <= set(input_ids)
    rule = 'Full input FASTA; mapping.ARG IDs = positive; all other input IDs = no ARG call (negative); potential.ARG excluded'
    rows.extend(binary_scores('DeepARG', input_ids, reference.loc[input_ids].ne('nonARG'),
                              pd.Series(input_ids).isin(set(calls.read_id)), path, rule))
    own = APP / 'protein/100%_test_sequence_predictions.csv'
    data = source(own)
    assert data.completeness_percent.eq(100).all()
    assert data.true_ARG.astype(int).eq(data.true_type.ne('nonARG').astype(int)).all()
    rows.extend(binary_scores('ARGScope', data.sequence_id, data.true_ARG, data.predicted_ARG,
                              own, 'Saved predicted_ARG and its original threshold; new held-out test'))
    frame = pd.DataFrame(rows)
    frame['_order'] = frame.Model.map(dict(zip(MODELS, range(5))))
    frame = frame.sort_values(['_order', 'Average']).drop(columns='_order')
    assert len(frame) == 15 and frame.N_nonARG.gt(0).all()
    return frame


def load_plotter():
    spec = importlib.util.spec_from_file_location('original_publication_layout', PUB / 'plot_publication_panels.py')
    pub = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pub)
    pub.prepare(cached=True)
    return pub


def draw_radar(pub, fig, box, frame, models=None):
    fw, fh = fig.get_size_inches() * 25.4
    x, y, w, h = box
    ax = fig.add_axes([(x + 12) / fw, (y + 21) / fh, 48 / fw, 48 / fh], projection='polar')
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    angles = np.arange(5) * 2 * np.pi / 5
    closed = np.r_[angles, angles[0]]
    ax.set_xticks(angles, ['Accuracy', 'Macro\nPrecision', 'Macro\nRecall', 'Macro\nF1', 'MCC'], fontsize=6.5)
    ax.tick_params(axis='x', pad=1.5)
    ax.set_ylim(0, 1)
    ax.set_yticks([.2, .4, .6, .8, 1.0], ['0.2', '0.4', '0.6', '0.8', '1.0'], fontsize=4.7, color='#6f6f6f')
    ax.set_rlabel_position(35)
    ax.grid(color='#dadada', linewidth=.4)
    ax.spines['polar'].set_color('#797979')
    ax.spines['polar'].set_linewidth(.6)
    markers = dict(zip(MODELS, ['o', 's', '^', 'D', 'P']))
    styles = dict(zip(MODELS, ['--', '-.', ':', '--', '-']))
    handles = []
    for model in (MODELS if models is None else models):
        row = frame[frame.Model.eq(model)].iloc[0]
        values = row[METRICS].to_numpy(float)
        assert np.isfinite(values).all() and ((values >= 0) & (values <= 1)).all()
        color = pub.MODEL_COLORS[model]
        line, = ax.plot(closed, np.r_[values, values[0]], color=color, lw=1.05,
                        marker=markers[model], ms=3.0, mec='#555555', mew=.25,
                        linestyle=styles[model], clip_on=False, label=model)
        np.testing.assert_array_equal(line.get_ydata(), np.r_[values, values[0]])
        if model == 'ARGScope':
            ax.fill(closed, np.r_[values, values[0]], color=color, alpha=.08)
        handles.append(Line2D([], [], color=color, lw=1.05, marker=markers[model], ms=3,
                              markeredgecolor='#555555', markeredgewidth=.25, linestyle=styles[model], label=model))
    ax.text(.5, .5, 'ARG /\nnon-ARG', transform=ax.transAxes, ha='center', va='center', fontsize=6, color='#555555')
    fig.legend(handles=handles, ncol=2, loc='upper left', mode='expand',
               bbox_to_anchor=pub.normalized_box(fig, box, (4, 1, 67, 14)),
               bbox_transform=fig.transFigure, frameon=False, borderaxespad=0,
               fontsize=5.6, handlelength=2.0, columnspacing=.7, labelspacing=.5)


def export(pub, fig, stem, preview):
    geometry = pub.check_geometry(fig, stem.name)
    target = HERE / '_radar_preview' / stem.name
    target.parent.mkdir(exist_ok=True)
    fig.savefig(target.with_suffix('.png'), dpi=150)
    if not preview:
        stem.parent.mkdir(exist_ok=True)
        for extension in ['png', 'pdf', 'svg']:
            path = stem.with_suffix('.' + extension)
            backup(path)
            fig.savefig(path, dpi=600 if extension == 'png' else 150)
    plt.close(fig)
    return geometry


def main(preview=False):
    # Freeze previously delivered data, fragment figures and all UMAP inputs.
    protected = {p: digest(p) for p in (HERE / 'figures').glob('*') if any(f'_{pct}pct_' in p.name for pct in (60, 70, 80, 90))}
    protected.update({p: digest(p) for p in (PUB / 'data').rglob('*') if p.is_file()})
    result = calculate()
    macro = result[result.Average.eq('macro')]
    pub = load_plotter()
    full = pub.condition_data('protein', 100)
    frames = pub.umap_data('protein')
    checks = {}
    fig = plt.figure(figsize=(74 / 25.4, 84 / 25.4), dpi=150)
    draw_radar(pub, fig, (0, 0, 74, 84), macro)
    checks['binary_radar'] = export(pub, fig, HERE / 'figures/Protein_100pct_ARG_nonARG_radar', preview)
    fig = pub.canvas('overall')
    pub.draw_overall(fig, (0, 0, *pub.SIZES['overall']), 'protein', full)
    checks['type_bars'] = export(pub, fig, HERE / 'figures/Protein_100pct_macro_comparison', preview)
    fig = plt.figure(figsize=(CANVAS_MM[0] / 25.4, CANVAS_MM[1] / 25.4), dpi=150)
    draw_radar(pub, fig, BOXES['radar'], macro)
    pub.draw_overall(fig, BOXES['overall'], 'protein', full)
    pub.draw_heatmaps(fig, BOXES['heatmaps'], 'protein', full)
    pub.draw_umap(fig, BOXES['umap'], 'protein', frames)
    for kind in ('confusion', 'errors'):
        pub.draw_matrix(fig, BOXES[kind], 'protein', full, kind)
    pub.draw_subtype(fig, BOXES['subtype'], 'protein', full)
    checks['assembled'] = export(pub, fig, HERE / 'figures/Protein_100pct_assembled_macro', preview)
    assert all(digest(path) == old for path, old in protected.items())
    assert all(digest(Path(path)) == old for path, old in INPUTS.items())
    if not preview:
        for filename, frame in [('07_ARG_nonARG_100pct_macro_weighted_micro.csv', result),
                                ('08_ARG_nonARG_100pct_radar_values.csv', macro),
                                ('09_ARG_nonARG_source_audit.csv', pd.DataFrame(AUDIT))]:
            path = HERE / filename
            backup(path)
            frame.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.15g')
        targets = {
            'Protein_100pct_ARG_nonARG_radar': [PUB / 'Protein/100pct/ARG_nonARG_radar_protein_100pct'],
            'Protein_100pct_macro_comparison': [PUB / 'Protein/100pct/overall_protein_100pct', REF / 'Protein/100pct/A_protein_100pct_overall_comparison'],
            'Protein_100pct_assembled_macro': [PUB / 'Protein/Protein_100pct_assembled'],
        }
        for stem, destinations in targets.items():
            for dst in destinations:
                for ext in ['png', 'pdf', 'svg']:
                    path = dst.with_suffix('.' + ext)
                    backup(path)
                    shutil.copy2(HERE / 'figures' / f'{stem}.{ext}', path)
        report_path = PUB / 'LAYOUT_VALIDATION.json'
        backup(report_path)
        report = json.loads(report_path.read_text(encoding='utf-8'))
        replacements = []
        for panel, size, stem, geometry in [
            ('binary_radar', (74, 84), 'Protein/100pct/ARG_nonARG_radar_protein_100pct', checks['binary_radar']),
            ('overall', (105, 84), 'Protein/100pct/overall_protein_100pct', checks['type_bars']),
            ('assembled', CANVAS_MM, 'Protein/Protein_100pct_assembled', checks['assembled'])]:
            replacements.append(dict(modality='protein', completeness_percent=100, panel=panel,
                                     width_mm=size[0], height_mm=size[1],
                                     files=[stem + '.' + ext for ext in ('png', 'pdf', 'svg')], **geometry))
        keys = {(row['modality'], row['completeness_percent'], row['panel']) for row in replacements}
        report['panels'] = [row for row in report['panels'] if (row['modality'], row['completeness_percent'], row['panel']) not in keys] + replacements
        report['figures'] = len(report['panels'])
        report['exports'] = sum(len(row['files']) for row in report['panels'])
        report['binary_radar_update'] = dict(date=STAMP, scope='Protein 100% only',
                                            average='macro', first_row=list(BOXES)[:3],
                                            bar_hatches=pub.MODEL_HATCHES,
                                            source=str(HERE / '08_ARG_nonARG_100pct_radar_values.csv'))
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
        index_path = PUB / 'PANEL_INDEX.csv'
        backup(index_path)
        pd.DataFrame([{key: value for key, value in row.items() if key != 'files'} | {'files': ';'.join(row['files'])}
                      for row in report['panels']]).to_csv(index_path, index=False, encoding='utf-8-sig')
        audit = dict(scope='Protein 100% only', first_row=['binary radar', 'Type macro bars', 'Type heatmaps'],
                     canvas_mm=CANVAS_MM, boxes_mm=BOXES, binary_average='macro',
                     macro_labels=['ARG', 'nonARG'], Type_values_unchanged=True,
                     fragments_60_to_90_unchanged=True, UMAP_coordinates_unchanged=True,
                     input_sha256=INPUTS, protected_file_count=len(protected), geometry=checks,
                     backup_manifest=BACKUPS, source_populations_NOT_matched=True)
        # Current delivery ZIP contains only final figures, tables and notes.
        archive = HERE / 'Protein_macro_results_and_figures.zip'
        backup(archive)
        (HERE / '100pct_binary_radar_validation.json').write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding='utf-8')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
            for path in sorted(HERE.iterdir()):
                if path.is_file() and path.suffix in {'.csv', '.md', '.json'}:
                    z.write(path, path.name)
            for path in sorted((HERE / 'figures').iterdir()):
                if path.suffix in {'.png', '.pdf', '.svg'}:
                    z.write(path, path.relative_to(HERE))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
    print(macro[['Model', 'N', 'N_ARG', 'N_nonARG', *METRICS]].to_string(index=False), flush=True)
    print('PASS: radar and three-column first row rendered; Type values, 60-90% exports and UMAP inputs unchanged.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preview', action='store_true')
    main(preview=parser.parse_args().preview)
