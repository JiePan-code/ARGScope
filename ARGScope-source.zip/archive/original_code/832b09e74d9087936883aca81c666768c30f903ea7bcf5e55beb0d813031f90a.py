"""Larger Figure 4 labels, preserving all plotted values and removing B row labels."""
from pathlib import Path
import json
import shutil
import zipfile
import importlib.util
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('existing_figure4', HERE/'plot_figure4_including_nonarg.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
KEEP_B_ROW_LABELS='--keep-row-labels' in sys.argv
OUT = HERE/('outputs/figure4_larger_fonts_row_labels_20260923' if KEEP_B_ROW_LABELS else 'outputs/figure4_larger_fonts_20260923')
DELIVERY = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片')/('Figure4_字体放大_保留Protein_DNA_20260923' if KEEP_B_ROW_LABELS else 'Figure4_字体放大_B删除行标题_20260923')
base.OUT = OUT


def legend(fig, radar=False):
    if radar:
        handles=[Line2D([],[],color=base.COLORS[m],ls=base.prior.STYLES[m],marker=base.prior.MARKERS[m],
                  lw=1.55,ms=4.8,mfc=base.COLORS[m] if m=='ARGScope' else 'none',label=m)
                 for m in base.MODELS['Protein']]
    else:
        handles=[Patch(facecolor=base.COLORS[m],edgecolor='#5B6268',hatch='///' if m=='DeepARG' else None,
                       label=f'{base.SHORT[m]}  {m}') for m in base.MODELS['Protein']]
    return fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,1.005),ncol=5,frameon=False,
                      fontsize=15,columnspacing=1.5,handlelength=2.1 if radar else 1.55,handletextpad=.5,borderaxespad=0)


def main():
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':13,'svg.fonttype':'path','pdf.fonttype':42,
        'text.color':'#24292D','hatch.linewidth':.5,'figure.facecolor':'none','axes.facecolor':'none',
        'savefig.facecolor':'none','savefig.transparent':True})
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'data').mkdir(exist_ok=True)
    summary,per,tables,display,hashes=base.data()

    # A retains the two modality names and the original eight circular bar charts.
    fig=plt.figure(figsize=(478/25.4,226/25.4))
    legend(fig)
    groups=[]; outer=[]
    for row,mod in enumerate(base.MODELS):
        for col,pct in enumerate(base.PCTS):
            ax=base.axes_mm(fig,13+117*col,9+106*row,104,104,polar=True)
            numbers,labels=base.sector(ax,mod,pct,summary)
            for t in numbers:
                t.set_fontsize(13)
                angle,radius=t.get_position()
                if radius>1:t.set_position((angle,1.13))
            for t in labels:
                t.set_fontsize(10.8 if t.get_text() in base.SHORT.values() else 16)
                if t.get_text() in base.SHORT.values():t.set_position((t.get_position()[0],1.62))
                if t.get_text()=='Macro\nprecision':t.set_position((np.deg2rad(60),2.22))
                elif t.get_text()=='Macro\nrecall':t.set_position((np.deg2rad(144),2.17))
                elif t.get_text()=='Macro F1':t.set_position((np.deg2rad(216),2.08))
                elif t.get_text()=='MCC':t.set_position((np.deg2rad(288),2.02))
            for t in ax.texts:
                if t in numbers or t in labels:continue
                t.set_fontsize(15 if '\n' in t.get_text() else 9.8)
            groups.append(numbers+labels);outer.extend(labels)
        base.text_mm(fig,3,61+106*row,mod,rotation=90,ha='center',va='center',fontsize=17,fontweight='bold')
    base.text_mm(fig,0,2,'A',ha='left',va='top',fontsize=21,fontweight='bold')
    base.save(fig,'Figure4A_larger_fonts',groups+[outer])

    # B preserves row order; the latest user request restores both row names.
    fig=plt.figure(figsize=(528/25.4,183/25.4))
    legend(fig,radar=True)
    old_spread=base.prior.spread
    base.prior.spread=lambda values,spacing=.16:old_spread(values,spacing=.19)
    groups=[]
    for row,mod in enumerate(base.MODELS):
        for col,pct in enumerate(base.PCTS):
            ax=base.axes_mm(fig,3+132*col,17+83*row,110,70.3)
            labels=base.radar(ax,mod,pct,tables[mod,pct],display)
            for t in labels:t.set_fontsize(13)
            for t in ax.texts:
                if t not in labels:t.set_fontsize(9.5)
            for line in ax.lines:
                if line.get_marker() not in ['None','none','',None]:
                    line.set_markersize(3.8)
                    line.set_linewidth(1.5 if line.get_color()==base.COLORS['ARGScope'] else 1.1)
            groups.extend(labels)
            if row==0:base.text_mm(fig,58+132*col,13,f'{pct}%',ha='center',va='center',fontsize=17,fontweight='bold')
    tag_x=0
    if KEEP_B_ROW_LABELS:
        fig.canvas.draw()
        min_x_mm=fig.get_tightbbox(fig.canvas.get_renderer()).x0*25.4
        for row,mod in enumerate(base.MODELS):
            base.text_mm(fig,min_x_mm-7.5,52.15+83*row,mod,rotation=90,
                         ha='center',va='center',fontsize=17,fontweight='bold')
        tag_x=min_x_mm-11.5
    base.text_mm(fig,tag_x,2,'B',ha='left',va='top',fontsize=21,fontweight='bold')
    assert not any(t.get_text() in ['Protein','DNA'] for ax in fig.axes for t in ax.texts)
    row_names=[t.get_text() for t in fig.texts if t.get_text() in ['Protein','DNA']]
    assert row_names==(['Protein','DNA'] if KEEP_B_ROW_LABELS else [])
    base.save(fig,'Figure4B_larger_fonts_with_row_labels' if KEEP_B_ROW_LABELS else 'Figure4B_larger_fonts_no_row_labels',[groups])

    bars=pd.DataFrame(base.BAR_RECORDS); points=pd.DataFrame(base.RADAR_RECORDS)
    previous=HERE/'outputs/figure4_60_90_including_nonARG_20260922/data'
    for name,frame,keys,values in [
        ('A_five_metric_values',bars,['Modality','Completeness','Model','Metric'],['Value']),
        ('B_precision_values',points,['Modality','Completeness','Model','Type'],['Precision'])]:
        old=pd.read_csv(previous/(name+'.csv'))
        a=frame.sort_values(keys).reset_index(drop=True)
        b=old.sort_values(keys).reset_index(drop=True)
        pd.testing.assert_frame_equal(a[keys],b[keys])
        np.testing.assert_allclose(a[values],b[values],rtol=0,atol=2e-15)
        frame.to_csv(OUT/'data'/(name+'.csv'),index=False,encoding='utf-8-sig',float_format='%.17g')
    for path,value in hashes.items():assert base.sha(path)==value
    assert len(bars)==160 and len(points[points.Type.eq('nonARG')])==32
    report={'status':'PASS','original_metrics_and_scope_preserved':True,'same_plotted_categories':True,
        'B_Protein_DNA_labels_removed':not KEEP_B_ROW_LABELS,'B_Protein_DNA_labels_preserved':KEEP_B_ROW_LABELS,'A_Protein_DNA_labels_preserved':True,
        'A_fonts_pt':{'numeric':13,'metric_names':16,'center':15,'model_abbreviations':10.8,'legend':15},
        'B_fonts_pt':{'category':13,'percentage_headers':17,'legend':15,'scale':9.5},
        'source_hashes':hashes,'exports':base.EXPORTS,'all_values_match_previous_plots':True,
        'note':'Model-specific source cohorts and original displayed-type filtering remain unchanged.'}
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    b_note='B：保留左侧 Protein / DNA，上排Protein，下排DNA。' if KEEP_B_ROW_LABELS else 'B：删除左侧 Protein / DNA，仍按原图上排蛋白质、下排核酸排列。'
    (OUT/'README.txt').write_text('Figure 4 字体放大版\nA：保留 Protein / DNA 行标题。\n'+b_note+'\n数字、类别名和图例放大，数据及评价口径不变。\n根目录 SVG 为文字转曲版，editable_text 内为可编辑 Arial 文字版。均为透明背景矢量图。\n',encoding='utf-8')
    shutil.copy2(__file__,OUT/'data'/Path(__file__).name)
    DELIVERY.mkdir(parents=True,exist_ok=True)
    for p in OUT.rglob('*'):
        if p.is_file() and 'qa' not in p.relative_to(OUT).parts:
            dest=DELIVERY/p.relative_to(OUT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    with zipfile.ZipFile(DELIVERY/'Figure4_A_B_SVG.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in DELIVERY.rglob('*'):
            if p.is_file() and p.suffix!='.zip':z.write(p,p.relative_to(DELIVERY))
    print('DELIVERY',DELIVERY,flush=True)


if __name__=='__main__':main()
