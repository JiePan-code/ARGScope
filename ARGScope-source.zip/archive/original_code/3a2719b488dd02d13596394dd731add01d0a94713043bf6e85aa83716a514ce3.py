from pathlib import Path
from types import SimpleNamespace
import math
import runpy
import ast
import plot_precision_60_90_fixed_protein80 as fixed

original_path = Path(r'C:\Users\Jie Pan\.codex\attachments\316c4b7e-bf23-41d3-be2d-42ee783f52f3\pasted-text.txt')
old = runpy.run_path(str(original_path))
root = Path(r'E:\1. ARGmodel\1. NonARG_training\Type_level_performance')
out = root / 'Protein_DNA_60_90pct_Precision_heatmaps'
args = SimpleNamespace(root=root, manifest=None, score_scale='fraction')
before = old['discover'](args, out)
after = fixed.discover(args, out)
target = ('Protein', 'ARGScope', 80)
assert target not in before
assert target in after
for combo, (path, values) in before.items():
    assert after[combo][0] == path
    assert values.keys() == after[combo][1].keys()
    for t, v in values.items():
        actual = after[combo][1][t]
        assert v == actual or math.isnan(v) and math.isnan(actual)
assert set(after) - set(before) == {target}
old_tree = ast.parse(original_path.read_text(encoding='utf-8'))
new_tree = ast.parse(Path(fixed.__file__).read_text(encoding='utf-8'))
for name in ('plot', 'average', 'main'):
    get = lambda tree: next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    assert ast.dump(get(old_tree)) == ast.dump(get(new_tree))
for name in ('CELL_WIDTH', 'CELL_HEIGHT', 'AVERAGE_GAP', 'DNA_COLORS', 'TYPE_ORDER', 'ANNOTATION_SIZE'):
    assert old[name] == getattr(fixed, name)
# Include false positives from nonARG and from Types outside the displayed set.
rows = [{'truetype': t, 'predictedtype': p} for t, p in [
    ('MLS', 'macrolide-lincosamide-streptogramin'), ('nonARG', 'MLS'),
    ('other_type', 'MLS'), ('MLS', 'nonARG'), ('bleomycin', 'bleomycin')]]
context = 'ARGscope/protein_80%_test_predictions.csv'
values = fixed.protein80_precision_from_predictions(rows, context, Path(context))[target]
assert values['MLS'] == 1/3 and values['bleomycin'] == 1
assert values['vancomycin'] == 0
assert fixed.protein80_precision_from_predictions(rows, context.replace('80%', '70%'), Path(context)) == {}
assert fixed.protein80_precision_from_predictions(rows, context.replace('protein', 'DNA'), Path(context)) == {}
print('PASS: actual data gains only Protein ARGScope 80%; all previous data and plotting settings unchanged.')
print('SOURCE:', after[target][0])
print('AVERAGE:', fixed.average(after[target][1]))
print('VALUES:', after[target][1])
