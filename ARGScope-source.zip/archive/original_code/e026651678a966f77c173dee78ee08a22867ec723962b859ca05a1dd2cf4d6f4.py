"""Regression and sklearn cross-checks for independent supplied-file metrics."""
import csv
import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\消融实验结果")
SCRIPT = ROOT / "calculate_provided_ablation_metrics.py"
OUT = ROOT / "provided_ablation_metrics_20260918_142959_469429"
spec = importlib.util.spec_from_file_location("provided_metrics", SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def check_different_populations():
    with tempfile.TemporaryDirectory(prefix="independent_regression_", dir=Path(__file__).parent) as folder:
        root = Path(folder).resolve()
        assert root.parent == Path(__file__).resolve().parent
        for index, (variant, modality) in enumerate((v, mod) for v in m.VARIANTS for mod in m.MODALITIES):
            # Different sample counts, disjoint IDs, label sets AND subtype->Type maps
            # must not borrow Full metadata or fail cross-model validation.
            rows = [{"sequence_id": f"{index}_{i}", "true_subtype": "s" if i else "nonARG",
                     "predicted_subtype": "s" if i else "nonARG",
                     "true_type": f"type_{index}" if i else "nonARG",
                     "predicted_type": f"type_{index}" if i else "nonARG",
                     "true_ARG": int(i > 0), "predicted_ARG": int(i > 0)} for i in range(index+2)]
            path = root / variant / modality.lower() / "test_sequence_predictions.csv"
            m.write_csv(path, rows)
        result = m.calculate(root)
        summary = read(result / "00_all_models_summary.csv")
        audit = read(result / "00_input_audit.csv")
        assert len(summary) == 56 and len(audit) == 8
        assert [int(r["N_test"]) for r in audit] == list(range(2, 10))
        assert all(float(r["Accuracy"]) == float(r["F1"]) == 1.0 for r in summary)
        assert all(int(r["Rows_filtered"]) == 0 for r in audit)
        assert len(m.discover_files(root)) == 8
        try:
            m.calculate(root, result)
        except FileExistsError:
            pass
        else:
            raise AssertionError("Existing outputs must not be overwritten")


def verify_actual_outputs():
    notes = json.loads((OUT / "calculation_notes.json").read_text(encoding="utf-8"))
    audit = read(OUT / "00_input_audit.csv")
    runs = {(r["Variant"], r["Modality"]): read(ROOT / r["Source_file"]) for r in audit}
    checks, max_error = 0, 0.0
    tables = ["00_all_models_summary.csv", "05_ARG_nonARG_macro_weighted_micro_optional.csv",
              "ARG_only/02_Type_macro_weighted_micro.csv", "ARG_only/03_Subtype_macro_weighted_micro.csv",
              "04_Per_type_five_metrics.csv", "ARG_only/04_Per_type_five_metrics.csv"]
    for filename in tables:
        for row in read(OUT / filename):
            data = runs[row["Variant"], row["Modality"]]
            assert int(row["N_test"]) == len(data)
            assert int(row["ARG_n"]) == sum(int(r["true_ARG"]) for r in data)
            per_class = "Label" in row
            arg_only = filename.startswith("ARG_only")
            if arg_only:
                data = [r for r in data if int(r["true_ARG"]) == 1]
                assert int(row["N_evaluated"]) == len(data)
            level = "type" if per_class else row.get("Level", "ARG_nonARG")
            column = "ARG" if level == "ARG_nonARG" else level
            y, p = ([r[side+"_"+column] for r in data] for side in ["true", "predicted"])
            if per_class:
                y, p = ([int(x == row["Label"]) for x in arr] for arr in [y, p])
                avg, labels = "binary", [0, 1]
            elif column == "ARG":
                y, p = list(map(int, y)), list(map(int, p))
                avg = "binary" if row["Average"] == "binary_ARG_positive" else row["Average"]
                labels = [0, 1]
            else:
                labels = sorted((set(y) | set(p)) - ({"nonARG"} if arg_only else set()))
                avg = row["Average"]
            pr, re, f1, _ = precision_recall_fscore_support(y, p, average=avg, labels=labels, zero_division=0)
            expected = dict(Accuracy=accuracy_score(y, p), Precision=pr, Recall=re, F1=f1, MCC=matthews_corrcoef(y, p))
            for name, value in expected.items():
                error = abs(float(row[name])-value)
                assert error < 1e-11, (filename, row["Variant"], row["Modality"], name, error)
                max_error = max(max_error, error)
                checks += 1
    assert len(read(OUT / "00_all_models_summary.csv")) == 56
    assert len(list((OUT / "per_type").glob("*.csv"))) == 24
    for row in audit:
        path = ROOT / row["Source_file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row["Input_SHA256"]
        assert int(row["Rows_used"]) == int(row["N_test"])
        assert int(row["Rows_filtered"]) == 0
    assert notes["cross_model_test_set_equality_required"] is False
    print(json.dumps(dict(status="PASS", independent_metric_checks=checks,
                          max_rounding_error=max_error, source_files_unchanged=True,
                          input_counts=[r["N_test"] for r in audit])))


if __name__ == "__main__":
    check_different_populations()
    verify_actual_outputs()
