"""Assemble QA-only contact sheets without modifying any output figure."""
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent
QA=ROOT/'document_qa'
def contact(paths,stem,cols=2,cell=(900,1000)):
    sheet=Image.new('RGB',(cols*cell[0],((len(paths)+cols-1)//cols)*cell[1]),'#eeeeee')
    for i,p in enumerate(paths):
        im=Image.open(p).convert('RGB'); im.thumbnail((cell[0]-20,cell[1]-35))
        x=(i%cols)*cell[0]; y=(i//cols)*cell[1]
        sheet.paste(im,(x+(cell[0]-im.width)//2,y+28))
        ImageDraw.Draw(sheet).text((x+10,y+7),p.stem,fill='black')
    sheet.save(QA/f'{stem}.png')
pages=sorted(QA.glob('page-*.png'))
for i in range(0,len(pages),4): contact(pages[i:i+4],f'review_document_{i//4+1}',cell=(800,1150))
for mod in ['Protein','DNA']:
    previews=sorted((ROOT/'workbook_previews').glob(f'{mod}_*.png'))
    for i in range(0,len(previews),4):contact(previews[i:i+4],f'review_{mod}_workbooks_{i//4+1}',cols=1,cell=(1700,310))
    for kind in ['macro_bars','precision_recall_F1']:
        paths=[ROOT/'figures_Type_ARG_only'/mod/f'{mod}_{p}pct_Type_{kind}.png' for p in [60,70,80,90,100]]
        if all(p.exists() for p in paths):contact(paths,f'review_{mod}_{kind}',cols=3,cell=(850,690))
print('Review contact sheets prepared.')
