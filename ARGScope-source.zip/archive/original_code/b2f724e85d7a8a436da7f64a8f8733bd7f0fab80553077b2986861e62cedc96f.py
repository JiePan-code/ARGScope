#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope Protein 100% Novel-Gene training - Windows local version.

Novel-gene benchmark definition
-------------------------------
1. External TRAIN and TEST IDs are read from the new split.
2. ARG subtype overlap between external TRAIN and TEST must be exactly zero.
3. Every TEST ARG Type must occur in external TRAIN.
4. The subtype classifier contains TRAIN ARG subtypes only.
5. TEST-only ARG subtypes are NEVER classifier classes and are NEVER used
   for Teacher/Student optimization or validation.
6. Validation is carved only from external TRAIN.
7. Final TEST reporting is Type-level:
      - ARG/nonARG
      - Type_on_true_ARG
      - Type_oracle_binary
      - End_to_end_Type
   Exact TEST subtype accuracy is intentionally not reported because all
   TEST ARG subtypes are novel by construction.

Model inputs
------------
Protein:
    ESM2_full_1to1/full_1to1_esm2_mean.pt
    ESM-2 mean pooled, 1280D

Fusion:
    Long_fusion/long_fusion.pt
    512D gated-fusion representation

Prototype prior:
    Refined_subtype_prototypes_long/
    refined_ARG_subtype_prototypes_residual_GAT.pt
    512D residual-GAT subtype prototypes

The network architecture and scientific hyperparameters are kept at the
selected Protein GRID-best configuration:
    effective batch size = 4096
    eval batch size      = 8192
    Teacher epochs       = 100
    Student epochs       = 200
    Teacher LR           = 2e-4
    Student LR           = 1e-4
    weight decay         = 3e-5
    Protein mapper       = 1280 -> 1536 -> 1024 -> 512
    dropout              = 0.10

For an 8-GB local GPU, the 4096 effective batch is implemented by gradient
accumulation over 128-sample CUDA micro-batches. This changes memory usage,
not the logical batch size.

CUDA is required. There is no silent CPU fallback.
"""

from __future__ import annotations

import copy
import csv
import json
import math
import os
import random
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)


# =============================================================================
# Windows paths
# =============================================================================

ROOT = Path(
    r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\5. novel gene"
)

PROTEIN_PT = (
    ROOT
    / "ESM2_full_1to1"
    / "full_1to1_esm2_mean.pt"
)

FUSION_PT = (
    ROOT
    / "Long_fusion"
    / "long_fusion.pt"
)

REFINED_PT = (
    ROOT
    / "Refined_subtype_prototypes_long"
    / "refined_ARG_subtype_prototypes_residual_GAT.pt"
)

# Preferred location produced by the Novel-Gene split script.
SPLIT_DIR = (
    ROOT
    / "Dataset"
)

TRAIN_IDS_FILE = SPLIT_DIR / "train_ids.txt"
TEST_IDS_FILE = SPLIT_DIR / "test_ids.txt"
SPLIT_STRUCTURE_FILE = SPLIT_DIR / "split_structure.txt"

OUTPUT_DIR = ROOT / "Protein_novel_gene_100pct"


# =============================================================================
# Fixed Protein GRID-best settings
# =============================================================================

SCRIPT_VERSION = "2026-09-08-protein-novelgene-100pct-windows-v1"
NONARG = "nonARG"


@dataclass
class Config:
    seed: int = 20260822

    # Scientific / logical batch sizes from Protein GRID-best.
    batch_size: int = 4096
    eval_batch_size: int = 8192

    # Physical CUDA micro-batches for a local 8-GB GPU.
    micro_batch_size: int = 128
    eval_micro_batch_size: int = 512

    teacher_epochs: int = 100
    student_epochs: int = 200

    teacher_patience: int = 15
    student_patience: int = 30

    teacher_lr: float = 2.0e-4
    student_lr: float = 1.0e-4
    weight_decay: float = 3.0e-5

    protein_hidden_1: int = 1536
    protein_hidden_2: int = 1024
    embedding_dim: int = 512

    dropout: float = 0.10

    logit_scale_binary: float = 16.0
    logit_scale_subtype: float = 22.0

    label_smoothing: float = 0.002

    class_weight_power: float = 0.0
    teacher_class_weight_power: float = 0.18

    temperature: float = 3.0

    teacher_binary_ce: float = 1.0
    teacher_subtype_ce: float = 1.0
    teacher_feature_anchor: float = 0.0
    teacher_refined_anchor: float = 0.10

    student_binary_ce: float = 1.0
    student_subtype_ce: float = 1.30
    student_binary_kd: float = 0.0
    student_subtype_kd: float = 0.05
    student_feature_align: float = 0.05
    student_prototype_align: float = 0.05
    student_head_anchor: float = 0.05

    gradient_clip: float = 1.0
    min_delta: float = 1.0e-5

    validation_fraction: float = 0.20

    # Keep the selected Protein GRID-best binary threshold unchanged.
    binary_threshold: float = 0.80


CFG = Config()


# =============================================================================
# General utilities
# =============================================================================

def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def require_cuda() -> torch.device:
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU was not detected. This script intentionally does not "
            "fall back to CPU. Check your PyTorch/CUDA installation."
        )

    device = torch.device("cuda:0")
    torch.cuda.set_device(device)

    print("=" * 100, flush=True)
    print("ARGScope Protein Novel-Gene 100% - Windows local", flush=True)
    print("=" * 100, flush=True)
    print(f"Script version : {SCRIPT_VERSION}", flush=True)
    print(f"PyTorch        : {torch.__version__}", flush=True)
    print(f"CUDA runtime   : {torch.version.cuda}", flush=True)
    print(f"GPU            : {torch.cuda.get_device_name(0)}", flush=True)
    props = torch.cuda.get_device_properties(0)
    print(f"GPU memory     : {props.total_memory / 1024**3:.2f} GB", flush=True)
    print(f"Device         : {device}", flush=True)
    print("=" * 100, flush=True)

    return device


def canonical_id(value: Any) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()
    compact = "".join(ch for ch in text.lower() if ch.isalnum())

    if compact in {
        "nonarg",
        "nonresistance",
        "negative",
        "nonresistant",
    }:
        return NONARG

    return text


def is_nonarg(value: Any) -> bool:
    return canonical_subtype(value) == NONARG


def load_pt(path: Path):
    try:
        return torch.load(
            path,
            map_location="cpu",
            weights_only=False,
        )
    except TypeError:
        return torch.load(
            path,
            map_location="cpu",
        )


def require_tensor_2d(value, name: str) -> torch.Tensor:
    if not isinstance(value, torch.Tensor) or value.ndim != 2:
        raise ValueError(f"{name} must be a 2D torch.Tensor.")

    value = value.detach().cpu().float().contiguous()

    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} contains NaN/Inf.")

    return value


def extract_embedding_pt(
    path: Path,
    description: str,
) -> Tuple[List[str], torch.Tensor, dict]:

    obj = load_pt(path)

    if not isinstance(obj, dict):
        raise TypeError(f"{description} PT must contain a dict: {path}")

    id_key = next(
        (
            key
            for key in (
                "ids",
                "sequence_ids",
                "fragment_ids",
            )
            if key in obj
        ),
        None,
    )

    emb_key = next(
        (
            key
            for key in (
                "embeddings",
                "mean_embeddings",
                "features",
                "fusion_embeddings",
            )
            if key in obj
        ),
        None,
    )

    if id_key is None or emb_key is None:
        raise KeyError(
            f"{description} PT must contain IDs and embeddings. "
            f"Found keys={sorted(obj.keys())}"
        )

    ids = [canonical_id(v) for v in obj[id_key]]
    embeddings = require_tensor_2d(
        obj[emb_key],
        f"{description} embeddings",
    )

    if len(ids) != embeddings.shape[0]:
        raise ValueError(
            f"{description} ID/embedding mismatch: "
            f"{len(ids)} vs {embeddings.shape[0]}"
        )

    if len(ids) != len(set(ids)):
        raise ValueError(f"{description} contains duplicate IDs.")

    return ids, embeddings, obj


def detect_delimiter(path: Path) -> str:
    with path.open("r", encoding="utf-8-sig") as handle:
        first = handle.readline()

    return "\t" if "\t" in first else ","


def read_id_file(path: Path) -> List[str]:
    ids: List[str] = []
    seen = set()

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, raw in enumerate(handle, start=1):
            seq_id = canonical_id(raw)
            if not seq_id:
                continue
            if seq_id in seen:
                raise ValueError(
                    f"Duplicate ID in {path} line {line_number}: {seq_id}"
                )
            seen.add(seq_id)
            ids.append(seq_id)

    if not ids:
        raise ValueError(f"ID file is empty: {path}")

    return ids


def find_column(fieldnames: Sequence[str], candidates: Sequence[str]) -> str:
    normalized = {
        str(name).strip().lower().replace("_", "").replace(".", ""): name
        for name in fieldnames
    }

    for candidate in candidates:
        key = (
            str(candidate)
            .strip()
            .lower()
            .replace("_", "")
            .replace(".", "")
        )
        if key in normalized:
            return normalized[key]

    raise KeyError(
        f"Could not find any of columns {list(candidates)}. "
        f"Found={list(fieldnames)}"
    )


def load_split_structure(path: Path) -> Dict[str, dict]:
    delimiter = detect_delimiter(path)

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle, delimiter=delimiter)

        if not reader.fieldnames:
            raise ValueError(f"Structure has no header: {path}")

        id_col = find_column(
            reader.fieldnames,
            ["SARG.Seq.ID", "Sequence_ID", "ID", "Seq_ID"],
        )
        type_col = find_column(
            reader.fieldnames,
            ["Type"],
        )
        subtype_col = find_column(
            reader.fieldnames,
            ["Subtype"],
        )

        # Split is strongly preferred. If absent, train/test ID files remain
        # authoritative and this field is simply not cross-checked.
        split_col = None
        try:
            split_col = find_column(reader.fieldnames, ["Split"])
        except KeyError:
            pass

        class_col = None
        try:
            class_col = find_column(
                reader.fieldnames,
                ["ARG.or.nonARG", "ARG_or_nonARG", "Label"],
            )
        except KeyError:
            pass

        records: Dict[str, dict] = {}

        for line_number, row in enumerate(reader, start=2):
            seq_id = canonical_id(row.get(id_col, ""))
            if not seq_id:
                continue

            if seq_id in records:
                raise ValueError(
                    f"Duplicate sequence ID in structure at line "
                    f"{line_number}: {seq_id}"
                )

            subtype = canonical_subtype(row.get(subtype_col, ""))
            type_name = str(row.get(type_col, "")).strip()

            if class_col is not None:
                class_text = str(row.get(class_col, "")).strip().lower()
                if "non" in class_text and "arg" in class_text:
                    subtype = NONARG

            if is_nonarg(subtype):
                type_name = NONARG

            if not subtype:
                raise ValueError(
                    f"Empty subtype at line {line_number}: {seq_id}"
                )

            if not type_name:
                raise ValueError(
                    f"Empty Type at line {line_number}: {seq_id}"
                )

            split = (
                str(row.get(split_col, "")).strip().lower()
                if split_col is not None
                else ""
            )

            records[seq_id] = {
                "subtype": subtype,
                "type": type_name,
                "declared_split": split,
            }

    if not records:
        raise ValueError(f"No records loaded from structure: {path}")

    return records


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        return

    fieldnames: List[str] = []
    seen = set()

    for row in rows:
        for key in row:
            if key not in seen:
                fieldnames.append(key)
                seen.add(key)

    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    os.replace(tmp, path)


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}

    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, np.integer):
        return int(value)

    if isinstance(value, np.floating):
        return float(value)

    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            return value.item()
        return value.detach().cpu().tolist()

    return value


def save_json(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(
            json_safe(obj),
            handle,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(tmp, path)


def safe_torch_save(obj, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)

    if not tmp.is_file() or tmp.stat().st_size <= 0:
        raise RuntimeError(f"Invalid temporary checkpoint: {tmp}")

    os.replace(tmp, path)


def check_input_files() -> None:
    required = [
        PROTEIN_PT,
        FUSION_PT,
        REFINED_PT,
        TRAIN_IDS_FILE,
        TEST_IDS_FILE,
        SPLIT_STRUCTURE_FILE,
    ]

    missing = [path for path in required if not path.is_file()]

    if missing:
        text = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(
            "Required input file(s) are missing:\n"
            f"{text}\n\n"
            "If your ARGScope_novel_gene_split folder is in another location, "
            "edit SPLIT_DIR near the top of this script."
        )


# =============================================================================
# Novel-gene split and data alignment
# =============================================================================

def build_validation_split(
    selected_ids: Sequence[str],
    records: Dict[str, dict],
    external_train_set: set,
    external_test_set: set,
    validation_fraction: float,
    seed: int,
) -> Tuple[List[str], List[str]]:

    if not (0.0 < float(validation_fraction) < 0.5):
        raise ValueError("validation_fraction must be between 0 and 0.5.")

    rng = random.Random(seed)

    model_split: List[str | None] = [None] * len(selected_ids)
    external_split: List[str | None] = [None] * len(selected_ids)

    arg_positions_by_subtype: Dict[str, List[int]] = defaultdict(list)
    nonarg_positions: List[int] = []

    for i, seq_id in enumerate(selected_ids):
        if seq_id in external_test_set:
            external_split[i] = "test"
            model_split[i] = "test"
            continue

        if seq_id not in external_train_set:
            raise RuntimeError(
                f"Selected ID belongs to neither external train nor test: {seq_id}"
            )

        external_split[i] = "train"
        subtype = records[seq_id]["subtype"]

        if is_nonarg(subtype):
            nonarg_positions.append(i)
        else:
            arg_positions_by_subtype[subtype].append(i)

    # Subtype-stratified validation only from external TRAIN.
    for subtype in sorted(arg_positions_by_subtype):
        positions = list(arg_positions_by_subtype[subtype])
        rng.shuffle(positions)
        n = len(positions)

        if n <= 1:
            n_val = 0
        else:
            n_val = int(round(n * validation_fraction))
            n_val = max(1, n_val)
            n_val = min(n - 1, n_val)

        val_set = set(positions[:n_val])

        for i in positions:
            model_split[i] = "validation" if i in val_set else "train"

    arg_val_count = sum(
        1
        for i, split in enumerate(model_split)
        if split == "validation"
        and not is_nonarg(records[selected_ids[i]]["subtype"])
    )

    shuffled_nonarg = list(nonarg_positions)
    rng.shuffle(shuffled_nonarg)

    if arg_val_count >= len(shuffled_nonarg):
        raise ValueError(
            "Not enough nonARG rows to create a 1:1 validation set."
        )

    nonarg_val = set(shuffled_nonarg[:arg_val_count])

    for i in shuffled_nonarg:
        model_split[i] = "validation" if i in nonarg_val else "train"

    if any(v is None for v in model_split):
        raise RuntimeError("Some selected rows were not assigned a model split.")

    return (
        [str(v) for v in model_split],
        [str(v) for v in external_split],
    )


def load_refined_train_prototypes(
    path: Path,
    train_arg_subtypes: set,
) -> Tuple[List[str], torch.Tensor, dict]:

    obj = load_pt(path)

    if not isinstance(obj, dict):
        raise TypeError("Refined prototype PT must contain a dict.")

    names_key = next(
        (
            k
            for k in (
                "arg_subtype_names",
                "ARG_subtype_names",
                "subtype_names",
            )
            if k in obj
        ),
        None,
    )

    proto_key = next(
        (
            k
            for k in (
                "refined_arg_subtype_prototypes",
                "refined_ARG_subtype_prototypes",
                "refined_prototypes",
                "prototypes",
            )
            if k in obj
        ),
        None,
    )

    if names_key is None or proto_key is None:
        raise KeyError(
            "Refined PT lacks subtype names or prototype tensor. "
            f"Found keys={sorted(obj.keys())}"
        )

    all_names = [canonical_subtype(v) for v in obj[names_key]]
    all_prototypes = require_tensor_2d(
        obj[proto_key],
        "refined ARG subtype prototypes",
    )

    if len(all_names) != all_prototypes.shape[0]:
        raise ValueError(
            "Refined subtype-name/prototype count mismatch."
        )

    if all_prototypes.shape[1] != CFG.embedding_dim:
        raise ValueError(
            f"Expected refined prototype dimension {CFG.embedding_dim}; "
            f"found {all_prototypes.shape[1]}"
        )

    if len(all_names) != len(set(all_names)):
        raise ValueError("Duplicate subtype names in refined prototype PT.")

    name_to_index = {
        name: i
        for i, name in enumerate(all_names)
    }

    missing = sorted(train_arg_subtypes - set(all_names))
    if missing:
        raise ValueError(
            f"{len(missing)} TRAIN ARG subtype(s) lack refined prototypes. "
            f"Examples={missing[:20]}"
        )

    # Preserve the source prototype order, but only retain TRAIN-known classes.
    selected_names = [
        name
        for name in all_names
        if name in train_arg_subtypes
    ]

    indices = torch.tensor(
        [name_to_index[name] for name in selected_names],
        dtype=torch.long,
    )

    selected = all_prototypes.index_select(0, indices).contiguous()
    selected = F.normalize(selected, p=2, dim=1)

    if set(selected_names) != train_arg_subtypes:
        raise RuntimeError("Internal train-prototype filtering error.")

    return selected_names, selected, obj


def load_and_align_data() -> dict:
    structure = load_split_structure(SPLIT_STRUCTURE_FILE)

    external_train_ids = read_id_file(TRAIN_IDS_FILE)
    external_test_ids = read_id_file(TEST_IDS_FILE)

    external_train_set = set(external_train_ids)
    external_test_set = set(external_test_ids)

    overlap = external_train_set & external_test_set
    if overlap:
        raise ValueError(
            f"External train/test ID overlap: {len(overlap)}. "
            f"Examples={sorted(overlap)[:10]}"
        )

    requested = external_train_set | external_test_set

    missing_structure = requested - set(structure)
    if missing_structure:
        raise ValueError(
            f"{len(missing_structure)} train/test IDs are absent from "
            f"split_structure.txt. Examples={sorted(missing_structure)[:20]}"
        )

    extra_structure = set(structure) - requested
    if extra_structure:
        raise ValueError(
            f"split_structure.txt contains {len(extra_structure)} IDs that are "
            f"not present in train_ids.txt or test_ids.txt. "
            f"Examples={sorted(extra_structure)[:20]}"
        )

    # Optional internal Split-column consistency check.
    for seq_id in external_train_set:
        declared = structure[seq_id]["declared_split"]
        if declared and declared not in {"train", "training"}:
            raise ValueError(
                f"Structure split disagrees with train_ids.txt: "
                f"{seq_id} -> {declared}"
            )

    for seq_id in external_test_set:
        declared = structure[seq_id]["declared_split"]
        if declared and declared not in {"test", "testing"}:
            raise ValueError(
                f"Structure split disagrees with test_ids.txt: "
                f"{seq_id} -> {declared}"
            )

    train_arg_subtypes = {
        structure[seq_id]["subtype"]
        for seq_id in external_train_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    test_arg_subtypes = {
        structure[seq_id]["subtype"]
        for seq_id in external_test_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    subtype_overlap = train_arg_subtypes & test_arg_subtypes

    if subtype_overlap:
        raise ValueError(
            "NOVEL-GENE VIOLATION: TRAIN and TEST ARG subtypes overlap. "
            f"n={len(subtype_overlap)}, examples={sorted(subtype_overlap)[:20]}"
        )

    train_arg_types = {
        structure[seq_id]["type"]
        for seq_id in external_train_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    test_arg_types = {
        structure[seq_id]["type"]
        for seq_id in external_test_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    missing_types = test_arg_types - train_arg_types

    if missing_types:
        raise ValueError(
            "NOVEL-GENE VIOLATION: TEST contains ARG Type(s) absent from TRAIN. "
            f"Types={sorted(missing_types)}"
        )

    # Load and align ESM-2 and fusion embeddings.
    protein_ids, protein, protein_obj = extract_embedding_pt(
        PROTEIN_PT,
        "ESM-2 protein",
    )

    fusion_ids, fusion, fusion_obj = extract_embedding_pt(
        FUSION_PT,
        "long fusion",
    )

    if protein.shape[1] != 1280:
        raise ValueError(
            f"Expected ESM-2 embedding dimension 1280; found {protein.shape[1]}"
        )

    if fusion.shape[1] != CFG.embedding_dim:
        raise ValueError(
            f"Expected fusion dimension {CFG.embedding_dim}; found {fusion.shape[1]}"
        )

    protein_index = {seq_id: i for i, seq_id in enumerate(protein_ids)}
    fusion_index = {seq_id: i for i, seq_id in enumerate(fusion_ids)}

    missing_protein = requested - set(protein_index)
    missing_fusion = requested - set(fusion_index)

    if missing_protein:
        raise ValueError(
            f"{len(missing_protein)} requested IDs are absent from Protein PT. "
            f"Examples={sorted(missing_protein)[:20]}"
        )

    if missing_fusion:
        raise ValueError(
            f"{len(missing_fusion)} requested IDs are absent from Fusion PT. "
            f"Examples={sorted(missing_fusion)[:20]}"
        )

    # Preserve structure-file insertion order for a stable, auditable dataset.
    selected_ids = [
        seq_id
        for seq_id in structure
        if seq_id in requested
    ]

    protein_idx = torch.tensor(
        [protein_index[seq_id] for seq_id in selected_ids],
        dtype=torch.long,
    )

    fusion_idx = torch.tensor(
        [fusion_index[seq_id] for seq_id in selected_ids],
        dtype=torch.long,
    )

    protein = protein.index_select(0, protein_idx).contiguous()
    fusion = fusion.index_select(0, fusion_idx).contiguous()

    model_splits, external_splits = build_validation_split(
        selected_ids=selected_ids,
        records=structure,
        external_train_set=external_train_set,
        external_test_set=external_test_set,
        validation_fraction=CFG.validation_fraction,
        seed=CFG.seed,
    )

    # The prediction head contains TRAIN ARG subtypes only.
    arg_names, refined, refined_obj = load_refined_train_prototypes(
        REFINED_PT,
        train_arg_subtypes,
    )

    arg_to_index = {
        name: i
        for i, name in enumerate(arg_names)
    }

    # Each TRAIN subtype must map to exactly one Type.
    subtype_to_type: Dict[str, str] = {}

    for seq_id in external_train_set:
        subtype = structure[seq_id]["subtype"]
        type_name = structure[seq_id]["type"]

        if is_nonarg(subtype):
            continue

        previous = subtype_to_type.get(subtype)

        if previous is not None and previous != type_name:
            raise ValueError(
                f"TRAIN subtype maps to multiple Types: "
                f"{subtype}: {previous} vs {type_name}"
            )

        subtype_to_type[subtype] = type_name

    if set(subtype_to_type) != set(arg_names):
        raise RuntimeError(
            "Internal mismatch between classifier subtype space and "
            "TRAIN subtype-to-Type map."
        )

    subtypes = [structure[seq_id]["subtype"] for seq_id in selected_ids]
    true_types = [structure[seq_id]["type"] for seq_id in selected_ids]

    binary_targets = torch.tensor(
        [0 if is_nonarg(v) else 1 for v in subtypes],
        dtype=torch.long,
    )

    # TEST ARG subtypes are deliberately unseen and receive target -1.
    arg_targets = torch.tensor(
        [
            -1
            if is_nonarg(subtype)
            else arg_to_index.get(subtype, -1)
            for subtype in subtypes
        ],
        dtype=torch.long,
    )

    split_indices = {
        split: torch.tensor(
            [
                i
                for i, value in enumerate(model_splits)
                if value == split
            ],
            dtype=torch.long,
        )
        for split in ("train", "validation", "test")
    }

    # Strong class-space checks.
    for split in ("train", "validation"):
        idx = split_indices[split]
        yb = binary_targets.index_select(0, idx)
        ya = arg_targets.index_select(0, idx)

        bad = (yb == 1) & (ya < 0)
        if bool(bad.any()):
            raise RuntimeError(
                f"{split} contains ARG rows outside TRAIN classifier space."
            )

    test_idx = split_indices["test"]
    test_yb = binary_targets.index_select(0, test_idx)
    test_ya = arg_targets.index_select(0, test_idx)

    # Every TEST ARG must be novel and therefore not have a classifier label.
    if bool(((test_yb == 1) & (test_ya >= 0)).any()):
        raise RuntimeError(
            "NOVEL-GENE VIOLATION: at least one TEST ARG subtype is present "
            "in the TRAIN classifier class space."
        )

    # Every TRAIN subtype must remain represented after validation carving.
    model_train_subtypes = {
        subtypes[i]
        for i in split_indices["train"].tolist()
        if not is_nonarg(subtypes[i])
    }

    missing_model_train = set(arg_names) - model_train_subtypes
    if missing_model_train:
        raise RuntimeError(
            f"{len(missing_model_train)} TRAIN subtype(s) were lost after "
            f"validation carving. Examples={sorted(missing_model_train)[:20]}"
        )

    # Build arrays convenient for reporting.
    type_names = sorted(train_arg_types, key=str.lower)

    print("\nNOVEL-GENE SPLIT CHECK", flush=True)
    print("-" * 100, flush=True)
    print(f"External TRAIN IDs        : {len(external_train_set):,}", flush=True)
    print(f"External TEST IDs         : {len(external_test_set):,}", flush=True)
    print(f"TRAIN ARG subtypes        : {len(train_arg_subtypes):,}", flush=True)
    print(f"TEST ARG subtypes         : {len(test_arg_subtypes):,}", flush=True)
    print(f"Subtype overlap           : {len(subtype_overlap):,}  [PASS]", flush=True)
    print(f"TRAIN ARG Types           : {len(train_arg_types):,}", flush=True)
    print(f"TEST ARG Types            : {len(test_arg_types):,}", flush=True)
    print(f"TEST Type outside TRAIN   : {len(missing_types):,}  [PASS]", flush=True)
    print(f"Classifier ARG classes    : {len(arg_names):,}  [TRAIN only]", flush=True)

    print("\nALIGNED DATA", flush=True)
    print("-" * 100, flush=True)
    print(f"Protein shape             : {tuple(protein.shape)}", flush=True)
    print(f"Fusion shape              : {tuple(fusion.shape)}", flush=True)
    print(f"Refined TRAIN prototypes  : {tuple(refined.shape)}", flush=True)

    for split, idx in split_indices.items():
        local_binary = binary_targets.index_select(0, idx)
        local_subtypes = {
            subtypes[i]
            for i in idx.tolist()
            if not is_nonarg(subtypes[i])
        }

        print(
            f"{split:10s} | n={idx.numel():,} | "
            f"ARG={int((local_binary == 1).sum()):,} | "
            f"nonARG={int((local_binary == 0).sum()):,} | "
            f"ARG_subtypes={len(local_subtypes):,}",
            flush=True,
        )

    return {
        "ids": selected_ids,
        "subtypes": subtypes,
        "true_types": true_types,
        "protein": protein,
        "fusion": fusion,
        "binary_targets": binary_targets,
        "arg_targets": arg_targets,
        "model_splits": model_splits,
        "external_splits": external_splits,
        "split_indices": split_indices,
        "arg_names": arg_names,
        "refined": refined,
        "subtype_to_type": subtype_to_type,
        "type_names": type_names,
        "train_arg_subtypes": sorted(train_arg_subtypes),
        "test_arg_subtypes": sorted(test_arg_subtypes),
        "train_arg_types": sorted(train_arg_types),
        "test_arg_types": sorted(test_arg_types),
        "source_protein": protein_obj,
        "source_fusion": fusion_obj,
        "source_refined": refined_obj,
    }


# =============================================================================
# Model
# =============================================================================

def mild_class_weights(
    targets: torch.Tensor,
    number_classes: int,
    power: float,
) -> torch.Tensor:

    counts = torch.bincount(
        targets,
        minlength=number_classes,
    ).float()

    if bool((counts == 0).any()):
        missing = torch.where(counts == 0)[0].tolist()
        raise ValueError(
            f"Missing model-train class(es): {missing[:20]}"
        )

    weights = (counts.mean() / counts).pow(power)
    weights = weights / weights.mean()

    return weights.clamp(0.70, 2.50)


class CosineHead(nn.Module):
    def __init__(
        self,
        number_classes: int,
        dimension: int,
        scale: float,
    ):
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(number_classes, dimension)
        )
        nn.init.xavier_uniform_(self.weight)

        self.scale = float(scale)

    def forward(self, features):
        return self.scale * F.linear(
            F.normalize(features, p=2, dim=1),
            F.normalize(self.weight, p=2, dim=1),
        )

    def normalized_weight(self):
        return F.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    def __init__(self, refined: torch.Tensor, config: Config):
        super().__init__()

        self.binary_head = CosineHead(
            2,
            config.embedding_dim,
            config.logit_scale_binary,
        )

        self.arg_head = CosineHead(
            refined.shape[0],
            config.embedding_dim,
            config.logit_scale_subtype,
        )

        with torch.no_grad():
            self.arg_head.weight.copy_(refined)

    def encode(self, fusion):
        return F.normalize(fusion, p=2, dim=1)

    def forward(self, fusion):
        z = self.encode(fusion)
        return (
            self.binary_head(z),
            self.arg_head(z),
            z,
        )


class ResidualBlock(nn.Module):
    def __init__(self, dimension: int, dropout: float):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
        )

    def forward(self, x):
        return F.gelu(x + self.net(x))


class ProteinStudent(nn.Module):
    def __init__(
        self,
        protein_dimension: int,
        protein_mean: torch.Tensor,
        protein_std: torch.Tensor,
        number_arg_subtypes: int,
        config: Config,
    ):
        super().__init__()

        self.register_buffer(
            "protein_mean",
            protein_mean.clone(),
        )
        self.register_buffer(
            "protein_std",
            protein_std.clone(),
        )

        self.input = nn.Sequential(
            nn.Linear(
                protein_dimension,
                config.protein_hidden_1,
            ),
            nn.LayerNorm(config.protein_hidden_1),
            nn.GELU(),
            nn.Dropout(config.dropout),

            nn.Linear(
                config.protein_hidden_1,
                config.protein_hidden_2,
            ),
            nn.LayerNorm(config.protein_hidden_2),
            nn.GELU(),
            nn.Dropout(config.dropout),
        )

        self.blocks = nn.Sequential(
            ResidualBlock(
                config.protein_hidden_2,
                config.dropout,
            ),
            ResidualBlock(
                config.protein_hidden_2,
                config.dropout,
            ),
        )

        self.output = nn.Sequential(
            nn.Linear(
                config.protein_hidden_2,
                config.embedding_dim,
            ),
            nn.LayerNorm(config.embedding_dim),
        )

        self.binary_head = CosineHead(
            2,
            config.embedding_dim,
            config.logit_scale_binary,
        )

        self.arg_head = CosineHead(
            number_arg_subtypes,
            config.embedding_dim,
            config.logit_scale_subtype,
        )

    def encode(self, protein):
        protein = (
            protein - self.protein_mean
        ) / self.protein_std

        hidden = self.input(protein)
        hidden = self.blocks(hidden)

        return F.normalize(
            self.output(hidden),
            p=2,
            dim=1,
        )

    def forward(self, protein):
        z = self.encode(protein)

        return (
            self.binary_head(z),
            self.arg_head(z),
            z,
        )


# =============================================================================
# Training helpers
# =============================================================================

def amp_context(enabled: bool):
    return torch.autocast(
        device_type="cuda",
        dtype=torch.float16,
        enabled=enabled,
    )


def make_grad_scaler(enabled: bool):
    try:
        return torch.amp.GradScaler(
            "cuda",
            enabled=enabled,
        )
    except Exception:
        return torch.cuda.amp.GradScaler(enabled=enabled)


def cosine_pull(
    features: torch.Tensor,
    targets: torch.Tensor,
) -> torch.Tensor:
    return (
        1.0
        - (
            F.normalize(features.float(), p=2, dim=1)
            * F.normalize(targets.float(), p=2, dim=1)
        ).sum(dim=1)
    ).mean()


def kd_loss(
    student: torch.Tensor,
    teacher: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    log_prob = F.log_softmax(
        student.float() / temperature,
        dim=1,
    )

    target_prob = F.softmax(
        teacher.float().detach() / temperature,
        dim=1,
    )

    return (
        F.kl_div(
            log_prob,
            target_prob,
            reduction="batchmean",
        )
        * temperature
        * temperature
    )


def initialize_binary_centers(
    model: nn.Module,
    fusion: torch.Tensor,
    binary_targets: torch.Tensor,
    train_indices: torch.Tensor,
) -> None:

    local_fusion = F.normalize(
        fusion.index_select(0, train_indices),
        p=2,
        dim=1,
    )

    local_binary = binary_targets.index_select(
        0,
        train_indices,
    )

    centers = []

    for label in (0, 1):
        selected = local_fusion[local_binary == label]

        if selected.shape[0] == 0:
            raise ValueError(
                f"Binary class {label} absent from model-train."
            )

        centers.append(
            F.normalize(
                selected.mean(dim=0),
                p=2,
                dim=0,
            )
        )

    with torch.no_grad():
        model.binary_head.weight.copy_(torch.stack(centers))


def shuffled_effective_groups(
    indices: torch.Tensor,
    effective_batch_size: int,
) -> Iterable[torch.Tensor]:
    order = indices[
        torch.randperm(indices.numel())
    ]

    for start in range(
        0,
        order.numel(),
        effective_batch_size,
    ):
        yield order[
            start : start + effective_batch_size
        ]


def micro_batches(
    group: torch.Tensor,
    micro_batch_size: int,
) -> Iterable[torch.Tensor]:
    for start in range(
        0,
        group.numel(),
        micro_batch_size,
    ):
        yield group[
            start : start + micro_batch_size
        ]


def train_mean_std(
    protein: torch.Tensor,
    train_indices: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:

    x = protein.index_select(0, train_indices)

    mean = x.mean(dim=0)
    std = x.std(dim=0, unbiased=False).clamp_min(1.0e-6)

    return mean, std


# =============================================================================
# Metrics
# =============================================================================

def safe_mcc(true, predicted) -> float:
    true = np.asarray(true)
    predicted = np.asarray(predicted)

    if (
        len(true) == 0
        or len(np.unique(true)) < 2
        or len(np.unique(predicted)) < 2
    ):
        return 0.0

    return float(
        matthews_corrcoef(true, predicted)
    )


def metric_dict(true, predicted) -> dict:
    true = np.asarray(true)
    predicted = np.asarray(predicted)

    if len(true) == 0:
        return {
            "n": 0,
            "accuracy": 0.0,
            "macro_precision": 0.0,
            "weighted_precision": 0.0,
            "micro_precision": 0.0,
            "macro_recall": 0.0,
            "weighted_recall": 0.0,
            "micro_recall": 0.0,
            "macro_f1": 0.0,
            "weighted_f1": 0.0,
            "micro_f1": 0.0,
            "mcc": 0.0,
        }

    return {
        "n": int(len(true)),
        "accuracy": float(
            accuracy_score(true, predicted)
        ),
        "macro_precision": float(
            precision_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_precision": float(
            precision_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_precision": float(
            precision_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "macro_recall": float(
            recall_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_recall": float(
            recall_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_recall": float(
            recall_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "macro_f1": float(
            f1_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_f1": float(
            f1_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "mcc": safe_mcc(true, predicted),
    }


@torch.inference_mode()
def collect_outputs(
    model: nn.Module,
    inputs: torch.Tensor,
    indices: torch.Tensor,
    device: torch.device,
    use_amp: bool,
) -> dict:

    model.eval()

    all_indices = []
    binary_logits = []
    arg_logits = []
    features = []

    for start in range(
        0,
        indices.numel(),
        CFG.eval_micro_batch_size,
    ):
        local_idx = indices[
            start : start + CFG.eval_micro_batch_size
        ]

        xb = inputs.index_select(
            0,
            local_idx,
        ).to(
            device,
            non_blocking=True,
        )

        with amp_context(use_amp):
            binary, subtype, z = model(xb)

        all_indices.append(local_idx.cpu())
        binary_logits.append(binary.float().cpu())
        arg_logits.append(subtype.float().cpu())
        features.append(z.float().cpu())

    return {
        "indices": torch.cat(all_indices),
        "binary_logits": torch.cat(binary_logits),
        "arg_logits": torch.cat(arg_logits),
        "features": torch.cat(features),
    }


def validation_metrics_from_outputs(
    outputs: dict,
    data: dict,
) -> Tuple[dict, dict]:

    idx = outputs["indices"]

    true_binary = (
        data["binary_targets"]
        .index_select(0, idx)
        .numpy()
    )

    true_arg = (
        data["arg_targets"]
        .index_select(0, idx)
        .numpy()
    )

    arg_prob = (
        torch.softmax(
            outputs["binary_logits"],
            dim=1,
        )[:, 1]
        .numpy()
    )

    pred_binary = (
        arg_prob >= CFG.binary_threshold
    ).astype(np.int64)

    pred_arg = (
        outputs["arg_logits"]
        .argmax(dim=1)
        .numpy()
    )

    arg_mask = true_binary == 1

    if bool((true_arg[arg_mask] < 0).any()):
        raise RuntimeError(
            "Validation contains ARG subtype outside TRAIN class space."
        )

    true_full = np.where(
        true_binary == 0,
        0,
        true_arg + 1,
    )

    pred_full = np.where(
        pred_binary == 0,
        0,
        pred_arg + 1,
    )

    metrics = {
        "binary": metric_dict(
            true_binary,
            pred_binary,
        ),
        "ARG_subtype_oracle_binary": metric_dict(
            true_arg[arg_mask],
            pred_arg[arg_mask],
        ),
        "end_to_end_subtype": metric_dict(
            true_full,
            pred_full,
        ),
    }

    arrays = {
        "true_binary": true_binary,
        "pred_binary": pred_binary,
        "true_arg": true_arg,
        "pred_arg": pred_arg,
        "ARG_probability": arg_prob,
    }

    return metrics, arrays


def validation_score(metrics: dict) -> float:
    full = metrics["end_to_end_subtype"]
    subtype = metrics["ARG_subtype_oracle_binary"]
    binary = metrics["binary"]

    # Same precision-priority score used by the final Protein pipeline.
    return (
        0.45 * float(subtype["weighted_precision"])
        + 0.25 * float(full["weighted_precision"])
        + 0.15 * float(full["accuracy"])
        + 0.10 * float(full["mcc"])
        + 0.05 * float(binary["weighted_precision"])
    )


def novel_test_metrics_from_outputs(
    outputs: dict,
    data: dict,
) -> Tuple[dict, List[dict]]:

    idx = outputs["indices"]
    idx_np = idx.numpy()

    true_binary = (
        data["binary_targets"]
        .index_select(0, idx)
        .numpy()
    )

    arg_prob = (
        torch.softmax(
            outputs["binary_logits"],
            dim=1,
        )[:, 1]
        .numpy()
    )

    pred_binary = (
        arg_prob >= CFG.binary_threshold
    ).astype(np.int64)

    pred_arg_idx = (
        outputs["arg_logits"]
        .argmax(dim=1)
        .numpy()
    )

    arg_softmax = torch.softmax(
        outputs["arg_logits"],
        dim=1,
    ).numpy()

    pred_known_subtype = [
        data["arg_names"][int(i)]
        for i in pred_arg_idx
    ]

    pred_known_type = [
        data["subtype_to_type"][subtype]
        for subtype in pred_known_subtype
    ]

    true_subtypes = [
        data["subtypes"][int(i)]
        for i in idx_np
    ]

    true_types = [
        NONARG
        if true_binary[j] == 0
        else data["true_types"][int(i)]
        for j, i in enumerate(idx_np)
    ]

    # Final Type prediction includes the binary gate.
    pred_types = [
        NONARG
        if pred_binary[j] == 0
        else pred_known_type[j]
        for j in range(len(pred_binary))
    ]

    # Diagnostic Type prediction ignores binary gate.
    oracle_pred_types = list(pred_known_type)

    arg_mask = true_binary == 1

    metrics = {
        "ARG_nonARG": metric_dict(
            true_binary,
            pred_binary,
        ),

        # Final behavior on all true ARGs. A binary false negative becomes
        # predicted Type "nonARG" and is counted as wrong.
        "Type_on_true_ARG": metric_dict(
            np.asarray(true_types, dtype=object)[arg_mask],
            np.asarray(pred_types, dtype=object)[arg_mask],
        ),

        # Diagnostic only: how well the known-subtype head transfers to
        # novel subtypes at the coarser Type level, ignoring binary gating.
        "Type_oracle_binary": metric_dict(
            np.asarray(true_types, dtype=object)[arg_mask],
            np.asarray(oracle_pred_types, dtype=object)[arg_mask],
        ),

        # End-to-end classification in the final label space:
        # nonARG + ARG Types.
        "End_to_end_Type": metric_dict(
            np.asarray(true_types, dtype=object),
            np.asarray(pred_types, dtype=object),
        ),
    }

    rows = []

    for j, global_i in enumerate(idx_np):
        seq_id = data["ids"][int(global_i)]
        true_subtype = data["subtypes"][int(global_i)]

        rows.append(
            {
                "sequence_id": seq_id,
                "split": "test",
                "true_ARG": int(true_binary[j]),
                "pred_ARG": int(pred_binary[j]),
                "ARG_probability": float(arg_prob[j]),
                "true_subtype": true_subtype,
                "predicted_known_subtype": pred_known_subtype[j],
                "predicted_known_subtype_probability": float(
                    arg_softmax[j, pred_arg_idx[j]]
                ),
                "true_type": true_types[j],
                "predicted_type": pred_types[j],
                "predicted_type_oracle_binary": oracle_pred_types[j],
                "type_correct": int(
                    str(true_types[j]) == str(pred_types[j])
                ),
                "novel_ARG_subtype": int(
                    true_binary[j] == 1
                    and true_subtype not in data["arg_names"]
                ),
            }
        )

    return metrics, rows


# =============================================================================
# Teacher training
# =============================================================================

def train_teacher(
    data: dict,
    device: torch.device,
    use_amp: bool,
) -> Tuple[FusionTeacher, dict, List[dict]]:

    refined_gpu = data["refined"].to(device)

    teacher = FusionTeacher(
        refined_gpu,
        CFG,
    ).to(device)

    train_idx = data["split_indices"]["train"]
    val_idx = data["split_indices"]["validation"]

    initialize_binary_centers(
        teacher,
        data["fusion"],
        data["binary_targets"],
        train_idx,
    )

    train_binary = data["binary_targets"].index_select(
        0,
        train_idx,
    )

    train_arg = data["arg_targets"].index_select(
        0,
        train_idx,
    )

    binary_weight = mild_class_weights(
        train_binary,
        2,
        CFG.teacher_class_weight_power,
    ).to(device)

    arg_only = train_arg[train_binary == 1]

    subtype_weight = mild_class_weights(
        arg_only,
        len(data["arg_names"]),
        CFG.teacher_class_weight_power,
    ).to(device)

    optimizer = torch.optim.AdamW(
        teacher.parameters(),
        lr=CFG.teacher_lr,
        weight_decay=CFG.weight_decay,
    )

    scaler = make_grad_scaler(use_amp)

    best_score = -float("inf")
    best_epoch = 0
    best_state = None
    patience_count = 0

    history: List[dict] = []

    print("\nTRAIN FUSION TEACHER", flush=True)
    print("-" * 100, flush=True)

    for epoch in range(1, CFG.teacher_epochs + 1):
        teacher.train()

        total_loss_sum = 0.0
        total_n = 0

        for group in shuffled_effective_groups(
            train_idx,
            CFG.batch_size,
        ):
            optimizer.zero_grad(set_to_none=True)

            group_n = int(group.numel())

            for local_idx in micro_batches(
                group,
                CFG.micro_batch_size,
            ):
                xb = data["fusion"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                yb = data["binary_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                ya = data["arg_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                with amp_context(use_amp):
                    binary_logits, arg_logits, z = teacher(xb)

                    loss_binary = F.cross_entropy(
                        binary_logits,
                        yb,
                        weight=binary_weight,
                        label_smoothing=CFG.label_smoothing,
                    )

                    arg_mask = yb == 1

                    loss_subtype = F.cross_entropy(
                        arg_logits[arg_mask],
                        ya[arg_mask],
                        weight=subtype_weight,
                        label_smoothing=CFG.label_smoothing,
                    )

                    loss_refined_anchor = (
                        1.0
                        - (
                            teacher.arg_head.normalized_weight()
                            * refined_gpu
                        ).sum(dim=1)
                    ).mean()

                    loss = (
                        CFG.teacher_binary_ce * loss_binary
                        + CFG.teacher_subtype_ce * loss_subtype
                        + CFG.teacher_refined_anchor * loss_refined_anchor
                    )

                # Exact mean weighting over the logical effective batch.
                scale = float(local_idx.numel()) / float(group_n)
                scaler.scale(loss * scale).backward()

                total_loss_sum += float(loss.detach().cpu()) * local_idx.numel()
                total_n += int(local_idx.numel())

            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                teacher.parameters(),
                CFG.gradient_clip,
            )
            scaler.step(optimizer)
            scaler.update()

        val_outputs = collect_outputs(
            teacher,
            data["fusion"],
            val_idx,
            device,
            use_amp,
        )

        val_metrics, _ = validation_metrics_from_outputs(
            val_outputs,
            data,
        )

        score = validation_score(val_metrics)

        row = {
            "stage": "Teacher",
            "epoch": epoch,
            "training_loss": total_loss_sum / max(total_n, 1),
            "validation_score": score,
            "val_binary_accuracy": val_metrics["binary"]["accuracy"],
            "val_binary_weighted_precision": val_metrics["binary"]["weighted_precision"],
            "val_subtype_accuracy": val_metrics["ARG_subtype_oracle_binary"]["accuracy"],
            "val_subtype_weighted_precision": val_metrics["ARG_subtype_oracle_binary"]["weighted_precision"],
            "val_end_accuracy": val_metrics["end_to_end_subtype"]["accuracy"],
            "val_end_weighted_precision": val_metrics["end_to_end_subtype"]["weighted_precision"],
            "val_end_mcc": val_metrics["end_to_end_subtype"]["mcc"],
        }
        history.append(row)

        improved = score > best_score + CFG.min_delta

        if improved:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(
                {
                    key: value.detach().cpu()
                    for key, value in teacher.state_dict().items()
                }
            )
            patience_count = 0
        else:
            patience_count += 1

        print(
            f"Teacher {epoch:03d}/{CFG.teacher_epochs} | "
            f"loss={row['training_loss']:.6f} | "
            f"val_score={score:.6f} | "
            f"val_end_ACC={row['val_end_accuracy']:.6f} | "
            f"val_subtype_WP={row['val_subtype_weighted_precision']:.6f} | "
            f"best={best_score:.6f}@{best_epoch}",
            flush=True,
        )

        if patience_count >= CFG.teacher_patience:
            print(
                f"Teacher early stopping at epoch {epoch}; "
                f"best epoch={best_epoch}.",
                flush=True,
            )
            break

    if best_state is None:
        raise RuntimeError("Teacher training did not produce a best state.")

    teacher.load_state_dict(best_state, strict=True)
    teacher.eval()

    result = {
        "best_epoch": best_epoch,
        "best_validation_score": best_score,
        "state_dict": best_state,
    }

    return teacher, result, history


# =============================================================================
# Student training
# =============================================================================

def train_student(
    data: dict,
    teacher: FusionTeacher,
    device: torch.device,
    use_amp: bool,
) -> Tuple[ProteinStudent, dict, List[dict]]:

    train_idx = data["split_indices"]["train"]
    val_idx = data["split_indices"]["validation"]

    protein_mean, protein_std = train_mean_std(
        data["protein"],
        train_idx,
    )

    student = ProteinStudent(
        protein_dimension=data["protein"].shape[1],
        protein_mean=protein_mean,
        protein_std=protein_std,
        number_arg_subtypes=len(data["arg_names"]),
        config=CFG,
    ).to(device)

    refined_gpu = data["refined"].to(device)

    # Initialize subtype classifier from TRAIN-only refined prototypes.
    with torch.no_grad():
        student.arg_head.weight.copy_(refined_gpu)

    # Binary centers live in the same 512D Teacher/fusion space.
    initialize_binary_centers(
        student,
        data["fusion"],
        data["binary_targets"],
        train_idx,
    )

    train_binary = data["binary_targets"].index_select(
        0,
        train_idx,
    )

    train_arg = data["arg_targets"].index_select(
        0,
        train_idx,
    )

    binary_weight = mild_class_weights(
        train_binary,
        2,
        CFG.class_weight_power,
    ).to(device)

    arg_only = train_arg[train_binary == 1]

    subtype_weight = mild_class_weights(
        arg_only,
        len(data["arg_names"]),
        CFG.class_weight_power,
    ).to(device)

    optimizer = torch.optim.AdamW(
        student.parameters(),
        lr=CFG.student_lr,
        weight_decay=CFG.weight_decay,
    )

    scaler = make_grad_scaler(use_amp)

    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)

    best_score = -float("inf")
    best_epoch = 0
    best_state = None
    patience_count = 0

    history: List[dict] = []

    print("\nTRAIN PROTEIN STUDENT", flush=True)
    print("-" * 100, flush=True)

    for epoch in range(1, CFG.student_epochs + 1):
        student.train()

        total_loss_sum = 0.0
        total_n = 0

        for group in shuffled_effective_groups(
            train_idx,
            CFG.batch_size,
        ):
            optimizer.zero_grad(set_to_none=True)

            group_n = int(group.numel())

            for local_idx in micro_batches(
                group,
                CFG.micro_batch_size,
            ):
                xp = data["protein"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                xf = data["fusion"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                yb = data["binary_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                ya = data["arg_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                with torch.no_grad():
                    with amp_context(use_amp):
                        teacher_binary, teacher_arg, teacher_z = teacher(xf)

                with amp_context(use_amp):
                    binary_logits, arg_logits, z = student(xp)

                    loss_binary_ce = F.cross_entropy(
                        binary_logits,
                        yb,
                        weight=binary_weight,
                        label_smoothing=CFG.label_smoothing,
                    )

                    arg_mask = yb == 1

                    loss_subtype_ce = F.cross_entropy(
                        arg_logits[arg_mask],
                        ya[arg_mask],
                        weight=subtype_weight,
                        label_smoothing=CFG.label_smoothing,
                    )

                    if CFG.student_binary_kd > 0:
                        loss_binary_kd = kd_loss(
                            binary_logits,
                            teacher_binary,
                            CFG.temperature,
                        )
                    else:
                        loss_binary_kd = binary_logits.sum() * 0.0

                    loss_subtype_kd = kd_loss(
                        arg_logits[arg_mask],
                        teacher_arg[arg_mask],
                        CFG.temperature,
                    )

                    loss_feature_align = cosine_pull(
                        z,
                        teacher_z,
                    )

                    target_proto = refined_gpu.index_select(
                        0,
                        ya[arg_mask],
                    )

                    loss_prototype_align = cosine_pull(
                        z[arg_mask],
                        target_proto,
                    )

                    loss_head_anchor = (
                        1.0
                        - (
                            student.arg_head.normalized_weight()
                            * refined_gpu
                        ).sum(dim=1)
                    ).mean()

                    loss = (
                        CFG.student_binary_ce * loss_binary_ce
                        + CFG.student_subtype_ce * loss_subtype_ce
                        + CFG.student_binary_kd * loss_binary_kd
                        + CFG.student_subtype_kd * loss_subtype_kd
                        + CFG.student_feature_align * loss_feature_align
                        + CFG.student_prototype_align * loss_prototype_align
                        + CFG.student_head_anchor * loss_head_anchor
                    )

                scale = float(local_idx.numel()) / float(group_n)
                scaler.scale(loss * scale).backward()

                total_loss_sum += float(loss.detach().cpu()) * local_idx.numel()
                total_n += int(local_idx.numel())

            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                student.parameters(),
                CFG.gradient_clip,
            )
            scaler.step(optimizer)
            scaler.update()

        val_outputs = collect_outputs(
            student,
            data["protein"],
            val_idx,
            device,
            use_amp,
        )

        val_metrics, _ = validation_metrics_from_outputs(
            val_outputs,
            data,
        )

        score = validation_score(val_metrics)

        row = {
            "stage": "Student",
            "epoch": epoch,
            "training_loss": total_loss_sum / max(total_n, 1),
            "validation_score": score,
            "val_binary_accuracy": val_metrics["binary"]["accuracy"],
            "val_binary_weighted_precision": val_metrics["binary"]["weighted_precision"],
            "val_subtype_accuracy": val_metrics["ARG_subtype_oracle_binary"]["accuracy"],
            "val_subtype_weighted_precision": val_metrics["ARG_subtype_oracle_binary"]["weighted_precision"],
            "val_end_accuracy": val_metrics["end_to_end_subtype"]["accuracy"],
            "val_end_weighted_precision": val_metrics["end_to_end_subtype"]["weighted_precision"],
            "val_end_mcc": val_metrics["end_to_end_subtype"]["mcc"],
        }
        history.append(row)

        improved = score > best_score + CFG.min_delta

        if improved:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(
                {
                    key: value.detach().cpu()
                    for key, value in student.state_dict().items()
                }
            )
            patience_count = 0
        else:
            patience_count += 1

        print(
            f"Student {epoch:03d}/{CFG.student_epochs} | "
            f"loss={row['training_loss']:.6f} | "
            f"val_score={score:.6f} | "
            f"val_end_ACC={row['val_end_accuracy']:.6f} | "
            f"val_subtype_WP={row['val_subtype_weighted_precision']:.6f} | "
            f"best={best_score:.6f}@{best_epoch}",
            flush=True,
        )

        if patience_count >= CFG.student_patience:
            print(
                f"Student early stopping at epoch {epoch}; "
                f"best epoch={best_epoch}.",
                flush=True,
            )
            break

    if best_state is None:
        raise RuntimeError("Student training did not produce a best state.")

    student.load_state_dict(best_state, strict=True)
    student.eval()

    result = {
        "best_epoch": best_epoch,
        "best_validation_score": best_score,
        "state_dict": best_state,
        "protein_mean": protein_mean,
        "protein_std": protein_std,
    }

    return student, result, history


# =============================================================================
# Reporting
# =============================================================================

def flatten_metric_rows(metrics: dict) -> List[dict]:
    rows = []

    for task, values in metrics.items():
        row = {"task": task}
        row.update(values)
        rows.append(row)

    return rows


def report_metrics(title: str, metrics: dict) -> None:
    print(f"\n{title}", flush=True)
    print("-" * 100, flush=True)

    for task, values in metrics.items():
        print(
            f"{task:22s} | "
            f"n={values['n']:,} | "
            f"ACC={values['accuracy']:.6f} | "
            f"weighted_P={values['weighted_precision']:.6f} | "
            f"macro_P={values['macro_precision']:.6f} | "
            f"weighted_F1={values['weighted_f1']:.6f} | "
            f"macro_F1={values['macro_f1']:.6f} | "
            f"MCC={values['mcc']:.6f}",
            flush=True,
        )


def save_split_audit(data: dict) -> None:
    rows = []

    for i, seq_id in enumerate(data["ids"]):
        rows.append(
            {
                "sequence_id": seq_id,
                "external_split": data["external_splits"][i],
                "model_split": data["model_splits"][i],
                "ARG_or_nonARG": (
                    "nonARG"
                    if is_nonarg(data["subtypes"][i])
                    else "ARG"
                ),
                "Subtype": data["subtypes"][i],
                "Type": data["true_types"][i],
                "in_classifier_class_space": int(
                    data["subtypes"][i] in data["arg_names"]
                ),
            }
        )

    write_csv(
        OUTPUT_DIR / "model_split_audit.csv",
        rows,
    )


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    started = time.time()

    check_input_files()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    device = require_cuda()
    seed_everything(CFG.seed)

    use_amp = True

    print("\nINPUT FILES", flush=True)
    print("-" * 100, flush=True)
    print(f"ROOT          : {ROOT}", flush=True)
    print(f"Protein PT    : {PROTEIN_PT}", flush=True)
    print(f"Fusion PT     : {FUSION_PT}", flush=True)
    print(f"Refined PT    : {REFINED_PT}", flush=True)
    print(f"Train IDs     : {TRAIN_IDS_FILE}", flush=True)
    print(f"Test IDs      : {TEST_IDS_FILE}", flush=True)
    print(f"Structure     : {SPLIT_STRUCTURE_FILE}", flush=True)
    print(f"Output        : {OUTPUT_DIR}", flush=True)

    print("\nFIXED PROTEIN GRID-BEST PARAMETERS", flush=True)
    print("-" * 100, flush=True)
    for key, value in asdict(CFG).items():
        print(f"{key:28s}: {value}", flush=True)

    data = load_and_align_data()
    save_split_audit(data)

    # ---------------------------------------------------------------------
    # Critical upstream provenance warning.
    # ---------------------------------------------------------------------
    print(
        "\n[PROVENANCE NOTE] This run excludes TEST-only ARG subtypes from the "
        "Teacher/Student classifier class space and from all current optimization. "
        "However, Long_fusion.pt and the residual-GAT prototype file are precomputed "
        "upstream artifacts. For a manuscript claim of a fully end-to-end "
        "leakage-free Novel-Gene experiment, regenerate those upstream artifacts "
        "using this same external TRAIN/TEST split.",
        flush=True,
    )

    teacher, teacher_result, teacher_history = train_teacher(
        data,
        device,
        use_amp,
    )

    student, student_result, student_history = train_student(
        data,
        teacher,
        device,
        use_amp,
    )

    # ---------------------------------------------------------------------
    # Final validation reporting with the selected Student.
    # No TEST has been evaluated before this point.
    # ---------------------------------------------------------------------
    val_outputs = collect_outputs(
        student,
        data["protein"],
        data["split_indices"]["validation"],
        device,
        use_amp,
    )

    val_metrics, _ = validation_metrics_from_outputs(
        val_outputs,
        data,
    )

    save_json(
        OUTPUT_DIR / "validation_metrics.json",
        val_metrics,
    )

    # ---------------------------------------------------------------------
    # FINAL TEST - once, after all model selection is complete.
    # ---------------------------------------------------------------------
    print("\nFINAL TEST EVALUATION START", flush=True)

    test_outputs = collect_outputs(
        student,
        data["protein"],
        data["split_indices"]["test"],
        device,
        use_amp,
    )

    test_metrics, test_prediction_rows = novel_test_metrics_from_outputs(
        test_outputs,
        data,
    )

    report_metrics(
        "FINAL NOVEL-GENE TEST RESULTS",
        test_metrics,
    )

    write_csv(
        OUTPUT_DIR / "test_metrics.csv",
        flatten_metric_rows(test_metrics),
    )

    write_csv(
        OUTPUT_DIR / "test_sequence_predictions.csv",
        test_prediction_rows,
    )

    # Combined training history.
    write_csv(
        OUTPUT_DIR / "training_history.csv",
        teacher_history + student_history,
    )

    checkpoint = {
        "model_name": "ARGScope Protein Student - 100% Novel-Gene",
        "script_version": SCRIPT_VERSION,
        "configuration": asdict(CFG),
        "student_state_dict": {
            key: value.detach().cpu()
            for key, value in student.state_dict().items()
        },
        "teacher_state_dict": {
            key: value.detach().cpu()
            for key, value in teacher.state_dict().items()
        },
        "protein_input_dimension": 1280,
        "embedding_dimension": CFG.embedding_dim,
        "arg_subtype_names": data["arg_names"],
        "classifier_class_space_definition": (
            "TRAIN ARG subtypes only; TEST ARG subtypes are unseen"
        ),
        "subtype_to_type": data["subtype_to_type"],
        "type_names": data["type_names"],
        "selected_binary_ARG_probability_threshold": CFG.binary_threshold,
        "protein_train_mean": student_result["protein_mean"],
        "protein_train_std": student_result["protein_std"],
        "train_only_refined_ARG_subtype_prototypes": data["refined"],
        "teacher_best_epoch": teacher_result["best_epoch"],
        "teacher_best_validation_score": teacher_result[
            "best_validation_score"
        ],
        "student_best_epoch": student_result["best_epoch"],
        "student_best_validation_score": student_result[
            "best_validation_score"
        ],
        "novel_gene_split": {
            "external_train_n": len(
                set(
                    data["ids"][i]
                    for i, x in enumerate(data["external_splits"])
                    if x == "train"
                )
            ),
            "external_test_n": len(
                set(
                    data["ids"][i]
                    for i, x in enumerate(data["external_splits"])
                    if x == "test"
                )
            ),
            "train_ARG_subtypes": data["train_arg_subtypes"],
            "test_ARG_subtypes": data["test_arg_subtypes"],
            "train_ARG_types": data["train_arg_types"],
            "test_ARG_types": data["test_arg_types"],
            "ARG_subtype_overlap_count": len(
                set(data["train_arg_subtypes"])
                & set(data["test_arg_subtypes"])
            ),
        },
        "test_metrics": test_metrics,
        "source_files": {
            "protein_pt": str(PROTEIN_PT),
            "fusion_pt": str(FUSION_PT),
            "refined_pt": str(REFINED_PT),
            "train_ids": str(TRAIN_IDS_FILE),
            "test_ids": str(TEST_IDS_FILE),
            "split_structure": str(SPLIT_STRUCTURE_FILE),
        },
    }

    safe_torch_save(
        checkpoint,
        OUTPUT_DIR / "protein_novelgene_100pct_best_model.pt",
    )

    run_summary = {
        "script_version": SCRIPT_VERSION,
        "configuration": asdict(CFG),
        "teacher_best_epoch": teacher_result["best_epoch"],
        "teacher_best_validation_score": teacher_result[
            "best_validation_score"
        ],
        "student_best_epoch": student_result["best_epoch"],
        "student_best_validation_score": student_result[
            "best_validation_score"
        ],
        "binary_threshold": CFG.binary_threshold,
        "classifier_ARG_subtypes": len(data["arg_names"]),
        "train_ARG_subtypes": len(data["train_arg_subtypes"]),
        "test_novel_ARG_subtypes": len(data["test_arg_subtypes"]),
        "train_test_ARG_subtype_overlap": len(
            set(data["train_arg_subtypes"])
            & set(data["test_arg_subtypes"])
        ),
        "train_ARG_types": len(data["train_arg_types"]),
        "test_ARG_types": len(data["test_arg_types"]),
        "test_metrics": test_metrics,
        "elapsed_seconds": time.time() - started,
    }

    save_json(
        OUTPUT_DIR / "run_summary.json",
        run_summary,
    )

    print("\nOUTPUT FILES", flush=True)
    print("-" * 100, flush=True)
    for name in (
        "protein_novelgene_100pct_best_model.pt",
        "training_history.csv",
        "validation_metrics.json",
        "test_metrics.csv",
        "test_sequence_predictions.csv",
        "model_split_audit.csv",
        "run_summary.json",
    ):
        path = OUTPUT_DIR / name
        print(
            f"{name:42s} | "
            f"{path.stat().st_size / 1024**2:.2f} MB",
            flush=True,
        )

    print(
        f"\nCompleted in {(time.time() - started) / 60:.2f} min.",
        flush=True,
    )


if __name__ == "__main__":
    main()
