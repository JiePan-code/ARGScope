#!/usr/bin/env python3
"""Read-only source audit and reproducible analysis of saved fragment predictions.

Outputs are confined to this script's data/ directory. Five fragments from one
parent are not independent training runs. No baseline-cohort equivalence assumed.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
APP = HERE.parent
RESULTS = APP.parent
DATASET = RESULTS.parent
OLD = APP / 'reference_style_small_panels_23types/data'
OUT = HERE / 'data'
PCTS = [60, 70, 80, 90]
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']
SOURCES = {}


def read(path, **kw):
    path = Path(path)
    SOURCES[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return pd.read_csv(path, **kw)


def export(df, name):
    df.to_csv(OUT / name, index=False, encoding='utf-8-sig', float_format='%.12g')


def scores(y, p):
    out = []
    for average in ['macro', 'weighted', 'micro']:
        precision, recall, f1, _ = precision_recall_fscore_support(y, p, average=average, zero_division=0)
        out.append(dict(Average=average, Accuracy=accuracy_score(y, p), Precision=precision,
                        Recall=recall, F1=f1, MCC=matthews_corrcoef(y, p)))
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    mapping = read(OLD / 'type_display_mapping.csv')
    order = mapping.Type.tolist()
    export(mapping, 'type_display_mapping.csv')
    structure = read(DATASET / 'all_ARG_nonARG_1to1_structure.txt', sep='\t')
    assert structure['SARG.Seq.ID'].is_unique
    structure = structure.set_index('SARG.Seq.ID')
    all_scores, types, audits, parents, errors, robustness = [], [], [], [], [], []
    fulls = {}
    train_support = {}
    reference_ids = None
    frames = {}
    rng = np.random.default_rng(20260919)
    for modality in ['protein', 'dna']:
        full = read(APP / modality / '100%_test_sequence_predictions.csv').set_index('parent_sequence_id')
        assert full.index.is_unique and len(full) == 4574
        fulls[modality] = full
        if reference_ids is None:
            reference_ids = set(full.index)
        assert set(full.index) == reference_ids
        train = read(RESULTS / 'full' / modality / 'train_sequence_predictions.csv')
        assert train.sequence_id.is_unique
        assert not set(train.sequence_id) & reference_ids
        support = train[train.true_ARG.eq(1)].groupby('true_subtype').size()
        train_support[modality] = support
        for pct in [100] + PCTS:
            path = APP / modality / ('100%_test_sequence_predictions.csv' if pct == 100 else f'{pct}%_fragment_predictions_test.csv')
            df = read(path)
            assert df.sequence_id.is_unique and df.notna().all().all()
            assert set(df.parent_sequence_id) == reference_ids
            assert df.completeness_percent.eq(pct).all()
            assert df.groupby('parent_sequence_id').size().eq(1 if pct == 100 else 5).all()
            if pct != 100:
                assert df.groupby('parent_sequence_id').replicate.apply(lambda v: set(v) == {1, 2, 3, 4, 5}).all()
            for col in ['true_type', 'true_subtype', 'true_ARG']:
                assert np.array_equal(df[col].to_numpy(), full.loc[df.parent_sequence_id, col].to_numpy())
            assert set(df[df.true_ARG.eq(1)].true_type) == set(order)
            assert ((df.predicted_ARG == 0) == df.predicted_type.eq('nonARG')).all()
            assert ((df.predicted_ARG == 0) == df.predicted_subtype.eq('nonARG')).all()
            frames[modality, pct] = df
            audits.append(dict(Modality=modality, Completeness=pct, N_fragments=len(df),
                               N_parents=df.parent_sequence_id.nunique(), N_ARG_parents=int(full.true_ARG.sum()),
                               N_types=df[df.true_ARG.eq(1)].true_type.nunique(),
                               N_subtypes=df[df.true_ARG.eq(1)].true_subtype.nunique(),
                               Train_test_ID_overlap=0, Repeats_per_parent=1 if pct == 100 else 5))
            for level, truth, pred in [('Type', 'true_type', 'predicted_type'), ('Subtype', 'true_subtype', 'predicted_subtype')]:
                for row in scores(df[truth], df[pred]):
                    all_scores.append(dict(Modality=modality, Completeness=pct, Level=level,
                                           Population='all_test_including_nonARG', **row))
            y, p = df.true_ARG, df.predicted_ARG
            precision, recall, f1, _ = precision_recall_fscore_support(y, p, average='binary', pos_label=1, zero_division=0)
            all_scores.append(dict(Modality=modality, Completeness=pct, Level='ARG/nonARG',
                                   Population='all_test_ARG_positive', Average='binary',
                                   Accuracy=accuracy_score(y,p), Precision=precision, Recall=recall,
                                   F1=f1, MCC=matthews_corrcoef(y,p)))
            for typ in order:
                y, p = df.true_type.eq(typ), df.predicted_type.eq(typ)
                tp, fp, fn, tn = (int((y&p).sum()), int((~y&p).sum()), int((y&~p).sum()), int((~y&~p).sum()))
                prec, rec, f1, _ = precision_recall_fscore_support(y,p,average='binary',zero_division=0)
                types.append(dict(Modality=modality, Completeness=pct, Type=typ, TP=tp, FP=fp, FN=fn, TN=tn,
                                  Support=tp+fn, Parent_support=int(full.true_type.eq(typ).sum()),
                                  Predicted_positive=tp+fp, Accuracy=(tp+tn)/len(df), Precision=prec,
                                  Recall=rec, F1=f1, MCC=matthews_corrcoef(y,p), Precision_defined=bool(tp+fp)))
            if pct == 100:
                continue
            arg = df[df.true_ARG.eq(1)].copy()
            arg['Correct_subtype'] = arg.true_subtype.eq(arg.predicted_subtype)
            arg['Correct_type'] = arg.true_type.eq(arg.predicted_type)
            arg['Detected_ARG'] = arg.predicted_ARG.eq(1)
            per_parent = arg.groupby('parent_sequence_id').agg(
                True_type=('true_type', 'first'), True_subtype=('true_subtype', 'first'),
                Subtype_fraction=('Correct_subtype', 'mean'), Type_fraction=('Correct_type', 'mean'),
                ARG_fraction=('Detected_ARG', 'mean'))
            per_parent['Modality'] = modality
            per_parent['Completeness'] = pct
            parents.append(per_parent.reset_index())
            for level in ['Type', 'Subtype', 'ARG']:
                values = per_parent[f'{level}_fraction'].to_numpy()
                stable = (values == 1).astype(float)
                boot = stable[rng.integers(0, len(values), size=(2000, len(values)))].mean(axis=1)
                robustness.append(dict(Modality=modality, Completeness=pct, Level=level,
                                       Mean_fragment_correct=float(values.mean()), All_five_correct=float(stable.mean()),
                                       CI_low=float(np.quantile(boot, .025)), CI_high=float(np.quantile(boot, .975)),
                                       N_ARG_parents=len(values), Bootstrap_unit='parent_sequence', Bootstrap_repeats=2000))
            counts = {
                'Correct subtype': int(arg.Correct_subtype.sum()),
                'Wrong subtype, correct Type': int((~arg.Correct_subtype & arg.Correct_type).sum()),
                'Wrong Type': int((~arg.Correct_type & arg.predicted_ARG.eq(1)).sum()),
                'Missed ARG': int(arg.predicted_ARG.eq(0).sum()),
            }
            assert sum(counts.values()) == len(arg)
            for category, count in counts.items():
                errors.append(dict(Modality=modality, Completeness=pct, Category=category,
                                   Count=count, Fraction=count/len(arg), N_ARG_fragments=len(arg)))
    for pct in [100] + PCTS:
        a, b = frames['protein',pct].set_index('sequence_id'), frames['dna',pct].set_index('sequence_id')
        assert set(a.index) == set(b.index)
        assert a[['parent_sequence_id','replicate','true_type','true_subtype','true_ARG']].equals(
            b.loc[a.index, ['parent_sequence_id','replicate','true_type','true_subtype','true_ARG']])
    export(pd.DataFrame(audits), 'cohort_audit.csv')
    overall = pd.DataFrame(all_scores)
    export(overall, 'ARGScope_all_five_metrics.csv')
    type_df = pd.DataFrame(types)
    export(type_df, 'ARGScope_per_type_five_metrics.csv')
    export(pd.DataFrame(errors), 'error_decomposition.csv')
    export(pd.DataFrame(robustness), 'five_fragment_stability.csv')
    parent_df = pd.concat(parents, ignore_index=True)
    export(parent_df, 'ARG_parent_fragment_accuracy.csv')

    # Independent-source reported comparisons, never used for paired tests/ranking.
    reported, raw_type, freshness = [], [], []
    for mod in ['protein','dna']:
        for pct in PCTS:
            values = read(OLD / mod / f'{pct}pct/A_overall_values_and_sources.csv')
            for idx, row in values[values.Model.ne('ARGScope')].iterrows():
                source = read(row.source)
                pick = source[source.iloc[:,0].astype(str).str.strip().eq(f'{pct}%')]
                assert len(pick) == 1
                for metric in METRICS:
                    col='ACC' if metric=='Accuracy' and 'ACC' in pick else metric
                    value=float(pick.iloc[0][col])
                    freshness.append(dict(Modality=mod,Completeness=pct,Model=row.Model,Level='Overall',
                                          Metric=metric,Snapshot_matches_current=bool(np.isclose(float(row[metric]),value))))
                    values.loc[idx,metric]=value
            own = overall[(overall.Modality==mod)&(overall.Completeness==pct)&(overall.Level=='Type')&(overall.Average=='weighted')].iloc[0]
            for metric in METRICS:
                values.loc[values.Model.eq('ARGScope'), metric] = own[metric]
            values['Comparability'] = 'reported_summaries_NOT_matched_cohort_or_aggregation'
            reported.append(values)
            for metric in ['Precision', 'Recall', 'F1']:
                table = read(OLD / mod / f'{pct}pct/B_{metric}_source_values.csv').set_index('Type')
                source_map=read(OLD / mod / f'{pct}pct/B_sources.csv')
                for row in source_map[source_map.Model.ne('ARGScope')].itertuples():
                    source=read(row.source)
                    cols={c.lower():c for c in source.columns}
                    source['canonical_Type']=source[cols['type']].replace({'MLS':'macrolide-lincosamide-streptogramin'})
                    source=source[source.canonical_Type.isin(order)].set_index('canonical_Type')
                    assert source.index.is_unique
                    current_column=pd.to_numeric(source[cols[metric.lower()]],errors='raise').reindex(table.index)
                    freshness.append(dict(Modality=mod,Completeness=pct,Model=row.Model,Level='Per_Type',
                                          Metric=metric,Snapshot_matches_current=bool(np.allclose(table[row.Model],current_column,equal_nan=True))))
                    table[row.Model]=current_column
                current = type_df[(type_df.Modality==mod)&(type_df.Completeness==pct)].set_index('Type')
                table['ARGScope'] = current[metric]
                long = table.reset_index().melt(id_vars='Type', var_name='Model', value_name='Value')
                long['Modality'],long['Completeness'],long['Metric'] = mod,pct,metric
                long['Comparability'] = 'reported_summaries_NOT_matched_cohort_or_aggregation'
                raw_type.append(long)
    export(pd.concat(reported, ignore_index=True), 'reported_overall_NOT_matched.csv')
    export(pd.concat(raw_type, ignore_index=True), 'reported_per_type_NOT_matched.csv')
    export(pd.DataFrame(freshness), 'baseline_source_freshness_audit.csv')

    # Each plotted feature/outcome is one row per ORIGINAL ARG parent, not fragment.
    ids = fulls['protein'].index[fulls['protein'].true_ARG.eq(1)]
    features = pd.DataFrame(index=ids)
    features['Type'] = fulls['protein'].loc[ids, 'true_type']
    features['Subtype'] = fulls['protein'].loc[ids, 'true_subtype']
    features['Protein_length'] = structure.loc[ids, 'Protein.Length.aa']
    features['DNA_length'] = structure.loc[ids, 'DNA.Length.nt']
    assert train_support['protein'].sort_index().equals(train_support['dna'].sort_index())
    features['Training_support'] = features.Subtype.map(train_support['protein'])
    assert features.Training_support.notna().all()
    for mod in ['protein','dna']:
        features[f'{mod}_ARG_confidence'] = fulls[mod].loc[ids, 'ARG_probability']
        features[f'{mod}_subtype_confidence'] = fulls[mod].loc[ids, 'ARG_subtype_max_probability']
        robustness_mean = parent_df[parent_df.Modality.eq(mod)].groupby('parent_sequence_id').Subtype_fraction.mean()
        features[f'{mod}_subtype_robustness'] = robustness_mean.loc[ids]
    covariates = ['Protein_length','Training_support','protein_ARG_confidence','protein_subtype_confidence',
                  'dna_ARG_confidence','dna_subtype_confidence']
    outcomes = ['protein_subtype_robustness','dna_subtype_robustness']
    corr = features[covariates].corr(method='spearman')
    corr.to_csv(OUT/'feature_spearman_matrix.csv', encoding='utf-8-sig', index_label='Feature')
    links = []
    # Descriptive coefficients only: no misleading significance claims from related genes.
    for outcome in outcomes:
        for cov in covariates:
            rho = spearmanr(features[cov], features[outcome]).statistic
            links.append(dict(Outcome=outcome, Feature=cov, Spearman_rho=rho,
                              N_parents=len(features), Statistical_claim='descriptive_no_P_value_no_causality'))
    export(pd.DataFrame(links), 'feature_robustness_links.csv')
    export(features.reset_index(), 'ARG_parent_features_and_robustness.csv')
    subtype_means = features.groupby('Subtype')[covariates+outcomes].mean()
    sensitivity = []
    for outcome in outcomes:
        for cov in covariates:
            sensitivity.append(dict(Outcome=outcome, Feature=cov,
                                    Spearman_rho=spearmanr(subtype_means[cov], subtype_means[outcome]).statistic,
                                    N_subtypes=len(subtype_means)))
    export(pd.DataFrame(sensitivity), 'subtype_aggregation_correlation_sensitivity.csv')
    paired = []
    for pct in PCTS:
        for level in ['Type','Subtype']:
            v = parent_df[parent_df.Completeness.eq(pct)].pivot(index='parent_sequence_id',columns='Modality',values=f'{level}_fraction')
            for label, count in [('Protein higher', (v.protein>v.dna).sum()),('Equal', (v.protein==v.dna).sum()),('DNA higher',(v.protein<v.dna).sum())]:
                paired.append(dict(Completeness=pct, Level=level, Outcome=label, Count=int(count), Fraction=count/len(v), N_parents=len(v)))
    export(pd.DataFrame(paired), 'paired_parent_modality_comparison.csv')
    (OUT/'input_sha256.json').write_text(json.dumps(SOURCES,ensure_ascii=False,indent=2),encoding='utf-8')
    print('AUDIT: 4574 fixed parents; 2287 ARG parents; 23 ARG Types; 820 subtypes; 5 fragments per parent per completeness; matching modalities; no train/test ID overlap.')
    print(overall[(overall.Level=='Type')&(overall.Average=='weighted')].to_string(index=False))
    print(pd.DataFrame(robustness).query("Level == 'Subtype'").to_string(index=False))
    print(pd.DataFrame(links).to_string(index=False))


if __name__ == '__main__':
    main()
