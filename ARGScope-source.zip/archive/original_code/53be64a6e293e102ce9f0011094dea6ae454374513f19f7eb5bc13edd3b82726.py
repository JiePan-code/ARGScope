# -*- coding: utf-8 -*-
"""
严格检查 ARGScope 的两套正确输入：
1. DNABERT-2 DNA embedding：768维
2. ESM-2 protein embedding：1280维

将本脚本放在 endtoend 目录，与以下文件同级后运行：
- all_arg_nonarg_dnabert2_embedding.txt
- all_arg_nonarg_protein_embeddings.txt
- all_arg_nonarg_id_label.csv
- official_train_core.csv
- official_validation.csv
- all_subtype_test_set.csv
- official_independent_test.csv

关键检查：
- DNA 是否为 26,878 × 768
- Protein 是否为 26,878 × 1280
- 两套 embedding 是否无重复ID、NaN、Inf、全零向量、常数列
- DNA、Protein、标签三者 ID 集合是否完全一致
- DNA 与 Protein 行顺序是否一致
- 标签是否为 2,825 Subtype、31 Type
- train/validation/independent 是否严格互斥
- coverage test 与 final train 的预期重叠是否为 2,004
"""

from __future__ import annotations

import gc
import json
import re
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd


# =============================================================================
# 配置
# =============================================================================

WORKDIR = Path(__file__).resolve().parent

DNA_FILE = WORKDIR / "all_arg_nonarg_dnabert2_embedding.txt"
PROTEIN_FILE = WORKDIR / "all_arg_nonarg_protein_embeddings.txt"

LABEL_FILE = WORKDIR / "all_arg_nonarg_id_label.csv"
TRAIN_FILE = WORKDIR / "official_train_core.csv"
VAL_FILE = WORKDIR / "official_validation.csv"
COVERAGE_FILE = WORKDIR / "all_subtype_test_set.csv"
INDEPENDENT_FILE = WORKDIR / "official_independent_test.csv"

EXPECTED_ROWS = 26878
EXPECTED_DNA_DIM = 768
EXPECTED_PROTEIN_DIM = 1280
EXPECTED_SUBTYPE_COUNT = 2825
EXPECTED_TYPE_COUNT = 31
EXPECTED_COVERAGE_OVERLAP = 2004

REPORT_JSON = WORKDIR / "dnabert2_esm2_embedding_check_report.json"
REPORT_CSV = WORKDIR / "dnabert2_esm2_embedding_check_summary.csv"
ID_MISMATCH_CSV = WORKDIR / "dnabert2_esm2_id_mismatch.csv"
ORDER_MISMATCH_CSV = WORKDIR / "dnabert2_esm2_order_mismatch.csv"
DNA_DUPLICATE_ID_CSV = WORKDIR / "dnabert2_duplicate_ids.csv"
PROTEIN_DUPLICATE_ID_CSV = WORKDIR / "esm2_protein_duplicate_ids.csv"

ID_CANDIDATES = [
    "id", "ID", "Id", "seq_id", "sequence_id", "Sequence_ID",
    "Geneid", "geneid", "NucleotideID", "ProteinID", "protein_id",
]


# =============================================================================
# 通用函数
# =============================================================================

def normalize_text(x) -> str:
    return str(x).strip()


def require_file(path: Path, description: str) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"找不到{description}: {path}")


def detect_separator(path: Path) -> str:
    with path.open("r", encoding="utf-8", errors="ignore") as handle:
        first = handle.readline()

    if "\t" in first:
        return "\t"
    if "," in first:
        return ","
    return r"\s+"


def token_is_float(token: str) -> bool:
    try:
        float(token)
        return True
    except Exception:
        return False


def detect_header(path: Path, sep: str) -> bool:
    with path.open("r", encoding="utf-8", errors="ignore") as handle:
        first = handle.readline().strip()

    tokens = re.split(r"\s+", first) if sep == r"\s+" else first.split(sep)

    if len(tokens) < 2:
        return False

    # 第一列是ID；第二列不是数值时，通常表示存在表头
    return not token_is_float(tokens[1])


def find_id_col(df: pd.DataFrame) -> str:
    for col in ID_CANDIDATES:
        if col in df.columns:
            return col
    return str(df.columns[0])


def load_embedding(
    path: Path,
    name: str,
) -> Tuple[pd.Series, np.ndarray, Dict]:
    require_file(path, f"{name} embedding 文件")

    sep = detect_separator(path)
    has_header = detect_header(path, sep)

    read_kwargs = {
        "sep": sep,
        "engine": "python",
    }

    if has_header:
        df = pd.read_csv(path, **read_kwargs)
        id_col = find_id_col(df)
        ids = df[id_col].map(normalize_text)
        feature_df = df.drop(columns=[id_col])
    else:
        df = pd.read_csv(path, header=None, **read_kwargs)
        ids = df.iloc[:, 0].map(normalize_text)
        feature_df = df.iloc[:, 1:]

    feature_df = (
        feature_df
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
    )
    values = feature_df.to_numpy(dtype=np.float32)

    meta = {
        "name": name,
        "path": str(path),
        "separator": "whitespace" if sep == r"\s+" else repr(sep),
        "has_header": bool(has_header),
        "raw_rows": int(df.shape[0]),
        "raw_columns": int(df.shape[1]),
        "feature_columns": int(values.shape[1]),
    }

    del feature_df
    del df
    gc.collect()

    return ids, values, meta


def load_table(path: Path, name: str) -> pd.DataFrame:
    require_file(path, name)
    df = pd.read_csv(path, encoding="utf-8-sig")
    id_col = find_id_col(df)
    df = df.rename(columns={id_col: "id"})
    df["id"] = df["id"].map(normalize_text)
    return df


def resolve_label_columns(df: pd.DataFrame) -> Tuple[str, str]:
    subtype_col = next(
        (x for x in ["Subtype", "subtype", "SUBTYPE"] if x in df.columns),
        None,
    )
    type_col = next(
        (x for x in ["Type", "type", "TYPE"] if x in df.columns),
        None,
    )

    if subtype_col is None or type_col is None:
        raise ValueError(
            "标签表必须包含 Type 和 Subtype 列。"
            f"当前列名: {df.columns.tolist()}"
        )

    return subtype_col, type_col


def status_row(
    check: str,
    observed,
    expected,
    passed: bool,
    note: str = "",
    critical: bool = True,
) -> Dict:
    return {
        "check": check,
        "observed": observed,
        "expected": expected,
        "passed": bool(passed),
        "critical": bool(critical),
        "note": note,
    }


def inspect_embedding(
    name: str,
    ids: pd.Series,
    values: np.ndarray,
    expected_dim: int,
    duplicate_csv: Path,
) -> Tuple[List[Dict], Dict]:
    rows: List[Dict] = []

    n_rows, n_dim = values.shape
    unique_ids = int(ids.nunique())

    duplicate_mask = ids.duplicated(keep=False)
    duplicate_rows = int(duplicate_mask.sum())
    duplicate_unique_ids = int(ids[duplicate_mask].nunique())

    nan_count = int(np.isnan(values).sum())
    inf_count = int(np.isinf(values).sum())

    finite_values = np.where(np.isfinite(values), values, 0.0)
    norms = np.linalg.norm(finite_values, axis=1)
    zero_vector_count = int(np.sum(norms <= 1e-12))

    col_std = np.nanstd(
        np.where(np.isfinite(values), values, np.nan),
        axis=0,
    )
    constant_column_count = int(
        np.sum(np.nan_to_num(col_std, nan=0.0) <= 1e-12)
    )

    rows.extend([
        status_row(
            f"{name} embedding维度",
            n_dim,
            expected_dim,
            n_dim == expected_dim,
            f"{name}必须严格为{expected_dim}维。",
        ),
        status_row(
            f"{name}总列数",
            n_dim + 1,
            expected_dim + 1,
            n_dim + 1 == expected_dim + 1,
            "预期为1列ID加embedding特征列。",
        ),
        status_row(
            f"{name}行数",
            n_rows,
            EXPECTED_ROWS,
            n_rows == EXPECTED_ROWS,
        ),
        status_row(
            f"{name}唯一ID数",
            unique_ids,
            EXPECTED_ROWS,
            unique_ids == EXPECTED_ROWS,
        ),
        status_row(
            f"{name}重复ID行数",
            duplicate_rows,
            0,
            duplicate_rows == 0,
            f"涉及{duplicate_unique_ids}个重复ID。",
        ),
        status_row(
            f"{name} NaN数量",
            nan_count,
            0,
            nan_count == 0,
        ),
        status_row(
            f"{name} Inf数量",
            inf_count,
            0,
            inf_count == 0,
        ),
        status_row(
            f"{name}全零向量数量",
            zero_vector_count,
            0,
            zero_vector_count == 0,
        ),
        status_row(
            f"{name}常数特征列数量",
            constant_column_count,
            0,
            constant_column_count == 0,
        ),
    ])

    if duplicate_rows > 0:
        pd.DataFrame({"id": ids[duplicate_mask]}).to_csv(
            duplicate_csv,
            index=False,
            encoding="utf-8-sig",
        )
    else:
        pd.DataFrame(columns=["id"]).to_csv(
            duplicate_csv,
            index=False,
            encoding="utf-8-sig",
        )

    summary = {
        "shape": [int(n_rows), int(n_dim)],
        "unique_ids": unique_ids,
        "duplicate_id_rows": duplicate_rows,
        "duplicate_unique_ids": duplicate_unique_ids,
        "nan_count": nan_count,
        "inf_count": inf_count,
        "zero_vector_count": zero_vector_count,
        "constant_column_count": constant_column_count,
        "norm_statistics": {
            "min": float(np.min(norms)),
            "max": float(np.max(norms)),
            "mean": float(np.mean(norms)),
            "median": float(np.median(norms)),
            "std": float(np.std(norms)),
        },
    }

    return rows, summary


# =============================================================================
# 主检查流程
# =============================================================================

def main() -> None:
    print("=" * 96)
    print("严格检查 DNABERT-2 768维 DNA + ESM-2 1280维 Protein embedding")
    print("=" * 96)
    print("工作目录:", WORKDIR)
    print("DNA文件   :", DNA_FILE)
    print("Protein文件:", PROTEIN_FILE)

    rows: List[Dict] = []
    report: Dict = {}

    # -------------------------------------------------------------------------
    # 1. DNA
    # -------------------------------------------------------------------------

    print("\n[1/4] 读取并检查 DNABERT-2 DNA embedding...")
    dna_ids, dna_values, dna_meta = load_embedding(
        DNA_FILE,
        "DNABERT-2 DNA",
    )
    dna_rows, dna_summary = inspect_embedding(
        "DNABERT-2 DNA",
        dna_ids,
        dna_values,
        EXPECTED_DNA_DIM,
        DNA_DUPLICATE_ID_CSV,
    )
    rows.extend(dna_rows)

    # 保存ID和统计后释放大型DNA矩阵，降低内存占用
    dna_id_list = dna_ids.tolist()
    dna_id_set = set(dna_id_list)

    del dna_values
    gc.collect()

    # -------------------------------------------------------------------------
    # 2. Protein
    # -------------------------------------------------------------------------

    print("[2/4] 读取并检查 ESM-2 Protein embedding...")
    protein_ids, protein_values, protein_meta = load_embedding(
        PROTEIN_FILE,
        "ESM-2 Protein",
    )
    protein_rows, protein_summary = inspect_embedding(
        "ESM-2 Protein",
        protein_ids,
        protein_values,
        EXPECTED_PROTEIN_DIM,
        PROTEIN_DUPLICATE_ID_CSV,
    )
    rows.extend(protein_rows)

    protein_id_list = protein_ids.tolist()
    protein_id_set = set(protein_id_list)

    del protein_values
    gc.collect()

    # -------------------------------------------------------------------------
    # 3. 标签和ID一致性
    # -------------------------------------------------------------------------

    print("[3/4] 检查 DNA、Protein、标签与数据划分的ID一致性...")
    labels = load_table(LABEL_FILE, "标签表")
    subtype_col, type_col = resolve_label_columns(labels)

    labels[subtype_col] = labels[subtype_col].map(normalize_text)
    labels[type_col] = labels[type_col].map(normalize_text)

    label_id_list = labels["id"].tolist()
    label_id_set = set(label_id_list)

    rows.extend([
        status_row(
            "标签表行数",
            len(labels),
            EXPECTED_ROWS,
            len(labels) == EXPECTED_ROWS,
        ),
        status_row(
            "标签表唯一ID数",
            labels["id"].nunique(),
            EXPECTED_ROWS,
            labels["id"].nunique() == EXPECTED_ROWS,
        ),
        status_row(
            "Subtype数量",
            labels[subtype_col].nunique(),
            EXPECTED_SUBTYPE_COUNT,
            labels[subtype_col].nunique() == EXPECTED_SUBTYPE_COUNT,
        ),
        status_row(
            "Type数量",
            labels[type_col].nunique(),
            EXPECTED_TYPE_COUNT,
            labels[type_col].nunique() == EXPECTED_TYPE_COUNT,
        ),
    ])

    dna_only = sorted(dna_id_set - label_id_set)
    protein_only = sorted(protein_id_set - label_id_set)
    label_missing_dna = sorted(label_id_set - dna_id_set)
    label_missing_protein = sorted(label_id_set - protein_id_set)
    dna_only_vs_protein = sorted(dna_id_set - protein_id_set)
    protein_only_vs_dna = sorted(protein_id_set - dna_id_set)

    rows.extend([
        status_row(
            "DNA与标签ID集合完全一致",
            f"dna_only={len(dna_only)}, label_missing_dna={len(label_missing_dna)}",
            "0 / 0",
            len(dna_only) == 0 and len(label_missing_dna) == 0,
        ),
        status_row(
            "Protein与标签ID集合完全一致",
            f"protein_only={len(protein_only)}, label_missing_protein={len(label_missing_protein)}",
            "0 / 0",
            len(protein_only) == 0 and len(label_missing_protein) == 0,
        ),
        status_row(
            "DNA与Protein ID集合完全一致",
            f"dna_only={len(dna_only_vs_protein)}, protein_only={len(protein_only_vs_dna)}",
            "0 / 0",
            len(dna_only_vs_protein) == 0 and len(protein_only_vs_dna) == 0,
            "这是后续按ID构建Fusion的必要条件。",
        ),
    ])

    mismatch_records = []
    mismatch_records.extend(
        {"id": x, "category": "dna_only_vs_label"} for x in dna_only
    )
    mismatch_records.extend(
        {"id": x, "category": "protein_only_vs_label"} for x in protein_only
    )
    mismatch_records.extend(
        {"id": x, "category": "label_missing_dna"} for x in label_missing_dna
    )
    mismatch_records.extend(
        {"id": x, "category": "label_missing_protein"} for x in label_missing_protein
    )
    mismatch_records.extend(
        {"id": x, "category": "dna_only_vs_protein"} for x in dna_only_vs_protein
    )
    mismatch_records.extend(
        {"id": x, "category": "protein_only_vs_dna"} for x in protein_only_vs_dna
    )

    pd.DataFrame(
        mismatch_records,
        columns=["id", "category"],
    ).to_csv(
        ID_MISMATCH_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    # 行顺序检查：不是Fusion正确性的必要条件，但可发现潜在的按行拼接风险
    same_order = (
        len(dna_id_list) == len(protein_id_list)
        and dna_id_list == protein_id_list
    )

    order_mismatch_records = []
    if len(dna_id_list) == len(protein_id_list):
        for i, (dna_id, protein_id) in enumerate(
            zip(dna_id_list, protein_id_list)
        ):
            if dna_id != protein_id:
                order_mismatch_records.append({
                    "row_index_0based": i,
                    "dna_id": dna_id,
                    "protein_id": protein_id,
                })

    pd.DataFrame(
        order_mismatch_records,
        columns=["row_index_0based", "dna_id", "protein_id"],
    ).to_csv(
        ORDER_MISMATCH_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    rows.append(status_row(
        "DNA与Protein行顺序完全一致",
        len(order_mismatch_records),
        0,
        same_order,
        "即使顺序不一致，也必须在训练代码中按ID merge，严禁直接按行拼接。",
        critical=False,
    ))

    # -------------------------------------------------------------------------
    # 4. split检查
    # -------------------------------------------------------------------------

    split_tables = {}
    for split_name, split_path in [
        ("train_core", TRAIN_FILE),
        ("validation", VAL_FILE),
        ("coverage_test", COVERAGE_FILE),
        ("independent_test", INDEPENDENT_FILE),
    ]:
        split_df = load_table(split_path, split_name)
        split_tables[split_name] = split_df
        split_ids = set(split_df["id"])

        rows.extend([
            status_row(
                f"{split_name} ID全部存在于DNA",
                len(split_ids - dna_id_set),
                0,
                len(split_ids - dna_id_set) == 0,
            ),
            status_row(
                f"{split_name} ID全部存在于Protein",
                len(split_ids - protein_id_set),
                0,
                len(split_ids - protein_id_set) == 0,
            ),
            status_row(
                f"{split_name}内部重复ID",
                int(split_df["id"].duplicated().sum()),
                0,
                int(split_df["id"].duplicated().sum()) == 0,
            ),
        ])

    train_ids = set(split_tables["train_core"]["id"])
    val_ids = set(split_tables["validation"]["id"])
    coverage_ids = set(split_tables["coverage_test"]["id"])
    independent_ids = set(split_tables["independent_test"]["id"])
    final_train_ids = train_ids | val_ids

    train_val_overlap = len(train_ids & val_ids)
    final_independent_overlap = len(final_train_ids & independent_ids)
    coverage_overlap = len(final_train_ids & coverage_ids)

    rows.extend([
        status_row(
            "train_core与validation重叠",
            train_val_overlap,
            0,
            train_val_overlap == 0,
        ),
        status_row(
            "final_train与independent_test重叠",
            final_independent_overlap,
            0,
            final_independent_overlap == 0,
            "严格独立测试必须为0。",
        ),
        status_row(
            "coverage_test与final_train重叠",
            coverage_overlap,
            EXPECTED_COVERAGE_OVERLAP,
            coverage_overlap == EXPECTED_COVERAGE_OVERLAP,
            "项目设计中允许2,004条singleton覆盖重叠。",
        ),
    ])

    # -------------------------------------------------------------------------
    # 输出报告
    # -------------------------------------------------------------------------

    summary_df = pd.DataFrame(rows)
    summary_df.to_csv(
        REPORT_CSV,
        index=False,
        encoding="utf-8-sig",
    )

    report.update({
        "dna_meta": dna_meta,
        "protein_meta": protein_meta,
        "dna_summary": dna_summary,
        "protein_summary": protein_summary,
        "label_summary": {
            "rows": int(len(labels)),
            "unique_ids": int(labels["id"].nunique()),
            "subtypes": int(labels[subtype_col].nunique()),
            "types": int(labels[type_col].nunique()),
        },
        "id_set_checks": {
            "dna_only_vs_label": len(dna_only),
            "protein_only_vs_label": len(protein_only),
            "label_missing_dna": len(label_missing_dna),
            "label_missing_protein": len(label_missing_protein),
            "dna_only_vs_protein": len(dna_only_vs_protein),
            "protein_only_vs_dna": len(protein_only_vs_dna),
            "dna_protein_same_row_order": bool(same_order),
            "dna_protein_order_mismatch_rows": len(order_mismatch_records),
        },
        "split_checks": {
            "train_validation_overlap": train_val_overlap,
            "final_train_independent_overlap": final_independent_overlap,
            "final_train_coverage_overlap": coverage_overlap,
        },
        "checks": rows,
    })

    critical_failed = summary_df[
        summary_df["critical"] & (~summary_df["passed"])
    ]
    report["all_critical_checks_passed"] = critical_failed.empty

    with REPORT_JSON.open("w", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)

    print("\n" + "=" * 96)
    print("核心结果")
    print("=" * 96)
    print(f"DNA shape                    : {tuple(dna_summary['shape'])}")
    print(f"DNA unique IDs               : {dna_summary['unique_ids']}")
    print(f"DNA duplicate IDs            : {dna_summary['duplicate_id_rows']}")
    print(f"DNA NaN / Inf                : {dna_summary['nan_count']} / {dna_summary['inf_count']}")
    print(f"DNA zero vectors             : {dna_summary['zero_vector_count']}")
    print(f"DNA constant columns         : {dna_summary['constant_column_count']}")
    print("-" * 96)
    print(f"Protein shape                : {tuple(protein_summary['shape'])}")
    print(f"Protein unique IDs           : {protein_summary['unique_ids']}")
    print(f"Protein duplicate IDs        : {protein_summary['duplicate_id_rows']}")
    print(f"Protein NaN / Inf            : {protein_summary['nan_count']} / {protein_summary['inf_count']}")
    print(f"Protein zero vectors         : {protein_summary['zero_vector_count']}")
    print(f"Protein constant columns     : {protein_summary['constant_column_count']}")
    print("-" * 96)
    print(f"Subtype / Type               : {labels[subtype_col].nunique()} / {labels[type_col].nunique()}")
    print(f"DNA-label ID mismatch        : {len(dna_only) + len(label_missing_dna)}")
    print(f"Protein-label ID mismatch    : {len(protein_only) + len(label_missing_protein)}")
    print(f"DNA-protein ID mismatch      : {len(dna_only_vs_protein) + len(protein_only_vs_dna)}")
    print(f"DNA-protein order mismatches : {len(order_mismatch_records)}")
    print(f"Train-Val overlap            : {train_val_overlap}")
    print(f"Train-Indep overlap          : {final_independent_overlap}")
    print(f"Train-Cover overlap          : {coverage_overlap}")
    print("-" * 96)

    if critical_failed.empty:
        print("结论：所有关键检查通过。")
        print("DNA可作为正确的768维DNABERT-2输入。")
        print("Protein可作为正确的1280维ESM-2输入。")
        if same_order:
            print("DNA与Protein的ID集合和行顺序均一致。")
        else:
            print("警告：DNA与Protein的ID集合一致，但行顺序不一致。")
            print("后续Fusion代码必须按ID merge，绝不能直接按行拼接。")
    else:
        print("结论：存在关键检查失败，暂时不要训练Fusion。")
        print(
            critical_failed[
                ["check", "observed", "expected", "note"]
            ].to_string(index=False)
        )

    print("\n报告文件:")
    print(" -", REPORT_JSON)
    print(" -", REPORT_CSV)
    print(" -", ID_MISMATCH_CSV)
    print(" -", ORDER_MISMATCH_CSV)
    print(" -", DNA_DUPLICATE_ID_CSV)
    print(" -", PROTEIN_DUPLICATE_ID_CSV)


if __name__ == "__main__":
    main()
