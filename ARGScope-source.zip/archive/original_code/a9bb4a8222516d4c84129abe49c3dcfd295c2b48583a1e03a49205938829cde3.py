# -*- coding: utf-8 -*-
"""
批量评估 ARGScope 的 *_subtype_test_predictions.csv 结果，
采用 FunGeneTyper 补充材料中的指标报告思路。

FunGeneTyper 指标口径
--------------------
1. 单标签多分类中：
   - Accuracy 代表整体正确率；
   - Micro Precision / Recall / F1 与 Accuracy 相同，因此不作为主表重复报告；
   - Precision、Recall、F1 的论文主结果使用 Macro average。

2. FunTrans 风格 Type 评估：
   - 在全部样本上进行；
   - nonARG 作为一个正式 Type 类别；
   - 使用真实标签空间中的全部 Type；
   - 报告 Accuracy、Macro Precision、Macro Recall、Macro F1；
   - 本脚本额外保留 MCC 和 Weighted/Micro 结果供补充分析。

3. FunRep 风格 Subtype 评估：
   - 只在真实 ARG 样本上进行，不把真实 nonARG 当作一个 Subtype；
   - 真实 ARG 即 Type != nonARG；
   - ARGScope 将真实 ARG 预测为 nonARG 时，不删除该样本，仍作为错误计入；
   - 使用真实 ARG 测试集中出现的全部 Subtype；
   - 报告 Accuracy、Macro Precision、Macro Recall、Macro F1；
   - 本脚本额外保留 MCC 和 Weighted/Micro 结果供补充分析。

4. ARG / nonARG 二分类：
   - 以 ARG 为正类；
   - 主结果报告 Accuracy、ARG Precision、ARG Recall、ARG F1 和 MCC；
   - 同时保留 Macro、Weighted、Micro 结果供检查。

输入文件示例
------------
    30aa_subtype_test_predictions.csv
    40aa_subtype_test_predictions.csv
    50aa_subtype_test_predictions.csv
    60p_subtype_test_predictions.csv
    ...
    100p_subtype_test_predictions.csv

每个输入文件必须包含
--------------------
    dataset
    KEY
    Type
    Subtype
    Pred_Subtype

标签处理
--------
- 不修改任何真实或预测标签；
- Pred_Type 从 Pred_Subtype 的第一个 "__" 之前提取；
- Type 的主评估标签空间来自真实 Type；
- Subtype 的主评估标签空间来自真实 ARG 样本的真实 Subtype；
- 预测到标签空间之外的类别不会被删除，对应样本仍按错误处理，
  并单独输出诊断文件。

输出目录
--------
    argscope_batch_fungenetyper_style_metrics/

最重要的批量结果
----------------
1. batch_fungenetyper_main_metrics_wide.csv
   每个数据集一行，包含：
   - ARG/nonARG：ACC、ARG Precision、ARG Recall、ARG F1、MCC
   - Type：ACC、Macro Precision、Macro Recall、Macro F1、MCC
   - Subtype：ACC、Macro Precision、Macro Recall、Macro F1、MCC

2. batch_fungenetyper_main_metrics_long.csv
   与主结果相同，但每个任务一行。

3. batch_all_metrics_wide.csv
   完整补充结果：Macro、Weighted、Micro、Accuracy、MCC。

4. batch_type_per_class_all_true_types.csv
   每个真实 Type 的 one-vs-rest 指标。

5. batch_subtype_per_class_true_ARG_only.csv
   真实 ARG 样本中每个 Subtype 的 one-vs-rest 指标。
"""

from __future__ import annotations

import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)


# =============================================================================
# 1. 路径和参数
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
INPUT_PATTERN = "*_subtype_test_predictions.csv"

OUT_ROOT = (
    SCRIPT_DIR
    / "argscope_batch_fungenetyper_style_metrics"
)
OUT_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)

TYPE_REPORT_DIR = (
    OUT_ROOT
    / "type_reports_for_plot"
)
TYPE_REPORT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

SUBTYPE_REPORT_DIR = (
    OUT_ROOT
    / "subtype_reports_for_plot"
)
SUBTYPE_REPORT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

ROUND_N = 4
NONARG_LABEL = "nonARG"
TOP_ERROR_PAIRS = 100

REQUIRED_COLUMNS = {
    "dataset",
    "KEY",
    "Type",
    "Subtype",
    "Pred_Subtype",
}


# =============================================================================
# 2. 通用函数
# =============================================================================

def natural_sort_key(value: str):
    """自然排序，例如 30aa < 40aa < 60p < 100p。"""
    return [
        int(token) if token.isdigit() else token.lower()
        for token in re.split(
            r"(\d+)",
            str(value),
        )
    ]


def clean_text_series(
    series: pd.Series,
) -> pd.Series:
    return (
        series
        .astype("string")
        .str.strip()
    )


def ordered_labels(
    values,
) -> list[str]:
    """
    对标签自然排序；nonARG放在第一位。
    """
    unique_values = {
        str(value).strip()
        for value in values
        if (
            pd.notna(value)
            and str(value).strip() != ""
        )
    }

    labels = sorted(
        unique_values,
        key=natural_sort_key,
    )

    if NONARG_LABEL in labels:
        labels.remove(
            NONARG_LABEL
        )
        labels.insert(
            0,
            NONARG_LABEL,
        )

    return labels


def dataset_name_from_file(
    input_file: Path,
    dataframe: pd.DataFrame,
) -> str:
    dataset_values = (
        dataframe["dataset"]
        .dropna()
        .astype(str)
        .str.strip()
    )

    dataset_values = (
        dataset_values[
            dataset_values.ne("")
        ]
        .unique()
        .tolist()
    )

    if len(dataset_values) == 1:
        return dataset_values[0]

    if len(dataset_values) > 1:
        warnings.warn(
            f"{input_file.name} 的 dataset 列包含多个值："
            f"{dataset_values}；将使用文件名作为数据集名称。",
            RuntimeWarning,
        )

    suffix = "_subtype_test_predictions.csv"

    if input_file.name.endswith(
        suffix
    ):
        return input_file.name[
            :-len(suffix)
        ]

    return input_file.stem


def extract_predicted_type(
    pred_subtype: pd.Series,
) -> pd.Series:
    """
    从 Pred_Subtype 提取 Pred_Type，不修改标签。
    """
    cleaned = clean_text_series(
        pred_subtype
    )

    return (
        cleaned
        .str.split(
            "__",
            n=1,
            regex=False,
        )
        .str[0]
        .str.strip()
    )


def safe_mcc(
    y_true,
    y_pred,
) -> float:
    if len(y_true) == 0:
        return 0.0

    try:
        result = matthews_corrcoef(
            y_true,
            y_pred,
        )

        if pd.isna(result):
            return 0.0

        return float(result)

    except Exception:
        return 0.0


def round_float_columns(
    dataframe: pd.DataFrame,
    ndigits: int = ROUND_N,
) -> pd.DataFrame:
    result = dataframe.copy()

    float_columns = (
        result.select_dtypes(
            include=[
                "float16",
                "float32",
                "float64",
            ]
        ).columns
    )

    result.loc[
        :,
        float_columns,
    ] = (
        result.loc[
            :,
            float_columns,
        ]
        .round(ndigits)
    )

    return result


def save_csv(
    dataframe: pd.DataFrame,
    output_file: Path,
    *,
    index: bool = False,
) -> None:
    dataframe.to_csv(
        output_file,
        index=index,
        encoding="utf-8-sig",
        float_format=(
            f"%.{ROUND_N}f"
        ),
    )


# =============================================================================
# 3. 指标函数
# =============================================================================

def make_multiclass_overall_metrics(
    y_true,
    y_pred,
    *,
    dataset_name: str,
    level_name: str,
    true_label_space: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    FunGeneTyper风格多分类总体指标。

    主指标：
        Accuracy
        Macro Precision
        Macro Recall
        Macro F1
        MCC

    补充指标：
        Weighted Precision/Recall/F1
        Micro Precision/Recall/F1

    说明：
    - Macro和Weighted严格使用真实标签空间；
    - Micro不显式限制labels，使用观测到的全部标签，
      因而在标准单标签多分类中与Accuracy相同；
    - 预测到真实标签空间之外的样本不会被删除。
    """
    y_true = pd.Series(
        y_true,
        dtype="string",
    )
    y_pred = pd.Series(
        y_pred,
        dtype="string",
    )

    if len(y_true) == 0:
        raise ValueError(
            f"{dataset_name} 的 {level_name} 没有可评估样本。"
        )

    accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    mcc = safe_mcc(
        y_true,
        y_pred,
    )

    (
        macro_precision,
        macro_recall,
        macro_f1,
        _,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=true_label_space,
        average="macro",
        zero_division=0,
    )

    (
        weighted_precision,
        weighted_recall,
        weighted_f1,
        _,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=true_label_space,
        average="weighted",
        zero_division=0,
    )

    (
        micro_precision,
        micro_recall,
        micro_f1,
        _,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="micro",
        zero_division=0,
    )

    correct_count = int(
        (y_true == y_pred).sum()
    )
    wrong_count = int(
        (y_true != y_pred).sum()
    )

    predicted_outside_mask = (
        ~y_pred.isin(
            true_label_space
        )
    )

    predicted_outside_count = int(
        predicted_outside_mask.sum()
    )

    vertical_rows = [
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "overall",
            "metric": "accuracy",
            "value": accuracy,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "overall",
            "metric": "mcc",
            "value": mcc,
        },

        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "macro",
            "metric": "precision",
            "value": macro_precision,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "macro",
            "metric": "recall",
            "value": macro_recall,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "macro",
            "metric": "f1",
            "value": macro_f1,
        },

        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "weighted",
            "metric": "precision",
            "value": weighted_precision,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "weighted",
            "metric": "recall",
            "value": weighted_recall,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "weighted",
            "metric": "f1",
            "value": weighted_f1,
        },

        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "micro",
            "metric": "precision",
            "value": micro_precision,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "micro",
            "metric": "recall",
            "value": micro_recall,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "micro",
            "metric": "f1",
            "value": micro_f1,
        },

        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "counts",
            "metric": "support",
            "value": len(y_true),
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "counts",
            "metric": "true_class_count",
            "value": len(
                true_label_space
            ),
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "counts",
            "metric": "correct_count",
            "value": correct_count,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "counts",
            "metric": "wrong_count",
            "value": wrong_count,
        },
        {
            "dataset": dataset_name,
            "level": level_name,
            "average": "counts",
            "metric": "predicted_outside_true_label_space_count",
            "value": predicted_outside_count,
        },
    ]

    vertical_df = pd.DataFrame(
        vertical_rows
    )

    wide_df = pd.DataFrame([{
        "dataset": dataset_name,
        "level": level_name,

        "ACC": accuracy,
        "MCC": mcc,

        "macro_precision": macro_precision,
        "macro_recall": macro_recall,
        "macro_f1": macro_f1,

        "weighted_precision": weighted_precision,
        "weighted_recall": weighted_recall,
        "weighted_f1": weighted_f1,

        "micro_precision": micro_precision,
        "micro_recall": micro_recall,
        "micro_f1": micro_f1,

        "support": len(y_true),
        "true_class_count": len(
            true_label_space
        ),
        "correct_count": correct_count,
        "wrong_count": wrong_count,
        "predicted_outside_true_label_space_count": (
            predicted_outside_count
        ),

        "micro_minus_accuracy": (
            micro_f1 - accuracy
        ),
    }])

    return (
        vertical_df,
        wide_df,
    )


def make_binary_metrics(
    y_true,
    y_pred,
    *,
    dataset_name: str,
) -> tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    """
    ARG/nonARG二分类。

    主结果以ARG为正类：
        Accuracy
        ARG Precision
        ARG Recall
        ARG F1
        MCC

    同时输出Macro、Weighted、Micro供补充检查。
    """
    y_true = pd.Series(
        y_true,
        dtype="string",
    )
    y_pred = pd.Series(
        y_pred,
        dtype="string",
    )

    accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    mcc = safe_mcc(
        y_true,
        y_pred,
    )

    arg_precision = precision_score(
        y_true,
        y_pred,
        pos_label="ARG",
        average="binary",
        zero_division=0,
    )

    arg_recall = recall_score(
        y_true,
        y_pred,
        pos_label="ARG",
        average="binary",
        zero_division=0,
    )

    arg_f1 = f1_score(
        y_true,
        y_pred,
        pos_label="ARG",
        average="binary",
        zero_division=0,
    )

    average_results = {}

    for average_name in [
        "macro",
        "weighted",
        "micro",
    ]:
        (
            precision_value,
            recall_value,
            f1_value,
            _,
        ) = precision_recall_fscore_support(
            y_true,
            y_pred,
            average=average_name,
            zero_division=0,
        )

        average_results[
            average_name
        ] = {
            "precision": precision_value,
            "recall": recall_value,
            "f1": f1_value,
        }

    binary_cm = confusion_matrix(
        y_true,
        y_pred,
        labels=[
            NONARG_LABEL,
            "ARG",
        ],
    )

    (
        tn,
        fp,
        fn,
        tp,
    ) = binary_cm.ravel()

    rows = [
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "overall",
            "metric": "accuracy",
            "value": accuracy,
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "overall",
            "metric": "mcc",
            "value": mcc,
        },

        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "ARG_positive",
            "metric": "precision",
            "value": arg_precision,
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "ARG_positive",
            "metric": "recall",
            "value": arg_recall,
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "ARG_positive",
            "metric": "f1",
            "value": arg_f1,
        },
    ]

    for average_name in [
        "macro",
        "weighted",
        "micro",
    ]:
        rows.extend([
            {
                "dataset": dataset_name,
                "level": "ARG_nonARG",
                "average": average_name,
                "metric": "precision",
                "value": average_results[
                    average_name
                ]["precision"],
            },
            {
                "dataset": dataset_name,
                "level": "ARG_nonARG",
                "average": average_name,
                "metric": "recall",
                "value": average_results[
                    average_name
                ]["recall"],
            },
            {
                "dataset": dataset_name,
                "level": "ARG_nonARG",
                "average": average_name,
                "metric": "f1",
                "value": average_results[
                    average_name
                ]["f1"],
            },
        ])

    rows.extend([
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "counts",
            "metric": "TP",
            "value": int(tp),
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "counts",
            "metric": "FP",
            "value": int(fp),
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "counts",
            "metric": "FN",
            "value": int(fn),
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "counts",
            "metric": "TN",
            "value": int(tn),
        },
        {
            "dataset": dataset_name,
            "level": "ARG_nonARG",
            "average": "counts",
            "metric": "support",
            "value": len(y_true),
        },
    ])

    vertical_df = pd.DataFrame(
        rows
    )

    wide_df = pd.DataFrame([{
        "dataset": dataset_name,
        "level": "ARG_nonARG",

        "ACC": accuracy,
        "MCC": mcc,

        "ARG_precision": arg_precision,
        "ARG_recall": arg_recall,
        "ARG_f1": arg_f1,

        "macro_precision": (
            average_results[
                "macro"
            ]["precision"]
        ),
        "macro_recall": (
            average_results[
                "macro"
            ]["recall"]
        ),
        "macro_f1": (
            average_results[
                "macro"
            ]["f1"]
        ),

        "weighted_precision": (
            average_results[
                "weighted"
            ]["precision"]
        ),
        "weighted_recall": (
            average_results[
                "weighted"
            ]["recall"]
        ),
        "weighted_f1": (
            average_results[
                "weighted"
            ]["f1"]
        ),

        "micro_precision": (
            average_results[
                "micro"
            ]["precision"]
        ),
        "micro_recall": (
            average_results[
                "micro"
            ]["recall"]
        ),
        "micro_f1": (
            average_results[
                "micro"
            ]["f1"]
        ),

        "TP": int(tp),
        "FP": int(fp),
        "FN": int(fn),
        "TN": int(tn),
        "support": len(y_true),
    }])

    per_class_df = (
        make_per_class_metrics(
            y_true,
            y_pred,
            labels=[
                "ARG",
                NONARG_LABEL,
            ],
            dataset_name=dataset_name,
            level_name="ARG_nonARG",
        )
    )

    return (
        vertical_df,
        wide_df,
        per_class_df,
    )


def make_per_class_metrics(
    y_true,
    y_pred,
    *,
    labels: list[str],
    dataset_name: str,
    level_name: str,
) -> pd.DataFrame:
    """
    对固定真实标签空间逐类执行one-vs-rest计算。
    """
    y_true = pd.Series(
        y_true,
        dtype="string",
    )
    y_pred = pd.Series(
        y_pred,
        dtype="string",
    )

    (
        precision_values,
        recall_values,
        f1_values,
        support_values,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=labels,
        average=None,
        zero_division=0,
    )

    pred_count_map = (
        y_pred
        .value_counts()
        .to_dict()
    )

    correct_label_map = (
        y_true.loc[
            y_true == y_pred
        ]
        .value_counts()
        .to_dict()
    )

    total_count = len(y_true)
    rows = []

    for index, label in enumerate(
        labels
    ):
        support = int(
            support_values[index]
        )
        pred_count = int(
            pred_count_map.get(
                label,
                0,
            )
        )
        tp = int(
            correct_label_map.get(
                label,
                0,
            )
        )
        fp = int(
            pred_count - tp
        )
        fn = int(
            support - tp
        )
        tn = int(
            total_count
            - tp
            - fp
            - fn
        )

        accuracy = (
            (tp + tn) / total_count
            if total_count > 0
            else 0.0
        )

        denominator = np.sqrt(
            (tp + fp)
            * (tp + fn)
            * (tn + fp)
            * (tn + fn)
        )

        mcc = (
            (
                tp * tn
                - fp * fn
            )
            / denominator
            if denominator > 0
            else 0.0
        )

        rows.append({
            "dataset": dataset_name,
            "level": level_name,
            "label": label,
            "support": support,
            "pred_count": pred_count,
            "correct": tp,
            "true_positive": tp,
            "false_positive": fp,
            "false_negative": fn,
            "true_negative": tn,
            "accuracy_one_vs_rest": accuracy,
            "precision": float(
                precision_values[index]
            ),
            "recall": float(
                recall_values[index]
            ),
            "f1": float(
                f1_values[index]
            ),
            "mcc": float(mcc),
        })

    return pd.DataFrame(
        rows
    )


def make_sparse_confusion(
    y_true,
    y_pred,
    *,
    dataset_name: str,
    level_name: str,
) -> pd.DataFrame:
    """
    保存非零混淆对，避免数千Subtype形成稠密矩阵。
    """
    confusion_long = pd.DataFrame({
        "true_label": pd.Series(
            y_true,
            dtype="string",
        ),
        "predicted_label": pd.Series(
            y_pred,
            dtype="string",
        ),
    })

    confusion_long = (
        confusion_long
        .groupby(
            [
                "true_label",
                "predicted_label",
            ],
            dropna=False,
        )
        .size()
        .reset_index(
            name="count"
        )
        .sort_values(
            [
                "count",
                "true_label",
                "predicted_label",
            ],
            ascending=[
                False,
                True,
                True,
            ],
        )
        .reset_index(
            drop=True
        )
    )

    confusion_long.insert(
        0,
        "level",
        level_name,
    )
    confusion_long.insert(
        0,
        "dataset",
        dataset_name,
    )

    confusion_long[
        "is_correct"
    ] = (
        confusion_long[
            "true_label"
        ]
        == confusion_long[
            "predicted_label"
        ]
    )

    return confusion_long


def make_top_error_pairs(
    sparse_confusion: pd.DataFrame,
    top_n: int = TOP_ERROR_PAIRS,
) -> pd.DataFrame:
    return (
        sparse_confusion.loc[
            ~sparse_confusion[
                "is_correct"
            ]
        ]
        .head(top_n)
        .reset_index(
            drop=True
        )
    )


# =============================================================================
# 4. 单个文件评估
# =============================================================================

def evaluate_one_file(
    input_file: Path,
) -> dict:
    dataframe = pd.read_csv(
        input_file,
        encoding="utf-8-sig",
    )

    dataframe.columns = [
        str(column).strip()
        for column in dataframe.columns
    ]

    missing_columns = (
        REQUIRED_COLUMNS
        - set(dataframe.columns)
    )

    if missing_columns:
        raise ValueError(
            f"{input_file.name} 缺少列："
            f"{sorted(missing_columns)}；"
            f"现有列：{list(dataframe.columns)}"
        )

    dataframe = dataframe.copy()

    for column in REQUIRED_COLUMNS:
        dataframe[column] = (
            clean_text_series(
                dataframe[column]
            )
        )

    missing_value_counts = {
        column: int(
            dataframe[column]
            .isna()
            .sum()
        )
        for column in REQUIRED_COLUMNS
    }

    if any(
        count > 0
        for count
        in missing_value_counts.values()
    ):
        raise ValueError(
            f"{input_file.name} 存在缺失值："
            f"{missing_value_counts}"
        )

    empty_value_counts = {
        column: int(
            dataframe[column]
            .eq("")
            .sum()
        )
        for column in REQUIRED_COLUMNS
    }

    if any(
        count > 0
        for count
        in empty_value_counts.values()
    ):
        raise ValueError(
            f"{input_file.name} 存在空字符串："
            f"{empty_value_counts}"
        )

    duplicate_key_count = int(
        dataframe["KEY"]
        .duplicated()
        .sum()
    )

    if duplicate_key_count > 0:
        duplicated_rows = (
            dataframe.loc[
                dataframe["KEY"]
                .duplicated(
                    keep=False
                )
            ]
            .copy()
        )

        duplicate_dir = (
            OUT_ROOT
            / "duplicate_key_diagnostics"
        )
        duplicate_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        save_csv(
            duplicated_rows,
            duplicate_dir
            / (
                f"{input_file.stem}"
                "_duplicated_KEYS.csv"
            ),
        )

        raise ValueError(
            f"{input_file.name} 中存在 "
            f"{duplicate_key_count} 个重复KEY；"
            "已保存重复记录，停止计算以避免重复计数。"
        )

    dataset_name = dataset_name_from_file(
        input_file,
        dataframe,
    )

    out_dir = (
        OUT_ROOT
        / dataset_name
    )
    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    dataframe[
        "Pred_Type"
    ] = extract_predicted_type(
        dataframe["Pred_Subtype"]
    )

    # -------------------------------------------------------------------------
    # 标签结构诊断
    # -------------------------------------------------------------------------

    true_subtype_prefix = (
        extract_predicted_type(
            dataframe["Subtype"]
        )
    )

    true_prefix_match = (
        true_subtype_prefix
        == dataframe["Type"]
    )

    prefix_mismatch_df = (
        dataframe.loc[
            ~true_prefix_match
        ]
        .copy()
    )

    prefix_mismatch_df[
        "Subtype_Type_prefix"
    ] = true_subtype_prefix.loc[
        ~true_prefix_match
    ]

    save_csv(
        prefix_mismatch_df,
        out_dir
        / "true_subtype_type_prefix_mismatches.csv",
    )

    # =========================================================================
    # A. ARG / nonARG 二分类
    # =========================================================================

    dataframe[
        "True_ARG_binary"
    ] = np.where(
        dataframe["Type"].eq(
            NONARG_LABEL
        ),
        NONARG_LABEL,
        "ARG",
    )

    dataframe[
        "Pred_ARG_binary"
    ] = np.where(
        dataframe["Pred_Type"].eq(
            NONARG_LABEL
        ),
        NONARG_LABEL,
        "ARG",
    )

    (
        binary_vertical,
        binary_wide,
        binary_per_class,
    ) = make_binary_metrics(
        dataframe[
            "True_ARG_binary"
        ],
        dataframe[
            "Pred_ARG_binary"
        ],
        dataset_name=dataset_name,
    )

    binary_cm_array = confusion_matrix(
        dataframe[
            "True_ARG_binary"
        ],
        dataframe[
            "Pred_ARG_binary"
        ],
        labels=[
            NONARG_LABEL,
            "ARG",
        ],
    )

    binary_cm = pd.DataFrame(
        binary_cm_array,
        index=[
            "true_nonARG",
            "true_ARG",
        ],
        columns=[
            "pred_nonARG",
            "pred_ARG",
        ],
    )

    # =========================================================================
    # B. FunTrans风格 Type：
    #    全部样本，nonARG作为正式Type类别
    # =========================================================================

    true_type_labels = ordered_labels(
        dataframe["Type"]
    )

    (
        type_vertical,
        type_wide,
    ) = make_multiclass_overall_metrics(
        dataframe["Type"],
        dataframe["Pred_Type"],
        dataset_name=dataset_name,
        level_name=(
            "Type_FunTrans_all_samples"
        ),
        true_label_space=(
            true_type_labels
        ),
    )

    type_per_class = (
        make_per_class_metrics(
            dataframe["Type"],
            dataframe["Pred_Type"],
            labels=true_type_labels,
            dataset_name=dataset_name,
            level_name=(
                "Type_FunTrans_all_samples"
            ),
        )
    )

    type_all_labels_for_matrix = (
        ordered_labels(
            list(
                dataframe["Type"]
            )
            + list(
                dataframe["Pred_Type"]
            )
        )
    )

    type_cm_array = confusion_matrix(
        dataframe["Type"],
        dataframe["Pred_Type"],
        labels=(
            type_all_labels_for_matrix
        ),
    )

    type_cm = pd.DataFrame(
        type_cm_array,
        index=[
            f"true_{label}"
            for label
            in type_all_labels_for_matrix
        ],
        columns=[
            f"pred_{label}"
            for label
            in type_all_labels_for_matrix
        ],
    )

    type_sparse_confusion = (
        make_sparse_confusion(
            dataframe["Type"],
            dataframe["Pred_Type"],
            dataset_name=dataset_name,
            level_name=(
                "Type_FunTrans_all_samples"
            ),
        )
    )

    type_top_errors = (
        make_top_error_pairs(
            type_sparse_confusion
        )
    )

    type_outside_mask = (
        ~dataframe["Pred_Type"]
        .isin(
            true_type_labels
        )
    )

    type_outside_df = (
        dataframe.loc[
            type_outside_mask
        ]
        .copy()
    )

    # =========================================================================
    # C. FunRep风格 Subtype：
    #    只在真实ARG样本上计算
    # =========================================================================

    subtype_eval_df = (
        dataframe.loc[
            ~dataframe["Type"]
            .eq(
                NONARG_LABEL
            )
        ]
        .copy()
    )

    if subtype_eval_df.empty:
        raise ValueError(
            f"{input_file.name} 中没有真实ARG样本，"
            "无法进行FunRep风格Subtype评估。"
        )

    true_subtype_labels = (
        ordered_labels(
            subtype_eval_df[
                "Subtype"
            ]
        )
    )

    (
        subtype_vertical,
        subtype_wide,
    ) = make_multiclass_overall_metrics(
        subtype_eval_df[
            "Subtype"
        ],
        subtype_eval_df[
            "Pred_Subtype"
        ],
        dataset_name=dataset_name,
        level_name=(
            "Subtype_FunRep_true_ARG_only"
        ),
        true_label_space=(
            true_subtype_labels
        ),
    )

    subtype_per_class = (
        make_per_class_metrics(
            subtype_eval_df[
                "Subtype"
            ],
            subtype_eval_df[
                "Pred_Subtype"
            ],
            labels=(
                true_subtype_labels
            ),
            dataset_name=dataset_name,
            level_name=(
                "Subtype_FunRep_true_ARG_only"
            ),
        )
    )

    subtype_sparse_confusion = (
        make_sparse_confusion(
            subtype_eval_df[
                "Subtype"
            ],
            subtype_eval_df[
                "Pred_Subtype"
            ],
            dataset_name=dataset_name,
            level_name=(
                "Subtype_FunRep_true_ARG_only"
            ),
        )
    )

    subtype_top_errors = (
        make_top_error_pairs(
            subtype_sparse_confusion
        )
    )

    subtype_outside_mask = (
        ~subtype_eval_df[
            "Pred_Subtype"
        ]
        .isin(
            true_subtype_labels
        )
    )

    subtype_outside_df = (
        subtype_eval_df.loc[
            subtype_outside_mask
        ]
        .copy()
    )

    subtype_predicted_nonarg_df = (
        subtype_eval_df.loc[
            subtype_eval_df[
                "Pred_Type"
            ].eq(
                NONARG_LABEL
            )
        ]
        .copy()
    )

    # =========================================================================
    # D. 正确性明细
    # =========================================================================

    dataframe[
        "Binary_correct"
    ] = (
        dataframe[
            "True_ARG_binary"
        ]
        == dataframe[
            "Pred_ARG_binary"
        ]
    )

    dataframe[
        "Type_correct"
    ] = (
        dataframe["Type"]
        == dataframe["Pred_Type"]
    )

    dataframe[
        "Subtype_correct_end_to_end"
    ] = (
        dataframe["Subtype"]
        == dataframe["Pred_Subtype"]
    )

    subtype_eval_df[
        "Subtype_correct_FunRep"
    ] = (
        subtype_eval_df[
            "Subtype"
        ]
        == subtype_eval_df[
            "Pred_Subtype"
        ]
    )

    wrong_type_df = (
        dataframe.loc[
            ~dataframe[
                "Type_correct"
            ]
        ]
        .copy()
    )

    wrong_subtype_df = (
        subtype_eval_df.loc[
            ~subtype_eval_df[
                "Subtype_correct_FunRep"
            ]
        ]
        .copy()
    )

    # =========================================================================
    # E. FunGeneTyper风格主结果
    # =========================================================================

    binary_main = {
        "dataset": dataset_name,
        "level": "ARG_nonARG",
        "ACC": float(
            binary_wide["ACC"].iloc[0]
        ),
        "Precision": float(
            binary_wide[
                "ARG_precision"
            ].iloc[0]
        ),
        "Recall": float(
            binary_wide[
                "ARG_recall"
            ].iloc[0]
        ),
        "F1": float(
            binary_wide[
                "ARG_f1"
            ].iloc[0]
        ),
        "MCC": float(
            binary_wide["MCC"].iloc[0]
        ),
        "precision_recall_f1_definition": (
            "ARG positive class"
        ),
    }

    type_main = {
        "dataset": dataset_name,
        "level": "Type_FunTrans_all_samples",
        "ACC": float(
            type_wide["ACC"].iloc[0]
        ),
        "Precision": float(
            type_wide[
                "macro_precision"
            ].iloc[0]
        ),
        "Recall": float(
            type_wide[
                "macro_recall"
            ].iloc[0]
        ),
        "F1": float(
            type_wide[
                "macro_f1"
            ].iloc[0]
        ),
        "MCC": float(
            type_wide["MCC"].iloc[0]
        ),
        "precision_recall_f1_definition": (
            "Macro average across all true Types, including nonARG"
        ),
    }

    subtype_main = {
        "dataset": dataset_name,
        "level": "Subtype_FunRep_true_ARG_only",
        "ACC": float(
            subtype_wide["ACC"].iloc[0]
        ),
        "Precision": float(
            subtype_wide[
                "macro_precision"
            ].iloc[0]
        ),
        "Recall": float(
            subtype_wide[
                "macro_recall"
            ].iloc[0]
        ),
        "F1": float(
            subtype_wide[
                "macro_f1"
            ].iloc[0]
        ),
        "MCC": float(
            subtype_wide["MCC"].iloc[0]
        ),
        "precision_recall_f1_definition": (
            "Macro average across true ARG Subtypes only"
        ),
    }

    main_long_df = pd.DataFrame([
        binary_main,
        type_main,
        subtype_main,
    ])

    main_wide_df = pd.DataFrame([{
        "dataset": dataset_name,

        "ARG_nonARG_ACC": (
            binary_main["ACC"]
        ),
        "ARG_nonARG_ARG_Precision": (
            binary_main["Precision"]
        ),
        "ARG_nonARG_ARG_Recall": (
            binary_main["Recall"]
        ),
        "ARG_nonARG_ARG_F1": (
            binary_main["F1"]
        ),
        "ARG_nonARG_MCC": (
            binary_main["MCC"]
        ),

        "Type_ACC": (
            type_main["ACC"]
        ),
        "Type_Macro_Precision": (
            type_main["Precision"]
        ),
        "Type_Macro_Recall": (
            type_main["Recall"]
        ),
        "Type_Macro_F1": (
            type_main["F1"]
        ),
        "Type_MCC": (
            type_main["MCC"]
        ),

        "Subtype_ARG_only_ACC": (
            subtype_main["ACC"]
        ),
        "Subtype_ARG_only_Macro_Precision": (
            subtype_main["Precision"]
        ),
        "Subtype_ARG_only_Macro_Recall": (
            subtype_main["Recall"]
        ),
        "Subtype_ARG_only_Macro_F1": (
            subtype_main["F1"]
        ),
        "Subtype_ARG_only_MCC": (
            subtype_main["MCC"]
        ),
    }])

    all_metrics_vertical = pd.concat(
        [
            binary_vertical,
            type_vertical,
            subtype_vertical,
        ],
        ignore_index=True,
    )

    all_metrics_wide = pd.concat(
        [
            binary_wide,
            type_wide,
            subtype_wide,
        ],
        ignore_index=True,
        sort=False,
    )

    # =========================================================================
    # F. 单数据集输出
    # =========================================================================

    save_csv(
        main_wide_df,
        out_dir
        / "fungenetyper_main_metrics_wide.csv",
    )

    save_csv(
        main_long_df,
        out_dir
        / "fungenetyper_main_metrics_long.csv",
    )

    save_csv(
        all_metrics_vertical,
        out_dir
        / "all_metrics_vertical.csv",
    )

    save_csv(
        all_metrics_wide,
        out_dir
        / "all_metrics_wide.csv",
    )

    save_csv(
        binary_vertical,
        out_dir
        / "ARG_nonARG_metrics_vertical.csv",
    )

    save_csv(
        binary_wide,
        out_dir
        / "ARG_nonARG_metrics_wide.csv",
    )

    save_csv(
        binary_per_class,
        out_dir
        / "ARG_nonARG_per_class_metrics.csv",
    )

    save_csv(
        binary_cm,
        out_dir
        / "ARG_nonARG_confusion_matrix.csv",
        index=True,
    )

    save_csv(
        type_vertical,
        out_dir
        / "type_FunTrans_metrics_vertical.csv",
    )

    save_csv(
        type_wide,
        out_dir
        / "type_FunTrans_metrics_wide.csv",
    )

    save_csv(
        type_per_class,
        out_dir
        / "type_FunTrans_per_class_all_true_types.csv",
    )

    save_csv(
        type_cm,
        out_dir
        / "type_FunTrans_confusion_matrix_all_observed_labels.csv",
        index=True,
    )

    save_csv(
        type_sparse_confusion,
        out_dir
        / "type_FunTrans_confusion_sparse.csv",
    )

    save_csv(
        type_top_errors,
        out_dir
        / "type_FunTrans_top100_misclassification_pairs.csv",
    )

    save_csv(
        type_outside_df,
        out_dir
        / "type_predictions_outside_true_label_space.csv",
    )

    save_csv(
        subtype_vertical,
        out_dir
        / "subtype_FunRep_ARG_only_metrics_vertical.csv",
    )

    save_csv(
        subtype_wide,
        out_dir
        / "subtype_FunRep_ARG_only_metrics_wide.csv",
    )

    save_csv(
        subtype_per_class,
        out_dir
        / "subtype_FunRep_ARG_only_per_class.csv",
    )

    save_csv(
        subtype_sparse_confusion,
        out_dir
        / "subtype_FunRep_ARG_only_confusion_sparse.csv",
    )

    save_csv(
        subtype_top_errors,
        out_dir
        / "subtype_FunRep_ARG_only_top100_misclassification_pairs.csv",
    )

    save_csv(
        subtype_outside_df,
        out_dir
        / "subtype_predictions_outside_true_ARG_subtype_space.csv",
    )

    save_csv(
        subtype_predicted_nonarg_df,
        out_dir
        / "true_ARG_predicted_as_nonARG_in_subtype_evaluation.csv",
    )

    save_csv(
        dataframe,
        out_dir
        / "all_predictions_with_derived_labels_and_correctness.csv",
    )

    save_csv(
        subtype_eval_df,
        out_dir
        / "subtype_FunRep_ARG_only_prediction_details.csv",
    )

    save_csv(
        wrong_type_df,
        out_dir
        / "wrong_type_predictions.csv",
    )

    save_csv(
        wrong_subtype_df,
        out_dir
        / "wrong_subtype_predictions_true_ARG_only.csv",
    )

    save_csv(
        type_per_class,
        TYPE_REPORT_DIR
        / (
            f"{dataset_name}"
            "_type_FunTrans_per_class.csv"
        ),
    )

    save_csv(
        subtype_per_class,
        SUBTYPE_REPORT_DIR
        / (
            f"{dataset_name}"
            "_subtype_FunRep_ARG_only_per_class.csv"
        ),
    )

    matching_summary = {
        "dataset": dataset_name,
        "input_file": input_file.name,
        "all_rows": len(dataframe),
        "unique_KEYs": (
            dataframe["KEY"].nunique()
        ),
        "duplicate_KEY_count": (
            duplicate_key_count
        ),

        "true_ARG_rows_for_Subtype": (
            len(subtype_eval_df)
        ),
        "true_nonARG_rows_excluded_from_Subtype": int(
            dataframe["Type"]
            .eq(NONARG_LABEL)
            .sum()
        ),

        "true_type_count_including_nonARG": (
            len(true_type_labels)
        ),
        "predicted_type_count": (
            dataframe["Pred_Type"]
            .nunique()
        ),
        "type_predictions_outside_true_label_space": (
            len(type_outside_df)
        ),

        "true_ARG_subtype_count": (
            len(true_subtype_labels)
        ),
        "predicted_subtype_count_within_true_ARG_rows": (
            subtype_eval_df[
                "Pred_Subtype"
            ].nunique()
        ),
        "subtype_predictions_outside_true_ARG_subtype_space": (
            len(subtype_outside_df)
        ),
        "true_ARG_predicted_as_nonARG_count": (
            len(
                subtype_predicted_nonarg_df
            )
        ),

        "true_subtype_type_prefix_mismatch_count": (
            len(prefix_mismatch_df)
        ),

        "Type_micro_f1_minus_ACC": float(
            type_wide[
                "micro_f1"
            ].iloc[0]
            - type_wide[
                "ACC"
            ].iloc[0]
        ),
        "Subtype_micro_f1_minus_ACC": float(
            subtype_wide[
                "micro_f1"
            ].iloc[0]
            - subtype_wide[
                "ACC"
            ].iloc[0]
        ),
    }

    matching_summary_df = pd.DataFrame([
        matching_summary
    ])

    save_csv(
        matching_summary_df,
        out_dir
        / "dataset_summary.csv",
    )

    return {
        "dataset": dataset_name,

        "main_wide": main_wide_df,
        "main_long": main_long_df,

        "all_metrics_vertical": (
            all_metrics_vertical
        ),
        "all_metrics_wide": (
            all_metrics_wide
        ),

        "binary_vertical": (
            binary_vertical
        ),
        "binary_wide": (
            binary_wide
        ),
        "binary_per_class": (
            binary_per_class
        ),

        "type_vertical": (
            type_vertical
        ),
        "type_wide": (
            type_wide
        ),
        "type_per_class": (
            type_per_class
        ),

        "subtype_vertical": (
            subtype_vertical
        ),
        "subtype_wide": (
            subtype_wide
        ),
        "subtype_per_class": (
            subtype_per_class
        ),

        "matching_summary": (
            matching_summary_df
        ),

        "type_top_errors": (
            type_top_errors
        ),
        "subtype_top_errors": (
            subtype_top_errors
        ),
    }


# =============================================================================
# 5. 批量运行
# =============================================================================

def main() -> None:
    input_files = sorted(
        [
            path
            for path
            in SCRIPT_DIR.glob(
                INPUT_PATTERN
            )
            if OUT_ROOT
            not in path.parents
        ],
        key=lambda path: natural_sort_key(
            path.name
        ),
    )

    if not input_files:
        raise FileNotFoundError(
            f"当前目录没有找到："
            f"{INPUT_PATTERN}"
        )

    print("=" * 100)
    print(
        "ARGScope batch evaluation: "
        "FunGeneTyper-style metrics"
    )
    print(
        "Type = FunTrans-style, all samples including nonARG"
    )
    print(
        "Subtype = FunRep-style, true ARG samples only"
    )
    print(
        "Main multiclass metrics = Accuracy + Macro P/R/F1"
    )
    print(
        "Weighted and Micro metrics are retained as supplementary outputs"
    )
    print("Input directory:", SCRIPT_DIR)
    print("Output directory:", OUT_ROOT)
    print("=" * 100)

    print(
        f"Found {len(input_files)} prediction files:"
    )

    for input_file in input_files:
        print(
            "  ",
            input_file.name,
        )

    all_main_wide = []
    all_main_long = []

    all_metrics_vertical = []
    all_metrics_wide = []

    all_binary_vertical = []
    all_binary_wide = []
    all_binary_per_class = []

    all_type_vertical = []
    all_type_wide = []
    all_type_per_class = []

    all_subtype_vertical = []
    all_subtype_wide = []
    all_subtype_per_class = []

    all_matching_summary = []
    all_type_top_errors = []
    all_subtype_top_errors = []

    for index, input_file in enumerate(
        input_files,
        start=1,
    ):
        print(
            "\n"
            + "=" * 100
        )
        print(
            f"[{index}/{len(input_files)}] "
            f"Processing: {input_file.name}"
        )
        print(
            "=" * 100
        )

        try:
            result = evaluate_one_file(
                input_file
            )

            all_main_wide.append(
                result["main_wide"]
            )
            all_main_long.append(
                result["main_long"]
            )

            all_metrics_vertical.append(
                result[
                    "all_metrics_vertical"
                ]
            )
            all_metrics_wide.append(
                result[
                    "all_metrics_wide"
                ]
            )

            all_binary_vertical.append(
                result[
                    "binary_vertical"
                ]
            )
            all_binary_wide.append(
                result[
                    "binary_wide"
                ]
            )
            all_binary_per_class.append(
                result[
                    "binary_per_class"
                ]
            )

            all_type_vertical.append(
                result[
                    "type_vertical"
                ]
            )
            all_type_wide.append(
                result[
                    "type_wide"
                ]
            )
            all_type_per_class.append(
                result[
                    "type_per_class"
                ]
            )

            all_subtype_vertical.append(
                result[
                    "subtype_vertical"
                ]
            )
            all_subtype_wide.append(
                result[
                    "subtype_wide"
                ]
            )
            all_subtype_per_class.append(
                result[
                    "subtype_per_class"
                ]
            )

            all_matching_summary.append(
                result[
                    "matching_summary"
                ]
            )
            all_type_top_errors.append(
                result[
                    "type_top_errors"
                ]
            )
            all_subtype_top_errors.append(
                result[
                    "subtype_top_errors"
                ]
            )

            main_row = result[
                "main_wide"
            ].iloc[0]

            print(
                "Type FunTrans-style: ",
                f"ACC={main_row['Type_ACC']:.4f}, ",
                f"Macro-P={main_row['Type_Macro_Precision']:.4f}, ",
                f"Macro-R={main_row['Type_Macro_Recall']:.4f}, ",
                f"Macro-F1={main_row['Type_Macro_F1']:.4f}, ",
                f"MCC={main_row['Type_MCC']:.4f}",
                sep="",
            )

            print(
                "Subtype FunRep-style: ",
                f"ACC={main_row['Subtype_ARG_only_ACC']:.4f}, ",
                f"Macro-P={main_row['Subtype_ARG_only_Macro_Precision']:.4f}, ",
                f"Macro-R={main_row['Subtype_ARG_only_Macro_Recall']:.4f}, ",
                f"Macro-F1={main_row['Subtype_ARG_only_Macro_F1']:.4f}, ",
                f"MCC={main_row['Subtype_ARG_only_MCC']:.4f}",
                sep="",
            )

        except Exception as error:
            error_dir = (
                OUT_ROOT
                / "errors"
            )
            error_dir.mkdir(
                parents=True,
                exist_ok=True,
            )

            error_file = (
                error_dir
                / (
                    f"{input_file.stem}"
                    "_ERROR.txt"
                )
            )

            error_file.write_text(
                f"Input file: {input_file}\n"
                f"Error: {error}\n",
                encoding="utf-8",
            )

            print(
                "ERROR:",
                error,
            )
            print(
                "Saved:",
                error_file,
            )

    if not all_main_wide:
        raise RuntimeError(
            "没有任何数据集成功完成计算，"
            "请检查输出目录中的 errors 文件夹。"
        )

    batch_main_wide = pd.concat(
        all_main_wide,
        ignore_index=True,
    )

    batch_main_long = pd.concat(
        all_main_long,
        ignore_index=True,
    )

    batch_all_metrics_vertical = pd.concat(
        all_metrics_vertical,
        ignore_index=True,
    )

    batch_all_metrics_wide = pd.concat(
        all_metrics_wide,
        ignore_index=True,
        sort=False,
    )

    batch_binary_vertical = pd.concat(
        all_binary_vertical,
        ignore_index=True,
    )

    batch_binary_wide = pd.concat(
        all_binary_wide,
        ignore_index=True,
    )

    batch_binary_per_class = pd.concat(
        all_binary_per_class,
        ignore_index=True,
    )

    batch_type_vertical = pd.concat(
        all_type_vertical,
        ignore_index=True,
    )

    batch_type_wide = pd.concat(
        all_type_wide,
        ignore_index=True,
    )

    batch_type_per_class = pd.concat(
        all_type_per_class,
        ignore_index=True,
    )

    batch_subtype_vertical = pd.concat(
        all_subtype_vertical,
        ignore_index=True,
    )

    batch_subtype_wide = pd.concat(
        all_subtype_wide,
        ignore_index=True,
    )

    batch_subtype_per_class = pd.concat(
        all_subtype_per_class,
        ignore_index=True,
    )

    batch_matching_summary = pd.concat(
        all_matching_summary,
        ignore_index=True,
    )

    batch_type_top_errors = pd.concat(
        all_type_top_errors,
        ignore_index=True,
    )

    batch_subtype_top_errors = pd.concat(
        all_subtype_top_errors,
        ignore_index=True,
    )

    save_csv(
        batch_main_wide,
        OUT_ROOT
        / "batch_fungenetyper_main_metrics_wide.csv",
    )

    save_csv(
        batch_main_long,
        OUT_ROOT
        / "batch_fungenetyper_main_metrics_long.csv",
    )

    save_csv(
        batch_all_metrics_vertical,
        OUT_ROOT
        / "batch_all_metrics_vertical.csv",
    )

    save_csv(
        batch_all_metrics_wide,
        OUT_ROOT
        / "batch_all_metrics_wide.csv",
    )

    save_csv(
        batch_binary_vertical,
        OUT_ROOT
        / "batch_ARG_nonARG_metrics_vertical.csv",
    )

    save_csv(
        batch_binary_wide,
        OUT_ROOT
        / "batch_ARG_nonARG_metrics_wide.csv",
    )

    save_csv(
        batch_binary_per_class,
        OUT_ROOT
        / "batch_ARG_nonARG_per_class_metrics.csv",
    )

    save_csv(
        batch_type_vertical,
        OUT_ROOT
        / "batch_type_FunTrans_metrics_vertical.csv",
    )

    save_csv(
        batch_type_wide,
        OUT_ROOT
        / "batch_type_FunTrans_metrics_wide.csv",
    )

    save_csv(
        batch_type_per_class,
        OUT_ROOT
        / "batch_type_per_class_all_true_types.csv",
    )

    save_csv(
        batch_subtype_vertical,
        OUT_ROOT
        / "batch_subtype_FunRep_ARG_only_metrics_vertical.csv",
    )

    save_csv(
        batch_subtype_wide,
        OUT_ROOT
        / "batch_subtype_FunRep_ARG_only_metrics_wide.csv",
    )

    save_csv(
        batch_subtype_per_class,
        OUT_ROOT
        / "batch_subtype_per_class_true_ARG_only.csv",
    )

    save_csv(
        batch_matching_summary,
        OUT_ROOT
        / "batch_matching_summary.csv",
    )

    save_csv(
        batch_type_top_errors,
        OUT_ROOT
        / "batch_type_top100_misclassification_pairs.csv",
    )

    save_csv(
        batch_subtype_top_errors,
        OUT_ROOT
        / "batch_subtype_top100_misclassification_pairs_true_ARG_only.csv",
    )

    print(
        "\n"
        + "=" * 100
    )
    print(
        "Batch evaluation completed."
    )
    print(
        "=" * 100
    )
    print(
        "Successful datasets:",
        len(batch_main_wide),
    )
    print(
        "Output root:",
        OUT_ROOT,
    )

    print(
        "\nFunGeneTyper-style main metrics:"
    )
    print(
        round_float_columns(
            batch_main_wide
        ).to_string(
            index=False
        )
    )

    print(
        "\nKey files:"
    )
    print(
        OUT_ROOT
        / "batch_fungenetyper_main_metrics_wide.csv"
    )
    print(
        OUT_ROOT
        / "batch_fungenetyper_main_metrics_long.csv"
    )
    print(
        OUT_ROOT
        / "batch_all_metrics_wide.csv"
    )
    print(
        OUT_ROOT
        / "batch_type_FunTrans_metrics_wide.csv"
    )
    print(
        OUT_ROOT
        / "batch_subtype_FunRep_ARG_only_metrics_wide.csv"
    )
    print(
        OUT_ROOT
        / "batch_type_per_class_all_true_types.csv"
    )
    print(
        OUT_ROOT
        / "batch_subtype_per_class_true_ARG_only.csv"
    )
    print(
        OUT_ROOT
        / "batch_matching_summary.csv"
    )


if __name__ == "__main__":
    main()
