@echo off
setlocal
set "UMAP_PYTHON=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%UMAP_PYTHON%" (
    echo Cannot find the configured Python interpreter. Edit UMAP_PYTHON in this file.
    pause
    exit /b 1
)
"%UMAP_PYTHON%" -X utf8 -B -u "%~dp0plot_epoch_type_umap.py" %*
if errorlevel 1 (
    echo UMAP plotting failed. Please keep the error message above.
) else (
    echo UMAP figures and code are in this folder.
)
pause
endlocal
