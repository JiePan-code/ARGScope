"""Validate and package authored figures after manual visual review."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import shutil
import zipfile
import plot_vf_bgc_full_length as plots
import numpy as np
import pandas as pd
from PIL import Image


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--visual-reviewed',action='store_true',required=True)
    parser.parse_args()
    files=[]
    for domain in ['VF','BGC']:
        data=plots.read_domain(domain)
        folder=plots.WORK/domain
        audit_path=folder/'verification.json'
        audit=json.loads(audit_path.read_text(encoding='utf-8'))
        metrics=pd.read_csv(folder/'plot_data'/'overall_metrics.csv')
        np.testing.assert_allclose(metrics[plots.METRICS],data['main'][plots.METRICS],atol=1e-12,rtol=0)
        for mod,model in data['models'].items():
            cm=pd.read_csv(folder/'plot_data'/f'{mod}_type_confusion_counts.csv',index_col=0)
            np.testing.assert_array_equal(cm.to_numpy(),model['cm'])
            fractions=pd.read_csv(folder/'plot_data'/f'{mod}_type_confusion_proportions.csv',index_col=0)
            np.testing.assert_allclose(fractions.sum(axis=1),1,atol=1e-12,rtol=0)
            for source in model['features']:
                coords=folder/'plot_data'/'umap'/f'{mod}_{source.stem}_umap.csv'
                frame=pd.read_csv(coords,keep_default_na=False)
                assert frame.id.is_unique and set(frame.id)==set(model['positive'].id)
                assert set(frame.Type)==set(data['labels'])
                assert np.isfinite(frame[['UMAP1','UMAP2']].to_numpy()).all()
                params=json.loads(coords.with_suffix('.json').read_text(encoding='utf-8'))
                assert params['configuration']['source_sha256']==plots.digest(source)
        pngs=sorted(folder.rglob('*.png'))
        assert len(pngs)==13,(domain,len(pngs))
        for png in pngs:
            with Image.open(png) as im:
                size=im.size
                assert min(size)>900,(png,size)
                assert all(abs(d-300)<.1 for d in im.info['dpi'])
                im.verify()
            for suffix in ['.png','.pdf','.svg']:
                target=png.with_suffix(suffix)
                assert target.stat().st_size>1000
                if suffix=='.pdf':
                    with target.open('rb') as stream: assert stream.read(4)==b'%PDF'
                files.append({'Domain':domain,'File':str(target.relative_to(plots.WORK)),
                              'SHA256':plots.digest(target),'Bytes':target.stat().st_size})
        audit.update({'all_averages_independently_recomputed':True,
                      'all_exported_confusion_matrices_match':True,
                      'all_exported_umap_ids_and_source_hashes_match':True,
                      'figure_count':len(pngs),'png_dpi':300,
                      'visual_review':'passed: main composites, heatmaps, subtype metrics and all epoch panels inspected. No overlapping row labels or titles in final render.',
                      'libraries':{p:importlib.metadata.version(p) for p in
                        ['torch','scikit-learn','umap-learn','numpy','pandas','matplotlib']}})
        audit_path.write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
        print(f'VERIFIED {domain}: {len(pngs)} figures, all metric averages and plotting-data checks passed',flush=True)
    pd.DataFrame(files).to_csv(plots.WORK/'figure_checksums.csv',index=False,encoding='utf-8-sig')
    code=plots.WORK/'code'
    code.mkdir(exist_ok=True)
    shutil.copy2(plots.HERE/'plot_vf_bgc_full_length.py',code/'plot_vf_bgc_full_length.py')
    shutil.copy2(plots.HERE/'vf_bgc_figures_README.md',plots.WORK/'README.md')
    paper=plots.PAPER
    paper.mkdir(parents=True,exist_ok=True)
    for domain in ['VF','BGC']:
        shutil.copytree(plots.WORK/domain,paper/domain,dirs_exist_ok=True)
        dataset_destination=plots.SPECS[domain]['root']/'论文组图_20260921'
        shutil.copytree(plots.WORK/domain,dataset_destination,dirs_exist_ok=True)
        shutil.copy2(plots.WORK/'README.md',dataset_destination/'README.md')
        shutil.copytree(code,dataset_destination/'code',dirs_exist_ok=True)
        print(f'DATASET_COPY {dataset_destination}',flush=True)
    shutil.copytree(code,paper/'code',dirs_exist_ok=True)
    for name in ['README.md','figure_checksums.csv']:
        shutil.copy2(plots.WORK/name,paper/name)
    previews=paper/'previews'
    previews.mkdir(exist_ok=True)
    for domain in ['VF','BGC']:
        name=f'{domain}_AA_NT_full_length_composite_preview.png'
        shutil.copy2(plots.WORK/name,previews/name)
    archive=paper/'VF_BGC_full_length_figures_20260921.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for source in sorted(paper.rglob('*')):
            if source.is_file() and source!=archive:
                z.write(source,source.relative_to(paper))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    for item in files:
        copied=paper/item['File']
        assert plots.digest(copied)==item['SHA256']
    print(f'DELIVERED {paper}',flush=True)
    print(f'ARCHIVE {archive} ({archive.stat().st_size:,} bytes)',flush=True)


if __name__=='__main__':
    main()
