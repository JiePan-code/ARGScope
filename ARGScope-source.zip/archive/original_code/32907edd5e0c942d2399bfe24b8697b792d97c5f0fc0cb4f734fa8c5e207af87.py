import pandas as pd
from tqdm import tqdm

# ==========================================================
# 文件路径
# ==========================================================
EMBEDDING1_TXT = "dna_90nt_5parts_embedding.txt"
EMBEDDING2_TXT = "protein_30aa_embed_1280.txt"
LABEL_FILE = "1. 数据IDARG_nonARG_table_5x.csv"

OUTPUT_EMB1_CSV = "3.60p_ARG_DNA_with_label.csv"
OUTPUT_EMB2_CSV = "2.30p_ARG_protein_with_label.csv"

TXT_SEP = r"\s+"


# ==========================================================
# 🚀 更快读取（带进度）
# ==========================================================
def load_embedding_txt_fast(txt_file):
    print(f"\nLoading {txt_file} ...")

    # 先读第一行确定列数
    with open(txt_file, "r") as f:
        first_line = f.readline()
    n_cols = len(first_line.strip().split())

    # 分块读取（关键提速）
    chunks = []
    chunk_size = 200000

    for chunk in tqdm(
        pd.read_csv(
            txt_file,
            sep=TXT_SEP,
            header=None,
            chunksize=chunk_size,
            engine="c"
        ),
        desc=f"Reading {txt_file}"
    ):
        chunks.append(chunk)

    df = pd.concat(chunks, ignore_index=True)

    if df.shape[1] < 2:
        raise ValueError(f"{txt_file} 读取失败")

    # 重命名列
    df.columns = ["id"] + [f"emb_{i}" for i in range(1, df.shape[1])]

    # 清洗 id
    df["id"] = df["id"].astype(str).str.strip().str.replace(">", "", regex=False)

    # 转 float（一次性）
    emb_cols = df.columns[1:]
    df[emb_cols] = df[emb_cols].astype("float32")

    print(f"{txt_file} loaded: {df.shape}")

    return df


# ==========================================================
# label（轻量）
# ==========================================================
def load_label_file(label_file):
    df = pd.read_csv(
        label_file,
        usecols=["id", "Type", "Subtype"]
    )
    df["id"] = df["id"].astype(str).str.strip()
    return df


# ==========================================================
# 🚀 超快 merge（O(n)）
# ==========================================================
def fast_merge(emb_df, label_df, output_file):

    print(f"\nMerging → {output_file}")

    # dict 查找（最快）
    type_map = dict(zip(label_df["id"], label_df["Type"]))
    subtype_map = dict(zip(label_df["id"], label_df["Subtype"]))

    # 🚀 这里不要 tqdm（否则慢10倍）
    emb_df["Type"] = emb_df["id"].map(type_map)
    emb_df["Subtype"] = emb_df["id"].map(subtype_map)

    # 列顺序
    emb_cols = [c for c in emb_df.columns if c.startswith("emb_")]
    emb_df = emb_df[["id", "Type", "Subtype"] + emb_cols]

    emb_df.to_csv(output_file, index=False)

    matched = emb_df["Type"].notna().sum()
    print(f"Saved: {output_file}")
    print(f"Matched: {matched} / {len(emb_df)}")


# ==========================================================
# 主程序（带进度）
# ==========================================================
def main():
    print("===== START =====")

    emb1_df = load_embedding_txt_fast(EMBEDDING1_TXT)
    emb2_df = load_embedding_txt_fast(EMBEDDING2_TXT)

    label_df = load_label_file(LABEL_FILE)

    fast_merge(emb1_df, label_df, OUTPUT_EMB1_CSV)
    fast_merge(emb2_df, label_df, OUTPUT_EMB2_CSV)

    print("===== DONE =====")


if __name__ == "__main__":
    main()