#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import glob
import math
import pandas as pd
import matplotlib.pyplot as plt

# 如果没安装：
# pip install matplotlib-venn
from matplotlib_venn import venn2


# =========================================================
# 路径设置：按你的实际路径修改
# =========================================================

# =========================================================
# 路径设置
# 当前 VN图.py 就放在 ARG110_D02_pred 目录下
# 因此自动使用脚本所在目录作为 BASE_DIR
# =========================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

PRED_ROOT = os.path.join(
    BASE_DIR,
    "ARG_predict_result"
)

BLAST_ROOT = os.path.join(
    BASE_DIR,
    "BLASTN_current_ARGScope_labelspace"
)

OUT_DIR = os.path.join(
    BASE_DIR,
    "venn_ARG110_vs_currentScope"
)

os.makedirs(OUT_DIR, exist_ok=True)


# 路径检查
print("=" * 90)
print("Path check")
print("=" * 90)
print("BASE_DIR   :", BASE_DIR)
print("PRED_ROOT  :", PRED_ROOT)
print("BLAST_ROOT :", BLAST_ROOT)
print("OUT_DIR    :", OUT_DIR)
print()

if not os.path.isdir(PRED_ROOT):
    raise FileNotFoundError(
        f"ARG prediction directory not found:\n{PRED_ROOT}"
    )

if not os.path.isdir(BLAST_ROOT):
    raise FileNotFoundError(
        f"BLAST directory not found:\n{BLAST_ROOT}"
    )


# =========================================================
# 可选：如果你想固定 9 个数据集，就写死
# 否则可以自动识别
# =========================================================

FIXED_SAMPLES = [
    "argbert_1",
    "argbert_2",
    "argbert_3",
    "argscope_1",
    "argscope_2",
    "argscope_3",
    "argscope_4",
    "argscope_5",
    "argscope_6",
]


def natural_key(s):
    """
    自然排序：argbert_2 < argbert_10
    """
    return [int(text) if text.isdigit() else text.lower()
            for text in re.split(r'(\d+)', s)]


def discover_samples(pred_root, blast_root, fixed_samples=None):
    """
    自动发现同时存在于两个目录中的样品名
    """
    pred_samples = set(
        d for d in os.listdir(pred_root)
        if os.path.isdir(os.path.join(pred_root, d))
    )
    blast_samples = set(
        d for d in os.listdir(blast_root)
        if os.path.isdir(os.path.join(blast_root, d))
    )

    common = pred_samples & blast_samples

    if fixed_samples is not None:
        samples = [s for s in fixed_samples if s in common]
    else:
        samples = sorted(common, key=natural_key)

    return samples


def load_predicted_arg_ids(sample_dir):
    """
    从 chunk_*_pred.csv.gz / .csv 中读取 predicted_ARG == 1 的 read_id
    支持一个数据集下多个 chunk 文件，最后取并集
    """
    patterns = [
        os.path.join(sample_dir, "chunk_*_pred.csv.gz"),
        os.path.join(sample_dir, "chunk_*_pred.csv"),
    ]

    files = []
    for p in patterns:
        files.extend(glob.glob(p))

    files = sorted(files, key=natural_key)

    if not files:
        raise FileNotFoundError(f"No prediction files found in: {sample_dir}")

    all_ids = set()

    for fp in files:
        print(f"  [Pred] reading: {fp}")
        if fp.endswith(".gz"):
            df = pd.read_csv(fp, compression="gzip", usecols=["read_id", "predicted_ARG"])
        else:
            df = pd.read_csv(fp, usecols=["read_id", "predicted_ARG"])

        # predicted_ARG 可能是 0/1，也可能是字符串
        ids = set(
            df.loc[pd.to_numeric(df["predicted_ARG"], errors="coerce") == 1, "read_id"]
            .astype(str)
            .tolist()
        )
        all_ids |= ids

    return all_ids


def load_blast_ids(sample_dir, sample_name):
    """
    从 *_current_scope_all_hits.tsv 读取 qseqid
    默认优先找：
        {sample_name}_current_scope_all_hits.tsv
    如果没有，就 fallback 到任意 *_current_scope_all_hits.tsv
    """
    preferred = os.path.join(sample_dir, f"{sample_name}_current_scope_all_hits.tsv")
    if os.path.exists(preferred):
        files = [preferred]
    else:
        files = sorted(
            glob.glob(os.path.join(sample_dir, "*_current_scope_all_hits.tsv")),
            key=natural_key
        )

    if not files:
        raise FileNotFoundError(f"No BLAST all_hits file found in: {sample_dir}")

    all_ids = set()

    for fp in files:
        print(f"  [BLAST] reading: {fp}")
        df = pd.read_csv(fp, sep="\t")

        # 如果存在 current_scope_status，就只保留 in_scope
        if "current_scope_status" in df.columns:
            df = df[df["current_scope_status"].astype(str).str.lower() == "in_scope"]

        ids = set(df["qseqid"].astype(str).tolist())
        all_ids |= ids

    return all_ids


def plot_one_venn(sample_name, set_pred, set_blast, out_png):
    """
    画单个样品的 2-set Venn 图
    """
    plt.figure(figsize=(6, 6))
    v = venn2(
        subsets=(set_pred, set_blast),
        set_labels=("ARG110 predicted ARG", "BLASTN current scope hits")
    )

    plt.title(
        f"{sample_name}\n"
        f"Intersection of predicted ARG reads and current-scope BLAST hits",
        fontsize=12
    )

    # 可选：美化字体大小
    for text in plt.gca().texts:
        text.set_fontsize(11)

    plt.tight_layout()
    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.close()


def plot_panel_venn(summary_records, out_png):
    """
    画 3x3 总图
    """
    n = len(summary_records)
    ncols = 3
    nrows = math.ceil(n / ncols)

    fig, axes = plt.subplots(nrows, ncols, figsize=(6 * ncols, 5.5 * nrows))
    axes = axes.flatten()

    for ax in axes[n:]:
        ax.axis("off")

    for ax, rec in zip(axes, summary_records):
        sample = rec["sample"]
        a_only = rec["pred_only"]
        b_only = rec["blast_only"]
        inter = rec["intersection"]

        venn2(
            subsets=(a_only, b_only, inter),
            set_labels=("ARG110", "BLAST"),
            ax=ax
        )
        ax.set_title(sample, fontsize=12)

    plt.suptitle("ARG110 vs BLASTN current ARGScope labelspace (9 datasets)", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.close()


def main():
    print("=" * 90)
    print("Draw Venn diagrams: ARG110 predictions vs BLASTN current ARGScope labelspace")
    print("=" * 90)
    print(f"BASE_DIR   : {BASE_DIR}")
    print(f"PRED_ROOT  : {PRED_ROOT}")
    print(f"BLAST_ROOT : {BLAST_ROOT}")
    print(f"OUT_DIR    : {OUT_DIR}")
    print()

    samples = discover_samples(PRED_ROOT, BLAST_ROOT, fixed_samples=FIXED_SAMPLES)

    if not samples:
        raise RuntimeError("No matched sample folders found between prediction and BLAST roots.")

    print("Samples to process:")
    for s in samples:
        print("  -", s)
    print()

    summary_records = []

    for sample in samples:
        print("-" * 90)
        print(f"Processing: {sample}")

        pred_dir = os.path.join(PRED_ROOT, sample)
        blast_dir = os.path.join(BLAST_ROOT, sample)

        pred_ids = load_predicted_arg_ids(pred_dir)
        blast_ids = load_blast_ids(blast_dir, sample)

        inter = pred_ids & blast_ids
        pred_only = pred_ids - blast_ids
        blast_only = blast_ids - pred_ids
        union = pred_ids | blast_ids

        rec = {
            "sample": sample,
            "pred_arg_reads": len(pred_ids),
            "blast_hit_reads": len(blast_ids),
            "intersection": len(inter),
            "pred_only": len(pred_only),
            "blast_only": len(blast_only),
            "union": len(union),
            "jaccard": len(inter) / len(union) if len(union) > 0 else 0.0,
            "overlap_pred_fraction": len(inter) / len(pred_ids) if len(pred_ids) > 0 else 0.0,
            "overlap_blast_fraction": len(inter) / len(blast_ids) if len(blast_ids) > 0 else 0.0,
        }
        summary_records.append(rec)

        print(f"  ARG110 predicted ARG reads : {rec['pred_arg_reads']}")
        print(f"  BLAST hit reads            : {rec['blast_hit_reads']}")
        print(f"  Intersection               : {rec['intersection']}")
        print(f"  ARG110 only                : {rec['pred_only']}")
        print(f"  BLAST only                 : {rec['blast_only']}")
        print(f"  Jaccard                    : {rec['jaccard']:.4f}")
        print(f"  Overlap / ARG110           : {rec['overlap_pred_fraction']:.4f}")
        print(f"  Overlap / BLAST            : {rec['overlap_blast_fraction']:.4f}")

        one_png = os.path.join(OUT_DIR, f"{sample}_venn.png")
        plot_one_venn(sample, pred_ids, blast_ids, one_png)
        print(f"  Saved: {one_png}")
        print()

    # summary csv
    df_summary = pd.DataFrame(summary_records)
    df_summary = df_summary.sort_values("sample", key=lambda x: x.map(natural_key))
    summary_csv = os.path.join(OUT_DIR, "venn_summary_9datasets.csv")
    df_summary.to_csv(summary_csv, index=False, encoding="utf-8-sig")

    # 3x3 panel
    panel_png = os.path.join(OUT_DIR, "venn_9datasets_panel.png")
    plot_panel_venn(summary_records, panel_png)

    print("=" * 90)
    print("Done.")
    print(f"Summary CSV : {summary_csv}")
    print(f"Panel Figure: {panel_png}")
    print("=" * 90)


if __name__ == "__main__":
    main()