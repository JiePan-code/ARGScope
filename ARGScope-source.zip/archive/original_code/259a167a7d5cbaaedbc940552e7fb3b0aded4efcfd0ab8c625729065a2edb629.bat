@echo off
setlocal
set "ARGPRECPY=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%ARGPRECPY%" (
  echo Python was not found. Edit ARGPRECPY in this launcher.
  pause
  exit /b 1
)
"%ARGPRECPY%" -X utf8 -B -u "%~dp0plot_precision_comparison.py"
if errorlevel 1 (
  echo Rendering failed. See the message above.
  pause
  exit /b 1
)
echo Done. See render_status.json for the latest output folder.
pause
