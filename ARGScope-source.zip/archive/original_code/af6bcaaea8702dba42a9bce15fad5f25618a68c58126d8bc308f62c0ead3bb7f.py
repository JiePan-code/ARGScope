#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DNA Top subtype misclassification pairs
=======================================

DNA version using the same final adjustable plotting logic as Protein.

Main features
-------------
1. Keep ALL subtype-pair text; no abbreviation and no truncation
2. Long labels are wrapped instead of shortened
3. Left labels are slightly rotated
4. Dedicated left label panel + right plotting panel
5. Plot-body width and height can be adjusted independently
6. PNG / PDF / SVG export with transparent background
7. PNG export at 600 dpi
8. Final canvas remains 9.15 cm × 7.80 cm unless changed manually

Expected CSV columns
--------------------
true_subtype
predicted_subtype
true_type
predicted_type
"""

from __future__ import annotations

from pathlib import Path
import re
import textwrap

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm


# =============================================================================
# 1. Paths
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# None = automatically detect a suitable CSV in the same directory.
# You can also set it explicitly, for example:
# INPUT_CSV = SCRIPT_DIR / "DNA_test_sequence_predictions.csv"
INPUT_CSV = None

OUTDIR = SCRIPT_DIR / "top_subtype_misclassification_pairs_DNA"
OUTDIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 2. Required columns
# =============================================================================

TRUE_SUBTYPE_COL = "true_subtype"
PRED_SUBTYPE_COL = "predicted_subtype"
TRUE_TYPE_COL = "true_type"
PRED_TYPE_COL = "predicted_type"

EXCLUDE_TRUE_NONARG = True


# =============================================================================
# 3. Plot settings
# =============================================================================

TOP_N = 20

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

DPI = 600
SAVE_PDF = True
SAVE_SVG = True
TRANSPARENT_EXPORT = True

# ---------------------------------------------------------------------------
# Final canvas size
# ---------------------------------------------------------------------------

FIG_WIDTH_CM = 9.15
FIG_HEIGHT_CM = 7.80

FIG_WIDTH_IN = FIG_WIDTH_CM / 2.54
FIG_HEIGHT_IN = FIG_HEIGHT_CM / 2.54

# ---------------------------------------------------------------------------
# Fonts
# ---------------------------------------------------------------------------

FONT_FAMILY = "Arial"

TITLE_SIZE = 9.0
AXIS_LABEL_SIZE = 8.0
X_TICK_SIZE = 6.5
Y_LABEL_SIZE = 4.9
LEGEND_SIZE = 5.8
ANNOT_SIZE = 5.5

# ---------------------------------------------------------------------------
# IMPORTANT: control the width of the plot body here
# ---------------------------------------------------------------------------
#
# Larger BAR_PANEL_RATIO  -> wider bar-chart body
# Larger LABEL_PANEL_RATIO -> wider left text area
#
# Recommended current setting:
# left labels = 1.90
# bar body    = 1.35
#
LABEL_PANEL_RATIO = 1.90
BAR_PANEL_RATIO = 1.35

# Space between the left label panel and the bar-chart body
PANEL_WSPACE = 0.015

# ---------------------------------------------------------------------------
# IMPORTANT: control the height of the plot body here
# ---------------------------------------------------------------------------
#
# Smaller PLOT_BOTTOM -> plot extends farther downward
# Larger PLOT_TOP     -> plot extends farther upward
#
PLOT_LEFT = 0.02
PLOT_RIGHT = 0.995
PLOT_BOTTOM = 0.06
PLOT_TOP = 0.995

# ---------------------------------------------------------------------------
# Vertical usage of the bar-chart body
# ---------------------------------------------------------------------------
#
# This reserves empty rows at the bottom for the legend.
# Smaller value -> bars occupy more vertical space.
#
LEGEND_RESERVED_ROWS = 3.0

# ---------------------------------------------------------------------------
# Left text
# ---------------------------------------------------------------------------

# Preserve every character; only wrap long labels.
WRAP_WIDTH = 30

# Slight rotation of the left-side labels
LABEL_ROTATION = 10

# Right edge of text inside the label panel
LABEL_X = 0.992

# ---------------------------------------------------------------------------
# Bars / colors
# ---------------------------------------------------------------------------

COLOR_TYPE_CORRECT = "#13A38B"
COLOR_TYPE_INCORRECT = "#E76F51"

BAR_EDGE = "#333333"
BAR_LINEWIDTH = 0.45
BAR_HEIGHT = 0.62

GRID_COLOR = "#D8D8D8"

SHOW_TITLE = False
TITLE_TEXT = "Top 20 subtype misclassification pairs"


# =============================================================================
# 4. Fonts / style
# =============================================================================

def configure_fonts() -> None:
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            FONT_FAMILY,
            "DejaVu Sans",
            "Liberation Sans",
        ],
        "font.size": X_TICK_SIZE,
        "axes.titlesize": TITLE_SIZE,
        "axes.labelsize": AXIS_LABEL_SIZE,
        "xtick.labelsize": X_TICK_SIZE,
        "ytick.labelsize": X_TICK_SIZE,
        "legend.fontsize": LEGEND_SIZE,

        # Keep fonts editable in vector outputs
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "axes.unicode_minus": False,

        # Transparent export
        "savefig.facecolor": "none",
        "savefig.edgecolor": "none",
    })


def report_font_status() -> None:
    try:
        path = fm.findfont(FONT_FAMILY, fallback_to_default=False)
        print(f"[FONT] Arial detected: {path}")
    except Exception:
        print("[FONT WARNING] Arial not found. Using fallback sans-serif font.")


# =============================================================================
# 5. Input discovery
# =============================================================================

def resolve_input_csv() -> Path:
    required = {
        TRUE_SUBTYPE_COL,
        PRED_SUBTYPE_COL,
        TRUE_TYPE_COL,
        PRED_TYPE_COL,
    }

    if INPUT_CSV is not None:
        path = Path(INPUT_CSV)

        if not path.is_absolute():
            path = SCRIPT_DIR / path

        if not path.is_file():
            raise FileNotFoundError(
                f"Cannot find configured input CSV: {path}"
            )

        return path

    candidates = []

    for path in sorted(SCRIPT_DIR.glob("*.csv")):
        try:
            header = pd.read_csv(path, nrows=0)
        except Exception:
            continue

        if required.issubset(set(header.columns)):
            candidates.append(path)

    if len(candidates) == 1:
        return candidates[0]

    preferred = [
        path
        for path in candidates
        if "test" in path.name.lower()
        and "prediction" in path.name.lower()
    ]

    if len(preferred) == 1:
        return preferred[0]

    if not candidates:
        raise FileNotFoundError(
            "No suitable CSV was found in the script folder.\n"
            "Required columns:\n"
            f"  - {TRUE_SUBTYPE_COL}\n"
            f"  - {PRED_SUBTYPE_COL}\n"
            f"  - {TRUE_TYPE_COL}\n"
            f"  - {PRED_TYPE_COL}"
        )

    raise RuntimeError(
        "Multiple suitable CSV files were found. "
        "Set INPUT_CSV explicitly.\n"
        + "\n".join(f"  - {p.name}" for p in candidates)
    )


# =============================================================================
# 6. Helpers
# =============================================================================

def clean_text(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).strip()


def normalize_nonarg(text: str) -> bool:
    key = re.sub(
        r"[\s_\-]+",
        "",
        str(text).strip().lower(),
    )
    return key in {"nonarg", "nonargs"}


def split_subtype_label(label: str):
    """
    If subtype is stored as:
        type__subtype

    return:
        type, subtype

    Otherwise keep the full original text as subtype.
    """
    text = clean_text(label)

    if "__" in text:
        left, right = text.split("__", 1)
        return left, right

    return "", text


def full_pair_label(
    true_subtype: str,
    pred_subtype: str,
) -> str:
    """
    Keep the complete subtype names.
    No abbreviation.
    No truncation.
    """
    _, true_name = split_subtype_label(true_subtype)
    _, pred_name = split_subtype_label(pred_subtype)

    return f"{true_name} → {pred_name}"


def wrap_pair_label(
    text: str,
    width: int = WRAP_WIDTH,
) -> str:
    """
    Preserve ALL text.

    Long labels are wrapped to multiple lines.
    No characters are deleted.
    """
    text = clean_text(text)

    if " → " in text:
        left, right = text.split(" → ", 1)

        left_wrapped = textwrap.fill(
            left,
            width=width,
            break_long_words=False,
            break_on_hyphens=False,
        )

        right_wrapped = textwrap.fill(
            right,
            width=width,
            break_long_words=False,
            break_on_hyphens=False,
        )

        return f"{left_wrapped} → {right_wrapped}"

    return textwrap.fill(
        text,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
    )


# =============================================================================
# 7. Analysis
# =============================================================================

def prepare_data(df: pd.DataFrame) -> pd.DataFrame:

    required = [
        TRUE_SUBTYPE_COL,
        PRED_SUBTYPE_COL,
        TRUE_TYPE_COL,
        PRED_TYPE_COL,
    ]

    missing = [
        col for col in required
        if col not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Missing required columns: {missing}"
        )

    work = df[required].copy()

    for col in required:
        work[col] = work[col].map(clean_text)

    work = work[
        (work[TRUE_SUBTYPE_COL] != "")
        & (work[PRED_SUBTYPE_COL] != "")
        & (work[TRUE_TYPE_COL] != "")
        & (work[PRED_TYPE_COL] != "")
    ].copy()

    if EXCLUDE_TRUE_NONARG:
        work = work[
            ~work[TRUE_TYPE_COL].map(normalize_nonarg)
        ].copy()

    work["subtype_correct"] = (
        work[TRUE_SUBTYPE_COL]
        == work[PRED_SUBTYPE_COL]
    )

    work["type_correct"] = (
        work[TRUE_TYPE_COL]
        == work[PRED_TYPE_COL]
    )

    errors = work[
        ~work["subtype_correct"]
    ].copy()

    if errors.empty:
        raise RuntimeError(
            "No subtype misclassification records found."
        )

    errors["pair_key"] = (
        errors[TRUE_SUBTYPE_COL]
        + "|||"
        + errors[PRED_SUBTYPE_COL]
    )

    errors["pair_label"] = [
        full_pair_label(t, p)
        for t, p in zip(
            errors[TRUE_SUBTYPE_COL],
            errors[PRED_SUBTYPE_COL],
        )
    ]

    errors["pair_label_wrapped"] = [
        wrap_pair_label(x)
        for x in errors["pair_label"]
    ]

    return errors


def summarize_pairs(
    errors: pd.DataFrame,
) -> pd.DataFrame:

    rows = []

    for pair_key, group in errors.groupby(
        "pair_key",
        sort=False,
    ):

        total = int(len(group))
        type_correct_n = int(
            group["type_correct"].sum()
        )
        type_incorrect_n = int(
            total - type_correct_n
        )

        pred_type_counts = (
            group[PRED_TYPE_COL]
            .value_counts()
        )

        pred_type_mode = (
            pred_type_counts.index[0]
            if len(pred_type_counts) > 0
            else ""
        )

        rows.append({
            "pair_key": pair_key,
            "pair_label": group["pair_label"].iloc[0],
            "pair_label_wrapped": group["pair_label_wrapped"].iloc[0],
            "true_subtype": group[TRUE_SUBTYPE_COL].iloc[0],
            "predicted_subtype": group[PRED_SUBTYPE_COL].iloc[0],
            "true_type": group[TRUE_TYPE_COL].iloc[0],
            "predicted_type_mode": pred_type_mode,

            "n_total": total,
            "n_type_correct": type_correct_n,
            "n_type_incorrect": type_incorrect_n,

            "pct_type_correct": (
                100.0 * type_correct_n / total
            ),
            "pct_type_incorrect": (
                100.0 * type_incorrect_n / total
            ),
        })

    summary = pd.DataFrame(rows)

    summary = summary.sort_values(
        [
            "n_total",
            "n_type_correct",
            "pair_label",
        ],
        ascending=[
            False,
            False,
            True,
        ],
        kind="mergesort",
    ).reset_index(drop=True)

    if len(summary) > TOP_N:
        summary = summary.iloc[
            :TOP_N
        ].copy()

    # Reverse for top-to-bottom display
    summary = (
        summary
        .iloc[::-1]
        .reset_index(drop=True)
    )

    return summary


# =============================================================================
# 8. Plot
# =============================================================================

def plot_top_pairs(
    summary: pd.DataFrame,
) -> None:

    n_rows = len(summary)

    # ---------------------------------------------------------------------
    # Figure
    # ---------------------------------------------------------------------

    fig = plt.figure(
        figsize=(
            FIG_WIDTH_IN,
            FIG_HEIGHT_IN,
        ),
        facecolor="none",
    )

    # ---------------------------------------------------------------------
    # Two-panel layout
    #
    # Left  = complete subtype text
    # Right = actual bar-chart body
    #
    # BAR_PANEL_RATIO controls the BODY WIDTH.
    # ---------------------------------------------------------------------

    gs = fig.add_gridspec(
        nrows=1,
        ncols=2,
        width_ratios=[
            LABEL_PANEL_RATIO,
            BAR_PANEL_RATIO,
        ],
        wspace=PANEL_WSPACE,
    )

    ax_label = fig.add_subplot(
        gs[0, 0]
    )

    ax = fig.add_subplot(
        gs[0, 1],
        sharey=ax_label,
    )

    # Transparent backgrounds
    fig.patch.set_alpha(0.0)
    ax.patch.set_alpha(0.0)
    ax_label.patch.set_alpha(0.0)

    # ---------------------------------------------------------------------
    # Data
    # ---------------------------------------------------------------------

    y = np.arange(n_rows)

    correct = (
        summary["n_type_correct"]
        .to_numpy(dtype=float)
    )

    incorrect = (
        summary["n_type_incorrect"]
        .to_numpy(dtype=float)
    )

    total = (
        summary["n_total"]
        .to_numpy(dtype=float)
    )

    # ---------------------------------------------------------------------
    # Bars
    # ---------------------------------------------------------------------

    ax.barh(
        y,
        correct,
        color=COLOR_TYPE_CORRECT,
        edgecolor=BAR_EDGE,
        linewidth=BAR_LINEWIDTH,
        height=BAR_HEIGHT,
        label="Subtype wrong, type correct",
        zorder=3,
    )

    ax.barh(
        y,
        incorrect,
        left=correct,
        color=COLOR_TYPE_INCORRECT,
        edgecolor=BAR_EDGE,
        linewidth=BAR_LINEWIDTH,
        height=BAR_HEIGHT,
        label="Subtype wrong, type incorrect",
        zorder=3,
    )

    # ---------------------------------------------------------------------
    # Y axis
    # ---------------------------------------------------------------------

    ax.set_yticks(y)
    ax.set_yticklabels([])

    ax.tick_params(
        axis="y",
        left=False,
        labelleft=False,
    )

    # Smaller LEGEND_RESERVED_ROWS =
    # bars occupy more vertical body area.
    ax.set_ylim(
        -LEGEND_RESERVED_ROWS,
        n_rows - 0.35,
    )

    # ---------------------------------------------------------------------
    # X axis
    # ---------------------------------------------------------------------

    xmax = max(
        1.0,
        float(np.max(total)),
    )

    annotation_pad = max(
        0.24,
        0.08 * xmax,
    )

    legend_reserved_width = max(
        2.4,
        0.58 * xmax,
    )

    ax.set_xlim(
        0,
        xmax
        + annotation_pad
        + legend_reserved_width,
    )

    ax.set_xlabel(
        "Count",
        fontsize=AXIS_LABEL_SIZE,
        labelpad=2,
    )

    # ---------------------------------------------------------------------
    # Optional title
    # ---------------------------------------------------------------------

    if SHOW_TITLE:
        ax.set_title(
            TITLE_TEXT,
            fontsize=TITLE_SIZE,
            pad=6,
        )

    # ---------------------------------------------------------------------
    # Grid / spines
    # ---------------------------------------------------------------------

    ax.xaxis.grid(
        True,
        color=GRID_COLOR,
        linewidth=0.5,
        alpha=0.85,
    )

    ax.set_axisbelow(True)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax.spines["left"].set_linewidth(0.75)
    ax.spines["bottom"].set_linewidth(0.75)

    ax.tick_params(
        axis="x",
        labelsize=X_TICK_SIZE,
        width=0.65,
        length=2.8,
        pad=1.5,
    )

    # ---------------------------------------------------------------------
    # Right-side values
    # ---------------------------------------------------------------------

    for yi, row in summary.iterrows():

        total_n = int(
            row["n_total"]
        )

        pct_correct = float(
            row["pct_type_correct"]
        )

        ax.text(
            row["n_total"]
            + annotation_pad * 0.45,
            yi,
            f"{total_n} ({pct_correct:.1f}%)",

            va="center",
            ha="left",

            fontsize=ANNOT_SIZE,
            color="#333333",

            clip_on=False,
        )

    # ---------------------------------------------------------------------
    # Legend
    # ---------------------------------------------------------------------

    ax.legend(
        loc="lower right",
        bbox_to_anchor=(0.98, 0.01),
        frameon=False,

        fontsize=LEGEND_SIZE,

        borderpad=0.15,
        labelspacing=0.18,

        handlelength=0.95,
        handletextpad=0.40,
    )

    # ---------------------------------------------------------------------
    # Left text panel
    # ---------------------------------------------------------------------

    ax_label.set_xlim(
        0,
        1,
    )

    ax_label.set_ylim(
        -LEGEND_RESERVED_ROWS,
        n_rows - 0.35,
    )

    ax_label.axis("off")

    for yi, label in enumerate(
        summary["pair_label_wrapped"].tolist()
    ):

        ax_label.text(
            LABEL_X,
            yi,
            label,

            ha="right",
            va="center",

            fontsize=Y_LABEL_SIZE,
            color="black",

            # Keep all text
            clip_on=False,

            # Slight rotation
            rotation=LABEL_ROTATION,
            rotation_mode="anchor",

            linespacing=0.95,
        )

    # ---------------------------------------------------------------------
    # IMPORTANT: actual plot-body HEIGHT
    #
    # PLOT_BOTTOM / PLOT_TOP control vertical body size.
    # ---------------------------------------------------------------------

    fig.subplots_adjust(
        left=PLOT_LEFT,
        right=PLOT_RIGHT,
        bottom=PLOT_BOTTOM,
        top=PLOT_TOP,
        wspace=PANEL_WSPACE,
    )

    # ---------------------------------------------------------------------
    # Save
    # ---------------------------------------------------------------------

    base = (
        OUTDIR
        / "DNA_top_subtype_misclassification_pairs_adjustableBody_fullText"
    )

    # PNG: 600 dpi + transparent
    fig.savefig(
        str(base) + ".png",
        dpi=DPI,
        transparent=TRANSPARENT_EXPORT,
    )

    # PDF: transparent vector output
    if SAVE_PDF:
        fig.savefig(
            str(base) + ".pdf",
            transparent=TRANSPARENT_EXPORT,
        )

    # SVG: transparent vector output
    if SAVE_SVG:
        fig.savefig(
            str(base) + ".svg",
            transparent=TRANSPARENT_EXPORT,
        )

    plt.close(fig)


# =============================================================================
# 9. Main
# =============================================================================

def main() -> None:

    configure_fonts()
    report_font_status()

    input_csv = resolve_input_csv()

    print(
        f"[INPUT] {input_csv}"
    )

    print(
        f"[FIGURE SIZE] "
        f"{FIG_WIDTH_CM:.2f} × "
        f"{FIG_HEIGHT_CM:.2f} cm"
    )

    print(
        f"[BODY WIDTH RATIO] "
        f"labels={LABEL_PANEL_RATIO:.2f}, "
        f"bars={BAR_PANEL_RATIO:.2f}"
    )

    print(
        f"[BODY HEIGHT] "
        f"bottom={PLOT_BOTTOM:.3f}, "
        f"top={PLOT_TOP:.3f}"
    )

    df = pd.read_csv(
        input_csv
    )

    errors = prepare_data(
        df
    )

    summary = summarize_pairs(
        errors
    )

    summary.to_csv(
        OUTDIR
        / "DNA_top_subtype_misclassification_pairs_summary_fullText.csv",

        index=False,
        encoding="utf-8-sig",
    )

    plot_top_pairs(
        summary
    )

    print("=" * 84)

    print(
        "DNA Top subtype misclassification pairs "
        "(same plotting logic as final Protein version)"
    )

    print("=" * 84)

    print(
        f"Total subtype-misclassified ARG sequences : "
        f"{len(errors):,}"
    )

    print(
        f"Pairs plotted                             : "
        f"{len(summary)}"
    )

    print(
        f"Output directory                          : "
        f"{OUTDIR}"
    )

    print("\nTop 10 shown pairs:")

    print(
        summary
        .iloc[::-1][
            [
                "pair_label",
                "n_total",
                "n_type_correct",
                "n_type_incorrect",
            ]
        ]
        .head(10)
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
