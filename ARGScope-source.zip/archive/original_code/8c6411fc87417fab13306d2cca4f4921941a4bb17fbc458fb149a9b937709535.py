import pandas as pd
import numpy as np

# =========================
# 1. 读取数据
# =========================
df = pd.read_csv("1.all_fusion_embedding_512_with_label.csv")

print("总样本数:", len(df))
print("Subtype 总数(原始):", df["Subtype"].astype(str).nunique())

# =========================
# 2. 选择特征列（512 维融合特征）
# =========================
feature_cols = [c for c in df.columns if c not in ["id", "Geneid", "Type", "Subtype"]]
print("特征维度(原始列数):", len(feature_cols))

# 让特征列保证是数值（避免读成 object）
df[feature_cols] = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

# 可选：把特征列统一改名为 g0..g511（强烈建议，便于后续脚本读取）
# 如果你不想改列名，把下面 rename 这段注释掉也行，但后续读取要跟着改
if len(feature_cols) == 512:
    new_feature_cols = [f"g{i}" for i in range(512)]
    rename_map = {old: new for old, new in zip(feature_cols, new_feature_cols)}
    df = df.rename(columns=rename_map)
    feature_cols = new_feature_cols
    print("已将特征列重命名为 g0..g511")
else:
    print("警告：特征列不是 512 维，请检查 feature_cols 选择逻辑。")

# =========================
# 3. 不过滤 subtype（全保留）
# =========================
min_count = 1  # ✅ 全保留：subtype 出现 1 次也要 prototype
sub_counts = df["Subtype"].astype(str).value_counts()
valid_subtypes = sub_counts[sub_counts >= min_count].index

df_sub = df[df["Subtype"].astype(str).isin(valid_subtypes)].copy()

print("过滤后 Subtype 数:", df_sub["Subtype"].astype(str).nunique())
print("过滤后样本数:", len(df_sub))

# =========================
# 4. 按 Subtype 计算 prototype（特征均值）和 count
# =========================
df_sub["Subtype"] = df_sub["Subtype"].astype(str)
df_sub["Type"] = df_sub["Type"].astype(str)

grouped = df_sub.groupby("Subtype", sort=False)

proto_matrix = grouped[feature_cols].mean()          # 每个 subtype 的中心向量
counts = grouped.size()                              # 每个 subtype 的样本数
types = grouped["Type"].agg(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else x.iloc[0])

# =========================
# 5. 整合成一个 DataFrame
# =========================
proto_df = proto_matrix.copy()
proto_df.insert(0, "Type", types)
proto_df.insert(1, "Count", counts)

proto_df = proto_df.reset_index()  # 列：Subtype, Type, Count, g0..g511

print("\n示例前几行:")
print(proto_df.head())

print("\nSubtype 原型数量:", len(proto_df))
print("Count=1 的 subtype 数量:", int((proto_df["Count"] == 1).sum()))

# =========================
# 6. 保存为 CSV
# =========================
output_file = "4.subtype_prototypes_512.csv"
proto_df.to_csv(output_file, index=False, encoding="utf-8-sig")
print(f"\n已保存 subtype prototype 到: {output_file}")