#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ONLY assign train/test labels at the ORIGINAL ID level.

This script DOES NOT split:
    - protein FASTA
    - DNA FASTA
    - protein embeddings
    - DNA embeddings

It only reads:
    all_ARG_nonARG_1to1_structure.txt

and produces a canonical train/test assignment table.

Later, protein / DNA / Fusion / Refined / Student pipelines should all
inherit the SAME split by matching SARG.Seq.ID.

Rules
-----
Subtype count = 1:
    all -> train

Subtype count = 2:
    1 train / 1 test

Subtype count >= 3:
    approximately train:test = 2:1

For n >= 3:
    n_test  = (n + 1) // 3
    n_train = n - n_test

Examples:
    3 -> 2 / 1
    4 -> 3 / 1
    5 -> 3 / 2
    6 -> 4 / 2
    7 -> 5 / 2
    8 -> 5 / 3
    9 -> 6 / 3

Output
------
06_original_level_split_ONLY/
    original_train_test_split.csv
    all_ARG_nonARG_1to1_structure_with_split.txt
    subtype_split_summary.csv
    train_ids.txt
    test_ids.txt
    split_QC_summary.txt
"""

from __future__ import annotations

import csv
import hashlib
import random
from collections import Counter, defaultdict
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

STRUCTURE_FILE = (
    SCRIPT_DIR
    / "all_ARG_nonARG_1to1_structure.txt"
)

OUTPUT_DIR = (
    SCRIPT_DIR
    / "06_original_level_split_ONLY"
)

OUT_SPLIT = (
    OUTPUT_DIR
    / "original_train_test_split.csv"
)

OUT_STRUCTURE = (
    OUTPUT_DIR
    / "all_ARG_nonARG_1to1_structure_with_split.txt"
)

OUT_SUBTYPE_SUMMARY = (
    OUTPUT_DIR
    / "subtype_split_summary.csv"
)

OUT_TRAIN_IDS = (
    OUTPUT_DIR
    / "train_ids.txt"
)

OUT_TEST_IDS = (
    OUTPUT_DIR
    / "test_ids.txt"
)

OUT_QC = (
    OUTPUT_DIR
    / "split_QC_summary.txt"
)

GLOBAL_SEED = 20260820


def canonical_id(value):
    text = str(value).strip()
    return text.split()[0] if text else ""


def detect_delimiter(path):
    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        first = handle.readline()

    return "\t" if "\t" in first else ","


def read_table(path):
    delimiter = detect_delimiter(path)

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        reader = csv.DictReader(
            handle,
            delimiter=delimiter,
        )

        if reader.fieldnames is None:
            raise ValueError(
                f"No header: {path}"
            )

        return (
            list(reader.fieldnames),
            list(reader),
        )


def write_csv(path, fields, rows):
    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            extrasaction="ignore",
        )

        writer.writeheader()
        writer.writerows(rows)


def write_tsv(path, fields, rows):
    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            extrasaction="ignore",
            lineterminator="\n",
        )

        writer.writeheader()
        writer.writerows(rows)


def stable_seed(subtype):
    payload = (
        f"{GLOBAL_SEED}|{subtype}"
        .encode("utf-8")
    )

    digest = hashlib.sha256(
        payload
    ).hexdigest()

    return int(
        digest[:16],
        16,
    )


def split_counts(n):
    if n == 1:
        return (
            1,
            0,
            "singleton_all_train",
        )

    if n == 2:
        return (
            1,
            1,
            "doubleton_1train_1test",
        )

    n_test = (
        n + 1
    ) // 3

    n_train = (
        n
        - n_test
    )

    return (
        n_train,
        n_test,
        "n_ge3_approximately_2to1",
    )


def main():
    if not STRUCTURE_FILE.is_file():
        raise FileNotFoundError(
            f"Structure file not found:\n"
            f"{STRUCTURE_FILE}"
        )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("=" * 110)
    print("ORIGINAL-LEVEL TRAIN / TEST ASSIGNMENT ONLY")
    print("=" * 110)
    print("This script does NOT split protein or DNA files.")
    print("It only assigns train/test labels by original SARG.Seq.ID.")
    print()
    print("Rules:")
    print("  subtype n=1  -> train 1 / test 0")
    print("  subtype n=2  -> train 1 / test 1")
    print("  subtype n>=3 -> approximately train:test = 2:1")
    print(f"Global seed    : {GLOBAL_SEED}")

    fields, rows = read_table(
        STRUCTURE_FILE
    )

    required = {
        "SARG.Seq.ID",
        "Type",
        "Subtype",
        "ARG.or.nonARG",
    }

    missing = (
        required
        - set(fields)
    )

    if missing:
        raise ValueError(
            "Structure file missing columns: "
            f"{sorted(missing)}"
        )

    structure_by_id = {}
    original_order = []

    subtype_to_ids = defaultdict(
        list
    )

    for row_number, row in enumerate(
        rows,
        start=2,
    ):
        sid = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        if not sid:
            raise ValueError(
                f"Empty SARG.Seq.ID at row "
                f"{row_number}"
            )

        if sid in structure_by_id:
            raise ValueError(
                f"Duplicate SARG.Seq.ID: {sid}"
            )

        subtype = str(
            row.get(
                "Subtype",
                "",
            )
        ).strip()

        if not subtype:
            raise ValueError(
                f"Empty Subtype for ID: {sid}"
            )

        structure_by_id[
            sid
        ] = row

        original_order.append(
            sid
        )

        subtype_to_ids[
            subtype
        ].append(
            sid
        )

    print()
    print(
        f"Original sequences : {len(original_order):,}"
    )

    print(
        f"Unique subtypes    : {len(subtype_to_ids):,}"
    )

    subtype_size_counts = Counter(
        len(ids)
        for ids
        in subtype_to_ids.values()
    )

    print(
        f"Subtype count=1    : "
        f"{subtype_size_counts.get(1, 0):,}"
    )

    print(
        f"Subtype count=2    : "
        f"{subtype_size_counts.get(2, 0):,}"
    )

    print(
        f"Subtype count>=3   : "
        f"{sum(v for k, v in subtype_size_counts.items() if k >= 3):,}"
    )

    split_by_id = {}

    subtype_summary_rows = []

    for subtype in sorted(
        subtype_to_ids
    ):
        ids = sorted(
            subtype_to_ids[
                subtype
            ]
        )

        total = len(
            ids
        )

        (
            n_train,
            n_test,
            rule_name,
        ) = split_counts(
            total
        )

        rng = random.Random(
            stable_seed(
                subtype
            )
        )

        shuffled = list(
            ids
        )

        rng.shuffle(
            shuffled
        )

        train_ids = shuffled[
            :n_train
        ]

        test_ids = shuffled[
            n_train:
        ]

        if len(
            test_ids
        ) != n_test:
            raise RuntimeError(
                f"Internal split error: "
                f"{subtype}"
            )

        for sid in train_ids:
            split_by_id[
                sid
            ] = "train"

        for sid in test_ids:
            split_by_id[
                sid
            ] = "test"

        example_row = structure_by_id[
            ids[
                0
            ]
        ]

        subtype_summary_rows.append(
            {
                "Subtype":
                    subtype,

                "Type":
                    str(
                        example_row.get(
                            "Type",
                            "",
                        )
                    ).strip(),

                "ARG.or.nonARG":
                    str(
                        example_row.get(
                            "ARG.or.nonARG",
                            "",
                        )
                    ).strip(),

                "total_count":
                    total,

                "train_count":
                    n_train,

                "test_count":
                    n_test,

                "split_rule":
                    rule_name,

                "subtype_seed":
                    stable_seed(
                        subtype
                    ),
            }
        )

    if set(
        split_by_id
    ) != set(
        original_order
    ):
        raise RuntimeError(
            "Not every original ID received one split."
        )

    train_ids = [
        sid
        for sid
        in original_order
        if split_by_id[
            sid
        ] == "train"
    ]

    test_ids = [
        sid
        for sid
        in original_order
        if split_by_id[
            sid
        ] == "test"
    ]

    split_rows = []

    structure_with_split_rows = []

    for sid in original_order:
        original_row = dict(
            structure_by_id[
                sid
            ]
        )

        split = split_by_id[
            sid
        ]

        split_rows.append(
            {
                "SARG.Seq.ID":
                    sid,

                "Original.ID":
                    str(
                        original_row.get(
                            "Original.ID",
                            sid,
                        )
                    ).strip(),

                "ARG.or.nonARG":
                    str(
                        original_row.get(
                            "ARG.or.nonARG",
                            "",
                        )
                    ).strip(),

                "Type":
                    str(
                        original_row.get(
                            "Type",
                            "",
                        )
                    ).strip(),

                "Subtype":
                    str(
                        original_row.get(
                            "Subtype",
                            "",
                        )
                    ).strip(),

                "split":
                    split,
            }
        )

        original_row[
            "split"
        ] = split

        structure_with_split_rows.append(
            original_row
        )

    write_csv(
        OUT_SPLIT,
        [
            "SARG.Seq.ID",
            "Original.ID",
            "ARG.or.nonARG",
            "Type",
            "Subtype",
            "split",
        ],
        split_rows,
    )

    output_structure_fields = list(
        fields
    )

    if "split" not in output_structure_fields:
        output_structure_fields.append(
            "split"
        )

    write_tsv(
        OUT_STRUCTURE,
        output_structure_fields,
        structure_with_split_rows,
    )

    write_csv(
        OUT_SUBTYPE_SUMMARY,
        [
            "Subtype",
            "Type",
            "ARG.or.nonARG",
            "total_count",
            "train_count",
            "test_count",
            "split_rule",
            "subtype_seed",
        ],
        subtype_summary_rows,
    )

    OUT_TRAIN_IDS.write_text(
        "\n".join(
            train_ids
        )
        + "\n",
        encoding="utf-8",
    )

    OUT_TEST_IDS.write_text(
        "\n".join(
            test_ids
        )
        + "\n",
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # QC
    # ------------------------------------------------------------------

    train_set = set(
        train_ids
    )

    test_set = set(
        test_ids
    )

    original_set = set(
        original_order
    )

    subtype_train = Counter()

    subtype_test = Counter()

    subtype_total = Counter()

    for sid in original_order:
        subtype = str(
            structure_by_id[
                sid
            ][
                "Subtype"
            ]
        ).strip()

        subtype_total[
            subtype
        ] += 1

        if split_by_id[
            sid
        ] == "train":
            subtype_train[
                subtype
            ] += 1

        else:
            subtype_test[
                subtype
            ] += 1

    rule_failures = []

    for subtype, total in subtype_total.items():
        (
            exp_train,
            exp_test,
            _,
        ) = split_counts(
            total
        )

        if (
            subtype_train[
                subtype
            ]
            != exp_train
            or subtype_test[
                subtype
            ]
            != exp_test
        ):
            rule_failures.append(
                subtype
            )

    train_class_counts = Counter(
        str(
            structure_by_id[
                sid
            ][
                "ARG.or.nonARG"
            ]
        ).strip()
        for sid
        in train_ids
    )

    test_class_counts = Counter(
        str(
            structure_by_id[
                sid
            ][
                "ARG.or.nonARG"
            ]
        ).strip()
        for sid
        in test_ids
    )

    checks = {
        "original_total":
            len(
                original_order
            ),

        "train_total":
            len(
                train_ids
            ),

        "test_total":
            len(
                test_ids
            ),

        "train_test_no_overlap":
            len(
                train_set
                & test_set
            )
            == 0,

        "train_test_union_equals_original":
            (
                train_set
                | test_set
            )
            == original_set,

        "all_subtypes_follow_requested_rule":
            len(
                rule_failures
            )
            == 0,

        "subtype_rule_failure_count":
            len(
                rule_failures
            ),

        "train_ARG":
            train_class_counts.get(
                "ARG",
                0,
            ),

        "train_nonARG":
            train_class_counts.get(
                "nonARG",
                0,
            ),

        "test_ARG":
            test_class_counts.get(
                "ARG",
                0,
            ),

        "test_nonARG":
            test_class_counts.get(
                "nonARG",
                0,
            ),
    }

    checks[
        "FINAL_QC_PASS"
    ] = (
        checks[
            "train_test_no_overlap"
        ]
        and checks[
            "train_test_union_equals_original"
        ]
        and checks[
            "all_subtypes_follow_requested_rule"
        ]
    )

    summary_lines = [
        f"GLOBAL_SEED\t{GLOBAL_SEED}",
        "split_unit\toriginal_SARG_Seq_ID",
        "protein_FASTA_split\tFalse",
        "DNA_FASTA_split\tFalse",
        "embedding_split\tFalse",
        "fusion_split\tFalse",
        "singleton_rule\t1_train_0_test",
        "doubleton_rule\t1_train_1_test",
        "n_ge3_rule\tapproximately_2_to_1",
    ]

    for key, value in checks.items():
        summary_lines.append(
            f"{key}\t{value}"
        )

    OUT_QC.write_text(
        "\n".join(
            summary_lines
        )
        + "\n",
        encoding="utf-8",
    )

    print()
    print("=" * 110)
    print("FINAL SPLIT ASSIGNMENT")
    print("=" * 110)

    print(
        f"Train total  : "
        f"{checks['train_total']:,}"
    )

    print(
        f"  ARG        : "
        f"{checks['train_ARG']:,}"
    )

    print(
        f"  nonARG     : "
        f"{checks['train_nonARG']:,}"
    )

    print()

    print(
        f"Test total   : "
        f"{checks['test_total']:,}"
    )

    print(
        f"  ARG        : "
        f"{checks['test_ARG']:,}"
    )

    print(
        f"  nonARG     : "
        f"{checks['test_nonARG']:,}"
    )

    print()

    print(
        f"Train/test overlap = 0      : "
        f"{checks['train_test_no_overlap']}"
    )

    print(
        f"Train+test covers all IDs   : "
        f"{checks['train_test_union_equals_original']}"
    )

    print(
        f"All subtype rules satisfied : "
        f"{checks['all_subtypes_follow_requested_rule']}"
    )

    print(
        f"FINAL_QC_PASS               : "
        f"{checks['FINAL_QC_PASS']}"
    )

    print()
    print(
        "Canonical split file:"
    )

    print(
        OUT_SPLIT
    )

    print()
    print(
        "Use this split column later for protein, DNA, embedding and Fusion."
    )

    if not checks[
        "FINAL_QC_PASS"
    ]:
        raise RuntimeError(
            f"Split QC failed. Inspect:\n"
            f"{OUT_QC}"
        )


if __name__ == "__main__":
    main()
