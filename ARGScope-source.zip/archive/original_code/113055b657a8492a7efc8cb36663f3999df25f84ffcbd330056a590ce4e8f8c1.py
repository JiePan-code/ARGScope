import pandas as pd
import numpy as np
import re
from pathlib import Path


# ==========================================================
# 1. 文件路径
# ==========================================================

EMBEDDING1_TXT = "VF_nonVF_dna_embedding.txt"
EMBEDDING2_TXT = "VF_nonVF_protein_embed_1280.txt"
LABEL_FILE = "vf_nonvf_ID表_clean_unique_subtype_type.csv"

OUTPUT_EMB1_CSV = "1_vfdb_DNA_with_label.csv"
OUTPUT_EMB2_CSV = "2_vfdb_protein_with_label.csv"


# ==========================================================
# 2. label 文件列名
# ==========================================================

LABEL_ID_COL = "id"
LABEL_TYPE_COL = "Type"
LABEL_SUBTYPE_COL = "Subtype"


# ==========================================================
# 3. 基础工具函数
# ==========================================================

def clean_id(x):
    x = str(x).strip()
    x = x.lstrip(">")
    x = x.split()[0]
    return x


def detect_label_columns(label_df):
    """
    兼容：
        id, Type, Subtype
        id, type, subtype
    """
    lower_map = {c.lower(): c for c in label_df.columns}

    if "id" not in lower_map:
        raise ValueError("label 文件缺少 id 列")

    if "type" not in lower_map:
        raise ValueError("label 文件缺少 Type/type 列")

    if "subtype" not in lower_map:
        raise ValueError("label 文件缺少 Subtype/subtype 列")

    return lower_map["id"], lower_map["type"], lower_map["subtype"]


def parse_embedding_line_fast(line):
    """
    快速解析一行 embedding。

    支持：
        id\t0.1\t0.2\t0.3
        id 0.1 0.2 0.3
        id,0.1,0.2,0.3
        id [0.1, 0.2, 0.3]
    """
    line = line.strip()

    if not line:
        return None

    # 找第一个分隔符，前面是 ID，后面全是 embedding 数值
    m = re.search(r"[\t,\s]+", line)

    if m is None:
        return None

    sample_id = clean_id(line[:m.start()])
    value_str = line[m.end():].strip()

    if not value_str:
        return None

    value_str = value_str.replace("[", " ")
    value_str = value_str.replace("]", " ")
    value_str = value_str.replace(",", " ")

    values = np.fromstring(value_str, sep=" ", dtype=np.float32)

    if values.size == 0:
        return "BAD_LINE"

    return sample_id, values


# ==========================================================
# 4. 高速读取 label 文件
# ==========================================================

def load_label_maps(label_file):
    label_file = Path(label_file)

    if not label_file.exists():
        raise FileNotFoundError("找不到 label 文件: {}".format(label_file))

    label_df = pd.read_csv(label_file)

    id_col, type_col, subtype_col = detect_label_columns(label_df)

    label_df = label_df[[id_col, type_col, subtype_col]].copy()
    label_df.columns = ["id", "Type", "Subtype"]

    label_df["id"] = label_df["id"].apply(clean_id)
    label_df["Type"] = label_df["Type"].astype(str).str.strip()
    label_df["Subtype"] = label_df["Subtype"].astype(str).str.strip()

    dup_n = label_df["id"].duplicated().sum()

    if dup_n > 0:
        print("警告: label 文件中发现重复 ID 数量: {}，保留第一次出现的记录。".format(dup_n))
        label_df = label_df.drop_duplicates(subset="id", keep="first")

    type_map = dict(zip(label_df["id"], label_df["Type"]))
    subtype_map = dict(zip(label_df["id"], label_df["Subtype"]))

    print("读取 label 成功:", label_file)
    print("label 样本数:", len(label_df))
    print("label 前 5 个 ID:", label_df["id"].head().tolist())
    print("-" * 60)

    return type_map, subtype_map


# ==========================================================
# 5. 高速读取 embedding 并直接写出 CSV
# ==========================================================

def convert_embedding_to_labeled_csv(txt_file, output_file, type_map, subtype_map):
    """
    读取 embedding txt，并直接输出带 Type / Subtype 的 CSV。
    不再构建完整 merge DataFrame，速度更快、内存更低。
    """
    txt_file = Path(txt_file)

    if not txt_file.exists():
        raise FileNotFoundError("找不到 embedding 文件: {}".format(txt_file))

    ids = []
    feats = []
    dim = None
    bad_lines = []
    duplicate_count = 0
    seen = set()

    print("开始读取 embedding:", txt_file)

    with open(txt_file, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, start=1):
            parsed = parse_embedding_line_fast(line)

            if parsed is None:
                continue

            if parsed == "BAD_LINE":
                if line_num == 1:
                    print("检测到表头或非数值首行，已跳过:", txt_file)
                    continue

                if len(bad_lines) < 5:
                    bad_lines.append((line_num, line[:200]))
                continue

            sample_id, values = parsed

            if sample_id in seen:
                duplicate_count += 1
                continue

            seen.add(sample_id)

            if dim is None:
                dim = values.size
            elif values.size != dim:
                raise ValueError(
                    "{} 第 {} 行 embedding 维度不一致。期望 {}，实际 {}。该行前 200 字符: {}".format(
                        txt_file,
                        line_num,
                        dim,
                        values.size,
                        line[:200]
                    )
                )

            ids.append(sample_id)
            feats.append(values)

            if line_num % 10000 == 0:
                print("已读取行数:", line_num)

    if len(ids) == 0:
        raise ValueError("{} 没有读取到任何有效 embedding。".format(txt_file))

    if duplicate_count > 0:
        print("警告: {} 中发现重复 ID 数量: {}，已保留第一次出现的记录。".format(txt_file, duplicate_count))

    if len(bad_lines) > 0:
        print("警告: 存在无法解析的行，示例:")
        for line_num, content in bad_lines:
            print("第 {} 行: {}".format(line_num, content))

    print("读取完成:", txt_file)
    print("样本数:", len(ids))
    print("embedding 维度:", dim)

    print("开始构建输出 DataFrame...")

    mat = np.vstack(feats).astype(np.float32)

    feature_cols = ["emb_{}".format(i) for i in range(1, dim + 1)]

    out_df = pd.DataFrame(mat, columns=feature_cols)
    out_df.insert(0, "Subtype", [subtype_map.get(x, np.nan) for x in ids])
    out_df.insert(0, "Type", [type_map.get(x, np.nan) for x in ids])
    out_df.insert(0, "id", ids)

    matched_n = out_df["Type"].notna().sum()
    unmatched_n = out_df["Type"].isna().sum()

    print("输出文件:", output_file)
    print("总样本数:", len(out_df))
    print("匹配到 label 的样本数:", matched_n)
    print("未匹配到 label 的样本数:", unmatched_n)

    if unmatched_n > 0:
        print("未匹配到 label 的 ID 示例:")
        print(out_df.loc[out_df["Type"].isna(), "id"].head(10).tolist())

    print("开始保存 CSV...")

    out_df.to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig"
    )

    print("Saved:", output_file)
    print("-" * 60)

    return out_df.shape


# ==========================================================
# 6. 主函数
# ==========================================================

def main():
    print("Loading label file...")
    print("=" * 60)

    type_map, subtype_map = load_label_maps(LABEL_FILE)

    print("Converting embedding files...")
    print("=" * 60)

    shape1 = convert_embedding_to_labeled_csv(
        txt_file=EMBEDDING1_TXT,
        output_file=OUTPUT_EMB1_CSV,
        type_map=type_map,
        subtype_map=subtype_map
    )

    shape2 = convert_embedding_to_labeled_csv(
        txt_file=EMBEDDING2_TXT,
        output_file=OUTPUT_EMB2_CSV,
        type_map=type_map,
        subtype_map=subtype_map
    )

    print("Embedding1 output shape:", shape1)
    print("Embedding2 output shape:", shape2)
    print("Done.")


if __name__ == "__main__":
    main()