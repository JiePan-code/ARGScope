import random
import multiprocessing as mp

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    classification_report,
)


# ==========================================================
# 1. 文件路径
# ==========================================================

FUSION_FILE = "1.all_fusion_embedding_512_with_label.csv"
LONGAA_FILE = "2_BGC_protein_with_label.csv"
TRAIN_SPLIT_FILE = "train_set.csv"
TEST_SPLIT_FILE = "test_set.csv"
PROTO_FILE = "3.all_Refined_embeddings_512.csv"

LABEL_COL = "Subtype"
TYPE_COL = "Type"

KEY_CANDIDATES = [
    "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "KEY"
]


# ==========================================================
# 2. 全局参数
# ==========================================================

SEED = 32
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()

BATCH_SIZE = 256
PRED_BATCH_SIZE = 1024

VAL_RATIO = 0.12
PRINT_EVERY = 5
MIN_DELTA = 1e-5

SAVE_CLASSIFICATION_REPORT = True


# ==========================================================
# 3. Stage 1 参数：BGC vs nonBGC
# ==========================================================

STAGE1_PARAMS = {
    "max_epochs_c": 180,
    "max_epochs_m": 220,
    "lr_c": 3e-4,
    "lr_m": 2e-4,
    "weight_decay": 1e-4,

    "lambda_mse": 0.70,
    "lambda_ce": 2.00,
    "lambda_prior": 0.30,
    "lambda_proto": 0.00,

    "scale": 18.0,

    "gamma": 0.8,
    "label_smoothing": 0.03,
    "class_weight_min": 0.8,
    "class_weight_max": 1.5,

    "early_stop_patience_c": 40,
    "early_stop_patience_m": 45,

    # 以 weighted F1 为主
    "score_precision_w": 0.30,
    "score_recall_w": 0.30,
    "score_f1_w": 0.40,
}


# ==========================================================
# 4. Stage 2 参数：BGC subtype 多分类
# ==========================================================

STAGE2_PARAMS = {
    "max_epochs_c": 220,
    "max_epochs_m": 260,
    "lr_c": 2.5e-4,
    "lr_m": 1.5e-4,
    "weight_decay": 1e-4,

    "lambda_mse": 0.80,
    "lambda_ce": 2.40,
    "lambda_prior": 0.80,
    "lambda_proto": 0.15,

    "scale": 28.0,

    "gamma": 1.2,
    "label_smoothing": 0.04,
    "class_weight_min": 0.6,
    "class_weight_max": 4.0,

    "early_stop_patience_c": 45,
    "early_stop_patience_m": 55,

    # 以 weighted F1 为主
    "score_precision_w": 0.20,
    "score_recall_w": 0.20,
    "score_f1_w": 0.60,
}


# ==========================================================
# 5. 基础函数
# ==========================================================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    if hasattr(torch, "set_float32_matmul_precision"):
        torch.set_float32_matmul_precision("high")


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def make_binary_label(x):
    x = str(x).strip()

    if x.lower() == "nonbgc":
        return "nonBGC"

    return "BGC"


def get_feature_cols(df):
    exclude_cols = {
        "KEY", "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "BinaryLabel",
        "Count"
    }

    return [
        c for c in df.columns
        if c not in exclude_cols and pd.api.types.is_numeric_dtype(df[c])
    ]


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def compute_overall_metrics(y_true, y_pred):
    return {
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(
            y_true, y_pred, average="weighted", zero_division=0
        ),
        "WEIGHTED_RECALL": recall_score(
            y_true, y_pred, average="weighted", zero_division=0
        ),
        "WEIGHTED_F1": f1_score(
            y_true, y_pred, average="weighted", zero_division=0
        ),
        "MACRO_F1": f1_score(
            y_true, y_pred, average="macro", zero_division=0
        ),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "sample_count": int(len(y_true)),
        "class_count": int(len(np.unique(y_true)))
    }


def make_stratified_train_val_split(y, val_ratio=0.12, seed=42):
    rng = np.random.default_rng(seed)
    y = np.asarray(y)

    train_idx = []
    val_idx = []

    for cls in sorted(np.unique(y)):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)

        n = len(idx)

        if n <= 2:
            train_idx.extend(idx.tolist())
            continue

        n_val = max(1, int(round(n * val_ratio)))

        if n_val >= n:
            n_val = n - 1

        val_idx.extend(idx[:n_val].tolist())
        train_idx.extend(idx[n_val:].tolist())

    rng.shuffle(train_idx)
    rng.shuffle(val_idx)

    return np.array(train_idx), np.array(val_idx)


def iter_gpu_batches(*tensors, batch_size=1024, shuffle=True):
    n = tensors[0].shape[0]

    if shuffle:
        idx = torch.randperm(n, device=tensors[0].device)
    else:
        idx = torch.arange(n, device=tensors[0].device)

    for start in range(0, n, batch_size):
        batch_idx = idx[start:start + batch_size]
        yield tuple(t[batch_idx] for t in tensors)


def predict_classifier(classifier, X_gpu, batch_size=4096):
    classifier.eval()

    preds = []
    confs = []

    with torch.no_grad():
        for (xb,) in iter_gpu_batches(X_gpu, batch_size=batch_size, shuffle=False):
            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                prob = torch.softmax(logits, dim=1)
                conf, pred = prob.max(dim=1)

            preds.append(pred.detach().cpu().numpy())
            confs.append(conf.detach().cpu().numpy())

    return np.concatenate(preds), np.concatenate(confs)


def predict_mapper(classifier, mapper, X_gpu, batch_size=4096):
    classifier.eval()
    mapper.eval()

    preds = []
    confs = []

    with torch.no_grad():
        for (xb,) in iter_gpu_batches(X_gpu, batch_size=batch_size, shuffle=False):
            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xb)
                logits = classifier(xf_hat)
                prob = torch.softmax(logits, dim=1)
                conf, pred = prob.max(dim=1)

            preds.append(pred.detach().cpu().numpy())
            confs.append(conf.detach().cpu().numpy())

    return np.concatenate(preds), np.concatenate(confs)


def build_prior_matrix_from_proto(prior_df, label_col, label_encoder):
    if label_col not in prior_df.columns:
        raise ValueError(f"PROTO_FILE 缺少标签列: {label_col}")

    feat_cols = get_feature_cols(prior_df)

    if len(feat_cols) == 0:
        raise ValueError("PROTO_FILE 中没有可用数值特征列")

    tmp = prior_df.copy()
    tmp[feat_cols] = tmp[feat_cols].apply(
        pd.to_numeric,
        errors="coerce"
    ).fillna(0.0)

    grouped = tmp.groupby(label_col)[feat_cols].mean()

    prior_map = {
        str(k): grouped.loc[k].values.astype(np.float32)
        for k in grouped.index
    }

    missing = [
        lab for lab in label_encoder.classes_
        if lab not in prior_map
    ]

    if len(missing) > 0:
        raise ValueError(
            f"PROTO_FILE 缺少这些类别的 prototype: {missing[:10]}"
        )

    matrix = np.stack(
        [prior_map[lab] for lab in label_encoder.classes_],
        axis=0
    ).astype(np.float32)

    return matrix


def build_prior_matrix_from_class_mean(X_fusion_scaled, y, num_classes):
    rows = []

    for c in range(num_classes):
        mask = y == c

        if mask.sum() == 0:
            rows.append(np.zeros(X_fusion_scaled.shape[1], dtype=np.float32))
        else:
            rows.append(X_fusion_scaled[mask].mean(axis=0).astype(np.float32))

    return np.stack(rows, axis=0).astype(np.float32)


def threshold_scan(y_true, y_pred, conf):
    rows = []

    for th in [
        0.50, 0.55, 0.60, 0.65, 0.70,
        0.75, 0.80, 0.85, 0.90, 0.92,
        0.94, 0.95, 0.96, 0.97, 0.98
    ]:
        mask = conf >= th
        kept = int(mask.sum())
        coverage = kept / len(y_true) if len(y_true) > 0 else 0.0

        if kept == 0:
            rows.append({
                "threshold": th,
                "coverage": 0.0,
                "kept_samples": 0,
                "WEIGHTED_PRECISION_kept": 0.0,
                "WEIGHTED_RECALL_kept": 0.0,
                "WEIGHTED_F1_kept": 0.0,
                "MCC_kept": 0.0
            })
            continue

        yt = y_true[mask]
        yp = y_pred[mask]

        rows.append({
            "threshold": th,
            "coverage": coverage,
            "kept_samples": kept,
            "WEIGHTED_PRECISION_kept": precision_score(
                yt, yp, average="weighted", zero_division=0
            ),
            "WEIGHTED_RECALL_kept": recall_score(
                yt, yp, average="weighted", zero_division=0
            ),
            "WEIGHTED_F1_kept": f1_score(
                yt, yp, average="weighted", zero_division=0
            ),
            "MCC_kept": matthews_corrcoef(yt, yp)
        })

    return pd.DataFrame(rows)


# ==========================================================
# 6. Loss 和模型
# ==========================================================

class WeightedFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=1.0, label_smoothing=0.04):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    def forward(self, logits, targets):
        ce_loss = nn.functional.cross_entropy(
            logits,
            targets,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing
        )

        pt = torch.exp(-ce_loss)
        loss = ((1.0 - pt) ** self.gamma) * ce_loss

        return loss.mean()


class FusionPrototypeClassifier(nn.Module):
    def __init__(self, input_dim, proto_dim, num_classes, prototype_init=None, scale=30.0):
        super().__init__()

        self.projector = nn.Sequential(
            nn.Linear(input_dim, 640),
            nn.LayerNorm(640),
            nn.GELU(),
            nn.Dropout(0.14),

            nn.Linear(640, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.14),

            nn.Linear(512, proto_dim),
            nn.LayerNorm(proto_dim)
        )

        if prototype_init is not None:
            self.prototype = nn.Parameter(
                torch.tensor(prototype_init, dtype=torch.float32)
            )
        else:
            self.prototype = nn.Parameter(
                torch.randn(num_classes, proto_dim)
            )

        self.scale = scale

    def forward(self, x, return_embed=False):
        z = self.projector(x)
        z = nn.functional.normalize(z, p=2, dim=1)

        p = nn.functional.normalize(self.prototype, p=2, dim=1)
        logits = self.scale * (z @ p.t())

        if return_embed:
            return z, logits

        return logits


class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.14):
        super().__init__()

        self.block = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(dim, dim),
            nn.LayerNorm(dim)
        )

        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.dropout(self.block(x)))


class LongAAToFusionMapper(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        self.input_proj = nn.Sequential(
            nn.Linear(in_dim, 768),
            nn.LayerNorm(768),
            nn.GELU(),
            nn.Dropout(0.14)
        )

        self.res1 = ResidualBlock(768, dropout=0.14)
        self.res2 = ResidualBlock(768, dropout=0.14)

        self.output_proj = nn.Sequential(
            nn.Linear(768, 640),
            nn.LayerNorm(640),
            nn.GELU(),
            nn.Dropout(0.12),

            nn.Linear(640, out_dim)
        )

    def forward(self, x):
        x = self.input_proj(x)
        x = self.res1(x)
        x = self.res2(x)
        return self.output_proj(x)


class PriorProjector(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        if in_dim == out_dim:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.proj(x)


# ==========================================================
# 7. 单阶段训练函数
# ==========================================================

def train_one_stage(
    stage_name,
    X_fusion,
    X_longaa,
    y_label_str,
    prior_matrix_raw=None,
    params=None
):
    print("=" * 70)
    print(f"{stage_name} | Start training")
    print("=" * 70)

    if params is None:
        raise ValueError("params 不能为空")

    le = LabelEncoder()
    y_all = le.fit_transform(y_label_str.astype(str)).astype(np.int64)

    num_classes = len(le.classes_)

    print(f"{stage_name} classes:", num_classes)
    print(f"{stage_name} class names:", le.classes_)

    scaler_fusion = StandardScaler()
    scaler_longaa = StandardScaler()

    X_fusion_s = scaler_fusion.fit_transform(X_fusion).astype(np.float32)
    X_longaa_s = scaler_longaa.fit_transform(X_longaa).astype(np.float32)

    train_idx, val_idx = make_stratified_train_val_split(
        y_all,
        val_ratio=VAL_RATIO,
        seed=SEED
    )

    Xf_train = X_fusion_s[train_idx]
    Xa_train = X_longaa_s[train_idx]
    y_train = y_all[train_idx]

    Xf_val = X_fusion_s[val_idx]
    Xa_val = X_longaa_s[val_idx]
    y_val = y_all[val_idx]

    if prior_matrix_raw is None:
        prior_matrix = build_prior_matrix_from_class_mean(
            X_fusion_scaled=X_fusion_s,
            y=y_all,
            num_classes=num_classes
        )
    else:
        prior_matrix = prior_matrix_raw.astype(np.float32)

    proto_dim = prior_matrix.shape[1]
    input_dim_fusion = X_fusion_s.shape[1]
    input_dim_longaa = X_longaa_s.shape[1]

    print(f"{stage_name} fusion dim:", input_dim_fusion)
    print(f"{stage_name} longAA dim:", input_dim_longaa)
    print(f"{stage_name} proto dim:", proto_dim)
    print(f"{stage_name} train/val:", len(train_idx), len(val_idx))

    Xf_train_t = torch.tensor(Xf_train, dtype=torch.float32, device=DEVICE)
    Xa_train_t = torch.tensor(Xa_train, dtype=torch.float32, device=DEVICE)
    y_train_t = torch.tensor(y_train, dtype=torch.long, device=DEVICE)

    Xf_val_t = torch.tensor(Xf_val, dtype=torch.float32, device=DEVICE)
    Xa_val_t = torch.tensor(Xa_val, dtype=torch.float32, device=DEVICE)

    prior_tensor = torch.tensor(prior_matrix, dtype=torch.float32, device=DEVICE)

    classifier = FusionPrototypeClassifier(
        input_dim=input_dim_fusion,
        proto_dim=proto_dim,
        num_classes=num_classes,
        prototype_init=prior_matrix,
        scale=params["scale"]
    ).to(DEVICE)

    mapper = LongAAToFusionMapper(
        in_dim=input_dim_longaa,
        out_dim=input_dim_fusion
    ).to(DEVICE)

    prior_proj = PriorProjector(
        in_dim=proto_dim,
        out_dim=proto_dim
    ).to(DEVICE)

    class_counts = np.bincount(y_train, minlength=num_classes).astype(np.float32)

    beta = 0.995
    effective_num = 1.0 - np.power(beta, class_counts)
    class_weights = (1.0 - beta) / (effective_num + 1e-8)

    class_weights = class_weights / class_weights.mean()
    class_weights = np.clip(
        class_weights,
        params["class_weight_min"],
        params["class_weight_max"]
    )

    class_weights = torch.tensor(
        class_weights,
        dtype=torch.float32,
        device=DEVICE
    )

    criterion_ce = WeightedFocalLoss(
        weight=class_weights,
        gamma=params["gamma"],
        label_smoothing=params["label_smoothing"]
    )

    criterion_mse = nn.SmoothL1Loss(beta=0.5)

    optimizer_c = optim.AdamW(
        list(classifier.parameters()) + list(prior_proj.parameters()),
        lr=params["lr_c"],
        weight_decay=params["weight_decay"]
    )

    optimizer_m = optim.AdamW(
        mapper.parameters(),
        lr=params["lr_m"],
        weight_decay=params["weight_decay"]
    )

    scheduler_c = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_c,
        mode="max",
        factor=0.5,
        patience=6
    )

    scheduler_m = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_m,
        mode="max",
        factor=0.5,
        patience=6
    )

    scaler_amp_c = torch.amp.GradScaler("cuda", enabled=USE_AMP)
    scaler_amp_m = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    # ======================================================
    # 7.1 训练 fusion classifier
    # ======================================================

    print(f"\n{stage_name} | Training classifier...")

    best_score_c = -1.0
    best_classifier_state = None
    best_prior_proj_state = None
    no_improve_c = 0

    for epoch in range(1, params["max_epochs_c"] + 1):
        classifier.train()
        prior_proj.train()

        total_loss = 0.0

        for xb, yb in iter_gpu_batches(
            Xf_train_t,
            y_train_t,
            batch_size=BATCH_SIZE,
            shuffle=True
        ):
            optimizer_c.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                loss_ce = criterion_ce(logits, yb)

                prior_proj_mat = prior_proj(prior_tensor)

                proto_now_norm = nn.functional.normalize(
                    classifier.prototype,
                    p=2,
                    dim=1
                )
                proto_ref_norm = nn.functional.normalize(
                    prior_proj_mat,
                    p=2,
                    dim=1
                )

                loss_proto = 1.0 - torch.mean(
                    torch.sum(proto_now_norm * proto_ref_norm, dim=1)
                )

                loss = loss_ce + params["lambda_proto"] * loss_proto

            scaler_amp_c.scale(loss).backward()
            scaler_amp_c.unscale_(optimizer_c)

            torch.nn.utils.clip_grad_norm_(
                list(classifier.parameters()) + list(prior_proj.parameters()),
                1.0
            )

            scaler_amp_c.step(optimizer_c)
            scaler_amp_c.update()

            total_loss += loss.item() * xb.size(0)

        avg_loss = total_loss / Xf_train_t.shape[0]

        y_val_pred_c, _ = predict_classifier(
            classifier,
            Xf_val_t,
            batch_size=PRED_BATCH_SIZE
        )

        val_precision_c = precision_score(
            y_val, y_val_pred_c, average="weighted", zero_division=0
        )
        val_recall_c = recall_score(
            y_val, y_val_pred_c, average="weighted", zero_division=0
        )
        val_f1_c = f1_score(
            y_val, y_val_pred_c, average="weighted", zero_division=0
        )

        val_score_c = (
            params["score_precision_w"] * val_precision_c
            + params["score_recall_w"] * val_recall_c
            + params["score_f1_w"] * val_f1_c
        )

        scheduler_c.step(val_score_c)

        if val_score_c > best_score_c + MIN_DELTA:
            best_score_c = val_score_c
            best_classifier_state = {
                k: v.detach().cpu().clone()
                for k, v in classifier.state_dict().items()
            }
            best_prior_proj_state = {
                k: v.detach().cpu().clone()
                for k, v in prior_proj.state_dict().items()
            }
            no_improve_c = 0
        else:
            no_improve_c += 1

        if epoch % PRINT_EVERY == 0 or epoch == 1:
            lr_now = optimizer_c.param_groups[0]["lr"]
            print(
                f"[{stage_name} Classifier] Epoch {epoch:03d} | "
                f"lr={lr_now:.2e} | loss={avg_loss:.4f} | "
                f"val_precision={val_precision_c:.4f} | "
                f"val_recall={val_recall_c:.4f} | "
                f"val_f1={val_f1_c:.4f}"
            )

        if no_improve_c >= params["early_stop_patience_c"]:
            print(
                f"[{stage_name} Classifier] Early stopping at epoch {epoch}, "
                f"best score={best_score_c:.4f}"
            )
            break

    classifier.load_state_dict(best_classifier_state)
    prior_proj.load_state_dict(best_prior_proj_state)

    classifier = classifier.to(DEVICE)
    prior_proj = prior_proj.to(DEVICE)

    for p in classifier.parameters():
        p.requires_grad = False

    for p in prior_proj.parameters():
        p.requires_grad = False

    classifier.eval()
    prior_proj.eval()

    # ======================================================
    # 7.2 训练 LongAA -> fusion mapper
    # ======================================================

    print(f"\n{stage_name} | Training mapper...")

    best_score_m = -1.0
    best_mapper_state = None
    no_improve_m = 0

    for epoch in range(1, params["max_epochs_m"] + 1):
        mapper.train()

        total_loss = 0.0

        for xa, xf_t, yb in iter_gpu_batches(
            Xa_train_t,
            Xf_train_t,
            y_train_t,
            batch_size=BATCH_SIZE,
            shuffle=True
        ):
            optimizer_m.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xa)

                loss_mse = criterion_mse(xf_hat, xf_t)

                logits = classifier(xf_hat)
                loss_ce = criterion_ce(logits, yb)

                z_hat, _ = classifier(xf_hat, return_embed=True)

                prior_batch = prior_proj(prior_tensor[yb])
                prior_batch = nn.functional.normalize(prior_batch, p=2, dim=1)

                loss_prior = 1.0 - torch.mean(
                    torch.sum(z_hat * prior_batch, dim=1)
                )

                loss = (
                    params["lambda_mse"] * loss_mse
                    + params["lambda_ce"] * loss_ce
                    + params["lambda_prior"] * loss_prior
                )

            scaler_amp_m.scale(loss).backward()
            scaler_amp_m.unscale_(optimizer_m)

            torch.nn.utils.clip_grad_norm_(mapper.parameters(), 1.0)

            scaler_amp_m.step(optimizer_m)
            scaler_amp_m.update()

            total_loss += loss.item() * xa.size(0)

        avg_loss = total_loss / Xa_train_t.shape[0]

        y_val_pred_m, _ = predict_mapper(
            classifier,
            mapper,
            Xa_val_t,
            batch_size=PRED_BATCH_SIZE
        )

        val_precision_m = precision_score(
            y_val, y_val_pred_m, average="weighted", zero_division=0
        )
        val_recall_m = recall_score(
            y_val, y_val_pred_m, average="weighted", zero_division=0
        )
        val_f1_m = f1_score(
            y_val, y_val_pred_m, average="weighted", zero_division=0
        )

        val_score_m = (
            params["score_precision_w"] * val_precision_m
            + params["score_recall_w"] * val_recall_m
            + params["score_f1_w"] * val_f1_m
        )

        scheduler_m.step(val_score_m)

        if val_score_m > best_score_m + MIN_DELTA:
            best_score_m = val_score_m
            best_mapper_state = {
                k: v.detach().cpu().clone()
                for k, v in mapper.state_dict().items()
            }
            no_improve_m = 0
        else:
            no_improve_m += 1

        if epoch % PRINT_EVERY == 0 or epoch == 1:
            lr_now = optimizer_m.param_groups[0]["lr"]
            print(
                f"[{stage_name} Mapper] Epoch {epoch:03d} | "
                f"lr={lr_now:.2e} | loss={avg_loss:.4f} | "
                f"val_precision={val_precision_m:.4f} | "
                f"val_recall={val_recall_m:.4f} | "
                f"val_f1={val_f1_m:.4f}"
            )

        if no_improve_m >= params["early_stop_patience_m"]:
            print(
                f"[{stage_name} Mapper] Early stopping at epoch {epoch}, "
                f"best score={best_score_m:.4f}"
            )
            break

    mapper.load_state_dict(best_mapper_state)
    mapper = mapper.to(DEVICE)
    mapper.eval()

    return {
        "stage_name": stage_name,
        "classifier": classifier,
        "mapper": mapper,
        "prior_proj": prior_proj,
        "label_encoder": le,
        "scaler_fusion": scaler_fusion,
        "scaler_longaa": scaler_longaa,
        "classes": le.classes_,
        "input_dim_fusion": input_dim_fusion,
        "input_dim_longaa": input_dim_longaa,
        "proto_dim": proto_dim,
        "params": params
    }


def predict_stage(stage_model, X_longaa_raw):
    X_s = stage_model["scaler_longaa"].transform(X_longaa_raw).astype(np.float32)
    X_t = torch.tensor(X_s, dtype=torch.float32, device=DEVICE)

    pred_id, conf = predict_mapper(
        stage_model["classifier"],
        stage_model["mapper"],
        X_t,
        batch_size=PRED_BATCH_SIZE
    )

    pred_label = stage_model["label_encoder"].inverse_transform(pred_id)

    return pred_label, conf


# ==========================================================
# 8. 主程序
# ==========================================================

def main():
    seed_everything(SEED)

    print("Using device:", DEVICE)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    # ======================================================
    # 8.1 读取文件
    # ======================================================

    print("Loading files...")

    fusion_df = pd.read_csv(FUSION_FILE)
    longaa_df = pd.read_csv(LONGAA_FILE)
    train_split_df = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split_df = pd.read_csv(TEST_SPLIT_FILE)
    proto_ref_df = pd.read_csv(PROTO_FILE)

    print("Fusion file shape:", fusion_df.shape)
    print("LongAA file shape:", longaa_df.shape)
    print("Train split shape:", train_split_df.shape)
    print("Test split shape:", test_split_df.shape)
    print("Prototype file shape:", proto_ref_df.shape)

    fusion_key = find_key_col(fusion_df, KEY_CANDIDATES)
    longaa_key = find_key_col(longaa_df, KEY_CANDIDATES)
    train_key = find_key_col(train_split_df, KEY_CANDIDATES)
    test_key = find_key_col(test_split_df, KEY_CANDIDATES)

    if fusion_key is None:
        raise ValueError("FUSION_FILE 中没有找到 key 列")

    if longaa_key is None:
        raise ValueError("LONGAA_FILE 中没有找到 key 列")

    if train_key is None:
        raise ValueError("TRAIN_SPLIT_FILE 中没有找到 key 列")

    if test_key is None:
        raise ValueError("TEST_SPLIT_FILE 中没有找到 key 列")

    for df_, key_ in [
        (fusion_df, fusion_key),
        (longaa_df, longaa_key),
        (train_split_df, train_key),
        (test_split_df, test_key)
    ]:
        df_[key_] = df_[key_].astype(str).str.strip()

    for df_ in [train_split_df, test_split_df]:
        for col in ["Type", "Subtype"]:
            if col not in df_.columns:
                raise ValueError(f"划分文件缺少必要列: {col}")

            df_[col] = df_[col].astype(str).replace(
                ["nan", "None", "NAN"],
                "Unknown"
            )

    for col in ["Type", "Subtype"]:
        if col in fusion_df.columns:
            fusion_df[col] = fusion_df[col].astype(str).replace(
                ["nan", "None", "NAN"],
                "Unknown"
            )

        if col in longaa_df.columns:
            longaa_df[col] = longaa_df[col].astype(str).replace(
                ["nan", "None", "NAN"],
                "Unknown"
            )

        if col in proto_ref_df.columns:
            proto_ref_df[col] = proto_ref_df[col].astype(str).replace(
                ["nan", "None", "NAN"],
                "Unknown"
            )

    # 去重
    for df_name, df_, key_ in [
        ("fusion", fusion_df, fusion_key),
        ("longAA", longaa_df, longaa_key)
    ]:
        dup_n = df_[key_].duplicated().sum()

        if dup_n > 0:
            print(
                f"Warning: {df_name} file has {dup_n} duplicated keys. "
                f"Keep first occurrence."
            )
            df_ = df_.drop_duplicates(subset=[key_], keep="first").copy()

            if df_name == "fusion":
                fusion_df = df_
            else:
                longaa_df = df_

    fusion_df = fusion_df.rename(columns={fusion_key: "KEY"})
    longaa_df = longaa_df.rename(columns={longaa_key: "KEY"})
    train_split_df = train_split_df.rename(columns={train_key: "KEY"})
    test_split_df = test_split_df.rename(columns={test_key: "KEY"})

    # ======================================================
    # 8.2 merge
    # ======================================================

    train_fusion_df = pd.merge(
        train_split_df,
        fusion_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    train_longaa_df = pd.merge(
        train_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    test_longaa_df = pd.merge(
        test_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    print("\nAfter merge:")
    print("Merged train_fusion samples:", len(train_fusion_df))
    print("Merged train_longAA samples:", len(train_longaa_df))
    print("Merged test_longAA samples:", len(test_longaa_df))

    if len(train_fusion_df) == 0:
        raise ValueError("train split 与 fusion 文件合并后为空，请检查 key 是否一致。")

    if len(train_longaa_df) == 0:
        raise ValueError("train split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    if len(test_longaa_df) == 0:
        raise ValueError("test split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    for df_ in [train_fusion_df, train_longaa_df, test_longaa_df]:
        for col in ["Type", "Subtype"]:
            split_col = f"{col}_split"

            if split_col in df_.columns:
                df_[col] = df_[split_col].astype(str)

        if "Geneid" not in df_.columns:
            df_["Geneid"] = df_["KEY"].astype(str)

    # train_fusion 和 train_longAA 对齐
    common_train_keys = sorted(
        set(train_fusion_df["KEY"]) & set(train_longaa_df["KEY"])
    )

    train_fusion_df = train_fusion_df[
        train_fusion_df["KEY"].isin(common_train_keys)
    ].copy()

    train_longaa_df = train_longaa_df[
        train_longaa_df["KEY"].isin(common_train_keys)
    ].copy()

    train_fusion_df.sort_values("KEY", inplace=True)
    train_longaa_df.sort_values("KEY", inplace=True)

    train_fusion_df.reset_index(drop=True, inplace=True)
    train_longaa_df.reset_index(drop=True, inplace=True)

    if len(train_fusion_df) != len(train_longaa_df):
        raise ValueError("train_fusion 与 train_longAA 数量不一致")

    if not np.all(train_fusion_df["KEY"].values == train_longaa_df["KEY"].values):
        raise ValueError("train_fusion 与 train_longAA 的 KEY 未对齐")

    # ======================================================
    # 8.3 添加二分类标签
    # ======================================================

    train_fusion_df["BinaryLabel"] = train_fusion_df["Subtype"].apply(make_binary_label)
    train_longaa_df["BinaryLabel"] = train_longaa_df["Subtype"].apply(make_binary_label)
    test_longaa_df["BinaryLabel"] = test_longaa_df["Subtype"].apply(make_binary_label)

    # ======================================================
    # 8.4 过滤 BGC subtype：Stage 2 必须在 train/test/prototype 中都存在
    # ======================================================

    proto_subtypes = set(proto_ref_df[LABEL_COL].astype(str).unique())

    train_bgc_subtypes = set(
        train_fusion_df.loc[
            train_fusion_df["BinaryLabel"] == "BGC",
            LABEL_COL
        ].astype(str).unique()
    )

    test_bgc_subtypes = set(
        test_longaa_df.loc[
            test_longaa_df["BinaryLabel"] == "BGC",
            LABEL_COL
        ].astype(str).unique()
    )

    valid_bgc_subtypes = train_bgc_subtypes & test_bgc_subtypes & proto_subtypes

    print("\nValid BGC subtype count:", len(valid_bgc_subtypes))

    if len(valid_bgc_subtypes) == 0:
        raise ValueError("有效 BGC subtype 数为 0，请检查 prototype 文件和标签是否一致。")

    def keep_valid_row(row):
        if row["BinaryLabel"] == "nonBGC":
            return True

        return str(row[LABEL_COL]) in valid_bgc_subtypes

    train_keep_mask = train_fusion_df.apply(keep_valid_row, axis=1).values
    test_keep_mask = test_longaa_df.apply(keep_valid_row, axis=1).values

    train_fusion_df = train_fusion_df[train_keep_mask].copy().reset_index(drop=True)
    train_longaa_df = train_longaa_df[train_keep_mask].copy().reset_index(drop=True)
    test_longaa_df = test_longaa_df[test_keep_mask].copy().reset_index(drop=True)

    proto_ref_df = proto_ref_df[
        proto_ref_df[LABEL_COL].astype(str).isin(valid_bgc_subtypes)
    ].copy()

    print("\nAfter filtering:")
    print("Train_fusion samples:", len(train_fusion_df))
    print("Train_longAA samples:", len(train_longaa_df))
    print("Test_longAA samples:", len(test_longaa_df))
    print("Train BinaryLabel distribution:")
    print(train_fusion_df["BinaryLabel"].value_counts())
    print("Test BinaryLabel distribution:")
    print(test_longaa_df["BinaryLabel"].value_counts())
    print("Train Subtype count:", train_fusion_df[LABEL_COL].nunique())
    print("Test Subtype count:", test_longaa_df[LABEL_COL].nunique())

    # ======================================================
    # 8.5 特征矩阵
    # ======================================================

    fusion_feature_cols = get_feature_cols(train_fusion_df)
    longaa_feature_cols = get_feature_cols(train_longaa_df)

    if len(fusion_feature_cols) == 0:
        raise ValueError("Fusion 特征列为 0")

    if len(longaa_feature_cols) == 0:
        raise ValueError("LongAA 特征列为 0")

    X_train_fusion = to_float_matrix(train_fusion_df, fusion_feature_cols)
    X_train_longaa = to_float_matrix(train_longaa_df, longaa_feature_cols)
    X_test_longaa = to_float_matrix(test_longaa_df, longaa_feature_cols)

    print("\nFeature dims:")
    print("Fusion feature dim:", X_train_fusion.shape[1])
    print("LongAA feature dim:", X_train_longaa.shape[1])

    # ======================================================
    # 8.6 Stage 1: BGC vs nonBGC
    # ======================================================

    y_stage1 = train_fusion_df["BinaryLabel"].astype(str).values

    stage1_model = train_one_stage(
        stage_name="Stage1_BGC_vs_nonBGC",
        X_fusion=X_train_fusion,
        X_longaa=X_train_longaa,
        y_label_str=y_stage1,
        prior_matrix_raw=None,
        params=STAGE1_PARAMS
    )

    # ======================================================
    # 8.7 Stage 2: BGC subtype
    # ======================================================

    bgc_train_mask = train_fusion_df["BinaryLabel"].values == "BGC"

    train_fusion_bgc_df = train_fusion_df[bgc_train_mask].copy().reset_index(drop=True)
    train_longaa_bgc_df = train_longaa_df[bgc_train_mask].copy().reset_index(drop=True)

    X_train_fusion_bgc = to_float_matrix(train_fusion_bgc_df, fusion_feature_cols)
    X_train_longaa_bgc = to_float_matrix(train_longaa_bgc_df, longaa_feature_cols)

    y_stage2 = train_fusion_bgc_df[LABEL_COL].astype(str).values

    stage2_le_tmp = LabelEncoder()
    stage2_le_tmp.fit(sorted(np.unique(y_stage2)))

    prior_matrix_stage2 = build_prior_matrix_from_proto(
        prior_df=proto_ref_df,
        label_col=LABEL_COL,
        label_encoder=stage2_le_tmp
    )

    stage2_model = train_one_stage(
        stage_name="Stage2_BGC_Subtype",
        X_fusion=X_train_fusion_bgc,
        X_longaa=X_train_longaa_bgc,
        y_label_str=y_stage2,
        prior_matrix_raw=prior_matrix_stage2,
        params=STAGE2_PARAMS
    )

    # ======================================================
    # 8.8 最终预测：Stage 1 -> Stage 2
    # ======================================================

    print("\nEvaluating two-stage model...")

    stage1_pred_label, stage1_conf = predict_stage(
        stage_model=stage1_model,
        X_longaa_raw=X_test_longaa
    )

    final_pred = np.array(["nonBGC"] * len(test_longaa_df), dtype=object)
    final_conf = stage1_conf.copy()

    bgc_pred_mask = stage1_pred_label == "BGC"

    if int(bgc_pred_mask.sum()) > 0:
        X_test_bgc_for_stage2 = X_test_longaa[bgc_pred_mask]

        stage2_pred_label, stage2_conf = predict_stage(
            stage_model=stage2_model,
            X_longaa_raw=X_test_bgc_for_stage2
        )

        final_pred[bgc_pred_mask] = stage2_pred_label
        final_conf[bgc_pred_mask] = stage2_conf

    y_true_final = test_longaa_df[LABEL_COL].astype(str).values
    y_pred_final = final_pred.astype(str)

    final_metrics = compute_overall_metrics(y_true_final, y_pred_final)

    print("\n=== FINAL TWO-STAGE TEST RESULT ===")
    for k, v in final_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    print("\n=== Weighted metrics ===")
    print(f"Weighted Precision: {final_metrics['WEIGHTED_PRECISION']:.4f}")
    print(f"Weighted Recall:    {final_metrics['WEIGHTED_RECALL']:.4f}")
    print(f"Weighted F1:        {final_metrics['WEIGHTED_F1']:.4f}")
    print(f"Macro F1:           {final_metrics['MACRO_F1']:.4f}")
    print(f"MCC:                {final_metrics['MCC']:.4f}")

    if SAVE_CLASSIFICATION_REPORT:
        print("\n=== Classification Report | Final Two-Stage ===")
        print(classification_report(
            y_true=y_true_final,
            y_pred=y_pred_final,
            zero_division=0,
            digits=4
        ))

    # ======================================================
    # 8.9 分析 Stage 1 二分类结果
    # ======================================================

    y_true_stage1 = test_longaa_df["BinaryLabel"].astype(str).values

    stage1_metrics = compute_overall_metrics(
        y_true=y_true_stage1,
        y_pred=stage1_pred_label
    )

    print("\n=== STAGE 1 TEST RESULT | BGC vs nonBGC ===")
    for k, v in stage1_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    # ======================================================
    # 8.10 只看真实 BGC 样本上的 Stage 2 结果
    # ======================================================

    true_bgc_mask = y_true_stage1 == "BGC"

    if int(true_bgc_mask.sum()) > 0:
        y_true_bgc = y_true_final[true_bgc_mask]
        y_pred_bgc_final = y_pred_final[true_bgc_mask]

        stage2_on_true_bgc_metrics = compute_overall_metrics(
            y_true=y_true_bgc,
            y_pred=y_pred_bgc_final
        )

        print("\n=== FINAL RESULT ON TRUE BGC SAMPLES ===")
        for k, v in stage2_on_true_bgc_metrics.items():
            print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    # ======================================================
    # 8.11 保存结果
    # ======================================================

    overall_df = pd.DataFrame([
        {
            "split": "test_set_final_two_stage",
            "sample_count": final_metrics["sample_count"],
            "class_count": final_metrics["class_count"],
            "ACC": final_metrics["ACC"],
            "WEIGHTED_PRECISION": final_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": final_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": final_metrics["WEIGHTED_F1"],
            "MACRO_F1": final_metrics["MACRO_F1"],
            "MCC": final_metrics["MCC"]
        },
        {
            "split": "test_set_stage1_binary",
            "sample_count": stage1_metrics["sample_count"],
            "class_count": stage1_metrics["class_count"],
            "ACC": stage1_metrics["ACC"],
            "WEIGHTED_PRECISION": stage1_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": stage1_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": stage1_metrics["WEIGHTED_F1"],
            "MACRO_F1": stage1_metrics["MACRO_F1"],
            "MCC": stage1_metrics["MCC"]
        }
    ]).round(4)

    overall_df.to_csv(
        "two_stage_overall_metrics_weighted.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pred_df = test_longaa_df[["KEY", "Type", "Subtype", "BinaryLabel"]].copy()
    pred_df["Stage1_Pred"] = stage1_pred_label
    pred_df["Stage1_Confidence"] = stage1_conf
    pred_df["Final_Pred_Subtype"] = y_pred_final
    pred_df["Final_Confidence"] = final_conf
    pred_df["Final_Correct"] = pred_df["Subtype"].astype(str) == pred_df["Final_Pred_Subtype"].astype(str)

    pred_df.to_csv(
        "two_stage_test_predictions.csv",
        index=False,
        encoding="utf-8-sig"
    )

    threshold_df = threshold_scan(
        y_true=y_true_final,
        y_pred=y_pred_final,
        conf=final_conf
    ).round(4)

    threshold_df.to_csv(
        "two_stage_precision_threshold_scan.csv",
        index=False,
        encoding="utf-8-sig"
    )

    torch.save(
        {
            "stage1_classifier": stage1_model["classifier"].state_dict(),
            "stage1_mapper": stage1_model["mapper"].state_dict(),
            "stage1_prior_proj": stage1_model["prior_proj"].state_dict(),
            "stage1_classes": stage1_model["classes"],

            "stage2_classifier": stage2_model["classifier"].state_dict(),
            "stage2_mapper": stage2_model["mapper"].state_dict(),
            "stage2_prior_proj": stage2_model["prior_proj"].state_dict(),
            "stage2_classes": stage2_model["classes"],

            "fusion_feature_cols": fusion_feature_cols,
            "longaa_feature_cols": longaa_feature_cols,
            "seed": SEED
        },
        "two_stage_bgc_nonbgc_subtype_model.pt"
    )

    print("\n结果已保存：")
    print(" - two_stage_overall_metrics_weighted.csv")
    print(" - two_stage_test_predictions.csv")
    print(" - two_stage_precision_threshold_scan.csv")
    print(" - two_stage_bgc_nonbgc_subtype_model.pt")
    print("Done.")


if __name__ == "__main__":
    mp.freeze_support()
    main()