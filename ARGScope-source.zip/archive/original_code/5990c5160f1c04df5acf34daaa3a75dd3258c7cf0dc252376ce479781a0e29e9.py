from pathlib import Path
import pandas as pd


# ==========================================================
# 1. 输入输出文件
# ==========================================================

FINAL_FASTA = "final_equal_BGC_nonBGC_protein.fasta"

DNA_EMBED_FILE = "BGC_dna_embedding.txt"
PROTEIN_EMBED_FILE = "BGC_protein_embed_1280.txt"

OUTPUT_DNA_EMBED_FILE = "final_equal_BGC_nonBGC_dna_embedding.txt"
OUTPUT_PROTEIN_EMBED_FILE = "final_equal_BGC_nonBGC_protein_embed_1280.txt"

OUTPUT_MISSING_DNA = "missing_ids_in_dna_embedding.csv"
OUTPUT_MISSING_PROTEIN = "missing_ids_in_protein_embedding.csv"

OUTPUT_SUMMARY = "filter_embedding_summary.csv"


# ==========================================================
# 2. 工具函数
# ==========================================================

def clean_id(x):
    if x is None:
        return ""

    x = str(x).strip()
    x = x.lstrip(">")

    if x == "" or x.lower() in ["nan", "none", "null"]:
        return ""

    parts = x.split()

    if len(parts) == 0:
        return ""

    return parts[0]


def remove_version(x):
    x = clean_id(x)

    if x == "":
        return ""

    if "." in x:
        return x.rsplit(".", 1)[0]

    return x


def read_fasta_ids(fasta_file):
    """
    从 final FASTA 中读取目标 ID，保持顺序并去重。
    """
    fasta_file = Path(fasta_file)

    if not fasta_file.exists():
        raise FileNotFoundError("找不到 FASTA 文件: {}".format(fasta_file))

    ids = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith(">"):
                sid = clean_id(line)
                if sid:
                    ids.append(sid)

    ids = list(dict.fromkeys(ids))

    print("FASTA ID 数:", len(ids))
    print("前 10 个 ID:", ids[:10])

    return ids


def parse_embedding_line(line):
    """
    解析 embedding 文件的一行。
    默认第一列是 ID，后面是 embedding。
    保留原始 line，不改动 embedding 数值。
    """
    raw_line = line.rstrip("\n").rstrip("\r")

    if raw_line.strip() == "":
        return "", raw_line

    # 兼容逗号、tab、空格
    tmp = raw_line.replace(",", " ")
    parts = tmp.split()

    if len(parts) == 0:
        return "", raw_line

    sid = clean_id(parts[0])

    return sid, raw_line


def read_embedding_to_index(embed_file):
    """
    读取 embedding 文件，建立：
        full_id -> 原始行
        no_version_id -> 原始行
    如果重复，保留第一次出现。
    """
    embed_file = Path(embed_file)

    if not embed_file.exists():
        raise FileNotFoundError("找不到 embedding 文件: {}".format(embed_file))

    full_index = {}
    nover_index = {}

    total_lines = 0
    valid_lines = 0
    skipped_header = 0
    duplicate_count = 0

    with open(embed_file, "r", encoding="utf-8") as f:
        for line in f:
            total_lines += 1

            sid, raw_line = parse_embedding_line(line)

            if sid == "":
                continue

            # 跳过可能的表头
            if sid.lower() in ["id", "protein_id", "geneid"]:
                skipped_header += 1
                continue

            sid_nover = remove_version(sid)

            if sid in full_index:
                duplicate_count += 1
                continue

            full_index[sid] = raw_line

            if sid_nover and sid_nover not in nover_index:
                nover_index[sid_nover] = raw_line

            valid_lines += 1

    print("读取 embedding:", embed_file)
    print("总行数:", total_lines)
    print("有效 embedding ID 数:", len(full_index))
    print("跳过表头行数:", skipped_header)
    print("重复 ID 行数:", duplicate_count)
    print("-" * 60)

    return full_index, nover_index


def filter_embedding_by_fasta_ids(target_ids, embed_file, output_file, missing_file):
    """
    按 target_ids 的顺序过滤 embedding。
    """
    full_index, nover_index = read_embedding_to_index(embed_file)

    output_lines = []
    missing_ids = []

    exact_match = 0
    nover_match = 0

    for sid in target_ids:
        sid_clean = clean_id(sid)
        sid_nover = remove_version(sid_clean)

        if sid_clean in full_index:
            output_lines.append(full_index[sid_clean])
            exact_match += 1
        elif sid_nover in nover_index:
            output_lines.append(nover_index[sid_nover])
            nover_match += 1
        else:
            missing_ids.append(sid_clean)

    with open(output_file, "w", encoding="utf-8") as f:
        for line in output_lines:
            f.write(line + "\n")

    missing_df = pd.DataFrame({"id": missing_ids})
    missing_df.to_csv(
        missing_file,
        index=False,
        encoding="utf-8-sig"
    )

    print("过滤完成:", embed_file)
    print("目标 ID 数:", len(target_ids))
    print("精确匹配数:", exact_match)
    print("去版本号匹配数:", nover_match)
    print("输出 embedding 数:", len(output_lines))
    print("未匹配 ID 数:", len(missing_ids))
    print("输出文件:", output_file)
    print("未匹配文件:", missing_file)
    print("-" * 60)

    return {
        "input_embedding_file": str(embed_file),
        "output_embedding_file": str(output_file),
        "target_id_count": len(target_ids),
        "exact_match_count": exact_match,
        "without_version_match_count": nover_match,
        "output_embedding_count": len(output_lines),
        "missing_count": len(missing_ids),
        "missing_file": str(missing_file)
    }


# ==========================================================
# 3. 主函数
# ==========================================================

def main():
    print("=" * 60)
    print("Step 1. 读取 final FASTA ID")
    print("=" * 60)

    target_ids = read_fasta_ids(FINAL_FASTA)

    print("=" * 60)
    print("Step 2. 过滤 DNA embedding")
    print("=" * 60)

    dna_summary = filter_embedding_by_fasta_ids(
        target_ids=target_ids,
        embed_file=DNA_EMBED_FILE,
        output_file=OUTPUT_DNA_EMBED_FILE,
        missing_file=OUTPUT_MISSING_DNA
    )

    print("=" * 60)
    print("Step 3. 过滤 protein embedding")
    print("=" * 60)

    protein_summary = filter_embedding_by_fasta_ids(
        target_ids=target_ids,
        embed_file=PROTEIN_EMBED_FILE,
        output_file=OUTPUT_PROTEIN_EMBED_FILE,
        missing_file=OUTPUT_MISSING_PROTEIN
    )

    summary_df = pd.DataFrame([dna_summary, protein_summary])
    summary_df.to_csv(
        OUTPUT_SUMMARY,
        index=False,
        encoding="utf-8-sig"
    )

    print("=" * 60)
    print("全部完成")
    print("=" * 60)

    print("DNA embedding 输出:", OUTPUT_DNA_EMBED_FILE)
    print("Protein embedding 输出:", OUTPUT_PROTEIN_EMBED_FILE)
    print("统计文件:", OUTPUT_SUMMARY)

    print("\nSummary:")
    print(summary_df)


if __name__ == "__main__":
    main()