# -*- coding: utf-8 -*-
"""
Apply trained LongNT Fusion-teacher DNA-student model to 90p DNA/NT embeddings.

放在同一个文件夹中运行：

当前文件夹/
├── LongNT_model_on_90p_DNA.py
├── 1.90_ARG_DNA_with_label.csv
├── model_checkpoint.pth
├── scaler_dna.joblib
├── subtype_encoder.joblib
├── test_set.csv
└── ...

输出：
当前文件夹/LongNT_model_on_90p_DNA_outputs/
"""

import os
import re
import json
import time
from pathlib import Path
from collections import Counter

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    classification_report,
)


# =========================================================
# 1. CONFIG
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

DNA_90P_FILE = BASE_DIR / "1.90_ARG_DNA_with_label.csv"
CHECKPOINT_FILE = BASE_DIR / "model_checkpoint.pth"
SCALER_DNA_FILE = BASE_DIR / "scaler_dna.joblib"
SUBTYPE_ENCODER_FILE = BASE_DIR / "subtype_encoder.joblib"
TEST_SET_FILE = BASE_DIR / "test_set.csv"

OUT_DIR = BASE_DIR / "LongNT_model_on_90p_DNA_outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 256

# 是否只保留 test_set.csv 中的 base ID
USE_TEST_SET_FILTER = True

# high confidence 阈值，沿用你原训练代码的默认值
DEFAULT_MIN_PROB = 0.40
DEFAULT_MIN_MARGIN = 0.08

SEED = 42


# =========================================================
# 2. MODEL CONFIG FROM TRAINING CODE
# =========================================================

DNA_HIDDEN_DIM = 1024
EMBED_DIM = 512
NUM_RES_BLOCKS = 2
DROPOUT = 0.18

LOGIT_SCALE = 28.0
ARCFACE_MARGIN = 0.15

SUBTYPE_COL = "Subtype"
TYPE_COL = "Type"

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id",
    "Original_ID", "original_id", "read_id", "Read_ID",
]


# =========================================================
# 3. BASIC UTILS
# =========================================================

def log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def seed_everything(seed=42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def safe_torch_load(path, map_location="cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def read_table(path):
    path = str(path)
    if path.lower().endswith((".tsv", ".txt")):
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def find_key_col(df):
    for c in KEY_CANDIDATES:
        if c in df.columns:
            return c
    obj_cols = [c for c in df.columns if df[c].dtype == "object"]
    if obj_cols:
        return obj_cols[0]
    raise ValueError("Cannot find key column. Please make sure your file has KEY / ID / Geneid column.")


def normalize_key_series(s):
    return s.astype(str).str.strip()


def normalize_base_id_one(x):
    """
    把 90p fragment ID 还原为 base ID。
    支持：
    xxx_1 / xxx_2 / xxx_3 / xxx_4 / xxx_5
    xxx_part1
    xxx_frag1
    xxx_fragment1
    xxx_window1
    """
    s = str(x).strip()
    s = re.sub(r"\s+", "", s)

    patterns = [
        r"(_90p)?(_part)[0-9]+$",
        r"(_90pct)?(_part)[0-9]+$",
        r"(_p90)?(_part)[0-9]+$",
        r"(_frag)[0-9]+$",
        r"(_fragment)[0-9]+$",
        r"(_window)[0-9]+$",
        r"(_piece)[0-9]+$",
        r"(_segment)[0-9]+$",
        r"(_seg)[0-9]+$",
        r"(\.part)[0-9]+$",
        r"(-part)[0-9]+$",
        r"(_[1-5])$",
    ]

    for p in patterns:
        s2 = re.sub(p, "", s, flags=re.IGNORECASE)
        if s2 != s:
            return s2

    return s


def infer_type_from_subtype(subtype):
    s = str(subtype)
    if "__" in s:
        return s.split("__", 1)[0]
    return "Unknown"


def get_numeric_feature_cols(df, exclude_cols):
    cols = []
    for c in df.columns:
        if c in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


# =========================================================
# 4. MODEL DEFINITIONS
# 必须和训练代码保持一致
# =========================================================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()

        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])

        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = F.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=30.0, margin=0.20, easy_margin=False):
        super().__init__()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = scale
        self.margin = margin
        self.easy_margin = easy_margin

        self.cos_m = np.cos(margin)
        self.sin_m = np.sin(margin)
        self.th = np.cos(np.pi - margin)
        self.mm = np.sin(np.pi - margin) * margin

    def forward(self, z, labels=None):
        z = F.normalize(z, p=2, dim=1)
        w = F.normalize(self.weight, p=2, dim=1)

        cosine = F.linear(z, w)

        if labels is None:
            return cosine * self.scale

        cosine_float = cosine.float()
        sine = torch.sqrt(torch.clamp(1.0 - torch.pow(cosine_float, 2), min=1e-7))
        phi = cosine_float * self.cos_m - sine * self.sin_m

        if self.easy_margin:
            phi = torch.where(cosine_float > 0, phi, cosine_float)
        else:
            phi = torch.where(cosine_float > self.th, phi, cosine_float - self.mm)

        one_hot = torch.zeros_like(cosine_float)
        one_hot.scatter_(1, labels.view(-1, 1), 1.0)

        output = (one_hot * phi) + ((1.0 - one_hot) * cosine_float)
        output = output * self.scale
        return output


class DNAStudent(nn.Module):
    def __init__(self, dna_dim, num_classes):
        super().__init__()
        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=DNA_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )
        self.head = ArcMarginHead(
            EMBED_DIM,
            num_classes,
            scale=LOGIT_SCALE,
            margin=ARCFACE_MARGIN,
        )

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


# =========================================================
# 5. METRICS
# =========================================================

def compute_metrics(y_true, y_pred):
    if len(y_true) == 0:
        return {
            "sample_count": 0,
            "class_count": 0,
            "ACC": np.nan,
            "WEIGHTED_PRECISION": np.nan,
            "WEIGHTED_RECALL": np.nan,
            "WEIGHTED_F1": np.nan,
            "MACRO_PRECISION": np.nan,
            "MACRO_RECALL": np.nan,
            "MACRO_F1": np.nan,
            "MICRO_PRECISION": np.nan,
            "MICRO_RECALL": np.nan,
            "MICRO_F1": np.nan,
            "MCC": np.nan,
        }

    return {
        "sample_count": int(len(y_true)),
        "class_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MICRO_PRECISION": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_RECALL": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_F1": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def per_class_metrics(y_true, y_pred, class_names, label_col, split_name):
    rows = []
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    for cid in sorted(np.unique(y_true)):
        true_bin = (y_true == cid).astype(int)
        pred_bin = (y_pred == cid).astype(int)

        support = int(true_bin.sum())
        pred_count = int(pred_bin.sum())
        correct = int(((y_true == cid) & (y_pred == cid)).sum())

        rows.append({
            "split": split_name,
            label_col: class_names[cid] if isinstance(class_names, (list, np.ndarray)) else cid,
            "class_id": int(cid) if isinstance(cid, (int, np.integer)) else str(cid),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct,
            "ACC": correct / support if support > 0 else 0.0,
            "PRECISION": precision_score(true_bin, pred_bin, zero_division=0),
            "RECALL": recall_score(true_bin, pred_bin, zero_division=0),
            "F1": f1_score(true_bin, pred_bin, zero_division=0),
            "MCC": matthews_corrcoef(true_bin, pred_bin)
            if (len(np.unique(true_bin)) > 1 or len(np.unique(pred_bin)) > 1)
            else 0.0,
        })

    return pd.DataFrame(rows)


def save_metric_tables(y_true, y_pred, class_names, label_col, prefix):
    metrics = compute_metrics(y_true, y_pred)
    metrics_df = pd.DataFrame([{"split": prefix, **metrics}]).round(6)
    metrics_df.to_csv(OUT_DIR / f"{prefix}_overall_metrics.csv", index=False, encoding="utf-8-sig")

    per_df = per_class_metrics(
        y_true=y_true,
        y_pred=y_pred,
        class_names=class_names,
        label_col=label_col,
        split_name=prefix,
    ).round(6)
    per_df.to_csv(OUT_DIR / f"{prefix}_metrics_by_class.csv", index=False, encoding="utf-8-sig")

    return metrics_df, per_df


# =========================================================
# 6. INFERENCE
# =========================================================

def load_models_from_checkpoint(ckpt):
    if "student_state_dicts" not in ckpt:
        raise KeyError(
            "checkpoint 中没有 student_state_dicts。"
            "请确认这个 model_checkpoint.pth 是由你上传的 Fusion teacher + DNA student 训练代码生成的。"
        )

    dna_dim = int(ckpt["dna_dim"])
    num_classes = int(ckpt["num_classes"])

    student_state_dicts = ckpt["student_state_dicts"]
    if not isinstance(student_state_dicts, list):
        raise TypeError("checkpoint['student_state_dicts'] 不是 list。")

    models = []

    for i, sd in enumerate(student_state_dicts):
        model = DNAStudent(dna_dim=dna_dim, num_classes=num_classes)
        model.load_state_dict(sd, strict=True)
        model.to(DEVICE)
        model.eval()
        models.append(model)
        log(f"Loaded DNAStudent #{i + 1}: dna_dim={dna_dim}, num_classes={num_classes}")

    return models, dna_dim, num_classes


def predict_ensemble(models, X):
    all_probs = []

    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    for mi, model in enumerate(models):
        model.eval()
        probs_this = []

        with torch.no_grad():
            for (xb,) in loader:
                xb = xb.to(DEVICE, non_blocking=True)
                _, logits_plain, _ = model(xb, labels=None)
                probs = torch.softmax(logits_plain.float(), dim=1)
                probs_this.append(probs.cpu().numpy())

        probs_this = np.concatenate(probs_this, axis=0)
        all_probs.append(probs_this)

    mean_probs = np.mean(np.stack(all_probs, axis=0), axis=0)

    pred_idx = mean_probs.argmax(axis=1)
    sorted_probs = np.sort(mean_probs, axis=1)[:, ::-1]
    confidence = sorted_probs[:, 0]
    margin = sorted_probs[:, 0] - sorted_probs[:, 1] if mean_probs.shape[1] >= 2 else np.zeros(len(mean_probs))

    return pred_idx, confidence, margin, mean_probs


# =========================================================
# 7. MAIN
# =========================================================

def main():
    seed_everything(SEED)

    log("============================================================")
    log("LongNT DNAStudent model on 90p DNA embedding")
    log("============================================================")
    log(f"BASE_DIR: {BASE_DIR}")
    log(f"DNA_90P_FILE: {DNA_90P_FILE}")
    log(f"CHECKPOINT_FILE: {CHECKPOINT_FILE}")
    log(f"SCALER_DNA_FILE: {SCALER_DNA_FILE}")
    log(f"SUBTYPE_ENCODER_FILE: {SUBTYPE_ENCODER_FILE}")
    log(f"TEST_SET_FILE: {TEST_SET_FILE}")
    log(f"OUT_DIR: {OUT_DIR}")
    log(f"DEVICE: {DEVICE}")
    if torch.cuda.is_available():
        log(f"GPU: {torch.cuda.get_device_name(0)}")
    log("============================================================")

    for f in [DNA_90P_FILE, CHECKPOINT_FILE, SCALER_DNA_FILE, SUBTYPE_ENCODER_FILE]:
        if not f.exists():
            raise FileNotFoundError(f"Required file not found: {f}")

    log("Loading checkpoint")
    ckpt = safe_torch_load(CHECKPOINT_FILE, map_location="cpu")

    log("Checkpoint keys:")
    for k in ckpt.keys():
        log(f"  {k}")

    models, dna_dim, num_classes = load_models_from_checkpoint(ckpt)

    log("Loading scaler_dna.joblib")
    scaler_dna = joblib.load(SCALER_DNA_FILE)

    log("Loading subtype_encoder.joblib")
    subtype_encoder = joblib.load(SUBTYPE_ENCODER_FILE)

    if hasattr(subtype_encoder, "classes_"):
        subtype_classes = list(subtype_encoder.classes_)
    elif "subtype_classes" in ckpt:
        subtype_classes = list(ckpt["subtype_classes"])
    else:
        raise ValueError("Cannot get subtype classes from subtype_encoder or checkpoint.")

    if len(subtype_classes) != num_classes:
        raise ValueError(
            f"Class number mismatch: checkpoint num_classes={num_classes}, "
            f"encoder classes={len(subtype_classes)}"
        )

    scaler_dim = getattr(scaler_dna, "n_features_in_", None)
    if scaler_dim is not None and int(scaler_dim) != dna_dim:
        raise ValueError(f"scaler_dna expects {scaler_dim} features, but checkpoint dna_dim={dna_dim}")

    log(f"dna_dim: {dna_dim}")
    log(f"num_classes: {num_classes}")
    log(f"student models: {len(models)}")

    log("Loading 90p DNA embedding")
    df = read_table(DNA_90P_FILE)

    key_col = find_key_col(df)
    log(f"Detected key column: {key_col}")

    df[key_col] = normalize_key_series(df[key_col])
    df["base_id"] = df[key_col].map(normalize_base_id_one)

    has_subtype = SUBTYPE_COL in df.columns
    has_type = TYPE_COL in df.columns

    if has_subtype:
        df[SUBTYPE_COL] = df[SUBTYPE_COL].astype(str).str.strip()
    if has_type:
        df[TYPE_COL] = df[TYPE_COL].astype(str).str.strip()

    if USE_TEST_SET_FILTER and TEST_SET_FILE.exists():
        log("Filtering by test_set.csv")
        test_df = read_table(TEST_SET_FILE)
        test_key_col = find_key_col(test_df)
        test_df[test_key_col] = normalize_key_series(test_df[test_key_col])
        test_base_ids = set(test_df[test_key_col].map(normalize_base_id_one).astype(str))

        before = len(df)
        df2 = df[df["base_id"].astype(str).isin(test_base_ids)].copy()
        after = len(df2)

        log(f"Rows before test filter: {before}")
        log(f"Rows after test filter: {after}")
        log(f"test base IDs: {len(test_base_ids)}")

        if after > 0:
            df = df2.reset_index(drop=True)
        else:
            log("WARNING: test_set filtering produced zero rows. Use all 90p rows instead.")
            df = df.reset_index(drop=True)
    else:
        df = df.reset_index(drop=True)

    exclude_cols = {
        key_col, "base_id",
        "KEY", "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "protein_id", "Protein_id",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count", "Pred_Subtype",
        "Unnamed: 0", "index", "Index",
        "split", "Split", "fold", "Fold",
        "part", "Part",
        "length", "Length",
        "label_id", "subtype_id", "type_id",
    }

    ckpt_dna_cols = ckpt.get("dna_feature_cols", None)

    if ckpt_dna_cols is not None and all(c in df.columns for c in ckpt_dna_cols):
        dna_cols = list(ckpt_dna_cols)
        log("Using dna_feature_cols from checkpoint.")
    else:
        dna_cols = get_numeric_feature_cols(df, exclude_cols)
        log("Using detected numeric feature columns.")

    if len(dna_cols) != dna_dim:
        raise ValueError(
            f"DNA feature dimension mismatch. Detected {len(dna_cols)}, checkpoint dna_dim={dna_dim}.\n"
            f"First 10 detected feature columns: {dna_cols[:10]}\n"
            f"Last 10 detected feature columns: {dna_cols[-10:]}\n"
            "请检查 1.90_ARG_DNA_with_label.csv 是否和训练用的 DNA embedding 列名/维度一致。"
        )

    log(f"Using DNA feature columns: {len(dna_cols)}")

    X_raw = to_float_matrix(df, dna_cols)

    if not np.isfinite(X_raw).all():
        raise ValueError("X_raw contains NaN or Inf after preprocessing.")

    log("Applying scaler_dna.transform()")
    X = scaler_dna.transform(X_raw).astype(np.float32)

    log("Running ensemble inference")
    pred_idx, confidence, margin, probs = predict_ensemble(models, X)

    pred_subtypes = subtype_encoder.inverse_transform(pred_idx)
    pred_types = [infer_type_from_subtype(x) for x in pred_subtypes]

    pred_df = pd.DataFrame({
        "KEY": df[key_col].astype(str).values,
        "base_id": df["base_id"].astype(str).values,
        "Pred_Subtype": pred_subtypes,
        "Pred_Type": pred_types,
        "subtype_confidence": confidence,
        "subtype_margin": margin,
    })

    if has_subtype:
        pred_df[SUBTYPE_COL] = df[SUBTYPE_COL].astype(str).values
        pred_df["Subtype_correct"] = pred_df[SUBTYPE_COL].astype(str).values == pred_df["Pred_Subtype"].astype(str).values

    if has_type:
        pred_df[TYPE_COL] = df[TYPE_COL].astype(str).values
    elif has_subtype:
        pred_df[TYPE_COL] = pred_df[SUBTYPE_COL].map(infer_type_from_subtype)

    if TYPE_COL in pred_df.columns:
        pred_df["Type_correct"] = pred_df[TYPE_COL].astype(str).values == pred_df["Pred_Type"].astype(str).values

    pred_df["high_confidence"] = (
        (pred_df["subtype_confidence"] >= DEFAULT_MIN_PROB)
        & (pred_df["subtype_margin"] >= DEFAULT_MIN_MARGIN)
    )

    log("Saving fragment-level predictions")
    pred_df.round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_fragment_all.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pred_df[pred_df["high_confidence"]].round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_fragment_high_confidence.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pred_df[~pred_df["high_confidence"]].round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_fragment_rejected.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # top5
    topk = min(5, num_classes)
    topk_idx = np.argsort(-probs, axis=1)[:, :topk]
    top_rows = []

    for i in range(len(pred_df)):
        row = {
            "KEY": pred_df.iloc[i]["KEY"],
            "base_id": pred_df.iloc[i]["base_id"],
        }
        for k in range(topk):
            cid = int(topk_idx[i, k])
            row[f"top{k + 1}_subtype"] = subtype_classes[cid]
            row[f"top{k + 1}_prob"] = float(probs[i, cid])
        top_rows.append(row)

    pd.DataFrame(top_rows).round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_fragment_top5.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary = {
        "input_file": str(DNA_90P_FILE),
        "checkpoint_file": str(CHECKPOINT_FILE),
        "device": str(DEVICE),
        "n_fragment_rows": int(len(pred_df)),
        "n_base_ids": int(pred_df["base_id"].nunique()),
        "dna_dim": int(dna_dim),
        "num_classes": int(num_classes),
        "n_student_models": int(len(models)),
        "min_prob": float(DEFAULT_MIN_PROB),
        "min_margin": float(DEFAULT_MIN_MARGIN),
        "n_high_conf_fragment": int(pred_df["high_confidence"].sum()),
        "n_rejected_fragment": int((~pred_df["high_confidence"]).sum()),
    }

    # Fragment-level metrics
    if has_subtype:
        log("Computing fragment-level subtype metrics")
        y_true_sub = subtype_encoder.transform(pred_df[SUBTYPE_COL].astype(str).values)
        y_pred_sub = subtype_encoder.transform(pred_df["Pred_Subtype"].astype(str).values)

        sub_metrics_df, _ = save_metric_tables(
            y_true=y_true_sub,
            y_pred=y_pred_sub,
            class_names=subtype_classes,
            label_col=SUBTYPE_COL,
            prefix="subtype_90p_DNA_fragment",
        )

        summary["fragment_subtype_ACC"] = float(sub_metrics_df.loc[0, "ACC"])
        summary["fragment_subtype_WEIGHTED_F1"] = float(sub_metrics_df.loc[0, "WEIGHTED_F1"])
        summary["fragment_subtype_MACRO_F1"] = float(sub_metrics_df.loc[0, "MACRO_F1"])
        summary["fragment_subtype_MCC"] = float(sub_metrics_df.loc[0, "MCC"])

        with open(OUT_DIR / "classification_report_subtype_fragment.txt", "w", encoding="utf-8") as f:
            f.write(classification_report(
                y_true=pred_df[SUBTYPE_COL].astype(str).values,
                y_pred=pred_df["Pred_Subtype"].astype(str).values,
                zero_division=0,
                digits=4,
            ))

    if TYPE_COL in pred_df.columns:
        log("Computing fragment-level type metrics")
        true_type = pred_df[TYPE_COL].astype(str).values
        pred_type = pred_df["Pred_Type"].astype(str).values

        type_labels = sorted(set(true_type) | set(pred_type))
        type_to_id = {x: i for i, x in enumerate(type_labels)}

        y_true_type = np.array([type_to_id[x] for x in true_type], dtype=np.int64)
        y_pred_type = np.array([type_to_id[x] for x in pred_type], dtype=np.int64)

        type_metrics_df, _ = save_metric_tables(
            y_true=y_true_type,
            y_pred=y_pred_type,
            class_names=type_labels,
            label_col=TYPE_COL,
            prefix="type_90p_DNA_fragment_from_subtype",
        )

        summary["fragment_type_ACC"] = float(type_metrics_df.loc[0, "ACC"])
        summary["fragment_type_WEIGHTED_F1"] = float(type_metrics_df.loc[0, "WEIGHTED_F1"])
        summary["fragment_type_MACRO_F1"] = float(type_metrics_df.loc[0, "MACRO_F1"])
        summary["fragment_type_MCC"] = float(type_metrics_df.loc[0, "MCC"])

    # =====================================================
    # Base-ID-level aggregation
    # 按 base_id 平均 probability
    # =====================================================

    log("Computing base-ID-level predictions by mean probability")

    base_rows = []
    base_ids = pred_df["base_id"].astype(str).values

    for base_id in pd.unique(base_ids):
        idx = np.where(base_ids == base_id)[0]
        mean_probs = probs[idx].mean(axis=0)

        pidx = int(np.argmax(mean_probs))
        pred_subtype = subtype_classes[pidx]
        pred_type = infer_type_from_subtype(pred_subtype)

        s_probs = np.sort(mean_probs)[::-1]
        conf = float(s_probs[0])
        mar = float(s_probs[0] - s_probs[1]) if len(s_probs) >= 2 else 0.0

        row = {
            "base_id": base_id,
            "n_fragments": int(len(idx)),
            "Pred_Subtype": pred_subtype,
            "Pred_Type": pred_type,
            "subtype_confidence": conf,
            "subtype_margin": mar,
        }

        if has_subtype:
            true_subtypes = pred_df.iloc[idx][SUBTYPE_COL].astype(str).tolist()
            row[SUBTYPE_COL] = Counter(true_subtypes).most_common(1)[0][0]
            row["Subtype_correct"] = row[SUBTYPE_COL] == row["Pred_Subtype"]

        if TYPE_COL in pred_df.columns:
            true_types = pred_df.iloc[idx][TYPE_COL].astype(str).tolist()
            row[TYPE_COL] = Counter(true_types).most_common(1)[0][0]
            row["Type_correct"] = row[TYPE_COL] == row["Pred_Type"]

        row["high_confidence"] = (
            (row["subtype_confidence"] >= DEFAULT_MIN_PROB)
            and (row["subtype_margin"] >= DEFAULT_MIN_MARGIN)
        )

        base_rows.append(row)

    base_df = pd.DataFrame(base_rows)

    log("Saving base-ID-level predictions")
    base_df.round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_baseid_all.csv",
        index=False,
        encoding="utf-8-sig",
    )
    base_df[base_df["high_confidence"]].round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_baseid_high_confidence.csv",
        index=False,
        encoding="utf-8-sig",
    )
    base_df[~base_df["high_confidence"]].round(6).to_csv(
        OUT_DIR / "subtype_predictions_90p_DNA_baseid_rejected.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary["n_baseid_rows"] = int(len(base_df))
    summary["n_high_conf_baseid"] = int(base_df["high_confidence"].sum())
    summary["n_rejected_baseid"] = int((~base_df["high_confidence"]).sum())

    # Base-ID metrics
    if has_subtype:
        log("Computing base-ID-level subtype metrics")

        y_true_sub_base = subtype_encoder.transform(base_df[SUBTYPE_COL].astype(str).values)
        y_pred_sub_base = subtype_encoder.transform(base_df["Pred_Subtype"].astype(str).values)

        base_sub_metrics_df, _ = save_metric_tables(
            y_true=y_true_sub_base,
            y_pred=y_pred_sub_base,
            class_names=subtype_classes,
            label_col=SUBTYPE_COL,
            prefix="subtype_90p_DNA_baseid",
        )

        summary["baseid_subtype_ACC"] = float(base_sub_metrics_df.loc[0, "ACC"])
        summary["baseid_subtype_WEIGHTED_F1"] = float(base_sub_metrics_df.loc[0, "WEIGHTED_F1"])
        summary["baseid_subtype_MACRO_F1"] = float(base_sub_metrics_df.loc[0, "MACRO_F1"])
        summary["baseid_subtype_MCC"] = float(base_sub_metrics_df.loc[0, "MCC"])

        with open(OUT_DIR / "classification_report_subtype_baseid.txt", "w", encoding="utf-8") as f:
            f.write(classification_report(
                y_true=base_df[SUBTYPE_COL].astype(str).values,
                y_pred=base_df["Pred_Subtype"].astype(str).values,
                zero_division=0,
                digits=4,
            ))

    if TYPE_COL in base_df.columns:
        log("Computing base-ID-level type metrics")

        true_type_base = base_df[TYPE_COL].astype(str).values
        pred_type_base = base_df["Pred_Type"].astype(str).values

        type_labels_base = sorted(set(true_type_base) | set(pred_type_base))
        type_to_id_base = {x: i for i, x in enumerate(type_labels_base)}

        y_true_type_base = np.array([type_to_id_base[x] for x in true_type_base], dtype=np.int64)
        y_pred_type_base = np.array([type_to_id_base[x] for x in pred_type_base], dtype=np.int64)

        base_type_metrics_df, _ = save_metric_tables(
            y_true=y_true_type_base,
            y_pred=y_pred_type_base,
            class_names=type_labels_base,
            label_col=TYPE_COL,
            prefix="type_90p_DNA_baseid_from_subtype",
        )

        summary["baseid_type_ACC"] = float(base_type_metrics_df.loc[0, "ACC"])
        summary["baseid_type_WEIGHTED_F1"] = float(base_type_metrics_df.loc[0, "WEIGHTED_F1"])
        summary["baseid_type_MACRO_F1"] = float(base_type_metrics_df.loc[0, "MACRO_F1"])
        summary["baseid_type_MCC"] = float(base_type_metrics_df.loc[0, "MCC"])

    pd.DataFrame([summary]).round(6).to_csv(
        OUT_DIR / "run_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    with open(OUT_DIR / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    log("============================================================")
    log("Done.")
    log("Main outputs:")
    log(str(OUT_DIR / "run_summary.csv"))
    log(str(OUT_DIR / "subtype_predictions_90p_DNA_fragment_all.csv"))
    log(str(OUT_DIR / "subtype_predictions_90p_DNA_baseid_all.csv"))
    log(str(OUT_DIR / "subtype_90p_DNA_fragment_overall_metrics.csv"))
    log(str(OUT_DIR / "subtype_90p_DNA_baseid_overall_metrics.csv"))
    log(str(OUT_DIR / "type_90p_DNA_fragment_from_subtype_overall_metrics.csv"))
    log(str(OUT_DIR / "type_90p_DNA_baseid_from_subtype_overall_metrics.csv"))
    log("============================================================")


if __name__ == "__main__":
    main()