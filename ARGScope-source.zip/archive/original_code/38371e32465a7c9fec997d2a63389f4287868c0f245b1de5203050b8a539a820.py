#!/usr/bin/env python3
# -*- coding: utf-8 -*-

r"""
Local Windows DNABERT-2 CLS embedding extraction for the 1:10 simulated DNA datasets.

IMPORTANT:
The DNABERT-2 scientific extraction definition is unchanged from the supplied script:

    * DNABERT-2-117M
    * native DNABERT-2 BPE tokenizer
    * full FASTA record; uppercase; U -> T
    * padding=True
    * truncation=True
    * max_length=512
    * final hidden layer first token / CLS:
          model_output[0][:, 0, :]
    * float32 inference
    * AMP disabled
    * output float32 [N, 768]
    * PyTorch attention fallback
    * initial batch size = 1024
    * 250,000 records per PT chunk
    * safe file-handle torch.save
    * flush + os.fsync
    * ZIP validation
    * torch.load verification
    * chunk-level resume

Only the input/output discovery was changed.

Expected layout:
    <SCRIPT_DIR>/
    |
    |-- extract_DNABERT2_CLS_110_dataset_WINDOWS.py
    |
    |-- 110_dataset/
    |   |-- fixed_30aa_90nt/
    |   |   `-- dna_90nt_5parts.fasta
    |   |
    |   |-- fixed_40aa_120nt/
    |   |   `-- dna_120nt_5parts.fasta
    |   |
    |   `-- fixed_50aa_150nt/
    |       `-- dna_150nt_5parts.fasta
    |
    `-- DNABERT-2-117M/          # optional local model directory

If DNABERT-2-117M is not present beside the script, the script falls back to:
    zhihan1996/DNABERT-2-117M
using the local Hugging Face cache when available.
"""

from __future__ import annotations

import os

_CPU_COUNT = os.cpu_count() or 1
os.environ.setdefault("TOKENIZERS_PARALLELISM", "true")
os.environ.setdefault("RAYON_NUM_THREADS", str(min(16, _CPU_COUNT)))
os.environ.setdefault("OMP_NUM_THREADS", str(min(8, _CPU_COUNT)))
os.environ.setdefault("MKL_NUM_THREADS", str(min(8, _CPU_COUNT)))

import argparse
import csv
import gc
import hashlib
import json
import time
import zipfile
from pathlib import Path
from typing import Any, Iterator

import torch
import transformers
from transformers import AutoModel, AutoTokenizer, BertConfig


SCRIPT_VERSION = "2026-08-18-local-DNABERT2-CLS-110-dataset-v2-autopath"

HF_MODEL_NAME = "zhihan1996/DNABERT-2-117M"
EMBEDDING_DIMENSION = 768
POOLING_NAME = "first_token_CLS"
IUPAC_DNA = frozenset("ACGTRYSWKMBDHVN")

SCRIPT_DIR = Path(__file__).resolve().parent

# Auto-detect whether the script itself is already inside 110_dataset.
# Case 1:
#   .../DNABERT_2-main/110_dataset/extract_*.py
#   -> input root = SCRIPT_DIR
#
# Case 2:
#   .../DNABERT_2-main/extract_*.py
#   -> input root = SCRIPT_DIR / "110_dataset"
if (
    (SCRIPT_DIR / "fixed_30aa_90nt").is_dir()
    or (SCRIPT_DIR / "fixed_40aa_120nt").is_dir()
    or (SCRIPT_DIR / "fixed_50aa_150nt").is_dir()
):
    DEFAULT_INPUT_ROOT = SCRIPT_DIR
else:
    DEFAULT_INPUT_ROOT = SCRIPT_DIR / "110_dataset"

# Prefer a DNABERT-2 local model beside the script.
# If the script is inside 110_dataset, also check its parent directory.
if (SCRIPT_DIR / "DNABERT-2-117M").is_dir():
    DEFAULT_MODEL_PATH = SCRIPT_DIR / "DNABERT-2-117M"
elif (SCRIPT_DIR.parent / "DNABERT-2-117M").is_dir():
    DEFAULT_MODEL_PATH = SCRIPT_DIR.parent / "DNABERT-2-117M"
else:
    # This non-existing path is intentional; the existing fallback logic
    # will then use zhihan1996/DNABERT-2-117M / Hugging Face cache.
    DEFAULT_MODEL_PATH = SCRIPT_DIR.parent / "DNABERT-2-117M"

# Put outputs next to the three input condition folders when the script
# itself is already inside 110_dataset.
DEFAULT_OUTPUT_ROOT = DEFAULT_INPUT_ROOT / "DNABERT2_CLS_embeddings"

CONDITION_ORDER = [
    "fixed_30aa_90nt",
    "fixed_40aa_120nt",
    "fixed_50aa_150nt",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract DNABERT-2 CLS embeddings for DNA FASTAs under 110_dataset."
        )
    )

    parser.add_argument(
        "--input-root",
        type=Path,
        default=DEFAULT_INPUT_ROOT,
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )

    parser.add_argument(
        "--model-path",
        type=Path,
        default=DEFAULT_MODEL_PATH,
        help=(
            "Optional fixed local DNABERT-2 directory. "
            "If absent, fall back to zhihan1996/DNABERT-2-117M."
        ),
    )

    parser.add_argument(
        "--model-name",
        default=HF_MODEL_NAME,
    )

    parser.add_argument(
        "--conditions",
        nargs="+",
        choices=CONDITION_ORDER,
        default=CONDITION_ORDER,
        help=(
            "Default runs all three conditions. "
            "Example: --conditions fixed_50aa_150nt"
        ),
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=1024,
        help=(
            "Initial local GPU batch size. "
            "Automatically halves after CUDA OOM."
        ),
    )

    parser.add_argument(
        "--records-per-chunk",
        type=int,
        default=1000_000,
    )

    parser.add_argument(
        "--max-token-length",
        type=int,
        default=512,
    )

    parser.add_argument(
        "--print-every",
        type=int,
        default=10_000,
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
    )

    parser.add_argument(
        "--skip-torch-load-verification",
        action="store_true",
        help=(
            "Skip full torch.load verification after saving. "
            "ZIP validation is still performed."
        ),
    )

    return parser.parse_args()


def find_dna_fasta(
    input_root: Path,
    condition: str,
) -> Path:
    folder = input_root / condition

    if not folder.is_dir():
        raise FileNotFoundError(
            f"Condition directory not found: {folder}"
        )

    matches = sorted(
        path
        for path in folder.glob("dna_*.fasta")
        if path.is_file()
    )

    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly one dna_*.fasta in {folder}; "
            f"found {len(matches)}: {[path.name for path in matches]}"
        )

    return matches[0]


def canonical_sequence(
    raw_sequence: str,
    sequence_id: str,
) -> str:
    sequence = raw_sequence.upper().replace("U", "T")

    if not sequence:
        raise ValueError(
            f"Empty DNA sequence: {sequence_id}"
        )

    invalid = sorted(
        set(sequence) - IUPAC_DNA
    )

    if invalid:
        raise ValueError(
            f"Invalid non-IUPAC DNA character(s) for "
            f"{sequence_id}: {invalid}"
        )

    return sequence


def fasta_iterator(
    path: Path,
) -> Iterator[tuple[str, str, str]]:

    header: str | None = None
    parts: list[str] = []

    with path.open(
        "r",
        encoding="utf-8-sig",
        errors="strict",
    ) as handle:

        for line_number, raw_line in enumerate(
            handle,
            start=1,
        ):
            line = raw_line.strip()

            if not line:
                continue

            if line.startswith(">"):

                if header is not None:
                    sequence_id = header.split()[0]
                    sequence = canonical_sequence(
                        "".join(parts),
                        sequence_id,
                    )

                    yield (
                        sequence_id,
                        header,
                        sequence,
                    )

                header = line[1:].strip()

                if not header:
                    raise ValueError(
                        f"Empty FASTA header at "
                        f"{path}:{line_number}"
                    )

                parts = []

            else:

                if header is None:
                    raise ValueError(
                        "Sequence before first FASTA header at "
                        f"{path}:{line_number}"
                    )

                parts.append(
                    "".join(
                        line.split()
                    )
                )

    if header is not None:
        sequence_id = header.split()[0]
        sequence = canonical_sequence(
            "".join(parts),
            sequence_id,
        )

        yield (
            sequence_id,
            header,
            sequence,
        )


def chunked_records(
    path: Path,
    records_per_chunk: int,
) -> Iterator[
    list[
        tuple[str, str, str]
    ]
]:

    records: list[
        tuple[str, str, str]
    ] = []

    for record in fasta_iterator(
        path
    ):
        records.append(
            record
        )

        if len(records) >= records_per_chunk:
            yield records
            records = []

    if records:
        yield records


def chunk_sha256(
    ids: list[str],
    headers: list[str],
    sequences: list[str],
) -> str:

    digest = hashlib.sha256()

    for sequence_id, header, sequence in zip(
        ids,
        headers,
        sequences,
    ):
        digest.update(
            sequence_id.encode("utf-8")
        )
        digest.update(b"\0")
        digest.update(
            header.encode("utf-8")
        )
        digest.update(b"\0")
        digest.update(
            sequence.encode("ascii")
        )
        digest.update(b"\0")

    return digest.hexdigest()


def atomic_json(
    path: Path,
    payload: dict[str, Any],
) -> None:

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def atomic_csv(
    path: Path,
    rows: list[
        dict[str, Any]
    ],
) -> None:

    if not rows:
        return

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=list(
                rows[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            rows
        )

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def gpu_memory_text() -> str:

    allocated = (
        torch.cuda.memory_allocated()
        / (1024 ** 3)
    )

    reserved = (
        torch.cuda.memory_reserved()
        / (1024 ** 3)
    )

    peak = (
        torch.cuda.max_memory_allocated()
        / (1024 ** 3)
    )

    total = (
        torch.cuda.get_device_properties(
            0
        ).total_memory
        / (1024 ** 3)
    )

    return (
        f"GPU alloc={allocated:.2f} GiB | "
        f"reserved={reserved:.2f} GiB | "
        f"peak={peak:.2f} GiB | "
        f"total={total:.2f} GiB"
    )


def resolve_model_source(
    model_path: Path,
    model_name: str,
) -> tuple[str, bool]:

    if model_path.is_dir():

        print(
            "Model source       : fixed local directory",
            flush=True,
        )

        print(
            f"Model directory    : {model_path}",
            flush=True,
        )

        return (
            str(model_path),
            True,
        )

    print(
        "Local fixed model directory was not found:",
        flush=True,
    )

    print(
        f"  {model_path}",
        flush=True,
    )

    print(
        "Falling back to Hugging Face/cache model: "
        f"{model_name}",
        flush=True,
    )

    return (
        model_name,
        False,
    )


def load_model(
    model_source: str,
    local_files_only: bool,
    device: torch.device,
):

    print(
        "\n===== LOAD DNABERT-2 =====",
        flush=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        model_source,
        trust_remote_code=True,
        local_files_only=local_files_only,
    )

    config = BertConfig.from_pretrained(
        model_source,
        local_files_only=local_files_only,
    )

    # Same compatibility setting as the supplied script.
    config.attention_probs_dropout_prob = 0.1

    model = AutoModel.from_pretrained(
        model_source,
        config=config,
        trust_remote_code=True,
        local_files_only=local_files_only,
    )

    model = (
        model
        .float()
        .to(device)
        .eval()
    )

    hidden_size = int(
        getattr(
            model.config,
            "hidden_size",
            EMBEDDING_DIMENSION,
        )
    )

    if hidden_size != EMBEDDING_DIMENSION:
        raise ValueError(
            "Expected hidden size "
            f"{EMBEDDING_DIMENSION}, "
            f"found {hidden_size}"
        )

    parameter_dtype = next(
        model.parameters()
    ).dtype

    if parameter_dtype != torch.float32:
        raise TypeError(
            "Expected float32 model parameters, "
            f"found {parameter_dtype}"
        )

    resolved_commit = getattr(
        model.config,
        "_commit_hash",
        None,
    )

    print(
        f"Model loaded       : {model_source}",
        flush=True,
    )
    print(
        f"Resolved commit    : {resolved_commit}",
        flush=True,
    )
    print(
        f"Hidden size        : {hidden_size}",
        flush=True,
    )
    print(
        "Tokenizer          : native DNABERT-2 BPE",
        flush=True,
    )
    print(
        "Truncation         : True",
        flush=True,
    )
    print(
        "Max token length   : 512",
        flush=True,
    )
    print(
        "Pooling            : first_token_CLS",
        flush=True,
    )
    print(
        "Pooling formula    : model_output[0][:, 0, :]",
        flush=True,
    )
    print(
        "Inference dtype    : float32; AMP disabled",
        flush=True,
    )
    print(
        "Attention backend  : PyTorch fallback",
        flush=True,
    )

    return (
        tokenizer,
        model,
        resolved_commit,
    )


def encode_batch(
    batch_sequences: list[str],
    tokenizer,
    model,
    device: torch.device,
    max_token_length: int,
) -> tuple[
    torch.Tensor,
    torch.Tensor,
    int,
]:

    encoded = tokenizer(
        batch_sequences,
        padding=True,
        truncation=True,
        max_length=max_token_length,
        return_attention_mask=True,
        return_tensors="pt",
    )

    attention_mask_cpu = encoded[
        "attention_mask"
    ]

    token_lengths = (
        attention_mask_cpu
        .sum(dim=1)
        .to(torch.long)
    )

    max_tokens = int(
        token_lengths.max()
    )

    encoded = {
        key: value.to(
            device,
            non_blocking=True,
        )
        for key, value
        in encoded.items()
    }

    with torch.inference_mode():

        hidden_states = (
            model(
                **encoded
            )[0]
            .float()
        )

        pooled = (
            hidden_states[
                :,
                0,
                :,
            ]
        )

    embeddings_cpu = (
        pooled
        .detach()
        .cpu()
        .float()
        .contiguous()
    )

    return (
        embeddings_cpu,
        token_lengths.contiguous(),
        max_tokens,
    )


def extract_chunk_embeddings(
    sequences: list[str],
    tokenizer,
    model,
    device: torch.device,
    initial_batch_size: int,
    max_token_length: int,
    print_every: int,
    chunk_started: float,
) -> tuple[
    torch.Tensor,
    torch.Tensor,
    int,
    int,
    int,
]:

    number = len(
        sequences
    )

    embeddings = torch.empty(
        (
            number,
            EMBEDDING_DIMENSION,
        ),
        dtype=torch.float32,
    )

    token_lengths = torch.empty(
        number,
        dtype=torch.long,
    )

    current_batch_size = min(
        initial_batch_size,
        number,
    )

    position = 0
    processed = 0
    successful_batches = 0
    oom_reductions = 0
    max_tokens_seen = 0
    next_print = print_every

    torch.cuda.reset_peak_memory_stats()

    while position < number:

        end = min(
            position
            + current_batch_size,
            number,
        )

        batch_sequences = sequences[
            position:end
        ]

        try:

            (
                batch_embeddings,
                batch_token_lengths,
                max_tokens,
            ) = encode_batch(
                batch_sequences=batch_sequences,
                tokenizer=tokenizer,
                model=model,
                device=device,
                max_token_length=max_token_length,
            )

        except torch.cuda.OutOfMemoryError:

            gc.collect()
            torch.cuda.empty_cache()

            if current_batch_size <= 1:
                raise RuntimeError(
                    "CUDA OOM even at batch size 1. "
                    f"FASTA index={position}"
                )

            old_batch_size = (
                current_batch_size
            )

            current_batch_size = max(
                1,
                current_batch_size // 2,
            )

            oom_reductions += 1

            print(
                "\n[CUDA OOM] batch "
                f"{old_batch_size:,} -> "
                f"{current_batch_size:,}; retrying.",
                flush=True,
            )

            continue

        count = (
            end - position
        )

        embeddings[
            position:end
        ] = batch_embeddings

        token_lengths[
            position:end
        ] = batch_token_lengths

        position = end
        processed += count
        successful_batches += 1

        max_tokens_seen = max(
            max_tokens_seen,
            max_tokens,
        )

        if (
            processed >= next_print
            or processed == number
        ):

            elapsed = (
                time.time()
                - chunk_started
            )

            speed = (
                processed / elapsed
                if elapsed > 0
                else 0.0
            )

            print(
                f"  encoded={processed:,}/{number:,} | "
                f"successful_batches={successful_batches:,} | "
                f"effective_batch={current_batch_size:,} | "
                f"last_batch={count:,} | "
                f"last_max_tokens={max_tokens} | "
                f"max_tokens_seen={max_tokens_seen} | "
                f"elapsed={elapsed/60.0:.2f} min | "
                f"speed={speed:,.2f} seq/s | "
                f"{gpu_memory_text()}",
                flush=True,
            )

            next_print = (
                (
                    processed
                    // print_every
                )
                + 1
            ) * print_every

        del (
            batch_embeddings,
            batch_token_lengths,
            batch_sequences,
        )

    return (
        embeddings.contiguous(),
        token_lengths.contiguous(),
        current_batch_size,
        oom_reductions,
        max_tokens_seen,
    )


def safe_torch_save(
    save_object: dict[str, Any],
    output_path: Path,
    expected_count: int,
    verify_torch_load: bool,
) -> None:

    temp_path = output_path.with_suffix(
        output_path.suffix + ".tmp"
    )

    if temp_path.exists():
        temp_path.unlink()

    try:

        with temp_path.open(
            "wb"
        ) as handle:

            torch.save(
                save_object,
                handle,
            )

            handle.flush()

            os.fsync(
                handle.fileno()
            )

        if not temp_path.is_file():
            raise RuntimeError(
                f"Temporary PT was not created: {temp_path}"
            )

        if temp_path.stat().st_size <= 0:
            raise RuntimeError(
                f"Temporary PT is empty: {temp_path}"
            )

        if not zipfile.is_zipfile(
            temp_path
        ):
            raise RuntimeError(
                "Saved PT does not contain a valid ZIP central directory:\n"
                f"  {temp_path}"
            )

        if verify_torch_load:

            try:
                verified = torch.load(
                    temp_path,
                    map_location="cpu",
                    weights_only=False,
                )
            except TypeError:
                verified = torch.load(
                    temp_path,
                    map_location="cpu",
                )

            if not isinstance(
                verified,
                dict,
            ):
                raise RuntimeError(
                    "Verified PT did not contain a dictionary."
                )

            if "embeddings" not in verified:
                raise RuntimeError(
                    "Verified PT is missing embeddings."
                )

            if "ids" not in verified:
                raise RuntimeError(
                    "Verified PT is missing ids."
                )

            verified_embeddings = verified[
                "embeddings"
            ]

            if tuple(
                verified_embeddings.shape
            ) != (
                expected_count,
                EMBEDDING_DIMENSION,
            ):
                raise RuntimeError(
                    "Verified embedding shape mismatch: "
                    f"{tuple(verified_embeddings.shape)} "
                    f"!= "
                    f"({expected_count}, {EMBEDDING_DIMENSION})"
                )

            if len(
                verified[
                    "ids"
                ]
            ) != expected_count:
                raise RuntimeError(
                    "Verified ID count mismatch."
                )

            del (
                verified_embeddings,
                verified,
            )

            gc.collect()

        os.replace(
            temp_path,
            output_path,
        )

    except Exception:

        if temp_path.exists():
            temp_path.unlink()

        raise


def completion_is_valid(
    output_path: Path,
    completion_path: Path,
    source_fasta: Path,
    expected_count: int,
    expected_chunk_sha256: str,
    model_identifier: str,
    model_commit: str | None,
    max_token_length: int,
) -> dict[str, Any] | None:

    if (
        not output_path.is_file()
        or not completion_path.is_file()
    ):
        return None

    try:

        if not zipfile.is_zipfile(
            output_path
        ):
            return None

        with completion_path.open(
            "r",
            encoding="utf-8",
        ) as handle:

            completion = json.load(
                handle
            )

        valid = (
            completion.get(
                "status"
            )
            == "COMPLETED"
            and completion.get(
                "script_version"
            )
            == SCRIPT_VERSION
            and int(
                completion.get(
                    "num_sequences",
                    -1,
                )
            )
            == expected_count
            and completion.get(
                "chunk_sha256"
            )
            == expected_chunk_sha256
            and completion.get(
                "model_identifier"
            )
            == model_identifier
            and completion.get(
                "model_commit"
            )
            == model_commit
            and completion.get(
                "pooling"
            )
            == POOLING_NAME
            and completion.get(
                "truncation"
            )
            is True
            and int(
                completion.get(
                    "max_token_length",
                    -1,
                )
            )
            == max_token_length
            and int(
                completion.get(
                    "embedding_dimension",
                    -1,
                )
            )
            == EMBEDDING_DIMENSION
            and completion.get(
                "embedding_dtype"
            )
            == "float32"
            and completion.get(
                "inference_dtype"
            )
            == "float32"
            and int(
                completion.get(
                    "source_size_bytes",
                    -1,
                )
            )
            == source_fasta.stat().st_size
            and int(
                completion.get(
                    "source_mtime_ns",
                    -1,
                )
            )
            == source_fasta.stat().st_mtime_ns
            and int(
                completion.get(
                    "output_size_bytes",
                    -1,
                )
            )
            == output_path.stat().st_size
        )

        return (
            completion
            if valid
            else None
        )

    except Exception:
        return None


def process_fasta(
    condition: str,
    fasta_path: Path,
    output_root: Path,
    tokenizer,
    model,
    device: torch.device,
    model_identifier: str,
    model_commit: str | None,
    args: argparse.Namespace,
) -> dict[str, Any]:

    output_dir = (
        output_root
        / condition
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    manifest_path = (
        output_dir
        / "DNABERT2_embedding_manifest.csv"
    )

    summary_path = (
        output_dir
        / "DNABERT2_embedding_summary.json"
    )

    print(
        "\n" + "=" * 118,
        flush=True,
    )
    print(
        f"CONDITION: {condition}",
        flush=True,
    )
    print(
        "=" * 118,
        flush=True,
    )
    print(
        f"DNA FASTA          : {fasta_path}",
        flush=True,
    )
    print(
        f"Output directory   : {output_dir}",
        flush=True,
    )

    manifest_rows: list[
        dict[str, Any]
    ] = []

    total_records = 0
    total_bases = 0
    computed_chunks = 0
    resumed_chunks = 0

    sample_started = time.time()

    for chunk_index, records in enumerate(
        chunked_records(
            fasta_path,
            args.records_per_chunk,
        ),
        start=1,
    ):

        chunk_started = time.time()

        ids = [
            record[0]
            for record
            in records
        ]

        headers = [
            record[1]
            for record
            in records
        ]

        sequences = [
            record[2]
            for record
            in records
        ]

        nt_lengths = [
            len(sequence)
            for sequence
            in sequences
        ]

        digest = chunk_sha256(
            ids,
            headers,
            sequences,
        )

        output_path = (
            output_dir
            / (
                f"{condition}"
                f"_chunk_{chunk_index:06d}"
                "_dnabert2_CLS.pt"
            )
        )

        completion_path = (
            output_path.with_suffix(
                ".complete.json"
            )
        )

        print(
            f"[CHUNK {chunk_index:06d}] "
            f"encoding {len(ids):,} sequences | "
            f"DNA={min(nt_lengths)}-{max(nt_lengths)} nt | "
            f"chunk_sha256={digest[:16]}...",
            flush=True,
        )

        existing = None

        if not args.overwrite:

            existing = completion_is_valid(
                output_path=output_path,
                completion_path=completion_path,
                source_fasta=fasta_path,
                expected_count=len(ids),
                expected_chunk_sha256=digest,
                model_identifier=model_identifier,
                model_commit=model_commit,
                max_token_length=args.max_token_length,
            )

        if existing is not None:

            token_min = int(
                existing[
                    "minimum_token_length"
                ]
            )

            token_max = int(
                existing[
                    "maximum_token_length"
                ]
            )

            effective_batch = int(
                existing.get(
                    "final_effective_batch_size",
                    args.batch_size,
                )
            )

            oom_reductions = int(
                existing.get(
                    "oom_batch_reductions",
                    0,
                )
            )

            status = (
                "RESUMED_VALID_EXISTING"
            )

            resumed_chunks += 1

            print(
                f"[CHUNK {chunk_index:06d}] "
                "resumed valid existing PT",
                flush=True,
            )

        else:

            (
                embeddings,
                token_lengths,
                effective_batch,
                oom_reductions,
                max_tokens_seen,
            ) = extract_chunk_embeddings(
                sequences=sequences,
                tokenizer=tokenizer,
                model=model,
                device=device,
                initial_batch_size=args.batch_size,
                max_token_length=args.max_token_length,
                print_every=args.print_every,
                chunk_started=chunk_started,
            )

            token_min = int(
                token_lengths.min()
            )

            token_max = int(
                token_lengths.max()
            )

            embedding_shape = tuple(
                embeddings.shape
            )

            save_object = {
                "ids": ids,
                "headers": headers,
                "sequence_lengths": torch.tensor(
                    nt_lengths,
                    dtype=torch.long,
                ),
                "token_lengths": token_lengths,
                "embeddings": embeddings,
                "source_fasta": str(
                    fasta_path
                ),
                "condition": condition,
                "model_identifier": model_identifier,
                "model_commit": model_commit,
                "tokenizer": "native_DNABERT2_BPE",
                "pooling": POOLING_NAME,
                "pooling_formula": "model_output[0][:, 0, :]",
                "truncation": True,
                "max_token_length": int(
                    args.max_token_length
                ),
                "attention_backend": "pytorch_fallback_eval_mode",
                "inference_dtype": "float32",
                "embedding_dtype": "float32",
                "embedding_dim": EMBEDDING_DIMENSION,
                "chunk_index": int(
                    chunk_index
                ),
                "num_sequences": int(
                    len(ids)
                ),
                "chunk_sha256": digest,
                "script_version": SCRIPT_VERSION,
                "initial_batch_size": int(
                    args.batch_size
                ),
                "final_effective_batch_size": int(
                    effective_batch
                ),
                "oom_batch_reductions": int(
                    oom_reductions
                ),
            }

            print(
                f"[CHUNK {chunk_index:06d}] "
                "saving with safe file-handle method...",
                flush=True,
            )

            safe_torch_save(
                save_object=save_object,
                output_path=output_path,
                expected_count=len(ids),
                verify_torch_load=(
                    not args.skip_torch_load_verification
                ),
            )

            output_size = (
                output_path.stat().st_size
            )

            completion = {
                "status": "COMPLETED",
                "script_version": SCRIPT_VERSION,
                "condition": condition,
                "chunk_index": int(
                    chunk_index
                ),
                "num_sequences": int(
                    len(ids)
                ),
                "chunk_sha256": digest,
                "model_identifier": model_identifier,
                "model_commit": model_commit,
                "source_fasta": str(
                    fasta_path
                ),
                "source_size_bytes": (
                    fasta_path.stat().st_size
                ),
                "source_mtime_ns": (
                    fasta_path.stat().st_mtime_ns
                ),
                "pooling": POOLING_NAME,
                "truncation": True,
                "max_token_length": int(
                    args.max_token_length
                ),
                "embedding_dimension": EMBEDDING_DIMENSION,
                "embedding_dtype": "float32",
                "inference_dtype": "float32",
                "minimum_DNA_length": min(
                    nt_lengths
                ),
                "maximum_DNA_length": max(
                    nt_lengths
                ),
                "minimum_token_length": token_min,
                "maximum_token_length": token_max,
                "maximum_tokens_seen": int(
                    max_tokens_seen
                ),
                "initial_batch_size": int(
                    args.batch_size
                ),
                "final_effective_batch_size": int(
                    effective_batch
                ),
                "oom_batch_reductions": int(
                    oom_reductions
                ),
                "output_size_bytes": output_size,
                "zip_validation": True,
                "torch_load_validation": (
                    not args.skip_torch_load_verification
                ),
                "safe_file_handle_save": True,
                "elapsed_seconds": round(
                    time.time()
                    - chunk_started,
                    4,
                ),
            }

            atomic_json(
                completion_path,
                completion,
            )

            status = "COMPUTED"
            computed_chunks += 1

            print(
                f"[CHUNK {chunk_index:06d}] SAVED + VERIFIED | "
                f"shape={embedding_shape} | "
                f"size={output_size/(1024**3):.3f} GiB | "
                f"tokens={token_min}-{token_max} | "
                f"effective_batch={effective_batch:,} | "
                f"OOM reductions={oom_reductions} | "
                f"time={(time.time()-chunk_started)/60.0:.2f} min",
                flush=True,
            )

            del (
                save_object,
                embeddings,
                token_lengths,
            )

            gc.collect()
            torch.cuda.empty_cache()

        total_records += len(
            ids
        )

        total_bases += sum(
            nt_lengths
        )

        manifest_rows.append(
            {
                "condition": condition,
                "chunk_index": chunk_index,
                "output_file": output_path.name,
                "completion_file": completion_path.name,
                "num_sequences": len(
                    ids
                ),
                "first_id": ids[0],
                "last_id": ids[-1],
                "chunk_sha256": digest,
                "minimum_DNA_length": min(
                    nt_lengths
                ),
                "maximum_DNA_length": max(
                    nt_lengths
                ),
                "minimum_token_length": token_min,
                "maximum_token_length": token_max,
                "initial_batch_size": args.batch_size,
                "final_effective_batch_size": effective_batch,
                "oom_batch_reductions": oom_reductions,
                "output_size_bytes": output_path.stat().st_size,
                "status": status,
            }
        )

        atomic_csv(
            manifest_path,
            manifest_rows,
        )

        del (
            records,
            ids,
            headers,
            sequences,
            nt_lengths,
        )

        gc.collect()

    summary = {
        "status": "COMPLETED",
        "script_version": SCRIPT_VERSION,
        "condition": condition,
        "input_fasta": str(
            fasta_path
        ),
        "input_size_bytes": fasta_path.stat().st_size,
        "model_identifier": model_identifier,
        "model_commit": model_commit,
        "output_directory": str(
            output_dir
        ),
        "total_fasta_records": total_records,
        "total_nucleotide_bases": total_bases,
        "number_of_pt_chunks": len(
            manifest_rows
        ),
        "records_per_chunk": args.records_per_chunk,
        "newly_computed_chunks": computed_chunks,
        "resumed_existing_chunks": resumed_chunks,
        "embedding_dimension": EMBEDDING_DIMENSION,
        "embedding_dtype": "float32",
        "tokenizer": "native_DNABERT2_BPE",
        "pooling": POOLING_NAME,
        "pooling_formula": "model_output[0][:, 0, :]",
        "truncation": True,
        "max_token_length": args.max_token_length,
        "attention_backend": "pytorch_fallback_eval_mode",
        "inference_dtype": "float32",
        "safe_file_handle_save": True,
        "elapsed_minutes": round(
            (
                time.time()
                - sample_started
            )
            / 60.0,
            4,
        ),
    }

    atomic_json(
        summary_path,
        summary,
    )

    print(
        f"\nCompleted {condition}: "
        f"{total_records:,} sequences",
        flush=True,
    )

    return summary


def main() -> None:

    args = parse_args()

    input_root = (
        args.input_root
        .expanduser()
        .resolve()
    )

    output_root = (
        args.output_root
        .expanduser()
        .resolve()
    )

    requested_model_path = (
        args.model_path
        .expanduser()
        .resolve()
    )

    if not input_root.is_dir():
        raise NotADirectoryError(
            f"Input root not found: {input_root}"
        )

    if args.records_per_chunk < 1:
        raise ValueError(
            "--records-per-chunk must be positive"
        )

    if args.batch_size < 1:
        raise ValueError(
            "--batch-size must be positive"
        )

    if args.print_every < 1:
        raise ValueError(
            "--print-every must be positive"
        )

    if args.max_token_length != 512:
        raise ValueError(
            "--max-token-length must be exactly 512 "
            "to match the current ARGScope DNA setup."
        )

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU is unavailable. CPU fallback is disabled."
        )

    conditions = list(
        dict.fromkeys(
            args.conditions
        )
    )

    datasets = [
        (
            condition,
            find_dna_fasta(
                input_root,
                condition,
            ),
        )
        for condition
        in conditions
    ]

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    device = torch.device(
        "cuda:0"
    )

    print(
        "=" * 118,
        flush=True,
    )
    print(
        "LOCAL DNABERT-2 CLS EXTRACTION -- 1:10 SIMULATED DNA DATASETS",
        flush=True,
    )
    print(
        "=" * 118,
        flush=True,
    )

    print(
        f"Script version     : {SCRIPT_VERSION}",
        flush=True,
    )
    print(
        f"Input root         : {input_root}",
        flush=True,
    )
    print(
        f"Output root        : {output_root}",
        flush=True,
    )
    print(
        f"Conditions         : {conditions}",
        flush=True,
    )
    print(
        "Input DNA FASTAs   :",
        flush=True,
    )

    for condition, path in datasets:
        print(
            f"  {condition}: {path.name}",
            flush=True,
        )

    print(
        f"Initial batch size : {args.batch_size:,}",
        flush=True,
    )
    print(
        f"Records per chunk  : {args.records_per_chunk:,}",
        flush=True,
    )
    print(
        "Max token length   : 512",
        flush=True,
    )
    print(
        "Truncation         : True",
        flush=True,
    )
    print(
        "Pooling            : first_token_CLS",
        flush=True,
    )
    print(
        "Pooling formula    : model_output[0][:, 0, :]",
        flush=True,
    )
    print(
        "Inference dtype    : float32; AMP disabled",
        flush=True,
    )
    print(
        "Safe PT saving     : file handle + fsync + ZIP verify",
        flush=True,
    )
    print(
        f"Full load verify   : "
        f"{not args.skip_torch_load_verification}",
        flush=True,
    )
    print(
        f"PyTorch            : {torch.__version__}",
        flush=True,
    )
    print(
        f"Transformers       : {transformers.__version__}",
        flush=True,
    )
    print(
        f"GPU                : {torch.cuda.get_device_name(0)}",
        flush=True,
    )
    print(
        "GPU memory         : "
        f"{torch.cuda.get_device_properties(0).total_memory/(1024**3):.2f} GiB",
        flush=True,
    )

    (
        model_source,
        local_files_only,
    ) = resolve_model_source(
        requested_model_path,
        args.model_name,
    )

    (
        tokenizer,
        model,
        model_commit,
    ) = load_model(
        model_source=model_source,
        local_files_only=local_files_only,
        device=device,
    )

    if local_files_only:

        model_identifier = (
            f"local::{requested_model_path}"
        )

    else:

        model_identifier = (
            f"hf::{args.model_name}"
        )

    environment_manifest = {
        "script_version": SCRIPT_VERSION,
        "input_root": str(
            input_root
        ),
        "conditions": conditions,
        "input_dna_fastas": {
            condition: str(path)
            for condition, path
            in datasets
        },
        "model_identifier": model_identifier,
        "model_commit": model_commit,
        "requested_local_model_path": str(
            requested_model_path
        ),
        "local_model_used": bool(
            local_files_only
        ),
        "hf_model_name": args.model_name,
        "pooling": POOLING_NAME,
        "pooling_formula": "model_output[0][:, 0, :]",
        "truncation": True,
        "max_token_length": 512,
        "records_per_chunk": args.records_per_chunk,
        "inference_dtype": "float32",
        "embedding_dtype": "float32",
        "safe_file_handle_save": True,
        "zip_validation": True,
        "torch_load_validation": (
            not args.skip_torch_load_verification
        ),
        "torch_version": torch.__version__,
        "transformers_version": transformers.__version__,
        "torch_cuda_version": torch.version.cuda,
        "gpu_name": torch.cuda.get_device_name(0),
    }

    atomic_json(
        output_root
        / "DNABERT2_CLS_environment_manifest.json",
        environment_manifest,
    )

    all_started = time.time()

    summaries = []

    for condition, fasta_path in datasets:

        summaries.append(
            process_fasta(
                condition=condition,
                fasta_path=fasta_path,
                output_root=output_root,
                tokenizer=tokenizer,
                model=model,
                device=device,
                model_identifier=model_identifier,
                model_commit=model_commit,
                args=args,
            )
        )

    overall = {
        "status": "COMPLETED",
        "script_version": SCRIPT_VERSION,
        "number_of_conditions": len(
            datasets
        ),
        "conditions": conditions,
        "total_sequences": sum(
            item[
                "total_fasta_records"
            ]
            for item
            in summaries
        ),
        "total_PT_chunks": sum(
            item[
                "number_of_pt_chunks"
            ]
            for item
            in summaries
        ),
        "records_per_chunk": args.records_per_chunk,
        "model_identifier": model_identifier,
        "model_commit": model_commit,
        "pooling": POOLING_NAME,
        "truncation": True,
        "max_token_length": 512,
        "safe_file_handle_save": True,
        "elapsed_minutes": round(
            (
                time.time()
                - all_started
            )
            / 60.0,
            4,
        ),
        "condition_summaries": summaries,
    }

    overall_path = (
        output_root
        / "all_110_dataset_CLS_embedding_summary.json"
    )

    atomic_json(
        overall_path,
        overall,
    )

    print(
        "\n" + "#" * 118,
        flush=True,
    )
    print(
        "ALL SELECTED 1:10 DNA DATASETS COMPLETED",
        flush=True,
    )
    print(
        "#" * 118,
        flush=True,
    )
    print(
        f"Total sequences : {overall['total_sequences']:,}",
        flush=True,
    )
    print(
        f"Total PT chunks : {overall['total_PT_chunks']:,}",
        flush=True,
    )
    print(
        f"Elapsed minutes : {overall['elapsed_minutes']}",
        flush=True,
    )
    print(
        f"Overall summary : {overall_path}",
        flush=True,
    )


if __name__ == "__main__":
    main()
