"""Large-type, tightly cropped 100% type heatmaps for Figure 2C and 3C."""
from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.text import Text
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import pandas as pd
from PIL import Image

HERE=Path(__file__).resolve().parent
ROOT=Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW")
OUT=HERE/"outputs"/"argscope_subtype_argonly_20260922"/"heatmaps"
DEST=Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\ARG_100pct_Type_heatmaps_large_font_20260922")
MODELS={"Protein":["ARGNet","DeepARG","PLM-ARG","FunGeneTyper","ARGScope"],
        "DNA":["ARGNet","DeepARG","ARGScope"]}
ORDER=["beta_lactam","trimethoprim","macrolide-lincosamide-streptogramin","fusidic_acid","fosfomycin",
       "aminoglycoside","quinolone","multidrug","vancomycin","chloramphenicol","florfenicol","rifamycin",
       "tetracycline","other_peptide_antibiotics","bacitracin","sulfonamide","tetracenomycin_C","novobiocin",
       "tunicamycin","streptothricin","polymyxin","bleomycin","puromycin"]
METRICS=["Precision","Recall","F1"]


def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):
            h.update(block)
    return h.hexdigest()


def draw(modality):
    models=MODELS[modality]
    source=ROOT/modality/"04_Per_Type_ARGScope23_display_view.csv"
    average_source=ROOT/modality/"02_Type_overall_macro_weighted_micro.csv"
    per=pd.read_csv(source)
    sub=per[per.Completeness.eq(100)].copy()
    assert sub.Scope.eq("ARG_only").all() and sub.N_labels_averaged.eq(23).all()
    assert len(sub)==23*len(models)
    for model in models:
        assert set(sub[sub.Model.eq(model)].Type)==set(ORDER)
    avg=pd.read_csv(average_source)
    avg=avg[avg.Completeness.eq(100)&avg.Average.eq("macro")].set_index("Model")
    own=sub[sub.Model.eq("ARGScope")].set_index("Type")
    shown=[]
    for typ in ORDER:
        other=sub[(sub.Type==typ)&(sub.Model!="ARGScope")]
        if own.loc[typ,METRICS].sum()==0 or other[METRICS].fillna(0).to_numpy().sum()==0:
            continue
        shown.append(typ)
    previous=pd.read_csv(ROOT/"figures_Type_ARG_only"/"heatmap_display_source.csv")
    previous=previous[(previous.Modality==modality)&(previous.Completeness==100)]
    assert set(shown)==set(previous.Type)
    labels=own.Type_display.to_dict()
    labels.update({"aminoglycoside":"Aminoglycosides","tetracycline":"Tetracyclines"})
    # Independently validate all 23-class cell values against TP/FP/FN counts.
    for field,num,den in [("Precision",sub.TP,sub.TP+sub.FP),
                          ("Recall",sub.TP,sub.TP+sub.FN),
                          ("F1",2*sub.TP,2*sub.TP+sub.FP+sub.FN)]:
        expected=np.divide(num,den,out=np.zeros(len(sub)),where=den.to_numpy()!=0)
        np.testing.assert_allclose(sub[field],expected,atol=1e-12,rtol=0)
        for model in models:
            np.testing.assert_allclose(float(avg.loc[model,field]),sub[sub.Model.eq(model)][field].mean(),atol=1e-12,rtol=0)
    n,nmod=len(shown),len(models)
    cell_w,cell_h=.55,.30
    left,bottom,top=1.79,1.22,.34
    gap,average_gap,color_gap,color_w,right=.135,.20,.14,.10,.49
    panel_w=nmod*cell_w
    heat_h=n*cell_h
    total_h=heat_h+average_gap+cell_h
    width=left+3*panel_w+2*gap+color_gap+color_w+right
    height=bottom+total_h+top
    fig=plt.figure(figsize=(width,height))
    fig.patch.set_alpha(0)
    cmap=plt.get_cmap("Blues" if modality=="Protein" else "Oranges")
    source_records=[]
    annotation_artists=[]
    axes=[]
    def axis_rect(x,y,w,h):
        return [x/width,y/height,w/width,h/height]
    for k,metric in enumerate(METRICS):
        x=left+k*(panel_w+gap)
        ax=fig.add_axes(axis_rect(x,bottom,panel_w,heat_h))
        axav=fig.add_axes(axis_rect(x,bottom+heat_h+average_gap,panel_w,cell_h))
        axes.extend([ax,axav])
        vals=np.array([[float(sub[(sub.Type==typ)&(sub.Model==model)].iloc[0][metric])
                        for model in models] for typ in shown])
        averages=np.array([[float(avg.loc[model,metric]) for model in models]])
        for a,arr,is_avg in [(ax,vals,False),(axav,averages,True)]:
            im=a.imshow(arr,cmap=cmap,vmin=0,vmax=1,aspect="auto",interpolation="nearest",rasterized=False)
            a.set_xticks(np.arange(nmod+1)-.5,minor=True)
            a.set_yticks(np.arange(arr.shape[0]+1)-.5,minor=True)
            a.grid(which="minor",color="white",linewidth=.8)
            a.tick_params(which="both",length=0)
            for spine in a.spines.values():
                spine.set_visible(False)
            for (i,j),v in np.ndenumerate(arr):
                rgb=np.array(cmap(v)[:3])
                linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
                luminance=float(linear@np.array([.2126,.7152,.0722]))
                color="white" if luminance<.20 else "#20282E"
                text=a.text(j,i,f"{v:.4f}",ha="center",va="center",fontsize=10.5,color=color)
                annotation_artists.append((a,text,j,i))
                source_records.append(dict(Modality=modality,Completeness=100,Metric=metric,
                    Type="Average" if is_avg else shown[i],Model=models[j],Value=float(v),
                    Source=str(average_source if is_avg else source),Scope="ARG_only"))
        axav.set_title(metric,fontsize=15,pad=7)
        axav.set_xticks([])
        axav.set_yticks([0],["Average"] if k==0 else [""],fontsize=13)
        ax.set_yticks(range(n),[labels[t] for t in shown] if k==0 else [""]*n,fontsize=13)
        ax.tick_params(axis="y",pad=6)
        ax.set_xticks(range(nmod),models,rotation=55,ha="right",rotation_mode="anchor",fontsize=12)
        ax.tick_params(axis="x",pad=4)
        for tick in ax.get_xticklabels():
            if tick.get_text()=="ARGScope":
                tick.set_color("#AD4635")
                tick.set_fontweight("bold")
    cax=fig.add_axes(axis_rect(left+3*panel_w+2*gap+color_gap,bottom,color_w,total_h))
    cb=fig.colorbar(im,cax=cax,ticks=[0,.25,.5,.75,1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter("%.4f"))
    cb.ax.tick_params(labelsize=10.5,length=2,width=.5,pad=3)
    cb.outline.set_linewidth(.5)
    # imshow is replaced by vector cell rectangles in the final SVG/PDF below.
    from matplotlib.patches import Rectangle
    for a in axes:
        arr=np.array(a.images[0].get_array())
        a.images[0].remove()
        for (i,j),v in np.ndenumerate(arr):
            a.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=cmap(float(v)),edgecolor="white",lw=.8,zorder=0))
        a.set_xlim(-.5,nmod-.5)
        a.set_ylim(arr.shape[0]-.5,-.5)
    cb.solids.set_rasterized(False)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for a,text,j,i in annotation_artists:
        box=text.get_window_extent(renderer)
        corners=a.transData.transform([[j-.5,i-.5],[j+.5,i+.5]])
        assert box.x0>corners[:,0].min() and box.x1<corners[:,0].max(),text.get_text()
        assert box.y0>corners[:,1].min() and box.y1<corners[:,1].max(),text.get_text()
    for artist in fig.findobj(match=Text):
        if artist.get_visible() and artist.get_text():
            assert artist.get_fontfamily()==["Arial"]
    plotted=pd.DataFrame(source_records)
    actual=plotted[plotted.Type.ne("Average")].merge(previous,on=["Modality","Completeness","Metric","Type","Model"],suffixes=("_new","_old"),validate="one_to_one")
    assert len(actual)==len(previous)
    np.testing.assert_allclose(actual.Value_new,actual.Value_old,atol=1e-12,rtol=0)
    stem="Figure2C_Protein_100pct_Type_heatmap_large_font" if modality=="Protein" else "Figure3C_DNA_100pct_Type_heatmap_large_font"
    for ext in ["svg","png","pdf"]:
        fig.savefig(OUT/f"{stem}.{ext}",dpi=600,bbox_inches="tight",pad_inches=0,
                    facecolor="none",edgecolor="none",transparent=True)
    root=ET.parse(OUT/f"{stem}.svg").getroot()
    assert not root.findall(".//{http://www.w3.org/2000/svg}image")
    with Image.open(OUT/f"{stem}.png") as image:
        pixels=np.asarray(image.convert("RGBA"))
        assert pixels[0,0,3]==0
        ys,xs=np.where(pixels[:,:,3]>0)
        margins=[int(xs.min()),int(ys.min()),int(pixels.shape[1]-1-xs.max()),int(pixels.shape[0]-1-ys.max())]
        assert max(margins)<32,(stem,margins)
        shape=list(image.size)
    plt.close(fig)
    plotted.to_csv(OUT/"plot_data"/f"{modality}_heatmap_values.csv",index=False)
    return dict(modality=modality,stem=stem,shown_types=shown,averaged_types=23,values_unchanged=True,
        values_checked_against_TP_FP_FN=True,cell_font_pt=10.5,type_font_pt=13,model_font_pt=12,
        metric_font_pt=15,old_cell_font_pt=6.3 if modality=="Protein" else 7,
        outer_padding_inches=0,transparent_background=True,detected_empty_margin_pixels=margins,png_size=shape,png_dpi=600,
        source_sha256=sha(source),average_source_sha256=sha(average_source),vector_svg=True)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/"plot_data").mkdir(exist_ok=True)
    font_manager.findfont("Arial",fallback_to_default=False)
    plt.rcParams.update({"font.family":"Arial","svg.fonttype":"none","pdf.fonttype":42,
                         "savefig.facecolor":"white","text.color":"#20282E"})
    audits=[draw(mod) for mod in ["Protein","DNA"]]
    (OUT/"plot_data"/"verification.json").write_text(json.dumps(audits,ensure_ascii=False,indent=2),encoding="utf-8")
    shutil.copy2(__file__,OUT/"plot_data"/Path(__file__).name)
    for destination in [DEST,ROOT/"Subtype_ARGonly_20260922"/"heatmaps"]:
        shutil.copytree(OUT,destination,dirs_exist_ok=True)
    print(json.dumps(audits,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
