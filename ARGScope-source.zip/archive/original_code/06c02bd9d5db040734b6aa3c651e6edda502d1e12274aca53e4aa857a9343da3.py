"""Create a new source-derived supplement; leave the supplied DOCX unchanged."""
import csv
import copy
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as ET

ROOT = Path(__file__).resolve().parent
SOURCE = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary materials.docx')
DEST = ROOT / 'Supplementary_materials_recalculated.docx'
QA = ROOT / 'document_qa'
QA.mkdir(exist_ok=True)
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
def e(tag, **attrs):
    return ET.Element('{%s}%s' % (W, tag), {'{%s}%s' % (W, k): str(v) for k, v in attrs.items()})
def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

tables = [
 (1,'Protein','ARGScope','ARG_nonARG'), (2,'Protein','ARGScope','Type'),
 (3,'Protein','ARGScope','Subtype'), (4,'DNA','ARGScope','ARG_nonARG'),
 (5,'DNA','ARGScope','Type'), (6,'DNA','ARGScope','Subtype'),
 (7,'Protein','ARGNet','ARG_nonARG'), (8,'Protein','ARGNet','Type'),
 (9,'DNA','ARGNet','ARG_nonARG'), (10,'DNA','ARGNet','Type'),
 (11,'Protein','FunGeneTyper','ARG_nonARG'), (12,'Protein','FunGeneTyper','Type'),
 (13,'Protein','PLM-ARG','ARG_nonARG'), (14,'Protein','PLM-ARG','Type'),
 (15,'Protein','DeepARG','ARG_nonARG'), (16,'Protein','DeepARG','Type'),
 (17,'DNA','DeepARG','ARG_nonARG'), (18,'DNA','DeepARG','Type')]
metrics = ['Accuracy','Precision','Recall','F1','MCC']
avg_order = {'ARG_positive':0,'macro':1,'weighted':2,'micro':3}
data = []
for mod in ['Protein','DNA']:
    for name in ['02_Type_overall_macro_weighted_micro.csv',
                 '05_ARG_nonARG_ARG_positive_five_metrics.csv',
                 '06_ARG_nonARG_macro_weighted_micro.csv']:
        data += rows(ROOT/mod/name)
# Preserve the original subtype evaluation population; the requested change is Type only.
data += [r for r in rows(ROOT/'supplementary_check'/'05_current_including_nonARG_REFERENCE_ONLY.csv')
         if r['Level']=='Subtype' and r['Model']=='ARGScope']

source_bytes=SOURCE.read_bytes()
source_hash=hashlib.sha256(source_bytes).hexdigest()
with ZipFile(SOURCE) as z:
    package={x.filename:z.read(x.filename) for x in z.infolist()}
    infos=z.infolist()
tree=ET.fromstring(package['word/document.xml'])
body=tree.find('w:body',NS)
sect=copy.deepcopy(body.find('w:sectPr',NS))
template_table=copy.deepcopy(body.findall('w:tbl',NS)[1])
template_caption=copy.deepcopy(next(p for p in body.findall('w:p',NS)
    if ''.join(p.itertext()).startswith('Table 2.')))
inventory={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
              'role':'editable' if n=='word/document.xml' else 'preserve-only'} for n,b in package.items()}
(QA/'reference_package_inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
(QA/'artifact.md').write_text(f'''# Supplement reference and edit contract
Reference: {SOURCE}
SHA256: {source_hash}
Single A4 portrait section, 210.0086 x 297.0036 mm, top/bottom margins 25.4 mm,
left/right margins 31.75 mm. No headers, footers, images, content controls or fields.
Source has title, eighteen table captions and eighteen tables; all body content is in scope.
Table 2 is the source pattern: centered numerical entries, black three-line table,
Times New Roman / 11 pt table text. Original table numbering remains 1-14.
Editable slots: word/document.xml / body title, table captions, table rows and notes.
Binary tables require an Average column; repeated Class column is removed
because classification level is explicit in each caption. The seven-column grid is
8200 twips wide and fits the original printable width. All 18 tables use the same pattern.
Each table begins a new page to keep all completeness levels together. Definition page added.
All other ZIP parts and all relationships remain byte-identical. Section geometry retained.
Source template has no other distinct section or recurring page pattern.
Full source rendering attempted with packaged renderer: unavailable because soffice.exe
is absent. Source layout above is OOXML-inspected, not visually certified.
Final must be numerically read back and rendered if a functioning Word renderer is available.
''',encoding='utf-8')

for child in list(body): body.remove(child)
def paragraph(text, size=11, bold=False, center=False, pagebreak=False, keep=False, after=100):
    p=e('p'); pr=e('pPr'); p.append(pr)
    pr.append(e('jc',val='center' if center else 'left'))
    pr.append(e('spacing',after=after,line=260,lineRule='auto'))
    if pagebreak: pr.append(e('pageBreakBefore'))
    if keep: pr.append(e('keepNext'))
    r=e('r'); rp=e('rPr'); r.append(rp)
    rp.append(e('rFonts',ascii='Times New Roman',hAnsi='Times New Roman',eastAsia='Times New Roman'))
    rp.append(e('sz',val=int(size*2)))
    if bold: rp.append(e('b'))
    t=e('t'); t.text=text; r.append(t); p.append(r)
    return p

body.append(paragraph('Supplementary Material',16,True,True,after=260))
body.append(paragraph('Evaluation definitions',12,True,after=160))
definitions=[
 'Results are reported at 60%, 70%, 80%, 90% and 100% sequence completeness using the available prediction files for each model. ARGScope-AA and ARGScope-NT denote the protein and DNA models, respectively. Values are rounded to four decimal places after calculation.',
 'Resistance-type evaluation uses the same fixed set of 23 ARGScope types for every model and completeness level. Only sequences whose reference Type belongs to this set are evaluated; reference nonARG and other reference types are excluded. Predictions of nonARG, unmapped labels or types outside this set remain errors. All 23 types enter macro, weighted and micro calculations, including zero-scoring and absent types.',
 'ACC is the fraction of evaluated sequences assigned the exact reference label. MCC is the global multiclass Matthews correlation coefficient, with nonARG and unmapped predictions retained as outcomes. ACC and MCC do not depend on the averaging method and are therefore repeated. Macro precision, recall and F1 weight eligible labels equally; weighted values use reference-label support; micro values pool their true-positive, false-positive and false-negative counts. A zero denominator is assigned a score of zero. In Type evaluation, excluded output labels can make micro precision differ from micro recall and ACC.',
 'ARG/nonARG evaluation includes both reference classes. The ARG-positive row reports precision, recall and F1 for ARG as the positive class. Macro, weighted and micro rows summarize both classes. ACC and binary MCC always use all available binary outcomes. These averaging methods are reported separately rather than mixed across models.',
 'Subtype Tables 3 and 6 retain the original evaluation scope, including nonARG as a class. The exclusion of reference nonARG applies to Type tables only. Separate ARG-only subtype results are supplied in the accompanying result workbooks.',
 'DeepARG Type results use the supplied prediction records selected for Type evaluation, whereas its ARG/nonARG results use the corresponding full binary evaluation records. No new training, threshold changes or cross-model cohort matching were performed. Comparisons describe these supplied evaluation outputs.',
 'Type names use identical names or explicit spelling/abbreviation equivalence, with no family/subclass or multilabel-to-multidrug conversion. Unresolved outputs share one error label for MCC; raw names remain in the mapping audit. Scores measure agreement with this 23-name vocabulary, not general biological equivalence. Bar charts use ACC, macro precision, macro recall, macro F1 and MCC.'
]
for text in definitions: body.append(paragraph(text,11,after=140))

expected=[]
widths=[1100,1450,1100,1200,1100,1100,1150]
def table_node(selected):
    tbl=copy.deepcopy(template_table)
    for tr in tbl.findall('w:tr',NS): tbl.remove(tr)
    pr=tbl.find('w:tblPr',NS)
    tw=pr.find('w:tblW',NS); tw.set('{%s}w'%W,str(sum(widths))); tw.set('{%s}type'%W,'dxa')
    layout=pr.find('w:tblLayout',NS)
    if layout is None: layout=e('tblLayout'); pr.append(layout)
    layout.set('{%s}type'%W,'fixed')
    grid=tbl.find('w:tblGrid',NS)
    for c in list(grid):grid.remove(c)
    for w in widths:grid.append(e('gridCol',w=w))
    allrows=[['Condition','Average','ACC','Precision','Recall','F1','MCC']]+[
      [r['Completeness']+'%', 'ARG-positive' if r['Average']=='ARG_positive' else r['Average']]
      +[f'{float(r[k]):.4f}' for k in metrics] for r in selected]
    for i,values in enumerate(allrows):
        tr=e('tr'); trpr=e('trPr'); tr.append(trpr); trpr.append(e('cantSplit'))
        if i==0:trpr.append(e('tblHeader'))
        for j,(value,width) in enumerate(zip(values,widths)):
            tc=e('tc'); cp=e('tcPr'); tc.append(cp); cp.append(e('tcW',w=width,type='dxa')); cp.append(e('vAlign',val='center'))
            mar=e('tcMar'); mar.append(e('top',w=60,type='dxa')); mar.append(e('bottom',w=60,type='dxa'))
            mar.append(e('left',w=45,type='dxa')); mar.append(e('right',w=45,type='dxa')); cp.append(mar)
            borders=e('tcBorders')
            if i==0:borders.append(e('bottom',val='single',sz=6,color='000000'))
            elif i>1 and selected[i-1]['Completeness']!=selected[i-2]['Completeness']:
                borders.append(e('top',val='single',sz=4,color='AAAAAA'))
            cp.append(borders)
            p=paragraph(value,11,bold=(i==0),center=True,after=0)
            p.find('w:pPr/w:spacing',NS).set('{%s}line'%W,'240')
            tc.append(p); tr.append(tc)
        tbl.append(tr)
    return tbl

for number,mod,model,level in tables:
    selected=[r for r in data if r['Modality']==mod and r['Model']==model and r['Level']==level]
    selected.sort(key=lambda r:(int(r['Completeness']),avg_order[r['Average']]))
    assert len(selected)==(20 if level=='ARG_nonARG' else 15),(number,len(selected))
    displaymodel=('ARGScope-AA' if mod=='Protein' else 'ARGScope-NT') if model=='ARGScope' else model
    displaylevel={'ARG_nonARG':'ARG/nonARG','Type':'Type','Subtype':'Subtype'}[level]
    title=f'Table {number}. {displaymodel} performance on {displaylevel}'
    if model!='ARGScope':title+=f' ({"protein" if mod=="Protein" else "DNA"})'
    body.append(paragraph(title,12,False,True,True,True,180))
    body.append(table_node(selected))
    note= {'Type':'Fixed 23 ARGScope reference types; name-only correspondence, without drug-family/subclass conversion. All 23 labels enter each average. NonARG and unresolved predictions remain errors. ACC and MCC are global metrics.',
           'ARG_nonARG':'Both reference ARG and nonARG sequences are evaluated. ARG-positive reports ARG-class precision, recall and F1. ACC and MCC are global binary metrics.',
           'Subtype':'Original subtype evaluation scope, including nonARG as a class. ACC and MCC are global metrics; the Type-only exclusion rule is not applied here.'}[level]
    if model=='DeepARG' and level=='Type':note+=' The supplied records selected for Type evaluation are used.'
    body.append(paragraph('Note. '+note,10,after=100))
    for row,r in enumerate(selected,1):
        expected.append({'Table':number,'Row':row,'Model':model,'Modality':mod,'Level':level,
                         'Completeness':int(r['Completeness']),'Average':r['Average'],
                         'Scope':r['Scope'],**{k:float(r[k]) for k in metrics}})
body.append(sect)
package['word/document.xml']=ET.tostring(tree,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(DEST,'w') as out:
    for info in infos: out.writestr(info,package[info.filename])
with ZipFile(DEST) as out:
    for n,old in inventory.items():
        if old['role']=='preserve-only':assert hashlib.sha256(out.read(n)).hexdigest()==old['sha256'],n

# Independent DOCX object-model readback, including every displayed metric.
from docx import Document
doc=Document(DEST)
assert len(doc.tables)==18
for r in expected:
    cells=doc.tables[r['Table']-1].rows[r['Row']].cells
    assert cells[0].text==str(r['Completeness'])+'%'
    assert cells[1].text==('ARG-positive' if r['Average']=='ARG_positive' else r['Average'])
    for cell,k in zip(cells[2:],metrics):assert cell.text==f'{r[k]:.4f}',(r['Table'],r['Row'],k)
    if r['Level']=='Type':assert r['Scope']=='ARG_only'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==source_hash
with (QA/'new_document_metric_rows.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(expected[0]));writer.writeheader();writer.writerows(expected)
check={'tables':18,'metric_rows':len(expected),'metric_cells_checked':len(expected)*5,
       'source_sha256':source_hash,'source_unchanged':True,'preserve_only_parts_unchanged':True,
       'Type_scope':'ARG_only','Fixed_Type_labels':23,'Subtype_scope':'including_nonARG',
       'render_status':'pending; packaged LibreOffice unavailable'}
(QA/'document_validation.json').write_text(json.dumps(check,indent=2),encoding='utf-8')
print(f'Created {DEST}; {len(expected)*5} numerical cells verified; source unchanged.')
