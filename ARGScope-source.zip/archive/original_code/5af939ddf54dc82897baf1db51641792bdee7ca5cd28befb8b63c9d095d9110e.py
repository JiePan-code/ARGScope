#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Layout-only exports from reviewed tables and cached UMAP coordinates.

No training, prediction, UMAP fitting, label remapping, or new metric calculation.
Run with --preview-only for fast inspection. Run with --cached after extracting
the delivery ZIP elsewhere; all plotting inputs are included in data/.
"""
import argparse
import hashlib
import json
import shutil
import textwrap
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import FormatStrFormatter, MaxNLocator, PercentFormatter
import numpy as np
import pandas as pd
from PIL import Image

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "reference_style_small_panels_23types"
UMAP_SOURCE = HERE.parent.parent / "full/UMAP_epoch_type_comparison"
UMAP_PROFILE = "reference_n50_min050"
UMAP_COORDINATES = HERE / "data/umap_reference_refit/coordinates"
METRICS = ["Accuracy", "Precision", "Recall", "F1", "MCC"]
HEAT_METRICS = ["Precision", "Recall", "F1"]
PCTS = [100, 60, 70, 80, 90]
MODELS = {"protein": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
          "dna": ["ARGNet", "DeepARG", "ARGScope"]}
MODEL_COLORS = {"ARGNet": "#e9e2d1", "DeepARG": "#eb8069", "PLM-ARG": "#858585",
                "FunGeneTyper": "#78aacf", "ARGScope": "#88c1a5"}
MODEL_HATCHES = {"ARGNet": "-", "DeepARG": "/", "PLM-ARG": "\\",
                 "FunGeneTyper": ".", "ARGScope": "+"}
CMAPS = {
    "protein": LinearSegmentedColormap.from_list(
        "protein_blue", ["#fbfdff", "#cde4f4", "#67a8d1", "#175480", "#092b50"]),
    "dna": LinearSegmentedColormap.from_list(
        "dna_orange", ["#fffdf9", "#fde1bc", "#f7b16e", "#d97932", "#844315"])
}
TYPE_CORRECT, TYPE_WRONG = "#319b89", "#df7858"
# Reference-inspired appearance only; these colors do not enter UMAP fitting.
UMAP_COLORS = {
    "beta_lactam": "#FFB65C", "multidrug": "#3B528B",
    "macrolide-lincosamide-streptogramin": "#FF7F89",
    "trimethoprim": "#7C36A6", "fusidic_acid": "#E7298A",
    "fosfomycin": "#4BC4B0", "aminoglycoside": "#25A62D",
    "quinolone": "#1B9E77", "vancomycin": "#68C5CC",
    "chloramphenicol": "#A6D854", "florfenicol": "#8C6D31",
    "rifamycin": "#E67600", "tetracycline": "#F2422E",
    "other_peptide_antibiotics": "#C89F3D", "bacitracin": "#89A9D8",
    "sulfonamide": "#E77DB8", "tetracenomycin_C": "#AF75BD",
    "novobiocin": "#D6C741", "tunicamycin": "#804B53",
    "streptothricin": "#78C850", "polymyxin": "#5C99C7",
    "bleomycin": "#B8B8B8", "puromycin": "#846844",
}
# Fixed physical canvases, NOT tight-cropped. All dimensions are millimetres.
SIZES = {"overall": (105, 84), "heatmaps": (150, 84), "umap": (260, 75),
         "confusion": (85, 85), "errors": (85, 85), "subtype": (85, 85),
         "assembled": (260, 250)}
COMPOSITE_BOXES = {
    "overall": (0, 166, 105, 84), "heatmaps": (110, 166, 150, 84),
    "umap": (0, 88, 260, 75), "confusion": (0, 0, 85, 85),
    "errors": (87.5, 0, 85, 85), "subtype": (175, 0, 85, 85),
}
plt.rcParams.update({
    "font.family": "Arial", "font.size": 7, "axes.titlesize": 7.4,
    "axes.labelsize": 7, "xtick.labelsize": 6.3, "ytick.labelsize": 6.3,
    "axes.linewidth": .55, "axes.unicode_minus": False,
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    "figure.facecolor": "white", "savefig.facecolor": "white",
})
INPUTS, PANELS, CHECKS = {}, [], []
ORDER, DISPLAY, PALETTE, EPOCHS = [], {}, {}, {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path, index=None):
    # Round-trip preserves e.g. 0.07225000000000001 -> "0.0723".
    return pd.read_csv(path, index_col=index, float_precision="round_trip")


def copy_input(source, target):
    require(source.is_file(), f"Missing plotting source: {source}")
    before = digest(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    require(digest(target) == before, f"Copy differs: {source}")
    INPUTS[str(source)] = before


def prepare(cached=False):
    if not cached:
        require(SOURCE.is_dir() and UMAP_SOURCE.is_dir(), "Source folders missing; use --cached for an extracted ZIP.")
        for source in (SOURCE / "data").rglob("*"):
            if source.is_file() and source.suffix.lower() in {".csv", ".json"}:
                copy_input(source, HERE / "data" / source.relative_to(SOURCE / "data"))
        copy_input(SOURCE / "README_图件说明.md", HERE / "data/source_metrics_notes.md")
        for name in ["selected_epochs.json", "type_color_and_counts.csv", "README_UMAP说明.md"]:
            copy_input(UMAP_SOURCE / name, HERE / "data/umap" / name)
        for source in (UMAP_SOURCE / "coordinates").glob("*"):
            if source.suffix.lower() in {".csv", ".json"}:
                copy_input(source, HERE / "data/umap/coordinates" / source.name)
        (HERE / "source_fingerprints.json").write_text(
            json.dumps(INPUTS, ensure_ascii=False, indent=2), encoding="utf-8")
    global ORDER, DISPLAY, PALETTE, EPOCHS
    labels = table(HERE / "data/type_display_mapping.csv")
    ORDER = labels.Type.tolist()
    DISPLAY = dict(zip(labels.Type, labels.Display))
    palette = table(HERE / "data/umap/type_color_and_counts.csv")
    PALETTE = dict(zip(palette.Type, palette.color))
    require(len(ORDER) == 23 and set(PALETTE) == set(ORDER), "Type mapping changed")
    require(dict(zip(palette.Type, palette.Display)) == DISPLAY, "UMAP and heatmap Type names disagree")
    EPOCHS = json.loads((HERE / "data/umap/selected_epochs.json").read_text(encoding="utf-8"))


def condition_data(modality, pct):
    base = HERE / "data" / modality / f"{pct}pct"
    a = table(base / "A_overall_values_and_sources.csv")
    require(a.Model.tolist() == MODELS[modality], "Overall model order changed")
    require(np.isfinite(a[METRICS].to_numpy()).all(), "Invalid overall values")
    heat = {}
    for metric in HEAT_METRICS:
        data = table(base / f"B_{metric}_values.csv", index=0)
        raw = table(base / f"B_{metric}_source_values.csv", index=0)
        require(raw.index.tolist() == ORDER, "Candidate Type order changed")
        require(data.columns.tolist() == MODELS[modality], "Heatmap model order changed")
        other = raw.drop(columns="ARGScope").to_numpy()
        keep = np.any(np.isfinite(other) & (other != 0), axis=1)
        wanted = raw.index[keep].tolist()
        require(data.index[1:].tolist() == wanted, "Heatmap row filter differs from the approved rule")
        expected = np.nan_to_num(raw.to_numpy()[keep], nan=0.0)
        np.testing.assert_array_equal(data.to_numpy()[1:], expected)
        np.testing.assert_allclose(data.to_numpy()[0], expected.mean(axis=0), rtol=0, atol=1e-14)
        require(np.isfinite(data.to_numpy()).all(), "Displayed heatmap has NA")
        require(((data.to_numpy() >= 0) & (data.to_numpy() <= 1)).all(), "Heatmap outside [0,1]")
        heat[metric] = data
    # Shared y labels are valid ONLY if the three independently filtered row sets match.
    require(all(heat[m].index.tolist() == heat["Precision"].index.tolist() for m in HEAT_METRICS),
            f"{modality}/{pct}: different P/R/F1 rows; cannot use a shared row axis without changing the data.")
    full = table(base / "full_confusion_counts_audit.csv", index=0)
    require(full.index.tolist() == ORDER + ["nonARG"], "Full confusion row order changed")
    require(full.columns.tolist() == ORDER + ["nonARG"], "Full confusion column order changed")
    d = table(base / "D_row_normalized_23types.csv", index=0)
    e = table(base / "E_off_diagonal_counts_23types.csv", index=0)
    for data in (d, e):
        require(data.index.tolist() == ORDER and data.columns.tolist() == ORDER, "Matrix label order changed")
    expected = full.to_numpy()[:-1, :-1].astype(float)
    np.testing.assert_allclose(d.to_numpy(), expected / full.to_numpy()[:-1].sum(axis=1)[:, None],
                               rtol=0, atol=1e-14)
    np.fill_diagonal(expected, 0)
    np.testing.assert_array_equal(e.to_numpy(), expected)
    f = table(base / "F_displayed_top20.csv")
    all_errors = table(base / "F_all_subtype_error_pairs.csv")
    pd.testing.assert_frame_equal(f, all_errors.head(20))
    require((f.Count > 0).all() and f.Type_correct_percent.isin([0, 100]).all(), "Unexpected subtype-error rows")
    CHECKS.append({"modality": modality, "pct": pct, "data_match": True,
                   "heatmap_types": len(heat["Precision"]) - 1,
                   "test_observations": int(full.to_numpy().sum()),
                   "ARG_observations": int(full.to_numpy()[:-1].sum()),
                   "subtype_error_pairs_shown": len(f)})
    return {"a": a, "heat": heat, "d": d, "e": e, "f": f}


def canvas(kind):
    w, h = SIZES[kind]
    return plt.figure(figsize=(w / 25.4, h / 25.4), dpi=150)


def axes_mm(fig, box, inner):
    x, y, w, h = box
    ix, iy, iw, ih = inner
    fw, fh = fig.get_size_inches() * 25.4
    return fig.add_axes([(x + ix) / fw, (y + iy) / fh, iw / fw, ih / fh])


def normalized_box(fig, box, inner):
    x, y, w, h = box
    ix, iy, iw, ih = inner
    fw, fh = fig.get_size_inches() * 25.4
    return ((x + ix) / fw, (y + iy) / fh, iw / fw, ih / fh)


def add_check(fig, function):
    if not hasattr(fig, "_layout_checks"):
        fig._layout_checks = []
    fig._layout_checks.append(function)


def draw_overall(fig, box, modality, data):
    ax = axes_mm(fig, box, (12, 17, 91, 59))
    rows = data["a"].to_dict("records")
    width = .80 / len(rows)
    x = np.arange(len(METRICS))
    textured = modality in ("protein", "dna") and "pct" in data["a"] and data["a"].pct.eq(100).all()
    for i, row in enumerate(rows):
        bars = ax.bar(x + (i - (len(rows) - 1) / 2) * width,
                      [row[k] for k in METRICS], width=width * .94,
                      color=MODEL_COLORS[row["Model"]], edgecolor="#666666",
                      linewidth=.45, label=row["Model"],
                      hatch=MODEL_HATCHES[row["Model"]] if textured else None)
        if textured:
            for bar in bars:
                if hasattr(bar, "set_hatch_linewidth"):
                    bar.set_hatch_linewidth(.3)
        np.testing.assert_array_equal([p.get_height() for p in bars], [row[k] for k in METRICS])
    is_macro = 'Average' in data['a'] and data['a'].Average.eq('macro').all()
    tick_labels = ['Accuracy', 'Macro\nPrecision', 'Macro\nRecall', 'Macro\nF1', 'MCC'] if is_macro else METRICS
    ax.set_xticks(x, tick_labels, fontsize=7)
    lower = min(0, data["a"][METRICS].to_numpy().min())
    ax.set_ylim(lower - .05 if lower < 0 else 0, 1.055)
    ax.set_yticks(np.arange(0, 1.01, .2))
    ax.set_ylabel("Score", labelpad=3)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e7e7e7", linewidth=.4)
    ax.set_axisbelow(True)
    ax.tick_params(length=2, pad=2, labelsize=7)
    ax.legend(loc="lower center", bbox_to_anchor=(.5, 1.04), ncol=len(rows),
              frameon=False, fontsize=6.1, handlelength=1.1,
              handletextpad=.35, columnspacing=.8)


def draw_heatmaps(fig, box, modality, data):
    matrices = data["heat"]
    types = matrices["Precision"].index[1:].tolist()
    n = len(types)
    left, right, gap = 26, 14, 3
    width = (box[2] - left - right - 2 * gap) / 3
    bottom, top = 17, 79
    cell_height = (top - bottom) / (n + 1.65)
    axes, averages, texts = [], [], []
    image = None
    for mi, metric in enumerate(HEAT_METRICS):
        values = matrices[metric].to_numpy()
        ax = axes_mm(fig, box, (left + mi * (width + gap), bottom, width, cell_height * n))
        avg = axes_mm(fig, box, (left + mi * (width + gap), top - cell_height, width, cell_height))
        for target, array in [(ax, values[1:]), (avg, values[:1])]:
            image = target.imshow(array, cmap=CMAPS[modality], vmin=0, vmax=1,
                                  aspect="auto", interpolation="nearest")
            target.tick_params(length=0, pad=2)
            target.set_xticks(np.arange(-.5, len(MODELS[modality]), 1), minor=True)
            target.set_yticks(np.arange(-.5, len(array), 1), minor=True)
            target.grid(which="minor", color="white", linewidth=.35)
            target.tick_params(which="minor", length=0)
            for spine in target.spines.values():
                spine.set_linewidth(.4)
        ax.set_xticks(range(len(MODELS[modality])), MODELS[modality],
                      rotation=53, ha="right", rotation_mode="anchor", fontsize=6.3)
        ax.set_yticks(range(n), [DISPLAY[t] for t in types] if mi == 0 else [""] * n, fontsize=6.3)
        avg.set_xticks([])
        avg.set_yticks([0], ["Average"] if mi == 0 else [""], fontsize=6.3)
        avg.set_title(metric, pad=4, fontsize=7.4)
        for tick in ax.get_xticklabels():
            if tick.get_text() == "ARGScope":
                tick.set_color("#b64b3a")
                tick.set_fontweight("bold")
        for i, row in enumerate(values):
            target, yy = (avg, 0) if i == 0 else (ax, i - 1)
            for j, value in enumerate(row):
                text = target.text(j, yy, f"{value:.4f}", ha="center", va="center",
                                   fontsize=5.25, color="white" if value > .62 else "#222222",
                                   gid=f"heatmap-{metric}-{i}-{j}")
                texts.append((text, target, len(row), n if i else 1))
        axes.append(ax)
        averages.append(avg)
    cax = axes_mm(fig, box, (box[2] - right + 2, bottom, 1.6, top - bottom))
    cb = fig.colorbar(image, cax=cax, ticks=[0, .25, .5, .75, 1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter("%.4f"))
    cb.ax.tick_params(labelsize=5.5, length=1.6, pad=1.5)

    def verify(renderer):
        for text, target, cols, rows in texts:
            b = text.get_window_extent(renderer)
            ab = target.get_window_extent(renderer)
            require(b.width < ab.width / cols * .98, "Four-decimal annotation does not fit cell")
            require(b.height < ab.height / rows * .96, "Heatmap value too tall for cell")
        for ax, avg in zip(axes, averages):
            b, a, c = [z.get_window_extent(renderer) for z in (ax, avg, cax)]
            require(abs(c.y0 - b.y0) < .5 and abs(c.y1 - a.y1) < .5, "Colorbar height mismatch")
            require(a.y0 - b.y1 > 2, "Average gap missing")
    add_check(fig, verify)


def draw_matrix(fig, box, modality, data, key):
    array = data["d" if key == "confusion" else "e"].to_numpy()
    side = box[2] - 37
    ax = axes_mm(fig, box, (24, 29, side, side))
    cmap = CMAPS[modality].copy()
    vmax = 1 if key == "confusion" else max(1, float(array.max()))
    if key == "errors":
        array = np.ma.array(array, mask=np.eye(len(ORDER), dtype=bool))
        cmap.set_bad("#eeeeee")
    image = ax.imshow(array, cmap=cmap, vmin=0, vmax=vmax, aspect="equal", interpolation="nearest")
    ax.set_xticks(range(23), [DISPLAY[t] for t in ORDER],
                  rotation=58, ha="right", rotation_mode="anchor", fontsize=5.7)
    ax.set_yticks(range(23), [DISPLAY[t] for t in ORDER], fontsize=5.7)
    ax.tick_params(length=1.5, pad=1.6)
    ax.set_xlabel("Predicted Type", fontsize=6.8, labelpad=3)
    ax.set_ylabel("True Type", fontsize=6.8, labelpad=3)
    cax = axes_mm(fig, box, (24 + side + 2, 29, 1.6, side))
    cb = fig.colorbar(image, cax=cax)
    cb.ax.tick_params(labelsize=5.5, length=1.5, pad=1)
    if key == "confusion":
        cb.set_ticks([0, .25, .5, .75, 1])
        cb.ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
        cb.set_label("Proportion", fontsize=6, labelpad=2)
    else:
        cb.locator = MaxNLocator(nbins=5, integer=True)
        cb.update_ticks()
        cb.set_label("Count", fontsize=6, labelpad=2)


def short_subtype(value):
    return value.split("__", 1)[-1]


def draw_subtype(fig, box, modality, data):
    rows = data["f"]
    labels = [textwrap.fill(f"{short_subtype(r.true_subtype)} → {short_subtype(r.predicted_subtype)}",
                            width=36, break_long_words=True, break_on_hyphens=False)
              for r in rows.itertuples()]
    ax = axes_mm(fig, box, (39, 17, 43, 64))
    # Wrapped names get extra vertical space, without changing the top-20 order.
    heights = np.array([1 + .65 * s.count("\n") for s in labels])
    ys = np.cumsum(heights) - heights / 2
    colors = [TYPE_CORRECT if p == 100 else TYPE_WRONG for p in rows.Type_correct_percent]
    bars = ax.barh(ys, rows.Count, height=.7, color=colors, edgecolor="#444444", linewidth=.3)
    max_count = float(rows.Count.max())
    for bar, row in zip(bars, rows.itertuples()):
        if row.Type_correct_percent != 100:
            bar.set_hatch("///")
        ax.text(row.Count + max_count * .025, bar.get_y() + bar.get_height() / 2,
                f"{row.Count} ({row.Type_correct_percent:.0f}%)", va="center", fontsize=5.6)
    ax.set_yticks(ys, labels, fontsize=5.6, linespacing=1.0)
    ax.set_ylim(heights.sum() + .2, -.2)
    ax.set_xlim(0, max_count * 1.55)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
    ax.tick_params(length=1.5, pad=1.8, labelsize=5.6)
    ax.set_xlabel("Count", fontsize=6.8, labelpad=2)
    ax.spines[["right", "top"]].set_visible(False)
    ax.grid(axis="x", color="#e8e8e8", linewidth=.35)
    ax.set_axisbelow(True)
    handles = [
        Patch(facecolor=TYPE_CORRECT, edgecolor="#444444", linewidth=.3,
              label="Subtype wrong, Type correct"),
        Patch(facecolor=TYPE_WRONG, edgecolor="#444444", linewidth=.3, hatch="///",
              label="Subtype wrong, Type incorrect")]
    fig.legend(handles=handles, loc="upper left",
               bbox_to_anchor=normalized_box(fig, box, (38, 1, 46, 8)),
               bbox_transform=fig.transFigure, frameon=False, fontsize=5.7,
               borderaxespad=0, borderpad=0, handlelength=1.1, labelspacing=.3)

    def verify(renderer):
        bboxes = [t.get_window_extent(renderer) for t in ax.get_yticklabels()]
        for i, a in enumerate(bboxes):
            for b in bboxes[i + 1:]:
                require(not a.overlaps(b), "Subtype labels overlap")
    add_check(fig, verify)


def umap_data(modality):
    selected = EPOCHS[modality]["selected_epochs"]
    best = EPOCHS[modality]["best_epoch"]
    require(len(selected) == 4 and selected[-1] == best, "Last UMAP is not the selected best epoch")
    frames = []
    for ep in selected:
        path = UMAP_COORDINATES / f"{modality}_epoch_{ep:03d}.csv"
        require(path.is_file(), "Refit coordinates missing; run refit_umap_reference.py first")
        metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        require(metadata["identity"]["profile"] == UMAP_PROFILE, "Wrong UMAP coordinate profile")
        require(metadata["identity"]["params"]["n_neighbors"] == 50 and
                metadata["identity"]["params"]["min_dist"] == .50, "Mixed UMAP layout settings")
        require(metadata["labels_used_in_fit"] is False, "Supervised coordinates are not allowed")
        require(metadata["coordinates_sha256"] == digest(path), "Refit coordinates changed after fitting")
        frame = table(path)
        original = table(HERE / "data/umap/coordinates" / path.name)
        pd.testing.assert_frame_equal(frame[["sequence_id", "Type", "Subtype"]],
                                      original[["sequence_id", "Type", "Subtype"]])
        frames.append(frame)
    reference = frames[0][["sequence_id", "Type", "Subtype"]]
    require(not reference.sequence_id.duplicated().any(), "Duplicate UMAP IDs")
    require(set(reference.Type) == set(ORDER) and len(reference) == 2287, "Unexpected UMAP cohort")
    for frame in frames:
        pd.testing.assert_frame_equal(frame[["sequence_id", "Type", "Subtype"]], reference)
        require(np.isfinite(frame[["UMAP1", "UMAP2"]].to_numpy()).all(), "Invalid UMAP coordinate")
    return frames


def draw_umap(fig, box, modality, frames):
    left, right, gap, bottom = 6, 2, 9, 21
    width = (box[2] - left - right - 3 * gap) / 4
    aspect = 1.20
    height = width / aspect
    axes = []
    order = np.random.default_rng(42).permutation(len(frames[0]))
    require(set(UMAP_COLORS) == set(ORDER), "Incomplete reference-style UMAP palette")
    point_colors = np.array([UMAP_COLORS[t] for t in frames[0].Type])
    for i, (epoch, frame) in enumerate(zip(EPOCHS[modality]["selected_epochs"], frames)):
        ax = axes_mm(fig, box, (left + i * (width + gap), bottom, width, height))
        xy = frame[["UMAP1", "UMAP2"]].to_numpy()
        scatter = ax.scatter(xy[order, 0], xy[order, 1], c=point_colors[order],
                             s=3.4, alpha=.90, edgecolors="none", linewidths=0, rasterized=False)
        np.testing.assert_array_equal(scatter.get_offsets(), xy[order])
        lo, hi = xy.min(axis=0), xy.max(axis=0)
        center = (lo + hi) / 2
        # Match the rectangular panel WITHOUT stretching distances, cropping
        # outliers, jittering, or translating individual points or classes.
        yspan = max(float(hi[1] - lo[1]), float(hi[0] - lo[0]) / aspect, 1e-6) * 1.08
        xspan = yspan * aspect
        ax.set_xlim(center[0] - xspan / 2, center[0] + xspan / 2)
        ax.set_ylim(center[1] - yspan / 2, center[1] + yspan / 2)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel("UMAP1", labelpad=2, fontsize=7)
        if i == 0:
            ax.set_ylabel("UMAP2", labelpad=2, fontsize=7)
        ax.set_title(f"Best model (epoch {epoch})" if i == 3 else f"Epoch {epoch}",
                     fontsize=7.4, fontweight="bold" if i == 3 else "normal", pad=4)
        axes.append(ax)
    handles = [Line2D([], [], color=UMAP_COLORS[t], marker="o", linestyle="none",
                      markersize=4, markeredgecolor="none", markeredgewidth=0,
                      label=DISPLAY[t]) for t in ORDER]
    legend = fig.legend(handles=handles, ncol=6, loc="upper left", mode="expand",
                        bbox_to_anchor=normalized_box(fig, box, (left, 1, box[2] - left - right, 13)),
                        bbox_transform=fig.transFigure, frameon=False, borderaxespad=0,
                        borderpad=0, handlelength=1, handletextpad=.4,
                        labelspacing=.4, fontsize=7.3)

    def verify(renderer):
        for ax in axes:
            ab = ax.get_window_extent(renderer)
            require(abs(ab.width / ab.height - aspect) < .001, "Incorrect UMAP panel aspect")
            scale_x = ab.width / abs(np.diff(ax.get_xlim())[0])
            scale_y = ab.height / abs(np.diff(ax.get_ylim())[0])
            require(abs(scale_x - scale_y) < 1e-8, "UMAP axes distort pairwise distances")
        lb = legend.get_window_extent(renderer)
        first, last = [a.get_window_extent(renderer) for a in (axes[0], axes[-1])]
        require(abs(lb.x0 - first.x0) < 1 and abs(lb.x1 - last.x1) < 1, "UMAP legend width mismatch")
        texts = [t.get_window_extent(renderer) for t in legend.get_texts()]
        require(len(texts) == 23, "UMAP legend dropped a Type")
        for i, a in enumerate(texts):
            for b in texts[i + 1:]:
                require(not a.overlaps(b), "UMAP legend labels overlap")
        require(lb.y1 + 2 < min(ax.xaxis.label.get_window_extent(renderer).y0 for ax in axes),
                "UMAP legend overlaps axes")
    add_check(fig, verify)


def meaningful_texts(fig):
    output = list(fig.texts)
    for ax in fig.axes:
        output.extend(ax.texts)
        output.extend([ax.title, ax.xaxis.label, ax.yaxis.label])
        # Locators may offer extra ticks outside the displayed limits; those
        # tick labels are not drawn and must not count as clipped content.
        for axis, limits in [(ax.xaxis, ax.get_xlim()), (ax.yaxis, ax.get_ylim())]:
            lo, hi = sorted(limits)
            output.extend(t for value, t in zip(axis.get_majorticklocs(), axis.get_ticklabels())
                          if lo - 1e-10 <= value <= hi + 1e-10)
        legend = ax.get_legend()
        if legend is not None:
            output.extend(legend.get_texts())
    for legend in fig.legends:
        output.extend(legend.get_texts())
    return [t for t in output if t.get_visible() and t.get_text().strip()]


def check_geometry(fig, name):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for verify in getattr(fig, "_layout_checks", []):
        verify(renderer)
    extent = fig.bbox
    for text in meaningful_texts(fig):
        label = text.get_text()
        require(label not in list("ABCDEF"), f"{name}: printed panel letter")
        require("completeness" not in label.lower() and "ARGScope Full" not in label,
                f"{name}: forbidden figure description")
        b = text.get_window_extent(renderer)
        require(b.x0 >= -1 and b.y0 >= -1 and b.x1 <= extent.x1 + 1 and b.y1 <= extent.y1 + 1,
                f"{name}: clipped text {label!r} bounds={tuple(round(v,1) for v in b.extents)} canvas={extent.extents}")
    return {"all_text_inside_canvas": True, "layout_checks": len(getattr(fig, "_layout_checks", []))}


def save(fig, relative, kind, modality, pct, args):
    geometry = check_geometry(fig, relative)
    target = HERE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    preview = HERE / "_preview" / relative
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview.with_suffix(".png"), dpi=150)  # exact fixed canvas
    paths = []
    if not args.preview_only:
        for extension in ("png", "svg", "pdf"):
            path = target.with_suffix("." + extension)
            fig.savefig(path, dpi=args.dpi if extension == "png" else 150)
            paths.append(str(path.relative_to(HERE)))
        svg = ET.parse(target.with_suffix(".svg")).getroot()
        fw, fh = fig.get_size_inches()
        require(abs(float(svg.attrib["width"].removesuffix("pt")) - fw * 72) < .01, "Wrong SVG width")
        require(abs(float(svg.attrib["height"].removesuffix("pt")) - fh * 72) < .01, "Wrong SVG height")
        with Image.open(target.with_suffix(".png")) as image:
            require(abs(image.width - fw * args.dpi) < 2 and abs(image.height - fh * args.dpi) < 2,
                    "Wrong raster export size")
    PANELS.append({"modality": modality, "completeness_percent": pct,
                   "panel": kind, "width_mm": SIZES[kind][0], "height_mm": SIZES[kind][1],
                   "files": paths, **geometry})
    plt.close(fig)


DRAW = {"overall": draw_overall, "heatmaps": draw_heatmaps, "subtype": draw_subtype}


def render_condition(modality, pct, data, args):
    folder = "Protein" if modality == "protein" else "DNA"
    for kind in ["overall", "heatmaps", "confusion", "errors", "subtype"]:
        fig = canvas(kind)
        box = (0, 0, *SIZES[kind])
        if kind in DRAW:
            DRAW[kind](fig, box, modality, data)
        else:
            draw_matrix(fig, box, modality, data, kind)
        save(fig, f"{folder}/{pct}pct/{kind}_{modality}_{pct}pct", kind, modality, pct, args)
    print(f"Rendered {modality} {pct}%: 5 panels", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cached", action="store_true", help="Use only data/ included with the ZIP")
    parser.add_argument("--preview-only", action="store_true")
    parser.add_argument("--umap-only", action="store_true", help="Update UMAP and full assemblies; leave other exports untouched")
    parser.add_argument("--modality", nargs="+", choices=["protein", "dna"], default=["protein", "dna"])
    parser.add_argument("--pct", nargs="+", type=int, choices=PCTS, default=PCTS)
    parser.add_argument("--dpi", type=int, default=600)
    args = parser.parse_args()
    old_report_path = HERE / "LAYOUT_VALIDATION.json"
    old_report = json.loads(old_report_path.read_text(encoding="utf-8")) if old_report_path.exists() else None
    protected = {}
    if args.umap_only and old_report:
        protected = {str(HERE / rel): digest(HERE / rel)
                     for entry in old_report["panels"] if entry["panel"] not in {"umap", "assembled"}
                     for rel in entry["files"]}
    prepare(args.cached)
    coordinate_hashes = {str(path): digest(path)
                         for directory in [HERE / "data/umap/coordinates", UMAP_COORDINATES]
                         for path in directory.glob("*.csv")}
    for modality in args.modality:
        full_data = None
        for pct in ([100] if args.umap_only else args.pct):
            data = condition_data(modality, pct)
            if not args.umap_only:
                render_condition(modality, pct, data, args)
            if pct == 100:
                full_data = data
        if full_data is not None:
            folder = "Protein" if modality == "protein" else "DNA"
            frames = umap_data(modality)
            fig = canvas("umap")
            draw_umap(fig, (0, 0, *SIZES["umap"]), modality, frames)
            save(fig, f"{folder}/100pct/umap_{modality}_4epochs", "umap", modality, 100, args)
            fig = canvas("assembled")
            draw_overall(fig, COMPOSITE_BOXES["overall"], modality, full_data)
            draw_heatmaps(fig, COMPOSITE_BOXES["heatmaps"], modality, full_data)
            draw_umap(fig, COMPOSITE_BOXES["umap"], modality, frames)
            for kind in ["confusion", "errors"]:
                draw_matrix(fig, COMPOSITE_BOXES[kind], modality, full_data, kind)
            draw_subtype(fig, COMPOSITE_BOXES["subtype"], modality, full_data)
            save(fig, f"{folder}/{folder}_100pct_assembled", "assembled", modality, 100, args)
            print(f"Rendered {modality}: refitted 4-epoch UMAP and assembled full-length figure", flush=True)
    if not args.cached:
        require(all(digest(Path(path)) == value for path, value in INPUTS.items()), "A source file changed during plotting")
    require(all(digest(Path(path)) == value for path, value in coordinate_hashes.items()), "Cached UMAP coordinates changed")
    require(all(digest(Path(path)) == value for path, value in protected.items()), "Unrelated panel exports changed")
    fresh_count = len(PANELS)
    # Preserve the complete index when only four UMAP-related figures change.
    if args.umap_only and not args.preview_only and old_report:
        updated_keys = {(p["modality"], p["completeness_percent"], p["panel"]): p for p in PANELS}
        merged = []
        for old in old_report["panels"]:
            key = (old["modality"], old["completeness_percent"], old["panel"])
            merged.append(updated_keys.pop(key, old))
        PANELS[:] = merged + list(updated_keys.values())
        updated_checks = {(c["modality"], c["pct"]): c for c in CHECKS}
        CHECKS[:] = [updated_checks.pop((c["modality"], c["pct"]), c) for c in old_report["data_checks"]] + list(updated_checks.values())
    report = {"status": "PASS", "preview_only": args.preview_only, "figures": len(PANELS),
              "exports": sum(len(p["files"]) for p in PANELS),
              "fixed_physical_canvases": True, "dpi": args.dpi,
              "source_files_unchanged": True, "metrics_unchanged": True,
              "original_umap_coordinates_unchanged": True, "display_coordinates_refitted": True,
              "freshly_rendered_figures": fresh_count, "unchanged_non_umap_exports": len(protected),
              "umap_style": {"panel_aspect_ratio": 1.2, "marker_area_points2": 3.4,
                             "alpha": .9, "marker_edges": "none", "colors": UMAP_COLORS,
                             "coordinates_refitted": True, "profile": UMAP_PROFILE,
                             "n_neighbors": 50, "min_dist": .50, "labels_used_in_fit": False,
                             "coordinates_manually_modified": False,
                             "cropped_points": 0, "equal_axis_scaling": True},
              "data_checks": CHECKS, "panels": PANELS,
              "scope_note": "Baseline populations are not matched; the supplied values are preserved. See README."}
    path = HERE / ("_preview/validation.json" if args.preview_only else "LAYOUT_VALIDATION.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if not args.preview_only:
        pd.DataFrame([{"Type": t, "Display": DISPLAY[t], "original_color": PALETTE[t],
                       "reference_style_color": UMAP_COLORS[t]} for t in ORDER]).to_csv(
            HERE / "umap_reference_palette.csv", index=False, encoding="utf-8-sig")
        pd.DataFrame([{"panel": k, "width_mm": v[0], "height_mm": v[1]} for k, v in SIZES.items()]).to_csv(
            HERE / "panel_sizes_mm.csv", index=False, encoding="utf-8-sig")
        pd.DataFrame([{k: v for k, v in p.items() if k != "files"} | {"files": ";".join(p["files"])}
                      for p in PANELS]).to_csv(HERE / "PANEL_INDEX.csv", index=False, encoding="utf-8-sig")
    print(f"PASS: {len(PANELS)} figures, {report['exports']} exports; source data unchanged.", flush=True)


if __name__ == "__main__":
    main()
