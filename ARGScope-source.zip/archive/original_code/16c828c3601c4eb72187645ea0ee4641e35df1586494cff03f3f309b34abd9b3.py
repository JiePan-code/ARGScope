#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope DNA 100% Novel-Gene training - Windows local version.

Novel-gene definition
---------------------
1. External TRAIN/TEST are read from:
       Dataset/train_ids.txt
       Dataset/test_ids.txt
       Dataset/split_structure.txt
2. Every TEST ARG subtype must be completely absent from TRAIN.
3. Every TEST ARG Type must still be represented in TRAIN.
4. The subtype classifier contains TRAIN ARG subtypes only.
5. TEST-only ARG subtypes never enter the classifier label space and are never
   used for Teacher/Student optimization, normalization, model selection, or
   validation.
6. Validation is carved only from external TRAIN.
7. Final TEST reporting is Type-level:
       ARG_nonARG
       Type_on_true_ARG
       Type_oracle_binary
       End_to_end_Type
   Exact TEST subtype accuracy is intentionally not reported because TEST ARG
   subtypes are deliberately unseen.

DNA model
---------
Official DNABERT-2 mean-pooled full-length DNA embedding [768]
 -> train-only standardization
 -> Linear(768, 1024) + LN + GELU + Dropout
 -> 2 residual blocks
 -> Linear(1024, 512) + LN
 -> L2 normalization
 -> binary cosine head: nonARG / ARG
 -> TRAIN-known ARG subtype cosine head

Training
--------
Stage 1: Fusion Teacher
Stage 2: DNA Student

The scientific hyperparameters are fixed to the uploaded DNA GRID-best result:
    seed                    = 20260822
    effective batch size    = 4096
    effective eval batch    = 8192
    Teacher epochs          = 80
    Student epochs          = 160
    Teacher patience        = 15
    Student patience        = 25
    Teacher LR              = 3e-4
    Student LR              = 2e-4
    weight decay            = 5e-5
    hidden dimension        = 1024
    embedding dimension     = 512
    dropout                 = 0.10
    temperature             = 3.0
    binary logit scale      = 16
    subtype logit scale     = 24
    label smoothing         = 0.002
    class weight power      = 0.0
    Teacher feature anchor  = 0.10
    Teacher refined anchor  = 0.05
    Student binary KD       = 0.20
    Student subtype KD      = 0.05
    Student feature align   = 0.05
    Student prototype align = 0.05
    Student head anchor     = 0.05
    binary ARG threshold    = 0.80

Windows/local-GPU note
----------------------
The GRID-best logical batch size remains 4096. To fit a local 8-GB GPU, each
logical batch is executed as CUDA micro-batches of 128 with gradient
accumulation. This changes memory usage, not the optimizer update frequency.

CUDA is required. There is no silent CPU fallback.
"""

from __future__ import annotations

import copy
import csv
import json
import math
import os
import random
import shutil
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)


# =============================================================================
# Windows paths
# =============================================================================

ROOT = Path(
    r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\5. novel gene"
)

DNA_PT = (
    ROOT
    / "DNABERT2_full_1to1"
    / "full_1to1_dnabert2_mean.pt"
)

FUSION_PT = (
    ROOT
    / "Long_fusion"
    / "long_fusion.pt"
)

REFINED_PT = (
    ROOT
    / "Refined_subtype_prototypes_long"
    / "refined_ARG_subtype_prototypes_residual_GAT.pt"
)

SPLIT_DIR = ROOT / "Dataset"

TRAIN_IDS_FILE = SPLIT_DIR / "train_ids.txt"
TEST_IDS_FILE = SPLIT_DIR / "test_ids.txt"
SPLIT_STRUCTURE_FILE = SPLIT_DIR / "split_structure.txt"

OUTPUT_DIR = ROOT / "DNA_novel_gene_100pct"

# Safer default: do not silently overwrite an existing completed run.
OVERWRITE_OUTPUT = False


# =============================================================================
# Fixed DNA GRID-best configuration
# =============================================================================

SCRIPT_VERSION = "2026-09-08-DNA-novelgene-100pct-windows-v1"
NONARG = "nonARG"


@dataclass
class Config:
    seed: int = 20260822

    # Logical/effective batch sizes from the uploaded DNA GRID-best CSV.
    batch_size: int = 4096
    eval_batch_size: int = 8192

    # Physical CUDA micro-batches for local 8-GB GPU memory.
    micro_batch_size: int = 128
    eval_micro_batch_size: int = 512

    teacher_epochs: int = 80
    student_epochs: int = 160

    teacher_patience: int = 15
    student_patience: int = 25

    teacher_lr: float = 3.0e-4
    student_lr: float = 2.0e-4
    weight_decay: float = 5.0e-5

    hidden_dim: int = 1024
    embedding_dim: int = 512

    dropout: float = 0.10
    temperature: float = 3.0

    logit_scale_binary: float = 16.0
    logit_scale_subtype: float = 24.0

    label_smoothing: float = 0.002
    class_weight_power: float = 0.0

    teacher_binary_ce: float = 1.0
    teacher_subtype_ce: float = 1.0
    teacher_feature_anchor: float = 0.10
    teacher_refined_anchor: float = 0.05

    student_binary_ce: float = 1.0
    student_subtype_ce: float = 1.0
    student_binary_kd: float = 0.20
    student_subtype_kd: float = 0.05
    student_feature_align: float = 0.05
    student_prototype_align: float = 0.05
    student_head_anchor: float = 0.05

    gradient_clip: float = 1.0
    min_delta: float = 1.0e-5

    validation_fraction: float = 0.20

    # Uploaded DNA GRID-best threshold.
    binary_threshold: float = 0.80

    # The uploaded NSCC trajectory script continued Student training through
    # all requested epochs while selecting the best validation checkpoint.
    # Keep that behavior here for the 160-epoch DNA run.
    continue_student_to_max_epochs: bool = True


CFG = Config()


# =============================================================================
# General utilities
# =============================================================================

def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def require_cuda() -> torch.device:
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU was not detected. CPU fallback is intentionally disabled."
        )

    device = torch.device("cuda:0")
    torch.cuda.set_device(device)

    props = torch.cuda.get_device_properties(0)

    print("=" * 108, flush=True)
    print("ARGScope DNA Novel-Gene 100% - Windows local", flush=True)
    print("=" * 108, flush=True)
    print(f"Script version : {SCRIPT_VERSION}", flush=True)
    print(f"PyTorch        : {torch.__version__}", flush=True)
    print(f"CUDA runtime   : {torch.version.cuda}", flush=True)
    print(f"GPU            : {torch.cuda.get_device_name(0)}", flush=True)
    print(f"GPU memory     : {props.total_memory / 1024**3:.2f} GB", flush=True)
    print(f"Device         : {device}", flush=True)
    print("=" * 108, flush=True)

    return device


def canonical_id(value: Any) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()
    compact = "".join(ch for ch in text.lower() if ch.isalnum())

    if compact in {
        "nonarg",
        "nonresistance",
        "negative",
        "nonresistant",
    }:
        return NONARG

    return text


def is_nonarg(value: Any) -> bool:
    return canonical_subtype(value) == NONARG


def load_pt(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def require_tensor_2d(value, name: str) -> torch.Tensor:
    if not isinstance(value, torch.Tensor) or value.ndim != 2:
        raise ValueError(f"{name} must be a 2D torch.Tensor.")

    value = value.detach().cpu().float().contiguous()

    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} contains NaN/Inf.")

    return value


def extract_embedding_pt(
    path: Path,
    description: str,
) -> Tuple[List[str], torch.Tensor, dict]:

    obj = load_pt(path)

    if not isinstance(obj, dict):
        raise TypeError(f"{description} PT must contain a dict: {path}")

    id_key = next(
        (
            key
            for key in ("ids", "sequence_ids", "fragment_ids")
            if key in obj
        ),
        None,
    )

    emb_key = next(
        (
            key
            for key in (
                "embeddings",
                "mean_embeddings",
                "features",
                "fusion_embeddings",
            )
            if key in obj
        ),
        None,
    )

    if id_key is None or emb_key is None:
        raise KeyError(
            f"{description} PT must contain IDs and embeddings. "
            f"Found keys={sorted(obj.keys())}"
        )

    ids = [canonical_id(v) for v in obj[id_key]]

    embeddings = require_tensor_2d(
        obj[emb_key],
        f"{description} embeddings",
    )

    if len(ids) != embeddings.shape[0]:
        raise ValueError(
            f"{description} ID/embedding mismatch: "
            f"{len(ids)} vs {embeddings.shape[0]}"
        )

    if len(ids) != len(set(ids)):
        raise ValueError(f"{description} contains duplicate IDs.")

    return ids, embeddings, obj


def detect_delimiter(path: Path) -> str:
    with path.open("r", encoding="utf-8-sig") as handle:
        first = handle.readline()
    return "\t" if "\t" in first else ","


def find_column(fieldnames: Sequence[str], candidates: Sequence[str]) -> str:
    normalized = {
        str(name).strip().lower().replace("_", "").replace(".", ""): name
        for name in fieldnames
    }

    for candidate in candidates:
        key = (
            str(candidate)
            .strip()
            .lower()
            .replace("_", "")
            .replace(".", "")
        )
        if key in normalized:
            return normalized[key]

    raise KeyError(
        f"Could not find any of columns {list(candidates)}. "
        f"Found={list(fieldnames)}"
    )


def read_id_file(path: Path) -> List[str]:
    ids: List[str] = []
    seen = set()

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, raw in enumerate(handle, start=1):
            seq_id = canonical_id(raw)

            if not seq_id:
                continue

            if seq_id in seen:
                raise ValueError(
                    f"Duplicate ID in {path} line {line_number}: {seq_id}"
                )

            seen.add(seq_id)
            ids.append(seq_id)

    if not ids:
        raise ValueError(f"ID file is empty: {path}")

    return ids


def load_split_structure(path: Path) -> Dict[str, dict]:
    delimiter = detect_delimiter(path)

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(handle, delimiter=delimiter)

        if not reader.fieldnames:
            raise ValueError(f"Structure has no header: {path}")

        id_col = find_column(
            reader.fieldnames,
            ["SARG.Seq.ID", "Sequence_ID", "ID", "Seq_ID"],
        )
        type_col = find_column(reader.fieldnames, ["Type"])
        subtype_col = find_column(reader.fieldnames, ["Subtype"])

        split_col = None
        try:
            split_col = find_column(reader.fieldnames, ["Split"])
        except KeyError:
            pass

        class_col = None
        try:
            class_col = find_column(
                reader.fieldnames,
                ["ARG.or.nonARG", "ARG_or_nonARG", "Label"],
            )
        except KeyError:
            pass

        records: Dict[str, dict] = {}

        for line_number, row in enumerate(reader, start=2):
            seq_id = canonical_id(row.get(id_col, ""))

            if not seq_id:
                continue

            if seq_id in records:
                raise ValueError(
                    f"Duplicate sequence ID in structure at line "
                    f"{line_number}: {seq_id}"
                )

            subtype = canonical_subtype(row.get(subtype_col, ""))
            type_name = str(row.get(type_col, "")).strip()

            if class_col is not None:
                class_text = str(row.get(class_col, "")).strip().lower()

                if "non" in class_text and "arg" in class_text:
                    subtype = NONARG

            if is_nonarg(subtype):
                type_name = NONARG

            if not subtype:
                raise ValueError(
                    f"Empty subtype at line {line_number}: {seq_id}"
                )

            if not type_name:
                raise ValueError(
                    f"Empty Type at line {line_number}: {seq_id}"
                )

            split = (
                str(row.get(split_col, "")).strip().lower()
                if split_col is not None
                else ""
            )

            records[seq_id] = {
                "subtype": subtype,
                "type": type_name,
                "declared_split": split,
            }

    if not records:
        raise ValueError(f"No records loaded from structure: {path}")

    return records


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        return

    fieldnames: List[str] = []
    seen = set()

    for row in rows:
        for key in row:
            if key not in seen:
                fieldnames.append(key)
                seen.add(key)

    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    os.replace(tmp, path)


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}

    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, np.integer):
        return int(value)

    if isinstance(value, np.floating):
        return float(value)

    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            return value.item()
        return value.detach().cpu().tolist()

    return value


def save_json(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(
            json_safe(obj),
            handle,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(tmp, path)


def safe_torch_save(obj, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)

    if not tmp.is_file() or tmp.stat().st_size <= 0:
        raise RuntimeError(f"Invalid temporary checkpoint: {tmp}")

    os.replace(tmp, path)


def check_input_files() -> None:
    required = [
        DNA_PT,
        FUSION_PT,
        REFINED_PT,
        TRAIN_IDS_FILE,
        TEST_IDS_FILE,
        SPLIT_STRUCTURE_FILE,
    ]

    missing = [path for path in required if not path.is_file()]

    if missing:
        text = "\n".join(f"  - {path}" for path in missing)

        raise FileNotFoundError(
            "Required input file(s) are missing:\n"
            f"{text}\n\n"
            "Check the Windows paths near the top of this script."
        )


def prepare_output_dir() -> None:
    if OUTPUT_DIR.exists() and any(OUTPUT_DIR.iterdir()):
        if not OVERWRITE_OUTPUT:
            raise FileExistsError(
                f"Output directory is not empty:\n{OUTPUT_DIR}\n\n"
                "Delete/rename it, or set OVERWRITE_OUTPUT = True near "
                "the top of the script."
            )

        shutil.rmtree(OUTPUT_DIR)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# Novel-gene split and data alignment
# =============================================================================

def build_validation_split(
    selected_ids: Sequence[str],
    records: Dict[str, dict],
    external_train_set: Set[str],
    external_test_set: Set[str],
    validation_fraction: float,
    seed: int,
) -> Tuple[List[str], List[str]]:

    if not (0.0 < float(validation_fraction) < 0.5):
        raise ValueError("validation_fraction must be between 0 and 0.5.")

    rng = random.Random(seed)

    model_split: List[str | None] = [None] * len(selected_ids)
    external_split: List[str | None] = [None] * len(selected_ids)

    arg_positions_by_subtype: Dict[str, List[int]] = defaultdict(list)
    nonarg_positions: List[int] = []

    for i, seq_id in enumerate(selected_ids):
        if seq_id in external_test_set:
            external_split[i] = "test"
            model_split[i] = "test"
            continue

        if seq_id not in external_train_set:
            raise RuntimeError(
                f"Selected ID belongs to neither external train nor test: {seq_id}"
            )

        external_split[i] = "train"
        subtype = records[seq_id]["subtype"]

        if is_nonarg(subtype):
            nonarg_positions.append(i)
        else:
            arg_positions_by_subtype[subtype].append(i)

    # ARG validation is carved only from external TRAIN and is stratified by
    # TRAIN subtype. Every TRAIN subtype retains at least one model-train row.
    for subtype in sorted(arg_positions_by_subtype):
        positions = list(arg_positions_by_subtype[subtype])
        rng.shuffle(positions)
        n = len(positions)

        if n <= 1:
            n_val = 0
        else:
            n_val = int(round(n * validation_fraction))
            n_val = max(1, n_val)
            n_val = min(n - 1, n_val)

        val_set = set(positions[:n_val])

        for i in positions:
            model_split[i] = "validation" if i in val_set else "train"

    arg_val_count = sum(
        1
        for i, split in enumerate(model_split)
        if split == "validation"
        and not is_nonarg(records[selected_ids[i]]["subtype"])
    )

    # Match nonARG validation size to ARG validation size.
    shuffled_nonarg = list(nonarg_positions)
    rng.shuffle(shuffled_nonarg)

    if arg_val_count >= len(shuffled_nonarg):
        raise ValueError(
            "Not enough nonARG rows to create a 1:1 validation set."
        )

    nonarg_val = set(shuffled_nonarg[:arg_val_count])

    for i in shuffled_nonarg:
        model_split[i] = "validation" if i in nonarg_val else "train"

    if any(v is None for v in model_split):
        raise RuntimeError("Some selected rows were not assigned a model split.")

    return (
        [str(v) for v in model_split],
        [str(v) for v in external_split],
    )


def load_refined_train_prototypes(
    path: Path,
    train_arg_subtypes: Set[str],
) -> Tuple[List[str], torch.Tensor, dict]:

    obj = load_pt(path)

    if not isinstance(obj, dict):
        raise TypeError("Refined prototype PT must contain a dict.")

    names_key = next(
        (
            key
            for key in (
                "arg_subtype_names",
                "ARG_subtype_names",
                "subtype_names",
            )
            if key in obj
        ),
        None,
    )

    proto_key = next(
        (
            key
            for key in (
                "refined_arg_subtype_prototypes",
                "refined_ARG_subtype_prototypes",
                "refined_prototypes",
                "prototypes",
            )
            if key in obj
        ),
        None,
    )

    if names_key is None or proto_key is None:
        raise KeyError(
            "Refined PT lacks subtype names or prototype tensor. "
            f"Found keys={sorted(obj.keys())}"
        )

    all_names = [canonical_subtype(v) for v in obj[names_key]]

    all_prototypes = require_tensor_2d(
        obj[proto_key],
        "refined ARG subtype prototypes",
    )

    if len(all_names) != all_prototypes.shape[0]:
        raise ValueError(
            "Refined subtype-name/prototype count mismatch."
        )

    if all_prototypes.shape[1] != CFG.embedding_dim:
        raise ValueError(
            f"Expected refined prototype dimension {CFG.embedding_dim}; "
            f"found {all_prototypes.shape[1]}"
        )

    if any(is_nonarg(name) for name in all_names):
        raise ValueError("nonARG must not occur in ARG refined prototypes.")

    if len(all_names) != len(set(all_names)):
        raise ValueError("Duplicate subtype names in refined prototype PT.")

    name_to_index = {
        name: i
        for i, name in enumerate(all_names)
    }

    missing = sorted(train_arg_subtypes - set(all_names))

    if missing:
        raise ValueError(
            f"{len(missing)} TRAIN ARG subtype(s) lack refined prototypes. "
            f"Examples={missing[:20]}"
        )

    # Only TRAIN-known ARG subtypes become classifier classes.
    selected_names = [
        name
        for name in all_names
        if name in train_arg_subtypes
    ]

    indices = torch.tensor(
        [name_to_index[name] for name in selected_names],
        dtype=torch.long,
    )

    selected = all_prototypes.index_select(0, indices).contiguous()
    selected = F.normalize(selected, p=2, dim=1)

    if set(selected_names) != train_arg_subtypes:
        raise RuntimeError("Internal train-prototype filtering error.")

    print("\nREFINED PROTOTYPE FILTERING", flush=True)
    print("-" * 108, flush=True)
    print(f"Source refined subtypes : {len(all_names):,}", flush=True)
    print(f"TRAIN classifier classes: {len(selected_names):,}", flush=True)
    print(
        f"Ignored non-TRAIN prototypes: "
        f"{len(all_names) - len(selected_names):,}",
        flush=True,
    )

    return selected_names, selected, obj


def load_and_align_data() -> dict:
    structure = load_split_structure(SPLIT_STRUCTURE_FILE)

    external_train_ids = read_id_file(TRAIN_IDS_FILE)
    external_test_ids = read_id_file(TEST_IDS_FILE)

    external_train_set = set(external_train_ids)
    external_test_set = set(external_test_ids)

    overlap = external_train_set & external_test_set

    if overlap:
        raise ValueError(
            f"External train/test ID overlap: {len(overlap)}. "
            f"Examples={sorted(overlap)[:10]}"
        )

    requested = external_train_set | external_test_set

    missing_structure = requested - set(structure)

    if missing_structure:
        raise ValueError(
            f"{len(missing_structure)} train/test IDs are absent from "
            f"split_structure.txt. Examples={sorted(missing_structure)[:20]}"
        )

    extra_structure = set(structure) - requested

    if extra_structure:
        raise ValueError(
            f"split_structure.txt contains {len(extra_structure)} IDs that are "
            f"not present in train_ids.txt or test_ids.txt. "
            f"Examples={sorted(extra_structure)[:20]}"
        )

    # Cross-check the optional Split column.
    for seq_id in external_train_set:
        declared = structure[seq_id]["declared_split"]

        if declared and declared not in {"train", "training"}:
            raise ValueError(
                f"Structure split disagrees with train_ids.txt: "
                f"{seq_id} -> {declared}"
            )

    for seq_id in external_test_set:
        declared = structure[seq_id]["declared_split"]

        if declared and declared not in {"test", "testing"}:
            raise ValueError(
                f"Structure split disagrees with test_ids.txt: "
                f"{seq_id} -> {declared}"
            )

    # ---------------------------------------------------------------------
    # Strict Novel-Gene checks
    # ---------------------------------------------------------------------
    train_arg_subtypes = {
        structure[seq_id]["subtype"]
        for seq_id in external_train_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    test_arg_subtypes = {
        structure[seq_id]["subtype"]
        for seq_id in external_test_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    subtype_overlap = train_arg_subtypes & test_arg_subtypes

    if subtype_overlap:
        raise ValueError(
            "NOVEL-GENE VIOLATION: TRAIN and TEST ARG subtypes overlap. "
            f"n={len(subtype_overlap)}, examples={sorted(subtype_overlap)[:20]}"
        )

    train_arg_types = {
        structure[seq_id]["type"]
        for seq_id in external_train_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    test_arg_types = {
        structure[seq_id]["type"]
        for seq_id in external_test_set
        if not is_nonarg(structure[seq_id]["subtype"])
    }

    missing_types = test_arg_types - train_arg_types

    if missing_types:
        raise ValueError(
            "NOVEL-GENE VIOLATION: TEST contains ARG Type(s) absent from TRAIN. "
            f"Types={sorted(missing_types)}"
        )

    train_arg_n = sum(
        1
        for seq_id in external_train_set
        if not is_nonarg(structure[seq_id]["subtype"])
    )
    train_nonarg_n = len(external_train_set) - train_arg_n

    test_arg_n = sum(
        1
        for seq_id in external_test_set
        if not is_nonarg(structure[seq_id]["subtype"])
    )
    test_nonarg_n = len(external_test_set) - test_arg_n

    if train_arg_n != train_nonarg_n:
        raise ValueError(
            f"External TRAIN is not 1:1: ARG={train_arg_n}, "
            f"nonARG={train_nonarg_n}"
        )

    if test_arg_n != test_nonarg_n:
        raise ValueError(
            f"External TEST is not 1:1: ARG={test_arg_n}, "
            f"nonARG={test_nonarg_n}"
        )

    # ---------------------------------------------------------------------
    # Load DNABERT-2 and fusion embeddings
    # ---------------------------------------------------------------------
    dna_ids, dna, dna_obj = extract_embedding_pt(
        DNA_PT,
        "DNABERT-2 DNA",
    )

    fusion_ids, fusion, fusion_obj = extract_embedding_pt(
        FUSION_PT,
        "long fusion",
    )

    if dna.shape[1] != 768:
        raise ValueError(
            f"Expected DNABERT-2 embedding dimension 768; found {dna.shape[1]}"
        )

    if fusion.shape[1] != CFG.embedding_dim:
        raise ValueError(
            f"Expected fusion dimension {CFG.embedding_dim}; "
            f"found {fusion.shape[1]}"
        )

    dna_index = {
        seq_id: i
        for i, seq_id in enumerate(dna_ids)
    }

    fusion_index = {
        seq_id: i
        for i, seq_id in enumerate(fusion_ids)
    }

    missing_dna = requested - set(dna_index)
    missing_fusion = requested - set(fusion_index)

    if missing_dna:
        raise ValueError(
            f"{len(missing_dna)} requested IDs are absent from DNA PT. "
            f"Examples={sorted(missing_dna)[:20]}"
        )

    if missing_fusion:
        raise ValueError(
            f"{len(missing_fusion)} requested IDs are absent from Fusion PT. "
            f"Examples={sorted(missing_fusion)[:20]}"
        )

    # Preserve split_structure order for auditability.
    selected_ids = [
        seq_id
        for seq_id in structure
        if seq_id in requested
    ]

    dna_idx = torch.tensor(
        [dna_index[seq_id] for seq_id in selected_ids],
        dtype=torch.long,
    )

    fusion_idx = torch.tensor(
        [fusion_index[seq_id] for seq_id in selected_ids],
        dtype=torch.long,
    )

    dna = dna.index_select(0, dna_idx).contiguous()
    fusion = fusion.index_select(0, fusion_idx).contiguous()

    # ---------------------------------------------------------------------
    # Validation only from new external TRAIN
    # ---------------------------------------------------------------------
    model_splits, external_splits = build_validation_split(
        selected_ids=selected_ids,
        records=structure,
        external_train_set=external_train_set,
        external_test_set=external_test_set,
        validation_fraction=CFG.validation_fraction,
        seed=CFG.seed,
    )

    # ---------------------------------------------------------------------
    # TRAIN-only classifier/prototype space
    # ---------------------------------------------------------------------
    arg_names, refined, refined_obj = load_refined_train_prototypes(
        REFINED_PT,
        train_arg_subtypes,
    )

    arg_to_index = {
        name: i
        for i, name in enumerate(arg_names)
    }

    subtype_to_type: Dict[str, str] = {}

    for seq_id in external_train_set:
        subtype = structure[seq_id]["subtype"]
        type_name = structure[seq_id]["type"]

        if is_nonarg(subtype):
            continue

        previous = subtype_to_type.get(subtype)

        if previous is not None and previous != type_name:
            raise ValueError(
                f"TRAIN subtype maps to multiple Types: "
                f"{subtype}: {previous} vs {type_name}"
            )

        subtype_to_type[subtype] = type_name

    if set(subtype_to_type) != set(arg_names):
        raise RuntimeError(
            "Classifier subtype space and TRAIN subtype-to-Type map differ."
        )

    subtypes = [
        structure[seq_id]["subtype"]
        for seq_id in selected_ids
    ]

    true_types = [
        structure[seq_id]["type"]
        for seq_id in selected_ids
    ]

    binary_targets = torch.tensor(
        [0 if is_nonarg(v) else 1 for v in subtypes],
        dtype=torch.long,
    )

    # TEST novel ARGs deliberately get -1: they are not classifier classes.
    arg_targets = torch.tensor(
        [
            -1
            if is_nonarg(subtype)
            else arg_to_index.get(subtype, -1)
            for subtype in subtypes
        ],
        dtype=torch.long,
    )

    split_indices = {
        split: torch.tensor(
            [
                i
                for i, value in enumerate(model_splits)
                if value == split
            ],
            dtype=torch.long,
        )
        for split in ("train", "validation", "test")
    }

    if any(idx.numel() == 0 for idx in split_indices.values()):
        raise ValueError(
            "train/validation/test must all be non-empty: "
            f"{ {k: int(v.numel()) for k, v in split_indices.items()} }"
        )

    # TRAIN/validation ARGs must belong to the TRAIN classifier space.
    for split in ("train", "validation"):
        idx = split_indices[split]
        yb = binary_targets.index_select(0, idx)
        ya = arg_targets.index_select(0, idx)

        bad = (yb == 1) & (ya < 0)

        if bool(bad.any()):
            raise RuntimeError(
                f"{split} contains ARG rows outside TRAIN classifier space."
            )

    # Every TEST ARG must be unseen and thus outside classifier target space.
    test_idx = split_indices["test"]
    test_yb = binary_targets.index_select(0, test_idx)
    test_ya = arg_targets.index_select(0, test_idx)

    if bool(((test_yb == 1) & (test_ya >= 0)).any()):
        raise RuntimeError(
            "NOVEL-GENE VIOLATION: at least one TEST ARG subtype is present "
            "in the TRAIN classifier class space."
        )

    # Every external TRAIN subtype must survive validation carving.
    model_train_subtypes = {
        subtypes[i]
        for i in split_indices["train"].tolist()
        if not is_nonarg(subtypes[i])
    }

    missing_model_train = set(arg_names) - model_train_subtypes

    if missing_model_train:
        raise RuntimeError(
            f"{len(missing_model_train)} TRAIN subtype(s) were lost after "
            f"validation carving. Examples={sorted(missing_model_train)[:20]}"
        )

    type_names = sorted(train_arg_types, key=str.lower)

    print("\nNOVEL-GENE SPLIT CHECK", flush=True)
    print("-" * 108, flush=True)
    print(f"External TRAIN IDs        : {len(external_train_set):,}", flush=True)
    print(f"External TEST IDs         : {len(external_test_set):,}", flush=True)
    print(
        f"External TRAIN            : ARG={train_arg_n:,}, "
        f"nonARG={train_nonarg_n:,}",
        flush=True,
    )
    print(
        f"External TEST             : ARG={test_arg_n:,}, "
        f"nonARG={test_nonarg_n:,}",
        flush=True,
    )
    print(f"TRAIN ARG subtypes        : {len(train_arg_subtypes):,}", flush=True)
    print(f"TEST ARG subtypes         : {len(test_arg_subtypes):,}", flush=True)
    print(f"Subtype overlap           : {len(subtype_overlap):,}  [PASS]", flush=True)
    print(f"TRAIN ARG Types           : {len(train_arg_types):,}", flush=True)
    print(f"TEST ARG Types            : {len(test_arg_types):,}", flush=True)
    print(f"TEST Type outside TRAIN   : {len(missing_types):,}  [PASS]", flush=True)
    print(f"Classifier ARG classes    : {len(arg_names):,}  [TRAIN only]", flush=True)

    print("\nALIGNED DATA", flush=True)
    print("-" * 108, flush=True)
    print(f"DNA shape                 : {tuple(dna.shape)}", flush=True)
    print(f"Fusion shape              : {tuple(fusion.shape)}", flush=True)
    print(f"Refined TRAIN prototypes  : {tuple(refined.shape)}", flush=True)

    for split, idx in split_indices.items():
        local_binary = binary_targets.index_select(0, idx)

        local_subtypes = {
            subtypes[i]
            for i in idx.tolist()
            if not is_nonarg(subtypes[i])
        }

        print(
            f"{split:10s} | n={idx.numel():,} | "
            f"ARG={int((local_binary == 1).sum()):,} | "
            f"nonARG={int((local_binary == 0).sum()):,} | "
            f"ARG_subtypes={len(local_subtypes):,}",
            flush=True,
        )

    return {
        "ids": selected_ids,
        "subtypes": subtypes,
        "true_types": true_types,
        "dna": dna,
        "fusion": fusion,
        "binary_targets": binary_targets,
        "arg_targets": arg_targets,
        "model_splits": model_splits,
        "external_splits": external_splits,
        "split_indices": split_indices,
        "arg_names": arg_names,
        "refined": refined,
        "subtype_to_type": subtype_to_type,
        "type_names": type_names,
        "train_arg_subtypes": sorted(train_arg_subtypes),
        "test_arg_subtypes": sorted(test_arg_subtypes),
        "train_arg_types": sorted(train_arg_types),
        "test_arg_types": sorted(test_arg_types),
        "source_dna": dna_obj,
        "source_fusion": fusion_obj,
        "source_refined": refined_obj,
    }


# =============================================================================
# Model definitions
# =============================================================================

def mild_class_weights(
    targets: torch.Tensor,
    number_classes: int,
    power: float,
) -> torch.Tensor:

    counts = torch.bincount(
        targets,
        minlength=number_classes,
    ).float()

    if bool((counts == 0).any()):
        missing = torch.where(counts == 0)[0].tolist()

        raise ValueError(
            f"Class weight calculation found absent class(es): "
            f"{missing[:20]}"
        )

    weights = (counts.mean() / counts).pow(power)
    weights = weights / weights.mean()

    return weights.clamp(0.70, 2.50)


class CosineHead(nn.Module):
    def __init__(
        self,
        number_classes: int,
        dimension: int,
        scale: float,
    ):
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(number_classes, dimension)
        )

        nn.init.xavier_uniform_(self.weight)
        self.scale = float(scale)

    def forward(self, features):
        return self.scale * F.linear(
            F.normalize(features, p=2, dim=1),
            F.normalize(self.weight, p=2, dim=1),
        )

    def normalized_weight(self):
        return F.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    def __init__(
        self,
        refined: torch.Tensor,
        config: Config,
    ):
        super().__init__()

        self.binary_head = CosineHead(
            2,
            config.embedding_dim,
            config.logit_scale_binary,
        )

        self.arg_head = CosineHead(
            refined.shape[0],
            config.embedding_dim,
            config.logit_scale_subtype,
        )

        with torch.no_grad():
            self.arg_head.weight.copy_(refined)

    def encode(self, fusion):
        return F.normalize(fusion, p=2, dim=1)

    def forward(self, fusion):
        z = self.encode(fusion)

        return (
            self.binary_head(z),
            self.arg_head(z),
            z,
        )


class ResidualBlock(nn.Module):
    def __init__(
        self,
        dimension: int,
        dropout: float,
    ):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
        )

    def forward(self, x):
        return F.gelu(x + self.net(x))


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        config: Config,
    ):
        super().__init__()

        self.register_buffer(
            "dna_mean",
            dna_mean.clone(),
        )

        self.register_buffer(
            "dna_std",
            dna_std.clone(),
        )

        self.input = nn.Sequential(
            nn.Linear(
                dna_dimension,
                config.hidden_dim,
            ),
            nn.LayerNorm(config.hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
        )

        self.blocks = nn.Sequential(
            ResidualBlock(
                config.hidden_dim,
                config.dropout,
            ),
            ResidualBlock(
                config.hidden_dim,
                config.dropout,
            ),
        )

        self.output = nn.Sequential(
            nn.Linear(
                config.hidden_dim,
                config.embedding_dim,
            ),
            nn.LayerNorm(config.embedding_dim),
        )

        self.binary_head = CosineHead(
            2,
            config.embedding_dim,
            config.logit_scale_binary,
        )

        self.arg_head = CosineHead(
            number_arg_subtypes,
            config.embedding_dim,
            config.logit_scale_subtype,
        )

    def encode(self, dna):
        dna = (
            dna - self.dna_mean
        ) / self.dna_std

        hidden = self.input(dna)
        hidden = self.blocks(hidden)

        return F.normalize(
            self.output(hidden),
            p=2,
            dim=1,
        )

    def forward(self, dna):
        z = self.encode(dna)

        return (
            self.binary_head(z),
            self.arg_head(z),
            z,
        )


# =============================================================================
# Loss / batching helpers
# =============================================================================

def amp_context(enabled: bool):
    return torch.autocast(
        device_type="cuda",
        dtype=torch.float16,
        enabled=enabled,
    )


def make_grad_scaler(enabled: bool):
    try:
        return torch.amp.GradScaler(
            "cuda",
            enabled=enabled,
        )
    except Exception:
        return torch.cuda.amp.GradScaler(enabled=enabled)


def cosine_pull(
    features: torch.Tensor,
    targets: torch.Tensor,
) -> torch.Tensor:

    return (
        1.0
        - (
            F.normalize(features.float(), p=2, dim=1)
            * F.normalize(targets.float(), p=2, dim=1)
        ).sum(dim=1)
    ).mean()


def kd_loss(
    student: torch.Tensor,
    teacher: torch.Tensor,
    temperature: float,
) -> torch.Tensor:

    log_prob = F.log_softmax(
        student.float() / temperature,
        dim=1,
    )

    target_prob = F.softmax(
        teacher.float().detach() / temperature,
        dim=1,
    )

    return (
        F.kl_div(
            log_prob,
            target_prob,
            reduction="batchmean",
        )
        * temperature
        * temperature
    )


def shuffled_effective_groups(
    indices: torch.Tensor,
    effective_batch_size: int,
) -> Iterable[torch.Tensor]:

    order = indices[
        torch.randperm(indices.numel())
    ]

    for start in range(
        0,
        order.numel(),
        effective_batch_size,
    ):
        yield order[
            start : start + effective_batch_size
        ]


def micro_batches(
    group: torch.Tensor,
    micro_batch_size: int,
) -> Iterable[torch.Tensor]:

    for start in range(
        0,
        group.numel(),
        micro_batch_size,
    ):
        yield group[
            start : start + micro_batch_size
        ]


def train_mean_std(
    dna: torch.Tensor,
    train_indices: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:

    x = dna.index_select(0, train_indices)

    mean = x.mean(dim=0)
    std = x.std(dim=0, unbiased=False).clamp_min(1.0e-6)

    return mean, std


def initialize_binary_centers(
    model: nn.Module,
    fusion: torch.Tensor,
    binary_targets: torch.Tensor,
    train_indices: torch.Tensor,
    device: torch.device,
) -> None:

    local_fusion = F.normalize(
        fusion.index_select(0, train_indices),
        p=2,
        dim=1,
    )

    local_binary = binary_targets.index_select(
        0,
        train_indices,
    )

    centers = []

    for label in (0, 1):
        selected = local_fusion[
            local_binary == label
        ]

        if selected.shape[0] == 0:
            raise ValueError(
                f"Binary class {label} absent from model-train."
            )

        centers.append(
            F.normalize(
                selected.mean(dim=0),
                p=2,
                dim=0,
            )
        )

    center_tensor = torch.stack(centers).to(device)

    with torch.no_grad():
        model.binary_head.weight.copy_(center_tensor)


# =============================================================================
# Metrics
# =============================================================================

def safe_mcc(true, predicted) -> float:
    true = np.asarray(true)
    predicted = np.asarray(predicted)

    if (
        len(true) == 0
        or len(np.unique(true)) < 2
        or len(np.unique(predicted)) < 2
    ):
        return 0.0

    return float(
        matthews_corrcoef(true, predicted)
    )


def metric_dict(true, predicted) -> dict:
    true = np.asarray(true)
    predicted = np.asarray(predicted)

    if len(true) == 0:
        return {
            "n": 0,
            "accuracy": 0.0,
            "macro_precision": 0.0,
            "weighted_precision": 0.0,
            "micro_precision": 0.0,
            "macro_recall": 0.0,
            "weighted_recall": 0.0,
            "micro_recall": 0.0,
            "macro_f1": 0.0,
            "weighted_f1": 0.0,
            "micro_f1": 0.0,
            "mcc": 0.0,
        }

    return {
        "n": int(len(true)),
        "accuracy": float(
            accuracy_score(true, predicted)
        ),
        "macro_precision": float(
            precision_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_precision": float(
            precision_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_precision": float(
            precision_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "macro_recall": float(
            recall_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_recall": float(
            recall_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_recall": float(
            recall_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "macro_f1": float(
            f1_score(
                true,
                predicted,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                true,
                predicted,
                average="weighted",
                zero_division=0,
            )
        ),
        "micro_f1": float(
            f1_score(
                true,
                predicted,
                average="micro",
                zero_division=0,
            )
        ),
        "mcc": safe_mcc(true, predicted),
    }


@torch.inference_mode()
def collect_outputs(
    model: nn.Module,
    inputs: torch.Tensor,
    indices: torch.Tensor,
    device: torch.device,
    use_amp: bool,
) -> dict:

    model.eval()

    all_indices = []
    binary_logits = []
    arg_logits = []
    features = []

    for start in range(
        0,
        indices.numel(),
        CFG.eval_micro_batch_size,
    ):

        local_idx = indices[
            start : start + CFG.eval_micro_batch_size
        ]

        xb = inputs.index_select(
            0,
            local_idx,
        ).to(
            device,
            non_blocking=True,
        )

        with amp_context(use_amp):
            binary, subtype, z = model(xb)

        all_indices.append(local_idx.cpu())
        binary_logits.append(binary.float().cpu())
        arg_logits.append(subtype.float().cpu())
        features.append(z.float().cpu())

    return {
        "indices": torch.cat(all_indices),
        "binary_logits": torch.cat(binary_logits),
        "arg_logits": torch.cat(arg_logits),
        "features": torch.cat(features),
    }


def validation_metrics_from_outputs(
    outputs: dict,
    data: dict,
    binary_threshold: float = 0.50,
) -> Tuple[dict, dict]:

    idx = outputs["indices"]

    true_binary = (
        data["binary_targets"]
        .index_select(0, idx)
        .numpy()
    )

    true_arg = (
        data["arg_targets"]
        .index_select(0, idx)
        .numpy()
    )

    arg_prob = (
        torch.softmax(
            outputs["binary_logits"],
            dim=1,
        )[:, 1]
        .numpy()
    )

    pred_binary = (
        arg_prob >= binary_threshold
    ).astype(np.int64)

    pred_arg = (
        outputs["arg_logits"]
        .argmax(dim=1)
        .numpy()
    )

    arg_mask = true_binary == 1

    if bool((true_arg[arg_mask] < 0).any()):
        raise RuntimeError(
            "Validation contains ARG subtype outside TRAIN class space."
        )

    true_full = np.where(
        true_binary == 0,
        0,
        true_arg + 1,
    )

    pred_full = np.where(
        pred_binary == 0,
        0,
        pred_arg + 1,
    )

    metrics = {
        "binary": metric_dict(
            true_binary,
            pred_binary,
        ),
        "ARG_subtype_oracle_binary": metric_dict(
            true_arg[arg_mask],
            pred_arg[arg_mask],
        ),
        "end_to_end_all_classes": metric_dict(
            true_full,
            pred_full,
        ),
    }

    arrays = {
        "true_binary": true_binary,
        "pred_binary": pred_binary,
        "true_arg": true_arg,
        "pred_arg": pred_arg,
        "ARG_probability": arg_prob,
    }

    return metrics, arrays


def validation_score(metrics: dict) -> float:
    full = metrics["end_to_end_all_classes"]
    subtype = metrics["ARG_subtype_oracle_binary"]
    binary = metrics["binary"]

    # Preserve the uploaded DNA precision-priority validation score.
    return (
        0.45 * float(subtype["weighted_precision"])
        + 0.25 * float(full["weighted_precision"])
        + 0.15 * float(full["accuracy"])
        + 0.10 * float(full["mcc"])
        + 0.05 * float(binary["weighted_precision"])
    )


def novel_test_metrics_from_outputs(
    outputs: dict,
    data: dict,
) -> Tuple[dict, List[dict]]:

    idx = outputs["indices"]
    idx_np = idx.numpy()

    true_binary = (
        data["binary_targets"]
        .index_select(0, idx)
        .numpy()
    )

    arg_prob = (
        torch.softmax(
            outputs["binary_logits"],
            dim=1,
        )[:, 1]
        .numpy()
    )

    pred_binary = (
        arg_prob >= CFG.binary_threshold
    ).astype(np.int64)

    pred_arg_idx = (
        outputs["arg_logits"]
        .argmax(dim=1)
        .numpy()
    )

    arg_softmax = torch.softmax(
        outputs["arg_logits"],
        dim=1,
    ).numpy()

    pred_known_subtype = [
        data["arg_names"][int(i)]
        for i in pred_arg_idx
    ]

    pred_known_type = [
        data["subtype_to_type"][subtype]
        for subtype in pred_known_subtype
    ]

    true_subtypes = [
        data["subtypes"][int(i)]
        for i in idx_np
    ]

    true_types = [
        NONARG
        if true_binary[j] == 0
        else data["true_types"][int(i)]
        for j, i in enumerate(idx_np)
    ]

    # Final deployed behavior includes the binary gate.
    pred_types = [
        NONARG
        if pred_binary[j] == 0
        else pred_known_type[j]
        for j in range(len(pred_binary))
    ]

    # Diagnostic: Type transfer from subtype head when binary status is known.
    oracle_pred_types = list(pred_known_type)

    arg_mask = true_binary == 1

    metrics = {
        "ARG_nonARG": metric_dict(
            true_binary,
            pred_binary,
        ),

        # Strict Type result on true novel ARGs. A binary false negative is
        # predicted Type nonARG and therefore counted as incorrect.
        "Type_on_true_ARG": metric_dict(
            np.asarray(true_types, dtype=object)[arg_mask],
            np.asarray(pred_types, dtype=object)[arg_mask],
        ),

        # Diagnostic only: ignores binary gating and tests whether a predicted
        # known subtype still maps to the correct resistance Type.
        "Type_oracle_binary": metric_dict(
            np.asarray(true_types, dtype=object)[arg_mask],
            np.asarray(oracle_pred_types, dtype=object)[arg_mask],
        ),

        # End-to-end label space = nonARG + resistance Types.
        "End_to_end_Type": metric_dict(
            np.asarray(true_types, dtype=object),
            np.asarray(pred_types, dtype=object),
        ),
    }

    rows = []

    for j, global_i in enumerate(idx_np):
        seq_id = data["ids"][int(global_i)]
        true_subtype = data["subtypes"][int(global_i)]

        rows.append(
            {
                "sequence_id": seq_id,
                "split": "test",
                "true_ARG": int(true_binary[j]),
                "pred_ARG": int(pred_binary[j]),
                "ARG_probability": float(arg_prob[j]),
                "binary_threshold": float(CFG.binary_threshold),
                "true_subtype": true_subtype,
                "predicted_known_subtype": pred_known_subtype[j],
                "predicted_known_subtype_probability": float(
                    arg_softmax[j, pred_arg_idx[j]]
                ),
                "true_type": true_types[j],
                "predicted_type": pred_types[j],
                "predicted_type_oracle_binary": oracle_pred_types[j],
                "type_correct": int(
                    str(true_types[j]) == str(pred_types[j])
                ),
                "novel_ARG_subtype": int(
                    true_binary[j] == 1
                    and true_subtype not in data["arg_names"]
                ),
            }
        )

    return metrics, rows


# =============================================================================
# Teacher training
# =============================================================================

def train_teacher(
    data: dict,
    device: torch.device,
    use_amp: bool,
) -> Tuple[FusionTeacher, dict, List[dict]]:

    refined_gpu = data["refined"].to(device)

    teacher = FusionTeacher(
        refined_gpu,
        CFG,
    ).to(device)

    train_idx = data["split_indices"]["train"]
    val_idx = data["split_indices"]["validation"]

    initialize_binary_centers(
        teacher,
        data["fusion"],
        data["binary_targets"],
        train_idx,
        device,
    )

    train_binary = data["binary_targets"].index_select(
        0,
        train_idx,
    )

    train_arg = data["arg_targets"].index_select(
        0,
        train_idx,
    )

    arg_only = train_arg[
        train_binary == 1
    ]

    subtype_weight = mild_class_weights(
        arg_only,
        len(data["arg_names"]),
        CFG.class_weight_power,
    ).to(device)

    optimizer = torch.optim.AdamW(
        teacher.parameters(),
        lr=CFG.teacher_lr,
        weight_decay=CFG.weight_decay,
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=5,
        min_lr=1.0e-6,
    )

    scaler = make_grad_scaler(use_amp)

    best_score = -float("inf")
    best_epoch = 0
    best_state = None
    no_improvement = 0

    history: List[dict] = []

    print("\nTRAIN FUSION TEACHER", flush=True)
    print("-" * 108, flush=True)

    for epoch in range(1, CFG.teacher_epochs + 1):
        epoch_started = time.time()
        teacher.train()

        total_loss_sum = 0.0
        total_n = 0

        for group in shuffled_effective_groups(
            train_idx,
            CFG.batch_size,
        ):

            optimizer.zero_grad(set_to_none=True)

            group_n = int(group.numel())
            group_binary = data["binary_targets"].index_select(0, group)
            group_arg_n = int((group_binary == 1).sum())

            if group_arg_n <= 0:
                raise RuntimeError(
                    "A logical Teacher batch contains no ARG samples."
                )

            for local_idx in micro_batches(
                group,
                CFG.micro_batch_size,
            ):

                xb = data["fusion"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                yb = data["binary_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                ya = data["arg_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                with amp_context(use_amp):
                    binary_logits, arg_logits, z = teacher(xb)

                    loss_binary = F.cross_entropy(
                        binary_logits.float(),
                        yb,
                        label_smoothing=CFG.label_smoothing,
                    )

                    arg_mask = yb == 1
                    local_arg_n = int(arg_mask.sum())

                    if local_arg_n > 0:
                        loss_subtype = F.cross_entropy(
                            arg_logits[arg_mask].float(),
                            ya[arg_mask],
                            weight=subtype_weight,
                            label_smoothing=CFG.label_smoothing,
                        )
                    else:
                        loss_subtype = binary_logits.sum() * 0.0

                    loss_feature = cosine_pull(
                        z,
                        F.normalize(xb, p=2, dim=1),
                    )

                    loss_refined = (
                        1.0
                        - (
                            teacher.arg_head.normalized_weight()
                            * refined_gpu
                        ).sum(dim=1)
                    ).mean()

                    scale_all = (
                        float(local_idx.numel())
                        / float(group_n)
                    )

                    scale_arg = (
                        float(local_arg_n)
                        / float(group_arg_n)
                    )

                    # Component-wise scaling reproduces the logical 4096-sample
                    # batch means under micro-batch gradient accumulation.
                    loss_scaled = (
                        CFG.teacher_binary_ce
                        * loss_binary
                        * scale_all
                        + CFG.teacher_subtype_ce
                        * loss_subtype
                        * scale_arg
                        + CFG.teacher_feature_anchor
                        * loss_feature
                        * scale_all
                        + CFG.teacher_refined_anchor
                        * loss_refined
                        * scale_all
                    )

                    # Unscaled loss only for readable epoch logging.
                    loss_display = (
                        CFG.teacher_binary_ce * loss_binary
                        + CFG.teacher_subtype_ce * loss_subtype
                        + CFG.teacher_feature_anchor * loss_feature
                        + CFG.teacher_refined_anchor * loss_refined
                    )

                scaler.scale(loss_scaled).backward()

                total_loss_sum += (
                    float(loss_display.detach().cpu())
                    * local_idx.numel()
                )
                total_n += int(local_idx.numel())

            scaler.unscale_(optimizer)

            torch.nn.utils.clip_grad_norm_(
                teacher.parameters(),
                CFG.gradient_clip,
            )

            scaler.step(optimizer)
            scaler.update()

        val_outputs = collect_outputs(
            teacher,
            data["fusion"],
            val_idx,
            device,
            use_amp,
        )

        # Preserve the old DNA model-selection rule: threshold 0.50 is used
        # for validation score; the final GRID-best threshold 0.80 is applied
        # only after model selection.
        val_metrics, _ = validation_metrics_from_outputs(
            val_outputs,
            data,
            binary_threshold=0.50,
        )

        score = validation_score(val_metrics)
        scheduler.step(score)

        row = {
            "stage": "Teacher",
            "epoch": epoch,
            "training_loss": total_loss_sum / max(total_n, 1),
            "validation_score": score,
            "val_binary_accuracy": val_metrics["binary"]["accuracy"],
            "val_binary_weighted_precision": val_metrics["binary"]["weighted_precision"],
            "val_subtype_accuracy": val_metrics["ARG_subtype_oracle_binary"]["accuracy"],
            "val_subtype_weighted_precision": val_metrics["ARG_subtype_oracle_binary"]["weighted_precision"],
            "val_end_accuracy": val_metrics["end_to_end_all_classes"]["accuracy"],
            "val_end_weighted_precision": val_metrics["end_to_end_all_classes"]["weighted_precision"],
            "val_end_macro_f1": val_metrics["end_to_end_all_classes"]["macro_f1"],
            "val_end_mcc": val_metrics["end_to_end_all_classes"]["mcc"],
            "lr": optimizer.param_groups[0]["lr"],
            "epoch_seconds": time.time() - epoch_started,
        }

        history.append(row)

        improved = score > best_score + CFG.min_delta

        if improved:
            best_score = score
            best_epoch = epoch

            best_state = copy.deepcopy(
                {
                    key: value.detach().cpu()
                    for key, value in teacher.state_dict().items()
                }
            )

            no_improvement = 0
        else:
            no_improvement += 1

        write_csv(
            OUTPUT_DIR / "teacher_training_history.csv",
            history,
        )

        print(
            f"Teacher {epoch:03d}/{CFG.teacher_epochs} | "
            f"loss={row['training_loss']:.6f} | "
            f"val_score={score:.6f} | "
            f"val_ACC={row['val_end_accuracy']:.6f} | "
            f"val_WP={row['val_end_weighted_precision']:.6f} | "
            f"val_MCC={row['val_end_mcc']:.6f} | "
            f"lr={row['lr']:.2e} | "
            f"best={best_score:.6f}@{best_epoch}",
            flush=True,
        )

        if no_improvement >= CFG.teacher_patience:
            print(
                f"Teacher early stopping at epoch {epoch}; "
                f"best epoch={best_epoch}.",
                flush=True,
            )
            break

    if best_state is None:
        raise RuntimeError(
            "Teacher training did not produce a best state."
        )

    teacher.load_state_dict(best_state, strict=True)
    teacher.eval()

    result = {
        "best_epoch": best_epoch,
        "best_validation_score": best_score,
        "state_dict": best_state,
    }

    return teacher, result, history


# =============================================================================
# Student training
# =============================================================================

def train_student(
    data: dict,
    teacher: FusionTeacher,
    device: torch.device,
    use_amp: bool,
) -> Tuple[DNAStudent, dict, List[dict]]:

    train_idx = data["split_indices"]["train"]
    val_idx = data["split_indices"]["validation"]

    dna_mean, dna_std = train_mean_std(
        data["dna"],
        train_idx,
    )

    student = DNAStudent(
        dna_dimension=data["dna"].shape[1],
        dna_mean=dna_mean.to(device),
        dna_std=dna_std.to(device),
        number_arg_subtypes=len(data["arg_names"]),
        config=CFG,
    ).to(device)

    refined_gpu = data["refined"].to(device)

    # Preserve the original DNA training logic: initialize both Student heads
    # directly from the selected Fusion Teacher heads.
    with torch.no_grad():
        student.binary_head.weight.copy_(
            teacher.binary_head.weight
        )
        student.arg_head.weight.copy_(
            teacher.arg_head.weight
        )

    teacher_binary_anchor = (
        teacher.binary_head
        .normalized_weight()
        .detach()
    )

    teacher_arg_anchor = (
        teacher.arg_head
        .normalized_weight()
        .detach()
    )

    # Train-only nonARG center in Teacher/fusion space.
    train_fusion = F.normalize(
        data["fusion"].index_select(
            0,
            train_idx,
        ),
        p=2,
        dim=1,
    )

    train_binary = data["binary_targets"].index_select(
        0,
        train_idx,
    )

    nonarg_features = train_fusion[
        train_binary == 0
    ]

    if nonarg_features.shape[0] == 0:
        raise ValueError(
            "No model-train nonARG sequences."
        )

    nonarg_center = F.normalize(
        nonarg_features.mean(dim=0),
        p=2,
        dim=0,
    ).to(device)

    train_arg = data["arg_targets"].index_select(
        0,
        train_idx,
    )

    arg_only = train_arg[
        train_binary == 1
    ]

    subtype_weight = mild_class_weights(
        arg_only,
        len(data["arg_names"]),
        CFG.class_weight_power,
    ).to(device)

    optimizer = torch.optim.AdamW(
        student.parameters(),
        lr=CFG.student_lr,
        weight_decay=CFG.weight_decay,
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=7,
        min_lr=1.0e-6,
    )

    scaler = make_grad_scaler(use_amp)

    teacher.eval()

    for p in teacher.parameters():
        p.requires_grad_(False)

    best_score = -float("inf")
    best_epoch = 0
    best_state = None
    no_improvement = 0
    early_stop_notified = False

    history: List[dict] = []

    print("\nTRAIN DNA STUDENT", flush=True)
    print("-" * 108, flush=True)

    for epoch in range(1, CFG.student_epochs + 1):
        epoch_started = time.time()
        student.train()

        total_loss_sum = 0.0
        total_n = 0

        for group in shuffled_effective_groups(
            train_idx,
            CFG.batch_size,
        ):

            optimizer.zero_grad(set_to_none=True)

            group_n = int(group.numel())
            group_binary = data["binary_targets"].index_select(0, group)
            group_arg_n = int((group_binary == 1).sum())

            if group_arg_n <= 0:
                raise RuntimeError(
                    "A logical Student batch contains no ARG samples."
                )

            for local_idx in micro_batches(
                group,
                CFG.micro_batch_size,
            ):

                dna = data["dna"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                fusion = data["fusion"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                yb = data["binary_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                ya = data["arg_targets"].index_select(
                    0,
                    local_idx,
                ).to(device, non_blocking=True)

                with torch.no_grad():
                    with amp_context(use_amp):
                        (
                            teacher_binary,
                            teacher_arg,
                            teacher_z,
                        ) = teacher(fusion)

                with amp_context(use_amp):
                    (
                        student_binary,
                        student_arg,
                        student_z,
                    ) = student(dna)

                    loss_binary = F.cross_entropy(
                        student_binary.float(),
                        yb,
                        label_smoothing=CFG.label_smoothing,
                    )

                    arg_mask = yb == 1
                    local_arg_n = int(arg_mask.sum())

                    if local_arg_n > 0:
                        loss_subtype = F.cross_entropy(
                            student_arg[arg_mask].float(),
                            ya[arg_mask],
                            weight=subtype_weight,
                            label_smoothing=CFG.label_smoothing,
                        )

                        loss_subtype_kd = kd_loss(
                            student_arg[arg_mask],
                            teacher_arg[arg_mask],
                            CFG.temperature,
                        )
                    else:
                        loss_subtype = student_binary.sum() * 0.0
                        loss_subtype_kd = student_binary.sum() * 0.0

                    loss_binary_kd = kd_loss(
                        student_binary,
                        teacher_binary,
                        CFG.temperature,
                    )

                    loss_feature = cosine_pull(
                        student_z,
                        teacher_z,
                    )

                    target_prototypes = torch.empty_like(
                        student_z
                    )

                    if local_arg_n > 0:
                        target_prototypes[arg_mask] = (
                            refined_gpu.index_select(
                                0,
                                ya[arg_mask],
                            )
                        )

                    target_prototypes[~arg_mask] = nonarg_center

                    loss_prototype = cosine_pull(
                        student_z,
                        target_prototypes,
                    )

                    # Preserve DNA head anchoring to Teacher binary + subtype
                    # cosine-head directions.
                    loss_head = (
                        1.0
                        - (
                            student.binary_head.normalized_weight()
                            * teacher_binary_anchor
                        ).sum(dim=1)
                    ).mean() + (
                        1.0
                        - (
                            student.arg_head.normalized_weight()
                            * teacher_arg_anchor
                        ).sum(dim=1)
                    ).mean()

                    scale_all = (
                        float(local_idx.numel())
                        / float(group_n)
                    )

                    scale_arg = (
                        float(local_arg_n)
                        / float(group_arg_n)
                    )

                    loss_scaled = (
                        CFG.student_binary_ce
                        * loss_binary
                        * scale_all
                        + CFG.student_subtype_ce
                        * loss_subtype
                        * scale_arg
                        + CFG.student_binary_kd
                        * loss_binary_kd
                        * scale_all
                        + CFG.student_subtype_kd
                        * loss_subtype_kd
                        * scale_arg
                        + CFG.student_feature_align
                        * loss_feature
                        * scale_all
                        + CFG.student_prototype_align
                        * loss_prototype
                        * scale_all
                        + CFG.student_head_anchor
                        * loss_head
                        * scale_all
                    )

                    loss_display = (
                        CFG.student_binary_ce * loss_binary
                        + CFG.student_subtype_ce * loss_subtype
                        + CFG.student_binary_kd * loss_binary_kd
                        + CFG.student_subtype_kd * loss_subtype_kd
                        + CFG.student_feature_align * loss_feature
                        + CFG.student_prototype_align * loss_prototype
                        + CFG.student_head_anchor * loss_head
                    )

                scaler.scale(loss_scaled).backward()

                total_loss_sum += (
                    float(loss_display.detach().cpu())
                    * local_idx.numel()
                )
                total_n += int(local_idx.numel())

            scaler.unscale_(optimizer)

            torch.nn.utils.clip_grad_norm_(
                student.parameters(),
                CFG.gradient_clip,
            )

            scaler.step(optimizer)
            scaler.update()

        val_outputs = collect_outputs(
            student,
            data["dna"],
            val_idx,
            device,
            use_amp,
        )

        # Same DNA validation selection convention as the uploaded NSCC code.
        val_metrics, _ = validation_metrics_from_outputs(
            val_outputs,
            data,
            binary_threshold=0.50,
        )

        score = validation_score(val_metrics)
        scheduler.step(score)

        row = {
            "stage": "Student",
            "epoch": epoch,
            "training_loss": total_loss_sum / max(total_n, 1),
            "validation_score": score,
            "val_binary_accuracy": val_metrics["binary"]["accuracy"],
            "val_binary_weighted_precision": val_metrics["binary"]["weighted_precision"],
            "val_subtype_accuracy": val_metrics["ARG_subtype_oracle_binary"]["accuracy"],
            "val_subtype_weighted_precision": val_metrics["ARG_subtype_oracle_binary"]["weighted_precision"],
            "val_end_accuracy": val_metrics["end_to_end_all_classes"]["accuracy"],
            "val_end_weighted_precision": val_metrics["end_to_end_all_classes"]["weighted_precision"],
            "val_end_macro_f1": val_metrics["end_to_end_all_classes"]["macro_f1"],
            "val_end_mcc": val_metrics["end_to_end_all_classes"]["mcc"],
            "lr": optimizer.param_groups[0]["lr"],
            "epoch_seconds": time.time() - epoch_started,
        }

        history.append(row)

        improved = score > best_score + CFG.min_delta

        if improved:
            best_score = score
            best_epoch = epoch

            best_state = copy.deepcopy(
                {
                    key: value.detach().cpu()
                    for key, value in student.state_dict().items()
                }
            )

            no_improvement = 0

            safe_torch_save(
                {
                    "model_name": (
                        "DNA Novel-Gene Student best-so-far"
                    ),
                    "script_version": SCRIPT_VERSION,
                    "epoch": int(best_epoch),
                    "validation_score": float(best_score),
                    "student_state_dict": best_state,
                    "dna_train_mean": dna_mean.detach().cpu(),
                    "dna_train_std": dna_std.detach().cpu(),
                    "configuration": asdict(CFG),
                    "binary_threshold": float(CFG.binary_threshold),
                    "arg_subtype_names": list(data["arg_names"]),
                    "subtype_to_type": dict(data["subtype_to_type"]),
                    "validation_metrics": copy.deepcopy(val_metrics),
                },
                OUTPUT_DIR / "DNA_student_best_so_far.pt",
            )

        else:
            no_improvement += 1

        write_csv(
            OUTPUT_DIR / "student_training_history.csv",
            history,
        )

        print(
            f"Student {epoch:03d}/{CFG.student_epochs} | "
            f"loss={row['training_loss']:.6f} | "
            f"val_score={score:.6f} | "
            f"val_ACC={row['val_end_accuracy']:.6f} | "
            f"val_WP={row['val_end_weighted_precision']:.6f} | "
            f"val_MCC={row['val_end_mcc']:.6f} | "
            f"lr={row['lr']:.2e} | "
            f"best={best_score:.6f}@{best_epoch}",
            flush=True,
        )

        if no_improvement >= CFG.student_patience:
            if CFG.continue_student_to_max_epochs:
                if not early_stop_notified:
                    print(
                        f"Student early-stop criterion reached at epoch "
                        f"{epoch}; best epoch={best_epoch}. "
                        f"Continuing to epoch {CFG.student_epochs} to preserve "
                        f"the uploaded DNA trajectory-run behavior.",
                        flush=True,
                    )
                    early_stop_notified = True
            else:
                print(
                    f"Student early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}.",
                    flush=True,
                )
                break

    if best_state is None:
        raise RuntimeError(
            "DNA Student training did not produce a best state."
        )

    student.load_state_dict(best_state, strict=True)
    student.eval()

    result = {
        "best_epoch": best_epoch,
        "best_validation_score": best_score,
        "state_dict": best_state,
        "dna_mean": dna_mean,
        "dna_std": dna_std,
    }

    return student, result, history


# =============================================================================
# Reporting
# =============================================================================

def flatten_metric_rows(metrics: dict) -> List[dict]:
    rows = []

    for task, values in metrics.items():
        row = {"task": task}
        row.update(values)
        rows.append(row)

    return rows


def report_metrics(title: str, metrics: dict) -> None:
    print(f"\n{title}", flush=True)
    print("-" * 108, flush=True)

    for task, values in metrics.items():
        print(
            f"{task:22s} | "
            f"n={values['n']:,} | "
            f"ACC={values['accuracy']:.6f} | "
            f"weighted_P={values['weighted_precision']:.6f} | "
            f"macro_P={values['macro_precision']:.6f} | "
            f"weighted_F1={values['weighted_f1']:.6f} | "
            f"macro_F1={values['macro_f1']:.6f} | "
            f"MCC={values['mcc']:.6f}",
            flush=True,
        )


def save_split_audit(data: dict) -> None:
    rows = []

    for i, seq_id in enumerate(data["ids"]):
        rows.append(
            {
                "sequence_id": seq_id,
                "external_split": data["external_splits"][i],
                "model_split": data["model_splits"][i],
                "ARG_or_nonARG": (
                    "nonARG"
                    if is_nonarg(data["subtypes"][i])
                    else "ARG"
                ),
                "Subtype": data["subtypes"][i],
                "Type": data["true_types"][i],
                "in_classifier_class_space": int(
                    data["subtypes"][i] in data["arg_names"]
                ),
            }
        )

    write_csv(
        OUTPUT_DIR / "model_split_audit.csv",
        rows,
    )


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    started = time.time()

    check_input_files()
    prepare_output_dir()

    device = require_cuda()
    seed_everything(CFG.seed)

    use_amp = True

    print("\nINPUT FILES", flush=True)
    print("-" * 108, flush=True)
    print(f"ROOT          : {ROOT}", flush=True)
    print(f"DNA PT        : {DNA_PT}", flush=True)
    print(f"Fusion PT     : {FUSION_PT}", flush=True)
    print(f"Refined PT    : {REFINED_PT}", flush=True)
    print(f"Train IDs     : {TRAIN_IDS_FILE}", flush=True)
    print(f"Test IDs      : {TEST_IDS_FILE}", flush=True)
    print(f"Structure     : {SPLIT_STRUCTURE_FILE}", flush=True)
    print(f"Output        : {OUTPUT_DIR}", flush=True)

    print("\nFIXED DNA GRID-BEST PARAMETERS", flush=True)
    print("-" * 108, flush=True)

    for key, value in asdict(CFG).items():
        print(f"{key:32s}: {value}", flush=True)

    data = load_and_align_data()
    save_split_audit(data)

    print(
        "\n[PROVENANCE NOTE] Current Teacher/Student optimization uses only the "
        "new Novel-Gene TRAIN/validation class space. Long_fusion.pt and the "
        "refined residual-GAT prototype PT are precomputed upstream artifacts. "
        "If the final manuscript claims a fully end-to-end leakage-free "
        "Novel-Gene experiment, those upstream artifacts should also be "
        "regenerated from this same Novel-Gene TRAIN split.",
        flush=True,
    )

    # ---------------------------------------------------------------------
    # Stage 1: Fusion Teacher
    # ---------------------------------------------------------------------
    teacher, teacher_result, teacher_history = train_teacher(
        data,
        device,
        use_amp,
    )

    safe_torch_save(
        {
            "script_version": SCRIPT_VERSION,
            "teacher_state_dict": {
                key: value.detach().cpu()
                for key, value in teacher.state_dict().items()
            },
            "teacher_best_epoch": int(
                teacher_result["best_epoch"]
            ),
            "teacher_best_validation_score": float(
                teacher_result["best_validation_score"]
            ),
            "configuration": asdict(CFG),
            "arg_subtype_names": list(data["arg_names"]),
        },
        OUTPUT_DIR / "fusion_teacher_best.pt",
    )

    torch.cuda.empty_cache()

    # ---------------------------------------------------------------------
    # Stage 2: DNA Student
    # ---------------------------------------------------------------------
    student, student_result, student_history = train_student(
        data,
        teacher,
        device,
        use_amp,
    )

    torch.cuda.empty_cache()

    # ---------------------------------------------------------------------
    # Final validation reporting using deployment threshold 0.80
    # ---------------------------------------------------------------------
    val_outputs = collect_outputs(
        student,
        data["dna"],
        data["split_indices"]["validation"],
        device,
        use_amp,
    )

    val_metrics_fixed_threshold, _ = validation_metrics_from_outputs(
        val_outputs,
        data,
        binary_threshold=CFG.binary_threshold,
    )

    save_json(
        OUTPUT_DIR / "validation_metrics.json",
        {
            "binary_threshold": CFG.binary_threshold,
            "metrics": val_metrics_fixed_threshold,
        },
    )

    # ---------------------------------------------------------------------
    # FINAL TEST
    # TEST is evaluated only after Teacher/Student selection is finished.
    # ---------------------------------------------------------------------
    print("\nFINAL NOVEL-GENE TEST EVALUATION START", flush=True)

    test_outputs = collect_outputs(
        student,
        data["dna"],
        data["split_indices"]["test"],
        device,
        use_amp,
    )

    test_metrics, test_prediction_rows = novel_test_metrics_from_outputs(
        test_outputs,
        data,
    )

    report_metrics(
        "FINAL DNA NOVEL-GENE TEST RESULTS",
        test_metrics,
    )

    write_csv(
        OUTPUT_DIR / "test_metrics.csv",
        flatten_metric_rows(test_metrics),
    )

    write_csv(
        OUTPUT_DIR / "test_sequence_predictions.csv",
        test_prediction_rows,
    )

    write_csv(
        OUTPUT_DIR / "training_history.csv",
        teacher_history + student_history,
    )

    # ---------------------------------------------------------------------
    # Final checkpoint
    # ---------------------------------------------------------------------
    checkpoint = {
        "model_name": "ARGScope DNA Student - 100% Novel-Gene",
        "script_version": SCRIPT_VERSION,
        "configuration": asdict(CFG),
        "student_state_dict": {
            key: value.detach().cpu()
            for key, value in student.state_dict().items()
        },
        "teacher_state_dict": {
            key: value.detach().cpu()
            for key, value in teacher.state_dict().items()
        },
        "dna_input_dimension": 768,
        "embedding_dimension": CFG.embedding_dim,
        "arg_subtype_names": data["arg_names"],
        "classifier_class_space_definition": (
            "TRAIN ARG subtypes only; TEST ARG subtypes are unseen"
        ),
        "subtype_to_type": data["subtype_to_type"],
        "type_names": data["type_names"],
        "selected_binary_ARG_probability_threshold": CFG.binary_threshold,
        "dna_train_mean": student_result["dna_mean"],
        "dna_train_std": student_result["dna_std"],
        "train_only_refined_ARG_subtype_prototypes": data["refined"],
        "teacher_best_epoch": teacher_result["best_epoch"],
        "teacher_best_validation_score": teacher_result[
            "best_validation_score"
        ],
        "student_best_epoch": student_result["best_epoch"],
        "student_best_validation_score": student_result[
            "best_validation_score"
        ],
        "novel_gene_split": {
            "train_ARG_subtypes": data["train_arg_subtypes"],
            "test_ARG_subtypes": data["test_arg_subtypes"],
            "train_ARG_types": data["train_arg_types"],
            "test_ARG_types": data["test_arg_types"],
            "ARG_subtype_overlap_count": len(
                set(data["train_arg_subtypes"])
                & set(data["test_arg_subtypes"])
            ),
        },
        "test_metrics": test_metrics,
        "source_files": {
            "dna_pt": str(DNA_PT),
            "fusion_pt": str(FUSION_PT),
            "refined_pt": str(REFINED_PT),
            "train_ids": str(TRAIN_IDS_FILE),
            "test_ids": str(TEST_IDS_FILE),
            "split_structure": str(SPLIT_STRUCTURE_FILE),
        },
    }

    safe_torch_save(
        checkpoint,
        OUTPUT_DIR / "DNA_novelgene_100pct_best_model.pt",
    )

    run_summary = {
        "script_version": SCRIPT_VERSION,
        "configuration": asdict(CFG),
        "teacher_best_epoch": teacher_result["best_epoch"],
        "teacher_best_validation_score": teacher_result[
            "best_validation_score"
        ],
        "student_best_epoch": student_result["best_epoch"],
        "student_best_validation_score": student_result[
            "best_validation_score"
        ],
        "binary_threshold": CFG.binary_threshold,
        "classifier_ARG_subtypes": len(data["arg_names"]),
        "train_ARG_subtypes": len(data["train_arg_subtypes"]),
        "test_novel_ARG_subtypes": len(data["test_arg_subtypes"]),
        "train_test_ARG_subtype_overlap": len(
            set(data["train_arg_subtypes"])
            & set(data["test_arg_subtypes"])
        ),
        "train_ARG_types": len(data["train_arg_types"]),
        "test_ARG_types": len(data["test_arg_types"]),
        "test_metrics": test_metrics,
        "elapsed_seconds": time.time() - started,
    }

    save_json(
        OUTPUT_DIR / "run_summary.json",
        run_summary,
    )

    print("\nOUTPUT FILES", flush=True)
    print("-" * 108, flush=True)

    for name in (
        "DNA_novelgene_100pct_best_model.pt",
        "fusion_teacher_best.pt",
        "training_history.csv",
        "teacher_training_history.csv",
        "student_training_history.csv",
        "validation_metrics.json",
        "test_metrics.csv",
        "test_sequence_predictions.csv",
        "model_split_audit.csv",
        "run_summary.json",
    ):

        path = OUTPUT_DIR / name

        print(
            f"{name:42s} | "
            f"{path.stat().st_size / 1024**2:.2f} MB",
            flush=True,
        )

    print(
        f"\nCompleted in {(time.time() - started) / 60:.2f} min.",
        flush=True,
    )


if __name__ == "__main__":
    main()
