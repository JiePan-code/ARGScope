#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create three-row macro/weighted/micro test summaries for Type and subtype.

Put this file in one Student-result folder and run it directly.  It finds the
sequence-level prediction CSV in that folder, then writes two files:

  test_subtype_five_metrics_averages.csv
  test_type_five_metrics_averages.csv
  test_model_overall_five_metrics.csv

The five reported metrics are Accuracy, Precision, Recall, F1 and MCC.  MCC
and Accuracy are global quantities, so they are repeated in the macro,
weighted and micro rows.  The precision/recall/F1 columns are averaged as
specified by each row.
"""
from __future__ import annotations

import csv
import re
from pathlib import Path

from sklearn.metrics import (
    accuracy_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
)


HERE = Path(__file__).resolve().parent


def normalise(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


TRUE_COLUMNS = {
    "subtype": (
        "truesubtype", "groundtruthsubtype", "actualsubtype", "subtypetrue",
        "truelabel", "groundtruthlabel", "actuallabel", "ytrue",
    ),
    "type": (
        "truetype", "groundtruthtype", "actualtype", "typetrue",
        "ytruetype",
    ),
}
PRED_COLUMNS = {
    "subtype": (
        "predictedsubtype", "predsubtype", "subtypepred", "subtypeprediction",
        "predictedlabel", "predlabel", "prediction", "ypred",
    ),
    "type": (
        "predictedtype", "predtype", "typepred", "typeprediction", "ypredtype",
    ),
}


def find_column(fieldnames: list[str], candidates: tuple[str, ...], kind: str) -> str:
    indexed = {normalise(name): name for name in fieldnames}
    for candidate in candidates:
        if candidate in indexed:
            return indexed[candidate]
    raise KeyError(
        f"Could not find the {kind} column. Available columns: {fieldnames}"
    )


def candidate_prediction_files() -> list[Path]:
    excluded = {
        "test_subtype_level_metrics.csv",
        "test_type_level_metrics.csv",
        "test_arg_nonarg_level_metrics.csv",
        "test_five_metrics_summary.csv",
        "test_subtype_five_metrics_averages.csv",
        "test_type_five_metrics_averages.csv",
    }
    files = [
        path for path in HERE.glob("*.csv")
        if "predict" in path.name.lower() and path.name.lower() not in excluded
    ]
    if not files:
        raise FileNotFoundError(
            "No sequence-level prediction CSV found. Put this script in the same "
            "folder as test_sequence_predictions.csv or protein_test_sequence_predictions.csv. "
            "The two aggregate metrics files alone cannot recover MCC exactly."
        )
    return sorted(files, key=lambda path: ("test" not in path.name.lower(), path.name.lower()))


def load_prediction_rows(path: Path) -> tuple[list[dict[str, str]], list[str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"Prediction CSV has no header: {path}")
        rows = list(reader)
    if not rows:
        raise ValueError(f"Prediction CSV is empty: {path}")
    return rows, list(reader.fieldnames)


def select_prediction_file() -> tuple[Path, list[dict[str, str]], list[str]]:
    failures = []
    for path in candidate_prediction_files():
        try:
            rows, fields = load_prediction_rows(path)
            # A valid file must support at least one requested level.
            for level in ("subtype", "type"):
                find_column(fields, TRUE_COLUMNS[level], f"true {level}")
                find_column(fields, PRED_COLUMNS[level], f"predicted {level}")
            return path, rows, fields
        except (KeyError, ValueError) as error:
            failures.append(f"{path.name}: {error}")
    raise ValueError(
        "Found prediction-like CSV files, but none has both true/predicted Type "
        "and subtype columns:\n  " + "\n  ".join(failures)
    )


def metric_rows(y_true: list[str], y_pred: list[str], level: str, source: str):
    if len(y_true) != len(y_pred) or not y_true:
        raise ValueError(f"Invalid {level} truth/prediction arrays")
    accuracy = accuracy_score(y_true, y_pred)
    mcc = matthews_corrcoef(y_true, y_pred)
    result = []
    for average in ("macro", "weighted", "micro"):
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average=average, zero_division=0
        )
        result.append({
            "level": level,
            "average": average,
            "accuracy": f"{accuracy:.6f}",
            "precision": f"{precision:.6f}",
            "recall": f"{recall:.6f}",
            "f1": f"{f1:.6f}",
            "mcc": f"{mcc:.6f}",
            "n_test_sequences": len(y_true),
            "n_observed_true_classes": len(set(y_true)),
            "prediction_source": source,
        })
    return result


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    columns = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    source, rows, fields = select_prediction_file()
    combined = []
    by_level = {}
    for level in ("subtype", "type"):
        true_column = find_column(fields, TRUE_COLUMNS[level], f"true {level}")
        pred_column = find_column(fields, PRED_COLUMNS[level], f"predicted {level}")
        y_true = [str(row[true_column]).strip() for row in rows]
        y_pred = [str(row[pred_column]).strip() for row in rows]
        if any(not value for value in y_true + y_pred):
            raise ValueError(f"Empty {level} label found in {source.name}")
        level_rows = metric_rows(y_true, y_pred, level, source.name)
        by_level[level] = {row["average"]: row for row in level_rows}
        out = HERE / f"test_{level}_five_metrics_averages.csv"
        write_rows(out, level_rows)
        combined.extend(level_rows)
        print(f"{level}: true={true_column}; predicted={pred_column}; wrote {out.name}")
    write_rows(HERE / "test_five_metrics_summary.csv", combined)

    # One model-level table: exactly three rows, no individual-class rows.
    overall = []
    for average in ("macro", "weighted", "micro"):
        row = {"average": average, "prediction_source": source.name}
        for level in ("subtype", "type"):
            values = by_level[level][average]
            for metric in ("accuracy", "precision", "recall", "f1", "mcc"):
                row[f"{level}_{metric}"] = values[metric]
        overall.append(row)
    write_rows(HERE / "test_model_overall_five_metrics.csv", overall)
    print("Completed: test_model_overall_five_metrics.csv (three model-level rows)")


if __name__ == "__main__":
    main()
