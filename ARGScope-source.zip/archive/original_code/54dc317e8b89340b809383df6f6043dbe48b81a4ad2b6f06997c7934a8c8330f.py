#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope train/test split.

Rules
-----
1. ARG subtype count == 1:
   remove that ARG sample/subtype.

2. ARG subtype count >= 2:
   split each subtype independently using:
       train = ceil(n / 2)
       test  = floor(n / 2)
   Examples: 2 -> 1/1, 3 -> 2/1, 4 -> 2/2, 5 -> 3/2.

3. nonARG:
   randomly downsample to the same total number as retained ARG samples.
   Then assign nonARG so that:
       train ARG : train nonARG = 1 : 1
       test  ARG : test  nonARG = 1 : 1

4. Protein, DNA and structure always follow the same sequence IDs.

Input files should be in the same directory as this script:
    all_ARG_nonARG_1to1_structure(2).txt
    all_ARG_nonARG_1to1_protein.fasta
    all_ARG_nonARG_1to1_DNA.fasta

Output:
    new_train_test_1to1/
"""

from collections import OrderedDict
from pathlib import Path
import random

import pandas as pd


# =============================================================================
# Settings
# =============================================================================

SEED = 42

ROOT_DIR = Path(__file__).resolve().parent

STRUCTURE_FILE = ROOT_DIR / "all_ARG_nonARG_1to1_structure.txt"
PROTEIN_FASTA = ROOT_DIR / "all_ARG_nonARG_1to1_protein.fasta"
DNA_FASTA = ROOT_DIR / "all_ARG_nonARG_1to1_DNA.fasta"

OUTPUT_DIR = ROOT_DIR / "new_train_test_1to1"

ID_COL = "SARG.Seq.ID"
TYPE_COL = "Type"
SUBTYPE_COL = "Subtype"
ARG_COL = "ARG.or.nonARG"


# =============================================================================
# FASTA
# =============================================================================

def read_fasta(path):
    records = OrderedDict()

    seq_id = None
    header = None
    seq_parts = []

    with path.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.rstrip("\r\n")

            if not line:
                continue

            if line.startswith(">"):
                if seq_id is not None:
                    if seq_id in records:
                        raise ValueError(
                            f"Duplicate FASTA ID in {path.name}: {seq_id}"
                        )

                    records[seq_id] = (
                        header,
                        "".join(seq_parts),
                    )

                header = line[1:].strip()

                if not header:
                    raise ValueError(
                        f"Empty FASTA header in {path}"
                    )

                seq_id = header.split()[0]
                seq_parts = []

            else:
                if seq_id is None:
                    raise ValueError(
                        f"Sequence before FASTA header in {path}"
                    )

                seq_parts.append(
                    line.strip()
                )

    if seq_id is not None:
        if seq_id in records:
            raise ValueError(
                f"Duplicate FASTA ID in {path.name}: {seq_id}"
            )

        records[seq_id] = (
            header,
            "".join(seq_parts),
        )

    return records


def write_fasta(path, ordered_ids, records):
    with path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:

        for seq_id in ordered_ids:
            header, sequence = records[seq_id]

            handle.write(
                f">{header}\n"
            )

            for start in range(
                0,
                len(sequence),
                80,
            ):
                handle.write(
                    sequence[
                        start:start + 80
                    ]
                    + "\n"
                )


# =============================================================================
# Load + validation
# =============================================================================

def normalize_arg_label(value):
    text = str(
        value
    ).strip().lower()

    if text == "arg":
        return "ARG"

    if text in {
        "nonarg",
        "non_arg",
        "non-arg",
    }:
        return "nonARG"

    raise ValueError(
        f"Unexpected {ARG_COL} value: {value!r}"
    )


def load_data():
    for path in (
        STRUCTURE_FILE,
        PROTEIN_FASTA,
        DNA_FASTA,
    ):
        if not path.is_file():
            raise FileNotFoundError(
                f"Missing input file: {path}"
            )

    df = pd.read_csv(
        STRUCTURE_FILE,
        sep="\t",
        dtype=str,
        keep_default_na=False,
        encoding="utf-8-sig",
    )

    required = {
        ID_COL,
        TYPE_COL,
        SUBTYPE_COL,
        ARG_COL,
    }

    missing = sorted(
        required - set(df.columns)
    )

    if missing:
        raise KeyError(
            f"Missing structure columns: {missing}"
        )

    for column in (
        ID_COL,
        TYPE_COL,
        SUBTYPE_COL,
        ARG_COL,
    ):
        df[column] = (
            df[column]
            .astype(str)
            .str.strip()
        )

    if df[ID_COL].duplicated().any():
        duplicates = (
            df.loc[
                df[ID_COL].duplicated(
                    keep=False
                ),
                ID_COL,
            ]
            .tolist()
        )

        raise ValueError(
            f"Duplicate structure IDs, examples: {duplicates[:10]}"
        )

    df[ARG_COL] = (
        df[ARG_COL]
        .map(normalize_arg_label)
    )

    protein_records = read_fasta(
        PROTEIN_FASTA
    )

    dna_records = read_fasta(
        DNA_FASTA
    )

    structure_ids = set(
        df[ID_COL]
    )

    protein_ids = set(
        protein_records
    )

    dna_ids = set(
        dna_records
    )

    if structure_ids != protein_ids:
        raise ValueError(
            "Structure and protein FASTA IDs do not match.\n"
            f"structure-only={len(structure_ids - protein_ids)}; "
            f"protein-only={len(protein_ids - structure_ids)}"
        )

    if structure_ids != dna_ids:
        raise ValueError(
            "Structure and DNA FASTA IDs do not match.\n"
            f"structure-only={len(structure_ids - dna_ids)}; "
            f"DNA-only={len(dna_ids - structure_ids)}"
        )

    print("=" * 90)
    print("Input validation PASS")
    print("=" * 90)
    print(
        f"Total  : {len(df):,}"
    )
    print(
        f"ARG    : {(df[ARG_COL] == 'ARG').sum():,}"
    )
    print(
        f"nonARG : {(df[ARG_COL] == 'nonARG').sum():,}"
    )

    return (
        df,
        protein_records,
        dna_records,
    )


# =============================================================================
# Split
# =============================================================================

def make_split(df):
    rng = random.Random(
        SEED
    )

    arg_df = df[
        df[ARG_COL] == "ARG"
    ].copy()

    nonarg_df = df[
        df[ARG_COL] == "nonARG"
    ].copy()

    subtype_counts = (
        arg_df[
            SUBTYPE_COL
        ]
        .value_counts()
    )

    singleton_subtypes = set(
        subtype_counts[
            subtype_counts == 1
        ].index.tolist()
    )

    retained_subtypes = set(
        subtype_counts[
            subtype_counts >= 2
        ].index.tolist()
    )

    removed_singleton_df = arg_df[
        arg_df[
            SUBTYPE_COL
        ].isin(
            singleton_subtypes
        )
    ].copy()

    retained_arg_df = arg_df[
        arg_df[
            SUBTYPE_COL
        ].isin(
            retained_subtypes
        )
    ].copy()

    print()
    print("=" * 90)
    print("ARG subtype filtering")
    print("=" * 90)
    print(
        f"Original ARG subtypes : {len(subtype_counts):,}"
    )
    print(
        f"count == 1 removed    : {len(singleton_subtypes):,}"
    )
    print(
        f"count >= 2 retained   : {len(retained_subtypes):,}"
    )
    print(
        f"Removed ARG samples   : {len(removed_singleton_df):,}"
    )
    print(
        f"Retained ARG samples  : {len(retained_arg_df):,}"
    )

    # -------------------------------------------------------------------------
    # ARG: split independently within every subtype.
    # -------------------------------------------------------------------------

    train_arg_ids = []
    test_arg_ids = []
    subtype_summary = []

    subtype_list = sorted(
        retained_subtypes
    )

    rng.shuffle(
        subtype_list
    )

    for subtype in subtype_list:
        group = retained_arg_df[
            retained_arg_df[
                SUBTYPE_COL
            ] == subtype
        ].copy()

        ids = group[
            ID_COL
        ].tolist()

        rng.shuffle(
            ids
        )

        n = len(
            ids
        )

        # Fixed per-subtype split rule:
        #   n = 2 -> train 1, test 1
        #   n = 3 -> train 2, test 1
        #   n = 4 -> train 2, test 2
        #   n = 5 -> train 3, test 2
        # In general:
        #   train = ceil(n / 2)
        #   test  = floor(n / 2)
        # Therefore, for every odd-sized subtype, the extra sample always
        # goes to TRAIN.
        n_train = (
            (n + 1) // 2
        )

        n_test = (
            n // 2
        )

        subtype_train = ids[
            :n_train
        ]

        subtype_test = ids[
            n_train:
        ]

        train_arg_ids.extend(
            subtype_train
        )

        test_arg_ids.extend(
            subtype_test
        )

        type_values = (
            group[
                TYPE_COL
            ]
            .drop_duplicates()
            .tolist()
        )

        if len(
            type_values
        ) != 1:
            raise ValueError(
                f"Subtype maps to multiple Types: {subtype} -> {type_values}"
            )

        subtype_summary.append(
            {
                "Subtype":
                    subtype,
                "Type":
                    type_values[0],
                "total":
                    n,
                "train":
                    n_train,
                "test":
                    n_test,
                "train_minus_test":
                    n_train - n_test,
            }
        )

    train_arg_ids = set(
        train_arg_ids
    )

    test_arg_ids = set(
        test_arg_ids
    )

    retained_arg_ids = set(
        retained_arg_df[
            ID_COL
        ]
    )

    if train_arg_ids & test_arg_ids:
        raise RuntimeError(
            "ARG train/test overlap."
        )

    if (
        train_arg_ids
        | test_arg_ids
    ) != retained_arg_ids:
        raise RuntimeError(
            "ARG split does not cover all retained ARG samples."
        )

    # -------------------------------------------------------------------------
    # nonARG:
    # keep exactly the same total number as retained ARG.
    # -------------------------------------------------------------------------

    all_nonarg_ids = nonarg_df[
        ID_COL
    ].tolist()

    rng.shuffle(
        all_nonarg_ids
    )

    retained_arg_total = len(
        retained_arg_ids
    )

    if len(
        all_nonarg_ids
    ) < retained_arg_total:
        raise ValueError(
            "Not enough nonARG samples to preserve 1:1 ARG/nonARG."
        )

    retained_nonarg_ids = (
        all_nonarg_ids[
            :retained_arg_total
        ]
    )

    removed_nonarg_ids = set(
        all_nonarg_ids[
            retained_arg_total:
        ]
    )

    # Match ARG counts exactly inside train and test.
    train_nonarg_n = len(
        train_arg_ids
    )

    train_nonarg_ids = set(
        retained_nonarg_ids[
            :train_nonarg_n
        ]
    )

    test_nonarg_ids = set(
        retained_nonarg_ids[
            train_nonarg_n:
        ]
    )

    if len(
        test_nonarg_ids
    ) != len(
        test_arg_ids
    ):
        raise RuntimeError(
            "nonARG test count does not match ARG test count."
        )

    train_ids = (
        train_arg_ids
        | train_nonarg_ids
    )

    test_ids = (
        test_arg_ids
        | test_nonarg_ids
    )

    removed_singleton_ids = set(
        removed_singleton_df[
            ID_COL
        ]
    )

    if train_ids & test_ids:
        raise RuntimeError(
            "Final train/test overlap."
        )

    all_accounted_ids = (
        train_ids
        | test_ids
        | removed_singleton_ids
        | removed_nonarg_ids
    )

    if all_accounted_ids != set(
        df[
            ID_COL
        ]
    ):
        raise RuntimeError(
            "Some input IDs were not assigned."
        )

    print()
    print("=" * 90)
    print("Final split")
    print("=" * 90)
    print(
        f"ARG train     : {len(train_arg_ids):,}"
    )
    print(
        f"ARG test      : {len(test_arg_ids):,}"
    )
    print(
        f"nonARG train  : {len(train_nonarg_ids):,}"
    )
    print(
        f"nonARG test   : {len(test_nonarg_ids):,}"
    )
    print(
        f"Train total   : {len(train_ids):,}"
    )
    print(
        f"Test total    : {len(test_ids):,}"
    )
    print(
        f"Removed ARG   : {len(removed_singleton_ids):,}"
    )
    print(
        f"Removed nonARG: {len(removed_nonarg_ids):,}"
    )

    return {
        "train_ids":
            train_ids,
        "test_ids":
            test_ids,
        "train_arg_ids":
            train_arg_ids,
        "test_arg_ids":
            test_arg_ids,
        "train_nonarg_ids":
            train_nonarg_ids,
        "test_nonarg_ids":
            test_nonarg_ids,
        "removed_singleton_ids":
            removed_singleton_ids,
        "removed_nonarg_ids":
            removed_nonarg_ids,
        "singleton_subtypes":
            singleton_subtypes,
        "retained_subtypes":
            retained_subtypes,
        "subtype_summary":
            pd.DataFrame(
                subtype_summary
            ),
    }


# =============================================================================
# Write outputs
# =============================================================================

def write_id_file(path, ids):
    with path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:
        for seq_id in ids:
            handle.write(
                seq_id
                + "\n"
            )


def write_outputs(
    df,
    protein_records,
    dna_records,
    split,
):
    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    original_order = df[
        ID_COL
    ].tolist()

    train_order = [
        seq_id
        for seq_id in original_order
        if seq_id in split[
            "train_ids"
        ]
    ]

    test_order = [
        seq_id
        for seq_id in original_order
        if seq_id in split[
            "test_ids"
        ]
    ]

    removed_singleton_order = [
        seq_id
        for seq_id in original_order
        if seq_id in split[
            "removed_singleton_ids"
        ]
    ]

    removed_nonarg_order = [
        seq_id
        for seq_id in original_order
        if seq_id in split[
            "removed_nonarg_ids"
        ]
    ]

    train_df = df[
        df[
            ID_COL
        ].isin(
            split[
                "train_ids"
            ]
        )
    ].copy()

    test_df = df[
        df[
            ID_COL
        ].isin(
            split[
                "test_ids"
            ]
        )
    ].copy()

    # IDs
    write_id_file(
        OUTPUT_DIR
        / "train_ids.txt",
        train_order,
    )

    write_id_file(
        OUTPUT_DIR
        / "test_ids.txt",
        test_order,
    )

    write_id_file(
        OUTPUT_DIR
        / "removed_singleton_ARG_ids.txt",
        removed_singleton_order,
    )

    write_id_file(
        OUTPUT_DIR
        / "removed_excess_nonARG_ids.txt",
        removed_nonarg_order,
    )

    # Structure
    train_df.to_csv(
        OUTPUT_DIR
        / "train_structure.txt",
        sep="\t",
        index=False,
        encoding="utf-8",
    )

    test_df.to_csv(
        OUTPUT_DIR
        / "test_structure.txt",
        sep="\t",
        index=False,
        encoding="utf-8",
    )

    # Protein FASTA
    write_fasta(
        OUTPUT_DIR
        / "train_protein.fasta",
        train_order,
        protein_records,
    )

    write_fasta(
        OUTPUT_DIR
        / "test_protein.fasta",
        test_order,
        protein_records,
    )

    # DNA FASTA
    write_fasta(
        OUTPUT_DIR
        / "train_DNA.fasta",
        train_order,
        dna_records,
    )

    write_fasta(
        OUTPUT_DIR
        / "test_DNA.fasta",
        test_order,
        dna_records,
    )

    # Split manifest
    split_map = {}

    for seq_id in split[
        "train_ids"
    ]:
        split_map[
            seq_id
        ] = "train"

    for seq_id in split[
        "test_ids"
    ]:
        split_map[
            seq_id
        ] = "test"

    for seq_id in split[
        "removed_singleton_ids"
    ]:
        split_map[
            seq_id
        ] = "removed_singleton_ARG"

    for seq_id in split[
        "removed_nonarg_ids"
    ]:
        split_map[
            seq_id
        ] = "removed_excess_nonARG"

    manifest = df.copy()

    manifest.insert(
        1,
        "split",
        manifest[
            ID_COL
        ].map(
            split_map
        ),
    )

    manifest.to_csv(
        OUTPUT_DIR
        / "split_manifest.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Per-subtype summary
    subtype_summary = (
        split[
            "subtype_summary"
        ]
        .sort_values(
            [
                "Type",
                "Subtype",
            ]
        )
        .reset_index(
            drop=True
        )
    )

    subtype_summary.to_csv(
        OUTPUT_DIR
        / "subtype_split_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Final summary
    train_arg_n = int(
        train_df[
            ARG_COL
        ].eq(
            "ARG"
        ).sum()
    )

    train_nonarg_n = int(
        train_df[
            ARG_COL
        ].eq(
            "nonARG"
        ).sum()
    )

    test_arg_n = int(
        test_df[
            ARG_COL
        ].eq(
            "ARG"
        ).sum()
    )

    test_nonarg_n = int(
        test_df[
            ARG_COL
        ].eq(
            "nonARG"
        ).sum()
    )

    retained_arg_ids = (
        split[
            "train_arg_ids"
        ]
        | split[
            "test_arg_ids"
        ]
    )

    retained_type_n = int(
        df[
            df[
                ID_COL
            ].isin(
                retained_arg_ids
            )
        ][
            TYPE_COL
        ].nunique()
    )

    summary = [
        "ARGScope train/test split summary",
        "=" * 70,
        f"Seed                         : {SEED}",
        "",
        f"Original total               : {len(df):,}",
        f"Original ARG                 : {(df[ARG_COL] == 'ARG').sum():,}",
        f"Original nonARG              : {(df[ARG_COL] == 'nonARG').sum():,}",
        "",
        f"Original ARG subtypes        : {df.loc[df[ARG_COL] == 'ARG', SUBTYPE_COL].nunique():,}",
        f"Removed singleton subtypes   : {len(split['singleton_subtypes']):,}",
        f"Removed singleton ARG rows   : {len(split['removed_singleton_ids']):,}",
        f"Retained ARG subtypes        : {len(split['retained_subtypes']):,}",
        f"Retained ARG Types           : {retained_type_n:,}",
        "",
        f"Removed excess nonARG        : {len(split['removed_nonarg_ids']):,}",
        "",
        f"TRAIN total                  : {len(train_df):,}",
        f"TRAIN ARG                    : {train_arg_n:,}",
        f"TRAIN nonARG                 : {train_nonarg_n:,}",
        "",
        f"TEST total                   : {len(test_df):,}",
        f"TEST ARG                     : {test_arg_n:,}",
        f"TEST nonARG                  : {test_nonarg_n:,}",
        "",
        f"Train/test overlap           : {len(split['train_ids'] & split['test_ids'])}",
        "Train ARG:nonARG             : 1:1",
        "Test ARG:nonARG              : 1:1",
    ]

    (
        OUTPUT_DIR
        / "split_summary.txt"
    ).write_text(
        "\n".join(
            summary
        )
        + "\n",
        encoding="utf-8",
    )

    print()
    print(
        f"All outputs saved to:\n{OUTPUT_DIR}"
    )


# =============================================================================
# Main
# =============================================================================

def main():
    (
        df,
        protein_records,
        dna_records,
    ) = load_data()

    split = make_split(
        df
    )

    write_outputs(
        df,
        protein_records,
        dna_records,
        split,
    )


if __name__ == "__main__":
    main()
