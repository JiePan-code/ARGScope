#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Three source-backed figures; run directly to export PNG, PDF and SVG.

No training or prediction files are edited. Existing metric caches are copied
byte-for-byte on the first run; subsequent runs use the bundled input snapshot.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.text import Text
from PIL import Image

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
SOURCE = ROOT.parent
PCTS = [60, 70, 80, 90]
METRICS = ["Accuracy", "Precision", "Recall", "F1", "MCC"]
MODELS = {"protein": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
          "dna": ["ARGNet", "DeepARG", "ARGScope"]}
COLORS = {"ARGNet": "#89949E", "DeepARG": "#8472B0", "PLM-ARG": "#BDA364",
          "FunGeneTyper": "#64A598", "ARGScope": "#CF4877"}
MARKERS = {"ARGNet": "s", "DeepARG": "^", "PLM-ARG": "D", "FunGeneTyper": "v", "ARGScope": "o"}
STYLES = {"ARGNet": "--", "DeepARG": ":", "PLM-ARG": "-.", "FunGeneTyper": "--", "ARGScope": "-"}
SOURCES = {
    "overall_scores.csv": SOURCE / "boxplot_revision/data/all_model_points_and_intervals.csv",
    "per_type_precision.csv": SOURCE / "data/reported_per_type_NOT_matched.csv",
    "type_mapping.csv": SOURCE / "data/type_display_mapping.csv",
    "ARGScope_type_counts.csv": SOURCE / "data/ARGScope_per_type_five_metrics.csv",
    "cohort_audit.csv": SOURCE / "boxplot_revision/data/baseline_source_audit.csv",
}
plt.rcParams.update({"font.family": "Arial", "font.size": 9, "axes.linewidth": .6,
                     "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42,
                     "savefig.facecolor": "white", "figure.facecolor": "white",
                     "text.color": "#24262A", "axes.labelcolor": "#24262A"})


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def csv_write(frame, path):
    frame.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.12g")


def get_inputs():
    INPUTS.mkdir(exist_ok=True)
    manifest_path = INPUTS / "source_manifest.json"
    if not manifest_path.exists():
        for target, source in SOURCES.items():
            if not source.is_file():
                raise FileNotFoundError(source)
            if (INPUTS / target).exists():
                raise RuntimeError("Incomplete input snapshot; inspect it before rerunning.")
        manifest = {}
        for target, source in SOURCES.items():
            shutil.copy2(source, INPUTS / target)
            manifest[target] = {"source": str(source), "sha256": sha(source)}
        json_write(manifest_path, manifest)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for name, meta in manifest.items():
        assert sha(INPUTS / name) == meta["sha256"], f"Changed input: {name}"
    return manifest


def load_data():
    overall = pd.read_csv(INPUTS / "overall_scores.csv")
    overall = overall[overall.Level.eq("Type") & overall.Completeness.isin(PCTS)].copy()
    keys = ["Modality", "Model", "Completeness", "Metric"]
    assert not overall.duplicated(keys).any()
    assert len(overall) == 160
    assert overall[["Point_estimate", "CI_low", "CI_high"]].notna().all().all()
    assert overall[["Point_estimate", "CI_low", "CI_high"]].ge(0).all().all()
    assert overall[["Point_estimate", "CI_low", "CI_high"]].le(1).all().all()
    assert (overall.CI_low <= overall.CI_high).all()
    per_type = pd.read_csv(INPUTS / "per_type_precision.csv")
    per_type = per_type[per_type.Metric.eq("Precision") & per_type.Completeness.isin(PCTS)].copy()
    assert not per_type.duplicated(["Modality", "Model", "Completeness", "Type"]).any()
    assert per_type.Value.dropna().between(0, 1).all()
    mapping = pd.read_csv(INPUTS / "type_mapping.csv")
    assert len(mapping) == 23 and mapping.Type.is_unique
    counts = pd.read_csv(INPUTS / "ARGScope_type_counts.csv")
    own = per_type[per_type.Model.eq("ARGScope")].merge(
        counts, on=["Modality", "Completeness", "Type"], validate="one_to_one")
    # Independent check of own per-Type precision using cached confusion counts.
    denominator = (own.TP + own.FP).to_numpy(float)
    recomputed = np.divide(own.TP, denominator, out=np.zeros(len(own)), where=denominator > 0)
    np.testing.assert_allclose(own.Value, recomputed, atol=6e-12, rtol=0)
    return overall, per_type, mapping


def make_delta_data(per_type, mapping):
    selection, rows = [], []
    for mod in MODELS:
        sub = per_type[per_type.Modality.eq(mod)]
        lookup = sub.set_index(["Type", "Model", "Completeness"]).Value
        for typ in mapping.Type:
            own = np.array([lookup.get((typ, "ARGScope", pct), np.nan) for pct in PCTS])
            others = np.array([lookup.get((typ, model, pct), np.nan)
                               for model in MODELS[mod][:-1] for pct in PCTS])
            own_positive = bool(np.any(np.isfinite(own) & (own > 0)))
            baseline_positive = bool(np.any(np.isfinite(others) & (others > 0)))
            keep = own_positive and baseline_positive
            reason = "displayed" if keep else ("ARGScope_zero_at_all_four_completenesses"
                      if not own_positive else "all_baselines_zero_or_missing_at_all_four_completenesses")
            selection.append({"Modality": mod, "Type": typ, "Displayed": keep, "Reason": reason})
            for model in MODELS[mod][:-1]:
                for pct in PCTS:
                    a, b = lookup.get((typ, "ARGScope", pct), np.nan), lookup.get((typ, model, pct), np.nan)
                    status = "available" if np.isfinite(a) and np.isfinite(b) else "missing_source_score"
                    delta = a - b if status == "available" else np.nan
                    rows.append({"Modality": mod, "Comparator": model, "Completeness": pct,
                                 "Type": typ, "ARGScope_precision": a, "Comparator_precision": b,
                                 "Delta_precision": delta, "Displayed": keep, "Status": status})
    return pd.DataFrame(rows), pd.DataFrame(selection)


def text_check(fig):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    bad = []
    for obj in fig.findobj(Text):
        if not obj.get_visible() or not obj.get_text().strip():
            continue
        box = obj.get_window_extent(renderer)
        if box.width == 0 or box.height == 0:
            continue
        if box.x0 < bounds.x0-2 or box.y0 < bounds.y0-2 or box.x1 > bounds.x1+2 or box.y1 > bounds.y1+2:
            bad.append(obj.get_text())
    assert not bad, f"Text outside figure: {bad}"
    return {"outside_canvas_text": bad}


def save(fig, name, output, manifest):
    check = text_check(fig)
    width, height = fig.get_size_inches() * 25.4
    for ext in ("png", "pdf", "svg"):
        path = output / f"{name}.{ext}"
        fig.savefig(path, dpi=450)
        manifest.append({"file": path.name, "width_mm": float(width), "height_mm": float(height),
                         "sha256": sha(path), **check})
    fig.savefig(output / f"{name}_preview.png", dpi=150)
    plt.close(fig)


def draw_radar(overall, output, manifest):
    fig = plt.figure(figsize=(320/25.4, 193/25.4))
    grid = fig.add_gridspec(2, 4, left=.075, right=.968, bottom=.11, top=.855,
                           hspace=.55, wspace=.39)
    angles = np.linspace(0, 2*np.pi, 5, endpoint=False)
    theta = np.r_[angles, angles[0]]
    actual = []
    for row, mod in enumerate(MODELS):
        row_axes = []
        for col, pct in enumerate(PCTS):
            ax = fig.add_subplot(grid[row, col], projection="polar")
            row_axes.append(ax)
            ax.set_theta_offset(np.pi/2)
            ax.set_theta_direction(-1)
            ax.set_ylim(0, 1)
            ax.set_xticks(angles, ["ACC", "Precision", "Recall", "F1", "MCC"])
            ax.tick_params(axis="x", labelsize=8, pad=5)
            ax.set_yticks([.25, .5, .75, 1], ["0.2500", "0.5000", "0.7500", "1.0000"])
            ax.set_rlabel_position(43)
            ax.tick_params(axis="y", labelsize=5.8, colors="#6A7075", pad=1)
            ax.grid(color="#D8DCE1", lw=.55)
            ax.spines["polar"].set_color("#A8AFB7")
            ax.spines["polar"].set_linewidth(.65)
            for model in MODELS[mod]:
                part = overall[(overall.Modality == mod) & (overall.Model == model)
                               & (overall.Completeness == pct)].set_index("Metric").loc[METRICS]
                values = part.Point_estimate.to_numpy(float)
                z = 5 if model == "ARGScope" else 3
                color = COLORS[model]
                line, = ax.plot(theta, np.r_[values, values[0]], color=color, lw=1.25,
                                ls=STYLES[model], marker=MARKERS[model], ms=3.4, mew=.8,
                                markerfacecolor=color if model == "ARGScope" else "white", zorder=z)
                for i, metric in enumerate(METRICS):
                    lo, hi = float(part.loc[metric, "CI_low"]), float(part.loc[metric, "CI_high"])
                    ax.plot([angles[i], angles[i]], [lo, hi], color=color, lw=.65, zorder=z-1)
                    for end in (lo, hi):
                        ax.plot([angles[i]-.016, angles[i]+.016], [end, end], color=color, lw=.65, zorder=z-1)
                    actual.append({"Modality": mod, "Model": model, "Completeness": pct,
                                   "Metric": metric, "Radius": float(line.get_ydata()[i]),
                                   "CI_low": lo, "CI_high": hi})
            if row == 0:
                box = ax.get_position()
                fig.text((box.x0+box.x1)/2, .899, f"{pct}%", ha="center", fontsize=11)
        ycenter = np.mean([ax.get_position().y0 + ax.get_position().height/2 for ax in row_axes])
        fig.text(.020, ycenter, "Protein" if mod == "protein" else "DNA", rotation=90,
                 ha="center", va="center", fontsize=12, fontweight="bold")
    handles = [Line2D([0], [0], color=COLORS[m], marker=MARKERS[m], lw=1.25, ls=STYLES[m],
                      ms=4, markerfacecolor=COLORS[m] if m == "ARGScope" else "white", label=m)
               for m in MODELS["protein"]]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.52, .987), ncol=5,
               frameon=False, fontsize=9, handlelength=2.6, columnspacing=2)
    fig.text(.52, .047, "Radial whiskers: 95% parent-bootstrap intervals", ha="center", fontsize=7.6, color="#59616B")
    fig.text(.52, .020, "Different evaluation cohorts; descriptive comparison only", ha="center", fontsize=7.6, color="#59616B")
    save(fig, "01_Protein_DNA_radar_60_90", output, manifest)
    return pd.DataFrame(actual)


def draw_heatmap(mod, deltas, selection, mapping, output, manifest):
    selected = selection[selection.Modality.eq(mod) & selection.Displayed].Type.tolist()
    names = mapping.set_index("Type").Display.to_dict()
    comparators = MODELS[mod][:-1]
    n = len(selected)
    width_mm = 300 if mod == "protein" else 195
    height_mm = 51 + n*6.0
    fig = plt.figure(figsize=(width_mm/25.4, height_mm/25.4))
    # Physical cell widths and type labels are kept readable in both modalities.
    left_mm, right_mm = 39, 7
    group_gap_mm = 3.7
    group_w_mm = (width_mm-left_mm-right_mm-group_gap_mm*(len(comparators)-1))/len(comparators)
    bottom_mm, top_mm = 27, 10
    data_height_mm = height_mm-bottom_mm-top_mm
    cmap = LinearSegmentedColormap.from_list("difference", ["#3F5B94", "#F8F8F8", "#C43B79"])
    cmap.set_bad("#ECEEF1")
    norm = Normalize(-1, 1)
    matrices, means, rendered = [], [], []
    display_values = deltas[deltas.Modality.eq(mod) & deltas.Displayed]
    for index, comparator in enumerate(comparators):
        data = display_values[display_values.Comparator.eq(comparator)]
        matrix = data.pivot(index="Type", columns="Completeness", values="Delta_precision").reindex(index=selected, columns=PCTS)
        average = matrix.mean(axis=0, skipna=True)
        count = matrix.notna().sum(axis=0)
        for pct in PCTS:
            means.append({"Modality": mod, "Comparator": comparator, "Completeness": pct,
                          "Average_delta": average[pct], "N_available_types": int(count[pct]),
                          "Definition": "unweighted_mean_delta_of_displayed_types_with_both_scores_available"})
        # Row 0: Average; row 1: deliberate white gap; rows 2+: Type scores.
        full = np.vstack([average.to_numpy(), np.full(4, np.nan), matrix.to_numpy()])
        x_mm = left_mm + index*(group_w_mm+group_gap_mm)
        ax = fig.add_axes([x_mm/width_mm, bottom_mm/height_mm, group_w_mm/width_mm, data_height_mm/height_mm])
        masked = np.ma.masked_invalid(full)
        image = ax.imshow(masked, cmap=cmap, norm=norm, interpolation="nearest", aspect="auto")
        matrices.append(image)
        ax.axhspan(.5, 1.5, color="white", zorder=3)
        ax.set_xticks(range(4), [f"{pct}%" for pct in PCTS])
        ax.tick_params(axis="x", length=0, labelsize=9, pad=5)
        ax.set_yticks([0]+list(range(2, n+2)), ["Average"]+[names[t] for t in selected] if index == 0 else [""]*(n+1))
        ax.tick_params(axis="y", length=0, labelsize=8.4, pad=5)
        ax.set_xticks(np.arange(-.5, 4, 1), minor=True)
        ax.set_yticks(np.arange(-.5, n+2, 1), minor=True)
        ax.grid(which="minor", color="white", lw=.65)
        ax.tick_params(which="minor", length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.set_title(f"ARGScope − {comparator}", fontsize=9, pad=8)
        for i in [0]+list(range(2, n+2)):
            for j, pct in enumerate(PCTS):
                value = full[i, j]
                label = "—" if np.isnan(value) else f"{0.0 if abs(value) < .00005 else value:+.4f}"
                color = "#9CA3AB" if np.isnan(value) else ("white" if abs(value) >= .62 else "#272A2E")
                artist = ax.text(j, i, label, ha="center", va="center", fontsize=7.25, color=color)
                rendered.append({"Modality": mod, "Comparator": comparator, "Completeness": pct,
                                 "Type": "Average" if i == 0 else selected[i-2],
                                 "Delta_precision": value, "Printed_label": artist.get_text()})
        # Inspect the actual plotted array, including signs and missing masks.
        np.testing.assert_allclose(image.get_array().filled(np.nan), full, equal_nan=True)
    color_w_mm = min(100, width_mm-68)
    color_x_mm = left_mm + (width_mm-left_mm-right_mm-color_w_mm)/2
    cax = fig.add_axes([color_x_mm/width_mm, 12/height_mm, color_w_mm/width_mm, 2.9/height_mm])
    colorbar = fig.colorbar(matrices[0], cax=cax, orientation="horizontal", ticks=[-1, -.5, 0, .5, 1])
    colorbar.ax.set_xticklabels(["−1.0000", "−0.5000", "0.0000", "+0.5000", "+1.0000"])
    colorbar.ax.tick_params(labelsize=7, length=2, pad=2)
    colorbar.outline.set_linewidth(.4)
    fig.text((color_x_mm+color_w_mm/2)/width_mm, 18/height_mm,
             "ΔPrecision    ← Comparator higher | ARGScope higher →", ha="center", fontsize=7.7)
    # No grand title or A/B/C letters. A minimal scope qualifier travels with the image.
    fig.text(.52, 1.6/height_mm, "Different evaluation cohorts; descriptive only   |   —: not reported", ha="center", va="bottom", fontsize=7, color="#59616B")
    name = "02_Protein_Type_Precision_difference" if mod == "protein" else "03_DNA_Type_Precision_difference"
    save(fig, name, output, manifest)
    return pd.DataFrame(means), pd.DataFrame(rendered)


def validate(overall, deltas, selected, actual_radar, actual_heatmap, averages, manifest, output, input_manifest):
    radar = actual_radar.merge(overall, on=["Modality", "Model", "Completeness", "Metric"], validate="one_to_one", suffixes=("_drawn", "_source"))
    assert len(radar) == 160
    np.testing.assert_array_equal(radar.Radius, radar.Point_estimate)
    for col in ("CI_low", "CI_high"):
        np.testing.assert_array_equal(radar[f"{col}_drawn"], radar[f"{col}_source"])
    detail = actual_heatmap[actual_heatmap.Type.ne("Average")].merge(
        deltas[deltas.Displayed], on=["Modality", "Comparator", "Completeness", "Type"],
        validate="one_to_one", suffixes=("_drawn", "_source"))
    assert len(detail) == int(deltas.Displayed.sum())
    np.testing.assert_allclose(detail.Delta_precision_drawn, detail.ARGScope_precision-detail.Comparator_precision,
                               equal_nan=True, atol=1e-15, rtol=0)
    for row in actual_heatmap.itertuples():
        expected = "—" if np.isnan(row.Delta_precision) else f"{0.0 if abs(row.Delta_precision) < .00005 else row.Delta_precision:+.4f}"
        assert row.Printed_label == expected
    assert not selected[selected.Displayed].Type.eq("puromycin").any()
    # For this input snapshot none of the retained Type/completeness rows has zero ARGScope precision.
    assert (deltas.loc[deltas.Displayed, "ARGScope_precision"] > 0).all()
    for row in averages.itertuples():
        vals = deltas[deltas.Displayed & deltas.Modality.eq(row.Modality)
                      & deltas.Comparator.eq(row.Comparator) & deltas.Completeness.eq(row.Completeness)].Delta_precision.dropna()
        assert len(vals) == row.N_available_types
        np.testing.assert_allclose(row.Average_delta, sum(vals)/len(vals), atol=1e-15)
    assert len(manifest) == 9 and len({Path(m["file"]).stem for m in manifest}) == 3
    for entry in manifest:
        path = output/entry["file"]
        assert sha(path) == entry["sha256"]
        if path.suffix == ".png":
            with Image.open(path) as img:
                img.verify()
        elif path.suffix == ".svg":
            ET.parse(path)
        else:
            blob = path.read_bytes()
            assert blob.startswith(b"%PDF-") and b"%%EOF" in blob[-100:]
    for name, meta in input_manifest.items():
        assert sha(INPUTS/name) == meta["sha256"]
        original = Path(meta["source"])
        if original.is_file():
            assert sha(original) == meta["sha256"], f"Source changed during plotting: {original}"
    return {"status": "PASS", "designs": 3, "formal_files": 9, "radar_scores": len(radar),
            "heatmap_type_cells": len(detail), "heatmap_missing_cells": int(detail.Delta_precision_drawn.isna().sum()),
            "displayed_type_counts": selected[selected.Displayed].groupby("Modality").size().to_dict(),
            "all_radar_values_and_intervals_unchanged": True,
            "all_heatmap_values_checked_against_subtraction": True, "zero_imputation": False,
            "same_evaluation_cohort_across_models": False, "outside_canvas_text": 0,
            "source_inputs_unchanged": True}


def package(output):
    # Only this run's three figures are packaged, not older timestamp directories.
    target = ROOT / "ARGScope_radar_and_difference_heatmaps.zip"
    files = [Path(__file__), ROOT/"README_三张图.md", ROOT/"双击重画.bat", ROOT/"render_status.json"]
    files += list(INPUTS.glob("*")) + list(output.rglob("*"))
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            if path.is_file():
                z.write(path, Path("ARGScope_radar_difference")/path.relative_to(ROOT))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    return target


def main():
    snapshot = get_inputs()
    # Keep paths short enough for Windows image exporters with MAX_PATH limits.
    stamp = datetime.now().strftime("%y%m%d_%H%M%S")
    output = ROOT / f"v{stamp}"
    output.mkdir()
    data = output/"data"
    data.mkdir()
    status = {"status": "RUNNING", "started_utc": datetime.now(timezone.utc).isoformat(),
              "code_sha256": sha(__file__), "figure_directory": str(output)}
    json_write(ROOT/"render_status.json", status)
    overall, per_type, mapping = load_data()
    deltas, selected = make_delta_data(per_type, mapping)
    csv_write(deltas, data/"all_type_differences_including_hidden.csv")
    csv_write(selected, data/"type_display_filter.csv")
    manifest = []
    print("Rendering combined Protein / DNA radar...", flush=True)
    actual_radar = draw_radar(overall, output, manifest)
    means, cells = [], []
    for mod in MODELS:
        print(f"Rendering {mod} Type difference heatmap...", flush=True)
        avg, cell = draw_heatmap(mod, deltas, selected, mapping, output, manifest)
        means.append(avg)
        cells.append(cell)
    averages, actual_heatmap = pd.concat(means, ignore_index=True), pd.concat(cells, ignore_index=True)
    csv_write(averages, data/"heatmap_average_values.csv")
    csv_write(actual_radar, data/"rendered_radar_values.csv")
    csv_write(actual_heatmap, data/"rendered_heatmap_values.csv")
    report = validate(overall, deltas, selected, actual_radar, actual_heatmap, averages, manifest, output, snapshot)
    json_write(output/"validation_report.json", report)
    json_write(output/"figure_manifest.json", manifest)
    status.update(status="COMPLETE", finished_utc=datetime.now(timezone.utc).isoformat(), validation=report)
    json_write(ROOT/"render_status.json", status)
    archive = package(output)
    print(json.dumps({"figures": str(output), "archive": str(archive), "validation": report}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
