from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

PRED_FILE = BASE_DIR / "subtype_predictions_all_DNA.csv"

if not PRED_FILE.exists():
    candidate_files = sorted(BASE_DIR.glob("*subtype*prediction*.csv"))

    if len(candidate_files) == 0:
        raise FileNotFoundError(
            "当前文件夹中没有找到 subtype_predictions_all_DNA.csv 或类似的 subtype prediction CSV 文件。"
        )

    PRED_FILE = candidate_files[0]


OUTPUT_DIR = BASE_DIR / "subtype_misclassification_pairs"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "subtype_misclassification_pairs_top20.pdf"
OUTPUT_TIF = OUTPUT_DIR / "subtype_misclassification_pairs_top20.tif"
OUTPUT_CSV = OUTPUT_DIR / "subtype_misclassification_pairs_all.csv"
OUTPUT_TOP_CSV = OUTPUT_DIR / "subtype_misclassification_pairs_top20.csv"
OUTPUT_ERROR_SAMPLES = OUTPUT_DIR / "subtype_misclassified_samples.csv"


# =========================================================
# 2. 参数设置
# =========================================================

TOP_N = 20

COLOR_BAR = "#3C5488"

# False：保留所有 subtype 错误，包括 nonARG 相关错误
# True：排除 nonARG → ARG subtype 和 ARG subtype → nonARG
EXCLUDE_NONARG_RELATED = False

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取数据
# =========================================================

df = pd.read_csv(PRED_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["Subtype", "Pred_Subtype"]
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"{PRED_FILE.name} 缺少这些列: {missing_cols}")

df["Subtype"] = df["Subtype"].astype(str).str.strip()
df["Pred_Subtype"] = df["Pred_Subtype"].astype(str).str.strip()


# =========================================================
# 4. 只保留 subtype 错误预测
# =========================================================

if "Subtype_correct" in df.columns:
    # 兼容 True/False 或字符串形式
    subtype_correct = df["Subtype_correct"].astype(str).str.lower().str.strip()
    error_df = df[subtype_correct.isin(["false", "0", "no"])].copy()

    # 如果 Subtype_correct 列格式不标准，则退回到直接比较
    if len(error_df) == 0 and (df["Subtype"] != df["Pred_Subtype"]).any():
        error_df = df[df["Subtype"] != df["Pred_Subtype"]].copy()
else:
    error_df = df[df["Subtype"] != df["Pred_Subtype"]].copy()

if EXCLUDE_NONARG_RELATED:
    error_df = error_df[
        (error_df["Subtype"] != "nonARG")
        & (error_df["Pred_Subtype"] != "nonARG")
    ].copy()

if len(error_df) == 0:
    raise ValueError("没有发现符合条件的 subtype-level 错误预测，无法绘制错误预测图。")

error_df.to_csv(OUTPUT_ERROR_SAMPLES, index=False, encoding="utf-8-sig")


# =========================================================
# 5. 统计 Subtype1 -> Pred_Subtype2 的错误数量
# =========================================================

pair_df = (
    error_df
    .groupby(["Subtype", "Pred_Subtype"])
    .size()
    .reset_index(name="Count")
    .sort_values(["Count", "Subtype", "Pred_Subtype"], ascending=[False, True, True])
    .reset_index(drop=True)
)

total_errors = int(pair_df["Count"].sum())
pair_df["Percentage_of_errors"] = pair_df["Count"] / total_errors * 100


# =========================================================
# 6. 标签简化
# =========================================================

def shorten_subtype_label(x):
    x = str(x)

    if x == "nonARG":
        return "nonARG"

    if "__" in x:
        return x.split("__", 1)[1]

    return x


pair_df["True_Subtype_short"] = pair_df["Subtype"].map(shorten_subtype_label)
pair_df["Pred_Subtype_short"] = pair_df["Pred_Subtype"].map(shorten_subtype_label)

pair_df["Pair"] = (
    pair_df["True_Subtype_short"]
    + " \u2192 "
    + pair_df["Pred_Subtype_short"]
)

pair_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")

top_pair_df = pair_df.head(TOP_N).copy()
top_pair_df.to_csv(OUTPUT_TOP_CSV, index=False, encoding="utf-8-sig")


# =========================================================
# 7. 绘图
# =========================================================

plot_df = top_pair_df.sort_values("Count", ascending=True).reset_index(drop=True)

n_pairs = len(plot_df)
fig_height = max(4.8, n_pairs * 0.34)

max_label_len = plot_df["Pair"].astype(str).str.len().max()
fig_width = max(8.2, min(12.5, 6.8 + max_label_len * 0.055))

fig, ax = plt.subplots(figsize=(fig_width, fig_height), dpi=600)

y_pos = np.arange(n_pairs)

ax.barh(
    y_pos,
    plot_df["Count"],
    color=COLOR_BAR,
    edgecolor="black",
    linewidth=0.5,
    height=0.68,
)

ax.set_yticks(y_pos)
ax.set_yticklabels(plot_df["Pair"], fontsize=7)

ax.set_xlabel("Number of misclassified samples")
ax.set_ylabel("")
ax.set_title(
    f"Top {len(plot_df)} subtype-level misclassification pairs",
    fontsize=11,
    pad=12,
)

max_count = plot_df["Count"].max()

for y, count, pct in zip(
    y_pos,
    plot_df["Count"],
    plot_df["Percentage_of_errors"],
):
    ax.text(
        count + max_count * 0.025,
        y,
        f"{int(count)} ({pct:.1f}%)",
        va="center",
        ha="left",
        fontsize=7,
    )

ax.set_xlim(0, max_count * 1.30)

ax.grid(
    axis="x",
    linestyle="-",
    linewidth=0.45,
    alpha=0.45,
)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()


# =========================================================
# 8. 保存
# =========================================================

fig.savefig(OUTPUT_PDF, bbox_inches="tight")
fig.savefig(
    OUTPUT_TIF,
    dpi=600,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 9. 输出结果
# =========================================================

print("\nInput file:")
print(PRED_FILE)

print("\nTotal subtype-level misclassified samples:")
print(len(error_df))

print("\nTop subtype-level misclassification pairs:")
print(top_pair_df[[
    "Subtype",
    "Pred_Subtype",
    "Count",
    "Percentage_of_errors",
]])

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_CSV)
print(OUTPUT_TOP_CSV)
print(OUTPUT_ERROR_SAMPLES)