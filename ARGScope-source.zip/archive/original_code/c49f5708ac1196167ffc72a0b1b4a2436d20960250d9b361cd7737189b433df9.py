import pandas as pd
import numpy as np


def split_by_type_train_test_strict(
    file_path,
    type_col="Type",
    test_ratio=0.3,
    random_state=42,
    train_output="train_set.csv",
    test_output="test_set.csv",
    stats_output="type_split_statistics.csv"
):
    # =========================
    # 1. 读取数据
    # =========================
    df = pd.read_csv(file_path).copy()
    df = df.reset_index(drop=True)

    if type_col not in df.columns:
        raise ValueError(f"数据中未找到必要列: {type_col}")

    if len(df) == 0:
        raise ValueError("输入数据为空。")

    df[type_col] = df[type_col].astype(str)

    # 保留原始行号，用于检查 train/test 是否有重复样本
    df["_original_index"] = df.index

    train_parts = []
    test_parts = []
    stats = []

    # =========================
    # 2. 按 Type 单独划分
    # =========================
    for type_name, sub_df in df.groupby(type_col, sort=False):
        sub_df = sub_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
        n = len(sub_df)

        # =====================================================
        # n = 1：
        # 只放入 train，不放入 test
        # 严格避免 train/test 重复样本
        # =====================================================
        if n == 1:
            train_sub = sub_df.copy()
            test_sub = sub_df.iloc[0:0].copy()
            split_mode = "single_sample_train_only"

        # =====================================================
        # n >= 2：
        # 按 test_ratio 划分
        # 同时保证 train/test 都至少 1 条
        # =====================================================
        else:
            n_test = int(round(n * test_ratio))

            # 保证 test 至少 1 条
            n_test = max(1, n_test)

            # 保证 train 至少 1 条
            n_test = min(n_test, n - 1)

            n_train = n - n_test

            train_sub = sub_df.iloc[:n_train].copy()
            test_sub = sub_df.iloc[n_train:].copy()

            split_mode = "type_stratified_with_min_train_test"

        train_parts.append(train_sub)

        if len(test_sub) > 0:
            test_parts.append(test_sub)

        stats.append({
            "Type": type_name,
            "Total_count": n,
            "Train_count": len(train_sub),
            "Test_count": len(test_sub),
            "Train_ratio": len(train_sub) / n,
            "Test_ratio": len(test_sub) / n,
            "Split_mode": split_mode
        })

    # =========================
    # 3. 合并 train / test
    # =========================
    train_df = pd.concat(train_parts, ignore_index=True)

    if len(test_parts) > 0:
        test_df = pd.concat(test_parts, ignore_index=True)
    else:
        raise RuntimeError("test 集为空。请检查是否所有 Type 都只有 1 条样本。")

    # 打乱最终数据
    train_df = train_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
    test_df = test_df.sample(frac=1, random_state=random_state).reset_index(drop=True)

    # =========================
    # 4. 检查 Type 覆盖
    # =========================
    all_types = set(df[type_col].astype(str).unique())
    train_types = set(train_df[type_col].astype(str).unique())
    test_types = set(test_df[type_col].astype(str).unique())

    type_counts = df[type_col].value_counts()

    single_sample_types = set(type_counts[type_counts == 1].index.astype(str))
    multi_sample_types = set(type_counts[type_counts >= 2].index.astype(str))

    missing_train = sorted(all_types - train_types)

    # test 只要求覆盖样本数 >= 2 的 Type
    # 样本数 = 1 的 Type 按规则只进 train
    missing_test_for_multi = sorted(multi_sample_types - test_types)

    if len(missing_train) > 0:
        raise RuntimeError(
            "错误：以下 Type 没有出现在 train 中：\n"
            + "\n".join(map(str, missing_train[:50]))
        )

    if len(missing_test_for_multi) > 0:
        raise RuntimeError(
            "错误：以下样本数 >= 2 的 Type 没有出现在 test 中：\n"
            + "\n".join(map(str, missing_test_for_multi[:50]))
        )

    # =========================
    # 5. 严格检查 train/test 是否有重复样本
    # =========================
    train_original_ids = set(train_df["_original_index"].tolist())
    test_original_ids = set(test_df["_original_index"].tolist())
    overlap_ids = train_original_ids & test_original_ids

    if len(overlap_ids) > 0:
        raise RuntimeError(
            f"错误：Train/Test 存在重复原始样本数: {len(overlap_ids)}。"
        )

    # 删除辅助列后再保存
    train_df_out = train_df.drop(columns=["_original_index"])
    test_df_out = test_df.drop(columns=["_original_index"])

    # =========================
    # 6. 保存结果
    # =========================
    train_df_out.to_csv(train_output, index=False, encoding="utf-8-sig")
    test_df_out.to_csv(test_output, index=False, encoding="utf-8-sig")

    stats_df = pd.DataFrame(stats)
    stats_df.to_csv(stats_output, index=False, encoding="utf-8-sig")

    # =========================
    # 7. 输出统计
    # =========================
    total_n = len(df)
    train_n = len(train_df_out)
    test_n = len(test_df_out)

    single_sample_count = int((stats_df["Split_mode"] == "single_sample_train_only").sum())
    multi_sample_count = int((stats_df["Split_mode"] == "type_stratified_with_min_train_test").sum())

    print("数据划分完成")
    print(f"原始总样本数: {total_n}")
    print(f"原始 Type 数: {len(all_types)}")

    print("\n划分规则:")
    print("按 Type 分层划分")
    print("n = 1: 只放入 train，不放入 test")
    print(f"n >= 2: 每个 Type 内部按 train/test = {1 - test_ratio:.1f}/{test_ratio:.1f} 划分，并保证 train/test 都至少 1 条")
    print("严格划分: train/test 不允许重复原始样本")

    print("\n最终数据集:")
    print(f"Train 样本数: {train_n}")
    print(f"Test 样本数: {test_n}")
    print(f"Train 比例: {train_n / (train_n + test_n):.4f}")
    print(f"Test 比例: {test_n / (train_n + test_n):.4f}")

    print("\nType 覆盖检查:")
    print(f"Train Type 数: {train_df_out[type_col].nunique()}")
    print(f"Test Type 数: {test_df_out[type_col].nunique()}")
    print(f"原始 Type 数: {len(all_types)}")
    print(f"样本数 = 1 的 Type 数: {len(single_sample_types)}")
    print(f"样本数 >= 2 的 Type 数: {len(multi_sample_types)}")
    print("Train 是否覆盖所有 Type:", len(missing_train) == 0)
    print("Test 是否覆盖所有样本数 >= 2 的 Type:", len(missing_test_for_multi) == 0)

    print("\n重复情况:")
    print(f"样本数 = 1 且只放入 train 的 Type 数: {single_sample_count}")
    print(f"样本数 >= 2 且按比例划分的 Type 数: {multi_sample_count}")
    print(f"Train/Test 重复原始样本数: {len(overlap_ids)}")

    print("\nTrain 中 Type 样本数:")
    print(train_df_out[type_col].value_counts().sort_values())

    print("\nTest 中 Type 样本数:")
    print(test_df_out[type_col].value_counts().sort_values())

    print(f"\n已保存 train: {train_output}")
    print(f"已保存 test: {test_output}")
    print(f"已保存统计文件: {stats_output}")

    return train_df_out, test_df_out, stats_df


# =========================
# 执行
# =========================
split_by_type_train_test_strict(
    file_path="all_arg_nonarg_id_label.csv",
    type_col="Type",
    test_ratio=0.3,
    random_state=42,
    train_output="train_set_type.csv",
    test_output="test_set_type.csv",
    stats_output="type_split_statistics_type.csv"
)