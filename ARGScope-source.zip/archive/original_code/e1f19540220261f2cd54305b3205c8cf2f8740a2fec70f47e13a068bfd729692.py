from pathlib import Path
from PIL import Image

root = Path(__file__).parent
qa = root / 'qa'
qa.mkdir(exist_ok=True)
for path in sorted(root.glob('Novel_gene_Type_heatmap_*.png')):
    im = Image.open(path).convert('RGBA')
    white = Image.new('RGBA', im.size, (255, 255, 255, 255))
    white.alpha_composite(im)
    white.thumbnail((1500, 1500))
    dest = qa / path.name
    white.convert('RGB').save(dest)
    print(dest)
