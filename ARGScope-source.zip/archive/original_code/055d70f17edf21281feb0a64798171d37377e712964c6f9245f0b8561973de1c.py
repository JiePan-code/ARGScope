"""Recalculate VF/BGC test metrics, without changing predictions or thresholds.

Run with Python + numpy. Results go only to new, explicitly named subfolders.
Type: reference-positive records, fixed biological labels, missed detections kept.
Binary and Subtype: all test records, including the negative class.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


OUT_NAME = "统一口径结果_20260921"
METRICS = ["ACC", "Precision", "Recall", "F1", "MCC"]
SPECS = [
    {
        "domain": "VF", "negative": "non-VF", "binary": "VF/non-VF",
        "root": r"E:\1. ARGmodel\毒力因子数据处理\独立因子新结果",
        "metadata": "Dataset_split/VF_nonVF_ID表_split.csv",
        "test_metadata": "Dataset_split/VF_nonVF_ID表_test.csv",
        "models": [("VFScope-AA", "1.result/1Protein_student_VF"),
                   ("VFScope-NT", "1.result/2DNA_student_VF")],
    },
    {
        "domain": "BGC", "negative": "nonBGC", "binary": "BGC/nonBGC",
        "root": r"E:\1. ARGmodel\BGC数据处理\BGC_novel dataset",
        "metadata": "Dataset_split/BGC_nonBGC_id_type_subtype_split.csv",
        "test_metadata": "Dataset_split/BGC_nonBGC_id_type_subtype_test.csv",
        "models": [("BGCScope-AA", "1 Result/1.Protein_student_BGC"),
                   ("BGCScope-NT", "1 Result/2.DNA_student_BGC")],
    },
]


def sha256(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return [{k: v.strip() for k, v in row.items()} for row in csv.DictReader(f)]


def write_csv(path, rows):
    assert rows, path
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def div(num, den):
    return num / den if den else 0.0


def metrics_from_labels(y_true, y_pred, eligible_labels):
    """Counter implementation; MCC retains all prediction outcomes."""
    assert len(y_true) == len(y_pred) and y_true
    assert len(set(eligible_labels)) == len(eligible_labels)
    assert set(y_true).issubset(eligible_labels)
    n = len(y_true)
    true_counts, pred_counts = Counter(y_true), Counter(y_pred)
    correct_counts = Counter(t for t, p in zip(y_true, y_pred) if t == p)
    observed = set(true_counts) | set(pred_counts)
    correct = sum(correct_counts.values())
    denominator = math.sqrt((n*n-sum(v*v for v in true_counts.values())) *
                            (n*n-sum(v*v for v in pred_counts.values())))
    mcc = div(correct*n-sum(true_counts[k]*pred_counts[k] for k in observed), denominator)
    per_class = []
    for label in eligible_labels:
        tp = correct_counts[label]
        fp, fn = pred_counts[label]-tp, true_counts[label]-tp
        tn = n - tp - fp - fn
        per_class.append({
            "Label": label, "Support": true_counts[label], "Predicted": pred_counts[label],
            "TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "ACC_ovr": div(tp+tn, n), "Precision": div(tp, tp+fp),
            "Recall": div(tp, tp+fn), "F1": div(2*tp, 2*tp+fp+fn),
            "MCC_ovr": div(tp*tn-fp*fn, math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))),
        })
    total_tp = sum(r["TP"] for r in per_class)
    total_fp = sum(r["FP"] for r in per_class)
    total_fn = sum(r["FN"] for r in per_class)
    results = []
    for avg in ["macro", "weighted", "micro"]:
        r = {"Average": avg, "ACC": correct/n}
        for metric in ["Precision", "Recall", "F1"]:
            if avg == "macro":
                r[metric] = sum(p[metric] for p in per_class) / len(per_class)
            elif avg == "weighted":
                r[metric] = sum(p[metric]*p["Support"] for p in per_class) / n
            else:
                r[metric] = {"Precision": div(total_tp, total_tp+total_fp),
                             "Recall": div(total_tp, total_tp+total_fn),
                             "F1": div(2*total_tp, 2*total_tp+total_fp+total_fn)}[metric]
        r["MCC"] = mcc
        results.append(r)
    verify_with_matrix(y_true, y_pred, eligible_labels, results)
    return results, per_class


def verify_with_matrix(y_true, y_pred, eligible_labels, calculated):
    """Independent dense confusion-matrix calculation, including miss column."""
    labels = sorted(set(y_true) | set(y_pred) | set(eligible_labels))
    index = {label: i for i, label in enumerate(labels)}
    cm = np.zeros((len(labels), len(labels)), dtype=np.int64)
    np.add.at(cm, ([index[t] for t in y_true], [index[p] for p in y_pred]), 1)
    selected = np.array([index[k] for k in eligible_labels])
    support = cm.sum(axis=1).astype(float)
    predicted = cm.sum(axis=0).astype(float)
    diagonal = cm.diagonal().astype(float)
    p = np.divide(diagonal, predicted, out=np.zeros_like(diagonal), where=predicted!=0)[selected]
    r = np.divide(diagonal, support, out=np.zeros_like(diagonal), where=support!=0)[selected]
    f = np.divide(2*p*r, p+r, out=np.zeros_like(p), where=(p+r)!=0)
    s = support[selected]
    n, correct = int(cm.sum()), int(np.trace(cm))
    denom = np.sqrt((n*n-np.dot(support,support))*(n*n-np.dot(predicted,predicted)))
    mcc = div(correct*n-np.dot(support,predicted), denom)
    tp, pp, tt = diagonal[selected].sum(), predicted[selected].sum(), support[selected].sum()
    expected = {
        "macro": [correct/n, p.mean(), r.mean(), f.mean(), mcc],
        "weighted": [correct/n, np.dot(p,s)/s.sum(), np.dot(r,s)/s.sum(), np.dot(f,s)/s.sum(), mcc],
        "micro": [correct/n, div(tp,pp), div(tp,tt), div(2*tp,pp+tt), mcc],
    }
    for row in calculated:
        np.testing.assert_allclose([row[k] for k in METRICS], expected[row["Average"]], rtol=0, atol=1e-12)


def process(spec):
    root = Path(spec["root"])
    metadata_path, test_path = root/spec["metadata"], root/spec["test_metadata"]
    neg, domain = spec["negative"], spec["domain"]
    all_metadata, test_metadata = read_csv(metadata_path), read_csv(test_path)
    assert len({r["id"] for r in all_metadata}) == len(all_metadata)
    expected = {r["id"]: r for r in test_metadata}
    assert len(expected) == len(test_metadata)
    assert {r["id"] for r in all_metadata if r["split"] == "test"} == set(expected)
    authoritative_ids_path = root/"Dataset_split/test_ids.txt"
    authoritative_ids = authoritative_ids_path.read_text(encoding="utf-8-sig").splitlines()
    assert len(authoritative_ids) == len(set(authoritative_ids))
    assert set(authoritative_ids) == set(expected)
    type_labels = sorted({r["type"] for r in all_metadata} - {neg})
    models, manifest = [], []

    def source(path, role, model=""):
        manifest.append({"Model": model, "Role": role, "Path": str(path.resolve()),
                         "SHA256": sha256(path), "Bytes": path.stat().st_size})

    source(metadata_path, "Full split label universe")
    source(test_path, "Authoritative test labels")
    source(authoritative_ids_path, "Authoritative test IDs")
    for name, rel in spec["models"]:
        pred_path = root/rel/"test_sequence_predictions.csv"
        rows = read_csv(pred_path)
        assert len({r["id"] for r in rows}) == len(rows)
        assert {r["id"] for r in rows} == set(expected)
        assert all(r["split"] == "test" for r in rows)
        for row in rows:
            truth = expected[row["id"]]
            for level in ["type", "subtype"]:
                assert row["true_"+level] == truth[level], (name, row["id"], level)
                assert row["predicted_"+level], (name, row["id"], "empty prediction")
            for prefix in ["true", "predicted"]:
                assert row[prefix+"_binary"] in [domain, neg]
                assert (row[prefix+"_binary"] == neg) == (row[prefix+"_type"] == neg)
                assert (row[prefix+"_binary"] == neg) == (row[prefix+"_subtype"] == neg)
            assert row["predicted_type"] in type_labels+[neg]
        old_path = root/rel/"five_metrics_results/all_overall_five_metrics.csv"
        models.append({"name": name, "rows": rows, "old": read_csv(old_path), "dir": root/rel})
        source(pred_path, "Test sequence predictions", name)
        source(old_path, "Previous all-sample metrics for reconciliation", name)
        source(root/rel/"run_summary.json", "Fixed model and threshold provenance", name)
    subtype_sets = [set(r[k] for r in m["rows"] for k in ["true_subtype", "predicted_subtype"]) for m in models]
    assert subtype_sets[0] == subtype_sets[1], "Subtype universe differs across modalities; review explicitly"
    subtype_labels = sorted(subtype_sets[0])
    assert set(subtype_labels) <= {r["subtype"] for r in all_metadata}
    assert neg in subtype_labels and neg not in type_labels
    all_rows, main, per_type, per_subtype, comparisons, cohort_audit, reconciliations = [], [], [], [], [], [], []
    for model in models:
        rows, name = model["rows"], model["name"]
        positive = [r for r in rows if r["true_binary"] == domain]
        misses = sum(r["predicted_binary"] == neg for r in positive)
        old_lookup = {(r["level"], r["average"]): r for r in model["old"]}
        cohort_audit.append({"Model": name, "Total_test": len(rows), "Type_evaluated": len(positive),
                             "Reference_negative_excluded_from_Type": len(rows)-len(positive),
                             "Missed_positives_kept_in_Type": misses, "Type_labels": len(type_labels),
                             "Subtype_labels_including_negative": len(subtype_labels)})
        for level, key, cohort, labels, scope in [
            (spec["binary"], "binary", rows, [domain, neg], "All test sequences"),
            ("Type", "type", positive, type_labels, "Reference-positive sequences; misses retained"),
            ("Subtype", "subtype", rows, subtype_labels, "All test sequences; negative class included"),
        ]:
            yt, yp = [r["true_"+key] for r in cohort], [r["predicted_"+key] for r in cohort]
            overall, class_rows = metrics_from_labels(yt, yp, labels)
            for row in overall:
                result = {"Model": name, "Task": level, **row, "Scope": scope,
                          "N_sequences": len(cohort), "N_labels": len(labels)}
                all_rows.append(result)
                if row["Average"] == ("weighted" if level == "Subtype" else "macro"):
                    main.append({k: result[k] for k in ["Model", "Task", "Average", *METRICS]})
            if level == "Type":
                per_type.extend({"Model": name, **r} for r in class_rows)
            if level == "Subtype":
                per_subtype.extend({"Model": name, **r} for r in class_rows)
            # Reproduce every old row with its original all-sample union-label definition.
            old_ytrue, old_ypred = [r["true_"+key] for r in rows], [r["predicted_"+key] for r in rows]
            old_recomputed, _ = metrics_from_labels(old_ytrue, old_ypred, sorted(set(old_ytrue)|set(old_ypred)))
            for old_recalc in old_recomputed:
                old = old_lookup[(level, old_recalc["Average"])]
                diff = max(abs(old_recalc[k]-float(old[{"ACC":"accuracy", "F1":"f1", "MCC":"mcc"}.get(k, k.lower())])) for k in METRICS)
                assert diff <= 5.1e-9, (name, level, old_recalc, old, diff)
                reconciliations.append({"Model": name, "Task": level, "Average": old_recalc["Average"],
                                        "Maximum_difference_to_old_8dp_csv": diff})
            old_main_average = "weighted" if domain == "VF" and level in ["Type", "Subtype"] else "macro"
            old_selected = next(r for r in old_recomputed if r["Average"] == old_main_average)
            new_selected = main[-1]
            for metric in METRICS:
                comparisons.append({"Model": name, "Task": level, "Metric": metric,
                                    "Old_average": old_main_average, "New_average": new_selected["Average"],
                                    "Old_value": old_selected[metric], "New_value": new_selected[metric],
                                    "Difference": new_selected[metric]-old_selected[metric],
                                    "Change": "Exclude reference negatives; macro main" if level == "Type" else
                                              "Weighted main; same population" if level == "Subtype" else
                                              "Macro main; same population"})
    supports = Counter(r["type"] for r in test_metadata)
    label_rows = [{"Type": label, "Test_support": supports[label], "Included_in_macro": True} for label in type_labels]
    out = root/OUT_NAME
    # Existing folders are only reusable if created by this script, never arbitrary user folders.
    if out.exists():
        assert (out/"verification.json").exists(), f"Unrecognized output folder: {out}"
        previous = json.loads((out/"verification.json").read_text(encoding="utf-8"))
        assert previous.get("generator") == Path(__file__).name
    else:
        out.mkdir()
    tables = {"01_main_results.csv": main, "02_all_averages.csv": all_rows,
              "03_per_type_metrics.csv": per_type, "04_per_subtype_metrics.csv": per_subtype,
              "05_type_label_universe.csv": label_rows, "06_old_vs_new.csv": comparisons,
              "07_sample_scope_audit.csv": cohort_audit, "08_source_manifest.csv": manifest}
    for filename, data in tables.items():
        write_csv(out/filename, data)
    # No prediction files or source metrics are rewritten.
    for entry in manifest:
        assert sha256(entry["Path"]) == entry["SHA256"], "Source changed during recalculation"
    audit = {"generator": Path(__file__).name, "created_utc": datetime.now(timezone.utc).isoformat(),
             "domain": domain, "input_sources_unchanged": True,
             "unique_test_ids_and_authoritative_test_set": True,
             "truth_labels_match_test_metadata": True,
             "binary_type_subtype_gating_consistent": True,
             "independent_counter_and_numpy_matrix_agree_atol": 1e-12,
             "type_labels": type_labels, "zero_division": 0,
             "old_metrics_reconciled": reconciliations,
             "model_cohorts": cohort_audit}
    (out/"verification.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    note = f"""# {domain} 统一口径结果

## 主表口径

- 二分类：全部测试序列，保留正、负两类；主表 Precision、Recall、F1 用 macro。
- Type：仅纳入真实 {domain} 序列，排除真实 {neg}；所有预测结果原样保留，预测成 {neg} 的漏检仍计错。
- Type 的 Precision、Recall、F1 在固定 {len(type_labels)} 个生物学类别上汇总，主表使用 macro，不因模型或类别得分为零而删类。
- Subtype：沿用前文补充表的端到端范围，全部测试序列、含 {neg} 类，主表使用 weighted；不是仅在正确检出的正样本上计算。
- 所有任务同时给出 macro、weighted、micro 三种平均方式。ACC 和 MCC 在该任务的同一测试总体上计算，不随平均方式改变。
- Subtype 标签集合沿用原结果的真实/预测标签并集，两种输入的集合一致，共 {len(subtype_labels)} 类（含非目标类）。
- 各类零分母按 0 处理，不把缺失记录当作正确结果。

## 文件

- 01_main_results.csv 与 Excel“Main”：可用于替换正文表格。数值列未预先四舍五入，Excel显示四位小数。
- 02_all_averages.csv 与 Excel“All averages”：三种平均方式完整结果。
- 03_per_type_metrics.csv：每个 Type 的五指标和 TP/FP/FN/TN；ACC_ovr、MCC_ovr 是该类别的一对其余类别指标，不是总体 ACC/MCC。
- 04_per_subtype_metrics.csv：全部 Subtype（含非目标类）的细分结果。
- 05_type_label_universe.csv：由完整划分元数据确定的 Type 集合。
- 06_old_vs_new.csv：此前正文使用的平均方式与新主表的逐指标对照。
- 07_sample_scope_audit.csv：排除的真实负样本数与保留的漏检数。
- 08_source_manifest.csv、verification.json：输入来源、文件哈希和核验记录。

## 解释时注意

Type 的 micro Precision 只累计目标类别的预测，预测成非目标的漏检进入 FN，因此 micro Precision、Recall、F1 不一定相等；micro Recall 等于此处 ACC。
MCC 使用全部预测取值（含漏检对应的非目标取值），不删掉错误预测。
Subtype 的 weighted 结果包含非目标类，不能写成“仅正样本的亚型识别性能”。请在正文或表注写明平均方式和统计范围。
旧 VF 表的 Type/Subtype 使用 weighted，而旧 BGC 表使用 macro；新表统一后数值变化不代表模型经过重新训练。
没有训练、调阈值、改预测、映射额外类别或改动原始结果文件。

Suggested table note: Binary metrics were calculated across all test sequences. Type metrics were calculated on reference-positive sequences, retaining missed detections as errors. Precision, recall and F1 are macro-averaged for binary and Type classification, and support-weighted for end-to-end Subtype classification, which includes the negative class. ACC and MCC were calculated on the corresponding evaluation population.
"""
    (out/"README_统计口径说明.md").write_text(note, encoding="utf-8")
    payload = {"domain": domain, "negative": neg, "output_dir": str(out), "main": main,
               "all_averages": all_rows, "per_type": per_type, "labels": label_rows,
               "audit": cohort_audit, "comparisons": comparisons, "sources": manifest}
    (out/"results_for_workbook.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"domain": domain, "output": str(out), "main": main, "audit": cohort_audit}, ensure_ascii=False))
    return payload


if __name__ == "__main__":
    # Explicit edge check: an abstention/miss remains in the denominator of recall/ACC.
    edge, _ = metrics_from_labels(["A", "B"], ["A", "negative"], ["A", "B", "C"])
    assert edge[0]["ACC"] == 0.5 and edge[0]["Recall"] == 1/3
    assert edge[2]["Precision"] == 1 and edge[2]["Recall"] == 0.5
    for item in SPECS:
        process(item)
