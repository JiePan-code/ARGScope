import pandas as pd

# =========================
# 文件路径
# =========================
FULL_TRAIN_FILE = "train_set.csv"
FULL_TEST_FILE = "test_set.csv"

SHORT_FILE = "1. 数据IDARG_nonARG_table_5x.csv"   # 你的 short 三列表
OUT_TRAIN = "short_train.csv"
OUT_TEST = "short_test.csv"
OUT_UNMATCHED = "short_unmatched.csv"

# =========================
# 列名设置
# =========================
FULL_ID_COL = "id"     # full-length 文件里的原始ID列
SHORT_ID_COL = "id"    # short 文件里的新ID列

# =========================
# 读取文件
# =========================
train_df = pd.read_csv(FULL_TRAIN_FILE, dtype=str)
test_df = pd.read_csv(FULL_TEST_FILE, dtype=str)
short_df = pd.read_csv(SHORT_FILE, dtype=str)

train_df.columns = train_df.columns.str.strip()
test_df.columns = test_df.columns.str.strip()
short_df.columns = short_df.columns.str.strip()

train_df[FULL_ID_COL] = train_df[FULL_ID_COL].astype(str).str.strip()
test_df[FULL_ID_COL] = test_df[FULL_ID_COL].astype(str).str.strip()
short_df[SHORT_ID_COL] = short_df[SHORT_ID_COL].astype(str).str.strip()

# =========================
# 从 short 的 id 还原原始母序列 ID
# 例如：
# 0910185A_1 -> 0910185A
# 0910185A_2 -> 0910185A
# =========================
short_df["raw_id"] = short_df[SHORT_ID_COL].str.replace(r"_[1-5]$", "", regex=True)

# =========================
# 构建 full-length 的 train/test ID 集合
# =========================
train_ids = set(train_df[FULL_ID_COL])
test_ids = set(test_df[FULL_ID_COL])

# 检查 full-length train/test 是否有重叠
overlap_full = train_ids & test_ids
print("full-length train/test 重叠数:", len(overlap_full))
if len(overlap_full) > 0:
    print("警告：原始 full-length 的 train/test 本身就有重叠！")

# =========================
# 继承 full-length 的划分
# =========================
short_train = short_df[short_df["raw_id"].isin(train_ids)].copy()
short_test = short_df[short_df["raw_id"].isin(test_ids)].copy()
short_unmatched = short_df[
    ~short_df["raw_id"].isin(train_ids) & ~short_df["raw_id"].isin(test_ids)
].copy()

# =========================
# 检查 short train/test 是否有母序列交叉
# =========================
short_train_raw_ids = set(short_train["raw_id"])
short_test_raw_ids = set(short_test["raw_id"])
overlap_short = short_train_raw_ids & short_test_raw_ids

print("short train 条数:", len(short_train))
print("short test 条数:", len(short_test))
print("short unmatched 条数:", len(short_unmatched))
print("short 母序列交叉数:", len(overlap_short))

if len(overlap_short) > 0:
    print("警告：short train/test 仍然有母序列重叠，存在数据泄露风险！")

# =========================
# 删除辅助列并保存
# =========================
short_train.drop(columns=["raw_id"]).to_csv(OUT_TRAIN, index=False, encoding="utf-8-sig")
short_test.drop(columns=["raw_id"]).to_csv(OUT_TEST, index=False, encoding="utf-8-sig")

if len(short_unmatched) > 0:
    short_unmatched.to_csv(OUT_UNMATCHED, index=False, encoding="utf-8-sig")

print("输出完成：")
print("训练集文件:", OUT_TRAIN)
print("测试集文件:", OUT_TEST)
if len(short_unmatched) > 0:
    print("未匹配文件:", OUT_UNMATCHED)