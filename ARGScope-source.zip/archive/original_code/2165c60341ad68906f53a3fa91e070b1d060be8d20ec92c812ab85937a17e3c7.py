#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Apply the new ARG:nonARG = 1:10 DNA student model to all Diamond0.2
candidate DNABERT-2 CLS embeddings.

Expected layout
---------------
DNABERT2_Diamond0.2_candidate_CLS_embeddings/
├── argbert_1_diamond0.2_candidate_reads/
├── argbert_2_diamond0.2_candidate_reads/
├── argbert_3_diamond0.2_candidate_reads/
├── argscope_1_diamond0.2_candidate_reads/
├── argscope_2_diamond0.2_candidate_reads/
├── argscope_3_diamond0.2_candidate_reads/
├── argscope_4_diamond0.2_candidate_reads/
├── argscope_5_diamond0.2_candidate_reads/
├── argscope_6_diamond0.2_candidate_reads/
│
├── DNA_student_ARG110_model/
│   └── DNA_student_fusion_refined_model.pt
│
├── DNA_model_818/
│   └── structure_50aa_150nt_5parts.txt      # fallback Type mapping
│
└── apply_DNA_student_ARG110_to_Diamond0.2_embeddings_LOCAL_GPU.py

Inference
---------
DNABERT-2 CLS 768D
    -> DNA student
    -> binary ARG probability
    -> checkpoint-saved binary threshold
    -> if ARG: ARG subtype head
    -> Type obtained from deterministic Subtype -> Type mapping

No threshold tuning is performed on the real Diamond0.2 data.
No Unknown/rejection class is used.
All candidate reads receive a prediction.

Outputs
-------
DNA_student_ARG110_Diamond0.2_predictions/
├── argbert_1_diamond0.2_candidate_reads/
│   ├── *_DNA_student_ARG110_predictions.csv.gz
│   ├── ARGScope_ARG_nonARG_counts.csv
│   ├── ARGScope_subtype_counts.csv
│   ├── ARGScope_type_counts.csv
│   └── ARGScope_prediction_summary.json
├── ...
├── ARG110_Diamond0.2_overall_summary.csv
└── ARG110_Diamond0.2_overall_summary.json
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import os
import time
from collections import Counter
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


SCRIPT_VERSION = "2026-08-18-ARG110-Diamond0.2-real-inference-GPU-shortpath-v2"
NONARG = "nonARG"

HERE = Path(__file__).resolve().parent

SAMPLES = [
    "argbert_1_diamond0.2_candidate_reads",
    "argbert_2_diamond0.2_candidate_reads",
    "argbert_3_diamond0.2_candidate_reads",
    "argscope_1_diamond0.2_candidate_reads",
    "argscope_2_diamond0.2_candidate_reads",
    "argscope_3_diamond0.2_candidate_reads",
    "argscope_4_diamond0.2_candidate_reads",
    "argscope_5_diamond0.2_candidate_reads",
    "argscope_6_diamond0.2_candidate_reads",
]

DEFAULT_MODEL = (
    HERE
    / "DNA_student_ARG110_model"
    / "DNA_student_fusion_refined_model.pt"
)

DEFAULT_OUTPUT_ROOT = (
    HERE
    / "ARG110_D02_pred"
)

STRUCTURE_CANDIDATES = [
    HERE
    / "DNA_student_ARG110_model"
    / "structure_50aa_150nt_5parts.txt",

    HERE
    / "structure_50aa_150nt_5parts.txt",

    HERE
    / "DNA_model_818"
    / "structure_50aa_150nt_5parts.txt",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Apply ARG:nonARG=1:10 DNA student to all "
            "Diamond0.2 candidate DNABERT-2 CLS embeddings."
        )
    )

    parser.add_argument(
        "--root",
        type=Path,
        default=HERE,
    )

    parser.add_argument(
        "--model",
        type=Path,
        default=DEFAULT_MODEL,
    )

    parser.add_argument(
        "--structure",
        type=Path,
        default=None,
        help=(
            "Subtype->Type structure file. If omitted, the script "
            "auto-detects structure_50aa_150nt_5parts.txt."
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )

    parser.add_argument(
        "--samples",
        nargs="+",
        default=SAMPLES,
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=8192,
    )

    parser.add_argument(
        "--no-amp",
        action="store_true",
    )

    parser.add_argument(
        "--no-write-predictions",
        action="store_true",
        help=(
            "Do not write per-read CSV.gz files. Summary/count files "
            "are still written."
        ),
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
    )

    return parser.parse_args()


def short_sample_name(sample_name: str) -> str:
    """
    Short output folder name to avoid the Windows ~260-character MAX_PATH issue.

    Examples:
        argbert_1_diamond0.2_candidate_reads -> argbert_1
        argscope_6_diamond0.2_candidate_reads -> argscope_6
    """
    suffix = "_diamond0.2_candidate_reads"

    if sample_name.endswith(suffix):
        return sample_name[:-len(suffix)]

    return sample_name


def canonical_id(value: Any) -> str:
    return str(value).strip().split()[0]


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()
    return NONARG if text.lower() == "nonarg" else text


def load_pt(path: Path) -> Any:
    try:
        return torch.load(
            path,
            map_location="cpu",
            weights_only=False,
        )
    except TypeError:
        return torch.load(
            path,
            map_location="cpu",
        )


def find_structure(
    requested: Path | None,
    root: Path,
) -> Path:

    if requested is not None:
        requested = (
            requested
            .expanduser()
            .resolve()
        )

        if not requested.is_file():
            raise FileNotFoundError(
                f"Structure not found: {requested}"
            )

        return requested

    candidates = [
        root
        / "DNA_student_ARG110_model"
        / "structure_50aa_150nt_5parts.txt",

        root
        / "structure_50aa_150nt_5parts.txt",

        root
        / "DNA_model_818"
        / "structure_50aa_150nt_5parts.txt",
    ]

    for path in candidates:
        if path.is_file():
            return path.resolve()

    raise FileNotFoundError(
        "Could not auto-detect structure_50aa_150nt_5parts.txt.\n"
        "Tried:\n  "
        + "\n  ".join(
            str(path)
            for path
            in candidates
        )
        + "\nUse --structure to specify it explicitly."
    )


class CosineHead(nn.Module):
    def __init__(
        self,
        number_classes: int,
        dimension: int,
        scale: float,
    ):
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(
                number_classes,
                dimension,
            )
        )

        nn.init.xavier_uniform_(
            self.weight
        )

        self.scale = float(
            scale
        )

    def forward(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:

        return self.scale * F.linear(
            F.normalize(
                features,
                p=2,
                dim=1,
            ),
            F.normalize(
                self.weight,
                p=2,
                dim=1,
            ),
        )


class ResidualBlock(nn.Module):
    def __init__(
        self,
        dimension: int,
        dropout: float,
    ):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
            nn.GELU(),
            nn.Dropout(
                dropout
            ),
            nn.Linear(
                dimension,
                dimension,
            ),
            nn.LayerNorm(
                dimension
            ),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:

        return F.gelu(
            x
            + self.net(
                x
            )
        )


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        hidden_dimension: int,
        embedding_dimension: int,
        dropout: float,
        binary_scale: float,
        subtype_scale: float,
    ):
        super().__init__()

        self.register_buffer(
            "dna_mean",
            dna_mean.clone().float(),
        )

        self.register_buffer(
            "dna_std",
            dna_std.clone().float(),
        )

        self.input = nn.Sequential(
            nn.Linear(
                dna_dimension,
                hidden_dimension,
            ),
            nn.LayerNorm(
                hidden_dimension
            ),
            nn.GELU(),
            nn.Dropout(
                dropout
            ),
        )

        self.blocks = nn.Sequential(
            ResidualBlock(
                hidden_dimension,
                dropout,
            ),
            ResidualBlock(
                hidden_dimension,
                dropout,
            ),
        )

        self.output = nn.Sequential(
            nn.Linear(
                hidden_dimension,
                embedding_dimension,
            ),
            nn.LayerNorm(
                embedding_dimension
            ),
        )

        self.binary_head = CosineHead(
            2,
            embedding_dimension,
            binary_scale,
        )

        self.arg_head = CosineHead(
            number_arg_subtypes,
            embedding_dimension,
            subtype_scale,
        )

    def encode(
        self,
        dna: torch.Tensor,
    ) -> torch.Tensor:

        dna = (
            dna
            - self.dna_mean
        ) / self.dna_std

        hidden = self.blocks(
            self.input(
                dna
            )
        )

        return F.normalize(
            self.output(
                hidden
            ),
            p=2,
            dim=1,
        )

    def forward(
        self,
        dna: torch.Tensor,
    ):
        features = self.encode(
            dna
        )

        return (
            self.binary_head(
                features
            ),
            self.arg_head(
                features
            ),
            features,
        )


def load_model(
    checkpoint_path: Path,
    device: torch.device,
):
    checkpoint = load_pt(
        checkpoint_path
    )

    if not isinstance(
        checkpoint,
        dict,
    ):
        raise TypeError(
            "Model checkpoint must contain a dictionary"
        )

    required = {
        "student_state_dict",
        "dna_input_dimension",
        "embedding_dimension",
        "arg_subtype_names",
        "dna_train_mean",
        "dna_train_std",
        "configuration",
    }

    missing = sorted(
        required
        - set(
            checkpoint
        )
    )

    if missing:
        raise KeyError(
            f"Model checkpoint missing fields: {missing}"
        )

    configuration = checkpoint[
        "configuration"
    ]

    arg_names = [
        canonical_subtype(
            value
        )
        for value
        in checkpoint[
            "arg_subtype_names"
        ]
    ]

    if NONARG in arg_names:
        raise ValueError(
            "arg_subtype_names unexpectedly contains nonARG"
        )

    dna_dimension = int(
        checkpoint[
            "dna_input_dimension"
        ]
    )

    embedding_dimension = int(
        checkpoint[
            "embedding_dimension"
        ]
    )

    model = DNAStudent(
        dna_dimension=dna_dimension,
        dna_mean=checkpoint[
            "dna_train_mean"
        ],
        dna_std=checkpoint[
            "dna_train_std"
        ],
        number_arg_subtypes=len(
            arg_names
        ),
        hidden_dimension=int(
            configuration.get(
                "hidden_dim",
                1024,
            )
        ),
        embedding_dimension=embedding_dimension,
        dropout=float(
            configuration.get(
                "dropout",
                0.18,
            )
        ),
        binary_scale=float(
            configuration.get(
                "logit_scale_binary",
                16.0,
            )
        ),
        subtype_scale=float(
            configuration.get(
                "logit_scale_subtype",
                24.0,
            )
        ),
    )

    model.load_state_dict(
        checkpoint[
            "student_state_dict"
        ],
        strict=True,
    )

    model.to(
        device
    ).eval()

    threshold = float(
        checkpoint.get(
            "selected_binary_ARG_probability_threshold",
            0.50,
        )
    )

    if not (
        0.0
        < threshold
        < 1.0
    ):
        raise ValueError(
            f"Invalid saved binary threshold: {threshold}"
        )

    return (
        model,
        checkpoint,
        arg_names,
        threshold,
    )


def build_subtype_to_type(
    structure_path: Path,
    model_arg_names: list[str],
):
    subtype_to_type: dict[
        str,
        str,
    ] = {
        NONARG:
            NONARG,
    }

    rows = 0

    with structure_path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                f"Structure has no header: {structure_path}"
            )

        required = {
            "Subtype",
            "Type",
        }

        missing = sorted(
            required
            - set(
                reader.fieldnames
            )
        )

        if missing:
            raise ValueError(
                f"Structure missing columns {missing}: {structure_path}"
            )

        for raw in reader:
            rows += 1

            subtype = canonical_subtype(
                raw.get(
                    "Subtype",
                    "",
                )
            )

            type_name = str(
                raw.get(
                    "Type",
                    "",
                )
            ).strip()

            if subtype == NONARG:
                type_name = NONARG

            if not subtype or not type_name:
                continue

            previous = subtype_to_type.get(
                subtype
            )

            if (
                previous is not None
                and previous != type_name
            ):
                raise ValueError(
                    f"Subtype maps to multiple Types: "
                    f"{subtype}: {previous} vs {type_name}"
                )

            subtype_to_type[
                subtype
            ] = type_name

    missing_model_subtypes = sorted(
        set(
            model_arg_names
        )
        - set(
            subtype_to_type
        )
    )

    if missing_model_subtypes:
        raise ValueError(
            "Structure does not cover all model ARG subtypes. "
            f"Missing={len(missing_model_subtypes)}; "
            f"examples={missing_model_subtypes[:20]}"
        )

    extra_structure_arg = sorted(
        set(
            subtype_to_type
        )
        - {
            NONARG
        }
        - set(
            model_arg_names
        )
    )

    return {
        "mapping":
            subtype_to_type,

        "structure_rows":
            rows,

        "mapped_model_subtypes":
            len(
                model_arg_names
            )
            - len(
                missing_model_subtypes
            ),

        "missing_model_subtypes":
            missing_model_subtypes,

        "extra_structure_arg_subtypes":
            extra_structure_arg,
    }


def find_embedding_chunks(
    sample_dir: Path,
) -> list[Path]:

    patterns = [
        "*_dnabert2_CLS.pt",
        "*_DNABERT2_CLS.pt",
        "*.pt",
    ]

    for pattern in patterns:

        matches = sorted(
            path
            for path
            in sample_dir.glob(
                pattern
            )
            if path.is_file()
        )

        if matches:
            return matches

    return []


def load_embedding_chunk(
    path: Path,
    expected_dimension: int,
):
    obj = load_pt(
        path
    )

    if not isinstance(
        obj,
        dict,
    ):
        raise TypeError(
            f"Embedding PT must contain dictionary: {path}"
        )

    id_key = next(
        (
            key
            for key
            in (
                "ids",
                "fragment_ids",
                "sequence_ids",
            )
            if key
            in obj
        ),
        None,
    )

    embedding_key = next(
        (
            key
            for key
            in (
                "embeddings",
                "mean_embeddings",
                "features",
            )
            if key
            in obj
        ),
        None,
    )

    if id_key is None:
        raise KeyError(
            f"No ID field in {path}; keys={sorted(obj)}"
        )

    if embedding_key is None:
        raise KeyError(
            f"No embedding field in {path}; keys={sorted(obj)}"
        )

    ids = [
        canonical_id(
            value
        )
        for value
        in obj[
            id_key
        ]
    ]

    embeddings = obj[
        embedding_key
    ]

    if not isinstance(
        embeddings,
        torch.Tensor,
    ):
        raise TypeError(
            f"Embeddings are not a torch.Tensor: {path}"
        )

    if embeddings.ndim != 2:
        raise ValueError(
            f"Embeddings must be 2D: {path}; "
            f"shape={tuple(embeddings.shape)}"
        )

    embeddings = (
        embeddings
        .detach()
        .cpu()
        .float()
        .contiguous()
    )

    if embeddings.shape[0] != len(
        ids
    ):
        raise ValueError(
            f"ID/embedding count mismatch: {path}"
        )

    if embeddings.shape[1] != expected_dimension:
        raise ValueError(
            f"Embedding dimension mismatch: {path}; "
            f"observed={embeddings.shape[1]}, "
            f"expected={expected_dimension}"
        )

    if len(
        set(
            ids
        )
    ) != len(
        ids
    ):
        raise ValueError(
            f"Duplicate read IDs in PT: {path}"
        )

    if not bool(
        torch.isfinite(
            embeddings
        ).all()
    ):
        raise ValueError(
            f"NaN/Inf detected in embeddings: {path}"
        )

    metadata = {
        "pooling":
            obj.get(
                "pooling",
                obj.get(
                    "pooling_name",
                    None,
                ),
            ),

        "truncation":
            obj.get(
                "truncation",
                None,
            ),

        "max_token_length":
            obj.get(
                "max_token_length",
                obj.get(
                    "model_max_length",
                    None,
                ),
            ),
    }

    return (
        ids,
        embeddings,
        metadata,
    )


def amp_context(
    use_amp: bool,
):
    return torch.autocast(
        device_type="cuda",
        dtype=torch.float16,
        enabled=use_amp,
    )


@torch.no_grad()
def infer_chunk(
    model: DNAStudent,
    embeddings: torch.Tensor,
    batch_size: int,
    device: torch.device,
    use_amp: bool,
):
    number = embeddings.shape[0]

    arg_probability = torch.empty(
        number,
        dtype=torch.float32,
    )

    subtype_probability = torch.empty(
        number,
        dtype=torch.float32,
    )

    subtype_index = torch.empty(
        number,
        dtype=torch.long,
    )

    start = 0

    while start < number:

        end = min(
            start
            + batch_size,
            number,
        )

        batch = embeddings[
            start:end
        ].to(
            device,
            non_blocking=True,
        )

        with amp_context(
            use_amp
        ):

            binary_logits, subtype_logits, _ = model(
                batch
            )

        binary_prob = torch.softmax(
            binary_logits.float(),
            dim=1,
        )[
            :,
            1,
        ]

        subtype_prob_tensor = torch.softmax(
            subtype_logits.float(),
            dim=1,
        )

        local_subtype_probability, local_subtype_index = torch.max(
            subtype_prob_tensor,
            dim=1,
        )

        arg_probability[
            start:end
        ] = binary_prob.cpu()

        subtype_probability[
            start:end
        ] = local_subtype_probability.cpu()

        subtype_index[
            start:end
        ] = local_subtype_index.cpu()

        start = end

    return (
        arg_probability,
        subtype_probability,
        subtype_index,
    )


def atomic_write_csv(
    path: Path,
    rows: list[dict[str, Any]],
) -> None:

    if not rows:
        return

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    fieldnames = list(
        rows[0].keys()
    )

    with temp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(
            rows
        )

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def atomic_write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )

        handle.flush()
        os.fsync(
            handle.fileno()
        )

    os.replace(
        temp,
        path,
    )


def write_prediction_gzip(
    path: Path,
    ids: list[str],
    arg_probability: torch.Tensor,
    subtype_probability: torch.Tensor,
    subtype_index: torch.Tensor,
    threshold: float,
    arg_names: list[str],
    subtype_to_type: dict[str, str],
) -> tuple[
    Counter,
    Counter,
    Counter,
]:

    temp = Path(
        str(
            path
        )
        + ".tmp"
    )

    subtype_counts: Counter = Counter()
    type_counts: Counter = Counter()
    binary_counts: Counter = Counter()

    with gzip.open(
        temp,
        mode="wt",
        encoding="utf-8",
        newline="",
        compresslevel=4,
    ) as handle:

        writer = csv.writer(
            handle
        )

        writer.writerow(
            [
                "read_id",
                "predicted_ARG",
                "ARG_probability",
                "predicted_subtype",
                "ARG_head_predicted_subtype",
                "predicted_type",
                "ARG_subtype_max_probability",
                "binary_threshold",
                "coverage",
            ]
        )

        for index, read_id in enumerate(
            ids
        ):

            probability = float(
                arg_probability[
                    index
                ]
            )

            arg_head_subtype = arg_names[
                int(
                    subtype_index[
                        index
                    ]
                )
            ]

            is_arg = (
                probability
                >= threshold
            )

            predicted_subtype = (
                arg_head_subtype
                if is_arg
                else NONARG
            )

            predicted_type = subtype_to_type[
                predicted_subtype
            ]

            binary_label = (
                "ARG"
                if is_arg
                else NONARG
            )

            binary_counts[
                binary_label
            ] += 1

            subtype_counts[
                predicted_subtype
            ] += 1

            type_counts[
                predicted_type
            ] += 1

            writer.writerow(
                [
                    read_id,
                    int(
                        is_arg
                    ),
                    f"{probability:.8f}",
                    predicted_subtype,
                    arg_head_subtype,
                    predicted_type,
                    f"{float(subtype_probability[index]):.8f}",
                    f"{threshold:.8f}",
                    "1.0",
                ]
            )

    os.replace(
        temp,
        path,
    )

    return (
        binary_counts,
        subtype_counts,
        type_counts,
    )


def counts_without_prediction_file(
    arg_probability: torch.Tensor,
    subtype_index: torch.Tensor,
    threshold: float,
    arg_names: list[str],
    subtype_to_type: dict[str, str],
):
    binary_counts: Counter = Counter()
    subtype_counts: Counter = Counter()
    type_counts: Counter = Counter()

    for index in range(
        arg_probability.shape[0]
    ):

        probability = float(
            arg_probability[
                index
            ]
        )

        arg_head_subtype = arg_names[
            int(
                subtype_index[
                    index
                ]
            )
        ]

        is_arg = (
            probability
            >= threshold
        )

        predicted_subtype = (
            arg_head_subtype
            if is_arg
            else NONARG
        )

        predicted_type = subtype_to_type[
            predicted_subtype
        ]

        binary_counts[
            "ARG"
            if is_arg
            else NONARG
        ] += 1

        subtype_counts[
            predicted_subtype
        ] += 1

        type_counts[
            predicted_type
        ] += 1

    return (
        binary_counts,
        subtype_counts,
        type_counts,
    )


def counter_to_rows(
    counter: Counter,
    label_column: str,
) -> list[dict[str, Any]]:

    rows = []

    for label, count in sorted(
        counter.items(),
        key=lambda item: (
            -item[1],
            item[0],
        ),
    ):

        rows.append(
            {
                label_column:
                    label,

                "count":
                    int(
                        count
                    ),
            }
        )

    return rows


def process_sample(
    sample_name: str,
    root: Path,
    output_root: Path,
    model: DNAStudent,
    checkpoint: dict[str, Any],
    arg_names: list[str],
    subtype_to_type: dict[str, str],
    threshold: float,
    batch_size: int,
    device: torch.device,
    use_amp: bool,
    write_predictions: bool,
    overwrite: bool,
):

    sample_dir = (
        root
        / sample_name
    )

    if not sample_dir.is_dir():
        raise NotADirectoryError(
            f"Sample directory not found: {sample_dir}"
        )

    chunks = find_embedding_chunks(
        sample_dir
    )

    if not chunks:
        raise FileNotFoundError(
            f"No PT embedding files found in: {sample_dir}"
        )

    output_dir = (
        output_root
        / short_sample_name(sample_name)
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    summary_path = (
        output_dir
        / "summary.json"
    )

    if (
        summary_path.exists()
        and not overwrite
    ):
        raise FileExistsError(
            f"Output already exists for {sample_name}: "
            f"{summary_path}\nUse --overwrite to rerun."
        )

    print()
    print(
        "=" * 120,
        flush=True,
    )

    print(
        f"SAMPLE: {sample_name}",
        flush=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        f"Embedding directory : {sample_dir}",
        flush=True,
    )

    print(
        f"Embedding chunks    : {len(chunks)}",
        flush=True,
    )

    print(
        f"Output directory    : {output_dir}",
        flush=True,
    )

    all_binary_counts: Counter = Counter()
    all_subtype_counts: Counter = Counter()
    all_type_counts: Counter = Counter()

    total_reads = 0

    started = time.time()

    for chunk_index, chunk_path in enumerate(
        chunks,
        start=1,
    ):

        print()
        print(
            f"[{chunk_index}/{len(chunks)}] {chunk_path.name}",
            flush=True,
        )

        ids, embeddings, metadata = load_embedding_chunk(
            chunk_path,
            int(
                checkpoint[
                    "dna_input_dimension"
                ]
            ),
        )

        print(
            f"  shape            : {tuple(embeddings.shape)}",
            flush=True,
        )

        print(
            f"  pooling          : {metadata['pooling']}",
            flush=True,
        )

        print(
            f"  truncation       : {metadata['truncation']}",
            flush=True,
        )

        print(
            f"  max_token_length : {metadata['max_token_length']}",
            flush=True,
        )

        chunk_started = time.time()

        (
            arg_probability,
            subtype_probability,
            subtype_index,
        ) = infer_chunk(
            model=model,
            embeddings=embeddings,
            batch_size=batch_size,
            device=device,
            use_amp=use_amp,
        )

        if write_predictions:

            prediction_path = (
                output_dir
                / f"chunk_{chunk_index:06d}_pred.csv.gz"
            )

            print(
                f"  prediction file  : {prediction_path.name}",
                flush=True,
            )
            print(
                f"  full path length : {len(str(prediction_path))} chars",
                flush=True,
            )

            (
                binary_counts,
                subtype_counts,
                type_counts,
            ) = write_prediction_gzip(
                path=prediction_path,
                ids=ids,
                arg_probability=arg_probability,
                subtype_probability=subtype_probability,
                subtype_index=subtype_index,
                threshold=threshold,
                arg_names=arg_names,
                subtype_to_type=subtype_to_type,
            )

        else:

            (
                binary_counts,
                subtype_counts,
                type_counts,
            ) = counts_without_prediction_file(
                arg_probability=arg_probability,
                subtype_index=subtype_index,
                threshold=threshold,
                arg_names=arg_names,
                subtype_to_type=subtype_to_type,
            )

        all_binary_counts.update(
            binary_counts
        )

        all_subtype_counts.update(
            subtype_counts
        )

        all_type_counts.update(
            type_counts
        )

        total_reads += len(
            ids
        )

        elapsed = (
            time.time()
            - chunk_started
        )

        speed = (
            len(
                ids
            )
            / elapsed
            if elapsed > 0
            else 0.0
        )

        print(
            f"  predicted        : {len(ids):,}",
            flush=True,
        )

        print(
            f"  predicted ARG    : {binary_counts.get('ARG', 0):,}",
            flush=True,
        )

        print(
            f"  ARG fraction     : "
            f"{binary_counts.get('ARG', 0)/len(ids):.8f}",
            flush=True,
        )

        print(
            f"  speed            : {speed:,.1f} reads/s",
            flush=True,
        )

        del (
            ids,
            embeddings,
            arg_probability,
            subtype_probability,
            subtype_index,
        )

        torch.cuda.empty_cache()

    predicted_arg = int(
        all_binary_counts.get(
            "ARG",
            0,
        )
    )

    predicted_nonarg = int(
        all_binary_counts.get(
            NONARG,
            0,
        )
    )

    arg_fraction = (
        predicted_arg
        / total_reads
        if total_reads
        else 0.0
    )

    atomic_write_csv(
        output_dir
        / "ARG_nonARG_counts.csv",
        counter_to_rows(
            all_binary_counts,
            "Class",
        ),
    )

    atomic_write_csv(
        output_dir
        / "subtype_counts.csv",
        counter_to_rows(
            all_subtype_counts,
            "Subtype",
        ),
    )

    atomic_write_csv(
        output_dir
        / "type_counts.csv",
        counter_to_rows(
            all_type_counts,
            "Type",
        ),
    )

    summary = {
        "sample":
            sample_name,

        "script_version":
            SCRIPT_VERSION,

        "training_ARG_nonARG_ratio":
            "1:10",

        "model_path":
            str(
                checkpoint.get(
                    "_model_path_for_manifest",
                    "",
                )
            ),

        "candidate_reads":
            int(
                total_reads
            ),

        "predicted_ARG":
            predicted_arg,

        "predicted_nonARG":
            predicted_nonarg,

        "ARG_fraction":
            arg_fraction,

        "binary_ARG_threshold":
            float(
                threshold
            ),

        "ARG_subtype_count":
            len(
                arg_names
            ),

        "DNA_input_dimension":
            int(
                checkpoint[
                    "dna_input_dimension"
                ]
            ),

        "embedding_definition":
            (
                "DNABERT-2 first_token_CLS; "
                "768D expected from checkpoint"
            ),

        "write_per_read_predictions":
            bool(
                write_predictions
            ),

        "number_embedding_chunks":
            len(
                chunks
            ),

        "elapsed_minutes":
            (
                time.time()
                - started
            )
            / 60.0,
    }

    atomic_write_json(
        summary_path,
        summary,
    )

    print()
    print(
        f"{sample_name} COMPLETED | "
        f"candidate reads={total_reads:,} | "
        f"predicted ARG={predicted_arg:,} | "
        f"ARG fraction={arg_fraction:.8f}",
        flush=True,
    )

    return summary


def main() -> None:

    args = parse_args()

    root = (
        args.root
        .expanduser()
        .resolve()
    )

    model_path = (
        args.model
        .expanduser()
        .resolve()
    )

    output_root = (
        args.output_root
        .expanduser()
        .resolve()
    )

    if not root.is_dir():
        raise NotADirectoryError(
            f"Root not found: {root}"
        )

    if not model_path.is_file():
        raise FileNotFoundError(
            f"Model not found: {model_path}"
        )

    if args.batch_size < 1:
        raise ValueError(
            "--batch-size must be positive"
        )

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU is unavailable. "
            "CPU fallback is disabled for this inference script."
        )

    device = torch.device(
        "cuda:0"
    )

    use_amp = (
        not args.no_amp
    )

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    structure_path = find_structure(
        args.structure,
        root,
    )

    (
        model,
        checkpoint,
        arg_names,
        threshold,
    ) = load_model(
        model_path,
        device,
    )

    checkpoint[
        "_model_path_for_manifest"
    ] = str(
        model_path
    )

    mapping_info = build_subtype_to_type(
        structure_path,
        arg_names,
    )

    subtype_to_type = mapping_info[
        "mapping"
    ]

    print(
        "=" * 120,
        flush=True,
    )

    print(
        "ARG:nonARG=1:10 DNA STUDENT -> Diamond0.2 CANDIDATE CLS EMBEDDINGS",
        flush=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        f"Root               : {root}",
        flush=True,
    )

    print(
        f"Samples            : {len(args.samples)}",
        flush=True,
    )

    print(
        f"Model              : {model_path}",
        flush=True,
    )

    print(
        f"Structure          : {structure_path}",
        flush=True,
    )

    print(
        f"Output root        : {output_root}",
        flush=True,
    )

    print(
        f"Batch size         : {args.batch_size:,}",
        flush=True,
    )

    print(
        f"Write predictions  : {not args.no_write_predictions}",
        flush=True,
    )

    print(
        f"Device             : {device}",
        flush=True,
    )

    print(
        f"GPU                : {torch.cuda.get_device_name(0)}",
        flush=True,
    )

    print(
        f"CUDA version       : {torch.version.cuda}",
        flush=True,
    )

    print(
        f"AMP                : {use_amp}",
        flush=True,
    )

    print(
        "CPU fallback       : disabled",
        flush=True,
    )

    print()
    print(
        f"DNA input dimension: {checkpoint['dna_input_dimension']}",
        flush=True,
    )

    print(
        f"ARG subtype count  : {len(arg_names)}",
        flush=True,
    )

    print(
        f"Saved ARG threshold: {threshold:.8f}",
        flush=True,
    )

    print(
        f"Structure rows     : {mapping_info['structure_rows']:,}",
        flush=True,
    )

    print(
        f"Mapped subtype     : "
        f"{mapping_info['mapped_model_subtypes']}/{len(arg_names)}",
        flush=True,
    )

    print(
        f"Extra structure ARG: "
        f"{len(mapping_info['extra_structure_arg_subtypes'])}",
        flush=True,
    )

    all_started = time.time()

    summaries = []

    for index, sample_name in enumerate(
        args.samples,
        start=1,
    ):

        print()
        print(
            "#" * 120,
            flush=True,
        )

        print(
            f"DATASET {index}/{len(args.samples)}: {sample_name}",
            flush=True,
        )

        print(
            "#" * 120,
            flush=True,
        )

        summary = process_sample(
            sample_name=sample_name,
            root=root,
            output_root=output_root,
            model=model,
            checkpoint=checkpoint,
            arg_names=arg_names,
            subtype_to_type=subtype_to_type,
            threshold=threshold,
            batch_size=args.batch_size,
            device=device,
            use_amp=use_amp,
            write_predictions=(
                not args.no_write_predictions
            ),
            overwrite=args.overwrite,
        )

        summaries.append(
            summary
        )

    overall_rows = [
        {
            "dataset":
                item[
                    "sample"
                ],

            "candidate_reads":
                item[
                    "candidate_reads"
                ],

            "predicted_ARG":
                item[
                    "predicted_ARG"
                ],

            "predicted_nonARG":
                item[
                    "predicted_nonARG"
                ],

            "ARG_fraction":
                item[
                    "ARG_fraction"
                ],

            "binary_ARG_threshold":
                item[
                    "binary_ARG_threshold"
                ],

            "ARG_subtype_count":
                item[
                    "ARG_subtype_count"
                ],
        }
        for item
        in summaries
    ]

    overall_csv = (
        output_root
        / "overall_summary.csv"
    )

    overall_json = (
        output_root
        / "overall_summary.json"
    )

    atomic_write_csv(
        overall_csv,
        overall_rows,
    )

    atomic_write_json(
        overall_json,
        {
            "script_version":
                SCRIPT_VERSION,

            "training_ARG_nonARG_ratio":
                "1:10",

            "model":
                str(
                    model_path
                ),

            "structure":
                str(
                    structure_path
                ),

            "saved_binary_ARG_threshold":
                threshold,

            "ARG_subtype_count":
                len(
                    arg_names
                ),

            "samples":
                summaries,

            "elapsed_minutes":
                (
                    time.time()
                    - all_started
                )
                / 60.0,

            "peak_GPU_memory_GiB":
                torch.cuda.max_memory_allocated(
                    0
                )
                / (
                    1024 ** 3
                ),
        },
    )

    print()
    print(
        "=" * 120,
        flush=True,
    )

    print(
        "ALL Diamond0.2 DATASETS COMPLETED",
        flush=True,
    )

    print(
        "=" * 120,
        flush=True,
    )

    print(
        f"Overall summary : {overall_csv}",
        flush=True,
    )

    print(
        f"Peak GPU memory : "
        f"{torch.cuda.max_memory_allocated(0)/(1024**3):.3f} GiB",
        flush=True,
    )


if __name__ == "__main__":
    main()
