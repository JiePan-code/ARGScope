@echo off
setlocal
set "ARGSCOPEDRAWPY=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%ARGSCOPEDRAWPY%" (
  echo Python was not found. Edit ARGSCOPEDRAWPY in this launcher.
  pause
  exit /b 1
)
"%ARGSCOPEDRAWPY%" -X utf8 -B -u "%~dp0plot_three_figures.py"
if errorlevel 1 (
  echo Rendering failed. See the message above.
  pause
  exit /b 1
)
echo Done. See render_status.json for the latest output folder.
pause
