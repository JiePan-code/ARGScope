"""Validate the repaired formal run; never train or change predictions."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import torch

TRANSFER_FIELDS = (
    "student_binary_kd", "student_subtype_kd", "student_feature_align",
    "student_prototype_align", "student_head_anchor",
)


def check(condition, message):
    if not condition:
        raise ValueError(message)


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def validate(data_root):
    result_root = data_root / "消融实验结果"
    output = result_root / "DNA_student_subtype2_newsplit_wo_transfer_fixed"
    status = json.loads((output / "run_status.json").read_text(encoding="utf-8"))
    check(status["phase"] == "completed", f"Run has not completed: {status}")
    checkpoint = torch.load(output / "DNA_student_long_model.pt", map_location="cpu", weights_only=False)
    config = checkpoint["configuration"]
    check(checkpoint["ablation"]["label"] == "w/o Knowledge Transfer", "Wrong ablation")
    check(checkpoint["teacher_best_epoch"] == 0, "Teacher was optimized")
    check(config["student_epochs"] == 300, "Not the formal 300-epoch run")
    for field in TRANSFER_FIELDS:
        check(config[field] == 0.0, f"Transfer coefficient is not zero: {field}")

    full_path = result_root / "DNA_student_subtype2_newsplit_unified" / "DNA_student_long_model.pt"
    full = torch.load(full_path, map_location="cpu", weights_only=False)
    full_config = full["configuration"]
    differences = {
        k: [full_config.get(k), config.get(k)]
        for k in full_config.keys() | config.keys()
        if k not in TRANSFER_FIELDS and full_config.get(k) != config.get(k)
    }
    check(not differences, f"Other configuration changed relative to Full: {differences}")
    threshold_key = "selected_binary_ARG_probability_threshold"
    check(checkpoint[threshold_key] == full[threshold_key] == 0.8, "Binary threshold mismatch")
    check(checkpoint["arg_subtype_names"] == full["arg_subtype_names"], "Subtype order differs from Full")

    history = read_csv(output / "student_training_history.csv")
    check([int(row["epoch"]) for row in history] == list(range(1, 301)), "Incomplete epoch history")
    errors = [
        abs(float(row["loss"]) - config["student_binary_ce"] * float(row["binary_loss"])
            - config["student_subtype_ce"] * float(row["subtype_loss"]))
        for row in history
    ]
    check(max(errors) < 1e-5, "Loss differs from supervised binary/subtype CE sum")

    predictions = read_csv(output / "test_sequence_predictions.csv")
    ids = [row["sequence_id"] for row in predictions]
    expected = {
        line.strip() for line in (data_root / "test_ids_subtype2.txt")
        .read_text(encoding="utf-8-sig").splitlines() if line.strip()
    }
    check(len(ids) == len(set(ids)) == len(expected) and set(ids) == expected,
          "Test ID mismatch or duplicate rows")
    full_predictions = read_csv(result_root / "DNA_student_subtype2_newsplit_unified" / "test_sequence_predictions.csv")
    full_truth = {row["sequence_id"]: (row["true_subtype"], row["true_type"], row["true_ARG"])
                  for row in full_predictions}
    check(all((row["true_subtype"], row["true_type"], row["true_ARG"]) == full_truth[row["sequence_id"]]
              for row in predictions), "Ground-truth labels differ from Full")

    for name in ("model_train_ids.txt", "validation_ids.txt", "test_ids.txt"):
        actual = set((output / name).read_text(encoding="utf-8-sig").splitlines())
        baseline = set((full_path.parent / name).read_text(encoding="utf-8-sig").splitlines())
        check(actual == baseline, f"Split differs from Full: {name}")
    for name in ("test_metrics.csv", "test_type_level_metrics.csv",
                 "test_subtype_level_metrics.csv", "test_ARG_nonARG_level_metrics.csv"):
        path = output / name
        check(path.is_file() and path.stat().st_size > 0, f"Missing result: {name}")
    report = {
        "status": "PASS", "output_dir": str(output), "epochs_completed": len(history),
        "student_best_epoch": checkpoint["student_best_epoch"], "teacher_best_epoch": 0,
        "transfer_coefficients": {field: config[field] for field in TRANSFER_FIELDS},
        "other_configuration_matches_full": True, "binary_threshold": checkpoint[threshold_key],
        "splits_and_truth_match_full": True, "test_records": len(ids),
        "max_supervised_loss_sum_error": max(errors),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--report", type=Path, default=None)
    args = parser.parse_args()
    report = validate(args.data_root.resolve())
    if args.report is not None:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
