# -*- coding: utf-8 -*-
"""
Summarize ARGScope DIAMOND0.7 results across different Gate thresholds.

Expected directory structure:

Diamon结果/
└── 4.Diamon/
    ├── ARGScope_DIAMOND_gate010_realdata_predictions/
    │   └── diamond0.7/
    │       └── all_samples_ARG_predictions.csv
    ├── ARGScope_DIAMOND_gate020_realdata_predictions/
    │   └── diamond0.7/
    │       └── all_samples_ARG_predictions.csv
    ├── ARGScope_DIAMOND_gate030_realdata_predictions/
    │   └── diamond0.7/
    │       └── all_samples_ARG_predictions.csv
    ├── ARGScope_DIAMOND_gate040_realdata_predictions/
    │   └── diamond0.7/
    │       └── all_samples_ARG_predictions.csv
    └── ARGScope_DIAMOND_gate050_realdata_predictions/
        └── diamond0.7/
            └── all_samples_ARG_predictions.csv

Output:
    4.Diamon/DIAMOND0.7_different_gate_ARG_count_summary.csv

Table format:
    sample_name, Gate0.1, Gate0.2, Gate0.3, Gate0.4, Gate0.5

Counting rule:
    - Keep only Pred_ARG == ARG, if Pred_ARG column exists
    - Verify gate_threshold when available
    - Verify diamond_threshold == diamond0.7 when available
    - Count UNIQUE read_id, not raw rows
"""

from __future__ import annotations

from pathlib import Path
import re
import numpy as np
import pandas as pd


# =============================================================================
# 1. PATH
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# Script may be placed:
# A) directly in 4.Diamon/
# B) in its parent Diamon结果/
if SCRIPT_DIR.name.lower() == "4.diamon":
    DIAMOND_ROOT = SCRIPT_DIR
elif (SCRIPT_DIR / "4.Diamon").is_dir():
    DIAMOND_ROOT = SCRIPT_DIR / "4.Diamon"
else:
    DIAMOND_ROOT = SCRIPT_DIR


# =============================================================================
# 2. SETTINGS
# =============================================================================

TARGET_DIAMOND = "diamond0.7"

GATE_CONFIG = {
    "Gate0.1": {
        "folder": "ARGScope_DIAMOND_gate010_realdata_predictions",
        "value": 0.10,
    },
    "Gate0.2": {
        "folder": "ARGScope_DIAMOND_gate020_realdata_predictions",
        "value": 0.20,
    },
    "Gate0.3": {
        "folder": "ARGScope_DIAMOND_gate030_realdata_predictions",
        "value": 0.30,
    },
    "Gate0.4": {
        "folder": "ARGScope_DIAMOND_gate040_realdata_predictions",
        "value": 0.40,
    },
    "Gate0.5": {
        "folder": "ARGScope_DIAMOND_gate050_realdata_predictions",
        "value": 0.50,
    },
}

OUTPUT_FILE = DIAMOND_ROOT / "DIAMOND0.7_different_gate_ARG_count_summary.csv"
LONG_OUTPUT_FILE = DIAMOND_ROOT / "DIAMOND0.7_different_gate_ARG_count_summary_long.csv"


# =============================================================================
# 3. HELPERS
# =============================================================================

def normalize_sample_name(x: str) -> str:
    x = str(x).strip()

    # Optional cleanup if sample names contain the embedding-folder suffix
    x = re.sub(r"_1_kneaddata$", "", x, flags=re.IGNORECASE)

    return x


def load_one_gate(label: str, folder: str, expected_gate: float) -> pd.DataFrame:
    csv_file = (
        DIAMOND_ROOT
        / folder
        / TARGET_DIAMOND
        / "all_samples_ARG_predictions.csv"
    )

    if not csv_file.exists():
        raise FileNotFoundError(
            f"\n[{label}] Input file not found:\n{csv_file}\n"
        )

    print("=" * 100)
    print(f"{label}")
    print(f"Input: {csv_file}")

    df = pd.read_csv(
        csv_file,
        encoding="utf-8-sig",
        low_memory=False,
    )

    required = ["sample_name", "read_id"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"[{label}] Missing required columns: {missing}\n"
            f"Available columns: {df.columns.tolist()}"
        )

    mask = pd.Series(True, index=df.index)

    # Only predicted ARG reads
    if "Pred_ARG" in df.columns:
        pred = df["Pred_ARG"].astype(str).str.strip().str.upper()
        mask &= pred.eq("ARG")

    # Check actual gate threshold
    if "gate_threshold" in df.columns:
        gate_values = pd.to_numeric(
            df["gate_threshold"],
            errors="coerce",
        )

        observed = sorted(gate_values.dropna().unique().tolist())
        print(f"Observed gate_threshold: {observed}")

        gate_mask = np.isclose(
            gate_values.to_numpy(dtype=float),
            expected_gate,
            rtol=0.0,
            atol=1e-10,
            equal_nan=False,
        )

        if not gate_mask.any():
            raise RuntimeError(
                f"[{label}] Expected gate_threshold={expected_gate}, "
                f"but no matching rows were found.\n"
                f"Observed values: {observed}"
            )

        mask &= gate_mask

    # Check actual DIAMOND threshold if this column exists
    if "diamond_threshold" in df.columns:
        diamond_text = (
            df["diamond_threshold"]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        observed_diamond = sorted(
            diamond_text.dropna().unique().tolist()
        )
        print(f"Observed diamond_threshold: {observed_diamond}")

        diamond_mask = diamond_text.eq(TARGET_DIAMOND.lower())

        if not diamond_mask.any():
            raise RuntimeError(
                f"[{label}] Expected diamond_threshold={TARGET_DIAMOND}, "
                f"but no matching rows were found.\n"
                f"Observed values: {observed_diamond}"
            )

        mask &= diamond_mask

    sub = df.loc[mask, ["sample_name", "read_id"]].copy()

    sub["sample_name"] = sub["sample_name"].map(normalize_sample_name)
    sub["read_id"] = sub["read_id"].astype(str).str.strip()

    sub = sub[
        sub["read_id"].ne("")
        & sub["read_id"].ne("nan")
        & sub["read_id"].ne("None")
    ]

    # Unique read-level ARG count
    counts = (
        sub.drop_duplicates(["sample_name", "read_id"])
        .groupby("sample_name")["read_id"]
        .nunique()
        .rename(label)
        .reset_index()
    )

    print(f"ARG-positive unique reads: {counts[label].sum():,}")
    print(f"Samples: {len(counts)}")

    return counts


# =============================================================================
# 4. MAIN
# =============================================================================

def main():
    print("=" * 100)
    print("ARGScope DIAMOND0.7 - different Gate thresholds summary")
    print("=" * 100)
    print(f"DIAMOND_ROOT : {DIAMOND_ROOT}")
    print(f"Target       : {TARGET_DIAMOND}")
    print("=" * 100)

    merged = None
    long_tables = []

    for label, cfg in GATE_CONFIG.items():
        counts = load_one_gate(
            label=label,
            folder=cfg["folder"],
            expected_gate=cfg["value"],
        )

        temp_long = counts.copy()
        temp_long["gate"] = label
        temp_long["gate_threshold"] = cfg["value"]
        temp_long = temp_long.rename(columns={label: "ARG_count"})
        long_tables.append(temp_long)

        if merged is None:
            merged = counts
        else:
            merged = merged.merge(
                counts,
                on="sample_name",
                how="outer",
            )

    if merged is None:
        raise RuntimeError("No data loaded.")

    gate_cols = list(GATE_CONFIG.keys())

    merged[gate_cols] = (
        merged[gate_cols]
        .fillna(0)
        .astype(int)
    )

    # Preferred biological/sample order
    preferred_order = [
        "argbert_1",
        "argbert_2",
        "argbert_3",
        "argscope_1",
        "argscope_2",
        "argscope_3",
        "argscope_4",
        "argscope_5",
        "argscope_6",
    ]

    order_map = {name: i for i, name in enumerate(preferred_order)}

    merged["_order"] = merged["sample_name"].map(
        lambda x: order_map.get(str(x).lower(), 999)
    )
    merged = (
        merged.sort_values(["_order", "sample_name"])
        .drop(columns="_order")
        .reset_index(drop=True)
    )

    # Add total row
    total_row = {"sample_name": "TOTAL"}
    for col in gate_cols:
        total_row[col] = int(merged[col].sum())

    summary_with_total = pd.concat(
        [merged, pd.DataFrame([total_row])],
        ignore_index=True,
    )

    summary_with_total.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    long_df = pd.concat(
        long_tables,
        ignore_index=True,
    )

    long_df["sample_name"] = long_df["sample_name"].astype(str)

    long_df.to_csv(
        LONG_OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 100)
    print("FINAL SUMMARY")
    print("=" * 100)
    print(summary_with_total.to_string(index=False))
    print()
    print(f"Wide table : {OUTPUT_FILE}")
    print(f"Long table : {LONG_OUTPUT_FILE}")
    print("=" * 100)


if __name__ == "__main__":
    main()
