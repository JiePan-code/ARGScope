"""Small launch helpers for the new-split ablations.

The full scripts remain untouched.  These launchers only replace an explicitly
named information path and choose separate output locations.
"""
from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path


SCRIPT_ROOT = Path(__file__).resolve().parent


def _first_existing(candidates: tuple[Path, ...], label: str) -> Path:
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    checked = "\n  ".join(str(path) for path in candidates)
    raise FileNotFoundError(f"Could not locate {label}. Checked:\n  {checked}")


def data_root_from_launcher(launcher: str | Path) -> Path:
    """Locate the folder containing new-split ID files and embeddings."""
    path = Path(launcher).resolve()
    candidates = []
    configured = os.environ.get("ARGSCOPE_DATA_ROOT", "").strip()
    if configured:
        candidates.append(Path(configured).expanduser().resolve())
    candidates.extend(
        (
            SCRIPT_ROOT.parent,
            path.parents[2],
            path.parents[3],
        )
    )
    unique_candidates = []
    for candidate in candidates:
        if candidate not in unique_candidates:
            unique_candidates.append(candidate)
    for candidate in unique_candidates:
        if (candidate / "train_ids_subtype2.txt").is_file() and (
            candidate / "test_ids_subtype2.txt"
        ).is_file():
            return candidate
    checked = "\n  ".join(str(candidate) for candidate in unique_candidates)
    raise FileNotFoundError(
        "Could not locate the data root from this launcher. Checked:\n  " + checked
    )


def base_script_root(filename: str) -> Path:
    """Support both an in-place install and a separately extracted archive."""
    candidates = (
        SCRIPT_ROOT,
        SCRIPT_ROOT / "argscope_subtype2_newsplit",
        SCRIPT_ROOT / "ARGScope_subtype2_newsplit",
        SCRIPT_ROOT.parent / "argscope_subtype2_newsplit",
        SCRIPT_ROOT.parent / "ARGScope_subtype2_newsplit",
    )
    for candidate in candidates:
        if (candidate / filename).is_file():
            return candidate
    checked = "\n  ".join(str(path / filename) for path in candidates)
    raise FileNotFoundError(
        f"Could not find the Full base script {filename}. Checked:\n  {checked}"
    )


def load_base(filename: str, module_name: str):
    """Load one full-pipeline script without executing its main block."""
    root = base_script_root(filename)
    sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location(module_name, root / filename)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load base script: {filename}")
    module = importlib.util.module_from_spec(spec)
    # dataclasses resolves postponed annotations through sys.modules during
    # class creation, so registration must precede exec_module.
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def add_default_structure(data_root: Path) -> None:
    """Make right-click execution work while retaining CLI override support."""
    if "--structure" not in sys.argv:
        sys.argv.extend(["--structure", str(data_root / "all_ARG_nonARG_1to1_structure.txt")])


def selected_protein_csv(data_root: Path) -> Path:
    """Prefer the normal Protein GRID-best CSV; support the user's local layout."""
    candidates = (
        data_root.parent / "2.Protein_student_long_gridsearch" / "best_parameters_and_test_results.csv",
        data_root / "2.Protein_student_long_gridsearch" / "best_parameters_and_test_results.csv",
        data_root.parent / "1.DNA_student_long_gridsearch" / "best_parameters_and_test_results.csv",
    )
    return _first_existing(candidates, "Protein GRID-best parameter CSV")


def protein_embedding_pt(data_root: Path) -> Path:
    return _first_existing(
        (
            data_root / "ESM2_EMBEDDING" / "percent_100" / "full_1to1_esm2_mean.pt",
            data_root / "ESM2_full_1to1" / "full_1to1_esm2_mean.pt",
        ),
        "full-length ESM-2 embedding PT",
    )


def dna_embedding_pt(data_root: Path) -> Path:
    return _first_existing(
        (
            data_root / "DNABERT2_embedding" / "percent_100" / "full_1to1_dnabert2_mean.pt",
            data_root / "DNABERT2_full_1to1" / "full_1to1_dnabert2_mean.pt",
        ),
        "full-length DNABERT-2 embedding PT",
    )


def set_fusion_defaults(module, data_root: Path, output_dir: str, output_name: str) -> None:
    module.ROOT = data_root
    module.DATA = data_root
    module.DEFAULT_PROTEIN_PT = protein_embedding_pt(data_root)
    module.DEFAULT_DNA_PT = dna_embedding_pt(data_root)
    module.DEFAULT_TRAIN_IDS = data_root / "train_ids_subtype2.txt"
    module.DEFAULT_TEST_IDS = data_root / "test_ids_subtype2.txt"
    module.DEFAULT_OUTPUT_PT = data_root / output_dir / output_name


def reject_overwrite_argument() -> None:
    """Right-click launchers never recursively replace an existing result."""
    if "--overwrite" in sys.argv:
        raise RuntimeError(
            "For safety, these local launchers do not accept --overwrite. "
            "Move or rename the existing result directory/file, then run again."
        )


def guard_student_recursive_delete(module, data_root: Path, output_prefix: str) -> None:
    """Confine any explicitly requested recursive deletion to one result folder."""
    original_rmtree = module.shutil.rmtree
    root = data_root.resolve()

    def guarded_rmtree(path, *args, **kwargs):
        target = Path(path).resolve()
        if target.parent != root or not target.name.startswith(output_prefix):
            raise RuntimeError(
                "Blocked unsafe recursive deletion. "
                f"Target={target}; allowed parent={root}; prefix={output_prefix}"
            )
        return original_rmtree(path, *args, **kwargs)

    module.shutil.rmtree = guarded_rmtree


def set_common_student_defaults(module, data_root: Path, modality: str, output_name: str) -> None:
    module.ROOT = data_root
    module.DEFAULT_FUSION_PT = data_root / "Long_fusion_subtype2_newsplit" / "long_fusion_subtype2_newsplit.pt"
    module.DEFAULT_REFINED_PT = data_root / "Refined_subtype_prototypes_subtype2_newsplit" / "refined_ARG_subtype_prototypes_residual_GAT.pt"
    module.DEFAULT_TRAIN_IDS = data_root / "train_ids_subtype2.txt"
    module.DEFAULT_TEST_IDS = data_root / "test_ids_subtype2.txt"
    module.DEFAULT_OUTPUT_DIR = data_root / output_name
    if modality == "protein":
        module.DEFAULT_PROTEIN_PT = protein_embedding_pt(data_root)
        module.DEFAULT_BEST_PARAMS = selected_protein_csv(data_root)
        module.DEFAULT_TEACHER_CHECKPOINT = (
            data_root.parent
            / "2.Protein_student_long_gridsearch"
            / "best_fusion_teacher.pt"
        )
    else:
        module.DEFAULT_DNA_PT = dna_embedding_pt(data_root)


def raw_as_refined(module, raw_path: Path):
    """Use raw centroids at every former refined-prototype attachment point."""
    raw_path = raw_path.resolve()
    original_load = module.load_pt
    original_validate = module.contract.validate_derived

    def load_pt(path):
        obj = original_load(path)
        if Path(path).resolve() != raw_path:
            return obj
        if "raw_arg_subtype_prototypes" not in obj:
            raise KeyError("w/o Graph requires the new raw-prototype PT")
        adapted = dict(obj)
        adapted["refined_arg_subtype_prototypes"] = obj["raw_arg_subtype_prototypes"]
        return adapted

    def validate(obj, fused, fusion_path, kind):
        if kind == "refined" and obj.get("artifact_kind") == "raw":
            return original_validate(obj, fused, fusion_path, "raw")
        return original_validate(obj, fused, fusion_path, kind)

    module.load_pt = load_pt
    module.contract.validate_derived = validate


def mark_saved_ablation(module, label: str, removed: str) -> None:
    save_name = "safe_save" if hasattr(module, "safe_save") else "save_checkpoint"
    if not hasattr(module, save_name):
        raise AttributeError(f"{module.__name__} has no supported checkpoint writer")
    original_save = getattr(module, save_name)

    def safe_save(obj, path):
        if isinstance(obj, dict):
            obj.setdefault("ablation", {"label": label, "removed_information_path": removed})
        return original_save(obj, path)

    setattr(module, save_name, safe_save)


def disable_learned_transfer(module) -> None:
    """Keep the Student architecture but remove every learned-Teacher loss path.

    A temporary random head only supplies the normal random Student head
    initialization required by the unmodified Student routine.  It is never
    optimized and every term that could transmit its outputs/geometry has a
    coefficient of zero.
    """
    original_student = module.train_student

    def untrained_teacher(data, config, use_amp, hb, progress_dir=None):
        # DNA passes progress_dir for Teacher training logs; Protein omits it.
        # This ablation does not train a Teacher, so no progress is written here.
        teacher = module.FusionTeacher(data["refined_gpu"], config).cuda()
        with module.torch.no_grad():
            module.nn.init.xavier_uniform_(teacher.binary_head.weight)
            module.nn.init.xavier_uniform_(teacher.arg_head.weight)
        print("Knowledge transfer disabled: Teacher is untrained and random.", flush=True)
        return teacher, [], 0, float("nan")

    def supervised_student(teacher, data, config, use_amp, hb, snapshot_epochs, snapshot_dir):
        for field in (
            "student_binary_kd",
            "student_subtype_kd",
            "student_feature_align",
            "student_prototype_align",
            "student_head_anchor",
        ):
            setattr(config, field, 0.0)
        print("Student objective: binary CE + subtype CE only.", flush=True)
        return original_student(teacher, data, config, use_amp, hb, snapshot_epochs, snapshot_dir)

    module.train_teacher = untrained_teacher
    module.train_student = supervised_student
