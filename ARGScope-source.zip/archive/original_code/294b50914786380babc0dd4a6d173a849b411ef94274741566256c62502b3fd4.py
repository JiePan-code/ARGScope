#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build train-only raw ARG subtype prototypes and nearest-prototype baselines.

Input is the single PT produced by ``train_supervised_gated_fusion_50aa_150nt.py``.

Method:
  1. Average the five fused fragment embeddings within each Original_ID.
  2. L2-normalize every original-sequence mean embedding.
  3. Use only ``model_splits == 'train'`` ARG originals.
  4. Average train-original embeddings within each ARG Subtype and L2-normalize.
  5. Evaluate cosine nearest-prototype classification on validation/test.

The main short-read result is fragment-level. Original-level results are also
reported as a diagnostic. ``nonARG`` is excluded from the ARG subtype graph and
baseline, but its train-only reference centroid is stored separately.

Exactly one final PT is written. No CSV, JSON, plot, or checkpoint is created.
"""

from __future__ import annotations

import argparse
import math
import os
import statistics
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT_PT = (
    SCRIPT_DIR
    / "Gated_fusion_50aa_150nt_supervised"
    / "all_50aa_150nt_supervised_gated_fused_embeddings.pt"
)
DEFAULT_OUTPUT_PT = (
    SCRIPT_DIR
    / "Raw_subtype_prototypes_50aa_150nt"
    / "raw_ARG_subtype_prototypes_and_baseline.pt"
)
SCRIPT_VERSION = "2026-08-17-raw-ARG-subtype-prototype-baseline-v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build train-only raw ARG subtype prototypes and baselines."
    )
    parser.add_argument("--input-pt", type=Path, default=DEFAULT_INPUT_PT)
    parser.add_argument("--output-pt", type=Path, default=DEFAULT_OUTPUT_PT)
    parser.add_argument("--batch-size", type=int, default=8192)
    parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda"],
        default="auto",
        help="Device used only for cosine classification.",
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def torch_load_cpu(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def canonical_id(value: object) -> str:
    text = str(value).strip()
    return text.split()[0] if text else ""


def is_nonarg(value: object) -> bool:
    compact = "".join(character for character in str(value).lower() if character.isalnum())
    return compact in {"nonarg", "nonresistance", "negative", "nonresistant"}


def choose_device(requested: str) -> torch.device:
    if requested == "cpu":
        return torch.device("cpu")
    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("--device cuda was requested, but CUDA is unavailable")
        return torch.device("cuda:0")
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def load_and_validate_input(path: Path):
    obj = torch_load_cpu(path)
    required = {
        "ids",
        "original_ids",
        "embeddings",
        "splits",
        "model_splits",
        "subtypes",
    }
    if not isinstance(obj, dict):
        raise TypeError(f"Input PT must contain a dictionary: {path}")
    missing = sorted(required - set(obj))
    if missing:
        raise KeyError(f"Input PT is missing keys: {missing}")

    ids = [canonical_id(value) for value in obj["ids"]]
    original_ids = [canonical_id(value) for value in obj["original_ids"]]
    subtypes = [str(value).strip() for value in obj["subtypes"]]
    external_splits = [str(value).strip().lower() for value in obj["splits"]]
    model_splits = [str(value).strip().lower() for value in obj["model_splits"]]
    embeddings = obj["embeddings"]

    number = len(ids)
    named_lists = {
        "original_ids": original_ids,
        "subtypes": subtypes,
        "splits": external_splits,
        "model_splits": model_splits,
    }
    for name, values in named_lists.items():
        if len(values) != number:
            raise ValueError(f"Length mismatch: ids={number}, {name}={len(values)}")
    if any(not value for value in ids + original_ids + subtypes):
        raise ValueError("Empty ID, Original_ID, or Subtype detected")
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate fragment IDs detected in input PT")
    if set(external_splits) - {"train", "test"}:
        raise ValueError(f"Invalid external splits: {sorted(set(external_splits))}")
    if set(model_splits) - {"train", "validation", "test"}:
        raise ValueError(f"Invalid model splits: {sorted(set(model_splits))}")
    if not isinstance(embeddings, torch.Tensor) or embeddings.ndim != 2:
        raise ValueError("Input embeddings must be a 2D torch.Tensor")
    if embeddings.shape[0] != number:
        raise ValueError(
            f"Embedding row mismatch: rows={embeddings.shape[0]}, IDs={number}"
        )
    embeddings = embeddings.detach().cpu().float().contiguous()
    if not bool(torch.isfinite(embeddings).all()):
        raise ValueError("Non-finite fused embeddings detected")

    # Validate that every original has one label and one split assignment.
    original_metadata: dict[str, tuple[str, str, str]] = {}
    for original_id, subtype, external_split, model_split in zip(
        original_ids, subtypes, external_splits, model_splits
    ):
        current = (subtype, external_split, model_split)
        previous = original_metadata.setdefault(original_id, current)
        if previous != current:
            raise ValueError(
                f"Inconsistent metadata within Original_ID={original_id}: "
                f"{previous} vs {current}"
            )

    if "nonARG" not in set(subtypes) and not any(is_nonarg(x) for x in subtypes):
        raise ValueError("Cannot identify the nonARG class")
    print(f"Input fragments        : {number:,}", flush=True)
    print(f"Input originals        : {len(original_metadata):,}", flush=True)
    print(f"Input embedding shape  : {tuple(embeddings.shape)}", flush=True)
    print(f"Input Subtypes         : {len(set(subtypes)):,}", flush=True)
    return (
        obj,
        ids,
        original_ids,
        subtypes,
        external_splits,
        model_splits,
        embeddings,
    )


def aggregate_original_embeddings(
    original_ids: list[str],
    subtypes: list[str],
    external_splits: list[str],
    model_splits: list[str],
    embeddings: torch.Tensor,
):
    ordered_originals: list[str] = []
    original_to_index: dict[str, int] = {}
    for original_id in original_ids:
        if original_id not in original_to_index:
            original_to_index[original_id] = len(ordered_originals)
            ordered_originals.append(original_id)

    inverse = torch.tensor(
        [original_to_index[value] for value in original_ids], dtype=torch.long
    )
    number_originals = len(ordered_originals)
    sums = torch.zeros(
        (number_originals, embeddings.shape[1]), dtype=torch.float32
    )
    sums.index_add_(0, inverse, embeddings)
    counts = torch.bincount(inverse, minlength=number_originals)
    if bool((counts == 0).any()):
        raise RuntimeError("Internal error: an original has no fragment")
    means = sums / counts.to(torch.float32).unsqueeze(1)
    norms = torch.linalg.vector_norm(means, dim=1)
    if bool((norms <= 1e-12).any()):
        bad = torch.where(norms <= 1e-12)[0][:10].tolist()
        raise ValueError(f"Zero original-mean embeddings detected: rows={bad}")
    normalized_means = F.normalize(means, p=2, dim=1)

    original_subtypes = [""] * number_originals
    original_external_splits = [""] * number_originals
    original_model_splits = [""] * number_originals
    for original_id, subtype, external_split, model_split in zip(
        original_ids, subtypes, external_splits, model_splits
    ):
        index = original_to_index[original_id]
        if original_subtypes[index] and original_subtypes[index] != subtype:
            raise ValueError(f"Subtype mismatch within original: {original_id}")
        if (
            original_external_splits[index]
            and original_external_splits[index] != external_split
        ):
            raise ValueError(f"External split mismatch within original: {original_id}")
        if original_model_splits[index] and original_model_splits[index] != model_split:
            raise ValueError(f"Model split mismatch within original: {original_id}")
        original_subtypes[index] = subtype
        original_external_splits[index] = external_split
        original_model_splits[index] = model_split

    count_distribution = Counter(counts.tolist())
    print(f"Fragments/original      : {dict(sorted(count_distribution.items()))}", flush=True)
    return {
        "ids": ordered_originals,
        "embeddings": normalized_means.contiguous(),
        "fragment_counts": counts,
        "subtypes": original_subtypes,
        "external_splits": original_external_splits,
        "model_splits": original_model_splits,
        "fragment_to_original_index": inverse,
    }


def ordered_arg_subtypes(input_obj: dict, observed_subtypes: list[str]) -> list[str]:
    label_map = input_obj.get("subtype_to_index")
    if isinstance(label_map, dict):
        ordered = [
            str(label)
            for label, _ in sorted(label_map.items(), key=lambda item: int(item[1]))
            if not is_nonarg(label)
        ]
    else:
        ordered = sorted({label for label in observed_subtypes if not is_nonarg(label)})
    observed_arg = {label for label in observed_subtypes if not is_nonarg(label)}
    if set(ordered) != observed_arg:
        missing = sorted(observed_arg - set(ordered))
        extra = sorted(set(ordered) - observed_arg)
        raise ValueError(
            f"ARG subtype label-map mismatch: missing={missing[:10]}, extra={extra[:10]}"
        )
    return ordered


def build_train_only_prototypes(
    input_obj: dict,
    original_data: dict,
    fragment_subtypes: list[str],
    fragment_model_splits: list[str],
):
    arg_subtypes = ordered_arg_subtypes(input_obj, original_data["subtypes"])
    subtype_to_index = {label: index for index, label in enumerate(arg_subtypes)}
    number_subtypes = len(arg_subtypes)
    embedding_dim = original_data["embeddings"].shape[1]

    train_original_indices = [
        index
        for index, (subtype, split) in enumerate(
            zip(original_data["subtypes"], original_data["model_splits"])
        )
        if split == "train" and not is_nonarg(subtype)
    ]
    if not train_original_indices:
        raise ValueError("No ARG train originals available for prototypes")
    train_features = original_data["embeddings"].index_select(
        0, torch.tensor(train_original_indices, dtype=torch.long)
    )
    train_targets = torch.tensor(
        [subtype_to_index[original_data["subtypes"][i]] for i in train_original_indices],
        dtype=torch.long,
    )
    sums = torch.zeros((number_subtypes, embedding_dim), dtype=torch.float32)
    sums.index_add_(0, train_targets, train_features)
    original_counts = torch.bincount(train_targets, minlength=number_subtypes)
    if bool((original_counts == 0).any()):
        missing_indices = torch.where(original_counts == 0)[0].tolist()
        missing_labels = [arg_subtypes[index] for index in missing_indices]
        raise ValueError(f"ARG Subtypes missing from train: {missing_labels[:20]}")
    prototypes = sums / original_counts.to(torch.float32).unsqueeze(1)
    prototypes = F.normalize(prototypes, p=2, dim=1).contiguous()

    fragment_counts = torch.zeros(number_subtypes, dtype=torch.long)
    for subtype, split in zip(fragment_subtypes, fragment_model_splits):
        if split == "train" and not is_nonarg(subtype):
            fragment_counts[subtype_to_index[subtype]] += 1

    nonarg_train_indices = [
        index
        for index, (subtype, split) in enumerate(
            zip(original_data["subtypes"], original_data["model_splits"])
        )
        if split == "train" and is_nonarg(subtype)
    ]
    if not nonarg_train_indices:
        raise ValueError("No nonARG train originals available")
    nonarg_features = original_data["embeddings"].index_select(
        0, torch.tensor(nonarg_train_indices, dtype=torch.long)
    )
    nonarg_centroid = F.normalize(
        nonarg_features.mean(dim=0, keepdim=True), p=2, dim=1
    )[0].contiguous()

    print(f"ARG raw prototypes      : {tuple(prototypes.shape)}", flush=True)
    print(
        f"Train originals/Subtype : min={original_counts.min().item()}, "
        f"median={statistics.median(original_counts.tolist())}, "
        f"max={original_counts.max().item()}",
        flush=True,
    )
    print(f"nonARG train originals  : {len(nonarg_train_indices):,}", flush=True)
    return {
        "arg_subtype_names": arg_subtypes,
        "arg_subtype_to_index": subtype_to_index,
        "raw_arg_subtype_prototypes": prototypes,
        "prototype_train_original_counts": original_counts,
        "prototype_train_fragment_counts": fragment_counts,
        "nonarg_reference_centroid": nonarg_centroid,
        "nonarg_train_original_count": len(nonarg_train_indices),
    }


def compute_metrics(
    true_indices: torch.Tensor,
    predicted_indices: torch.Tensor,
    number_classes: int,
    top5_correct: torch.Tensor,
    maximum_similarities: torch.Tensor,
    subtype_names: list[str],
):
    true_np = true_indices.numpy().astype(np.int64, copy=False)
    predicted_np = predicted_indices.numpy().astype(np.int64, copy=False)
    confusion = np.zeros((number_classes, number_classes), dtype=np.int64)
    np.add.at(confusion, (true_np, predicted_np), 1)
    tp = np.diag(confusion).astype(np.float64)
    support = confusion.sum(axis=1).astype(np.float64)
    predicted_count = confusion.sum(axis=0).astype(np.float64)
    precision = np.divide(
        tp, predicted_count, out=np.zeros_like(tp), where=predicted_count != 0
    )
    recall = np.divide(tp, support, out=np.zeros_like(tp), where=support != 0)
    f1 = np.divide(
        2.0 * precision * recall,
        precision + recall,
        out=np.zeros_like(tp),
        where=(precision + recall) != 0,
    )
    total = float(confusion.sum())
    active = support > 0
    sample_weights = support / total if total else np.zeros_like(support)

    correct = float(np.trace(confusion))
    predicted_marginal = confusion.sum(axis=0).astype(np.float64)
    true_marginal = confusion.sum(axis=1).astype(np.float64)
    numerator = correct * total - float(np.dot(predicted_marginal, true_marginal))
    denominator = math.sqrt(
        max(total * total - float(np.dot(predicted_marginal, predicted_marginal)), 0.0)
        * max(total * total - float(np.dot(true_marginal, true_marginal)), 0.0)
    )
    mcc = numerator / denominator if denominator > 0 else 0.0

    per_subtype = {
        subtype_names[index]: {
            "support": int(support[index]),
            "predicted_count": int(predicted_count[index]),
            "precision": float(precision[index]),
            "recall": float(recall[index]),
            "f1": float(f1[index]),
        }
        for index in range(number_classes)
    }
    metrics = {
        "support": int(total),
        "evaluated_subtypes": int(active.sum()),
        "top1_accuracy": float(correct / total) if total else 0.0,
        "top5_accuracy": float(top5_correct.float().mean().item()),
        "macro_precision": float(precision[active].mean()),
        "macro_recall": float(recall[active].mean()),
        "macro_f1": float(f1[active].mean()),
        "weighted_precision": float(np.sum(precision * sample_weights)),
        "weighted_recall": float(np.sum(recall * sample_weights)),
        "weighted_f1": float(np.sum(f1 * sample_weights)),
        "mcc": float(mcc),
        "mean_max_cosine_similarity": float(maximum_similarities.mean().item()),
        "median_max_cosine_similarity": float(maximum_similarities.median().item()),
        "per_subtype": per_subtype,
    }
    return metrics, torch.from_numpy(confusion.astype(np.int32, copy=False))


@torch.no_grad()
def nearest_prototype_evaluation(
    features: torch.Tensor,
    labels: list[str],
    record_ids: list[str],
    selected_indices: list[int],
    prototypes: torch.Tensor,
    subtype_names: list[str],
    subtype_to_index: dict[str, int],
    device: torch.device,
    batch_size: int,
):
    arg_indices = [
        index for index in selected_indices if not is_nonarg(labels[index])
    ]
    excluded_nonarg = len(selected_indices) - len(arg_indices)
    if not arg_indices:
        raise ValueError("Evaluation split has no ARG records")

    index_tensor = torch.tensor(arg_indices, dtype=torch.long)
    selected_features = F.normalize(
        features.index_select(0, index_tensor), p=2, dim=1
    )
    true_indices = torch.tensor(
        [subtype_to_index[labels[index]] for index in arg_indices], dtype=torch.long
    )
    selected_ids = [record_ids[index] for index in arg_indices]
    prototype_device = prototypes.to(device)
    predicted_parts = []
    max_similarity_parts = []
    top5_parts = []
    top_k = min(5, prototypes.shape[0])
    for start in range(0, len(arg_indices), batch_size):
        end = min(start + batch_size, len(arg_indices))
        batch = selected_features[start:end].to(device)
        similarity = batch @ prototype_device.T
        values, indices = similarity.topk(k=top_k, dim=1)
        true_batch = true_indices[start:end].to(device)
        predicted_parts.append(indices[:, 0].cpu())
        max_similarity_parts.append(values[:, 0].float().cpu())
        top5_parts.append((indices == true_batch.unsqueeze(1)).any(dim=1).cpu())

    predicted = torch.cat(predicted_parts).long()
    max_similarity = torch.cat(max_similarity_parts).float()
    top5_correct = torch.cat(top5_parts).bool()
    metrics, confusion = compute_metrics(
        true_indices,
        predicted,
        prototypes.shape[0],
        top5_correct,
        max_similarity,
        subtype_names,
    )
    return {
        "metrics": metrics,
        "evaluated_ids": selected_ids,
        "true_subtype_indices": true_indices,
        "predicted_subtype_indices": predicted,
        "maximum_cosine_similarities": max_similarity,
        "top5_correct": top5_correct,
        "confusion_matrix": confusion,
        "excluded_nonarg_records": excluded_nonarg,
    }


def print_result(name: str, result: dict) -> None:
    metrics = result["metrics"]
    print(
        f"{name:28s} | n={metrics['support']:,} | "
        f"subtypes={metrics['evaluated_subtypes']:,} | "
        f"ACC={metrics['top1_accuracy']:.6f} | "
        f"macro_F1={metrics['macro_f1']:.6f} | "
        f"weighted_F1={metrics['weighted_f1']:.6f} | "
        f"MCC={metrics['mcc']:.6f}",
        flush=True,
    )


def main() -> None:
    args = parse_args()
    if not args.input_pt.is_file():
        raise FileNotFoundError(f"Input gated-fusion PT not found: {args.input_pt}")
    if args.output_pt.exists() and not args.overwrite:
        raise FileExistsError(
            f"Output already exists: {args.output_pt}\nUse --overwrite to replace it."
        )
    if args.batch_size < 1:
        raise ValueError("--batch-size must be positive")

    device = choose_device(args.device)
    args.output_pt.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    print("=" * 120, flush=True)
    print("Train-only raw ARG subtype prototypes and cosine baselines", flush=True)
    print("=" * 120, flush=True)
    print(f"Script version : {SCRIPT_VERSION}", flush=True)
    print(f"Input PT       : {args.input_pt}", flush=True)
    print(f"Output PT      : {args.output_pt}", flush=True)
    print(f"Device         : {device}", flush=True)

    (
        input_obj,
        fragment_ids,
        fragment_original_ids,
        fragment_subtypes,
        fragment_external_splits,
        fragment_model_splits,
        fragment_embeddings,
    ) = load_and_validate_input(args.input_pt)

    original_data = aggregate_original_embeddings(
        fragment_original_ids,
        fragment_subtypes,
        fragment_external_splits,
        fragment_model_splits,
        fragment_embeddings,
    )
    prototype_data = build_train_only_prototypes(
        input_obj,
        original_data,
        fragment_subtypes,
        fragment_model_splits,
    )
    prototypes = prototype_data["raw_arg_subtype_prototypes"]
    subtype_names = prototype_data["arg_subtype_names"]
    subtype_to_index = prototype_data["arg_subtype_to_index"]

    fragment_split_indices = {
        split: [
            index
            for index, value in enumerate(fragment_model_splits)
            if value == split
        ]
        for split in ("validation", "test")
    }
    original_split_indices = {
        split: [
            index
            for index, value in enumerate(original_data["model_splits"])
            if value == split
        ]
        for split in ("validation", "test")
    }

    print("\n===== COSINE NEAREST-PROTOTYPE BASELINES (ARG ONLY) =====", flush=True)
    evaluations = {
        "validation_fragment": nearest_prototype_evaluation(
            fragment_embeddings,
            fragment_subtypes,
            fragment_ids,
            fragment_split_indices["validation"],
            prototypes,
            subtype_names,
            subtype_to_index,
            device,
            args.batch_size,
        ),
        "test_fragment": nearest_prototype_evaluation(
            fragment_embeddings,
            fragment_subtypes,
            fragment_ids,
            fragment_split_indices["test"],
            prototypes,
            subtype_names,
            subtype_to_index,
            device,
            args.batch_size,
        ),
        "validation_original": nearest_prototype_evaluation(
            original_data["embeddings"],
            original_data["subtypes"],
            original_data["ids"],
            original_split_indices["validation"],
            prototypes,
            subtype_names,
            subtype_to_index,
            device,
            args.batch_size,
        ),
        "test_original": nearest_prototype_evaluation(
            original_data["embeddings"],
            original_data["subtypes"],
            original_data["ids"],
            original_split_indices["test"],
            prototypes,
            subtype_names,
            subtype_to_index,
            device,
            args.batch_size,
        ),
    }
    for name, result in evaluations.items():
        print_result(name, result)

    output = {
        "arg_subtype_names": subtype_names,
        "arg_subtype_to_index": subtype_to_index,
        "raw_arg_subtype_prototypes": prototypes,
        "prototype_train_original_counts": prototype_data[
            "prototype_train_original_counts"
        ],
        "prototype_train_fragment_counts": prototype_data[
            "prototype_train_fragment_counts"
        ],
        "nonarg_reference_centroid": prototype_data["nonarg_reference_centroid"],
        "nonarg_train_original_count": prototype_data[
            "nonarg_train_original_count"
        ],
        "original_ids": original_data["ids"],
        "original_mean_embeddings": original_data["embeddings"],
        "original_fragment_counts": original_data["fragment_counts"],
        "original_subtypes": original_data["subtypes"],
        "original_external_splits": original_data["external_splits"],
        "original_model_splits": original_data["model_splits"],
        "baseline_evaluations": evaluations,
        "embedding_dimension": int(prototypes.shape[1]),
        "num_ARG_subtypes": len(subtype_names),
        "prototype_construction": (
            "mean fragments per Original_ID -> L2 normalize original mean -> "
            "mean model-train originals per ARG Subtype -> L2 normalize prototype"
        ),
        "classification_rule": "maximum cosine similarity to all raw ARG subtype prototypes",
        "nonARG_policy": "excluded from ARG prototype graph; train-only reference centroid stored separately",
        "source_gated_fusion_pt": str(args.input_pt),
        "script_version": SCRIPT_VERSION,
    }
    temporary = args.output_pt.with_suffix(args.output_pt.suffix + ".tmp")
    torch.save(output, temporary)
    os.replace(temporary, args.output_pt)

    print("\n" + "=" * 120, flush=True)
    print("RAW PROTOTYPE BASELINE COMPLETED", flush=True)
    print("=" * 120, flush=True)
    print(f"Raw ARG prototypes : {tuple(prototypes.shape)}", flush=True)
    print(f"Only output file   : {args.output_pt}", flush=True)
    print(f"Elapsed seconds    : {time.time()-started:.3f}", flush=True)


if __name__ == "__main__":
    main()
