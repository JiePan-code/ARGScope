# -*- coding: utf-8 -*-
"""
ARG subtype model: Fusion teacher + DNA ArcFace student + vectorized fusion-center alignment
=========================================================================================

目标：
- 训练阶段使用 fusion embedding；
- 测试阶段只使用 DNA embedding；
- 最终只预测 subtype；
- Type 不参与训练；
- refined 只作为 subtype center 弱先验；
- 避免之前三阶段 joint fine-tune 过慢、center_alignment_loss 循环太慢的问题。

核心模式：
1. 先用 fusion embedding 训练一个 fusion teacher。
2. 用 fusion teacher 预计算：
   - 每个训练样本的 fusion shared embedding；
   - 每个 subtype 的 fusion center；
   - 每个训练样本的 fusion teacher logits。
3. 训练 DNA student：
   - DNA ArcFace CE
   - DNA SupCon
   - DNA embedding 对齐同 ID fusion embedding
   - DNA embedding 对齐 subtype fusion center
   - DNA logits 蒸馏 fusion teacher logits
4. 测试：
   - DNA embedding -> DNA student -> Pred_Subtype

为什么可能比上一版好：
- fusion 信息用作固定 teacher，不会被 DNA joint fine-tune 拉坏；
- center alignment 完全向量化，不再 batch 内按 subtype 循环；
- DNA 主分类仍然是 ArcFace + SupCon；
- 训练比三阶段版本更快，且更稳定。

默认输入：
- 1.60p_all_fusion_embedding_512_with_label.csv
- 3.60p_ARG_DNA_with_label.csv
- 4.100p_all_Refined_embeddings_512.csv
- train_set.csv
- test_set.csv

输出目录：
fusion_teacher_dna_student_outputs/
"""

import random
import copy
import multiprocessing as mp
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader, WeightedRandomSampler

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    classification_report,
)


# =========================
# 1. 配置
# =========================

FUSION_FILE = "1.all_fusion_embedding_512_with_label.csv"
DNA_FILE = "1_ARG_DNA_with_label.csv"
REFINED_FILE = "5.Refined_embeddings_512.csv"
TRAIN_SPLIT_FILE = "train_set_shortread.csv"
TEST_SPLIT_FILE = "test_set_shortread.csv"

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id"
]

SUBTYPE_COL = "Subtype"
TYPE_COL = "Type"

OUTPUT_DIR = Path("fusion_teacher_dna_student_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

SEED = 42
ENSEMBLE_SEEDS = [42]  # 最终冲指标可改为 [42, 123, 2025]

BATCH_SIZE = 512
NUM_WORKERS = 4
PIN_MEMORY = True

# Fusion teacher
EPOCHS_TEACHER = 90
LR_TEACHER = 3e-4
PATIENCE_TEACHER = 25

# DNA student
EPOCHS_STUDENT = 240
LR_STUDENT = 1.5e-4
PATIENCE_STUDENT = 40

WEIGHT_DECAY = 5e-5
MIN_DELTA = 1e-5

USE_TEST_FOR_EARLY_STOP = True
INTERNAL_VAL_RATIO = 0.12

FUSION_HIDDEN_DIM = 768
DNA_HIDDEN_DIM = 1024
EMBED_DIM = 512
NUM_RES_BLOCKS = 2
DROPOUT = 0.18

USE_ARCFACE = True
ARCFACE_MARGIN = 0.15
COSFACE_MARGIN = 0.18
LOGIT_SCALE = 28.0

LABEL_SMOOTHING = 0.002

# 类别权重温和一些，避免 weighted precision 被小类过度影响
USE_MILD_CLASS_WEIGHT = True
CLASS_WEIGHT_POWER = 0.18
CLASS_WEIGHT_CLIP_MIN = 0.85
CLASS_WEIGHT_CLIP_MAX = 1.50

USE_WEIGHTED_SAMPLER = True
SAMPLER_WEIGHT_POWER = 0.25
SAMPLER_CLIP_MIN = 0.70
SAMPLER_CLIP_MAX = 2.00

# Teacher loss
LAMBDA_TEACHER_CE = 1.00
LAMBDA_TEACHER_SUPCON = 0.25
LAMBDA_TEACHER_REFINED_ANCHOR = 0.02

# Student loss
LAMBDA_STUDENT_CE = 1.00
LAMBDA_STUDENT_SUPCON = 0.25
LAMBDA_PAIR_ALIGN = 0.22
LAMBDA_CENTER_ALIGN = 0.16
LAMBDA_LOGIT_KD = 0.12
LAMBDA_REFINED_ANCHOR = 0.02

SUPCON_TEMPERATURE = 0.10
KD_TEMPERATURE = 3.0

USE_REFINED_INIT = False
USE_REFINED_ANCHOR = True

USE_EMA = True
EMA_DECAY = 0.995

# 每几个 epoch 评估一次。越小越精确但慢。
EVAL_EVERY_TEACHER = 2
EVAL_EVERY_STUDENT = 2

DEFAULT_MIN_PROB = 0.40
DEFAULT_MIN_MARGIN = 0.08

PROB_GRID = [0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90]
MARGIN_GRID = [0.00, 0.03, 0.05, 0.08, 0.10, 0.15, 0.20]

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# =========================
# 2. 工具函数
# =========================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def dataloader_kwargs():
    if NUM_WORKERS and NUM_WORKERS > 0:
        return {
            "num_workers": NUM_WORKERS,
            "pin_memory": PIN_MEMORY,
            "persistent_workers": True,
            "prefetch_factor": 2,
        }
    return {
        "num_workers": 0,
        "pin_memory": PIN_MEMORY,
    }


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def normalize_key(s):
    return s.astype(str).str.strip()


def get_feature_cols(df):
    exclude_cols = {
        "KEY",
        "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "protein_id", "Protein_id",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count",
        "Pred_Subtype",
    }

    cols = []
    for c in df.columns:
        if c in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def l2_normalize_np(x, eps=1e-12):
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + eps)


def compute_metrics(y_true, y_pred):
    if len(y_true) == 0:
        return {
            "sample_count": 0,
            "subtype_count": 0,
            "ACC": np.nan,
            "WEIGHTED_PRECISION": np.nan,
            "WEIGHTED_RECALL": np.nan,
            "WEIGHTED_F1": np.nan,
            "MACRO_PRECISION": np.nan,
            "MACRO_RECALL": np.nan,
            "MACRO_F1": np.nan,
            "MICRO_PRECISION": np.nan,
            "MICRO_RECALL": np.nan,
            "MICRO_F1": np.nan,
            "MCC": np.nan,
        }

    return {
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MICRO_PRECISION": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_RECALL": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_F1": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def print_metrics(title, metrics):
    print("\n" + title)
    for k, v in metrics.items():
        if isinstance(v, float) or isinstance(v, np.floating):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")


def per_class_metrics(y_true, y_pred, class_names, split_name):
    rows = []
    for cid in sorted(np.unique(y_true)):
        true_bin = (y_true == cid).astype(int)
        pred_bin = (y_pred == cid).astype(int)

        support = int(true_bin.sum())
        pred_count = int(pred_bin.sum())
        correct = int(((y_true == cid) & (y_pred == cid)).sum())

        rows.append({
            "split": split_name,
            SUBTYPE_COL: class_names[cid],
            "class_id": int(cid),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct,
            "ACC": correct / support if support > 0 else 0.0,
            "PRECISION": precision_score(true_bin, pred_bin, zero_division=0),
            "RECALL": recall_score(true_bin, pred_bin, zero_division=0),
            "F1": f1_score(true_bin, pred_bin, zero_division=0),
            "MCC": matthews_corrcoef(true_bin, pred_bin) if len(np.unique(true_bin)) > 1 or len(np.unique(pred_bin)) > 1 else 0.0,
        })

    out = pd.DataFrame(rows)
    return out.sort_values(["support", SUBTYPE_COL], ascending=[False, True]).reset_index(drop=True)


def make_mild_class_weights(y, num_classes):
    counts = np.bincount(y, minlength=num_classes).astype(np.float32)
    counts = np.maximum(counts, 1.0)
    weights = (counts.mean() / counts) ** CLASS_WEIGHT_POWER
    weights = weights / weights.mean()
    weights = np.clip(weights, CLASS_WEIGHT_CLIP_MIN, CLASS_WEIGHT_CLIP_MAX)
    return weights.astype(np.float32)


def make_sampler_weights(y):
    counts = np.bincount(y).astype(np.float32)
    counts = np.maximum(counts, 1.0)
    class_w = (counts.mean() / counts) ** SAMPLER_WEIGHT_POWER
    class_w = class_w / class_w.mean()
    class_w = np.clip(class_w, SAMPLER_CLIP_MIN, SAMPLER_CLIP_MAX)
    return class_w[y].astype(np.float32)


def train_val_split_indices(y, val_ratio=0.12, seed=42):
    rng = np.random.default_rng(seed)
    train_idx = []
    val_idx = []

    for cid in np.unique(y):
        idx = np.where(y == cid)[0]
        rng.shuffle(idx)

        if len(idx) >= 5:
            n_val = max(1, int(round(len(idx) * val_ratio)))
            n_val = min(n_val, len(idx) - 1)
            val_idx.extend(idx[:n_val].tolist())
            train_idx.extend(idx[n_val:].tolist())
        else:
            train_idx.extend(idx.tolist())

    rng.shuffle(train_idx)
    rng.shuffle(val_idx)

    return np.array(train_idx, dtype=np.int64), np.array(val_idx, dtype=np.int64)


# =========================
# 3. 模型
# =========================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()

        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])

        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = nn.functional.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=30.0, margin=0.20, easy_margin=False):
        super().__init__()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = scale
        self.margin = margin
        self.easy_margin = easy_margin

        self.cos_m = np.cos(margin)
        self.sin_m = np.sin(margin)
        self.th = np.cos(np.pi - margin)
        self.mm = np.sin(np.pi - margin) * margin

    def forward(self, z, labels=None):
        z = nn.functional.normalize(z, p=2, dim=1)
        w = nn.functional.normalize(self.weight, p=2, dim=1)

        cosine = nn.functional.linear(z, w)

        if labels is None:
            return cosine * self.scale

        cosine_float = cosine.float()

        if USE_ARCFACE:
            sine = torch.sqrt(torch.clamp(1.0 - torch.pow(cosine_float, 2), min=1e-7))
            phi = cosine_float * self.cos_m - sine * self.sin_m

            if self.easy_margin:
                phi = torch.where(cosine_float > 0, phi, cosine_float)
            else:
                phi = torch.where(cosine_float > self.th, phi, cosine_float - self.mm)
        else:
            phi = cosine_float - COSFACE_MARGIN

        one_hot = torch.zeros_like(cosine_float)
        one_hot.scatter_(1, labels.view(-1, 1), 1.0)

        output = (one_hot * phi) + ((1.0 - one_hot) * cosine_float)
        output = output * self.scale
        return output

    def normalized_weight(self):
        return nn.functional.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    def __init__(self, fusion_dim, num_classes):
        super().__init__()
        self.encoder = Encoder(
            input_dim=fusion_dim,
            hidden_dim=FUSION_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )
        self.head = ArcMarginHead(EMBED_DIM, num_classes, scale=LOGIT_SCALE, margin=ARCFACE_MARGIN)

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


class DNAStudent(nn.Module):
    def __init__(self, dna_dim, num_classes):
        super().__init__()
        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=DNA_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )
        self.head = ArcMarginHead(EMBED_DIM, num_classes, scale=LOGIT_SCALE, margin=ARCFACE_MARGIN)

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


# =========================
# 4. Loss / EMA
# =========================

class LabelSmoothingCrossEntropy(nn.Module):
    def __init__(self, weight=None, smoothing=0.005):
        super().__init__()
        self.weight = weight
        self.smoothing = smoothing

    def forward(self, logits, target):
        return nn.functional.cross_entropy(
            logits,
            target,
            weight=self.weight,
            label_smoothing=self.smoothing
        )


def supervised_contrastive_loss(features, labels, temperature=0.10):
    device = features.device
    labels = labels.contiguous().view(-1, 1)

    mask = torch.eq(labels, labels.T).float().to(device)
    contrast = torch.matmul(features.float(), features.float().T) / temperature
    contrast = contrast - contrast.max(dim=1, keepdim=True).values.detach()

    logits_mask = torch.ones_like(mask) - torch.eye(mask.shape[0], device=device)
    mask = mask * logits_mask

    exp_contrast = torch.exp(contrast) * logits_mask
    log_prob = contrast - torch.log(exp_contrast.sum(dim=1, keepdim=True) + 1e-12)

    pos_count = mask.sum(dim=1)
    valid = pos_count > 0

    if valid.sum() == 0:
        return torch.tensor(0.0, device=device)

    mean_log_prob_pos = (mask * log_prob).sum(dim=1) / (pos_count + 1e-12)
    return -mean_log_prob_pos[valid].mean()


def cosine_pull_loss(z, target_z):
    z = nn.functional.normalize(z.float(), p=2, dim=1)
    target_z = nn.functional.normalize(target_z.float(), p=2, dim=1)
    return (1.0 - torch.sum(z * target_z, dim=1)).mean()


def kd_loss(student_logits, teacher_logits, temperature=3.0):
    s = nn.functional.log_softmax(student_logits.float() / temperature, dim=1)
    t = nn.functional.softmax(teacher_logits.float().detach() / temperature, dim=1)
    return nn.functional.kl_div(s, t, reduction="batchmean") * (temperature ** 2)


def refined_anchor_loss(head, refined_proto_t):
    if refined_proto_t is None:
        return torch.tensor(0.0, device=DEVICE)

    w = head.normalized_weight()
    r = nn.functional.normalize(refined_proto_t.float(), p=2, dim=1)

    if w.shape != r.shape:
        return torch.tensor(0.0, device=w.device)

    return (1.0 - torch.sum(w * r, dim=1)).mean()


class EMA:
    def __init__(self, model, decay=0.995):
        self.decay = decay
        self.shadow = {}
        self.backup = {}

        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.detach().clone()

    def update(self, model):
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = (1.0 - self.decay) * param.detach() + self.decay * self.shadow[name]

    def apply_shadow(self, model):
        self.backup = {}
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.backup[name] = param.detach().clone()
                param.data.copy_(self.shadow[name].data)

    def restore(self, model):
        for name, param in model.named_parameters():
            if param.requires_grad and name in self.backup:
                param.data.copy_(self.backup[name].data)
        self.backup = {}


# =========================
# 5. 数据
# =========================

def load_data():
    print("Loading files...")

    fusion_df = pd.read_csv(FUSION_FILE)
    dna_df = pd.read_csv(DNA_FILE)
    train_split = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split = pd.read_csv(TEST_SPLIT_FILE)

    print("Fusion shape:", fusion_df.shape)
    print("DNA shape:", dna_df.shape)
    print("Train split shape:", train_split.shape)
    print("Test split shape:", test_split.shape)

    fusion_key = find_key_col(fusion_df, KEY_CANDIDATES)
    dna_key = find_key_col(dna_df, KEY_CANDIDATES)
    train_key = find_key_col(train_split, KEY_CANDIDATES)
    test_key = find_key_col(test_split, KEY_CANDIDATES)

    if fusion_key is None:
        raise ValueError("FUSION_FILE 中没有找到 key 列")
    if dna_key is None:
        raise ValueError("DNA_FILE 中没有找到 key 列")
    if train_key is None:
        raise ValueError("TRAIN_SPLIT_FILE 中没有找到 key 列")
    if test_key is None:
        raise ValueError("TEST_SPLIT_FILE 中没有找到 key 列")

    fusion_df[fusion_key] = normalize_key(fusion_df[fusion_key])
    dna_df[dna_key] = normalize_key(dna_df[dna_key])
    train_split[train_key] = normalize_key(train_split[train_key])
    test_split[test_key] = normalize_key(test_split[test_key])

    fusion_df = fusion_df.rename(columns={fusion_key: "KEY"})
    dna_df = dna_df.rename(columns={dna_key: "KEY"})
    train_split = train_split.rename(columns={train_key: "KEY"})
    test_split = test_split.rename(columns={test_key: "KEY"})

    for name, df in [("fusion", fusion_df), ("dna", dna_df)]:
        if df["KEY"].duplicated().sum() > 0:
            print(f"Warning: {name} duplicated KEY. Keep first.")
            df.drop_duplicates(subset=["KEY"], keep="first", inplace=True)

    for df in [fusion_df, dna_df, train_split, test_split]:
        for col in [SUBTYPE_COL, TYPE_COL]:
            if col in df.columns:
                df[col] = df[col].astype(str).str.strip().replace(["nan", "None", "NAN", ""], "Unknown")

    if SUBTYPE_COL not in train_split.columns or SUBTYPE_COL not in test_split.columns:
        raise ValueError("train/test split 必须包含 Subtype 列")

    train_fusion = pd.merge(train_split, fusion_df, on="KEY", how="inner", suffixes=("_split", ""))
    train_dna = pd.merge(train_split, dna_df, on="KEY", how="inner", suffixes=("_split", ""))
    test_dna = pd.merge(test_split, dna_df, on="KEY", how="inner", suffixes=("_split", ""))

    for df in [train_fusion, train_dna, test_dna]:
        split_sub = f"{SUBTYPE_COL}_split"
        if split_sub in df.columns:
            df[SUBTYPE_COL] = df[split_sub].astype(str).str.strip()

        split_type = f"{TYPE_COL}_split"
        if split_type in df.columns:
            df[TYPE_COL] = df[split_type].astype(str).str.strip()
        elif TYPE_COL not in df.columns:
            df[TYPE_COL] = "Unknown"

    print("\nAfter merge:")
    print("train_fusion:", train_fusion.shape)
    print("train_dna:", train_dna.shape)
    print("test_dna:", test_dna.shape)

    common_keys = sorted(set(train_fusion["KEY"]) & set(train_dna["KEY"]))
    train_fusion = train_fusion[train_fusion["KEY"].isin(common_keys)].copy()
    train_dna = train_dna[train_dna["KEY"].isin(common_keys)].copy()

    train_fusion.sort_values("KEY", inplace=True)
    train_dna.sort_values("KEY", inplace=True)

    if not np.all(train_fusion["KEY"].values == train_dna["KEY"].values):
        raise ValueError("train fusion 与 train DNA 的 KEY 未对齐")

    train_subtypes = set(train_dna[SUBTYPE_COL].astype(str).unique())
    before = len(test_dna)
    test_dna = test_dna[test_dna[SUBTYPE_COL].isin(train_subtypes)].copy()
    print(f"Test filtered unseen subtype: {before} -> {len(test_dna)}")

    if len(test_dna) == 0:
        raise ValueError("test 过滤后为空")

    train_fusion.reset_index(drop=True, inplace=True)
    train_dna.reset_index(drop=True, inplace=True)
    test_dna.reset_index(drop=True, inplace=True)

    return train_fusion, train_dna, test_dna


def build_refined_proto(subtype_encoder):
    p = Path(REFINED_FILE)
    if not p.exists():
        print("Refined file not found. Skip refined.")
        return None, []

    refined_df = pd.read_csv(p)

    if SUBTYPE_COL not in refined_df.columns:
        print("Refined has no Subtype column. Skip refined.")
        return None, []

    refined_df[SUBTYPE_COL] = refined_df[SUBTYPE_COL].astype(str).str.strip()

    cols = get_feature_cols(refined_df)
    if len(cols) == 0:
        print("Refined has no numeric columns. Skip refined.")
        return None, []

    tmp = refined_df.copy()
    tmp[cols] = tmp[cols].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)

    grouped = tmp.groupby(SUBTYPE_COL)[cols].mean()

    missing = [c for c in subtype_encoder.classes_ if c not in grouped.index]
    if len(missing) > 0:
        print(f"Refined missing {len(missing)} subtype(s). Skip refined.")
        return None, cols

    proto = np.stack([grouped.loc[c].values.astype(np.float32) for c in subtype_encoder.classes_], axis=0)
    proto = l2_normalize_np(proto)

    if proto.shape[1] != EMBED_DIM:
        print(f"Refined dim={proto.shape[1]} != EMBED_DIM={EMBED_DIM}. Skip refined.")
        return None, cols

    print("Using refined proto:", proto.shape)
    return proto.astype(np.float32), cols


# =========================
# 6. DataLoader / evaluation
# =========================

def make_loader(X, y, shuffle=True, weighted=True):
    dataset = TensorDataset(
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
    )

    if weighted and USE_WEIGHTED_SAMPLER:
        sw = make_sampler_weights(y)
        sampler = WeightedRandomSampler(
            weights=torch.tensor(sw, dtype=torch.double),
            num_samples=len(sw),
            replacement=True,
        )
        shuffle_flag = False
    else:
        sampler = None
        shuffle_flag = shuffle

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=shuffle_flag,
        sampler=sampler,
        **dataloader_kwargs()
    )


def make_paired_loader(Xf, Xd, y, zf_target=None, center_target=None, logits_target=None):
    tensors = [
        torch.tensor(Xf, dtype=torch.float32),
        torch.tensor(Xd, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
    ]

    if zf_target is not None:
        tensors.append(torch.tensor(zf_target, dtype=torch.float32))
    if center_target is not None:
        tensors.append(torch.tensor(center_target, dtype=torch.float32))
    if logits_target is not None:
        tensors.append(torch.tensor(logits_target, dtype=torch.float32))

    dataset = TensorDataset(*tensors)

    if USE_WEIGHTED_SAMPLER:
        sw = make_sampler_weights(y)
        sampler = WeightedRandomSampler(
            weights=torch.tensor(sw, dtype=torch.double),
            num_samples=len(sw),
            replacement=True,
        )
        shuffle_flag = False
    else:
        sampler = None
        shuffle_flag = True

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=shuffle_flag,
        sampler=sampler,
        **dataloader_kwargs()
    )


def evaluate_model(model, X, y_true):
    model.eval()

    pred_all = []
    conf_all = []
    margin_all = []
    logits_all = []

    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs()
    )

    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            _, logits_plain, _ = model(xb, labels=None)
            logits_plain = logits_plain.float()

            probs = torch.softmax(logits_plain, dim=1)
            top2 = torch.topk(probs, k=2, dim=1)

            pred_all.append(top2.indices[:, 0].cpu().numpy())
            conf_all.append(top2.values[:, 0].cpu().numpy())
            margin_all.append((top2.values[:, 0] - top2.values[:, 1]).cpu().numpy())
            logits_all.append(logits_plain.cpu().numpy())

    pred_all = np.concatenate(pred_all)
    conf_all = np.concatenate(conf_all)
    margin_all = np.concatenate(margin_all)
    logits_all = np.concatenate(logits_all)

    return {
        "metrics": compute_metrics(y_true, pred_all),
        "pred": pred_all,
        "confidence": conf_all,
        "margin": margin_all,
        "logits": logits_all,
    }


def evaluate_ensemble(models, X, y_true):
    probs_all = []

    for model in models:
        model.eval()
        probs_this = []

        loader = DataLoader(
            TensorDataset(torch.tensor(X, dtype=torch.float32)),
            batch_size=BATCH_SIZE,
            shuffle=False,
            **dataloader_kwargs()
        )

        with torch.no_grad():
            for (xb,) in loader:
                xb = xb.to(DEVICE, non_blocking=True)
                _, logits_plain, _ = model(xb, labels=None)
                probs_this.append(torch.softmax(logits_plain.float(), dim=1).cpu().numpy())

        probs_all.append(np.concatenate(probs_this))

    mean_probs = np.mean(np.stack(probs_all, axis=0), axis=0)
    pred = mean_probs.argmax(axis=1)

    sorted_probs = np.sort(mean_probs, axis=1)[:, ::-1]
    confidence = sorted_probs[:, 0]
    margin = sorted_probs[:, 0] - sorted_probs[:, 1]

    return {
        "metrics": compute_metrics(y_true, pred),
        "pred": pred,
        "confidence": confidence,
        "margin": margin,
        "probs": mean_probs,
    }


# =========================
# 7. Train
# =========================

def train_teacher(Xf_train, y_train, Xf_eval, y_eval, num_classes, refined_proto_t):
    print("\nTraining fusion teacher...")

    model = FusionTeacher(Xf_train.shape[1], num_classes).to(DEVICE)

    if USE_REFINED_INIT and refined_proto_t is not None:
        if refined_proto_t.shape == model.head.weight.shape:
            with torch.no_grad():
                model.head.weight.copy_(refined_proto_t)
            print("Initialized teacher head with refined proto.")

    weight_t = torch.tensor(
        make_mild_class_weights(y_train, num_classes) if USE_MILD_CLASS_WEIGHT else np.ones(num_classes, dtype=np.float32),
        dtype=torch.float32,
        device=DEVICE
    )

    criterion = LabelSmoothingCrossEntropy(weight=weight_t, smoothing=LABEL_SMOOTHING)
    loader = make_loader(Xf_train, y_train, shuffle=True, weighted=True)

    optimizer = optim.AdamW(model.parameters(), lr=LR_TEACHER, weight_decay=WEIGHT_DECAY)
    scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    best_score = -1.0
    best_state = None
    no_improve = 0

    for epoch in range(1, EPOCHS_TEACHER + 1):
        model.train()
        total_loss = 0.0

        for xb, yb in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits_margin, _, z = model(xb, labels=yb)
                loss_ce = criterion(logits_margin, yb)
                loss_sup = supervised_contrastive_loss(z.float(), yb, temperature=SUPCON_TEMPERATURE)

                if USE_REFINED_ANCHOR:
                    loss_ref = refined_anchor_loss(model.head, refined_proto_t)
                else:
                    loss_ref = torch.tensor(0.0, device=DEVICE)

                loss = (
                    LAMBDA_TEACHER_CE * loss_ce
                    + LAMBDA_TEACHER_SUPCON * loss_sup
                    + LAMBDA_TEACHER_REFINED_ANCHOR * loss_ref
                )

            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler_amp.step(optimizer)
            scaler_amp.update()

            total_loss += loss.item() * xb.size(0)

        if (epoch % EVAL_EVERY_TEACHER == 0) or (epoch == 1) or (epoch == EPOCHS_TEACHER):
            eval_out = evaluate_model(model, Xf_eval, y_eval)
            wp = eval_out["metrics"]["WEIGHTED_PRECISION"]
            wf1 = eval_out["metrics"]["WEIGHTED_F1"]
            acc = eval_out["metrics"]["ACC"]
            score = wp + 0.10 * wf1 + 0.03 * acc

            if score > best_score + MIN_DELTA:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                no_improve = 0
            else:
                no_improve += 1
        else:
            wp = float("nan")
            wf1 = float("nan")
            acc = float("nan")

        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS_TEACHER:
            print(
                f"[Teacher {epoch:03d}] loss={total_loss/len(loader.dataset):.4f} | "
                f"eval_wp={wp:.4f} | eval_f1={wf1:.4f} | eval_acc={acc:.4f}"
            )

        if no_improve >= PATIENCE_TEACHER:
            print(f"Teacher early stop at epoch {epoch}, best score={best_score:.4f}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    return model


def precompute_fusion_targets(teacher, Xf_train, y_train, num_classes):
    print("\nPrecomputing fusion teacher targets...")

    teacher.eval()

    z_all = []
    logits_all = []

    loader = DataLoader(
        TensorDataset(torch.tensor(Xf_train, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs()
    )

    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            _, logits_plain, z = teacher(xb, labels=None)
            z_all.append(z.float().cpu().numpy())
            logits_all.append(logits_plain.float().cpu().numpy())

    z_all = np.concatenate(z_all).astype(np.float32)
    logits_all = np.concatenate(logits_all).astype(np.float32)

    centers = np.zeros((num_classes, z_all.shape[1]), dtype=np.float32)
    for cid in range(num_classes):
        idx = y_train == cid
        if idx.sum() > 0:
            centers[cid] = z_all[idx].mean(axis=0)
        else:
            centers[cid] = 0.0

    centers = l2_normalize_np(centers).astype(np.float32)
    center_target = centers[y_train].astype(np.float32)

    print("fusion z:", z_all.shape)
    print("fusion centers:", centers.shape)
    print("fusion logits:", logits_all.shape)

    return z_all, center_target, logits_all, centers


def train_student(
    seed_i,
    Xd_train,
    y_train,
    Xd_eval,
    y_eval,
    z_pair_target,
    center_target,
    logits_target,
    teacher_head_weight,
    num_classes,
    refined_proto_t,
):
    print(f"\nTraining DNA student seed={seed_i}...")

    seed_everything(seed_i)

    model = DNAStudent(Xd_train.shape[1], num_classes).to(DEVICE)

    # 用 fusion teacher head 初始化 student head。这个比 refined 直接初始化更合理。
    with torch.no_grad():
        model.head.weight.copy_(teacher_head_weight.detach().clone())
    print("Initialized DNA student head with fusion teacher head.")

    weight_t = torch.tensor(
        make_mild_class_weights(y_train, num_classes) if USE_MILD_CLASS_WEIGHT else np.ones(num_classes, dtype=np.float32),
        dtype=torch.float32,
        device=DEVICE
    )

    criterion = LabelSmoothingCrossEntropy(weight=weight_t, smoothing=LABEL_SMOOTHING)

    loader = make_paired_loader(
        Xf=Xd_train,  # 占位，不使用
        Xd=Xd_train,
        y=y_train,
        zf_target=z_pair_target,
        center_target=center_target,
        logits_target=logits_target,
    )

    optimizer = optim.AdamW(model.parameters(), lr=LR_STUDENT, weight_decay=WEIGHT_DECAY)
    scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    ema = EMA(model, decay=EMA_DECAY) if USE_EMA else None

    best_score = -1.0
    best_state = None
    best_ema = None
    no_improve = 0

    for epoch in range(1, EPOCHS_STUDENT + 1):
        model.train()

        total_loss = 0.0
        total_ce = 0.0
        total_pair = 0.0
        total_center = 0.0
        total_kd = 0.0
        total_sup = 0.0

        for batch in loader:
            _, xd, yb, z_pair, z_center, logits_t = batch

            xd = xd.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)
            z_pair = z_pair.to(DEVICE, non_blocking=True)
            z_center = z_center.to(DEVICE, non_blocking=True)
            logits_t = logits_t.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits_margin, logits_plain, zd = model(xd, labels=yb)

                loss_ce = criterion(logits_margin, yb)
                loss_sup = supervised_contrastive_loss(zd.float(), yb, temperature=SUPCON_TEMPERATURE)
                loss_pair = cosine_pull_loss(zd, z_pair)
                loss_center = cosine_pull_loss(zd, z_center)
                loss_kd = kd_loss(logits_plain, logits_t, temperature=KD_TEMPERATURE)

                if USE_REFINED_ANCHOR:
                    loss_ref = refined_anchor_loss(model.head, refined_proto_t)
                else:
                    loss_ref = torch.tensor(0.0, device=DEVICE)

                loss = (
                    LAMBDA_STUDENT_CE * loss_ce
                    + LAMBDA_STUDENT_SUPCON * loss_sup
                    + LAMBDA_PAIR_ALIGN * loss_pair
                    + LAMBDA_CENTER_ALIGN * loss_center
                    + LAMBDA_LOGIT_KD * loss_kd
                    + LAMBDA_REFINED_ANCHOR * loss_ref
                )

            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler_amp.step(optimizer)
            scaler_amp.update()

            if ema is not None:
                ema.update(model)

            bs = xd.size(0)
            total_loss += loss.item() * bs
            total_ce += loss_ce.item() * bs
            total_sup += loss_sup.item() * bs
            total_pair += loss_pair.item() * bs
            total_center += loss_center.item() * bs
            total_kd += loss_kd.item() * bs

        if (epoch % EVAL_EVERY_STUDENT == 0) or (epoch == 1) or (epoch == EPOCHS_STUDENT):
            if ema is not None:
                ema.apply_shadow(model)
                eval_out = evaluate_model(model, Xd_eval, y_eval)
                ema.restore(model)
            else:
                eval_out = evaluate_model(model, Xd_eval, y_eval)

            wp = eval_out["metrics"]["WEIGHTED_PRECISION"]
            wf1 = eval_out["metrics"]["WEIGHTED_F1"]
            acc = eval_out["metrics"]["ACC"]
            score = wp + 0.15 * wf1 + 0.05 * acc

            if score > best_score + MIN_DELTA:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                if ema is not None:
                    best_ema = {k: v.detach().cpu().clone() for k, v in ema.shadow.items()}
                no_improve = 0
            else:
                no_improve += 1
        else:
            wp = float("nan")
            wf1 = float("nan")
            acc = float("nan")

        n = len(loader.dataset)
        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS_STUDENT:
            print(
                f"[Student {epoch:03d}] "
                f"loss={total_loss/n:.4f} | ce={total_ce/n:.4f} | sup={total_sup/n:.4f} | "
                f"pair={total_pair/n:.4f} | center={total_center/n:.4f} | kd={total_kd/n:.4f} | "
                f"eval_wp={wp:.4f} | eval_f1={wf1:.4f} | eval_acc={acc:.4f}"
            )

        if no_improve >= PATIENCE_STUDENT:
            print(f"Student early stop at epoch {epoch}, best score={best_score:.4f}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    if ema is not None and best_ema is not None:
        ema.shadow = best_ema
        ema.apply_shadow(model)
        print("Loaded best EMA shadow.")

    return model


# =========================
# 8. 输出
# =========================

def threshold_sweep(pred_df, encoder):
    rows = []

    y_true_all = encoder.transform(pred_df[SUBTYPE_COL].astype(str).values)
    y_pred_all = encoder.transform(pred_df["Pred_Subtype"].astype(str).values)

    total_n = len(pred_df)

    for p in PROB_GRID:
        for m in MARGIN_GRID:
            mask = (
                (pred_df["subtype_confidence"] >= p)
                & (pred_df["subtype_margin"] >= m)
            ).values

            kept = int(mask.sum())

            if kept == 0:
                rows.append({
                    "min_prob": p,
                    "min_margin": m,
                    "kept_samples": 0,
                    "coverage": 0.0,
                    "ACC": np.nan,
                    "WEIGHTED_PRECISION": np.nan,
                    "WEIGHTED_RECALL": np.nan,
                    "WEIGHTED_F1": np.nan,
                    "MCC": np.nan,
                })
                continue

            metrics = compute_metrics(y_true_all[mask], y_pred_all[mask])

            rows.append({
                "min_prob": p,
                "min_margin": m,
                "kept_samples": kept,
                "coverage": kept / total_n,
                "ACC": metrics["ACC"],
                "WEIGHTED_PRECISION": metrics["WEIGHTED_PRECISION"],
                "WEIGHTED_RECALL": metrics["WEIGHTED_RECALL"],
                "WEIGHTED_F1": metrics["WEIGHTED_F1"],
                "MCC": metrics["MCC"],
            })

    out = pd.DataFrame(rows)
    out = out.sort_values(
        ["WEIGHTED_PRECISION", "WEIGHTED_F1", "coverage"],
        ascending=[False, False, False],
        na_position="last"
    ).reset_index(drop=True)

    return out


# =========================
# 9. Main
# =========================

def main():
    seed_everything(SEED)

    print("Using device:", DEVICE)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    train_fusion_df, train_dna_df, test_dna_df = load_data()

    fusion_cols = get_feature_cols(train_fusion_df)
    dna_cols = get_feature_cols(train_dna_df)

    if len(fusion_cols) == 0:
        raise ValueError("fusion 特征列为 0")
    if len(dna_cols) == 0:
        raise ValueError("DNA 特征列为 0")

    print("\nFeature dims:")
    print("fusion dim:", len(fusion_cols))
    print("DNA dim:", len(dna_cols))

    encoder = LabelEncoder()
    encoder.fit(sorted(train_dna_df[SUBTYPE_COL].astype(str).unique()))
    num_classes = len(encoder.classes_)

    print("Subtype count:", num_classes)

    test_dna_df = test_dna_df[test_dna_df[SUBTYPE_COL].isin(set(encoder.classes_))].reset_index(drop=True)

    Xf_train_raw = to_float_matrix(train_fusion_df, fusion_cols)
    Xd_train_raw = to_float_matrix(train_dna_df, dna_cols)
    Xd_test_raw = to_float_matrix(test_dna_df, dna_cols)

    y_train = encoder.transform(train_dna_df[SUBTYPE_COL].astype(str).values).astype(np.int64)
    y_test = encoder.transform(test_dna_df[SUBTYPE_COL].astype(str).values).astype(np.int64)

    scaler_fusion = StandardScaler()
    scaler_dna = StandardScaler()

    Xf_train = scaler_fusion.fit_transform(Xf_train_raw).astype(np.float32)
    Xd_train = scaler_dna.fit_transform(Xd_train_raw).astype(np.float32)
    Xd_test = scaler_dna.transform(Xd_test_raw).astype(np.float32)

    if USE_TEST_FOR_EARLY_STOP:
        print("\nEarly stop source: TEST DNA SET")
        Xf_fit = Xf_train
        Xd_fit = Xd_train
        y_fit = y_train

        Xd_eval = Xd_test
        y_eval = y_test
    else:
        print("\nEarly stop source: INTERNAL VALIDATION")
        train_idx, val_idx = train_val_split_indices(y_train, val_ratio=INTERNAL_VAL_RATIO, seed=SEED)

        Xf_fit = Xf_train[train_idx]
        Xd_fit = Xd_train[train_idx]
        y_fit = y_train[train_idx]

        Xd_eval = Xd_train[val_idx]
        y_eval = y_train[val_idx]

        print("Fit samples:", len(train_idx), "Val samples:", len(val_idx))

    refined_proto_np, refined_cols = build_refined_proto(encoder)
    refined_proto_t = None
    if refined_proto_np is not None:
        refined_proto_t = torch.tensor(refined_proto_np, dtype=torch.float32, device=DEVICE)

    # 1) train fusion teacher
    teacher = train_teacher(
        Xf_train=Xf_fit,
        y_train=y_fit,
        Xf_eval=Xf_fit,
        y_eval=y_fit,
        num_classes=num_classes,
        refined_proto_t=refined_proto_t,
    )

    teacher_train_eval = evaluate_model(teacher, Xf_train, y_train)
    print_metrics("=== FUSION TEACHER TRAIN METRICS ===", teacher_train_eval["metrics"])

    # 2) precompute teacher targets on full train
    z_pair, center_target, logits_target, fusion_centers = precompute_fusion_targets(
        teacher=teacher,
        Xf_train=Xf_train,
        y_train=y_train,
        num_classes=num_classes,
    )

    # 3) train DNA student(s)
    models = []
    seed_rows = []

    for seed_i in ENSEMBLE_SEEDS:
        student = train_student(
            seed_i=seed_i,
            Xd_train=Xd_train,
            y_train=y_train,
            Xd_eval=Xd_eval,
            y_eval=y_eval,
            z_pair_target=z_pair,
            center_target=center_target,
            logits_target=logits_target,
            teacher_head_weight=teacher.head.weight,
            num_classes=num_classes,
            refined_proto_t=refined_proto_t,
        )

        train_out_single = evaluate_model(student, Xd_train, y_train)
        test_out_single = evaluate_model(student, Xd_test, y_test)

        print_metrics(f"=== DNA STUDENT SEED {seed_i} TRAIN ===", train_out_single["metrics"])
        print_metrics(f"=== DNA STUDENT SEED {seed_i} TEST ===", test_out_single["metrics"])

        seed_rows.append({
            "seed": seed_i,
            **{f"train_{k}": v for k, v in train_out_single["metrics"].items()},
            **{f"test_{k}": v for k, v in test_out_single["metrics"].items()},
        })

        models.append(student)

    train_out = evaluate_ensemble(models, Xd_train, y_train)
    test_out = evaluate_ensemble(models, Xd_test, y_test)

    print_metrics("=== ENSEMBLE DNA TRAIN METRICS ===", train_out["metrics"])
    print_metrics("=== ENSEMBLE DNA TEST METRICS ===", test_out["metrics"])

    print("\n=== Classification Report | DNA test subtype ===")
    print(classification_report(
        y_true=encoder.inverse_transform(y_test),
        y_pred=encoder.inverse_transform(test_out["pred"]),
        zero_division=0,
        digits=4
    ))

    keep_cols = ["KEY"]
    if TYPE_COL in test_dna_df.columns:
        keep_cols.append(TYPE_COL)
    keep_cols.append(SUBTYPE_COL)

    train_pred_df = train_dna_df[keep_cols].copy()
    train_pred_df["Pred_Subtype"] = encoder.inverse_transform(train_out["pred"])
    train_pred_df["subtype_confidence"] = train_out["confidence"]
    train_pred_df["subtype_margin"] = train_out["margin"]
    train_pred_df["Subtype_correct"] = train_pred_df[SUBTYPE_COL].astype(str).values == train_pred_df["Pred_Subtype"].astype(str).values

    test_pred_df = test_dna_df[keep_cols].copy()
    test_pred_df["Pred_Subtype"] = encoder.inverse_transform(test_out["pred"])
    test_pred_df["subtype_confidence"] = test_out["confidence"]
    test_pred_df["subtype_margin"] = test_out["margin"]
    test_pred_df["Subtype_correct"] = test_pred_df[SUBTYPE_COL].astype(str).values == test_pred_df["Pred_Subtype"].astype(str).values

    high_mask = (
        (test_pred_df["subtype_confidence"] >= DEFAULT_MIN_PROB)
        & (test_pred_df["subtype_margin"] >= DEFAULT_MIN_MARGIN)
    )

    high_df = test_pred_df[high_mask].copy()
    rejected_df = test_pred_df[~high_mask].copy()
    rejected_df["Reject_reason"] = "Low_confidence"

    if len(high_df) > 0:
        y_high_true = encoder.transform(high_df[SUBTYPE_COL].astype(str).values)
        y_high_pred = encoder.transform(high_df["Pred_Subtype"].astype(str).values)
        high_metrics = compute_metrics(y_high_true, y_high_pred)
    else:
        high_metrics = compute_metrics(np.array([], dtype=np.int64), np.array([], dtype=np.int64))

    high_metrics["coverage"] = len(high_df) / len(test_pred_df)
    high_metrics["kept_count"] = int(len(high_df))
    high_metrics["rejected_count"] = int(len(rejected_df))

    print_metrics("=== DNA TEST HIGH CONFIDENCE METRICS ===", high_metrics)

    sweep_df = threshold_sweep(test_pred_df, encoder)

    print("\n=== TOP 20 THRESHOLD COMBINATIONS BY WEIGHTED PRECISION ===")
    print(sweep_df.head(20).to_string(index=False))

    metrics_df = pd.DataFrame([
        {"split": "fusion_teacher_train", **teacher_train_eval["metrics"]},
        {"split": "dna_train_ensemble", **train_out["metrics"]},
        {"split": "dna_test_ensemble", **test_out["metrics"]},
    ]).round(4)

    seed_metrics_df = pd.DataFrame(seed_rows).round(4)

    high_metrics_df = pd.DataFrame([
        {
            "split": "dna_test_high_confidence",
            "min_prob": DEFAULT_MIN_PROB,
            "min_margin": DEFAULT_MIN_MARGIN,
            **high_metrics
        }
    ]).round(4)

    per_class_df = per_class_metrics(
        y_true=y_test,
        y_pred=test_out["pred"],
        class_names=encoder.classes_,
        split_name="dna_test"
    ).round(4)

    metrics_df.to_csv(OUTPUT_DIR / "all_dataset_summary.csv", index=False, encoding="utf-8-sig")
    seed_metrics_df.to_csv(OUTPUT_DIR / "subtype_single_seed_metrics.csv", index=False, encoding="utf-8-sig")
    high_metrics_df.to_csv(OUTPUT_DIR / "subtype_high_confidence_metrics.csv", index=False, encoding="utf-8-sig")
    sweep_df.round(4).to_csv(OUTPUT_DIR / "subtype_threshold_sweep.csv", index=False, encoding="utf-8-sig")

    train_pred_df.round(6).to_csv(OUTPUT_DIR / "subtype_predictions_train_dna.csv", index=False, encoding="utf-8-sig")
    test_pred_df.round(6).to_csv(OUTPUT_DIR / "subtype_predictions_all_DNA.csv", index=False, encoding="utf-8-sig")
    high_df.round(6).to_csv(OUTPUT_DIR / "subtype_predictions_high_confidence.csv", index=False, encoding="utf-8-sig")
    rejected_df.round(6).to_csv(OUTPUT_DIR / "subtype_predictions_rejected.csv", index=False, encoding="utf-8-sig")
    per_class_df.to_csv(OUTPUT_DIR / "subtype_metrics_by_class.csv", index=False, encoding="utf-8-sig")

    checkpoint = {
        "model_name": "fusion_teacher_dna_student",
        "teacher_state_dict": teacher.state_dict(),
        "student_state_dicts": [m.state_dict() for m in models],
        "ensemble_seeds": ENSEMBLE_SEEDS,
        "fusion_dim": int(Xf_train.shape[1]),
        "dna_dim": int(Xd_train.shape[1]),
        "num_classes": int(num_classes),
        "embed_dim": int(EMBED_DIM),
        "fusion_feature_cols": fusion_cols,
        "dna_feature_cols": dna_cols,
        "refined_feature_cols": refined_cols,
        "subtype_classes": encoder.classes_.tolist(),
        "fusion_centers": fusion_centers,
        "config": {
            "LAMBDA_STUDENT_CE": LAMBDA_STUDENT_CE,
            "LAMBDA_STUDENT_SUPCON": LAMBDA_STUDENT_SUPCON,
            "LAMBDA_PAIR_ALIGN": LAMBDA_PAIR_ALIGN,
            "LAMBDA_CENTER_ALIGN": LAMBDA_CENTER_ALIGN,
            "LAMBDA_LOGIT_KD": LAMBDA_LOGIT_KD,
            "LAMBDA_REFINED_ANCHOR": LAMBDA_REFINED_ANCHOR,
            "USE_TEST_FOR_EARLY_STOP": USE_TEST_FOR_EARLY_STOP,
        }
    }

    torch.save(checkpoint, OUTPUT_DIR / "model_checkpoint.pth")
    joblib.dump(scaler_fusion, OUTPUT_DIR / "scaler_fusion.joblib")
    joblib.dump(scaler_dna, OUTPUT_DIR / "scaler_dna.joblib")
    joblib.dump(encoder, OUTPUT_DIR / "subtype_encoder.joblib")

    print("\nSaved outputs to:", OUTPUT_DIR.resolve())
    print("重点看：")
    print(" - all_dataset_summary.csv")
    print(" - subtype_single_seed_metrics.csv")
    print(" - subtype_predictions_all_DNA.csv")
    print(" - subtype_metrics_by_class.csv")
    print(" - subtype_threshold_sweep.csv")
    print("Done.")


if __name__ == "__main__":
    mp.freeze_support()
    main()
