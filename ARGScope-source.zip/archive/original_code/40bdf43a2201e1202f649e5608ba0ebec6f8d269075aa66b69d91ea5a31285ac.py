#!/usr/bin/env python3
"""Verify source preservation, exported arithmetic/layout, then package artifacts."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'


def main():
    for script in ROOT.glob('*.py'):
        ast.parse(script.read_text(encoding='utf-8'))
    source_hashes=json.loads((DATA/'input_sha256.json').read_text(encoding='utf-8'))
    for filename,expected in source_hashes.items():
        assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==expected, filename
    audit=pd.read_csv(DATA/'cohort_audit.csv')
    assert len(audit)==10 and audit.N_parents.eq(4574).all()
    assert audit.N_ARG_parents.eq(2287).all() and audit.N_subtypes.eq(820).all()
    assert audit.N_types.eq(23).all() and audit.Train_test_ID_overlap.eq(0).all()
    assert audit.loc[audit.Completeness.ne(100),'N_fragments'].eq(22870).all()
    per_type=pd.read_csv(DATA/'ARGScope_per_type_five_metrics.csv')
    for metric,denom,num in [('Precision',per_type.TP+per_type.FP,per_type.TP),
                             ('Recall',per_type.TP+per_type.FN,per_type.TP),
                             ('F1',2*per_type.TP+per_type.FP+per_type.FN,2*per_type.TP)]:
        expected=np.divide(num,denom,out=np.zeros(len(num)),where=denom.ne(0))
        assert np.allclose(per_type[metric],expected,atol=1e-10)
    errors=pd.read_csv(DATA/'error_decomposition.csv')
    assert np.allclose(errors.groupby(['Modality','Completeness']).Fraction.sum(),1)
    stability=pd.read_csv(DATA/'five_fragment_stability.csv')
    assert (stability.CI_low<=stability.All_five_correct).all()
    assert (stability.CI_high>=stability.All_five_correct).all()
    assert stability.Bootstrap_unit.eq('parent_sequence').all()
    links=pd.read_csv(DATA/'feature_robustness_links.csv')
    assert len(links)==12 and links.Spearman_rho.between(-1,1).all()
    assert not any('p_value'==col.lower() for col in links.columns)
    layout=json.loads((ROOT/'layout_validation.json').read_text(encoding='utf-8'))
    assert len(layout)==11
    assert all(not entry['visible_text_outside_canvas'] for entry in layout)
    figures=json.loads((ROOT/'figure_manifest.json').read_text(encoding='utf-8'))
    assert len(figures)==33
    for spec in figures:
        path=ROOT/'figures'/spec['file']
        assert path.stat().st_size>1000,path
        if path.suffix=='.png':
            with Image.open(path) as im:
                im.verify()
        elif path.suffix=='.svg':
            ET.parse(path)
        else:
            assert path.read_bytes().startswith(b'%PDF')
    report=dict(status='PASS',preserved_source_files=len(source_hashes),
                fixed_parents=4574,ARG_parents=2287,fragments_per_modality_completeness=22870,
                valid_figure_formats=33,figure_designs=11,clipped_text_items=0,
                cross_model_comparability='NOT verified; reported summaries only',
                correlation_method='descriptive Spearman, NOT Mantel',
                biological_independence='ID-level independence only; homology not assessed')
    (ROOT/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    archive=ROOT.parent/'ARGScope_fragment_robustness_figures.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for file in sorted(ROOT.rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts:
                z.write(file,arcname=Path(ROOT.name)/file.relative_to(ROOT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        report['archive_files']=len(z.infolist())
    print(json.dumps(report,ensure_ascii=False,indent=2))
    print(f'Archive: {archive} ({archive.stat().st_size/1024**2:.2f} MiB)')


if __name__=='__main__':
    main()
