// Verify the actual SVG deliverables with an independent SVG renderer.
const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = path.resolve(process.argv[2] || 'outputs/figure2_figure3_readable_compact_20260923');
const qa = path.join(root, 'qa_svg');
fs.mkdirSync(qa, {recursive:true});
(async () => {
  const report = [];
  for (const textVariant of [false, true]) {
    for (const folder of ['Figure2_Protein', 'Figure3_DNA']) {
      const dir = path.join(root, ...(textVariant ? ['editable_text'] : []), folder);
      const files = fs.readdirSync(dir).filter(f => f.endsWith('.svg'));
      if (files.length !== Number(process.argv[3] || 16)) throw new Error('Unexpected file count ' + dir);
      for (const file of files) {
        const source = fs.readFileSync(path.join(dir, file));
        if (source.toString().includes('<image ')) throw new Error('Raster found ' + file);
        const result = await sharp(source, {density:150}).resize({width:2100,height:3600,fit:'inside'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
        const {width,height,channels} = result.info;
        let x0=width,y0=height,x1=-1,y1=-1,transparent=0;
        for (let y=0;y<height;y++) for (let x=0;x<width;x++) {
          const a=result.data[(y*width+x)*channels+channels-1];
          if (a===0) transparent++;
          if (a>5) {x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
        }
        if (!transparent) throw new Error('Opaque background ' + file);
        const margins=[x0,y0,width-1-x1,height-1-y1];
        const name=(textVariant ? 'editable_' : '') + file.replace('.svg','.png');
        await sharp(result.data,{raw:result.info}).flatten({background:'#ffffff'}).png().toFile(path.join(qa,name));
        report.push({file,variant:textVariant?'editable':'outlined',width,height,transparent_pixels:transparent,margins_px:margins,edge_touch:Math.min(...margins)===0});
      }
    }
  }
  fs.writeFileSync(path.join(qa,'svg_render_verification.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({rendered:report.length,edge_touch:report.filter(r=>r.edge_touch),composites:report.filter(r=>r.file.includes('combined'))},null,2));
})().catch(e=>{console.error(e);process.exit(1);});
