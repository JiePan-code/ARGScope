import pandas as pd

# ==========================================================
# 1. 文件路径
# ==========================================================
EMBEDDING1_TXT = "dna_embedding.txt"
EMBEDDING2_TXT = "all_arg_nonarg_protein_embeddings.txt"
LABEL_FILE = "all_arg_nonarg_id_label.csv"

OUTPUT_EMB1_CSV = "3.60p_ARG_DNA_with_label.csv"
OUTPUT_EMB2_CSV = "2.30p_ARG_protein_with_label.csv"

# ==========================================================
# 2. label 文件列名
# ==========================================================
LABEL_ID_COL = "id"
LABEL_TYPE_COL = "Type"
LABEL_SUBTYPE_COL = "Subtype"


# ==========================================================
# 3. 读取 embedding（自动适配空格）
# ==========================================================
def load_embedding_txt(txt_file):
    """
    读取 embedding txt
    支持空格 / 多空格分隔
    """
    df = pd.read_csv(
        txt_file,
        sep=r"\s+",          # ⭐ 关键：支持任意空格
        header=None,
        engine="python"
    )

    if df.shape[1] < 2:
        raise ValueError(f"{txt_file} 读取失败，请检查文件格式或分隔符。")

    # 重命名列
    col_names = ["id"] + [f"emb_{i}" for i in range(1, df.shape[1])]
    df.columns = col_names

    df["id"] = df["id"].astype(str).str.strip()

    print(f"{txt_file} loaded: {df.shape}")

    return df


# ==========================================================
# 4. 读取 label
# ==========================================================
def load_label_file(label_file):
    label_df = pd.read_csv(label_file)

    required_cols = [LABEL_ID_COL, LABEL_TYPE_COL, LABEL_SUBTYPE_COL]
    for col in required_cols:
        if col not in label_df.columns:
            raise ValueError(f"label 文件缺少列: {col}")

    label_df = label_df[[LABEL_ID_COL, LABEL_TYPE_COL, LABEL_SUBTYPE_COL]].copy()
    label_df[LABEL_ID_COL] = label_df[LABEL_ID_COL].astype(str).str.strip()

    label_df.columns = ["id", "Type", "Subtype"]

    print(f"Label loaded: {label_df.shape}")

    return label_df


# ==========================================================
# 5. 合并
# ==========================================================
def merge_embedding_with_label(emb_df, label_df, output_file):
    merged_df = emb_df.merge(label_df, on="id", how="left")

    emb_cols = [c for c in merged_df.columns if c.startswith("emb_")]
    final_cols = ["id", "Type", "Subtype"] + emb_cols
    merged_df = merged_df[final_cols]

    # ⭐ 减少文件体积
    merged_df.to_csv(output_file, index=False, float_format="%.6f")

    matched_n = merged_df["Type"].notna().sum()
    unmatched_n = merged_df["Type"].isna().sum()

    print(f"Saved: {output_file}")
    print(f"Total rows: {len(merged_df)}")
    print(f"Matched labels: {matched_n}")
    print(f"Unmatched labels: {unmatched_n}")
    print("-" * 50)

    return merged_df


# ==========================================================
# 6. 主函数
# ==========================================================
def main():
    print("Loading embedding txt files...")

    emb1_df = load_embedding_txt(EMBEDDING1_TXT)
    emb2_df = load_embedding_txt(EMBEDDING2_TXT)

    print("Loading label file...")
    label_df = load_label_file(LABEL_FILE)

    print("Merging DNA embedding with labels...")
    merge_embedding_with_label(emb1_df, label_df, OUTPUT_EMB1_CSV)

    print("Merging protein embedding with labels...")
    merge_embedding_with_label(emb2_df, label_df, OUTPUT_EMB2_CSV)

    print("Done.")


# ==========================================================
# 7. 入口
# ==========================================================
if __name__ == "__main__":
    main()