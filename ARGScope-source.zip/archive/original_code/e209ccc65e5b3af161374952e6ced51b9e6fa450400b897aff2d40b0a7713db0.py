import csv
import hashlib
import itertools
import json
import unittest
from collections import Counter
from pathlib import Path

import rebuild_split_80_20_grouped as split


class AllocationTests(unittest.TestCase):
    def test_quota_optimum_against_exhaustive_search(self):
        sizes = {"a": 2, "b": 8, "c": 10}
        low, high = {k: 1 for k in sizes}, {k: sizes[k]-1 for k in sizes}
        for budget in range(3, 12):
            q = split.quotas(sizes, low, high, .2, budget)
            objective = sum((q[k]-.2*sizes[k])**2 for k in sizes)
            possible = (v for v in itertools.product(*[range(low[k], high[k]+1) for k in sizes]) if sum(v)==budget)
            best = min(sum((v[i]-.2*sizes[k])**2 for i,k in enumerate(sizes)) for v in possible)
            self.assertAlmostEqual(objective, best)

    def test_impossible_budget_is_not_silently_relaxed(self):
        with self.assertRaises(ValueError):
            split.quotas({"a": 2, "b": 2}, {"a": 1, "b": 1}, {"a": 1, "b": 1}, .2, 1)

    def test_group_cannot_be_split(self):
        with self.assertRaises(ValueError):
            split.select_groups([("a", "b"), ("c", "d")], 1, 3, "test")
        result = split.select_groups([("a", "b"), ("c",), ("d",)], 3, 3, "test")
        self.assertEqual(len(result), 3)
        self.assertEqual("a" in result, "b" in result)

    def test_order_independent_reproducibility(self):
        groups = [(str(i),) for i in range(25)] + [("x", "y")]
        a = split.select_groups(groups, 7, 20260822, "test")
        b = split.select_groups(list(reversed(groups)), 7, 20260822, "test")
        self.assertEqual(a, b)

    def test_protein_or_dna_transitive_grouping(self):
        ids = {"a", "b", "c"}
        labels = {k: {"ARG.or.nonARG": "ARG", "Type": "t", "Subtype": "s"} for k in ids}
        p = {"a": ("p1", 1), "b": ("p1", 1), "c": ("p2", 1)}
        d = {"a": ("d1", 1), "b": ("d2", 1), "c": ("d2", 1)}
        self.assertEqual(split.group_sequences(ids, labels, p, d), [("a", "b", "c")])
        labels["b"]["Subtype"] = "different"
        with self.assertRaises(ValueError):
            split.group_sequences(ids, labels, p, d)


def independent_check():
    out = Path(__file__).resolve().parent / "outputs" / "split_80_20_verified"
    root = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset")
    def ids(name):
        lines = (out / name).read_text(encoding="utf-8-sig").splitlines()
        assert lines and all(lines) and len(lines) == len(set(lines))
        return set(lines)
    tr, va, te = ids("model_train_ids.txt"), ids("validation_ids.txt"), ids("test_ids_subtype2.txt")
    et = ids("train_ids_subtype2.txt")
    assert len(tr)==14636 and len(va)==3660 and len(te)==4574 and len(et)==18296
    assert tr|va==et and not(tr&va or tr&te or va&te)
    old = set((root/"train_ids_subtype2.txt").read_text(encoding="utf-8-sig").splitlines()) | set((root/"test_ids_subtype2.txt").read_text(encoding="utf-8-sig").splitlines())
    assert tr|va|te == old == ids("population_ids.txt")
    with (out/"split_manifest.csv").open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    assert len(rows)==22870 and len({r["sequence_id"] for r in rows})==22870
    with (root/"all_ARG_nonARG_1to1_structure.txt").open(encoding="utf-8-sig", newline="") as f:
        raw = {r["SARG.Seq.ID"]:r for r in csv.DictReader(f, delimiter="\t")}
    for r in rows:
        source = raw[r["sequence_id"]]
        assert r["Type"]==source["Type"] and r["Subtype"]==source["Subtype"] and r["ARG_or_nonARG"]==source["ARG.or.nonARG"]
    groups = {"train":tr, "validation":va, "test":te}
    for name, idset in groups.items():
        assert idset == {r["sequence_id"] for r in rows if r["model_split"]==name}
        counts = Counter(raw[s]["ARG.or.nonARG"] for s in idset)
        assert counts["ARG"]==counts["nonARG"]
    subtypes = {raw[s]["Subtype"] for s in old if raw[s]["ARG.or.nonARG"]=="ARG"}
    assert len(subtypes)==820
    assert {raw[s]["Subtype"] for s in te if raw[s]["ARG.or.nonARG"]=="ARG"}==subtypes
    assert {raw[s]["Subtype"] for s in tr if raw[s]["ARG.or.nonARG"]=="ARG"}==subtypes
    all_counts=Counter(raw[s]["Subtype"] for s in old if raw[s]["ARG.or.nonARG"]=="ARG")
    n2=[k for k,v in all_counts.items() if v==2]
    assert len(n2)==328
    for k in n2:
        assert sum(raw[s]["Subtype"]==k for s in te)==1
        assert sum(raw[s]["Subtype"]==k for s in tr)==1
    # Independently compare literal sequence strings, not generated hashes.
    seq_report={}
    for modality, filename in (("Protein","all_ARG_nonARG_1to1_protein.fasta"),("DNA","all_ARG_nonARG_1to1_DNA.fasta")):
        p=split.DEFAULT_FASTA_DIR/filename
        seqs={name:set() for name in groups}
        current=None
        buffer=[]
        def keep():
            if current in old:
                seq="".join(buffer).upper()
                for name,idset in groups.items():
                    if current in idset:
                        seqs[name].add(seq)
        with p.open(encoding="utf-8-sig") as f:
            for line in f:
                if line.startswith(">"):
                    keep()
                    current=line[1:].split()[0]
                    buffer=[]
                else:
                    buffer.extend(line.split())
            keep()
        overlaps={f"{a}_{b}":len(seqs[a]&seqs[b]) for a,b in (("train","test"),("validation","test"),("train","validation"))}
        assert all(v==0 for v in overlaps.values())
        seq_report[modality]=overlaps
    report=json.loads((out/"split_contract.json").read_text(encoding="utf-8"))
    for path,digest in report["source_sha256"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
    for name,digest in report["output_sha256"].items():
        assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
    with (out.parent/"split_80_20_grouped"/"split_contract.json").open(encoding="utf-8") as f:
        first=json.load(f)
    assert first["split_fingerprint"]==report["split_fingerprint"]
    verification={"status":"PASS", "all_22870_IDs_and_labels_preserved":True,
                  "test_ARG_subtypes":820, "model_train_ARG_subtypes":820,
                  "n2_ARG_subtypes_train1_test1":len(n2), "test_fraction":len(te)/len(old),
                  "literal_sequence_cross_split_overlap":seq_report, "input_files_unchanged":True,
                  "repeat_run_same_fingerprint":True}
    (out/"independent_validation.json").write_text(json.dumps(verification,indent=2),encoding="utf-8")
    print(json.dumps(verification,indent=2))


if __name__=="__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(AllocationTests))
    if not result.wasSuccessful():
        raise SystemExit(1)
    independent_check()
