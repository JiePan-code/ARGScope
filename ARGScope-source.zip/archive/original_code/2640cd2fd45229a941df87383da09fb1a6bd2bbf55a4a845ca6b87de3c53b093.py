"""Copy validated artifacts to new user-facing folders without replacing old work."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs/argscope_including_nonARG_20260922'
ROOT=Path(r'E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW')
DEST=ROOT/'Including_nonARG_20260922'
DESKTOP=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写')
DOCNAME='Supplementary_materials_including_nonARG_20260922.docx'
FIGS=OUT/'Figure2_Figure3_SVG'
DESKTOP_FIGS=DESKTOP/'result图片/Figure2_Figure3_含nonARG_透明SVG_20260922'
ZIPNAME='Figure2_Figure3_including_nonARG_SVG_20260922.zip'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def copy_new(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert sha(source)==sha(target),f'Refusing to overwrite a different file: {target}'
    else:
        shutil.copy2(source,target)
    assert sha(source)==sha(target)

def tree(source,target):
    for source_file in source.rglob('*'):
        if source_file.is_file():copy_new(source_file,target/source_file.relative_to(source))

def main():
    assert json.loads((OUT/'data/release_metric_verification.json').read_text())['heatmap_every_cell_verified']
    assert json.loads((OUT/'qa_docx/render_verification.json').read_text())['actual_docx_numeric_cells_verified']==750
    assert len(json.loads((OUT/'qa_svg/svg_render_verification.json').read_text()))==28
    for folder in ['Figure2_Protein','Figure3_DNA']:
        assert len(list((FIGS/folder).glob('*.svg')))==7
    # Flat package contains only the requested SVG variants, plot values and guide.
    zip_path=OUT/ZIPNAME
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
        archive.write(OUT/'README.md','README.md')
        for folder in ['Figure2_Protein','Figure3_DNA','editable_text','plot_data']:
            for source in sorted((FIGS/folder).rglob('*')):
                if source.is_file():archive.write(source,source.relative_to(FIGS))
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        assert len([name for name in archive.namelist() if name.endswith('.svg')])==28
    # Comprehensive result archive includes the numerical audit, figures and DOCX.
    tree(OUT/'data',DEST/'data')
    tree(FIGS,DEST/'Figure2_Figure3_SVG')
    for name in [DOCNAME,ZIPNAME,'README.md']:copy_new(OUT/name,DEST/name)
    for file in [OUT/'qa_docx/render_verification.json',OUT/'qa_svg/svg_render_verification.json']:
        copy_new(file,DEST/'verification'/file.name)
    # Preserve executable sources together. They still refer to the original input locations.
    for name in ['recalculate_argscope_including_nonarg.py','plot_argscope_including_nonarg.py',
                 'plot_argscope_all_panels_transparent.py','update_supplement_including_nonarg.py',
                 'verify_including_nonarg_metrics.py','verify_including_nonarg_document.py',
                 'verify_including_nonarg_svg.cjs','export_docx_for_qa.ps1']:
        copy_new(HERE/name,DEST/'code_snapshot'/name)
    for name in ['rebuild_all_results.py','strict_type_names.py']:
        copy_new(ROOT/name,DEST/'code_snapshot/original_helpers'/name)
    # Manuscript-adjacent copies for easy replacement while assembling figures.
    copy_new(OUT/DOCNAME,DESKTOP/DOCNAME)
    for folder in ['Figure2_Protein','Figure3_DNA','editable_text','plot_data']:
        tree(FIGS/folder,DESKTOP_FIGS/folder)
    copy_new(OUT/'README.md',DESKTOP_FIGS/'README.md')
    copy_new(zip_path,DESKTOP_FIGS/ZIPNAME)
    result={'results_folder':str(DEST),'supplementary_materials':str(DESKTOP/DOCNAME),
            'figure_folder':str(DESKTOP_FIGS),'figure_zip':str(DESKTOP_FIGS/ZIPNAME),
            'primary_svg_panels':14,'editable_alternatives':14,'originals_preserved':True,
            'docx_sha256':sha(DESKTOP/DOCNAME),'zip_sha256':sha(DESKTOP_FIGS/ZIPNAME)}
    (OUT/'delivery_receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    copy_new(OUT/'delivery_receipt.json',DEST/'delivery_receipt.json')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
