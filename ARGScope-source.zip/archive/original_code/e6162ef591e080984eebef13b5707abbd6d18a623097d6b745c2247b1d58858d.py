#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create an approximately 80:20 split without changing the selected population.

Standard library only. Protein-identical OR DNA-identical records are inseparable.
No model predictions, probabilities, losses or old scores enter the allocation.
Old inputs and model artifacts are never overwritten. See README in the output.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import heapq
import json
import random
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

VERSION = "argscope-80-20-exact-sequence-grouped-v1"
HERE = Path(__file__).resolve().parent
DEFAULT_FASTA_DIR = Path(r"E:\1. ARGmodel\1. NonARG_training\1. Dataset\最后的数据集\2. ARG_nonARG_dataset")


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_ids(path):
    ids = [s.strip() for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]
    if not ids or len(ids) != len(set(ids)):
        raise ValueError(f"Empty or duplicate IDs: {path}")
    return set(ids)


def read_structure(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    required = {"SARG.Seq.ID", "Type", "Subtype", "ARG.or.nonARG"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError("Structure table schema is not recognized")
    result = {}
    for r in rows:
        row = {k: v.strip() for k, v in r.items()}
        sid = row["SARG.Seq.ID"]
        if sid in result or any(not row[k] for k in required):
            raise ValueError(f"Duplicate ID or empty label in structure: {sid}")
        if row["ARG.or.nonARG"] not in ("ARG", "nonARG"):
            raise ValueError(f"Unexpected binary label: {sid}")
        result[sid] = row
    return result


def read_fasta(path):
    records = {}
    sid, pieces = None, []

    def finish():
        if sid is None:
            return
        seq = "".join(pieces).upper()
        if sid in records or not seq:
            raise ValueError(f"Duplicate FASTA ID or empty sequence: {sid}")
        records[sid] = (hashlib.sha256(seq.encode("ascii")).hexdigest(), len(seq))

    with Path(path).open(encoding="utf-8-sig") as f:
        for line in f:
            if line.startswith(">"):
                finish()
                sid, pieces = line[1:].split()[0], []
            elif line.strip():
                if sid is None:
                    raise ValueError(f"Sequence before first FASTA header: {path}")
                pieces.append("".join(line.split()))
    finish()
    return records


def group_sequences(ids, labels, protein, dna):
    """Transitive union: equal protein OR equal DNA implies the same group."""
    parent = {sid: sid for sid in ids}

    def find(sid):
        while parent[sid] != sid:
            parent[sid] = parent[parent[sid]]
            sid = parent[sid]
        return sid

    for sequences in (protein, dna):
        first = {}
        for sid in sorted(ids):
            h = sequences[sid][0]
            if h in first:
                a, b = sorted((find(sid), find(first[h])))
                parent[b] = a
            else:
                first[h] = sid
    grouped = defaultdict(list)
    for sid in sorted(ids):
        grouped[find(sid)].append(sid)
    groups = []
    for members in grouped.values():
        categories = {(labels[s]["ARG.or.nonARG"], labels[s]["Type"], labels[s]["Subtype"]) for s in members}
        if len(categories) != 1:
            raise ValueError(f"Sequence-identical group has conflicting labels: {members[:5]}")
        groups.append(tuple(members))
    return sorted(groups)


def quotas(sizes, lower, upper, fraction, budget):
    """Constrained integer allocation closest to fraction*n, at exact total budget.

    Squared count deviation is minimized by successive smallest marginal costs.
    Tie-breaking is by stable label, not by any observed model result.
    """
    if not sum(lower.values()) <= budget <= sum(upper.values()):
        raise ValueError(f"Requested total {budget} incompatible with subtype bounds "
                         f"[{sum(lower.values())}, {sum(upper.values())}]")
    result = dict(lower)
    heap = []
    for label in sorted(sizes):
        if result[label] < upper[label]:
            cost = 2 * (result[label] - sizes[label] * fraction) + 1
            heapq.heappush(heap, (cost, label))
    for _ in range(budget - sum(result.values())):
        _, label = heapq.heappop(heap)
        result[label] += 1
        if result[label] < upper[label]:
            cost = 2 * (result[label] - sizes[label] * fraction) + 1
            heapq.heappush(heap, (cost, label))
    return result


def select_groups(groups, budget, seed, key):
    """Exact subset sum with seeded group order, using a bitset and predecessors."""
    if budget == 0:
        return set()
    ordered = sorted(groups)
    stable_seed = int.from_bytes(hashlib.sha256(f"{seed}|{key}".encode()).digest()[:8], "big")
    random.Random(stable_seed).shuffle(ordered)
    reachable = 1
    mask = (1 << (budget + 1)) - 1
    previous = {}
    for i, group in enumerate(ordered):
        weight = len(group)
        new = ((reachable << weight) & mask) & ~reachable
        states = new
        while states:
            bit = states & -states
            state = bit.bit_length() - 1
            previous[state] = (state - weight, i)
            states ^= bit
        reachable |= new
        if (reachable >> budget) & 1:
            result, remaining = set(), budget
            while remaining:
                remaining, idx = previous[remaining]
                result.update(ordered[idx])
            return result
    raise ValueError(f"Cannot allocate {budget} records without splitting an identical-sequence group: {key}")


def allocate(groups, labels, fraction, seed, stage):
    """Allocate separately by ARG/nonARG, then subtype, preserving train coverage."""
    buckets = defaultdict(list)
    for group in groups:
        r = labels[group[0]]
        buckets[(r["ARG.or.nonARG"], r["Subtype"])].append(group)
    selected = set()
    budgets = {}
    for binary in ("ARG", "nonARG"):
        subset = {s: g for (b, s), g in buckets.items() if b == binary}
        sizes = {s: sum(map(len, g)) for s, g in subset.items()}
        if not sizes:
            raise ValueError(f"Missing binary class: {binary}")
        # Two independent groups: keep at least one on each side. A single
        # inseparable group stays in training and is recorded as an exception.
        lower = {s: min(map(len, g)) if len(g) >= 2 else 0 for s, g in subset.items()}
        upper = {s: sizes[s] - min(map(len, g)) if len(g) >= 2 else 0 for s, g in subset.items()}
        target = int(sum(sizes.values()) * fraction + 0.5)
        allocation = quotas(sizes, lower, upper, fraction, target)
        for subtype in sorted(subset):
            selected.update(select_groups(subset[subtype], allocation[subtype], seed,
                                          f"{stage}|{binary}|{subtype}"))
        budgets[binary] = target
    return selected, budgets


def partition(groups, labels, test_fraction=.2, validation_fraction=.2, seed=20260822):
    ids = {sid for g in groups for sid in g}
    test, test_budget = allocate(groups, labels, test_fraction, seed, "test")
    external_train = ids - test
    train_groups = [g for g in groups if g[0] in external_train]
    validation, val_budget = allocate(train_groups, labels, validation_fraction, seed, "validation")
    model_train = external_train - validation
    return {"train": model_train, "validation": validation, "test": test}, test_budget, val_budget


def verify(splits, population, labels, protein, dna, test_fraction):
    tr, va, te = (splits[k] for k in ("train", "validation", "test"))
    if tr & va or tr & te or va & te or (tr | va | te) != population:
        raise ValueError("Split ID overlap or lost/added IDs")
    observed = len(te) / len(population)
    if abs(observed - test_fraction) > .005:
        raise ValueError("Global test ratio differs from requested ratio by more than 0.5 percentage points")
    overlap = {}
    for name, source in (("Protein", protein), ("DNA", dna)):
        hashes = {s: {source[sid][0] for sid in ids} for s, ids in splits.items()}
        overlap[name] = {f"{a}_vs_{b}": len(hashes[a] & hashes[b])
                         for a, b in (("train", "test"), ("validation", "test"), ("train", "validation"))}
        if any(overlap[name].values()):
            raise ValueError(f"Exact {name} sequence crosses split boundaries")
    all_subtypes = {labels[s]["Subtype"] for s in population}
    missing_train = all_subtypes - {labels[s]["Subtype"] for s in tr}
    arg_subtypes = {labels[s]["Subtype"] for s in population if labels[s]["ARG.or.nonARG"] == "ARG"}
    test_arg_subtypes = {labels[s]["Subtype"] for s in te if labels[s]["ARG.or.nonARG"] == "ARG"}
    if arg_subtypes - test_arg_subtypes:
        raise ValueError(f"Test must cover EVERY input ARG subtype: {sorted(arg_subtypes - test_arg_subtypes)}")
    all_types = {labels[s]["Type"] for s in population}
    missing_test_types = all_types - {labels[s]["Type"] for s in te}
    if missing_train or missing_test_types:
        raise ValueError(f"Missing training subtypes {missing_train} or test types {missing_test_types}")
    return {"test_fraction": observed, "ID_overlap": 0, "exact_sequence_overlap": overlap,
            "all_input_IDs_preserved": True, "all_subtypes_in_model_train": True,
            "all_types_in_train_and_test": True, "ARG_subtypes_in_test": len(test_arg_subtypes),
            "ARG_subtypes_in_model_train": len({labels[s]["Subtype"] for s in tr if labels[s]["ARG.or.nonARG"] == "ARG"})}


def write_ids(path, ids):
    Path(path).write_text("\n".join(sorted(ids)) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def build(args):
    root = args.data_root.resolve()
    source_ids = [args.population_ids] if args.population_ids else [root / "train_ids_subtype2.txt", root / "test_ids_subtype2.txt"]
    populations = [read_ids(p) for p in source_ids]
    if len(populations) == 2 and populations[0] & populations[1]:
        raise ValueError("Old external train/test overlap; population must be resolved first")
    population = set.union(*populations)
    structure = root / "all_ARG_nonARG_1to1_structure.txt"
    inputs = [*source_ids, structure, args.protein_fasta, args.dna_fasta]
    before_hashes = {str(p.resolve()): file_hash(p) for p in inputs}
    labels = read_structure(structure)
    protein, dna = read_fasta(args.protein_fasta), read_fasta(args.dna_fasta)
    if population - labels.keys() or population - protein.keys() or population - dna.keys():
        raise ValueError("Selected IDs missing from structure or paired FASTA")
    n_arg_subtypes = len({labels[s]["Subtype"] for s in population if labels[s]["ARG.or.nonARG"] == "ARG"})
    if n_arg_subtypes != args.expected_arg_subtypes:
        raise ValueError(f"Expected {args.expected_arg_subtypes} ARG subtypes in the selected population, got {n_arg_subtypes}")
    for sid in population:
        for source, col in ((protein, "Protein.Length.aa"), (dna, "DNA.Length.nt")):
            if source[sid][1] != int(labels[sid][col]):
                raise ValueError(f"FASTA/structure length mismatch: {sid}")
    groups = group_sequences(population, labels, protein, dna)
    splits, test_budget, val_budget = partition(groups, labels, args.test_fraction, args.validation_fraction, args.seed)
    audit = verify(splits, population, labels, protein, dna, args.test_fraction)
    state = {sid: split for split, ids in splits.items() for sid in ids}
    group_ids = {sid: "g_" + hashlib.sha256("\n".join(g).encode()).hexdigest()
                 for g in groups for sid in g}
    manifest = [{"sequence_id": sid, "Subtype": labels[sid]["Subtype"], "Type": labels[sid]["Type"],
                 "ARG_or_nonARG": labels[sid]["ARG.or.nonARG"],
                 "external_split": "test" if state[sid] == "test" else "train", "model_split": state[sid],
                 "sequence_group": group_ids[sid], "protein_sha256": protein[sid][0], "dna_sha256": dna[sid][0]}
                for sid in sorted(population)]
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    fingerprint = hashlib.sha256(canonical.encode()).hexdigest()
    subtype_summary = []
    by_subtype = defaultdict(list)
    for sid in sorted(population):
        by_subtype[labels[sid]["Subtype"]].append(sid)
    for subtype, ids in sorted(by_subtype.items()):
        n = len(ids)
        count = Counter(state[s] for s in ids)
        n_groups = len({group_ids[s] for s in ids})
        subtype_summary.append({"Subtype": subtype, "Type": labels[ids[0]]["Type"], "N": n,
                                "independent_sequence_groups": n_groups,
                                "external_train": count["train"] + count["validation"],
                                "model_train": count["train"], "validation": count["validation"], "test": count["test"],
                                "test_fraction": count["test"] / n,
                                "coverage_exception": "single_sequence_group_train_only" if n_groups == 1 else ""})
    type_summary = []
    for typ in sorted({labels[s]["Type"] for s in population}):
        ids = [s for s in population if labels[s]["Type"] == typ]
        c = Counter(state[s] for s in ids)
        type_summary.append({"Type": typ, "N": len(ids), "external_train": c["train"] + c["validation"],
                             "model_train": c["train"], "validation": c["validation"], "test": c["test"]})
    counts = {s: {"total": len(ids), **Counter(labels[x]["ARG.or.nonARG"] for x in ids)} for s, ids in splits.items()}
    external_train = splits["train"] | splits["validation"]
    counts["external_train"] = {"total": len(external_train), **Counter(labels[x]["ARG.or.nonARG"] for x in external_train)}
    output = args.output_dir or root / "split_80_20_grouped"
    if output.exists():
        if args.output_dir is not None:
            raise FileExistsError(f"Refusing to overwrite existing output: {output}")
        output = output.with_name(output.name + "_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    # Validate everything before creating a new output directory.
    if before_hashes != {str(p.resolve()): file_hash(p) for p in inputs}:
        raise ValueError("Source changed during split generation")
    output.mkdir(parents=True, exist_ok=False)
    write_ids(output / "population_ids.txt", population)
    write_ids(output / "train_ids_subtype2.txt", external_train)
    write_ids(output / "test_ids_subtype2.txt", splits["test"])
    write_ids(output / "model_train_ids.txt", splits["train"])
    write_ids(output / "validation_ids.txt", splits["validation"])
    write_csv(output / "split_manifest.csv", manifest)
    write_csv(output / "subtype_split_summary.csv", subtype_summary)
    write_csv(output / "type_split_summary.csv", type_summary)
    report = {"schema": VERSION, "seed": args.seed, "requested_test_fraction": args.test_fraction,
              "validation_fraction_of_external_train": args.validation_fraction,
              "selected_population_N": len(population), "counts": counts,
              "test_class_budgets": test_budget, "validation_class_budgets": val_budget,
              "source_sha256": before_hashes, "split_fingerprint": fingerprint,
              "verification": audit, "sequence_group_sizes": dict(Counter(map(len, groups))),
              "subtypes_total_including_nonARG": len(by_subtype),
              "subtypes_absent_from_test": [r["Subtype"] for r in subtype_summary if not r["test"]],
              "subtypes_absent_from_validation": [r["Subtype"] for r in subtype_summary if not r["validation"]],
              "grouping": "Connected components of exact protein OR exact DNA identity; uppercase, no whitespace, stop characters retained",
              "allocation": "Global 20 percent by binary class; integer subtype allocation minimizing squared count deviation subject to coverage; seeded group sampling",
              "not_checked": ["sequence homology", "reverse-complement DNA identity", "model training"],
              "old_artifacts_compatible": False,
              "training_entrypoints_switched": False}
    report["output_sha256"] = {p.name: file_hash(p) for p in output.iterdir() if p.is_file()}
    (output / "split_contract.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "README_先看这里.txt").write_text(
        "新划分已经生成，旧划分、旧模型和旧结果均未覆盖。\n\n"
        f"样本总数 {len(population)}；external train {len(external_train)}；test {len(splits['test'])}。\n"
        f"external train 内部再分：model train {len(splits['train'])}；validation {len(splits['validation'])}。\n"
        "8:2 指 external train:test；validation 从前者内部划出，不是另外增加的样本。\n\n"
        "规则\n"
        "1. 保留旧 train_ids_subtype2 与 test_ids_subtype2 的并集，不增删样本或修改标签。\n"
        "2. 总体 train:test 约8:2优先，ARG/nonARG分别分配20%测试名额。\n"
        "3. 每个ARG subtype必须同时进入model train和test；测试集强制覆盖820个ARG subtype（nonARG另算一类）。\n"
        "   如果只有一个不可拆分的序列组，代码会报错，不会悄悄丢掉测试类别或把相同序列拆到两侧。\n"
        "4. 当前两条样本的ARG subtype各1条train/test；>=3条不固定2:1，按总体20%预算分配。\n"
        "5. 相同protein或DNA全长序列的ID作为不可拆分组，组的传递关联也不拆分。\n"
        "6. validation仅从external train取，比例约20%，仍保留每类至少一个model-train组。\n"
        "7. seed=20260822。没有使用预测结果、损失或测试分数来选择新划分。\n\n"
        "文件\n"
        "train_ids_subtype2.txt 是 external train（含validation），不是实际梯度训练名单。\n"
        "model_train_ids.txt 是实际训练名单；validation_ids.txt 是固定验证名单。\n"
        "test_ids_subtype2.txt 是固定测试名单；split_manifest.csv 是逐序列唯一划分依据。\n"
        "population_ids.txt 保存这次的固定样本全集，重新运行代码时优先使用它。\n\n"
        "下一步注意\n"
        "本次仅重新划分，尚未切换旧训练入口，未启动训练。不要直接运行原来的bat并认为已使用新划分。\n"
        "旧训练代码会自行重新切validation，必须改为统一读取本目录的固定model_split。\n"
        "Full和所有消融必须使用同一个新manifest。旧融合、prototype、GAT、teacher、student产物不能作为新划分产物复用。\n"
        "基础预训练模型的无监督逐序列embedding是否可复用，应确认其未使用旧划分监督训练后再决定。\n"
        "若要公平比较，须在新划分上重新训练和计算Full及消融；不能沿用补充材料中旧Full数值。\n"
        "本次只保证ID及完全相同的protein/DNA不跨集合，未做同源聚类。\n",
        encoding="utf-8-sig")
    return output, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    detected = next((p for p in (HERE, HERE.parent) if (p / "all_ARG_nonARG_1to1_structure.txt").is_file()), None)
    parser.add_argument("--data-root", type=Path, default=detected)
    parser.add_argument("--population-ids", type=Path, default=HERE / "population_ids.txt" if (HERE / "population_ids.txt").is_file() else None)
    parser.add_argument("--protein-fasta", type=Path, default=DEFAULT_FASTA_DIR / "all_ARG_nonARG_1to1_protein.fasta")
    parser.add_argument("--dna-fasta", type=Path, default=DEFAULT_FASTA_DIR / "all_ARG_nonARG_1to1_DNA.fasta")
    parser.add_argument("--test-fraction", type=float, default=.2)
    parser.add_argument("--validation-fraction", type=float, default=.2)
    parser.add_argument("--seed", type=int, default=20260822)
    parser.add_argument("--expected-arg-subtypes", type=int, default=820)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    if args.data_root is None:
        parser.error("Please provide --data-root, or put the script beside the structure table or in its child folder")
    if not 0 < args.test_fraction < 1 or not 0 < args.validation_fraction < 1:
        parser.error("Fractions must be between zero and one")
    output, report = build(args)
    print(json.dumps({"output": str(output), "counts": report["counts"], "verification": report["verification"],
                      "missing_test_subtypes": report["subtypes_absent_from_test"], "fingerprint": report["split_fingerprint"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
