#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope vs ARG-OAP vs DeepARG: real-data Type-level comparison
===============================================================

Place this script in the ROOT folder that contains, for example:

ROOT/
├─ ARGScope_DIAMOND_gate010_realdata_predictions/
│  ├─ diamond0.2/
│  │  └─ all_samples_ARG_predictions.csv
│  ├─ diamond0.5/
│  │  └─ all_samples_ARG_predictions.csv
│  └─ ...
├─ ARGScope_DIAMOND_gate020_realdata_predictions/
├─ ARGScope_DIAMOND_gate030_realdata_predictions/
├─ ARGScope_DIAMOND_gate040_realdata_predictions/
├─ ARGScope_DIAMOND_gate050_realdata_predictions/
├─ ARGOAP/
│  └─ unnormalized_count.type.revised.txt
└─ DeepARG_Fast结果/                     # folder name can be different
   ├─ argbert_1.clean.deeparg.mapping.ARG
   ├─ argbert_2.clean.deeparg.mapping.ARG
   └─ ...

What this script does
---------------------
1. Automatically scans ALL ARGScope gate x DIAMOND settings.
2. Reads ARGScope all_samples_ARG_predictions.csv and counts Pred_Type.
3. Reads ARG-OAP unnormalized_count.type.revised.txt.
4. Reads all DeepARG *.clean.deeparg.mapping.ARG files.
5. Canonicalizes Type names into one common vocabulary.
6. Excludes obvious non-Type ARG-OAP rows such as species names / 23S / efflux
   by using an explicit valid resistance-Type vocabulary.
7. Produces BOTH raw counts and within-model relative abundance (%).
8. Computes Type-composition concordance metrics per sample:
      - Spearman correlation
      - Bray-Curtis similarity
      - detected-Type Jaccard similarity
      - Top-5 overlap / Jaccard
9. Produces publication-style figures with ARGScope visually emphasized.

IMPORTANT INTERPRETATION
------------------------
These are real-data Type-composition comparisons, NOT ACC/Precision/Recall,
because there is no per-read ground-truth label for these real samples.

Main figures
------------
A) For EVERY gate x DIAMOND configuration:
   horizontal grouped barplot of mean Type relative abundance across 9 samples.
   All valid detected Types are included (optionally limited by MAX_TYPES_IN_BAR).

B) For EVERY gate x DIAMOND configuration:
   three aligned sample x Type heatmaps (ARGScope / ARG-OAP / DeepARG).

C) Parameter-landscape heatmaps:
   mean ARGScope-vs-ARG-OAP and ARGScope-vs-DeepARG Type-composition similarity.

D) One automatically selected representative setting:
   selected only for visualization using a configurable concordance score.
   The full 30-setting tables are ALWAYS exported, so no result is hidden.

Python 3.8 compatible.
Dependencies: pandas, numpy, matplotlib
"""

from __future__ import print_function

import math
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd


# =============================================================================
# 1. CONFIG
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

OUTDIR = ROOT_DIR / "ARGScope_ARGOAP_DeepARG_Type_level_comparison"
FIG_DIR = OUTDIR / "figures"
FIG_CONFIG_DIR = FIG_DIR / "all_gate_diamond_configurations"
TABLE_DIR = OUTDIR / "tables"

for p in [OUTDIR, FIG_DIR, FIG_CONFIG_DIR, TABLE_DIR]:
    p.mkdir(parents=True, exist_ok=True)

# Files are auto-detected recursively.
ARGSCOPE_FILE_NAME = "all_samples_ARG_predictions.csv"
ARGOAP_FILE_NAME = "unnormalized_count.type.revised.txt"
DEEPARG_PATTERN = "*.clean.deeparg.mapping.ARG"

# Only keep predicted ARG rows in ARGScope if this column exists.
ARGSCOPE_REQUIRE_PRED_ARG = True

# DeepARG: after read-level de-duplication, use `counts` as weight if available.
# If all counts are 1, this is identical to counting rows.
USE_DEEPARG_COUNTS_COLUMN = True

# Relative-abundance comparison is recommended because total ARG counts differ
# strongly between tools.
USE_RELATIVE_ABUNDANCE_FOR_MAIN_FIGURES = True

# Barplots: None = show every valid Type detected by at least one tool.
# Set e.g. 20 if you later want a more compact main figure.
MAX_TYPES_IN_BAR = None

# Heatmaps: retain Types whose mean abundance across all tools/samples is > 0.
MAX_TYPES_IN_HEATMAP = None

# Only used to mark a representative configuration in summary figures.
# It does NOT remove or hide any other gate/DIAMOND result.
# score = mean of ARGScope-vs-ARGOAP and ARGScope-vs-DeepARG Bray-Curtis similarity
AUTO_SELECT_REPRESENTATIVE_CONFIG = True

# Figure output
DPI = 500
SAVE_PDF = True
SAVE_SVG = True

# Visual emphasis: ARGScope is the foreground model.
MODEL_ORDER = ["ARGScope", "ARG-OAP", "DeepARG"]
MODEL_COLORS = {
    "ARGScope": "#C43C39",   # strong red
    "ARG-OAP": "#B7B7B7",    # neutral gray
    "DeepARG": "#5B7FA3",    # muted blue
}

SAMPLE_ORDER_PREFERRED = [
    "argbert_1", "argbert_2", "argbert_3",
    "argscope_1", "argscope_2", "argscope_3",
    "argscope_4", "argscope_5", "argscope_6",
]

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9.5,
    "axes.titlesize": 11.5,
    "axes.labelsize": 10.5,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.fontsize": 9.5,
    "axes.linewidth": 0.9,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 2. CANONICAL TYPE VOCABULARY
# =============================================================================

# Explicit valid ARG resistance-Type vocabulary.
# This prevents species names / gene fragments from ARG-OAP being treated as
# resistance Types. Add extra valid categories here if your database includes them.
VALID_TYPES = [
    "aminoglycoside",
    "antibacterial_fatty_acid",
    "bacitracin",
    "beta_lactam",
    "bicyclomycin",
    "bleomycin",
    "chloramphenicol",
    "defensin",
    "edeine",
    "factumycin",
    "fosfomycin",
    "fusidic_acid",
    "MLS",
    "multidrug",
    "mupirocin",
    "novobiocin",
    "other_peptide_antibiotics",
    "pleuromutilin_tiamulin",
    "polymyxin",
    "puromycin",
    "quinolone",
    "rifamycin",
    "streptothricin",
    "sulfonamide",
    "tetracenomycin_C",
    "tetracycline",
    "trimethoprim",
    "tunicamycin",
    "vancomycin",
]
VALID_TYPE_SET = set(VALID_TYPES)

# Common aliases -> canonical ARGScope-style Type names.
TYPE_ALIASES = {
    # MLS
    "mls": "MLS",
    "macrolide_lincosamide_streptogramin": "MLS",
    "macrolide_lincosamide_streptogramins": "MLS",

    # beta lactam
    "beta_lactam": "beta_lactam",
    "betalactam": "beta_lactam",
    "betalactams": "beta_lactam",
    "beta_lactams": "beta_lactam",

    # quinolone / fluoroquinolone
    "quinolone": "quinolone",
    "quinolones": "quinolone",
    "fluoroquinolone": "quinolone",
    "fluoroquinolones": "quinolone",

    # phenicol
    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "phenicols": "chloramphenicol",
    "florfenicol": "chloramphenicol",

    # glycopeptide
    "glycopeptide": "vancomycin",
    "glycopeptides": "vancomycin",
    "vancomycin": "vancomycin",

    # pleuromutilin
    "pleuromutilin": "pleuromutilin_tiamulin",
    "pleuromutilin_tiamulin": "pleuromutilin_tiamulin",

    # peptide category (distinct from polymyxin)
    "peptide": "other_peptide_antibiotics",
    "other_peptide_antibiotics": "other_peptide_antibiotics",
    "other_peptide_antibiotic": "other_peptide_antibiotics",

    # tetracenomycin
    "tetracenomycin": "tetracenomycin_C",
    "tetracenomycin_c": "tetracenomycin_C",

    # rifamycin
    "rifamycin": "rifamycin",
    "rifampin": "rifamycin",
    "rifampicin": "rifamycin",

    # remaining direct categories
    "aminoglycoside": "aminoglycoside",
    "bacitracin": "bacitracin",
    "bleomycin": "bleomycin",
    "fosfomycin": "fosfomycin",
    "fusidic_acid": "fusidic_acid",
    "multidrug": "multidrug",
    "multi_drug": "multidrug",
    "multi_drug_resistance": "multidrug",
    "mupirocin": "mupirocin",
    "polymyxin": "polymyxin",
    "streptothricin": "streptothricin",
    "sulfonamide": "sulfonamide",
    "tetracycline": "tetracycline",
    "trimethoprim": "trimethoprim",
    "tunicamycin": "tunicamycin",
    "antibacterial_fatty_acid": "antibacterial_fatty_acid",
    "antibacterial_free_fatty_acids": "antibacterial_fatty_acid",
    "bicyclomycin": "bicyclomycin",
    "defensin": "defensin",
    "edeine": "edeine",
    "factumycin": "factumycin",
    "novobiocin": "novobiocin",
    "puromycin": "puromycin",
}

# DeepARG can contain compound class names. These are intentionally conservative.
# Unmapped classes are kept in diagnostics but excluded from the canonical
# resistance-Type comparison unless you add a mapping here.
DEEPARG_SPECIAL_ALIASES = {
    "aminoglycoside_aminocoumarin": "aminoglycoside",
    "aminoglycoside_aminocoumarins": "aminoglycoside",
}


# =============================================================================
# 3. BASIC HELPERS
# =============================================================================

def clean_text(x):
    if pd.isna(x):
        return ""
    return str(x).replace("\ufeff", "").strip()


def token(x):
    s = clean_text(x).lower()
    s = s.replace("%", "pct")
    s = re.sub(r"[\s/\-:]+", "_", s)
    s = re.sub(r"[^a-z0-9_]+", "", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def canonical_type(x, source="generic"):
    raw = clean_text(x)
    t = token(raw)

    if t in TYPE_ALIASES:
        return TYPE_ALIASES[t]

    if source == "DeepARG" and t in DEEPARG_SPECIAL_ALIASES:
        return DEEPARG_SPECIAL_ALIASES[t]

    # Preserve exact canonical spelling if already in whitelist.
    for valid in VALID_TYPES:
        if token(valid) == t:
            return valid

    return raw


def safe_numeric(series, fill_value=0.0):
    return pd.to_numeric(series, errors="coerce").fillna(fill_value)


def sort_samples(values):
    vals = [str(v) for v in values]
    preferred = [s for s in SAMPLE_ORDER_PREFERRED if s in vals]
    rest = sorted(set(vals) - set(preferred))
    return preferred + rest


def format_gate(g):
    return "%.2f" % float(g)


def format_diamond(d):
    return "%.1f" % float(d)


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(s))


def save_figure(fig, base_path):
    base_path = Path(base_path)
    fig.savefig(base_path.with_suffix(".png"), dpi=DPI, bbox_inches="tight", facecolor="white")
    if SAVE_PDF:
        fig.savefig(base_path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    if SAVE_SVG:
        fig.savefig(base_path.with_suffix(".svg"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# =============================================================================
# 4. ARGScope READER
# =============================================================================

def infer_gate_from_path(path):
    text = str(path).lower()
    m = re.search(r"gate(\d+)", text)
    if not m:
        return np.nan
    return int(m.group(1)) / 100.0


def infer_diamond_from_path(path):
    text = str(path).lower()
    m = re.search(r"diamond\s*([01]?\.\d+)", text)
    if not m:
        return np.nan
    return float(m.group(1))


def parse_diamond_value(x):
    s = clean_text(x).lower()
    m = re.search(r"([01]?\.\d+)", s)
    if m:
        return float(m.group(1))
    try:
        return float(s)
    except Exception:
        return np.nan


def read_argscope_one_file(path):
    gate = infer_gate_from_path(path)
    diamond_path = infer_diamond_from_path(path.parent)

    usecols_candidates = [
        "diamond_threshold", "sample_name", "read_id", "Pred_ARG", "Pred_Type",
        "gate_probability", "subtype_probability_among_ARG_classes",
    ]

    # Read header first because some older files may not contain every column.
    header = pd.read_csv(path, nrows=0, encoding="utf-8-sig")
    available = [c for c in usecols_candidates if c in header.columns]

    required = {"sample_name", "read_id", "Pred_Type"}
    if not required.issubset(set(available)):
        raise ValueError(
            "ARGScope file missing required columns %s: %s" %
            (sorted(required - set(available)), path)
        )

    df = pd.read_csv(path, usecols=available, encoding="utf-8-sig", low_memory=False)

    # If file is inside diamond0.x, keep only that threshold when column exists.
    if "diamond_threshold" in df.columns:
        df["diamond_num"] = df["diamond_threshold"].map(parse_diamond_value)
        if np.isfinite(diamond_path):
            df = df[np.isclose(df["diamond_num"], diamond_path, atol=1e-9)].copy()
    else:
        df["diamond_num"] = diamond_path

    if ARGSCOPE_REQUIRE_PRED_ARG and "Pred_ARG" in df.columns:
        df = df[df["Pred_ARG"].astype(str).str.upper().eq("ARG")].copy()

    df["sample_name"] = df["sample_name"].astype(str).str.strip()
    df["read_id"] = df["read_id"].astype(str).str.strip()
    df["canonical_type"] = df["Pred_Type"].map(lambda x: canonical_type(x, "ARGScope"))

    # Exclude nonARG, Unknown, and non-canonical categories.
    df = df[df["canonical_type"].isin(VALID_TYPE_SET)].copy()

    # Read-level de-duplication.
    sort_cols = []
    ascending = []
    if "gate_probability" in df.columns:
        df["gate_probability"] = safe_numeric(df["gate_probability"], -1.0)
        sort_cols.append("gate_probability")
        ascending.append(False)
    if "subtype_probability_among_ARG_classes" in df.columns:
        df["subtype_probability_among_ARG_classes"] = safe_numeric(
            df["subtype_probability_among_ARG_classes"], -1.0
        )
        sort_cols.append("subtype_probability_among_ARG_classes")
        ascending.append(False)

    if sort_cols:
        df = df.sort_values(sort_cols, ascending=ascending)

    df = df.drop_duplicates(subset=["sample_name", "read_id"], keep="first")

    rows = (
        df.groupby(["sample_name", "canonical_type"], as_index=False)
        .size()
        .rename(columns={"size": "count"})
    )

    rows["gate"] = gate
    if np.isfinite(diamond_path):
        rows["diamond"] = diamond_path
    else:
        # Normally one file corresponds to one diamond. Fallback uses the first
        # observed value; if multiple exist, caller should have separate files.
        uniq = sorted(df["diamond_num"].dropna().unique().tolist())
        rows["diamond"] = uniq[0] if len(uniq) == 1 else np.nan
    rows["model"] = "ARGScope"
    rows["source_file"] = str(path)
    return rows, df


def scan_argscope(root):
    files = []
    for path in root.rglob(ARGSCOPE_FILE_NAME):
        if OUTDIR in path.parents:
            continue
        if "ARGScope_DIAMOND_gate" not in str(path):
            continue
        files.append(path)
    files = sorted(set(files))

    if not files:
        raise FileNotFoundError("No ARGScope %s found under %s" % (ARGSCOPE_FILE_NAME, root))

    all_rows = []
    diagnostics = []

    print("\n[ARGScope] files found:", len(files))
    for i, path in enumerate(files, 1):
        try:
            rows, raw_filtered = read_argscope_one_file(path)
            all_rows.append(rows)
            diagnostics.append({
                "file": str(path.relative_to(root)),
                "ok": True,
                "gate": infer_gate_from_path(path),
                "diamond": infer_diamond_from_path(path.parent),
                "ARG_reads_after_filter_and_dedup": len(raw_filtered),
                "type_rows": len(rows),
                "error": "",
            })
            print("  [%02d/%02d] gate=%s diamond=%s rows=%d" % (
                i, len(files),
                format_gate(infer_gate_from_path(path)),
                format_diamond(infer_diamond_from_path(path.parent)),
                len(raw_filtered),
            ))
        except Exception as e:
            diagnostics.append({
                "file": str(path.relative_to(root)),
                "ok": False,
                "gate": infer_gate_from_path(path),
                "diamond": infer_diamond_from_path(path.parent),
                "ARG_reads_after_filter_and_dedup": 0,
                "type_rows": 0,
                "error": "%s: %s" % (type(e).__name__, e),
            })
            print("  [SKIP]", path, repr(e))

    if not all_rows:
        raise RuntimeError("All ARGScope files failed to parse.")

    out = pd.concat(all_rows, ignore_index=True)
    out = (
        out.groupby(["gate", "diamond", "sample_name", "canonical_type", "model"], as_index=False)
        .agg(count=("count", "sum"), source_file=("source_file", "first"))
    )

    pd.DataFrame(diagnostics).to_csv(
        TABLE_DIR / "ARGScope_file_diagnostics.csv", index=False, encoding="utf-8-sig"
    )
    out.to_csv(TABLE_DIR / "ARGScope_type_counts_all_settings.csv", index=False, encoding="utf-8-sig")
    return out


# =============================================================================
# 5. ARG-OAP READER
# =============================================================================

def find_argoap_file(root):
    candidates = [p for p in root.rglob(ARGOAP_FILE_NAME) if OUTDIR not in p.parents]
    if not candidates:
        raise FileNotFoundError("Cannot find %s under %s" % (ARGOAP_FILE_NAME, root))
    # Prefer file under a folder whose name contains ARGOAP.
    candidates = sorted(candidates, key=lambda p: ("argoap" not in str(p).lower(), len(str(p))))
    return candidates[0]


def read_argoap(root):
    path = find_argoap_file(root)
    print("\n[ARG-OAP]", path)

    df = pd.read_csv(path, sep="\t", encoding="utf-8-sig")
    if df.shape[1] < 2:
        raise ValueError("ARG-OAP file has fewer than 2 columns: %s" % path)

    type_col = df.columns[0]
    df["canonical_type"] = df[type_col].map(lambda x: canonical_type(x, "ARG-OAP"))

    # Diagnostic: rows excluded because they are not canonical resistance Types.
    excluded = df[~df["canonical_type"].isin(VALID_TYPE_SET)][[type_col, "canonical_type"]].copy()
    excluded.to_csv(TABLE_DIR / "ARGOAP_excluded_noncanonical_rows.csv", index=False, encoding="utf-8-sig")

    df = df[df["canonical_type"].isin(VALID_TYPE_SET)].copy()
    sample_cols = [c for c in df.columns if c not in {type_col, "canonical_type"}]

    long_df = df.melt(
        id_vars=["canonical_type"], value_vars=sample_cols,
        var_name="sample_name", value_name="count"
    )
    long_df["count"] = safe_numeric(long_df["count"], 0.0)
    long_df["sample_name"] = long_df["sample_name"].astype(str).str.strip()
    long_df["model"] = "ARG-OAP"
    long_df["source_file"] = str(path)

    long_df = (
        long_df.groupby(["sample_name", "canonical_type", "model"], as_index=False)
        .agg(count=("count", "sum"), source_file=("source_file", "first"))
    )
    long_df.to_csv(TABLE_DIR / "ARGOAP_type_counts.csv", index=False, encoding="utf-8-sig")
    return long_df


# =============================================================================
# 6. DeepARG READER
# =============================================================================

def sample_name_from_deeparg_file(path):
    name = path.name
    suffix = ".clean.deeparg.mapping.ARG"
    if name.endswith(suffix):
        return name[:-len(suffix)]
    m = re.search(r"(argbert_\d+|argscope_\d+)", name, flags=re.I)
    if m:
        return m.group(1).lower()
    return path.stem


def read_one_deeparg(path):
    sample = sample_name_from_deeparg_file(path)
    try:
        df = pd.read_csv(path, sep="\t", encoding="utf-8-sig")
    except pd.errors.EmptyDataError:
        return pd.DataFrame(columns=["sample_name", "canonical_type", "count", "model", "source_file"]), []

    required = {"read_id", "predicted_ARG-class"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError("DeepARG file missing %s: %s" % (sorted(missing), path))

    df["read_id"] = df["read_id"].astype(str).str.strip()
    df["predicted_ARG-class"] = df["predicted_ARG-class"].astype(str).str.strip()

    # Best hit per read, consistent with the user's earlier evaluation logic.
    sort_cols = []
    asc = []
    if "probability" in df.columns:
        df["probability"] = safe_numeric(df["probability"], -1.0)
        sort_cols.append("probability")
        asc.append(False)
    if "alignment-bitscore" in df.columns:
        df["alignment-bitscore"] = safe_numeric(df["alignment-bitscore"], -1.0)
        sort_cols.append("alignment-bitscore")
        asc.append(False)
    if sort_cols:
        df = df.sort_values(sort_cols, ascending=asc)
    df = df.drop_duplicates(subset=["read_id"], keep="first").copy()

    df["canonical_type"] = df["predicted_ARG-class"].map(lambda x: canonical_type(x, "DeepARG"))

    unmapped = sorted(set(
        df.loc[~df["canonical_type"].isin(VALID_TYPE_SET), "predicted_ARG-class"].astype(str).tolist()
    ))

    df = df[df["canonical_type"].isin(VALID_TYPE_SET)].copy()

    if USE_DEEPARG_COUNTS_COLUMN and "counts" in df.columns:
        df["weight"] = safe_numeric(df["counts"], 1.0)
        # zero / negative count is not useful as abundance weight.
        df.loc[df["weight"] <= 0, "weight"] = 1.0
    else:
        df["weight"] = 1.0

    out = (
        df.groupby("canonical_type", as_index=False)["weight"]
        .sum()
        .rename(columns={"weight": "count"})
    )
    out["sample_name"] = sample
    out["model"] = "DeepARG"
    out["source_file"] = str(path)
    out = out[["sample_name", "canonical_type", "count", "model", "source_file"]]
    return out, unmapped


def scan_deeparg(root):
    files = [p for p in root.rglob(DEEPARG_PATTERN) if OUTDIR not in p.parents]
    files = sorted(set(files))
    if not files:
        raise FileNotFoundError("No DeepARG files matching %s under %s" % (DEEPARG_PATTERN, root))

    print("\n[DeepARG] files found:", len(files))
    parts = []
    diag = []
    for i, path in enumerate(files, 1):
        try:
            out, unmapped = read_one_deeparg(path)
            parts.append(out)
            diag.append({
                "file": str(path.relative_to(root)),
                "sample_name": sample_name_from_deeparg_file(path),
                "ok": True,
                "canonical_type_rows": len(out),
                "unmapped_classes": ";".join(unmapped),
                "error": "",
            })
            print("  [%02d/%02d] %-12s Type rows=%d" % (
                i, len(files), sample_name_from_deeparg_file(path), len(out)
            ))
        except Exception as e:
            diag.append({
                "file": str(path.relative_to(root)),
                "sample_name": sample_name_from_deeparg_file(path),
                "ok": False,
                "canonical_type_rows": 0,
                "unmapped_classes": "",
                "error": "%s: %s" % (type(e).__name__, e),
            })
            print("  [SKIP]", path, repr(e))

    if not parts:
        raise RuntimeError("All DeepARG files failed to parse.")

    out = pd.concat(parts, ignore_index=True)
    out = (
        out.groupby(["sample_name", "canonical_type", "model"], as_index=False)
        .agg(count=("count", "sum"), source_file=("source_file", "first"))
    )
    out.to_csv(TABLE_DIR / "DeepARG_type_counts.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(diag).to_csv(TABLE_DIR / "DeepARG_file_diagnostics.csv", index=False, encoding="utf-8-sig")
    return out


# =============================================================================
# 7. ALIGN MODELS AND CALCULATE RELATIVE ABUNDANCE
# =============================================================================

def complete_reference_table(ref_df, samples):
    idx = pd.MultiIndex.from_product(
        [samples, VALID_TYPES], names=["sample_name", "canonical_type"]
    )
    x = ref_df.set_index(["sample_name", "canonical_type"])["count"].reindex(idx, fill_value=0.0)
    out = x.reset_index(name="count")
    out["model"] = ref_df["model"].iloc[0]
    return out


def complete_argscope_config(df, samples, gate, diamond):
    idx = pd.MultiIndex.from_product(
        [samples, VALID_TYPES], names=["sample_name", "canonical_type"]
    )
    sub = df[
        np.isclose(df["gate"].astype(float), float(gate)) &
        np.isclose(df["diamond"].astype(float), float(diamond))
    ].copy()
    x = sub.set_index(["sample_name", "canonical_type"])["count"].reindex(idx, fill_value=0.0)
    out = x.reset_index(name="count")
    out["model"] = "ARGScope"
    out["gate"] = float(gate)
    out["diamond"] = float(diamond)
    return out


def add_relative_abundance(df):
    df = df.copy()
    totals = df.groupby(["gate", "diamond", "sample_name", "model"])["count"].transform("sum")
    df["total_valid_type_count"] = totals
    df["relative_abundance"] = np.where(totals > 0, df["count"] / totals, 0.0)
    df["relative_abundance_pct"] = 100.0 * df["relative_abundance"]
    return df


def build_all_aligned(argscope_df, argoap_df, deeparg_df):
    samples = sort_samples(
        sorted(
            set(argscope_df["sample_name"].astype(str))
            | set(argoap_df["sample_name"].astype(str))
            | set(deeparg_df["sample_name"].astype(str))
        )
    )

    # Use sample intersection for quantitative concordance, but export sample
    # coverage so missing samples are explicit.
    argscope_samples = set(argscope_df["sample_name"].astype(str))
    argoap_samples = set(argoap_df["sample_name"].astype(str))
    deeparg_samples = set(deeparg_df["sample_name"].astype(str))

    coverage_rows = []
    for s in samples:
        coverage_rows.append({
            "sample_name": s,
            "ARGScope": int(s in argscope_samples),
            "ARG-OAP": int(s in argoap_samples),
            "DeepARG": int(s in deeparg_samples),
            "available_all_three": int(s in argscope_samples and s in argoap_samples and s in deeparg_samples),
        })
    pd.DataFrame(coverage_rows).to_csv(
        TABLE_DIR / "sample_model_coverage.csv", index=False, encoding="utf-8-sig"
    )

    common_samples = [
        s for s in samples
        if s in argscope_samples and s in argoap_samples and s in deeparg_samples
    ]
    if not common_samples:
        raise RuntimeError("No sample is shared by ARGScope, ARG-OAP, and DeepARG.")

    argoap_complete = complete_reference_table(argoap_df, common_samples)
    deeparg_complete = complete_reference_table(deeparg_df, common_samples)

    configs = (
        argscope_df[["gate", "diamond"]]
        .dropna()
        .drop_duplicates()
        .sort_values(["gate", "diamond"])
        .reset_index(drop=True)
    )

    parts = []
    for _, r in configs.iterrows():
        gate = float(r["gate"])
        diamond = float(r["diamond"])
        a = complete_argscope_config(argscope_df, common_samples, gate, diamond)

        for ref in [argoap_complete, deeparg_complete]:
            tmp = ref.copy()
            tmp["gate"] = gate
            tmp["diamond"] = diamond
            parts.append(tmp)
        parts.append(a)

    all_df = pd.concat(parts, ignore_index=True)
    all_df["count"] = safe_numeric(all_df["count"], 0.0)
    all_df = add_relative_abundance(all_df)
    all_df.to_csv(TABLE_DIR / "ALL_models_all_configs_type_abundance_long.csv", index=False, encoding="utf-8-sig")
    return all_df, configs, common_samples


# =============================================================================
# 8. CONCORDANCE METRICS
# =============================================================================

def spearman_corr(x, y):
    x = pd.Series(np.asarray(x, dtype=float)).rank(method="average").to_numpy()
    y = pd.Series(np.asarray(y, dtype=float)).rank(method="average").to_numpy()
    if np.std(x) == 0 or np.std(y) == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def bray_curtis_similarity(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    den = np.sum(x + y)
    if den <= 0:
        return np.nan
    dist = np.sum(np.abs(x - y)) / den
    return float(1.0 - dist)


def jaccard_presence(x, y):
    a = set(np.where(np.asarray(x, dtype=float) > 0)[0].tolist())
    b = set(np.where(np.asarray(y, dtype=float) > 0)[0].tolist())
    u = a | b
    if not u:
        return np.nan
    return float(len(a & b) / len(u))


def top_k_indices(x, k=5):
    arr = np.asarray(x, dtype=float)
    positive = np.where(arr > 0)[0]
    if len(positive) == 0:
        return set()
    order = positive[np.argsort(arr[positive])[::-1]]
    return set(order[:k].tolist())


def topk_metrics(x, y, k=5):
    a = top_k_indices(x, k)
    b = top_k_indices(y, k)
    overlap = len(a & b)
    union = len(a | b)
    jacc = overlap / union if union > 0 else np.nan
    return overlap, float(jacc) if np.isfinite(jacc) else np.nan


def calculate_concordance(all_df, configs, samples):
    rows = []
    type_order = VALID_TYPES

    for _, cfg in configs.iterrows():
        gate = float(cfg["gate"])
        diamond = float(cfg["diamond"])
        sub_cfg = all_df[
            np.isclose(all_df["gate"], gate) &
            np.isclose(all_df["diamond"], diamond)
        ]

        for sample in samples:
            sub_s = sub_cfg[sub_cfg["sample_name"] == sample]

            vectors = {}
            for model in MODEL_ORDER:
                m = (
                    sub_s[sub_s["model"] == model]
                    .set_index("canonical_type")["relative_abundance"]
                    .reindex(type_order, fill_value=0.0)
                    .to_numpy(dtype=float)
                )
                vectors[model] = m

            a = vectors["ARGScope"]
            for ref_model in ["ARG-OAP", "DeepARG"]:
                b = vectors[ref_model]
                top_overlap, top_jacc = topk_metrics(a, b, 5)
                rows.append({
                    "gate": gate,
                    "diamond": diamond,
                    "sample_name": sample,
                    "comparison": "ARGScope_vs_%s" % ref_model.replace("-", ""),
                    "reference_model": ref_model,
                    "spearman": spearman_corr(a, b),
                    "bray_curtis_similarity": bray_curtis_similarity(a, b),
                    "jaccard_detected_types": jaccard_presence(a, b),
                    "top5_overlap_n": top_overlap,
                    "top5_jaccard": top_jacc,
                    "ARGScope_detected_type_n": int(np.sum(a > 0)),
                    "reference_detected_type_n": int(np.sum(b > 0)),
                })

    detail = pd.DataFrame(rows)
    detail.to_csv(TABLE_DIR / "type_concordance_per_sample.csv", index=False, encoding="utf-8-sig")

    summary = (
        detail.groupby(["gate", "diamond", "reference_model"], as_index=False)
        .agg(
            mean_spearman=("spearman", "mean"),
            median_spearman=("spearman", "median"),
            mean_bray_curtis_similarity=("bray_curtis_similarity", "mean"),
            median_bray_curtis_similarity=("bray_curtis_similarity", "median"),
            mean_jaccard_detected_types=("jaccard_detected_types", "mean"),
            mean_top5_overlap_n=("top5_overlap_n", "mean"),
            mean_top5_jaccard=("top5_jaccard", "mean"),
            sample_n=("sample_name", "nunique"),
        )
    )
    summary.to_csv(TABLE_DIR / "type_concordance_summary_by_config.csv", index=False, encoding="utf-8-sig")

    # Configuration-level combined concordance score for a representative setting.
    pivot = summary.pivot_table(
        index=["gate", "diamond"], columns="reference_model",
        values="mean_bray_curtis_similarity", aggfunc="mean"
    ).reset_index()
    for col in ["ARG-OAP", "DeepARG"]:
        if col not in pivot.columns:
            pivot[col] = np.nan
    pivot["combined_mean_bray_curtis_similarity"] = pivot[["ARG-OAP", "DeepARG"]].mean(axis=1)
    pivot = pivot.sort_values(
        ["combined_mean_bray_curtis_similarity", "gate", "diamond"],
        ascending=[False, True, True]
    ).reset_index(drop=True)
    pivot.to_csv(TABLE_DIR / "configuration_concordance_ranking.csv", index=False, encoding="utf-8-sig")
    return detail, summary, pivot


# =============================================================================
# 9. FIGURE: TYPE-LEVEL GROUPED BARPLOT FOR ONE CONFIG
# =============================================================================

def get_config_mean_table(all_df, gate, diamond, metric_col):
    sub = all_df[
        np.isclose(all_df["gate"], float(gate)) &
        np.isclose(all_df["diamond"], float(diamond))
    ].copy()

    mean_df = (
        sub.groupby(["model", "canonical_type"], as_index=False)[metric_col]
        .mean()
    )
    mat = mean_df.pivot(index="canonical_type", columns="model", values=metric_col)
    mat = mat.reindex(columns=MODEL_ORDER).fillna(0.0)

    # Retain Types detected by at least one model.
    mat = mat[mat.max(axis=1) > 0].copy()

    # Sort primarily by ARGScope, then overall abundance. This makes ARGScope the
    # visual anchor while retaining every detected valid Type.
    mat["__overall"] = mat[MODEL_ORDER].mean(axis=1)
    mat = mat.sort_values(["ARGScope", "__overall"], ascending=[True, True])
    mat = mat.drop(columns=["__overall"])

    if MAX_TYPES_IN_BAR is not None and len(mat) > MAX_TYPES_IN_BAR:
        # For compact plotting only; full table remains exported.
        scores = mat["ARGScope"] + 0.20 * mat[["ARG-OAP", "DeepARG"]].mean(axis=1)
        keep = scores.nlargest(MAX_TYPES_IN_BAR).index
        mat = mat.loc[keep]
        mat["__overall"] = mat[MODEL_ORDER].mean(axis=1)
        mat = mat.sort_values(["ARGScope", "__overall"], ascending=[True, True]).drop(columns=["__overall"])

    return mat


def plot_type_bar_for_config(all_df, gate, diamond):
    metric = "relative_abundance_pct" if USE_RELATIVE_ABUNDANCE_FOR_MAIN_FIGURES else "count"
    mat = get_config_mean_table(all_df, gate, diamond, metric)
    if mat.empty:
        return

    # Export exactly what is plotted.
    mat.to_csv(
        TABLE_DIR / ("gate%s_diamond%s_mean_type_composition.csv" % (
            format_gate(gate).replace(".", ""), format_diamond(diamond).replace(".", "")
        )), encoding="utf-8-sig"
    )

    n = len(mat)
    fig_h = max(6.2, 0.36 * n + 2.2)
    fig, ax = plt.subplots(figsize=(10.8, fig_h), dpi=180)

    y = np.arange(n)
    bar_h = 0.23
    offsets = [-bar_h, 0, bar_h]

    for model, offset in zip(MODEL_ORDER, offsets):
        vals = mat[model].to_numpy(dtype=float)
        alpha = 1.0 if model == "ARGScope" else 0.76
        edge = "#6F1D1B" if model == "ARGScope" else "white"
        lw = 0.65 if model == "ARGScope" else 0.35
        bars = ax.barh(
            y + offset, vals, height=bar_h * 0.88,
            label=model, color=MODEL_COLORS[model], alpha=alpha,
            edgecolor=edge, linewidth=lw, zorder=3 if model == "ARGScope" else 2,
        )

        # Only annotate ARGScope values to keep focus on ARGScope.
        if model == "ARGScope":
            vmax = max(float(np.nanmax(mat.to_numpy(dtype=float))), 1e-12)
            for b, v in zip(bars, vals):
                if v <= 0:
                    continue
                txt = "%.2f" % v if metric == "relative_abundance_pct" else ("%.0f" % v)
                ax.text(
                    v + 0.012 * vmax,
                    b.get_y() + b.get_height() / 2.0,
                    txt,
                    va="center", ha="left", fontsize=7.2,
                    color=MODEL_COLORS["ARGScope"], fontweight="bold",
                )

    ax.set_yticks(y)
    ax.set_yticklabels(mat.index.tolist(), fontsize=8.7)
    ax.set_xlabel(
        "Mean relative abundance across samples (%)"
        if metric == "relative_abundance_pct" else
        "Mean ARG Type count across samples"
    )
    ax.set_ylabel("ARG Type")
    ax.set_title(
        "ARGScope-centered Type composition | gate %s, DIAMOND %s" %
        (format_gate(gate), format_diamond(diamond)),
        fontsize=13.2, fontweight="bold", pad=12,
    )
    ax.grid(axis="x", linestyle=":", linewidth=0.55, alpha=0.35, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    leg = ax.legend(
        loc="lower right", frameon=True, fancybox=True,
        edgecolor="#D0D0D0", ncol=1,
    )
    for t in leg.get_texts():
        if t.get_text() == "ARGScope":
            t.set_color(MODEL_COLORS["ARGScope"])
            t.set_fontweight("bold")

    fig.tight_layout()
    base = FIG_CONFIG_DIR / (
        "gate%s_diamond%s_type_composition_bar" %
        (format_gate(gate).replace(".", ""), format_diamond(diamond).replace(".", ""))
    )
    save_figure(fig, base)


# =============================================================================
# 10. FIGURE: 3 ALIGNED SAMPLE x TYPE HEATMAPS FOR ONE CONFIG
# =============================================================================

def make_light_cmap(base_color):
    from matplotlib.colors import to_rgb
    rgb = np.asarray(to_rgb(base_color), dtype=float)
    colors = []
    for t in np.linspace(0.0, 1.0, 256):
        # white -> target color
        c = (1.0 - t) * np.ones(3) + t * rgb
        colors.append(tuple(c.tolist()))
    return LinearSegmentedColormap.from_list("custom_%s" % base_color.replace("#", ""), colors)


def plot_type_heatmaps_for_config(all_df, samples, gate, diamond):
    sub = all_df[
        np.isclose(all_df["gate"], float(gate)) &
        np.isclose(all_df["diamond"], float(diamond))
    ].copy()

    # Sort Type rows by ARGScope mean relative abundance, descending.
    mean_scope = (
        sub[sub["model"] == "ARGScope"]
        .groupby("canonical_type")["relative_abundance_pct"]
        .mean()
        .sort_values(ascending=False)
    )
    union_detected = (
        sub.groupby("canonical_type")["relative_abundance_pct"].max()
    )
    type_order = [t for t in mean_scope.index if union_detected.get(t, 0) > 0]
    # Add Types detected only by references at the bottom.
    for t in union_detected[union_detected > 0].sort_values(ascending=False).index:
        if t not in type_order:
            type_order.append(t)

    if MAX_TYPES_IN_HEATMAP is not None:
        type_order = type_order[:MAX_TYPES_IN_HEATMAP]
    if not type_order:
        return

    ntypes = len(type_order)
    fig_h = max(6.0, 0.34 * ntypes + 2.0)
    fig, axes = plt.subplots(1, 3, figsize=(16.5, fig_h), sharey=True, dpi=180)

    vmax = max(
        float(sub["relative_abundance_pct"].quantile(0.995)),
        1e-6,
    )

    last_im = None
    for i, model in enumerate(MODEL_ORDER):
        ax = axes[i]
        m = (
            sub[sub["model"] == model]
            .pivot_table(
                index="canonical_type", columns="sample_name",
                values="relative_abundance_pct", aggfunc="sum", fill_value=0.0
            )
            .reindex(index=type_order, columns=samples, fill_value=0.0)
        )

        cmap = make_light_cmap(MODEL_COLORS[model])
        last_im = ax.imshow(
            m.to_numpy(dtype=float), aspect="auto", interpolation="nearest",
            cmap=cmap, vmin=0.0, vmax=vmax,
        )
        ax.set_title(model, fontsize=12.2,
                     fontweight="bold" if model == "ARGScope" else "normal",
                     color=MODEL_COLORS[model] if model == "ARGScope" else "black")
        ax.set_xticks(np.arange(len(samples)))
        ax.set_xticklabels(samples, rotation=55, ha="right", fontsize=7.7)
        ax.set_yticks(np.arange(ntypes))
        if i == 0:
            ax.set_yticklabels(type_order, fontsize=8.2)
            ax.set_ylabel("ARG Type")
        else:
            ax.tick_params(axis="y", labelleft=False)
        ax.set_xlabel("Sample")

        ax.set_xticks(np.arange(-0.5, len(samples), 1), minor=True)
        ax.set_yticks(np.arange(-0.5, ntypes, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.45, alpha=0.7)
        ax.tick_params(which="minor", bottom=False, left=False)

    # Shared colorbar with abundance scale.
    cbar = fig.colorbar(last_im, ax=axes, fraction=0.018, pad=0.018)
    cbar.set_label("Relative abundance (%)", rotation=270, labelpad=14)

    fig.suptitle(
        "Sample-level ARG Type composition | gate %s, DIAMOND %s" %
        (format_gate(gate), format_diamond(diamond)),
        fontsize=14.0, fontweight="bold", y=0.995,
    )
    fig.subplots_adjust(left=0.14, right=0.93, top=0.92, bottom=0.18, wspace=0.16)

    base = FIG_CONFIG_DIR / (
        "gate%s_diamond%s_sample_type_heatmaps" %
        (format_gate(gate).replace(".", ""), format_diamond(diamond).replace(".", ""))
    )
    save_figure(fig, base)


# =============================================================================
# 11. PARAMETER LANDSCAPE HEATMAPS
# =============================================================================

def plot_parameter_landscape(summary, ranking):
    refs = ["ARG-OAP", "DeepARG"]
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.8), dpi=180)

    for ax, ref in zip(axes, refs):
        sub = summary[summary["reference_model"] == ref].copy()
        mat = sub.pivot(index="gate", columns="diamond", values="mean_bray_curtis_similarity")
        mat = mat.sort_index().sort_index(axis=1)

        im = ax.imshow(mat.to_numpy(dtype=float), aspect="auto", cmap="YlOrRd", vmin=0, vmax=1)
        ax.set_xticks(np.arange(len(mat.columns)))
        ax.set_xticklabels([format_diamond(x) for x in mat.columns])
        ax.set_yticks(np.arange(len(mat.index)))
        ax.set_yticklabels([format_gate(x) for x in mat.index])
        ax.set_xlabel("DIAMOND threshold")
        ax.set_ylabel("Gate threshold")
        ax.set_title("ARGScope vs %s" % ref, fontsize=11.5, fontweight="bold")

        for r in range(mat.shape[0]):
            for c in range(mat.shape[1]):
                v = mat.iloc[r, c]
                if np.isfinite(v):
                    ax.text(c, r, "%.3f" % v, ha="center", va="center", fontsize=8.2,
                            color="black" if v < 0.75 else "white")

        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label("Mean Bray-Curtis similarity")

    # Mark representative setting on both panels.
    if AUTO_SELECT_REPRESENTATIVE_CONFIG and len(ranking) > 0:
        best = ranking.iloc[0]
        bg = float(best["gate"])
        bd = float(best["diamond"])
        for ax, ref in zip(axes, refs):
            sub = summary[summary["reference_model"] == ref].copy()
            mat = sub.pivot(index="gate", columns="diamond", values="mean_bray_curtis_similarity")
            mat = mat.sort_index().sort_index(axis=1)
            if bg in mat.index and bd in mat.columns:
                r = list(mat.index).index(bg)
                c = list(mat.columns).index(bd)
                ax.scatter([c], [r], marker="*", s=180, c=MODEL_COLORS["ARGScope"],
                           edgecolors="black", linewidths=0.7, zorder=8)

    fig.suptitle(
        "ARGScope Type-composition concordance across filtering settings",
        fontsize=13.5, fontweight="bold", y=1.02,
    )
    fig.tight_layout()
    save_figure(fig, FIG_DIR / "ARGScope_type_concordance_parameter_landscape")


# =============================================================================
# 12. REPRESENTATIVE CONFIG: SAMPLE-WISE TOP TYPE BARS
# =============================================================================

def plot_representative_sample_bars(all_df, samples, gate, diamond, top_n=10):
    sub = all_df[
        np.isclose(all_df["gate"], float(gate)) &
        np.isclose(all_df["diamond"], float(diamond))
    ].copy()

    ncols = 3
    nrows = int(math.ceil(len(samples) / float(ncols)))
    fig, axes = plt.subplots(nrows, ncols, figsize=(17.5, 4.4 * nrows), dpi=180)
    axes = np.asarray(axes).reshape(-1)

    for ai, sample in enumerate(samples):
        ax = axes[ai]
        s = sub[sub["sample_name"] == sample].copy()
        pivot = s.pivot_table(
            index="canonical_type", columns="model",
            values="relative_abundance_pct", aggfunc="sum", fill_value=0.0
        ).reindex(columns=MODEL_ORDER, fill_value=0.0)

        # Select Top-N using ARGScope first, then max reference abundance.
        score = pivot["ARGScope"] + 0.15 * pivot[["ARG-OAP", "DeepARG"]].max(axis=1)
        keep = score.nlargest(top_n).index
        pivot = pivot.loc[keep].copy()
        pivot["__sort"] = pivot["ARGScope"] + 0.15 * pivot[["ARG-OAP", "DeepARG"]].max(axis=1)
        pivot = pivot.sort_values("__sort", ascending=True).drop(columns=["__sort"])

        y = np.arange(len(pivot))
        h = 0.23
        for model, off in zip(MODEL_ORDER, [-h, 0, h]):
            ax.barh(y + off, pivot[model], height=h * 0.88,
                    color=MODEL_COLORS[model],
                    alpha=1.0 if model == "ARGScope" else 0.75,
                    edgecolor="#6F1D1B" if model == "ARGScope" else "white",
                    linewidth=0.55 if model == "ARGScope" else 0.3,
                    label=model if ai == 0 else None)
        ax.set_yticks(y)
        ax.set_yticklabels(pivot.index, fontsize=7.8)
        ax.set_title(sample, fontsize=10.8, fontweight="bold")
        ax.set_xlabel("Relative abundance (%)")
        ax.grid(axis="x", linestyle=":", alpha=0.30)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    for j in range(len(samples), len(axes)):
        axes[j].axis("off")

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.985),
               ncol=3, frameon=False, fontsize=10.5)
    fig.suptitle(
        "Representative ARGScope setting: sample-wise Top-%d ARG Types\n"
        "gate %s, DIAMOND %s" % (top_n, format_gate(gate), format_diamond(diamond)),
        fontsize=14.0, fontweight="bold", y=1.025,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    save_figure(fig, FIG_DIR / "representative_setting_samplewise_top_types")


# =============================================================================
# 13. MAIN
# =============================================================================

def main():
    print("=" * 92)
    print("ARGScope vs ARG-OAP vs DeepARG | real-data Type-level comparison")
    print("=" * 92)
    print("ROOT_DIR :", ROOT_DIR)
    print("OUTDIR   :", OUTDIR)
    print("Interpretation: Type composition / abundance concordance, not ACC/Precision.")

    argscope = scan_argscope(ROOT_DIR)
    argoap = read_argoap(ROOT_DIR)
    deeparg = scan_deeparg(ROOT_DIR)

    print("\nCounts loaded:")
    print("  ARGScope rows:", len(argscope))
    print("  ARG-OAP rows :", len(argoap))
    print("  DeepARG rows :", len(deeparg))

    all_df, configs, samples = build_all_aligned(argscope, argoap, deeparg)
    print("\nCommon samples used for quantitative comparison (%d):" % len(samples))
    for s in samples:
        print("  -", s)

    detail, summary, ranking = calculate_concordance(all_df, configs, samples)

    print("\nGate x DIAMOND configurations:", len(configs))
    print(configs.to_string(index=False))

    # Generate direct Type-composition figures for EVERY configuration.
    for i, cfg in configs.iterrows():
        gate = float(cfg["gate"])
        diamond = float(cfg["diamond"])
        print("[FIG %02d/%02d] gate=%s diamond=%s" % (
            i + 1, len(configs), format_gate(gate), format_diamond(diamond)
        ))
        plot_type_bar_for_config(all_df, gate, diamond)
        plot_type_heatmaps_for_config(all_df, samples, gate, diamond)

    plot_parameter_landscape(summary, ranking)

    if AUTO_SELECT_REPRESENTATIVE_CONFIG and len(ranking) > 0:
        best = ranking.iloc[0]
        gate = float(best["gate"])
        diamond = float(best["diamond"])
        pd.DataFrame([best]).to_csv(
            TABLE_DIR / "representative_configuration.csv",
            index=False, encoding="utf-8-sig"
        )
        print("\nRepresentative configuration for visualization:")
        print("  gate    =", format_gate(gate))
        print("  diamond =", format_diamond(diamond))
        print("  combined mean Bray-Curtis similarity = %.4f" %
              float(best["combined_mean_bray_curtis_similarity"]))
        plot_representative_sample_bars(all_df, samples, gate, diamond, top_n=10)

    print("\n" + "=" * 92)
    print("Completed")
    print("=" * 92)
    print("Figures:", FIG_DIR)
    print("All configuration figures:", FIG_CONFIG_DIR)
    print("Tables :", TABLE_DIR)
    print("\nKey tables:")
    print(" - ALL_models_all_configs_type_abundance_long.csv")
    print(" - type_concordance_per_sample.csv")
    print(" - type_concordance_summary_by_config.csv")
    print(" - configuration_concordance_ranking.csv")
    print(" - ARGOAP_excluded_noncanonical_rows.csv")
    print(" - DeepARG_file_diagnostics.csv")


if __name__ == "__main__":
    main()
