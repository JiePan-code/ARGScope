// Render the actual exported SVG files for visual inspection, not a substitute drawing.
const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const out = __dirname;
(async () => {
  for (const stem of ['VF_BGC_updated_composite', 'VF_BGC_updated_no_letters']) {
    const svg = path.join(out, stem + '.svg');
    const buf = fs.readFileSync(svg);
    if (buf.toString().includes('<image')) throw new Error('Raster data embedded in SVG');
    await sharp(buf, {density:144}).resize({width:1600}).flatten({background:'#ffffff'})
      .png().toFile(path.join(out, stem + '_preview.png'));
    await sharp(buf, {density:144}).resize(3508,4961,{fit:'fill'})
      .withMetadata({density:300}).png().toFile(path.join(out, stem + '_300dpi.png'));
  }
  const summary = {rendered_from_final_SVG:true, preview_width:1600,
    native_300dpi_exports:true, renderer:'sharp', subtype_error_bars:false};
  fs.writeFileSync(path.join(out, 'render_verification.json'), JSON.stringify(summary, null, 2));
  console.log(JSON.stringify(summary));
})().catch(error => {console.error(error); process.exit(1);});
