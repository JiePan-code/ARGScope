#!/usr/bin/env python3
"""ARGScope: Protein/DNA Type-level Precision, split 60-70% and 80-90% figures.

Usage: python plot_precision_60_90.py --root "E:/1. ARGmodel/1. NonARG_training/Type_level_performance"
Dependencies: python -m pip install matplotlib numpy

Uses CSV/TSV reports, not raw predictions. Automatic discovery recognizes the
historical model folders and 60p / 60pct / 60% / protein_60 naming schemes.
Batch reports may supply dataset, completeness, modality and model columns.
Unmarked full-length reports are NEVER substituted for incomplete sequences.
PLM-ARG follows the original ARG-only evaluation: prefer a per-completeness
ARG_only file, then the ARG_only long/batch report. Lower-priority versions
are not combined with it. Equally preferred conflicting files still error.
For unusual paths or competing report versions, use --manifest files.csv:
modality,model,completeness,path
Protein,ARGNet,60,ARGnet/protein_60pct_argnet-l_classification_report_fixed18.csv
DNA,CustomModel,70,other/results.csv
Manifest paths are relative to --root (or absolute). Manifest entries override
automatic discovery for that combination; additional models are supported.

Average is the unweighted mean over finite values in the original 18 Types,
including bleomycin, which is hidden from the main panel by default. Missing
values are NA, never zero. Average counts and selected files are exported.
Original source attachment was unavailable; discovery/normalization have been
reconstructed from the accessible conversation, rather than copied verbatim.
"""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
import re
import sys
import unicodedata

ROOT_DIR = Path(r"E:\1. ARGmodel\1. NonARG_training\Type_level_performance")
COMPLETENESS = (60, 70, 80, 90)
FIGURE_GROUPS = ((60, 70), (80, 90))
TYPE_ORDER = [
    "vancomycin", "trimethoprim", "tetracycline", "sulfonamide",
    "streptothricin", "rifamycin", "quinolone", "polymyxin", "novobiocin",
    "multidrug", "MLS", "fusidic_acid", "fosfomycin", "chloramphenicol",
    "bleomycin", "beta_lactam", "bacitracin", "aminoglycoside",
]
MODEL_ORDER = ["ARGNet", "DeepARG", "Fungenetyper", "PLM-ARG", "ARGScope"]
MODEL_ALIASES = {
    "ARGNet": ("argnet",), "DeepARG": ("deeparg",),
    "Fungenetyper": ("fungenetyper", "fungentyper"),
    "PLM-ARG": ("plmarg",), "ARGScope": ("argscope",),
}
FONT_FAMILY = "DejaVu Sans"  # Change to Arial if installed.
TYPE_LABEL_SIZE = 9
MODEL_LABEL_SIZE = 8
ANNOTATION_SIZE = 6.5
PANEL_TITLE_SIZE = 11
CELL_WIDTH = 0.39  # inches; increase for wider cells
CELL_HEIGHT = 0.4
AVERAGE_GAP = 0.1
DNA_COLORS = ["#FFF9F4", "#FCEBDD", "#F8D7BE", "#F3BE96", "#EDA36F"]


def key(value):
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def normalize_type(value):
    value = unicodedata.normalize("NFKC", str(value)).strip().lower()
    value = value.replace("β", "beta")
    value = re.sub(r"[\s_–—-]+", "_", value)
    aliases = {
        "mls": "MLS", "macrolide_lincosamide_streptogramin": "MLS",
        "macrolide_lincosamide_streptogramins": "MLS",
        "diaminopyrimidine": "trimethoprim", "fluoroquinolone": "quinolone",
        "phenicol": "chloramphenicol", "betalactam": "beta_lactam",
        "fusidicacid": "fusidic_acid",
    }
    return aliases.get(value, value)


def modality_of(value):
    tokens = set(re.findall(r"[a-z0-9]+", str(value).lower()))
    found = set()
    if tokens & {"protein", "longaa", "aa", "prot"}:
        found.add("Protein")
    if tokens & {"dna", "longnt", "nt", "nucl", "nucleotide"}:
        found.add("DNA")
    return next(iter(found)) if len(found) == 1 else None


def model_of(value):
    compact = key(value)
    hits = [m for m, aliases in MODEL_ALIASES.items() if any(a in compact for a in aliases)]
    return hits[0] if len(hits) == 1 else None


def pct_of(value):
    text = str(value).strip().lower()
    if re.fullmatch(r"\d+(?:\.\d+)?\s*(?:%|pct|p)?", text):
        num = float(re.sub(r"[%a-z\s]", "", text))
        return int(round(num * 100 if 0 < num <= 1 else num))
    hits = re.findall(r"(?<![\d.])(60|70|80|90|100)(?:pct|percent|p|%)(?![a-z0-9])", text)
    if not hits:
        hits = re.findall(r"(?:^|[_/\\\s-])(60|70|80|90|100)(?=$|[_/\\\s-])", text)
    return int(hits[0]) if len(set(hits)) == 1 else None


def read_rows(path):
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            with path.open(encoding=encoding, newline="") as handle:
                sample = handle.read(8192)
                handle.seek(0)
                try:
                    dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
                except csv.Error:
                    dialect = csv.excel_tab if path.suffix.lower() == ".tsv" else csv.excel
                reader = csv.DictReader(handle, dialect=dialect)
                return [{key(k): v for k, v in row.items() if k is not None} for row in reader]
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Cannot decode {path}")


def first(row, names):
    return next((row[n] for n in names if row.get(n) not in (None, "")), None)


def score(value, scale):
    if value is None or str(value).strip().lower() in {"", "na", "nan", "n/a", "none", "-"}:
        return math.nan
    text = str(value).strip()
    number = float(text.rstrip("%"))
    if text.endswith("%") or scale == "percent":
        number /= 100
    if not math.isfinite(number) or not 0 <= number <= 1:
        raise ValueError(f"Invalid precision {value!r}; use --score-scale percent for 0–100 input")
    return number


def extract(path, root, scale, forced=None):
    """Return (modality, model, completeness) -> normalized Type -> score."""
    groups = {}
    try:
        context = str(path.relative_to(root))
    except ValueError:
        context = str(path)
    rows = read_rows(path)
    if not rows or not any(k in rows[0] for k in ("precision", "prec", "positivepredictivevalue")):
        return groups
    for row in rows:
        raw_type = first(row, ("type", "argtype", "drugclass", "antibioticclass", "class", "label", "classname", "unnamed0", ""))
        if raw_type is None:
            continue
        type_name = normalize_type(raw_type)
        if type_name not in TYPE_ORDER:
            continue
        dataset = first(row, ("dataset", "condition", "sample", "datasetname")) or ""
        explicit_mod = first(row, ("modality", "sequencetype"))
        mod = modality_of(explicit_mod or dataset) or modality_of(context)
        raw_model = first(row, ("model", "tool", "method"))
        model = (model_of(raw_model) or raw_model) if raw_model else model_of(context)
        # Historical PLM_ARG/PLMARG_5conditions_perType_metrics has no AA token.
        if mod is None and model == "PLM-ARG" and "plmarg5conditions" in key(context):
            mod = "Protein"
        explicit_pct = first(row, ("completeness", "completenesspercent", "percentage", "percent", "pct"))
        pct = pct_of(explicit_pct if explicit_pct is not None else dataset)
        if pct is None:
            pct = pct_of(context)
        if forced:
            fm, fmodel, fp = forced
            # Filter batch rows with known metadata before applying overrides.
            if (mod and mod != fm) or (model and model != fmodel) or (pct and pct != fp):
                continue
            mod, model, pct = forced
        if mod not in ("Protein", "DNA") or not model or pct not in COMPLETENESS:
            continue
        values = groups.setdefault((mod, model, pct), {})
        number = score(first(row, ("precision", "prec", "positivepredictivevalue")), scale)
        if type_name in values and not (values[type_name] == number or math.isnan(values[type_name]) and math.isnan(number)):
            raise ValueError(f"Conflicting duplicate Type {type_name} in {path}; select a single report/condition")
        values[type_name] = number
    return groups


def preferred_candidates(combo, options):
    """Preserve PLM-ARG's original ARG-only report choice, with batch fallback."""
    if combo[1] != "PLM-ARG":
        return options
    arg_only = [(path, values) for path, values in options
                if "argonly" in key(path.stem)]
    if not arg_only:
        return options
    individual = [(path, values) for path, values in arg_only
                  if pct_of(path.stem) == combo[2]]
    preferred = individual or arg_only
    if len(preferred) < len(options):
        print(f"[Select] {combo[0]}/PLM-ARG/{combo[2]}%: "
              f"{'per-completeness' if individual else 'batch'} ARG-only report")
    return preferred


def discover(args, out):
    candidates = {}
    for path in sorted(args.root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {".csv", ".tsv"}:
            continue
        if out == path or out in path.parents or (args.manifest and path == args.manifest.resolve()):
            continue
        for combo, values in extract(path, args.root, args.score_scale).items():
            candidates.setdefault(combo, []).append((path, values))
    if args.manifest:
        for row in read_rows(args.manifest):
            combo = (modality_of(row.get("modality", "")), model_of(row.get("model", "")) or row.get("model"), pct_of(row.get("completeness", "")))
            if combo[0] is None or not combo[1] or combo[2] not in COMPLETENESS:
                raise ValueError(f"Invalid manifest entry: {row}")
            path = Path(row["path"])
            path = path if path.is_absolute() else args.root / path
            values = extract(path, args.root, args.score_scale, combo).get(combo)
            if not values:
                raise ValueError(f"No matching Type precision rows in manifest file {path}")
            candidates[combo] = [(path, values)]
    selected = {}
    for combo, options in candidates.items():
        options = preferred_candidates(combo, options)
        # Exact duplicate exports are safe; different report versions need a manifest.
        signatures = {tuple((t, 'NA' if math.isnan(v) else v) for t, v in sorted(vals.items())) for _, vals in options}
        if len(signatures) != 1:
            paths = "\n  ".join(str(p) for p, _ in options)
            raise ValueError(f"Ambiguous files for {combo}; choose with --manifest:\n  {paths}")
        selected[combo] = options[0]
    return selected


def write_csv(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(fields)
        writer.writerows(rows)


def average(values):
    finite = [values[t] for t in TYPE_ORDER if t in values and math.isfinite(values[t])]
    return (sum(finite) / len(finite) if finite else math.nan), len(finite)


def plot_group(modality, models, selected, args, out, pct_group):
    """Plot one modality and one completeness pair, e.g. 60-70 or 80-90."""
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap

    plt.rcParams.update({
        "font.family": FONT_FAMILY,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    })

    cmap = (
        plt.get_cmap("Blues").copy()
        if modality == "Protein"
        else LinearSegmentedColormap.from_list("DNA_LightOrange", DNA_COLORS)
    )
    cmap.set_bad("#E6E6E6")

    # bleomycin is hidden from the displayed main heatmap by default,
    # but remains in TYPE_ORDER and therefore remains in Average calculation.
    types = [t for t in TYPE_ORDER if args.show_bleomycin or t != "bleomycin"]

    n_panels = len(pct_group)  # 2 panels per figure
    width = 2.2 + n_panels * len(models) * CELL_WIDTH + 1.2
    fig = plt.figure(
        figsize=(width, (len(types) + 1) * CELL_HEIGHT + 1.9)
    )

    # 2 rows: Average + main Type heatmap
    # n_panels completeness blocks + one colorbar column
    gs = fig.add_gridspec(
        2,
        n_panels + 1,
        width_ratios=[1] * n_panels + [0.055],
        height_ratios=[1, len(types)],
        left=2.0 / width,
        right=0.96,
        top=0.88,
        bottom=0.19,
        wspace=0.10,
        hspace=AVERAGE_GAP,
    )

    averages = []
    matrix_rows = []
    im = None

    for col, pct in enumerate(pct_group):
        data = [
            selected.get((modality, model, pct), (None, {}))[1]
            for model in models
        ]

        # Average uses all original 18 Types, including bleomycin.
        avg = [average(d) for d in data]

        for model, (value, count) in zip(models, avg):
            averages.append([
                pct,
                model,
                value if math.isfinite(value) else "",
                count,
                len(TYPE_ORDER),
            ])

        for typ in TYPE_ORDER:
            matrix_rows.append([
                pct,
                typ,
                *[d.get(typ, "") for d in data],
            ])

        panel_specs = (
            (0, ["Average"], [[a[0] for a in avg]]),
            (1, types, [[d.get(t, math.nan) for d in data] for t in types]),
        )

        for row_index, labels, values in panel_specs:
            ax = fig.add_subplot(gs[row_index, col])
            values = np.asarray(values, dtype=float)

            im = ax.imshow(
                np.ma.masked_invalid(values),
                cmap=cmap,
                vmin=0,
                vmax=1,
                aspect="auto",
                interpolation="nearest",
            )

            ax.set_yticks(
                range(len(labels)),
                labels if col == 0 else [],
                fontsize=TYPE_LABEL_SIZE,
            )
            ax.set_xticks(
                range(len(models)),
                models if row_index else [],
                rotation=48,
                ha="right",
                fontsize=MODEL_LABEL_SIZE,
            )
            ax.tick_params(which="both", length=0)

            # Cell borders
            ax.set_xticks(np.arange(-0.5, len(models), 1), minor=True)
            ax.set_yticks(np.arange(-0.5, len(labels), 1), minor=True)
            ax.grid(which="minor", color="white", linewidth=0.7)

            for spine in ax.spines.values():
                spine.set_visible(False)

            if row_index == 0:
                ax.set_title(f"{pct}%", fontsize=PANEL_TITLE_SIZE, pad=10)

            # Cell annotations
            for y in range(values.shape[0]):
                for x in range(values.shape[1]):
                    v = values[y, x]
                    rgb = cmap(v)[:3] if np.isfinite(v) else (1, 1, 1)
                    luminance = sum(
                        a * b for a, b in zip(rgb, (0.299, 0.587, 0.114))
                    )
                    color = "white" if luminance < 0.5 else "#222222"

                    # Missing cells are visually grey and labeled NA instead of 0.
                    label = f"{v:.4f}" if np.isfinite(v) else "0"
                    ax.text(
                        x,
                        y,
                        label,
                        ha="center",
                        va="center",
                        fontsize=ANNOTATION_SIZE,
                        color=color,
                        fontweight=("bold" if models[x] == "ARGScope" else "normal"),
                    )

    cax = fig.add_subplot(gs[:, -1])
    cbar = fig.colorbar(
        im,
        cax=cax,
        ticks=np.linspace(0, 1, 6),
    )
    cbar.set_label("Precision")

    group_start, group_end = pct_group[0], pct_group[-1]
    stem = (
        f"{modality}_{group_start}_{group_end}pct_"
        f"Precision_heatmaps_with_Average"
    )

    for ext in args.formats:
        fig.savefig(
            out / f"{stem}.{ext}",
            dpi=args.dpi,
            bbox_inches="tight",
            transparent=args.transparent,
        )
    plt.close(fig)

    # Group-specific value tables.
    write_csv(
        out / f"{modality}_{group_start}_{group_end}pct_Average_values.csv",
        ["completeness", "model", "Average", "n_types_used", "n_types_expected"],
        averages,
    )
    write_csv(
        out / f"{modality}_{group_start}_{group_end}pct_Precision_values.csv",
        ["completeness", "Type"] + models,
        matrix_rows,
    )

    print(f"Saved figure: {out / (stem + '.png')}")

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", type=Path, default=ROOT_DIR)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--dpi", type=int, default=600)
    parser.add_argument("--formats", nargs="+", choices=["png", "tif", "pdf", "svg"], default=["png", "tif", "pdf", "svg"])
    parser.add_argument("--score-scale", choices=["fraction", "percent"], default="fraction")
    parser.add_argument("--show-bleomycin", action="store_true")
    parser.add_argument("--transparent", action="store_true")
    parser.add_argument("--discover-only", action="store_true", help="Export selected_files.csv without requiring plotting dependencies")
    args = parser.parse_args()
    args.root = args.root.resolve()
    if not args.root.is_dir():
        parser.error(f"Input folder does not exist: {args.root}; set ROOT_DIR or pass --root")
    if args.dpi <= 0:
        parser.error("--dpi must be positive")
    out = (args.out or args.root / "Protein_DNA_60_70_80_90pct_Precision_split_heatmaps").resolve()
    selected = discover(args, out)
    if not selected:
        raise ValueError("No 60–90% per-Type precision files found. Check --root or provide --manifest.")
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / "selected_files.csv", ["modality", "model", "completeness", "path", "n_types_used"],
              [[*combo, str(path), average(vals)[1]] for combo, (path, vals) in sorted(selected.items())])
    for mod in ("Protein", "DNA"):
        available = {m for md, m, pct in selected if md == mod}
        models = [m for m in MODEL_ORDER if m in available] + sorted(available - set(MODEL_ORDER))
        if not models:
            print(f"WARNING: No {mod} data found; cannot generate this figure.", file=sys.stderr)
            continue
        for m in models:
            for pct in COMPLETENESS:
                count = average(selected.get((mod, m, pct), (None, {}))[1])[1]
                if count < 18:
                    print(f"WARNING: {mod}/{m}/{pct}%: {count}/18 Types; missing cells shown as NA.", file=sys.stderr)
        if not args.discover_only:
            for pct_group in FIGURE_GROUPS:
                plot_group(mod, models, selected, args, out, pct_group)
    print(f"Saved: {out}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as exc:
        raise SystemExit(f"ERROR: {exc}")
