"""Restyle the existing 2x4 UMAP panel without refitting or changing points."""
from pathlib import Path
import hashlib
import json
import shutil
import textwrap
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.offsetbox import AnnotationBbox, HPacker, TextArea
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/vf_bgc_merged_20260922_v6'
OUT = ROOT / 'outputs/vf_bgc_umap_bold_best_20260922'
DELIVERY = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/VF_BGC_含非目标类_透明SVG_20260922')
NAME = 'Figure5GH_VF_BGC_UMAP_2x4_bold_best_epoch'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wrapped(label):
    return '\n'.join(textwrap.wrap(label.replace('_', ' ').replace('/', '/ '),
                                  width=30, break_long_words=False,
                                  break_on_hyphens=False))


def main():
    for folder in [OUT, OUT/'editable_text', OUT/'previews']:
        folder.mkdir(parents=True, exist_ok=True)
    regular = font_manager.findfont(font_manager.FontProperties(family='Arial'),
                                    fallback_to_default=False)
    bold = font_manager.findfont(font_manager.FontProperties(family='Arial', weight='bold'),
                                 fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 13,
                         'axes.labelsize': 13, 'axes.titlesize': 12,
                         'axes.linewidth': .9, 'svg.hashsalt': 'vf-bgc-umap-best-bold',
                         'pdf.fonttype': 42})
    manifest = json.loads((SOURCE/'epoch_manifest.json').read_text(encoding='utf-8'))
    assert len(manifest) == 8
    fig = plt.figure(figsize=(14, 8.8), facecolor='none')
    audit, titles, source_hashes = [], [], {}
    for row, (domain, top) in enumerate([('VF', 8.6), ('BGC', 3.9)]):
        palette = pd.read_csv(SOURCE/'plot_data'/domain/'type_palette.csv')
        labels = palette.Type.tolist()
        colors = dict(zip(labels, palette.Color))
        panel_top, panel_bottom = top-.25, top-.25-2.65
        grid = fig.add_gridspec(1, 4, left=.068, right=.985,
                               top=panel_top/8.8, bottom=panel_bottom/8.8, wspace=.16)
        fig.text(.025, (panel_top+panel_bottom)/(2*8.8), domain, rotation=90,
                 ha='center', va='center', fontsize=15, weight='bold')
        for col in range(4):
            item = next(x for x in manifest if x['row'] == row and x['column'] == col)
            source = SOURCE/'plot_data'/domain/'umap'/(
                item['variant']+'_'+Path(item['feature_file']).stem+'_umap.csv')
            source_hashes[str(source)] = digest(source)
            frame = pd.read_csv(source, encoding='utf-8-sig', keep_default_na=False)
            assert frame.id.is_unique and len(frame) == item['samples']
            assert set(frame.Type) <= set(labels)
            assert set(frame.epoch) == {item['epoch']}
            assert np.isfinite(frame[['UMAP1', 'UMAP2']].to_numpy()).all()
            # Match the original ordering, marker size, limits, and colors exactly.
            order = np.random.default_rng(20260921).permutation(len(frame))
            points = frame.iloc[order]
            ax = fig.add_subplot(grid[col], facecolor='none')
            marks = ax.scatter(points.UMAP1, points.UMAP2,
                               c=[colors[label] for label in points.Type],
                               s=4.2, alpha=.8, linewidths=0, rasterized=False)
            assert np.array_equal(np.asarray(marks.get_offsets()),
                                  points[['UMAP1', 'UMAP2']].to_numpy())
            low = frame[['UMAP1', 'UMAP2']].min().to_numpy()
            high = frame[['UMAP1', 'UMAP2']].max().to_numpy()
            center, half = (low+high)/2, max(high-low)*.55
            ax.set_xlim(center[0]-half, center[0]+half)
            ax.set_ylim(center[1]-half, center[1]+half)
            ax.set_box_aspect(1)
            ax.set_aspect('equal', adjustable='box')
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_xlabel('UMAP1', fontsize=12, labelpad=3)
            ax.set_ylabel('UMAP2', fontsize=12, labelpad=3)
            for spine in ax.spines.values():
                spine.set_visible(True)
                spine.set_linewidth(.8)
            modality = 'Protein' if item['variant'] == 'AA' else 'DNA'
            is_best = col % 2 == 1
            prefix = TextArea(modality+' · ', textprops={'family':'Arial', 'size':12.5})
            suffix = TextArea('Best epoch' if is_best else 'Epoch 0',
                              textprops={'family':'Arial', 'size':12.5,
                                         'weight':'bold' if is_best else 'normal'})
            title = AnnotationBbox(HPacker(children=[prefix,suffix], align='baseline',
                                          pad=0, sep=0), (.5,1), xybox=(0,6),
                                   xycoords='axes fraction', boxcoords='offset points',
                                   box_alignment=(.5,0), frameon=False, pad=0,
                                   annotation_clip=False)
            ax.add_artist(title)
            titles.append(title)
            audit.append({**item, 'coordinate_csv':str(source),
                          'coordinate_sha256':source_hashes[str(source)],
                          'coordinates_and_order_unchanged':True,
                          'best_epoch_bold':is_best, 'rasterized':False})
        legend_height = 1.10 if domain == 'VF' else .64
        legend_gap = .40 if domain == 'VF' else .24
        legend_bottom = panel_bottom-legend_gap-legend_height
        lax = fig.add_axes([.068,legend_bottom/8.8,.917,legend_height/8.8], facecolor='none')
        lax.axis('off')
        handles = [Line2D([0],[0],color=colors[label],marker='o',linestyle='',ms=6,
                          label=wrapped(label)) for label in labels]
        lax.legend(handles=handles,loc='center',bbox_to_anchor=(0,0,1,1),mode='expand',
                   ncol=4,frameon=False,fontsize=11.5,handlelength=.8,handletextpad=.4,
                   borderaxespad=0,columnspacing=1,labelspacing=.6)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for title in titles:
        box = title.get_window_extent(renderer)
        assert box.x0 >= 0 and box.y0 >= 0
        assert box.x1 <= fig.bbox.width and box.y1 <= fig.bbox.height
    save_options = dict(bbox_inches='tight', pad_inches=.025, transparent=True)
    with plt.rc_context({'svg.fonttype':'path'}):
        fig.savefig(OUT/(NAME+'.svg'), **save_options)
    with plt.rc_context({'svg.fonttype':'none'}):
        fig.savefig(OUT/'editable_text'/(NAME+'.svg'), **save_options)
    fig.savefig(OUT/'previews'/(NAME+'.png'), dpi=150,
                bbox_inches='tight',pad_inches=.025,facecolor='white',transparent=False)
    plt.close(fig)
    ns = {'s':'http://www.w3.org/2000/svg'}
    for path in [OUT/(NAME+'.svg'), OUT/'editable_text'/(NAME+'.svg')]:
        tree = ET.parse(path)
        assert not tree.findall('.//s:image',ns), 'All scatter points must remain vector'
        if path.parent.name == 'editable_text':
            best = [el for el in tree.findall('.//s:text',ns) if el.text == 'Best epoch']
            assert len(best) == 4
            assert all('700' in el.attrib.get('style','') or
                       'bold' in el.attrib.get('style','') for el in best)
    assert all(digest(Path(path)) == value for path,value in source_hashes.items())
    verification = {'layout':'VF / BGC, 2 rows x 4 columns', 'font':'Arial',
                    'regular_font':regular, 'bold_font':bold,
                    'only_best_epoch_words_bold':True, 'best_epoch_labels':4,
                    'transparent_background':True, 'outer_padding_pt':1.8,
                    'all_points_vector':True, 'source_files_unmodified':True,
                    'panels':audit}
    (OUT/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),
                                       encoding='utf-8')
    for relative in [Path(NAME+'.svg'),Path('editable_text')/(NAME+'.svg'),
                     Path('previews')/(NAME+'.png')]:
        dest = DELIVERY/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():
            raise FileExistsError(f'Refusing to replace an existing deliverable: {dest}')
        shutil.copy2(OUT/relative,dest)
        assert digest(OUT/relative) == digest(dest)
    print(json.dumps({'svg':str(DELIVERY/(NAME+'.svg')), 'points':sum(x['samples'] for x in audit),
                      'bold_labels':4, 'verified':True},ensure_ascii=False))


if __name__ == '__main__':
    main()
