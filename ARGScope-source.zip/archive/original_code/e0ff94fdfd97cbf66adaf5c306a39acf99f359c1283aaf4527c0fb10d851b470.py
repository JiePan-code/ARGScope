import pandas as pd

# ==========================================================
# 1. 文件路径
# ==========================================================
EMBEDDING1_TXT = "all_arg_nonarg_DNA_embedding.txt"
EMBEDDING2_TXT = "all_arg_nonarg_protein_embeddings.txt"
LABEL_FILE = "all_arg_nonarg_id_label.csv"

OUTPUT_EMB1_CSV = "3.60p_ARG_DNA_with_label.csv"
OUTPUT_EMB2_CSV = "2.30p_ARG_protein_with_label.csv"

# ==========================================================
# 2. label 文件列名
# ==========================================================
LABEL_ID_COL = "id"
LABEL_TYPE_COL = "type"
LABEL_SUBTYPE_COL = "subtype"

# ==========================================================
# 3. txt 分隔符设置
# 如果是 tab 分隔，用 sep="\t"
# 如果是空格分隔，用 sep=r"\s+"
# ==========================================================
TXT_SEP = "\t"


def load_embedding_txt(txt_file, sep="\t"):
    """
    读取 embedding txt
    默认:
        第1列 = id
        后面列 = embedding
    """
    df = pd.read_csv(txt_file, sep=sep, header=None, engine="python")

    if df.shape[1] < 2:
        raise ValueError(f"{txt_file} 读取失败，列数小于2，请检查分隔符。")

    # 重命名列
    col_names = ["id"] + [f"emb_{i}" for i in range(1, df.shape[1])]
    df.columns = col_names

    # 去空格
    df["id"] = df["id"].astype(str).str.strip()

    return df


def load_label_file(label_file):
    """
    读取 label 文件，只保留 id / Type / Subtype
    """
    label_df = pd.read_csv(label_file)

    required_cols = [LABEL_ID_COL, LABEL_TYPE_COL, LABEL_SUBTYPE_COL]
    for col in required_cols:
        if col not in label_df.columns:
            raise ValueError(f"label 文件缺少列: {col}")

    label_df = label_df[[LABEL_ID_COL, LABEL_TYPE_COL, LABEL_SUBTYPE_COL]].copy()
    label_df[LABEL_ID_COL] = label_df[LABEL_ID_COL].astype(str).str.strip()

    # 统一列名
    label_df.columns = ["id", "Type", "Subtype"]

    return label_df


def merge_embedding_with_label(emb_df, label_df, output_file):
    """
    将 embedding 和 label 按 id 合并，并输出 csv
    """
    merged_df = emb_df.merge(label_df, on="id", how="left")

    # 把 Type / Subtype 放到前面一点
    emb_cols = [c for c in merged_df.columns if c.startswith("emb_")]
    final_cols = ["id", "Type", "Subtype"] + emb_cols
    merged_df = merged_df[final_cols]

    merged_df.to_csv(output_file, index=False)

    matched_n = merged_df["Type"].notna().sum()
    unmatched_n = merged_df["Type"].isna().sum()

    print(f"Saved: {output_file}")
    print(f"Total rows: {len(merged_df)}")
    print(f"Matched labels: {matched_n}")
    print(f"Unmatched labels: {unmatched_n}")
    print("-" * 50)

    return merged_df


def main():
    print("Loading embedding txt files...")
    emb1_df = load_embedding_txt(EMBEDDING1_TXT, sep=TXT_SEP)
    emb2_df = load_embedding_txt(EMBEDDING2_TXT, sep=TXT_SEP)

    print("Embedding1 shape:", emb1_df.shape)
    print("Embedding2 shape:", emb2_df.shape)

    print("Loading label file...")
    label_df = load_label_file(LABEL_FILE)
    print("Label shape:", label_df.shape)

    print("Merging embedding1 with labels...")
    merge_embedding_with_label(emb1_df, label_df, OUTPUT_EMB1_CSV)

    print("Merging embedding2 with labels...")
    merge_embedding_with_label(emb2_df, label_df, OUTPUT_EMB2_CSV)

    print("Done.")


if __name__ == "__main__":
    main()