#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Recalculate DNA fragment-level Type/Subtype metrics for percent_60/70/80/90.

Input expected in:
    DNA_percent60_90_local_results/
    ├─ percent_60/DNA_fragment_test_predictions.csv
    ├─ percent_70/DNA_fragment_test_predictions.csv
    ├─ percent_80/DNA_fragment_test_predictions.csv
    └─ percent_90/DNA_fragment_test_predictions.csv

The script can be placed either:
1) inside DNA_percent60_90_local_results/, or
2) in its parent folder (e.g. 4.DNA_student_subtype2_newsplit/).

Outputs:
    DNA_percent60_90_local_results/
    └─ recalculated_DNA_Type_Subtype_metrics_60_90/
       ├─ 00_ALL_main_summary.csv
       ├─ 01_ALL_Subtype_overall_metrics.csv
       ├─ 02_ALL_ARG_only_Subtype_overall_metrics.csv
       ├─ 03_ALL_Type_overall_metrics.csv
       ├─ 04_ALL_per_Subtype_metrics.csv
       ├─ 05_ALL_per_Type_metrics.csv
       ├─ 06_class_counts_by_condition.csv
       └─ percent_60/
          ├─ Subtype_overall_metrics.csv
          ├─ ARG_only_Subtype_overall_metrics.csv
          ├─ Type_overall_metrics.csv
          ├─ per_Subtype_metrics.csv
          └─ per_Type_metrics.csv

Overall multiclass metrics:
    ACC
    MCC
    Macro Precision / Recall / F1
    Weighted Precision / Recall / F1
    Micro Precision / Recall / F1

Per-class metrics are one-vs-rest:
    ACC
    Precision
    Recall
    Specificity
    F1
    MCC
    Support
    Predicted_count
    TP / FP / FN / TN

Definitions
-----------
Subtype_end_to_end:
    true_subtype vs predicted_subtype on ALL fragments.
    nonARG is included as an ordinary final class.

ARG_only_Subtype:
    Keep rows with true_ARG == 1.
    Compare true_subtype vs FINAL predicted_subtype.
    If a true ARG fragment is predicted as nonARG, it remains an error.

Type_end_to_end:
    true_type vs predicted_type on ALL fragments.
    nonARG is included as an ordinary final class.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    matthews_corrcoef,
    precision_recall_fscore_support,
)

CONDITIONS = ("percent_60", "percent_70", "percent_80", "percent_90")
INPUT_FILENAME = "DNA_fragment_test_predictions.csv"
DEFAULT_RESULTS_DIRNAME = "DNA_percent60_90_local_results"
OUTPUT_DIRNAME = "recalculated_DNA_Type_Subtype_metrics_60_90"


# =============================================================================
# CLI
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description=(
            "Recalculate DNA percent_60/70/80/90 "
            "Subtype and Type metrics."
        )
    )

    p.add_argument(
        "--results-root",
        type=Path,
        default=None,
        help=(
            "Directory containing percent_60/70/80/90. "
            "Default: auto-detect."
        ),
    )

    p.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Output directory. Default: "
            "<results-root>/recalculated_DNA_Type_Subtype_metrics_60_90"
        ),
    )

    p.add_argument(
        "--conditions",
        nargs="+",
        default=list(CONDITIONS),
        choices=list(CONDITIONS),
    )

    p.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing CSV files.",
    )

    return p.parse_args()


# =============================================================================
# Path detection
# =============================================================================

def is_valid_results_root(path: Path) -> bool:
    return all(
        (
            path
            / condition
            / INPUT_FILENAME
        ).is_file()
        for condition in CONDITIONS
    )


def detect_results_root(script_dir: Path) -> Path:
    # Script directly inside result folder
    if is_valid_results_root(script_dir):
        return script_dir

    # Script in model root
    candidate = (
        script_dir
        / DEFAULT_RESULTS_DIRNAME
    )

    if is_valid_results_root(candidate):
        return candidate

    raise FileNotFoundError(
        "Cannot auto-detect DNA results root.\n\n"
        "Expected either:\n"
        f"  {script_dir}/percent_60/{INPUT_FILENAME}\n"
        "or:\n"
        f"  {script_dir}/{DEFAULT_RESULTS_DIRNAME}/percent_60/{INPUT_FILENAME}\n\n"
        "You can also specify it explicitly with --results-root."
    )


# =============================================================================
# Metrics helpers
# =============================================================================

def safe_mcc(y_true, y_pred) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    if len(y_true) == 0:
        return 0.0

    try:
        return float(
            matthews_corrcoef(
                y_true,
                y_pred,
            )
        )
    except Exception:
        return 0.0


def multiclass_metrics(
    y_true,
    y_pred,
    condition: str,
    evaluation: str,
):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    if len(y_true) == 0:
        raise ValueError(
            f"No samples for {condition} / {evaluation}"
        )

    row = {
        "condition": condition,
        "evaluation": evaluation,
        "N": int(len(y_true)),
        "True_class_count": int(
            len(
                np.unique(
                    y_true
                )
            )
        ),
        "Predicted_class_count": int(
            len(
                np.unique(
                    y_pred
                )
            )
        ),
        "Union_class_count": int(
            len(
                set(
                    y_true.tolist()
                )
                |
                set(
                    y_pred.tolist()
                )
            )
        ),
        "ACC": float(
            accuracy_score(
                y_true,
                y_pred,
            )
        ),
        "MCC": safe_mcc(
            y_true,
            y_pred,
        ),
    }

    for average in (
        "macro",
        "weighted",
        "micro",
    ):

        (
            precision,
            recall,
            f1,
            _,
        ) = precision_recall_fscore_support(
            y_true,
            y_pred,
            average=average,
            zero_division=0,
        )

        prefix = average.capitalize()

        row[
            f"{prefix}_Precision"
        ] = float(
            precision
        )

        row[
            f"{prefix}_Recall"
        ] = float(
            recall
        )

        row[
            f"{prefix}_F1"
        ] = float(
            f1
        )

    return row


def one_vs_rest_metrics(
    y_true,
    y_pred,
    class_names,
    condition: str,
    evaluation: str,
    class_column: str,
):
    y_true = np.asarray(
        y_true,
        dtype=object,
    )

    y_pred = np.asarray(
        y_pred,
        dtype=object,
    )

    total = len(
        y_true
    )

    rows = []

    for class_name in class_names:

        true_binary = (
            y_true
            == class_name
        ).astype(
            np.int64
        )

        pred_binary = (
            y_pred
            == class_name
        ).astype(
            np.int64
        )

        cm = confusion_matrix(
            true_binary,
            pred_binary,
            labels=[
                0,
                1,
            ],
        )

        tn, fp, fn, tp = cm.ravel()

        precision = (
            tp
            / (
                tp
                + fp
            )
            if (
                tp
                + fp
            ) > 0
            else 0.0
        )

        recall = (
            tp
            / (
                tp
                + fn
            )
            if (
                tp
                + fn
            ) > 0
            else 0.0
        )

        specificity = (
            tn
            / (
                tn
                + fp
            )
            if (
                tn
                + fp
            ) > 0
            else 0.0
        )

        f1 = (
            2.0
            * precision
            * recall
            / (
                precision
                + recall
            )
            if (
                precision
                + recall
            ) > 0
            else 0.0
        )

        rows.append(
            {
                "condition":
                    condition,

                "evaluation":
                    evaluation,

                class_column:
                    class_name,

                "ACC":
                    (
                        (
                            tp
                            + tn
                        )
                        / total
                        if total > 0
                        else 0.0
                    ),

                "Precision":
                    precision,

                "Recall":
                    recall,

                "Specificity":
                    specificity,

                "F1":
                    f1,

                "MCC":
                    safe_mcc(
                        true_binary,
                        pred_binary,
                    ),

                "Support":
                    int(
                        tp
                        + fn
                    ),

                "Predicted_count":
                    int(
                        tp
                        + fp
                    ),

                "Correct_count":
                    int(
                        tp
                    ),

                "Wrong_count":
                    int(
                        fn
                    ),

                "TP":
                    int(
                        tp
                    ),

                "FP":
                    int(
                        fp
                    ),

                "FN":
                    int(
                        fn
                    ),

                "TN":
                    int(
                        tn
                    ),

                "Total_samples":
                    int(
                        total
                    ),
            }
        )

    return rows


def ordered_classes(
    true_values,
    predicted_values,
):
    classes = sorted(
        set(
            true_values
        )
        |
        set(
            predicted_values
        ),
        key=lambda x:
            str(
                x
            ).lower(),
    )

    # Keep nonARG at the end for easier reading.
    nonarg_matches = [
        value
        for value in classes
        if str(
            value
        ).strip().lower()
        == "nonarg"
    ]

    if nonarg_matches:

        nonarg_value = nonarg_matches[
            0
        ]

        classes = [
            value
            for value in classes
            if value
            != nonarg_value
        ]

        classes.append(
            nonarg_value
        )

    return classes


# =============================================================================
# Data loading
# =============================================================================

def load_prediction_file(
    path: Path,
    condition: str,
):
    df = pd.read_csv(
        path
    )

    required = [
        "condition",
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
        "true_ARG",
        "predicted_ARG",
    ]

    missing = [
        column
        for column in required
        if column not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Missing columns in:\n{path}\n"
            f"{missing}\n"
            f"Available columns:\n{list(df.columns)}"
        )

    if len(df) == 0:
        raise ValueError(
            f"Empty file: {path}"
        )

    df = df.dropna(
        subset=[
            "true_subtype",
            "predicted_subtype",
            "true_type",
            "predicted_type",
            "true_ARG",
            "predicted_ARG",
        ]
    ).copy()

    for column in (
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
    ):
        df[
            column
        ] = (
            df[
                column
            ]
            .astype(
                str
            )
            .str
            .strip()
        )

    df[
        "true_ARG"
    ] = pd.to_numeric(
        df[
            "true_ARG"
        ],
        errors="raise",
    ).astype(
        int
    )

    df[
        "predicted_ARG"
    ] = pd.to_numeric(
        df[
            "predicted_ARG"
        ],
        errors="raise",
    ).astype(
        int
    )

    observed_conditions = sorted(
        set(
            df[
                "condition"
            ]
            .astype(
                str
            )
            .str
            .strip()
        )
    )

    if observed_conditions != [
        condition
    ]:
        raise ValueError(
            f"Unexpected condition values in {path}:\n"
            f"{observed_conditions}\n"
            f"Expected only: {condition}"
        )

    return df


# =============================================================================
# Per-condition analysis
# =============================================================================

def analyze_condition(
    df: pd.DataFrame,
    condition: str,
):
    # -------------------------------------------------------------------------
    # Subtype: ALL samples, nonARG included.
    # -------------------------------------------------------------------------

    subtype_overall = multiclass_metrics(
        df[
            "true_subtype"
        ].to_numpy(),
        df[
            "predicted_subtype"
        ].to_numpy(),
        condition,
        "Subtype_end_to_end",
    )

    # -------------------------------------------------------------------------
    # ARG-only subtype:
    # true ARG only, but FINAL predicted subtype retained.
    # ARG -> nonARG therefore remains an error.
    # -------------------------------------------------------------------------

    arg_only = df.loc[
        df[
            "true_ARG"
        ]
        == 1
    ].copy()

    if len(
        arg_only
    ) == 0:
        raise ValueError(
            f"No true ARG rows in {condition}"
        )

    arg_only_subtype_overall = multiclass_metrics(
        arg_only[
            "true_subtype"
        ].to_numpy(),
        arg_only[
            "predicted_subtype"
        ].to_numpy(),
        condition,
        "ARG_only_Subtype_final_prediction",
    )

    # -------------------------------------------------------------------------
    # Type: ALL samples, nonARG included.
    # -------------------------------------------------------------------------

    type_overall = multiclass_metrics(
        df[
            "true_type"
        ].to_numpy(),
        df[
            "predicted_type"
        ].to_numpy(),
        condition,
        "Type_end_to_end",
    )

    # -------------------------------------------------------------------------
    # Per subtype
    # -------------------------------------------------------------------------

    subtype_classes = ordered_classes(
        df[
            "true_subtype"
        ].tolist(),
        df[
            "predicted_subtype"
        ].tolist(),
    )

    per_subtype = one_vs_rest_metrics(
        df[
            "true_subtype"
        ].to_numpy(),
        df[
            "predicted_subtype"
        ].to_numpy(),
        subtype_classes,
        condition,
        "Subtype_one_vs_rest",
        "Subtype",
    )

    # -------------------------------------------------------------------------
    # Per Type
    # -------------------------------------------------------------------------

    type_classes = ordered_classes(
        df[
            "true_type"
        ].tolist(),
        df[
            "predicted_type"
        ].tolist(),
    )

    per_type = one_vs_rest_metrics(
        df[
            "true_type"
        ].to_numpy(),
        df[
            "predicted_type"
        ].to_numpy(),
        type_classes,
        condition,
        "Type_one_vs_rest",
        "Type",
    )

    # -------------------------------------------------------------------------
    # Counts / QC
    # -------------------------------------------------------------------------

    counts = {
        "condition":
            condition,

        "N_fragments":
            int(
                len(
                    df
                )
            ),

        "True_ARG_count":
            int(
                (
                    df[
                        "true_ARG"
                    ]
                    == 1
                ).sum()
            ),

        "True_nonARG_count":
            int(
                (
                    df[
                        "true_ARG"
                    ]
                    == 0
                ).sum()
            ),

        "True_Subtype_count":
            int(
                df[
                    "true_subtype"
                ].nunique()
            ),

        "Predicted_Subtype_count":
            int(
                df[
                    "predicted_subtype"
                ].nunique()
            ),

        "True_Type_count":
            int(
                df[
                    "true_type"
                ].nunique()
            ),

        "Predicted_Type_count":
            int(
                df[
                    "predicted_type"
                ].nunique()
            ),
    }

    # -------------------------------------------------------------------------
    # Compact summary rows
    # -------------------------------------------------------------------------

    summary_rows = []

    for evaluation_name, metrics in (
        (
            "Subtype",
            subtype_overall,
        ),
        (
            "ARG_only_Subtype",
            arg_only_subtype_overall,
        ),
        (
            "Type",
            type_overall,
        ),
    ):

        for average, prefix in (
            (
                "macro",
                "Macro",
            ),
            (
                "weighted",
                "Weighted",
            ),
            (
                "micro",
                "Micro",
            ),
        ):

            summary_rows.append(
                {
                    "condition":
                        condition,

                    "evaluation":
                        evaluation_name,

                    "average":
                        average,

                    "ACC":
                        metrics[
                            "ACC"
                        ],

                    "Precision":
                        metrics[
                            f"{prefix}_Precision"
                        ],

                    "Recall":
                        metrics[
                            f"{prefix}_Recall"
                        ],

                    "F1":
                        metrics[
                            f"{prefix}_F1"
                        ],

                    "MCC":
                        metrics[
                            "MCC"
                        ],

                    "N":
                        metrics[
                            "N"
                        ],

                    "True_class_count":
                        metrics[
                            "True_class_count"
                        ],
                }
            )

    return {
        "Subtype_overall":
            subtype_overall,

        "ARG_only_Subtype_overall":
            arg_only_subtype_overall,

        "Type_overall":
            type_overall,

        "per_Subtype":
            per_subtype,

        "per_Type":
            per_type,

        "counts":
            counts,

        "summary_rows":
            summary_rows,
    }


# =============================================================================
# Saving
# =============================================================================

def save_dataframe(
    dataframe: pd.DataFrame,
    path: Path,
    overwrite: bool,
):
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    if (
        path.exists()
        and not overwrite
    ):
        raise FileExistsError(
            f"Output already exists:\n{path}\n"
            "Use --overwrite to replace existing output."
        )

    dataframe.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# Main
# =============================================================================

def main():
    args = parse_args()

    script_dir = Path(
        __file__
    ).resolve().parent

    if (
        args.results_root
        is None
    ):
        results_root = detect_results_root(
            script_dir
        )
    else:
        results_root = (
            args.results_root
            .expanduser()
            .resolve()
        )

    if (
        args.output_dir
        is None
    ):
        output_dir = (
            results_root
            / OUTPUT_DIRNAME
        )
    else:
        output_dir = (
            args.output_dir
            .expanduser()
            .resolve()
        )

    print(
        "=" * 110
    )
    print(
        "ARGScope DNA percent_60/70/80/90 Type/Subtype metric recalculation"
    )
    print(
        "=" * 110
    )
    print(
        f"Results root : {results_root}"
    )
    print(
        f"Output dir   : {output_dir}"
    )
    print(
        f"Conditions   : {args.conditions}"
    )

    all_summary_rows = []
    all_subtype_overall = []
    all_arg_only_subtype_overall = []
    all_type_overall = []
    all_per_subtype = []
    all_per_type = []
    all_counts = []

    for condition in args.conditions:

        prediction_path = (
            results_root
            / condition
            / INPUT_FILENAME
        )

        if not prediction_path.is_file():
            raise FileNotFoundError(
                f"Prediction file not found:\n"
                f"{prediction_path}"
            )

        print()
        print(
            "-" * 110
        )
        print(
            f"Processing: {condition}"
        )
        print(
            f"Input     : {prediction_path}"
        )

        df = load_prediction_file(
            prediction_path,
            condition,
        )

        result = analyze_condition(
            df,
            condition,
        )

        condition_output = (
            output_dir
            / condition
        )

        # Save each condition separately.
        save_dataframe(
            pd.DataFrame(
                [
                    result[
                        "Subtype_overall"
                    ]
                ]
            ),
            condition_output
            / "Subtype_overall_metrics.csv",
            args.overwrite,
        )

        save_dataframe(
            pd.DataFrame(
                [
                    result[
                        "ARG_only_Subtype_overall"
                    ]
                ]
            ),
            condition_output
            / "ARG_only_Subtype_overall_metrics.csv",
            args.overwrite,
        )

        save_dataframe(
            pd.DataFrame(
                [
                    result[
                        "Type_overall"
                    ]
                ]
            ),
            condition_output
            / "Type_overall_metrics.csv",
            args.overwrite,
        )

        save_dataframe(
            pd.DataFrame(
                result[
                    "per_Subtype"
                ]
            ),
            condition_output
            / "per_Subtype_metrics.csv",
            args.overwrite,
        )

        save_dataframe(
            pd.DataFrame(
                result[
                    "per_Type"
                ]
            ),
            condition_output
            / "per_Type_metrics.csv",
            args.overwrite,
        )

        # Collect combined tables.
        all_summary_rows.extend(
            result[
                "summary_rows"
            ]
        )

        all_subtype_overall.append(
            result[
                "Subtype_overall"
            ]
        )

        all_arg_only_subtype_overall.append(
            result[
                "ARG_only_Subtype_overall"
            ]
        )

        all_type_overall.append(
            result[
                "Type_overall"
            ]
        )

        all_per_subtype.extend(
            result[
                "per_Subtype"
            ]
        )

        all_per_type.extend(
            result[
                "per_Type"
            ]
        )

        all_counts.append(
            result[
                "counts"
            ]
        )

        subtype = result[
            "Subtype_overall"
        ]

        type_result = result[
            "Type_overall"
        ]

        print(
            f"{condition} | "
            f"N={len(df):,} | "
            f"Subtype ACC={subtype['ACC']:.6f} | "
            f"Subtype Macro-F1={subtype['Macro_F1']:.6f} | "
            f"Subtype Weighted-F1={subtype['Weighted_F1']:.6f} | "
            f"Type ACC={type_result['ACC']:.6f} | "
            f"Type Macro-F1={type_result['Macro_F1']:.6f} | "
            f"Type Weighted-F1={type_result['Weighted_F1']:.6f}"
        )

    # -------------------------------------------------------------------------
    # Combined 60-90 tables
    # -------------------------------------------------------------------------

    save_dataframe(
        pd.DataFrame(
            all_summary_rows
        ),
        output_dir
        / "00_ALL_main_summary.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_subtype_overall
        ),
        output_dir
        / "01_ALL_Subtype_overall_metrics.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_arg_only_subtype_overall
        ),
        output_dir
        / "02_ALL_ARG_only_Subtype_overall_metrics.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_type_overall
        ),
        output_dir
        / "03_ALL_Type_overall_metrics.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_per_subtype
        ),
        output_dir
        / "04_ALL_per_Subtype_metrics.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_per_type
        ),
        output_dir
        / "05_ALL_per_Type_metrics.csv",
        args.overwrite,
    )

    save_dataframe(
        pd.DataFrame(
            all_counts
        ),
        output_dir
        / "06_class_counts_by_condition.csv",
        args.overwrite,
    )

    print()
    print(
        "=" * 110
    )
    print(
        "FINISHED"
    )
    print(
        "=" * 110
    )
    print(
        f"Output folder:\n{output_dir}"
    )
    print()
    print(
        "Main files:"
    )
    print(
        "  00_ALL_main_summary.csv"
    )
    print(
        "  01_ALL_Subtype_overall_metrics.csv"
    )
    print(
        "  02_ALL_ARG_only_Subtype_overall_metrics.csv"
    )
    print(
        "  03_ALL_Type_overall_metrics.csv"
    )
    print(
        "  04_ALL_per_Subtype_metrics.csv"
    )
    print(
        "  05_ALL_per_Type_metrics.csv"
    )
    print(
        "  06_class_counts_by_condition.csv"
    )


if __name__ == "__main__":
    main()
