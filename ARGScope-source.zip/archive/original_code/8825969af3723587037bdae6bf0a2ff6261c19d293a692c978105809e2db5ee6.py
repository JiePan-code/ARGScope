"""Read back exported XLSX values, confirm sources unchanged, emit evidence."""
import csv
import hashlib
import json
import math
import posixpath
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

base = Path(__file__).resolve().parent.parent
qa = base/'outputs/vf_bgc_consistent_metrics_20260921'
specs = json.loads((qa/'workbook_expectations.json').read_text(encoding='utf-8'))
ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
rns = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
verified_cells = 0
queries = []

for spec in specs:
    file = Path(spec['path'])
    with zipfile.ZipFile(file) as z:
        strings = []
        if 'xl/sharedStrings.xml' in z.namelist():
            strings = [''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        rels = {n.attrib['Id']: n.attrib['Target'] for n in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        sheets = {}
        for s in ET.fromstring(z.read('xl/workbook.xml')).find('s:sheets',ns):
            target = rels[s.attrib['{'+rns+'}id']]
            target = target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl',target))
            root = ET.fromstring(z.read(target))
            assert root.find('s:sheetViews/s:sheetView',ns).attrib.get('showGridLines') == '0'
            cells = {}
            for c in root.findall('.//s:sheetData/s:row/s:c', ns):
                value = c.find('s:v',ns)
                value = value.text if value is not None else None
                if c.attrib.get('t') == 's':
                    value = strings[int(value)]
                elif c.attrib.get('t') == 'inlineStr':
                    value = ''.join(c.find('s:is',ns).itertext())
                elif c.attrib.get('t') not in ['str','e'] and value is not None:
                    value = float(value)
                cells[c.attrib['r']] = value
            sheets[s.attrib['name']] = cells
        for section in spec['ranges']:
            for i, row in enumerate(section['expected']):
                for j, want in enumerate(row):
                    address = f"{chr(65+j)}{i+section['startRow']}"
                    got = sheets[section['sheet']][address]
                    if isinstance(want, (float,int)):
                        assert math.isclose(got,want,rel_tol=0,abs_tol=1e-12), (file, section['sheet'], address,got,want)
                    else:
                        assert got==want, (file, section['sheet'], address,got,want)
                    verified_cells += 1
        assert b'0.0000' in z.read('xl/styles.xml')
    folder = file.parent
    with (folder/'08_source_manifest.csv').open(encoding='utf-8-sig',newline='') as f:
        manifest = list(csv.DictReader(f))
    for entry in manifest:
        with Path(entry['Path']).open('rb') as f:
            assert hashlib.file_digest(f,'sha256').hexdigest()==entry['SHA256']
    payload = json.loads((folder/'results_for_workbook.json').read_text(encoding='utf-8'))
    audit = json.loads((folder/'verification.json').read_text(encoding='utf-8'))
    audit['exported_xlsx_numeric_readback_passed'] = True
    audit['workbook_visual_review_all_three_sheets'] = 'passed'
    audit['source_hashes_rechecked_after_export'] = True
    (folder/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    sources = [{'label':str(Path(e['Path']).parent.name+'/'+Path(e['Path']).name)}
               for e in manifest if e['Role'] in ['Test sequence predictions','Full split label universe']]
    queries.append({
        'id':payload['domain'].lower()+'-recalculated',
        'source':{
            'label':payload['domain']+' 逐序列重算', 'files':sources,
            'metricDefinitions':[
                {'label':'Type','definition':'仅真实目标序列；固定全部生物学 Type；漏检保留计错；主报 macro。'},
                {'label':'二分类','definition':'全部测试序列含正负两类；主报 macro。'},
                {'label':'Subtype','definition':'全部测试序列含非目标类；主报 weighted；另附 macro 和 micro。'},
            ],
            'filters':['数据划分：test'],
            'caveats':['Subtype 的 weighted 指标包含非目标类，不是仅正样本的亚型识别结果。',
                       '统计范围与主报平均方式更新，预测、模型及阈值均未修改。'],
            'evidenceFlow':[
                {'kind':'validation','title':'测试集和标签核对','detail':'四份预测分别与各自的 test_ids.txt、测试标签表匹配；无重复ID，Type标签与元数据逐项一致。'},
                {'kind':'calculation','title':'指标重算','detail':'ACC、MCC按对应任务总体计算；Precision、Recall、F1给出macro、weighted和micro。'},
                {'kind':'validation','title':'独立核算与文件导出','detail':'计数法与独立混淆矩阵法差值小于1e-12；所有旧口径指标复现至原文件8位小数；导出Excel逐单元格回读一致，源文件哈希未变。'},
            ],
        },
        'columns':['Model','Task','Average','ACC','Precision','Recall','F1','MCC'],
        'rows':payload['main'],
        'preview':{'kind':'aggregate','note':'两种输入的三项任务主结果。完整平均方式和类别结果已保存。','totalRows':6},
    })

(qa/'delivery_check.json').write_text(json.dumps({'verified_cells':verified_cells,'workbooks':2,'status':'passed'}),encoding='utf-8')
(base/'work_vf_bgc_reporting_audit/recalculated_sources.json').write_text(json.dumps({
    'schemaVersion':1,'items':[{'id':'consistent-vf-bgc-results','title':'VF与BGC结果按前文口径重新计算','queries':queries}]
},ensure_ascii=False,indent=2),encoding='utf-8')
print(f'PASS: {verified_cells} saved XLSX cells; 2 workbooks; all source hashes unchanged.')
