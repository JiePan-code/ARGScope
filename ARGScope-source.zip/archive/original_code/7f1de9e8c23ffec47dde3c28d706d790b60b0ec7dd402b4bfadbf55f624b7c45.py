#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Official DNABERT-2 mean embedding for the corrected BGC/nonBGC DNA FASTA.

Input:
  /scratch/users/ntu/pan.jie/work/BGCdataset/
  dataset/corrected_BGC_nonBGC_dna.fasta

Scientific definition
---------------------
model      : zhihan1996/DNABERT-2-117M
tokenizer  : official native DNABERT-2 BPE
config     : official config.json values unchanged
output     : final hidden states
pooling    : official mean pooling over all valid tokenizer tokens
dimension  : 768
dtype      : float32
truncation : OFF

The BGC DNA file contains exceptionally long records. Sequences whose BPE
token count exceeds --max-window-tokens are split into contiguous token
windows for GPU inference. Every original token is retained exactly once,
and window embeddings are combined with token-count-weighted mean pooling.
Short sequences are processed exactly as in the original VF script. Global
self-attention does not cross window boundaries for windowed sequences.

Batched mean:
  sum(hidden_states * attention_mask) / sum(attention_mask)

This is the padded-batch equivalent of the official single-sequence example:
  torch.mean(hidden_states[0], dim=0)

NSCC compatibility
------------------
1. Newer transformers rejects the local remote-code BertConfig class mismatch.
   We therefore load the same official config.json values using the standard
   transformers.BertConfig class. No config value is modified.

2. DNABERT-2's bundled legacy Triton kernel uses the old
   tl.dot(..., trans_b=True) API and is incompatible with the current Triton.
   We force the official bert_layers.py PyTorch attention fallback by setting
   only the module-global flash_attn_qkvpacked_func pointer to None.

The following remain unchanged:
  pretrained weights
  attention_probs_dropout_prob = 0.0
  hidden_dropout_prob = 0.1
  ALiBi configuration
  tokenizer
  pooling
  embedding dimension

A100 engineering
----------------
CUDA only; no CPU fallback.
TF32 on by default.
Length bucketing.
Adaptive batch size using attention-cost budget.
CUDA OOM -> lower attention budget and retry.
CPU tokenization in chunks with live heartbeat.
Pinned memory + non-blocking transfer.
No normal-path torch.cuda.empty_cache() calls.
"""

from __future__ import annotations

import os

ROOT_STR = (
    "/scratch/users/ntu/pan.jie/work/BGCdataset"
)

# ---------------------------------------------------------------------
# Put all runtime/JIT/cache files on scratch, not quota-limited $HOME.
# This affects cache location only, not model calculations.
# ---------------------------------------------------------------------

CACHE_ROOT = os.environ.get(
    "BGC_RUNTIME_CACHE",
    f"{ROOT_STR}/.runtime_cache",
)

CACHE_ENV = {
    "XDG_CACHE_HOME":
        f"{CACHE_ROOT}/xdg",

    "HF_HOME":
        f"{CACHE_ROOT}/huggingface",

    "HF_MODULES_CACHE":
        f"{CACHE_ROOT}/huggingface/modules",

    "TRITON_CACHE_DIR":
        f"{CACHE_ROOT}/triton",

    "CUDA_CACHE_PATH":
        f"{CACHE_ROOT}/cuda",

    "TORCHINDUCTOR_CACHE_DIR":
        f"{CACHE_ROOT}/torchinductor",
}

for env_name, folder in CACHE_ENV.items():
    os.environ[env_name] = folder
    os.makedirs(
        folder,
        exist_ok=True,
    )

os.environ.pop(
    "TRANSFORMERS_CACHE",
    None,
)

ORIGINAL_CUDA_VISIBLE_DEVICES = os.environ.get(
    "CUDA_VISIBLE_DEVICES",
    "",
)

if ORIGINAL_CUDA_VISIBLE_DEVICES.startswith(
    "GPU-"
):
    os.environ[
        "ORIGINAL_CUDA_VISIBLE_DEVICES"
    ] = ORIGINAL_CUDA_VISIBLE_DEVICES

    os.environ[
        "CUDA_VISIBLE_DEVICES"
    ] = "0"

import argparse
import gc
import hashlib
import json
import threading
import time
from pathlib import Path

import torch
from transformers import (
    AutoModel,
    AutoTokenizer,
    BertConfig,
)


ROOT = Path(ROOT_STR)

DEFAULT_FASTA = (
    ROOT
    / "dataset/corrected_BGC_nonBGC_dna.fasta"
)

DEFAULT_OUT = (
    ROOT
    / "DNABERT2_BGC"
)

MODEL_PATH = Path(
    "/scratch/users/ntu/pan.jie/work/DNABERT/model/DNABERT-2-117M"
)

MODEL_NAME = "zhihan1996/DNABERT-2-117M"
DIM = 768

POOLING = "official_mean_pooling"

SCRIPT_VERSION = (
    "2026-09-15-dnabert2-bgc-v1"
)

# Input DNA QC. Standard IUPAC DNA symbols are accepted.
IUPAC_DNA = frozenset(
    "ACGTRYSWKMBDHVN"
)


# =============================================================================
# CLI
# =============================================================================

def parse_args():

    p = argparse.ArgumentParser()

    p.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_FASTA,
    )

    p.add_argument(
        "--out",
        type=Path,
        default=DEFAULT_OUT,
    )

    p.add_argument(
        "--model",
        type=Path,
        default=MODEL_PATH,
    )

    p.add_argument(
        "--tokenize-chunk",
        type=int,
        default=5000,
        help=(
            "Number of DNA sequences tokenized per CPU tokenizer call."
        ),
    )

    p.add_argument(
        "--max-window-tokens",
        type=int,
        default=2048,
        help=(
            "Maximum BPE tokens per GPU window. All tokens are retained "
            "and window means are token-count weighted. 0 disables "
            "windowing (unsafe for exceptionally long BGC records)."
        ),
    )

    p.add_argument(
        "--max-batch",
        type=int,
        default=0,
        help=(
            "Maximum sequence batch. 0 = auto for GPU memory."
        ),
    )

    p.add_argument(
        "--attention-budget",
        type=int,
        default=0,
        help=(
            "Approximate batch_size * max_token_length^2. "
            "0 = auto."
        ),
    )

    p.add_argument(
        "--log-interval",
        type=int,
        default=30,
    )

    p.add_argument(
        "--disable-tf32",
        action="store_true",
    )

    p.add_argument(
        "--overwrite",
        action="store_true",
    )

    return p.parse_args()


# =============================================================================
# Live heartbeat
# =============================================================================

class Heartbeat:

    def __init__(
        self,
        interval,
    ):

        self.interval = max(
            5,
            int(
                interval
            ),
        )

        self.lock = threading.Lock()

        self.stop_event = (
            threading.Event()
        )

        self.thread = None

        self.phase = "startup"
        self.done = 0
        self.total = 0
        self.note = ""

        self.started = time.time()

    def update(
        self,
        phase=None,
        done=None,
        total=None,
        note=None,
    ):

        with self.lock:

            if phase is not None:
                self.phase = str(
                    phase
                )

            if done is not None:
                self.done = int(
                    done
                )

            if total is not None:
                self.total = int(
                    total
                )

            if note is not None:
                self.note = str(
                    note
                )

    def emit(self):

        with self.lock:
            phase = self.phase
            done = self.done
            total = self.total
            note = self.note
            started = self.started

        elapsed = max(
            time.time()
            - started,
            1e-9,
        )

        if total > 0:

            pct = (
                100.0
                * done
                / total
            )

            rate = (
                done
                / elapsed
            )

            progress = (
                f"{done:,}/{total:,} "
                f"({pct:.2f}%) | "
                f"{rate:.1f} seq/s"
            )

        else:

            progress = "progress=NA"

        try:

            allocated = (
                torch.cuda
                .memory_allocated(
                    0
                )
                / (1024 ** 3)
            )

            reserved = (
                torch.cuda
                .memory_reserved(
                    0
                )
                / (1024 ** 3)
            )

            gpu_text = (
                f"GPU_alloc="
                f"{allocated:.2f}GB | "
                f"GPU_reserved="
                f"{reserved:.2f}GB"
            )

        except Exception:

            gpu_text = "GPU_mem=NA"

        print(
            f"[HEARTBEAT] "
            f"{time.strftime('%Y-%m-%d %H:%M:%S')} | "
            f"phase={phase} | "
            f"{progress} | "
            f"{gpu_text}"
            f"{' | ' + note if note else ''}",
            flush=True,
        )

    def loop(self):

        while not self.stop_event.wait(
            self.interval
        ):
            self.emit()

    def start(self):

        self.started = time.time()

        self.thread = threading.Thread(
            target=self.loop,
            daemon=True,
        )

        self.thread.start()

        self.emit()

    def stop(self):

        self.stop_event.set()

        if self.thread is not None:
            self.thread.join(
                timeout=5,
            )

        self.emit()


# =============================================================================
# FASTA
# =============================================================================

def read_fasta(
    path: Path,
    hb: Heartbeat,
):

    ids = []
    headers = []
    sequences = []

    current_header = None
    sequence_parts = []

    hb.update(
        phase="reading_fasta",
        done=0,
        total=0,
        note=str(
            path
        ),
    )

    with path.open(
        "r",
        encoding="utf-8",
    ) as handle:

        for line_number, raw in enumerate(
            handle,
            start=1,
        ):

            line = raw.strip()

            if not line:
                continue

            if line.startswith(">"):

                if current_header is not None:

                    sequence = "".join(
                        sequence_parts
                    ).upper()

                    sequence_id = (
                        current_header
                        .split()[0]
                    )

                    ids.append(
                        sequence_id
                    )

                    headers.append(
                        current_header
                    )

                    sequences.append(
                        sequence
                    )

                    if len(ids) % 5000 == 0:

                        hb.update(
                            phase="reading_fasta",
                            done=len(
                                ids
                            ),
                            total=0,
                            note=(
                                f"records_read="
                                f"{len(ids):,}"
                            ),
                        )

                        print(
                            f"[FASTA] "
                            f"read {len(ids):,} records",
                            flush=True,
                        )

                current_header = (
                    line[1:]
                    .strip()
                )

                if not current_header:

                    raise ValueError(
                        f"Empty FASTA header "
                        f"at line {line_number}"
                    )

                sequence_parts = []

            else:

                if current_header is None:

                    raise ValueError(
                        f"Sequence before FASTA header "
                        f"at line {line_number}"
                    )

                sequence_parts.append(
                    "".join(
                        line.split()
                    )
                )

    if current_header is not None:

        sequence = "".join(
            sequence_parts
        ).upper()

        sequence_id = (
            current_header
            .split()[0]
        )

        ids.append(
            sequence_id
        )

        headers.append(
            current_header
        )

        sequences.append(
            sequence
        )

    if not ids:

        raise RuntimeError(
            "No DNA FASTA records found."
        )

    if len(ids) != len(set(ids)):

        raise RuntimeError(
            "Duplicate FASTA IDs found."
        )

    invalid_counts = {}

    for sequence in sequences:

        for symbol in set(
            sequence
        ):

            if symbol not in IUPAC_DNA:

                invalid_counts[
                    symbol
                ] = (
                    invalid_counts.get(
                        symbol,
                        0,
                    )
                    + sequence.count(
                        symbol
                    )
                )

    if invalid_counts:

        raise RuntimeError(
            "Non-IUPAC DNA symbols found: "
            f"{invalid_counts}"
        )

    hb.update(
        phase="reading_fasta",
        done=len(
            ids
        ),
        total=len(
            ids
        ),
        note="FASTA read completed",
    )

    return (
        ids,
        headers,
        sequences,
    )


# =============================================================================
# Utility
# =============================================================================

def sha_ids(
    ids,
):

    h = hashlib.sha256()

    for seq_id in ids:

        h.update(
            seq_id.encode(
                "utf-8"
            )
        )

        h.update(
            b"\0"
        )

    return h.hexdigest()


def atomic_json(
    path,
    obj,
):

    tmp = path.with_suffix(
        path.suffix
        + ".tmp"
    )

    with tmp.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            obj,
            handle,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(
        tmp,
        path,
    )


def safe_save(
    obj,
    path,
):

    tmp = path.with_suffix(
        path.suffix
        + ".tmp"
    )

    if tmp.exists():
        tmp.unlink()

    torch.save(
        obj,
        tmp,
    )

    if (
        not tmp.is_file()
        or tmp.stat().st_size <= 0
    ):

        raise RuntimeError(
            f"Invalid temporary PT: "
            f"{tmp}"
        )

    os.replace(
        tmp,
        path,
    )


# =============================================================================
# Official model + environment compatibility
# =============================================================================

def force_official_pytorch_attention(
    model,
):

    """
    Force the PyTorch attention branch already present in official
    DNABERT-2 bert_layers.py.

    Only the module-global legacy Triton function pointer is set to None.
    No weights/config values are changed.
    """

    affected = 0

    for module in model.modules():

        if (
            module.__class__.__name__
            == "BertUnpadSelfAttention"
        ):

            fn = getattr(
                module.forward,
                "__func__",
                None,
            )

            if fn is None:

                raise RuntimeError(
                    "Cannot access DNABERT-2 "
                    "attention forward globals."
                )

            globals_dict = (
                fn.__globals__
            )

            if (
                "flash_attn_qkvpacked_func"
                not in globals_dict
            ):

                raise RuntimeError(
                    "DNABERT-2 attention global "
                    "flash_attn_qkvpacked_func "
                    "not found."
                )

            globals_dict[
                "flash_attn_qkvpacked_func"
            ] = None

            affected += 1

    if affected < 1:

        raise RuntimeError(
            "No DNABERT-2 attention layers found."
        )

    return affected


def load_model(
    model_path,
    device,
):

    print(
        "\n===== LOAD OFFICIAL DNABERT-2 =====",
        flush=True,
    )

    tokenizer = (
        AutoTokenizer
        .from_pretrained(
            str(
                model_path
            ),
            trust_remote_code=True,
            local_files_only=True,
        )
    )

    # Compatibility fix for current transformers:
    # same official config.json VALUES, standard BertConfig Python class.
    config = (
        BertConfig
        .from_pretrained(
            str(
                model_path
            ),
            local_files_only=True,
        )
    )

    model = (
        AutoModel
        .from_pretrained(
            str(
                model_path
            ),
            config=config,
            trust_remote_code=True,
            local_files_only=True,
        )
    )

    expected = {
        "hidden_size":
            768,

        "attention_probs_dropout_prob":
            0.0,

        "hidden_dropout_prob":
            0.1,

        "alibi_starting_size":
            512,
    }

    for field, expected_value in expected.items():

        actual = getattr(
            model.config,
            field,
            None,
        )

        if actual != expected_value:

            raise RuntimeError(
                f"Unexpected official config value: "
                f"{field}={actual}; "
                f"expected={expected_value}"
            )

    model = (
        model
        .to(
            device
        )
        .eval()
    )

    fallback_layers = (
        force_official_pytorch_attention(
            model
        )
    )

    print(
        f"Model                 : "
        f"{MODEL_NAME}",
        flush=True,
    )

    print(
        f"Tokenizer             : "
        f"{tokenizer.__class__.__name__}",
        flush=True,
    )

    print(
        f"Config class          : "
        f"{model.config.__class__.__module__}."
        f"{model.config.__class__.__name__}",
        flush=True,
    )

    print(
        f"hidden_size           : "
        f"{model.config.hidden_size}",
        flush=True,
    )

    print(
        f"attention dropout     : "
        f"{model.config.attention_probs_dropout_prob}",
        flush=True,
    )

    print(
        f"hidden dropout        : "
        f"{model.config.hidden_dropout_prob}",
        flush=True,
    )

    print(
        f"ALiBi start size      : "
        f"{model.config.alibi_starting_size}",
        flush=True,
    )

    print(
        f"Attention backend     : "
        f"official PyTorch fallback",
        flush=True,
    )

    print(
        f"Fallback layers       : "
        f"{fallback_layers}",
        flush=True,
    )

    print(
        f"Pooling               : "
        f"{POOLING}",
        flush=True,
    )

    return (
        tokenizer,
        model,
        fallback_layers,
    )


# =============================================================================
# Tokenization
# =============================================================================

def tokenize_all(
    sequences,
    tokenizer,
    chunk_size,
    hb,
):

    total = len(
        sequences
    )

    all_token_ids = []

    hb.update(
        phase="tokenizing",
        done=0,
        total=total,
        note=(
            "official DNABERT-2 BPE; "
            "truncation=False"
        ),
    )

    for start in range(
        0,
        total,
        chunk_size,
    ):

        end = min(
            total,
            start
            + chunk_size,
        )

        encoded = tokenizer(
            sequences[
                start:
                end
            ],
            add_special_tokens=True,
            padding=False,
            truncation=False,
            return_attention_mask=False,
            return_token_type_ids=False,
        )

        token_ids = encoded[
            "input_ids"
        ]

        if len(
            token_ids
        ) != (
            end
            - start
        ):

            raise RuntimeError(
                "Tokenizer output count mismatch."
            )

        all_token_ids.extend(
            token_ids
        )

        hb.update(
            phase="tokenizing",
            done=end,
            total=total,
            note=(
                f"chunk="
                f"{start:,}-"
                f"{end:,}"
            ),
        )

        print(
            f"[TOKENIZE] "
            f"{end:,}/{total:,}",
            flush=True,
        )

    token_lengths = [
        len(
            token_ids
        )
        for token_ids
        in all_token_ids
    ]

    return (
        all_token_ids,
        token_lengths,
    )


def make_token_windows(
    token_ids,
    max_window_tokens,
):
    """Split long token lists without dropping or duplicating any token."""

    window_token_ids = []
    window_owners = []
    window_weights = []
    windows_per_sequence = []

    for owner, sequence_tokens in enumerate(token_ids):

        if max_window_tokens == 0:
            chunks = [sequence_tokens]
        else:
            chunks = [
                sequence_tokens[start:start + max_window_tokens]
                for start in range(
                    0,
                    len(sequence_tokens),
                    max_window_tokens,
                )
            ]

        if not chunks:
            raise RuntimeError(
                f"Tokenizer produced no tokens for sequence index {owner}."
            )

        windows_per_sequence.append(len(chunks))

        for chunk in chunks:
            window_token_ids.append(chunk)
            window_owners.append(owner)
            window_weights.append(len(chunk))

    window_lengths = [
        len(chunk)
        for chunk in window_token_ids
    ]

    return (
        window_token_ids,
        window_lengths,
        window_owners,
        window_weights,
        windows_per_sequence,
    )


def combine_window_embeddings(
    window_embeddings,
    window_owners,
    window_weights,
    num_sequences,
):
    """Token-count-weighted mean of all windows belonging to a sequence."""

    owner_tensor = torch.tensor(
        window_owners,
        dtype=torch.long,
    )
    weight_tensor = torch.tensor(
        window_weights,
        dtype=torch.float32,
    )

    sequence_embeddings = torch.zeros(
        (num_sequences, DIM),
        dtype=torch.float32,
    )
    sequence_weights = torch.zeros(
        num_sequences,
        dtype=torch.float32,
    )

    sequence_embeddings.index_add_(
        0,
        owner_tensor,
        window_embeddings
        * weight_tensor.unsqueeze(1),
    )
    sequence_weights.index_add_(
        0,
        owner_tensor,
        weight_tensor,
    )

    if torch.any(sequence_weights <= 0):
        raise RuntimeError("A sequence received zero pooled token weight.")

    sequence_embeddings.div_(
        sequence_weights.unsqueeze(1)
    )

    return sequence_embeddings.contiguous()


# =============================================================================
# A100 batching
# =============================================================================

def auto_limits(
    device,
    args,
):

    memory_gb = (
        torch.cuda
        .get_device_properties(
            device
        )
        .total_memory
        / (1024 ** 3)
    )

    if memory_gb >= 75:

        max_batch = 512
        budget = 32_000_000

    elif memory_gb >= 39:

        max_batch = 256
        budget = 16_000_000

    elif memory_gb >= 23:

        max_batch = 128
        budget = 8_000_000

    else:

        max_batch = 64
        budget = 4_000_000

    if args.max_batch > 0:

        max_batch = (
            args.max_batch
        )

    if args.attention_budget > 0:

        budget = (
            args.attention_budget
        )

    return (
        memory_gb,
        max_batch,
        budget,
    )


def choose_batch_size(
    sorted_lengths,
    start,
    max_batch,
    budget,
):

    remaining = (
        len(
            sorted_lengths
        )
        - start
    )

    batch_size = min(
        max_batch,
        remaining,
    )

    while batch_size > 1:

        max_len = sorted_lengths[
            start
            + batch_size
            - 1
        ]

        cost = (
            batch_size
            * max_len
            * max_len
        )

        if cost <= budget:
            break

        estimated = max(
            1,
            int(
                budget
                // max(
                    1,
                    max_len
                    * max_len,
                )
            ),
        )

        if estimated >= batch_size:

            batch_size -= 1

        else:

            batch_size = (
                estimated
            )

    return max(
        1,
        batch_size,
    )


def padded_batch(
    token_lists,
    pad_id,
):

    batch_size = len(
        token_lists
    )

    max_len = max(
        len(
            x
        )
        for x
        in token_lists
    )

    input_ids = torch.full(
        (
            batch_size,
            max_len,
        ),
        fill_value=pad_id,
        dtype=torch.long,
    )

    attention_mask = torch.zeros(
        (
            batch_size,
            max_len,
        ),
        dtype=torch.long,
    )

    # Explicit zero segment IDs avoid the fixed token-type buffer for
    # long sequences while remaining equivalent to standard single-segment
    # BERT input.
    token_type_ids = torch.zeros(
        (
            batch_size,
            max_len,
        ),
        dtype=torch.long,
    )

    for row, token_ids in enumerate(
        token_lists
    ):

        length = len(
            token_ids
        )

        input_ids[
            row,
            :length
        ] = torch.tensor(
            token_ids,
            dtype=torch.long,
        )

        attention_mask[
            row,
            :length
        ] = 1

    input_ids = (
        input_ids
        .pin_memory()
    )

    attention_mask = (
        attention_mask
        .pin_memory()
    )

    token_type_ids = (
        token_type_ids
        .pin_memory()
    )

    return (
        input_ids,
        attention_mask,
        token_type_ids,
    )


def forward_mean(
    token_lists,
    tokenizer,
    model,
    device,
):

    (
        input_ids_cpu,
        mask_cpu,
        token_type_cpu,
    ) = padded_batch(
        token_lists,
        tokenizer.pad_token_id,
    )

    input_ids = (
        input_ids_cpu
        .to(
            device,
            non_blocking=True,
        )
    )

    attention_mask = (
        mask_cpu
        .to(
            device,
            non_blocking=True,
        )
    )

    token_type_ids = (
        token_type_cpu
        .to(
            device,
            non_blocking=True,
        )
    )

    with torch.inference_mode():

        # Official DNABERT-2 final hidden states.
        hidden_states = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )[0]

        valid_mask = (
            attention_mask
            .unsqueeze(
                -1
            )
            .to(
                hidden_states.dtype
            )
        )

        pooled = (
            (
                hidden_states
                * valid_mask
            )
            .sum(
                dim=1
            )
            /
            valid_mask
            .sum(
                dim=1
            )
            .clamp_min(
                1.0
            )
        )

    result = (
        pooled
        .float()
        .cpu()
        .contiguous()
    )

    del input_ids
    del attention_mask
    del token_type_ids
    del hidden_states
    del valid_mask
    del pooled

    return result


def embed_all(
    token_ids,
    token_lengths,
    tokenizer,
    model,
    device,
    max_batch,
    initial_budget,
    hb,
):

    total = len(
        token_ids
    )

    # Length bucketing reduces max sequence length and padding per batch.
    sorted_indices = sorted(
        range(
            total
        ),
        key=lambda i:
            token_lengths[
                i
            ],
    )

    sorted_tokens = [
        token_ids[
            i
        ]
        for i
        in sorted_indices
    ]

    sorted_lengths = [
        token_lengths[
            i
        ]
        for i
        in sorted_indices
    ]

    sorted_embeddings = torch.empty(
        (
            total,
            DIM,
        ),
        dtype=torch.float32,
    )

    current_budget = (
        initial_budget
    )

    processed = 0
    start = 0
    batch_number = 0
    started = time.time()

    hb.update(
        phase="dnabert2_gpu_inference",
        done=0,
        total=total,
        note=(
            f"max_batch={max_batch:,}; "
            f"attention_budget="
            f"{current_budget:,}"
        ),
    )

    while start < total:

        batch_number += 1

        batch_size = (
            choose_batch_size(
                sorted_lengths,
                start,
                max_batch,
                current_budget,
            )
        )

        while True:

            end = (
                start
                + batch_size
            )

            batch_tokens = (
                sorted_tokens[
                    start:
                    end
                ]
            )

            max_len = max(
                len(
                    x
                )
                for x
                in batch_tokens
            )

            try:

                batch_embeddings = (
                    forward_mean(
                        batch_tokens,
                        tokenizer,
                        model,
                        device,
                    )
                )

                break

            except torch.cuda.OutOfMemoryError:

                torch.cuda.empty_cache()
                gc.collect()

                if batch_size <= 1:

                    raise RuntimeError(
                        "CUDA OOM at batch size 1. "
                        "CPU fallback disabled."
                    )

                old_batch = (
                    batch_size
                )

                batch_size = max(
                    1,
                    batch_size
                    // 2,
                )

                current_budget = min(
                    current_budget,
                    max(
                        1,
                        int(
                            batch_size
                            * max_len
                            * max_len
                            * 0.90
                        ),
                    ),
                )

                print(
                    f"[CUDA OOM] "
                    f"batch {old_batch:,} -> "
                    f"{batch_size:,} | "
                    f"tokens={max_len:,} | "
                    f"new_budget="
                    f"{current_budget:,}",
                    flush=True,
                )

                hb.update(
                    phase="OOM_retry",
                    done=processed,
                    total=total,
                    note=(
                        f"batch "
                        f"{old_batch:,}->"
                        f"{batch_size:,}; "
                        f"budget="
                        f"{current_budget:,}"
                    ),
                )

        sorted_embeddings[
            start:
            end
        ] = batch_embeddings

        processed += (
            batch_size
        )

        start = end

        hb.update(
            phase="dnabert2_gpu_inference",
            done=processed,
            total=total,
            note=(
                f"batch_no={batch_number:,}; "
                f"batch_size="
                f"{batch_size:,}; "
                f"tokens={max_len:,}; "
                f"budget="
                f"{current_budget:,}"
            ),
        )

        if (
            batch_number == 1
            or batch_number % 20 == 0
            or processed == total
        ):

            elapsed = max(
                time.time()
                - started,
                1e-9,
            )

            print(
                f"[PROGRESS] "
                f"batch={batch_number:,} | "
                f"seq={processed:,}/"
                f"{total:,} | "
                f"{100.0*processed/total:.2f}% | "
                f"{processed/elapsed:.1f} seq/s | "
                f"batch_size="
                f"{batch_size:,} | "
                f"max_tokens="
                f"{max_len:,} | "
                f"GPU_alloc="
                f"{torch.cuda.memory_allocated(0)/(1024**3):.2f}GB | "
                f"GPU_reserved="
                f"{torch.cuda.memory_reserved(0)/(1024**3):.2f}GB",
                flush=True,
            )

        del batch_embeddings

    # Restore exact FASTA order.
    embeddings = torch.empty_like(
        sorted_embeddings
    )

    restore_index = torch.tensor(
        sorted_indices,
        dtype=torch.long,
    )

    embeddings.index_copy_(
        0,
        restore_index,
        sorted_embeddings,
    )

    del sorted_embeddings
    del restore_index

    return (
        embeddings.contiguous(),
        current_budget,
        batch_number,
    )


# =============================================================================
# Existing output
# =============================================================================

def valid_existing(
    pt,
    complete,
    ids,
    digest,
    max_window_tokens,
):

    if (
        not pt.is_file()
        or not complete.is_file()
    ):

        return False

    try:

        with complete.open(
            "r",
            encoding="utf-8",
        ) as handle:

            meta = json.load(
                handle
            )

        return (
            meta.get(
                "status"
            )
            == "COMPLETED"
            and meta.get(
                "model_name"
            )
            == MODEL_NAME
            and meta.get(
                "pooling"
            )
            == POOLING
            and int(
                meta.get(
                    "num_sequences",
                    -1,
                )
            )
            == len(
                ids
            )
            and meta.get(
                "id_sha256"
            )
            == digest
            and int(
                meta.get(
                    "max_window_tokens",
                    -1,
                )
            )
            == max_window_tokens
            and int(
                meta.get(
                    "output_size_bytes",
                    -1,
                )
            )
            == pt.stat().st_size
        )

    except Exception:

        return False


# =============================================================================
# Main
# =============================================================================

def main():

    args = parse_args()

    input_fasta = (
        args.input
        .expanduser()
        .resolve()
    )

    out_dir = (
        args.out
        .expanduser()
        .resolve()
    )

    model_path = (
        args.model
        .expanduser()
        .resolve()
    )

    if not input_fasta.is_file():

        raise FileNotFoundError(
            input_fasta
        )

    if not model_path.is_dir():

        raise FileNotFoundError(
            model_path
        )

    if not torch.cuda.is_available():

        raise RuntimeError(
            "CUDA unavailable. "
            "CPU fallback disabled."
        )

    if args.tokenize_chunk < 1:

        raise ValueError(
            "--tokenize-chunk must be > 0"
        )

    if (
        args.max_window_tokens != 0
        and args.max_window_tokens < 8
    ):

        raise ValueError(
            "--max-window-tokens must be 0 or >= 8"
        )

    if args.log_interval < 5:

        raise ValueError(
            "--log-interval must be >= 5"
        )

    torch.cuda.set_device(
        0
    )

    device = torch.device(
        "cuda:0"
    )

    tf32 = (
        not args.disable_tf32
    )

    torch.backends.cuda.matmul.allow_tf32 = (
        tf32
    )

    if hasattr(
        torch,
        "set_float32_matmul_precision"
    ):

        torch.set_float32_matmul_precision(
            "high"
            if tf32
            else "highest"
        )

    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_pt = (
        out_dir
        / "BGC_nonBGC_dnabert2_mean.pt"
    )

    complete_json = (
        out_dir
        / "BGC_nonBGC_dnabert2_mean.complete.json"
    )

    summary_json = (
        out_dir
        / "summary.json"
    )

    print(
        "=" * 108,
        flush=True,
    )

    print(
        "BGC/NONBGC OFFICIAL DNABERT-2 MEAN",
        flush=True,
    )

    print(
        "=" * 108,
        flush=True,
    )

    print(
        f"Input       : {input_fasta}",
        flush=True,
    )

    print(
        f"Output      : {out_dir}",
        flush=True,
    )

    print(
        f"Model path  : {model_path}",
        flush=True,
    )

    print(
        f"GPU         : "
        f"{torch.cuda.get_device_name(0)}",
        flush=True,
    )

    print(
        f"TF32        : {tf32}",
        flush=True,
    )

    print(
        f"Heartbeat   : "
        f"{args.log_interval}s",
        flush=True,
    )

    print(
        f"Cache root  : "
        f"{CACHE_ROOT}",
        flush=True,
    )

    hb = Heartbeat(
        args.log_interval
    )

    hb.start()

    try:

        (
            ids,
            headers,
            sequences,
        ) = read_fasta(
            input_fasta,
            hb,
        )

        digest = sha_ids(
            ids
        )

        nucleotide_lengths = torch.tensor(
            [
                len(
                    sequence
                )
                for sequence
                in sequences
            ],
            dtype=torch.long,
        )

        print(
            f"Records     : "
            f"{len(ids):,}",
            flush=True,
        )

        print(
            f"NT length   : "
            f"{int(nucleotide_lengths.min())}"
            f"-"
            f"{int(nucleotide_lengths.max())}",
            flush=True,
        )

        if (
            not args.overwrite
            and valid_existing(
                output_pt,
                complete_json,
                ids,
                digest,
                args.max_window_tokens,
            )
        ):

            print(
                f"[SKIP] valid output exists: "
                f"{output_pt}",
                flush=True,
            )

            hb.update(
                phase="completed_existing",
                done=len(
                    ids
                ),
                total=len(
                    ids
                ),
            )

            return

        hb.update(
            phase="loading_model",
            done=0,
            total=len(
                ids
            ),
        )

        (
            tokenizer,
            model,
            fallback_layers,
        ) = load_model(
            model_path,
            device,
        )

        if tokenizer.pad_token_id is None:

            raise RuntimeError(
                "Official DNABERT-2 tokenizer "
                "has no pad token."
            )

        (
            token_ids,
            token_lengths,
        ) = tokenize_all(
            sequences,
            tokenizer,
            args.tokenize_chunk,
            hb,
        )

        token_lengths_tensor = torch.tensor(
            token_lengths,
            dtype=torch.long,
        )

        (
            window_token_ids,
            window_token_lengths,
            window_owners,
            window_weights,
            windows_per_sequence,
        ) = make_token_windows(
            token_ids,
            args.max_window_tokens,
        )

        windowed_sequence_count = sum(
            count > 1
            for count in windows_per_sequence
        )
        maximum_windows_per_sequence = max(
            windows_per_sequence
        )

        print(
            f"Token windows    : {len(window_token_ids):,} "
            f"(windowed sequences={windowed_sequence_count:,}; "
            f"max windows/sequence={maximum_windows_per_sequence:,}; "
            f"max tokens/window={max(window_token_lengths):,})",
            flush=True,
        )

        (
            memory_gb,
            max_batch,
            attention_budget,
        ) = auto_limits(
            device,
            args,
        )

        print(
            "\n===== A100 SETTINGS =====",
            flush=True,
        )

        print(
            f"GPU memory       : "
            f"{memory_gb:.2f} GB",
            flush=True,
        )

        print(
            f"Max batch        : "
            f"{max_batch:,}",
            flush=True,
        )

        print(
            f"Attention budget : "
            f"{attention_budget:,}",
            flush=True,
        )

        print(
            f"BPE token length : "
            f"{min(token_lengths):,}-"
            f"{max(token_lengths):,}",
            flush=True,
        )

        started = time.time()

        (
            window_embeddings,
            final_budget,
            batch_count,
        ) = embed_all(
            window_token_ids,
            window_token_lengths,
            tokenizer,
            model,
            device,
            max_batch,
            attention_budget,
            hb,
        )

        embeddings = combine_window_embeddings(
            window_embeddings,
            window_owners,
            window_weights,
            len(ids),
        )

        del window_embeddings

        if tuple(
            embeddings.shape
        ) != (
            len(
                ids
            ),
            DIM,
        ):

            raise RuntimeError(
                f"Unexpected embedding shape: "
                f"{tuple(embeddings.shape)}"
            )

        hb.update(
            phase="saving_pt",
            done=len(
                ids
            ),
            total=len(
                ids
            ),
            note=str(
                output_pt
            ),
        )

        save_obj = {
            "ids":
                ids,

            "headers":
                headers,

            "nucleotide_lengths":
                nucleotide_lengths,

            "token_lengths":
                token_lengths_tensor,

            "embeddings":
                embeddings,

            "source_DNA_fasta":
                str(
                    input_fasta
                ),

            "model_path":
                str(
                    model_path
                ),

            "model_name":
                MODEL_NAME,

            "official_config_values_unchanged":
                True,

            "attention_backend":
                "official_bert_layers_pytorch_fallback",

            "pytorch_fallback_layers":
                fallback_layers,

            "tokenizer":
                "official_native_DNABERT2_BPE",

            "pooling":
                POOLING,

            "pooling_definition":
                (
                    "attention-mask-aware mean over all valid final "
                    "hidden-state tokens; long sequences use contiguous "
                    "BPE token windows combined by token-count-weighted mean"
                ),

            "long_sequence_strategy":
                "contiguous_BPE_token_windows_token_weighted_mean",

            "max_window_tokens":
                args.max_window_tokens,

            "global_attention_across_windows":
                False,

            "total_windows":
                len(window_token_ids),

            "windowed_sequence_count":
                windowed_sequence_count,

            "maximum_windows_per_sequence":
                maximum_windows_per_sequence,

            "embedding_dimension":
                DIM,

            "embedding_dtype":
                "float32",

            "truncation":
                False,

            "attention_probs_dropout_prob":
                float(
                    model.config
                    .attention_probs_dropout_prob
                ),

            "hidden_dropout_prob":
                float(
                    model.config
                    .hidden_dropout_prob
                ),

            "alibi_starting_size":
                int(
                    model.config
                    .alibi_starting_size
                ),

            "num_sequences":
                len(
                    ids
                ),

            "BGC_nonBGC_ratio":
                "1:1",

            "TF32_enabled":
                tf32,

            "final_attention_budget":
                final_budget,

            "id_sha256":
                digest,

            "script_version":
                SCRIPT_VERSION,
        }

        safe_save(
            save_obj,
            output_pt,
        )

        elapsed = (
            time.time()
            - started
        ) / 60.0

        summary = {
            "status":
                "COMPLETED",

            "input_fasta":
                str(
                    input_fasta
                ),

            "output_pt":
                str(
                    output_pt
                ),

            "num_sequences":
                len(
                    ids
                ),

            "model_name":
                MODEL_NAME,

            "embedding_dimension":
                DIM,

            "embedding_dtype":
                "float32",

            "pooling":
                POOLING,

            "truncation":
                False,

            "long_sequence_strategy":
                "contiguous_BPE_token_windows_token_weighted_mean",

            "max_window_tokens":
                args.max_window_tokens,

            "global_attention_across_windows":
                False,

            "total_windows":
                len(window_token_ids),

            "windowed_sequence_count":
                windowed_sequence_count,

            "maximum_windows_per_sequence":
                maximum_windows_per_sequence,

            "attention_backend":
                "official_bert_layers_pytorch_fallback",

            "minimum_nt_length":
                int(
                    nucleotide_lengths
                    .min()
                    .item()
                ),

            "maximum_nt_length":
                int(
                    nucleotide_lengths
                    .max()
                    .item()
                ),

            "minimum_BPE_token_length":
                int(
                    token_lengths_tensor
                    .min()
                    .item()
                ),

            "maximum_BPE_token_length":
                int(
                    token_lengths_tensor
                    .max()
                    .item()
                ),

            "max_sequence_batch":
                max_batch,

            "initial_attention_budget":
                attention_budget,

            "final_attention_budget":
                final_budget,

            "GPU_batches":
                batch_count,

            "TF32_enabled":
                tf32,

            "elapsed_minutes":
                round(
                    elapsed,
                    4,
                ),

            "output_size_bytes":
                output_pt
                .stat()
                .st_size,

            "id_sha256":
                digest,

            "max_window_tokens":
                args.max_window_tokens,

            "script_version":
                SCRIPT_VERSION,
        }

        completion = {
            "status":
                "COMPLETED",

            "model_name":
                MODEL_NAME,

            "pooling":
                POOLING,

            "num_sequences":
                len(
                    ids
                ),

            "id_sha256":
                digest,

            "max_window_tokens":
                args.max_window_tokens,

            "output_size_bytes":
                output_pt
                .stat()
                .st_size,
        }

        atomic_json(
            summary_json,
            summary,
        )

        atomic_json(
            complete_json,
            completion,
        )

        hb.update(
            phase="COMPLETED",
            done=len(
                ids
            ),
            total=len(
                ids
            ),
            note=(
                f"elapsed="
                f"{elapsed:.2f} min"
            ),
        )

        print(
            "\n"
            + "=" * 108,
            flush=True,
        )

        print(
            "COMPLETED",
            flush=True,
        )

        print(
            "=" * 108,
            flush=True,
        )

        for key, value in summary.items():

            print(
                f"{key:38s}: "
                f"{value}",
                flush=True,
            )

    finally:

        hb.stop()


if __name__ == "__main__":
    main()
