import os
import re
import json
import pandas as pd
from Bio import SeqIO


# ==========================================================
# 1. 输入输出文件
# ==========================================================

PROTEIN_FASTA = "mibig_final_protein.fasta"

MIBIG_GBK_DIR = "mibig_gbk_4.0"
MIBIG_JSON_DIR = "mibig_json_4.0"

OUTPUT_FILE = "protein_ID_type_subtype.csv"
UNMATCHED_FILE = "protein_ID_unmatched.csv"


# ==========================================================
# 2. 基础清理函数
# ==========================================================

def clean_text(x):
    if x is None:
        return ""

    x = str(x).strip()
    x = x.replace("\n", " ")
    x = x.replace("\r", " ")
    x = " ".join(x.split())

    return x


def clean_id(x):
    """
    清理 protein ID。
    FASTA 中如果是:
        >AEK75490.1 some description
    则只取 AEK75490.1

    兼容空字符串、None、nan。
    """
    if x is None:
        return ""

    x = str(x).strip()

    if x == "" or x.lower() in ["nan", "none", "null"]:
        return ""

    x = x.lstrip(">")
    parts = x.split()

    if len(parts) == 0:
        return ""

    return parts[0]


def remove_version(x):
    """
    AEK75490.1 -> AEK75490
    用于兼容部分 GBK/JSON 里不带版本号的情况。
    """
    x = clean_id(x)

    if x == "":
        return ""

    if "." in x:
        return x.rsplit(".", 1)[0]

    return x


def get_first_qualifier(feature, keys):
    for key in keys:
        if key in feature.qualifiers:
            val = feature.qualifiers[key]

            if isinstance(val, list):
                if len(val) > 0:
                    return clean_text(val[0])
            else:
                return clean_text(val)

    return ""


# ==========================================================
# 3. BGC Type / Subtype 规则
# ==========================================================

def normalize_raw_class_text(x):
    x = clean_text(x)

    x = x.replace("_", " ")
    x = x.replace("-", "-")
    x = re.sub(r"\s+", " ", x)

    return x


def detect_major_type(raw_text):
    """
    将 MIBiG / antiSMASH 中的原始 class/product 文本归并为粗粒度 type。
    """
    s = normalize_raw_class_text(raw_text).lower()

    if not s:
        return "Unknown"

    pks_keys = [
        "pks", "polyketide", "t1pks", "t2pks", "t3pks",
        "transat", "trans-at", "trans at", "nrps-pks", "pks-nrps"
    ]

    nrps_keys = [
        "nrps", "nonribosomal", "non-ribosomal", "non ribosomal",
        "siderophore"
    ]

    ripp_keys = [
        "ripp", "ribosomal", "lanthipeptide", "lasso peptide",
        "thiopeptide", "cyanobactin", "sactipeptide", "bottromycin",
        "glycocin", "microviridin", "proteusin", "ranthipeptide",
        "lap", "linear azol", "azol(in)e"
    ]

    terpene_keys = [
        "terpene", "terpenoid", "carotenoid", "hopene",
        "meroterpenoid"
    ]

    saccharide_keys = [
        "saccharide", "glycoside", "aminoglycoside",
        "oligosaccharide", "polysaccharide", "exopolysaccharide"
    ]

    alkaloid_keys = [
        "alkaloid", "indole"
    ]

    has_pks = any(k in s for k in pks_keys)
    has_nrps = any(k in s for k in nrps_keys)
    has_ripp = any(k in s for k in ripp_keys)
    has_terpene = any(k in s for k in terpene_keys)
    has_saccharide = any(k in s for k in saccharide_keys)
    has_alkaloid = any(k in s for k in alkaloid_keys)

    hit_types = []

    if has_pks:
        hit_types.append("PKS")
    if has_nrps:
        hit_types.append("NRPS")
    if has_ripp:
        hit_types.append("RiPP")
    if has_terpene:
        hit_types.append("Terpene")
    if has_saccharide:
        hit_types.append("Saccharide")
    if has_alkaloid:
        hit_types.append("Alkaloid")

    hit_types = list(dict.fromkeys(hit_types))

    if len(hit_types) >= 2:
        return "Hybrid"

    if len(hit_types) == 1:
        return hit_types[0]

    nonbgc_keys = ["nonbgc", "non-bgc", "non bgc"]
    if any(k in s for k in nonbgc_keys):
        return "nonBGC"

    return "Other"


def detect_subtype(raw_text, major_type=None):
    """
    根据原始 BGC class/product 文本提取更细的 BGC subtype。
    注意：这里不使用 CDS product/function。
    """
    s_raw = normalize_raw_class_text(raw_text)
    s = s_raw.lower()

    if not s:
        return "Unknown"

    # Hybrid 优先判断
    detected = []

    if any(k in s for k in ["pks", "polyketide", "t1pks", "t2pks", "t3pks", "transat", "trans-at", "trans at"]):
        detected.append("PKS")

    if any(k in s for k in ["nrps", "nonribosomal", "non-ribosomal", "non ribosomal", "siderophore"]):
        detected.append("NRPS")

    if any(k in s for k in ["ripp", "ribosomal", "lanthipeptide", "lasso", "thiopeptide", "cyanobactin", "sactipeptide"]):
        detected.append("RiPP")

    if any(k in s for k in ["terpene", "terpenoid", "carotenoid", "hopene"]):
        detected.append("Terpene")

    if any(k in s for k in ["saccharide", "glycoside", "aminoglycoside", "oligosaccharide", "polysaccharide"]):
        detected.append("Saccharide")

    detected = list(dict.fromkeys(detected))

    if major_type == "Hybrid" and len(detected) >= 2:
        return "-".join(detected)

    # PKS subtype
    if "trans-at" in s or "transat" in s or "trans at" in s:
        return "transAT-PKS"

    if "t1pks" in s or "type i pks" in s or "type 1 pks" in s or "type-i pks" in s:
        return "T1PKS"

    if "t2pks" in s or "type ii pks" in s or "type 2 pks" in s or "type-ii pks" in s:
        return "T2PKS"

    if "t3pks" in s or "type iii pks" in s or "type 3 pks" in s or "type-iii pks" in s:
        return "T3PKS"

    if "pks-like" in s or "pks like" in s:
        return "PKS-like"

    if "pufa" in s:
        return "PUFA"

    if major_type == "PKS":
        return "PKS"

    # NRPS subtype
    if "nrps-like" in s or "nrps like" in s:
        return "NRPS-like"

    if "siderophore" in s:
        return "siderophore"

    if "lipopeptide" in s:
        return "lipopeptide"

    if "depsipeptide" in s:
        return "depsipeptide"

    if "glycopeptide" in s:
        return "glycopeptide"

    if major_type == "NRPS":
        return "NRPS"

    # RiPP subtype
    ripp_subtypes = [
        ("lanthipeptide", "lanthipeptide"),
        ("lasso peptide", "lasso peptide"),
        ("lasso", "lasso peptide"),
        ("thiopeptide", "thiopeptide"),
        ("cyanobactin", "cyanobactin"),
        ("sactipeptide", "sactipeptide"),
        ("bottromycin", "bottromycin"),
        ("glycocin", "glycocin"),
        ("microviridin", "microviridin"),
        ("proteusin", "proteusin"),
        ("ranthipeptide", "ranthipeptide"),
        ("lap", "LAP")
    ]

    for key, val in ripp_subtypes:
        if key in s:
            return val

    if major_type == "RiPP":
        return "RiPP"

    # Terpene subtype
    if "carotenoid" in s:
        return "carotenoid"

    if "hopene" in s:
        return "hopene"

    if "meroterpenoid" in s:
        return "meroterpenoid"

    if major_type == "Terpene":
        return "terpene"

    # Saccharide subtype
    if "aminoglycoside" in s:
        return "aminoglycoside"

    if "oligosaccharide" in s:
        return "oligosaccharide"

    if "polysaccharide" in s:
        return "polysaccharide"

    if "glycoside" in s:
        return "glycoside"

    if major_type == "Saccharide":
        return "saccharide"

    # Other subtype
    other_subtypes = [
        "arylpolyene",
        "aryl polyene",
        "bacteriocin",
        "beta-lactone",
        "butyrolactone",
        "ectoine",
        "hserlactone",
        "nucleoside",
        "phosphonate",
        "phenazine",
        "resorcinol",
        "ladderane",
        "melanin",
        "fatty acid",
        "aminocoumarin",
        "phosphoglycolipid"
    ]

    for key in other_subtypes:
        if key in s:
            return key.replace(" ", "-")

    # 如果没有更细 subtype，保留原始 BGC class 文本，但不要太长
    if s_raw and s_raw.lower() not in ["unknown", "none", "nan"]:
        return s_raw[:100]

    return "Other"


def classify_bgc_from_raw_text(raw_text, prefer_raw_subtype_text=None):
    """
    输入原始 BGC class/product 字符串，输出 type 和 Subtype。

    raw_text:
        通常来自 JSON + GBK 的综合信息，用于判断粗 type。

    prefer_raw_subtype_text:
        优先用于判断 subtype，通常来自 GBK region/protocluster product。
        因为 GBK 里经常比 JSON 有更细的 antiSMASH 类型。
    """
    raw_text = clean_text(raw_text)
    prefer_raw_subtype_text = clean_text(prefer_raw_subtype_text)

    major_type = detect_major_type(raw_text)

    if prefer_raw_subtype_text:
        subtype = detect_subtype(prefer_raw_subtype_text, major_type)
    else:
        subtype = detect_subtype(raw_text, major_type)

    # 如果 GBK 没提取出更细 subtype，再回退用综合 raw_text
    if subtype in ["Unknown", "Other", major_type]:
        subtype2 = detect_subtype(raw_text, major_type)

        if subtype2 not in ["Unknown", "Other"]:
            subtype = subtype2

    return major_type, subtype


# ==========================================================
# 4. FASTA ID 读取
# ==========================================================

def load_protein_ids_from_fasta(fasta_file):
    ids = []

    for record in SeqIO.parse(fasta_file, "fasta"):
        pid = clean_id(record.id)
        ids.append(pid)

    ids = list(dict.fromkeys(ids))

    print("FASTA protein ID 数:", len(ids))
    print("FASTA 前 5 个 ID:", ids[:5])

    return ids


# ==========================================================
# 5. JSON 解析：提取 BGC-level class 信息
# ==========================================================

def flatten_json_values(obj, key_hint=None):
    """
    递归提取 JSON 中可能包含 BGC class/type/product 的字段。
    """
    values = []

    important_keys = {
        "biosyn_class",
        "biosynthetic_class",
        "biosynthetic_classes",
        "class",
        "classes",
        "category",
        "categories",
        "product",
        "products",
        "cluster_type",
        "cluster_types",
        "type",
        "types"
    }

    if isinstance(obj, dict):
        for k, v in obj.items():
            k_lower = str(k).lower()

            if k_lower in important_keys:
                if isinstance(v, list):
                    for item in v:
                        if isinstance(item, (str, int, float)):
                            values.append(clean_text(item))
                        elif isinstance(item, dict):
                            values.extend(flatten_json_values(item, key_hint=k_lower))
                elif isinstance(v, (str, int, float)):
                    values.append(clean_text(v))
                elif isinstance(v, dict):
                    values.extend(flatten_json_values(v, key_hint=k_lower))

            # 继续递归，防止字段嵌套较深
            if isinstance(v, (dict, list)):
                values.extend(flatten_json_values(v, key_hint=k_lower))

    elif isinstance(obj, list):
        for item in obj:
            values.extend(flatten_json_values(item, key_hint=key_hint))

    return values


def get_bgc_id_from_json_filename(json_file):
    base = os.path.basename(json_file)
    bgc_id = os.path.splitext(base)[0]
    return bgc_id


def parse_mibig_json_folder(json_dir):
    """
    返回:
        bgc_id -> raw_bgc_class_text
    """
    bgc_class_map = {}

    json_files = []

    for root, dirs, files in os.walk(json_dir):
        for fn in files:
            if fn.lower().endswith(".json"):
                json_files.append(os.path.join(root, fn))

    print("发现 JSON 文件数:", len(json_files))

    for i, jf in enumerate(json_files, start=1):
        if i % 1000 == 0:
            print("已处理 JSON:", i, "/", len(json_files))

        bgc_id = get_bgc_id_from_json_filename(jf)

        try:
            with open(jf, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except Exception as e:
            print("JSON 读取失败:", jf, e)
            continue

        values = flatten_json_values(obj)

        # 过滤过于无关的字段
        values = [v for v in values if v and v.lower() not in ["none", "nan", "unknown"]]

        if len(values) == 0:
            raw_text = ""
        else:
            # 去重合并
            uniq = []
            for v in values:
                if v not in uniq:
                    uniq.append(v)

            raw_text = "; ".join(uniq)

        bgc_class_map[bgc_id] = raw_text

    print("JSON BGC class map 数:", len(bgc_class_map))

    return bgc_class_map


# ==========================================================
# 6. GBK 解析：protein_id -> BGC_id，并辅助提取 BGC class
# ==========================================================

def infer_bgc_class_from_gbk_record(record):
    """
    从 GBK 的 region/protocluster/cluster feature 中提取 BGC-level class/product。
    """
    candidates = []

    for feature in record.features:
        ftype = str(feature.type).lower()

        if ftype in ["region", "protocluster", "cluster", "cand_cluster"]:
            val = get_first_qualifier(
                feature,
                [
                    "product",
                    "products",
                    "class",
                    "category",
                    "biosynthetic_class",
                    "note"
                ]
            )

            val = clean_text(val)

            if val:
                candidates.append(val)

    uniq = []
    for x in candidates:
        if x not in uniq:
            uniq.append(x)

    return "; ".join(uniq)


def parse_mibig_gbk_folder(gbk_dir):
    """
    返回:
        protein_id_to_bgc_id: protein_id -> bgc_id
        bgc_class_from_gbk: bgc_id -> raw_bgc_class_text
    """
    protein_to_bgc = {}
    bgc_class_from_gbk = {}

    gbk_files = []

    for root, dirs, files in os.walk(gbk_dir):
        for fn in files:
            if fn.lower().endswith((".gbk", ".gb", ".genbank")):
                gbk_files.append(os.path.join(root, fn))

    print("发现 GBK 文件数:", len(gbk_files))

    for i, gbk_file in enumerate(gbk_files, start=1):
        if i % 500 == 0:
            print("已处理 GBK:", i, "/", len(gbk_files))

        bgc_id = os.path.splitext(os.path.basename(gbk_file))[0]

        try:
            records = list(SeqIO.parse(gbk_file, "genbank"))
        except Exception as e:
            print("GBK 读取失败:", gbk_file, e)
            continue

        bgc_class_candidates = []

        for record in records:
            record_class = infer_bgc_class_from_gbk_record(record)

            if record_class:
                bgc_class_candidates.append(record_class)

            for feature in record.features:
                if feature.type != "CDS":
                    continue

                protein_id = get_first_qualifier(
                    feature,
                    ["protein_id"]
                )

                locus_tag = get_first_qualifier(
                    feature,
                    ["locus_tag", "gene"]
                )

                protein_id = clean_id(protein_id)
                locus_tag = clean_id(locus_tag)

                # 优先用 protein_id
                if protein_id:
                    protein_to_bgc[protein_id] = bgc_id
                    protein_to_bgc[remove_version(protein_id)] = bgc_id

                # 兼容有些 FASTA 用 locus_tag 的情况
                if locus_tag:
                    protein_to_bgc[locus_tag] = bgc_id
                    protein_to_bgc[remove_version(locus_tag)] = bgc_id

        uniq_class = []
        for x in bgc_class_candidates:
            if x not in uniq_class:
                uniq_class.append(x)

        bgc_class_from_gbk[bgc_id] = "; ".join(uniq_class)

    print("protein -> BGC 映射数:", len(protein_to_bgc))
    print("GBK BGC class map 数:", len(bgc_class_from_gbk))

    return protein_to_bgc, bgc_class_from_gbk


# ==========================================================
# 7. 主流程：FASTA ID -> BGC ID -> Type/Subtype
# ==========================================================

def main():
    print("=" * 60)
    print("Step 1. 读取 FASTA protein ID")
    print("=" * 60)

    protein_ids = load_protein_ids_from_fasta(PROTEIN_FASTA)

    print("=" * 60)
    print("Step 2. 解析 MIBiG JSON，提取 BGC-level class")
    print("=" * 60)

    json_bgc_class_map = parse_mibig_json_folder(MIBIG_JSON_DIR)

    print("=" * 60)
    print("Step 3. 解析 MIBiG GBK，建立 protein_id -> BGC_id")
    print("=" * 60)

    protein_to_bgc, gbk_bgc_class_map = parse_mibig_gbk_folder(MIBIG_GBK_DIR)

    print("=" * 60)
    print("Step 4. 根据规则生成 id,type,Subtype")
    print("=" * 60)

    rows = []
    unmatched_rows = []

    for pid in protein_ids:
        pid_clean = clean_id(pid)
        pid_nover = remove_version(pid_clean)

        bgc_id = None

        if pid_clean in protein_to_bgc:
            bgc_id = protein_to_bgc[pid_clean]
        elif pid_nover in protein_to_bgc:
            bgc_id = protein_to_bgc[pid_nover]

        if bgc_id is None:
            rows.append({
                "id": pid_clean,
                "type": "Unknown",
                "Subtype": "Unknown"
            })

            unmatched_rows.append({
                "id": pid_clean,
                "reason": "protein_id not found in GBK"
            })

            continue

        # 优先使用 JSON 的 BGC class；如果没有，再用 GBK region/protocluster class
        raw_class_text = json_bgc_class_map.get(bgc_id, "")

        if not raw_class_text:
            raw_class_text = gbk_bgc_class_map.get(bgc_id, "")

        major_type, subtype = classify_bgc_from_raw_text(raw_class_text)

        rows.append({
            "id": pid_clean,
            "type": major_type,
            "Subtype": subtype
        })

        if major_type == "Unknown":
            unmatched_rows.append({
                "id": pid_clean,
                "reason": "BGC class not found",
                "bgc_id": bgc_id,
                "raw_class_text": raw_class_text
            })

    out_df = pd.DataFrame(rows)
    unmatched_df = pd.DataFrame(unmatched_rows)

    out_df.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig"
    )

    unmatched_df.to_csv(
        UNMATCHED_FILE,
        index=False,
        encoding="utf-8-sig"
    )

    print("输出文件:", OUTPUT_FILE)
    print("总 protein ID 数:", len(out_df))
    print("匹配到 type 的数量:", (out_df["type"] != "Unknown").sum())
    print("Unknown 数量:", (out_df["type"] == "Unknown").sum())

    print("\nType 分布:")
    print(out_df["type"].value_counts())

    print("\nSubtype 前 30:")
    print(out_df["Subtype"].value_counts().head(30))

    print("\n未匹配文件:", UNMATCHED_FILE)
    print("Done.")


if __name__ == "__main__":
    main()