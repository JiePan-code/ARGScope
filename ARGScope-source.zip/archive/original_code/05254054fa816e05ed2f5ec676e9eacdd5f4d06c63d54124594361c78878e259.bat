@echo off
setlocal
set "ARGTYPEPY=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%ARGTYPEPY%" (
  echo Python was not found. Edit ARGTYPEPY in this launcher.
  pause
  exit /b 1
)
"%ARGTYPEPY%" -X utf8 -B -u "%~dp0plot_type_pr_radar.py"
if errorlevel 1 (
  echo Rendering failed. See the message above.
  pause
  exit /b 1
)
echo Done. The latest folder is recorded in render_status.json.
pause
