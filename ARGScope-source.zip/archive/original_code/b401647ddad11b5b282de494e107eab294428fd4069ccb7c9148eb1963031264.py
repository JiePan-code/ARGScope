"""Release cross-check from saved sequence predictions, independent of plot code."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

OUT=Path(__file__).resolve().parent/'outputs/argscope_including_nonARG_20260922'
DATA=OUT/'data'
PLOTS=OUT/'Figure2_Figure3_SVG/plot_data'

def main():
    metrics=pd.read_csv(DATA/'all_metrics_including_nonARG.csv')
    per=pd.read_csv(DATA/'per_type_including_nonARG.csv')
    receipt=json.loads((DATA/'calculation_verification.json').read_text(encoding='utf-8'))
    labels=receipt['type_labels']
    checked=[]
    for mod in ['Protein','DNA']:
        heat=pd.read_csv(PLOTS/mod/'C_heatmap_values.csv')
        assert set(heat[heat.Type.eq('nonARG')].Model)==set(metrics[metrics.Modality.eq(mod)].Model)
        for path in sorted((DATA/mod).glob('*_100pct_sequence_evaluation.csv')):
            model=path.name.removesuffix('_100pct_sequence_evaluation.csv')
            raw=pd.read_csv(path,keep_default_na=False)
            actual=metrics[metrics.Modality.eq(mod)&metrics.Model.eq(model)&metrics.Completeness.eq(100)&metrics.Level.eq('Type')]
            for avg in ['macro','weighted','micro']:
                row=actual[actual.Average.eq(avg)].iloc[0]
                p,r,f,_=precision_recall_fscore_support(raw.true_type,raw.predicted_type,labels=labels,average=avg,zero_division=0)
                np.testing.assert_allclose(row[['Accuracy','Precision','Recall','F1','MCC']].to_numpy(float),
                    [accuracy_score(raw.true_type,raw.predicted_type),p,r,f,matthews_corrcoef(raw.true_type,raw.predicted_type)],atol=1e-12,rtol=0)
            p,r,f,s=precision_recall_fscore_support(raw.true_type,raw.predicted_type,labels=labels,zero_division=0)
            classwise=pd.DataFrame({'Precision':p,'Recall':r,'F1':f},index=labels)
            for cell in heat[heat.Model.eq(model)].itertuples():
                expected=classwise[cell.Metric].mean() if cell.Type=='Average' else classwise.loc[cell.Type,cell.Metric]
                assert abs(cell.Value-expected)<1e-12
            if model=='ARGScope':
                cm=pd.crosstab(raw.true_type,raw.predicted_type).reindex(index=labels,columns=labels,fill_value=0)
                delivered=pd.read_csv(PLOTS/mod/'E_full_24class_confusion_counts.csv',index_col=0)
                pd.testing.assert_frame_equal(cm,delivered,check_names=False)
                fn=int((raw.true_type.ne('nonARG')&raw.predicted_type.eq('nonARG')).sum())
                fp=int((raw.true_type.eq('nonARG')&raw.predicted_type.ne('nonARG')).sum())
                cross=int((raw.true_type.ne('nonARG')&raw.predicted_type.ne('nonARG')&raw.true_type.ne(raw.predicted_type)).sum())
                subtype=metrics[metrics.Modality.eq(mod)&metrics.Model.eq(model)&metrics.Completeness.eq(100)&metrics.Level.eq('Subtype')]
                subtype_labels=subtype.iloc[0].Averaged_labels.split(';')
                assert len(subtype_labels)==821 and 'nonARG' in subtype_labels
                for row in subtype.itertuples():
                    p,r,f,_=precision_recall_fscore_support(raw.true_subtype,raw.predicted_subtype,labels=subtype_labels,average=row.Average,zero_division=0)
                    np.testing.assert_allclose([row.Accuracy,row.Precision,row.Recall,row.F1,row.MCC],
                        [accuracy_score(raw.true_subtype,raw.predicted_subtype),p,r,f,matthews_corrcoef(raw.true_subtype,raw.predicted_subtype)],atol=1e-12,rtol=0)
                b=pd.read_csv(PLOTS/mod/'B_subtype_macro_values.csv').iloc[0]
                np.testing.assert_allclose(b[['Accuracy','Precision','Recall','F1','MCC']].to_numpy(float),
                    subtype[subtype.Average.eq('macro')].iloc[0][['Accuracy','Precision','Recall','F1','MCC']].to_numpy(float),atol=1e-12,rtol=0)
                pairs=pd.read_csv(PLOTS/mod/'G_all_subtype_error_pairs_including_nonARG.csv',keep_default_na=False)
                assert pairs.Count.sum()==raw.true_subtype.ne(raw.predicted_subtype).sum()
                for row in pairs.itertuples():
                    pair=(raw.true_subtype.eq(row.true_subtype)&raw.predicted_subtype.eq(row.predicted_subtype)&raw.true_type.eq(row.true_type)&raw.predicted_type.eq(row.predicted_type))
                    assert pair.sum()==row.Count
                checked.append(dict(modality=mod,model=model,all_metrics_match=True,ARG_missed=fn,nonARG_false_positive=fp,cross_ARG_type_errors=cross))
            else:
                checked.append(dict(modality=mod,model=model,all_metrics_match=True))
    assert len(checked)==8
    result={'saved_sequence_metrics_rechecked':checked,'heatmap_every_cell_verified':True,'type_nonARG_row_in_both_heatmaps':True,'subtype_full_821_labels':True}
    (DATA/'release_metric_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
