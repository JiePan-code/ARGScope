#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    precision_recall_fscore_support,
)


# ============================================================
# Configuration
# ============================================================

SCRIPT_DIR = Path(__file__).resolve().parent

INPUT_FILE = SCRIPT_DIR / "test_sequence_predictions.csv"

OUTPUT_DIR = SCRIPT_DIR / "test_sequence_predictions_metrics"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Whether to retain nonARG in the per-Type table
INCLUDE_NONARG_IN_PER_TYPE = True

# Whether to retain nonARG in the per-Subtype table
INCLUDE_NONARG_IN_PER_SUBTYPE = True


# ============================================================
# Utility functions
# ============================================================

def safe_divide(a, b):
    """Safely divide two numbers."""
    return a / b if b != 0 else 0.0


def safe_mcc(y_true, y_pred):
    """
    MCC may be undefined for a degenerate one-vs-rest class
    when both y_true and y_pred contain only one value.
    Return 0.0 in that case.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    try:
        return matthews_corrcoef(y_true, y_pred)
    except Exception:
        return 0.0


def binary_metrics(y_true, y_pred, y_prob=None):
    """
    Calculate binary classification metrics.
    Positive class = 1 (ARG).
    """

    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])

    tn, fp, fn, tp = cm.ravel()

    acc = accuracy_score(y_true, y_pred)

    precision = precision_score(
        y_true,
        y_pred,
        pos_label=1,
        zero_division=0,
    )

    recall = recall_score(
        y_true,
        y_pred,
        pos_label=1,
        zero_division=0,
    )

    specificity = safe_divide(tn, tn + fp)

    f1 = f1_score(
        y_true,
        y_pred,
        pos_label=1,
        zero_division=0,
    )

    mcc = safe_mcc(y_true, y_pred)

    metrics = {
        "ACC": acc,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "F1": f1,
        "MCC": mcc,
        "Support_ARG": int(np.sum(y_true == 1)),
        "Support_nonARG": int(np.sum(y_true == 0)),
        "TP": int(tp),
        "FP": int(fp),
        "FN": int(fn),
        "TN": int(tn),
    }

    if y_prob is not None:

        y_prob = np.asarray(y_prob).astype(float)

        try:
            metrics["AUC"] = roc_auc_score(y_true, y_prob)
        except ValueError:
            metrics["AUC"] = np.nan

        try:
            metrics["AUPR"] = average_precision_score(
                y_true,
                y_prob,
            )
        except ValueError:
            metrics["AUPR"] = np.nan

    return metrics


def multiclass_overall_metrics(y_true, y_pred, level_name):
    """
    Overall multiclass metrics with macro, weighted and micro averages.
    """

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    acc = accuracy_score(y_true, y_pred)

    macro_precision, macro_recall, macro_f1, _ = (
        precision_recall_fscore_support(
            y_true,
            y_pred,
            average="macro",
            zero_division=0,
        )
    )

    weighted_precision, weighted_recall, weighted_f1, _ = (
        precision_recall_fscore_support(
            y_true,
            y_pred,
            average="weighted",
            zero_division=0,
        )
    )

    micro_precision, micro_recall, micro_f1, _ = (
        precision_recall_fscore_support(
            y_true,
            y_pred,
            average="micro",
            zero_division=0,
        )
    )

    mcc = safe_mcc(
        y_true,
        y_pred,
    )

    return {
        "Level": level_name,
        "ACC": acc,

        "Macro_Precision": macro_precision,
        "Macro_Recall": macro_recall,
        "Macro_F1": macro_f1,

        "Weighted_Precision": weighted_precision,
        "Weighted_Recall": weighted_recall,
        "Weighted_F1": weighted_f1,

        "Micro_Precision": micro_precision,
        "Micro_Recall": micro_recall,
        "Micro_F1": micro_f1,

        "MCC": mcc,

        "N_sequences": len(y_true),
        "N_true_classes": len(np.unique(y_true)),
        "N_predicted_classes": len(np.unique(y_pred)),
        "N_union_classes": len(
            set(y_true.tolist()) | set(y_pred.tolist())
        ),
    }


def per_class_one_vs_rest_metrics(
    y_true,
    y_pred,
    class_names,
    class_column,
):
    """
    One-vs-rest metrics for each class.
    """

    y_true = np.asarray(y_true, dtype=object)
    y_pred = np.asarray(y_pred, dtype=object)

    rows = []

    for class_name in class_names:

        true_binary = (
            y_true == class_name
        ).astype(int)

        pred_binary = (
            y_pred == class_name
        ).astype(int)

        cm = confusion_matrix(
            true_binary,
            pred_binary,
            labels=[0, 1],
        )

        tn, fp, fn, tp = cm.ravel()

        acc = accuracy_score(
            true_binary,
            pred_binary,
        )

        precision = precision_score(
            true_binary,
            pred_binary,
            zero_division=0,
        )

        recall = recall_score(
            true_binary,
            pred_binary,
            zero_division=0,
        )

        specificity = safe_divide(
            tn,
            tn + fp,
        )

        f1 = f1_score(
            true_binary,
            pred_binary,
            zero_division=0,
        )

        mcc = safe_mcc(
            true_binary,
            pred_binary,
        )

        support = int(
            np.sum(true_binary)
        )

        predicted_count = int(
            np.sum(pred_binary)
        )

        rows.append(
            {
                class_column: class_name,
                "ACC": acc,
                "Precision": precision,
                "Recall": recall,
                "Specificity": specificity,
                "F1": f1,
                "MCC": mcc,
                "Support": support,
                "Predicted_count": predicted_count,
                "Correct_count": int(tp),
                "Wrong_count": int(fn),
                "TP": int(tp),
                "FP": int(fp),
                "FN": int(fn),
                "TN": int(tn),
            }
        )

    return pd.DataFrame(rows)


# ============================================================
# Main
# ============================================================

def main():

    print("=" * 100)
    print("ARGScope test prediction metrics")
    print("=" * 100)

    print(f"Input : {INPUT_FILE}")
    print(f"Output: {OUTPUT_DIR}")

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found:\n{INPUT_FILE}"
        )

    # --------------------------------------------------------
    # Load predictions
    # --------------------------------------------------------

    df = pd.read_csv(INPUT_FILE)

    print()
    print(f"Number of sequences: {len(df):,}")
    print(f"Columns: {len(df.columns)}")

    required_columns = [
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
        "true_ARG",
        "predicted_ARG",
    ]

    missing_columns = [
        x for x in required_columns
        if x not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing required columns: {missing_columns}"
        )

    # Remove rows with missing labels
    df = df.dropna(
        subset=[
            "true_subtype",
            "predicted_subtype",
            "true_type",
            "predicted_type",
            "true_ARG",
            "predicted_ARG",
        ]
    ).copy()

    # Standardize data types
    df["true_subtype"] = (
        df["true_subtype"]
        .astype(str)
        .str.strip()
    )

    df["predicted_subtype"] = (
        df["predicted_subtype"]
        .astype(str)
        .str.strip()
    )

    df["true_type"] = (
        df["true_type"]
        .astype(str)
        .str.strip()
    )

    df["predicted_type"] = (
        df["predicted_type"]
        .astype(str)
        .str.strip()
    )

    df["true_ARG"] = df["true_ARG"].astype(int)
    df["predicted_ARG"] = df["predicted_ARG"].astype(int)

    print(f"Valid sequences: {len(df):,}")

    # ========================================================
    # 1. ARG / nonARG binary metrics
    # ========================================================

    print()
    print("=" * 100)
    print("1. ARG / nonARG binary classification")
    print("=" * 100)

    y_true_arg = df["true_ARG"].values
    y_pred_arg = df["predicted_ARG"].values

    if "ARG_probability" in df.columns:
        arg_prob = df["ARG_probability"].values
    else:
        arg_prob = None

    arg_metrics = binary_metrics(
        y_true_arg,
        y_pred_arg,
        arg_prob,
    )

    arg_metrics_df = pd.DataFrame(
        [arg_metrics]
    )

    arg_metrics_df.insert(
        0,
        "Level",
        "ARG_nonARG",
    )

    print()
    print(
        arg_metrics_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    arg_metrics_df.to_csv(
        OUTPUT_DIR / "01_ARG_nonARG_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 2. Type-level overall metrics
    # ========================================================

    print()
    print("=" * 100)
    print("2. Type-level overall classification")
    print("=" * 100)

    y_true_type = df["true_type"].values
    y_pred_type = df["predicted_type"].values

    type_metrics = multiclass_overall_metrics(
        y_true_type,
        y_pred_type,
        "Type",
    )

    type_overall = pd.DataFrame(
        [type_metrics]
    )

    print()
    print(
        type_overall.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    type_overall.to_csv(
        OUTPUT_DIR / "02_Type_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 3. Per-Type metrics
    # ========================================================

    print()
    print("=" * 100)
    print("3. Per-Type metrics (one-vs-rest)")
    print("=" * 100)

    all_types = sorted(
        set(df["true_type"].unique())
        |
        set(df["predicted_type"].unique())
    )

    if "nonARG" in all_types:
        all_types.remove("nonARG")
        all_types.append("nonARG")

    if not INCLUDE_NONARG_IN_PER_TYPE:
        all_types = [
            x for x in all_types
            if x != "nonARG"
        ]

    per_type_df = per_class_one_vs_rest_metrics(
        y_true_type,
        y_pred_type,
        all_types,
        "Type",
    )

    print()
    print(
        per_type_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    per_type_df.to_csv(
        OUTPUT_DIR / "03_per_Type_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 4. Subtype-level overall metrics
    # ========================================================

    print()
    print("=" * 100)
    print("4. Subtype-level overall classification")
    print("=" * 100)

    y_true_subtype = df["true_subtype"].values
    y_pred_subtype = df["predicted_subtype"].values

    subtype_metrics = multiclass_overall_metrics(
        y_true_subtype,
        y_pred_subtype,
        "Subtype",
    )

    subtype_overall = pd.DataFrame(
        [subtype_metrics]
    )

    print()
    print(
        subtype_overall.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    subtype_overall.to_csv(
        OUTPUT_DIR / "04_Subtype_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 5. Per-Subtype metrics
    # ========================================================

    print()
    print("=" * 100)
    print("5. Per-Subtype metrics (one-vs-rest)")
    print("=" * 100)

    all_subtypes = sorted(
        set(df["true_subtype"].unique())
        |
        set(df["predicted_subtype"].unique())
    )

    if "nonARG" in all_subtypes:
        all_subtypes.remove("nonARG")
        all_subtypes.append("nonARG")

    if not INCLUDE_NONARG_IN_PER_SUBTYPE:
        all_subtypes = [
            x for x in all_subtypes
            if x != "nonARG"
        ]

    per_subtype_df = per_class_one_vs_rest_metrics(
        y_true_subtype,
        y_pred_subtype,
        all_subtypes,
        "Subtype",
    )

    print()
    print(
        per_subtype_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    per_subtype_df.to_csv(
        OUTPUT_DIR / "05_per_Subtype_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 6. ARG-only subtype metrics
    #
    # This keeps only true ARG samples.
    # The final predicted_subtype is still used directly.
    # Therefore an ARG sequence predicted as nonARG remains an error.
    # ========================================================

    print()
    print("=" * 100)
    print("6. ARG-only Subtype metrics")
    print("=" * 100)

    arg_only_df = df[
        df["true_ARG"] == 1
    ].copy()

    if len(arg_only_df) > 0:

        y_true_subtype_arg = (
            arg_only_df["true_subtype"].values
        )

        y_pred_subtype_arg = (
            arg_only_df["predicted_subtype"].values
        )

        arg_only_subtype_metrics = (
            multiclass_overall_metrics(
                y_true_subtype_arg,
                y_pred_subtype_arg,
                "ARG_only_Subtype",
            )
        )

        arg_only_subtype_overall = pd.DataFrame(
            [arg_only_subtype_metrics]
        )

    else:

        arg_only_subtype_metrics = None

        arg_only_subtype_overall = pd.DataFrame(
            columns=[
                "Level",
                "ACC",
                "Macro_Precision",
                "Macro_Recall",
                "Macro_F1",
                "Weighted_Precision",
                "Weighted_Recall",
                "Weighted_F1",
                "Micro_Precision",
                "Micro_Recall",
                "Micro_F1",
                "MCC",
                "N_sequences",
                "N_true_classes",
                "N_predicted_classes",
                "N_union_classes",
            ]
        )

    print()
    print(
        arg_only_subtype_overall.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    arg_only_subtype_overall.to_csv(
        OUTPUT_DIR / "06_ARG_only_Subtype_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # 7. Compact summary
    # ========================================================

    summary_rows = [
        {
            "Evaluation": "ARG/nonARG",
            "Average": "positive_ARG",
            "ACC": arg_metrics["ACC"],
            "Precision": arg_metrics["Precision"],
            "Recall": arg_metrics["Recall"],
            "F1": arg_metrics["F1"],
            "MCC": arg_metrics["MCC"],
        },

        {
            "Evaluation": "Type",
            "Average": "macro",
            "ACC": type_metrics["ACC"],
            "Precision": type_metrics["Macro_Precision"],
            "Recall": type_metrics["Macro_Recall"],
            "F1": type_metrics["Macro_F1"],
            "MCC": type_metrics["MCC"],
        },

        {
            "Evaluation": "Type",
            "Average": "weighted",
            "ACC": type_metrics["ACC"],
            "Precision": type_metrics["Weighted_Precision"],
            "Recall": type_metrics["Weighted_Recall"],
            "F1": type_metrics["Weighted_F1"],
            "MCC": type_metrics["MCC"],
        },

        {
            "Evaluation": "Type",
            "Average": "micro",
            "ACC": type_metrics["ACC"],
            "Precision": type_metrics["Micro_Precision"],
            "Recall": type_metrics["Micro_Recall"],
            "F1": type_metrics["Micro_F1"],
            "MCC": type_metrics["MCC"],
        },

        {
            "Evaluation": "Subtype",
            "Average": "macro",
            "ACC": subtype_metrics["ACC"],
            "Precision": subtype_metrics["Macro_Precision"],
            "Recall": subtype_metrics["Macro_Recall"],
            "F1": subtype_metrics["Macro_F1"],
            "MCC": subtype_metrics["MCC"],
        },

        {
            "Evaluation": "Subtype",
            "Average": "weighted",
            "ACC": subtype_metrics["ACC"],
            "Precision": subtype_metrics["Weighted_Precision"],
            "Recall": subtype_metrics["Weighted_Recall"],
            "F1": subtype_metrics["Weighted_F1"],
            "MCC": subtype_metrics["MCC"],
        },

        {
            "Evaluation": "Subtype",
            "Average": "micro",
            "ACC": subtype_metrics["ACC"],
            "Precision": subtype_metrics["Micro_Precision"],
            "Recall": subtype_metrics["Micro_Recall"],
            "F1": subtype_metrics["Micro_F1"],
            "MCC": subtype_metrics["MCC"],
        },
    ]

    if arg_only_subtype_metrics is not None:

        for average, prefix in [
            ("macro", "Macro"),
            ("weighted", "Weighted"),
            ("micro", "Micro"),
        ]:

            summary_rows.append(
                {
                    "Evaluation": "ARG_only_Subtype",
                    "Average": average,
                    "ACC": arg_only_subtype_metrics["ACC"],
                    "Precision": arg_only_subtype_metrics[
                        f"{prefix}_Precision"
                    ],
                    "Recall": arg_only_subtype_metrics[
                        f"{prefix}_Recall"
                    ],
                    "F1": arg_only_subtype_metrics[
                        f"{prefix}_F1"
                    ],
                    "MCC": arg_only_subtype_metrics["MCC"],
                }
            )

    compact_df = pd.DataFrame(
        summary_rows
    )

    compact_df.to_csv(
        OUTPUT_DIR / "00_main_metrics_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ========================================================
    # Final
    # ========================================================

    print()
    print("=" * 100)
    print("Finished")
    print("=" * 100)

    print(
        f"""
Output files:

{OUTPUT_DIR / '00_main_metrics_summary.csv'}
{OUTPUT_DIR / '01_ARG_nonARG_overall_metrics.csv'}
{OUTPUT_DIR / '02_Type_overall_metrics.csv'}
{OUTPUT_DIR / '03_per_Type_metrics.csv'}
{OUTPUT_DIR / '04_Subtype_overall_metrics.csv'}
{OUTPUT_DIR / '05_per_Subtype_metrics.csv'}
{OUTPUT_DIR / '06_ARG_only_Subtype_overall_metrics.csv'}
"""
    )


if __name__ == "__main__":
    main()
