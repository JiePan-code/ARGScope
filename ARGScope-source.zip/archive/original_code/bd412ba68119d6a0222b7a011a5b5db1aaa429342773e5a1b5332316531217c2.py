"""Static publication panels from reviewed ARG-only Type CSVs, without old-output overwrites."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import FormatStrFormatter

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures_Type_ARG_only'
OUT.mkdir(exist_ok=True)
METRICS=['Accuracy','Precision','Recall','F1','MCC']
LABELS=['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC']
MODELS={'Protein':['ARGNet','DeepARG','PLM-ARG','FunGeneTyper','ARGScope'],
        'DNA':['ARGNet','DeepARG','ARGScope']}
COLORS={'ARGNet':'#e9e3d4','DeepARG':'#e87863','PLM-ARG':'#858585','FunGeneTyper':'#84b3d8','ARGScope':'#88c4aa'}
HATCH={'ARGNet':'-','DeepARG':'/','PLM-ARG':'\\','FunGeneTyper':'.','ARGScope':'+'}
ORDER=['beta_lactam','trimethoprim','macrolide-lincosamide-streptogramin','fusidic_acid','fosfomycin',
       'aminoglycoside','quinolone','multidrug','vancomycin','chloramphenicol','florfenicol','rifamycin',
       'tetracycline','other_peptide_antibiotics','bacitracin','sulfonamide','tetracenomycin_C','novobiocin',
       'tunicamycin','streptothricin','polymyxin','bleomycin','puromycin']
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.linewidth':.65,'axes.spines.top':False,
 'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','hatch.linewidth':.35,
 'savefig.facecolor':'white','axes.labelcolor':'#222222','xtick.color':'#222222','ytick.color':'#222222'})
checked=[]
heatmap_records=[]
radar_records=[]
def save(fig,stem):
    for ext in ['png','pdf','svg']:
        fig.savefig(stem.with_suffix('.'+ext),dpi=400,facecolor='white')
    plt.close(fig)
def handles(mod):
    return [Patch(facecolor=COLORS[m],edgecolor='#777777',linewidth=.5,hatch=HATCH[m],label=m) for m in MODELS[mod]]

LINE_COLORS={'ARGNet':'#9c8756','DeepARG':'#d36652','PLM-ARG':'#62666c','FunGeneTyper':'#4b90c2','ARGScope':'#2a9478'}
STYLES={'ARGNet':('--','s'),'DeepARG':('-.','D'),'PLM-ARG':(':','^'),'FunGeneTyper':('--','v'),'ARGScope':('-','o')}
def radar_handles(mod):
    return [Line2D([0],[0],color=LINE_COLORS[m],linestyle=STYLES[m][0],marker=STYLES[m][1],
        markersize=4,linewidth=1.2,label=m) for m in MODELS[mod]]

def draw_binary_radar(ax,mod):
    source=ROOT/mod/'06_ARG_nonARG_macro_weighted_micro.csv'
    data=pd.read_csv(source)
    section=data[(data.Completeness==100)&(data.Average=='macro')].set_index('Model')
    assert set(section.index)==set(MODELS[mod])
    assert section.Scope.eq('ARG_and_nonARG').all() and section.N_labels_averaged.eq(2).all()
    angles=np.linspace(0,2*np.pi,5,endpoint=False);closed=np.r_[angles,angles[0]]
    ax.set_theta_offset(np.pi/2);ax.set_theta_direction(-1)
    ax.set_xticks(angles,['ACC','Macro\nprecision','Macro\nrecall','Macro F1','MCC'])
    ax.tick_params(axis='x',pad=12,labelsize=9)
    for angle,tick in zip(angles,ax.get_xticklabels()):
        tick.set_horizontalalignment('left' if np.sin(angle)>.1 else 'right' if np.sin(angle)<-.1 else 'center')
    ax.set_ylim(0,1);ax.set_yticks([.2,.4,.6,.8,1.]);ax.set_yticklabels(['0.2','0.4','0.6','0.8','1.0'],fontsize=7,color='#656565')
    ax.set_rlabel_position(18);ax.grid(color='#d9dfe1',linewidth=.55)
    ax.spines['polar'].set_visible(True);ax.spines['polar'].set_color('#8c9498');ax.spines['polar'].set_linewidth(.65)
    for model in MODELS[mod]:
        values=section.loc[model,METRICS].to_numpy(dtype=float)
        assert np.isfinite(values).all() and ((values>=0)&(values<=1)).all()
        style,marker=STYLES[model]
        ax.plot(closed,np.r_[values,values[0]],color=LINE_COLORS[model],linestyle=style,
            marker=marker,markersize=4,linewidth=1.35,markeredgewidth=.7,
            markerfacecolor='white' if model!='ARGScope' else LINE_COLORS[model],clip_on=False)
        if model=='ARGScope':ax.fill(closed,np.r_[values,values[0]],color=LINE_COLORS[model],alpha=.06)
        for metric,value in zip(METRICS,values):
            radar_records.append(dict(Modality=mod,Completeness=100,Model=model,Metric=metric,
                Value=float(value),Average='macro',Scope='ARG_and_nonARG',N=int(section.loc[model,'N']),Source=str(source)))
def draw_bars(ax,df,mod,pct):
    section=df[df.Completeness.eq(pct)].set_index('Model')
    width=.79/len(MODELS[mod]);x=np.arange(5)
    for j,model in enumerate(MODELS[mod]):
        values=section.loc[model,METRICS].to_numpy(dtype=float)
        assert np.isfinite(values).all()
        bars=ax.bar(x+(j-(len(MODELS[mod])-1)/2)*width,values,width=width*.91,
                    color=COLORS[model],edgecolor='#737373',linewidth=.5,hatch=HATCH[model],zorder=3)
        for metric,value,bar in zip(METRICS,values,bars):
            assert bar.get_height()==value
            checked.append(dict(Modality=mod,Completeness=pct,Model=model,Metric=metric,Height=value))
    ax.set_xticks(x,LABELS);ax.tick_params(axis='x',length=0,labelsize=8)
    ax.set_ylim(min(0,float(section.MCC.min())-.025) if section.MCC.min()<0 else 0,1.045)
    ax.set_yticks(np.arange(0,1.01,.2));ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax.set_axisbelow(True);ax.grid(axis='y',color='#e5e5e5',linewidth=.5)
    ax.set_ylabel('Score');ax.set_xlim(-.6,4.6)

def draw_heatmaps(per,overall,mod,pct):
    sub=per[per.Completeness.eq(pct)]
    own=sub[sub.Model.eq('ARGScope')].set_index('Type')
    # Display-only filters from the user's earlier instructions. Never change the aggregate metrics.
    shown=[]
    for typ in ORDER:
        if typ not in own.index or own.loc[typ,['Precision','Recall','F1']].sum()==0:continue
        others=sub[(sub.Type==typ)&(sub.Model!='ARGScope')]
        if others[['Precision','Recall','F1']].fillna(0).to_numpy().sum()==0:continue
        shown.append(typ)
    assert shown and not any(x.lower()=='nonarg' for x in shown)
    display=own.Type_display.to_dict()
    display.update({'aminoglycoside':'Aminoglycosides','tetracycline':'Tetracyclines'})
    n=len(shown); nmod=len(MODELS[mod])
    fig=plt.figure(figsize=(10.0 if mod=='Protein' else 7.6,7.0))
    grid=fig.add_gridspec(3,4,left=.225 if mod=='Protein' else .285,right=.95,bottom=.18,top=.95,
        height_ratios=[1,.6,n],width_ratios=[nmod,nmod,nmod,.17],wspace=.12,hspace=0)
    cmap=plt.get_cmap('Blues' if mod=='Protein' else 'Oranges')
    for j,metric in enumerate(['Precision','Recall','F1']):
        axav=fig.add_subplot(grid[0,j]);ax=fig.add_subplot(grid[2,j])
        av=overall[(overall.Completeness==pct)&(overall.Average=='macro')].set_index('Model')
        avg=np.array([[float(av.loc[m,metric]) for m in MODELS[mod]]])
        vals=np.zeros((n,nmod))
        for i,typ in enumerate(shown):
            for k,model in enumerate(MODELS[mod]):
                found=sub[(sub.Type==typ)&(sub.Model==model)]
                present=len(found)==1
                val=float(found.iloc[0][metric]) if present else 0.
                vals[i,k]=val
                heatmap_records.append({'Modality':mod,'Completeness':pct,'Metric':metric,'Type':typ,
                     'Model':model,'Value':val,'Source_present':present,'Display_missing_as_zero':not present})
        for this,arr in [(axav,avg),(ax,vals)]:
            image=this.imshow(arr,cmap=cmap,vmin=0,vmax=1,aspect='auto',interpolation='nearest')
            this.set_xticks(np.arange(nmod+1)-.5,minor=True);this.set_yticks(np.arange(arr.shape[0]+1)-.5,minor=True)
            this.grid(which='minor',color='white',linewidth=.7);this.tick_params(which='both',length=0)
            for (i,k),v in np.ndenumerate(arr):
                this.text(k,i,f'{v:.4f}',ha='center',va='center',fontsize=6.3 if mod=='Protein' else 7,
                          color='white' if v>.57 else '#202020')
            for spine in this.spines.values():spine.set_visible(False)
        axav.set_title(metric,fontsize=10,pad=6);axav.set_xticks([])
        axav.set_yticks([0],['Average'] if j==0 else [''],fontsize=8)
        ax.set_yticks(np.arange(n),[display[t] for t in shown] if j==0 else ['']*n,fontsize=8)
        ax.set_xticks(np.arange(nmod),MODELS[mod],rotation=52,ha='right',fontsize=8)
        for tick in ax.get_xticklabels():
            if tick.get_text()=='ARGScope':tick.set_color('#b44635');tick.set_fontweight('bold')
    cax=fig.add_subplot(grid[:,3]);cb=fig.colorbar(image,cax=cax)
    cb.set_ticks([0,.25,.5,.75,1]);cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=7,length=2);cb.outline.set_linewidth(.4)
    save(fig,OUT/mod/f'{mod}_{pct}pct_Type_precision_recall_F1')

def write_radars():
    for mod in MODELS:
        (OUT/mod).mkdir(exist_ok=True)
        fig,ax=plt.subplots(figsize=(5.4,5.0),subplot_kw={'projection':'polar'})
        fig.subplots_adjust(left=.18,right=.82,bottom=.24,top=.9)
        draw_binary_radar(ax,mod)
        fig.legend(handles=radar_handles(mod),loc='lower center',bbox_to_anchor=(.5,.035),ncol=3,
            frameon=False,fontsize=8,columnspacing=1.3,handlelength=2.3)
        save(fig,OUT/mod/f'{mod}_100pct_ARG_nonARG_macro_radar')
    fig,axes=plt.subplots(1,2,figsize=(11.2,5.5),subplot_kw={'projection':'polar'})
    fig.subplots_adjust(left=.095,right=.905,bottom=.27,top=.9,wspace=.55)
    for ax,mod in zip(axes,['Protein','DNA']):
        draw_binary_radar(ax,mod)
        ax.text(.5,-.20,mod,transform=ax.transAxes,ha='center',va='top',fontsize=12)
    fig.legend(handles=radar_handles('Protein'),loc='lower center',bbox_to_anchor=(.5,.025),ncol=5,
        frameon=False,fontsize=9,columnspacing=1.8,handlelength=2.3)
    save(fig,OUT/'Protein_DNA_100pct_ARG_nonARG_macro_radar')
    pd.DataFrame(radar_records).drop_duplicates().to_csv(OUT/'radar_values_source.csv',index=False,encoding='utf-8-sig',float_format='%.15g')

write_radars()
if '--radar-only' in sys.argv:
    print('Three binary radar figures generated.');sys.exit(0)

for mod in MODELS:
    (OUT/mod).mkdir(exist_ok=True)
    df=pd.read_csv(ROOT/mod/'01_Type_barplot_macro_five_metrics.csv')
    overall=pd.read_csv(ROOT/mod/'02_Type_overall_macro_weighted_micro.csv')
    per=pd.read_csv(ROOT/mod/'04_Per_Type_ARGScope23_display_view.csv')
    assert df.Scope.eq('ARG_only').all() and overall.Scope.eq('ARG_only').all()
    assert df.N_labels_averaged.eq(23).all() and overall.N_labels_averaged.eq(23).all()
    for pct in [60,70,80,90,100]:
        fig,ax=plt.subplots(figsize=(5.2,4.1))
        fig.subplots_adjust(left=.13,right=.985,bottom=.17,top=.86)
        draw_bars(ax,df,mod,pct)
        fig.legend(handles=handles(mod),loc='upper center',bbox_to_anchor=(.52,.985),ncol=len(MODELS[mod]),
                   frameon=False,fontsize=6.6 if mod=='Protein' else 8,handlelength=1.2,columnspacing=.8)
        save(fig,OUT/mod/f'{mod}_{pct}pct_Type_macro_bars')
        draw_heatmaps(per,overall,mod,pct)
    fig,axes=plt.subplots(2,3,figsize=(13.2,7.5),sharey=True)
    fig.subplots_adjust(left=.065,right=.985,bottom=.095,top=.89,wspace=.24,hspace=.32)
    for ax,pct in zip(axes.flat,[60,70,80,90,100]):
        draw_bars(ax,df,mod,pct);ax.set_title(f'{pct}%',fontsize=11,pad=8)
    axes[1,2].axis('off')
    fig.legend(handles=handles(mod),loc='upper center',bbox_to_anchor=(.52,.995),ncol=len(MODELS[mod]),
               frameon=False,fontsize=10,handlelength=1.6,columnspacing=1.8)
    save(fig,OUT/f'{mod}_60_to_100_Type_macro_bars')


pd.DataFrame(checked).drop_duplicates().to_csv(OUT/'bar_heights_source.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(heatmap_records).to_csv(OUT/'heatmap_display_source.csv',index=False,encoding='utf-8-sig')
(OUT/'plot_validation.json').write_text(json.dumps({'checked_bar_heights':len(checked),
 'unique_bar_heights':len(pd.DataFrame(checked).drop_duplicates()),'Type_scope':'ARG_only',
 'standalone_bar_panels':10,'combined_bar_figures':2,'combined_PRF_heatmaps':10,
 'binary_radar_figures':3,'radar_completeness':100,'radar_average':'macro','radar_includes_nonARG':True,
 'mapping_policy':'strict_name_equivalence_v1',
 'formats':['png','pdf','svg'],'Fixed_Type_labels':23,'previous_generated_figures_replaced':True},indent=2),encoding='utf-8')
(OUT/'README_作图口径.txt').write_text('''本次图片全部从 ALL_result 的新总表绘制，不使用旧图中读取的数值。
严格名称对应：仅同名、明确缩写和拼写规范化；取消跨层级映射及多类别转multidrug。映射明细见根目录Type_name_mapping_audit.csv。
新增100% ARG/nonARG雷达图：Protein、DNA单图及合图。五轴为ACC、macro precision、macro recall、macro F1、MCC；含真实ARG和nonARG，不使用Type筛选。雷达数值见radar_values_source.csv。
Type 只保留真实标签属于 ARGScope 固定 23 类的样本；真实 nonARG 及额外 Type 样本排除。预测成 nonARG、额外 Type 或 unmapped 的仍保留为错误。
柱状图：ACC、macro precision、macro recall、macro F1、全局 MCC。数据底稿为 bar_heights_source.csv。
每个完整度提供一个单独柱状图、一个合并 Precision/Recall/F1 热图；Protein 和 DNA 各有一张 60–100% 柱状图汇总。
单图不加 A/B 字母、顶部描述或底部小字。汇总图仅标注必要的完整度。
热图使用 ARGScope 23 个 Type 范围。若 ARGScope 的 P/R/F1 全为 0，或其他模型 P/R/F1 全为缺失/0，则仅从显示中移除；剩余缺失值按此前要求显示为 0。显示底稿记录了真实 0 与缺失填 0 的区别。
热图 Average 与柱状图对应的 macro 值一致，统一按全部 23 个 Type 计算，不是筛选后可见行的均值。
上述显示筛选不改变任何总指标；整体计算统一使用固定 23 类，保留零分及无真实支持的 Type。
DeepARG Type 为提供的 Type 评估记录；其二分类使用对应完整记录。结果是现有输出的描述性对照，并未新建匹配测试队列。
PNG 为 400 dpi；PDF/SVG 为矢量图。本目录上次生成的结果已替换；原始数据及原补充材料未修改。
''',encoding='utf-8')
print(f'Saved 25 figures in PNG/PDF/SVG under {OUT}; {len(checked)} bar heights verified; 40 unique radar values checked.')
