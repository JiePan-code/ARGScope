# inspect_fusion_embedding_dataset.py

from pathlib import Path
import re
import pandas as pd


# ============================================================
# 配置
# ============================================================
FUSION_FILE = Path("1.all_fusion_embedding_512_with_label.csv")

OUT_REPORT = Path("fusion_embedding_diagnosis.txt")
OUT_DUPLICATES = Path("fusion_duplicate_ids.csv")
OUT_CONFLICTS = Path("fusion_subtype_type_conflicts.csv")
OUT_SAMPLE_IDS = Path("fusion_sample_ids.csv")

CHUNK_SIZE = 100000


# ============================================================
# 工具函数
# ============================================================
def infer_base_id(x: str) -> str:
    """
    尝试移除常见扩增后缀，例如：
    geneA_1 -> geneA
    geneA_5 -> geneA

    这只是辅助检查，不会修改原始数据。
    """
    x = str(x).strip()
    return re.sub(r"_[1-9][0-9]*$", "", x)


def write_line(handle, text=""):
    print(text)
    handle.write(str(text) + "\n")


# ============================================================
# 1. 检查文件
# ============================================================
if not FUSION_FILE.exists():
    raise FileNotFoundError(f"找不到文件：{FUSION_FILE.resolve()}")

header_df = pd.read_csv(FUSION_FILE, nrows=0)
all_cols = header_df.columns.astype(str).tolist()

required_meta_cols = ["id", "Type", "Subtype"]
missing_meta = [c for c in required_meta_cols if c not in all_cols]

if missing_meta:
    raise RuntimeError(f"缺少必要列：{missing_meta}")

expected_feature_cols = [f"fusion_{i}" for i in range(512)]
existing_feature_cols = [c for c in all_cols if c.startswith("fusion_")]

missing_features = [
    c for c in expected_feature_cols
    if c not in all_cols
]

unexpected_cols = [
    c for c in all_cols
    if c not in required_meta_cols + expected_feature_cols
]


# ============================================================
# 2. 分块读取元数据列
# ============================================================
meta_parts = []

for chunk in pd.read_csv(
    FUSION_FILE,
    usecols=required_meta_cols,
    chunksize=CHUNK_SIZE,
    low_memory=False,
):
    meta_parts.append(chunk)

meta = pd.concat(meta_parts, ignore_index=True)

for col in required_meta_cols:
    meta[col] = meta[col].astype("string").str.strip()

meta["base_id_inferred"] = meta["id"].map(infer_base_id)


# ============================================================
# 3. 基础统计
# ============================================================
total_rows = len(meta)
unique_ids = meta["id"].nunique(dropna=True)
unique_base_ids = meta["base_id_inferred"].nunique(dropna=True)
unique_types = meta["Type"].nunique(dropna=True)
unique_subtypes = meta["Subtype"].nunique(dropna=True)

missing_id = int(meta["id"].isna().sum())
missing_type = int(meta["Type"].isna().sum())
missing_subtype = int(meta["Subtype"].isna().sum())

empty_id = int((meta["id"].fillna("") == "").sum())
empty_type = int((meta["Type"].fillna("") == "").sum())
empty_subtype = int((meta["Subtype"].fillna("") == "").sum())


# ============================================================
# 4. 重复 ID 检查
# ============================================================
duplicate_mask = meta["id"].duplicated(keep=False)
duplicate_df = meta.loc[duplicate_mask].sort_values(
    ["id", "Type", "Subtype"]
)

duplicate_df.to_csv(
    OUT_DUPLICATES,
    index=False,
    encoding="utf-8-sig",
)


# ============================================================
# 5. 同一 ID 是否对应多个标签
# ============================================================
id_type_nunique = meta.groupby("id", dropna=False)["Type"].nunique()
id_subtype_nunique = meta.groupby("id", dropna=False)["Subtype"].nunique()

id_type_conflict_count = int((id_type_nunique > 1).sum())
id_subtype_conflict_count = int((id_subtype_nunique > 1).sum())


# ============================================================
# 6. subtype -> Type 映射冲突
# ============================================================
subtype_type_counts = (
    meta.groupby(["Subtype", "Type"], dropna=False)
    .size()
    .reset_index(name="Count")
)

subtype_type_nunique = (
    subtype_type_counts.groupby("Subtype")["Type"]
    .nunique()
)

conflict_subtypes = subtype_type_nunique[
    subtype_type_nunique > 1
].index

conflict_df = subtype_type_counts[
    subtype_type_counts["Subtype"].isin(conflict_subtypes)
].sort_values(["Subtype", "Count"], ascending=[True, False])

conflict_df.to_csv(
    OUT_CONFLICTS,
    index=False,
    encoding="utf-8-sig",
)


# ============================================================
# 7. 检查扩增 ID 情况
# ============================================================
base_id_counts = (
    meta.groupby("base_id_inferred")
    .size()
    .sort_values(ascending=False)
)

base_ids_with_multiple_rows = int((base_id_counts > 1).sum())
max_rows_per_base_id = int(base_id_counts.max()) if len(base_id_counts) else 0

suffix_match = meta["id"].fillna("").str.match(r".+_[1-9][0-9]*$")
suffix_match_count = int(suffix_match.sum())


# ============================================================
# 8. 保存部分示例 ID
# ============================================================
sample_n = min(200, len(meta))

sample_df = meta.head(sample_n).copy()
sample_df.to_csv(
    OUT_SAMPLE_IDS,
    index=False,
    encoding="utf-8-sig",
)


# ============================================================
# 9. 输出诊断报告
# ============================================================
with open(OUT_REPORT, "w", encoding="utf-8") as f:

    write_line(f, "=" * 70)
    write_line(f, "Fusion embedding dataset diagnosis")
    write_line(f, "=" * 70)

    write_line(f, f"File: {FUSION_FILE.resolve()}")
    write_line(f, f"File size MB: {FUSION_FILE.stat().st_size / 1024 / 1024:.2f}")

    write_line(f)
    write_line(f, "[Column structure]")
    write_line(f, f"Total columns: {len(all_cols)}")
    write_line(f, f"Metadata columns: {required_meta_cols}")
    write_line(f, f"Detected fusion columns: {len(existing_feature_cols)}")
    write_line(f, f"Expected fusion columns: 512")
    write_line(f, f"Missing fusion columns: {len(missing_features)}")
    write_line(f, f"Unexpected columns: {unexpected_cols}")

    if existing_feature_cols:
        write_line(f, f"First fusion columns: {existing_feature_cols[:10]}")
        write_line(f, f"Last fusion columns: {existing_feature_cols[-10:]}")

    write_line(f)
    write_line(f, "[Dataset size]")
    write_line(f, f"Total rows: {total_rows}")
    write_line(f, f"Unique IDs: {unique_ids}")
    write_line(f, f"Unique inferred base IDs: {unique_base_ids}")
    write_line(f, f"Unique Types: {unique_types}")
    write_line(f, f"Unique Subtypes: {unique_subtypes}")

    write_line(f)
    write_line(f, "[Missing values]")
    write_line(f, f"Missing ID: {missing_id}")
    write_line(f, f"Missing Type: {missing_type}")
    write_line(f, f"Missing Subtype: {missing_subtype}")
    write_line(f, f"Empty ID: {empty_id}")
    write_line(f, f"Empty Type: {empty_type}")
    write_line(f, f"Empty Subtype: {empty_subtype}")

    write_line(f)
    write_line(f, "[Duplicate and label conflict]")
    write_line(f, f"Rows belonging to duplicated IDs: {len(duplicate_df)}")
    write_line(f, f"Unique duplicated IDs: {duplicate_df['id'].nunique()}")
    write_line(f, f"IDs mapped to multiple Types: {id_type_conflict_count}")
    write_line(f, f"IDs mapped to multiple Subtypes: {id_subtype_conflict_count}")
    write_line(f, f"Subtypes mapped to multiple Types: {len(conflict_subtypes)}")

    write_line(f)
    write_line(f, "[Fragment/base-ID pattern]")
    write_line(f, f"IDs ending with numeric suffix such as _1: {suffix_match_count}")
    write_line(f, f"Base IDs represented by multiple rows: {base_ids_with_multiple_rows}")
    write_line(f, f"Maximum rows for one inferred base ID: {max_rows_per_base_id}")

    write_line(f)
    write_line(f, "[Most frequent Types]")
    for type_name, count in meta["Type"].value_counts().head(20).items():
        write_line(f, f"{type_name}\t{count}")

    write_line(f)
    write_line(f, "[Most frequent Subtypes]")
    for subtype_name, count in meta["Subtype"].value_counts().head(20).items():
        write_line(f, f"{subtype_name}\t{count}")

    write_line(f)
    write_line(f, "[Output files]")
    write_line(f, str(OUT_REPORT.resolve()))
    write_line(f, str(OUT_DUPLICATES.resolve()))
    write_line(f, str(OUT_CONFLICTS.resolve()))
    write_line(f, str(OUT_SAMPLE_IDS.resolve()))

print("\n检查完成。")
print("请把下面文件上传给我：")
print(f"1. {OUT_REPORT}")
print(f"2. {OUT_DUPLICATES}")
print(f"3. {OUT_CONFLICTS}")
print(f"4. {OUT_SAMPLE_IDS}")