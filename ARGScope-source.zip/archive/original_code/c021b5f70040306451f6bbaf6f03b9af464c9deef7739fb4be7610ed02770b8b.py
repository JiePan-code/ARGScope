import pandas as pd
import numpy as np

# =========================
# 配置
# =========================
PROTO_FILE = "1.all_subtype_prototypes_512.csv"
OUT_EDGE_FILE = "2.all_subtype_graph_edges.csv"
K = 20                 # 每个节点在同 Type 内连 K 个最近邻（建议 10~30）
ADD_SELF_LOOP = False  # 是否加自环
MAKE_BIDIRECTIONAL = True  # True: i->j 和 j->i 都输出（GAT常用）

# =========================
# 1. 读取 prototype
# =========================
proto_df = pd.read_csv(PROTO_FILE)
print("Subtype 数量:", len(proto_df))

# 给每个 Subtype 一个节点 ID
proto_df["node_id"] = np.arange(len(proto_df))
subtype_to_id = dict(zip(proto_df["Subtype"].astype(str), proto_df["node_id"]))

# =========================
# 2. 选择特征列
#    优先用 g0..g511；否则用所有数值列（排除 Count/node_id）
# =========================
g_cols = [c for c in proto_df.columns if str(c).startswith("g")]
if len(g_cols) > 0:
    feat_cols = g_cols
else:
    # fallback：自动找数值列
    num_cols = proto_df.select_dtypes(include=[np.number]).columns.tolist()
    feat_cols = [c for c in num_cols if c not in ["Count", "node_id"]]

print("特征维度:", len(feat_cols))

# 确保数值
proto_df[feat_cols] = proto_df[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

# =========================
# 3. 同 Type 内 KNN 构边（cosine）
# =========================
edges_set = set()

def l2_normalize(X, eps=1e-12):
    norm = np.linalg.norm(X, axis=1, keepdims=True)
    return X / (norm + eps)

types = proto_df["Type"].astype(str).unique().tolist()

for t in types:
    df_t = proto_df[proto_df["Type"].astype(str) == t].copy()
    node_ids = df_t["node_id"].values
    n = len(df_t)

    if n <= 1:
        continue  # 这个 type 只有一个节点，没法连邻居

    X = df_t[feat_cols].values.astype(np.float32)
    X = l2_normalize(X)  # cosine 相似度 = 点积

    # 相似度矩阵 S = X @ X.T（n x n）
    S = X @ X.T
    np.fill_diagonal(S, -np.inf)  # 不选自己当邻居

    # 每个节点选 topK
    k_eff = min(K, n - 1)

    # argpartition 得到 topk 的索引（无序），再按相似度排序
    topk_idx = np.argpartition(-S, kth=k_eff-1, axis=1)[:, :k_eff]

    # 逐点生成边
    for i in range(n):
        src = int(node_ids[i])
        nbrs = topk_idx[i]
        # 按相似度从大到小排序（可读性更好）
        nbrs = nbrs[np.argsort(-S[i, nbrs])]

        for j_local in nbrs:
            dst = int(node_ids[int(j_local)])

            edges_set.add((src, dst))
            if MAKE_BIDIRECTIONAL:
                edges_set.add((dst, src))

# 可选自环
if ADD_SELF_LOOP:
    for nid in proto_df["node_id"].values:
        edges_set.add((int(nid), int(nid)))

edges = np.array(sorted(list(edges_set)), dtype=np.int64)
print("边数量:", len(edges))

# =========================
# 4. 保存 edge list
# =========================
edge_df = pd.DataFrame(edges, columns=["source", "target"])
edge_df.to_csv(OUT_EDGE_FILE, index=False, encoding="utf-8-sig")
print(f"已保存 {OUT_EDGE_FILE}")