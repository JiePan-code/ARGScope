import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
)

# =========================
# 输入输出文件
# =========================
INPUT_FILE = "subtype_test_predictions.csv"

OUTPUT_PRED_FILE = "type_test_predictions.csv"
OUTPUT_OVERALL_FILE = "type_overall_metrics_from_subtype.csv"
OUTPUT_PER_CLASS_FILE = "50aa_type_metrics_by_class_from_subtype.csv"

# =========================
# 计算总体指标
# =========================
def compute_overall_metrics(y_true, y_pred):
    return {
        "sample_count": int(len(y_true)),
        "type_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),

        "PRECISION_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "RECALL_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "F1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),

        "PRECISION_weighted": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "RECALL_weighted": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "F1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),

        "PRECISION_micro": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "RECALL_micro": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "F1_micro": f1_score(y_true, y_pred, average="micro", zero_division=0),

        "MCC": matthews_corrcoef(y_true, y_pred),
    }

# =========================
# 计算每个 type 的指标
# =========================
def compute_binary_mcc_for_class(y_true, y_pred, class_name):
    y_true_bin = (y_true == class_name).astype(int)
    y_pred_bin = (y_pred == class_name).astype(int)

    if len(np.unique(y_true_bin)) == 1 and len(np.unique(y_pred_bin)) == 1:
        return 0.0

    return matthews_corrcoef(y_true_bin, y_pred_bin)

def compute_per_type_metrics(y_true, y_pred):
    rows = []
    all_types = sorted(pd.Series(y_true).astype(str).unique())

    for t in all_types:
        y_true_bin = (y_true == t).astype(int)
        y_pred_bin = (y_pred == t).astype(int)

        support = int(y_true_bin.sum())
        pred_count = int(y_pred_bin.sum())
        correct_count = int(((y_true == t) & (y_pred == t)).sum())

        acc = correct_count / support if support > 0 else 0.0
        precision = precision_score(y_true_bin, y_pred_bin, zero_division=0)
        recall = recall_score(y_true_bin, y_pred_bin, zero_division=0)
        f1 = f1_score(y_true_bin, y_pred_bin, zero_division=0)
        mcc = compute_binary_mcc_for_class(y_true, y_pred, t)

        rows.append({
            "Type": t,
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct_count,
            "ACC": acc,
            "PRECISION": precision,
            "RECALL": recall,
            "F1": f1,
            "MCC": mcc
        })

    return pd.DataFrame(rows).sort_values(
        by=["support", "Type"], ascending=[False, True]
    ).reset_index(drop=True)

# =========================
# 主程序
# =========================
df = pd.read_csv(INPUT_FILE)

required_cols = ["Type", "Subtype", "Pred_Subtype"]
for col in required_cols:
    if col not in df.columns:
        raise ValueError(f"输入文件缺少必要列: {col}")

df["Type"] = df["Type"].astype(str)
df["Subtype"] = df["Subtype"].astype(str)
df["Pred_Subtype"] = df["Pred_Subtype"].astype(str)

# 1. 构造 Subtype -> Type 映射（基于真实标签）
subtype_type_df = df[["Subtype", "Type"]].drop_duplicates().copy()

dup_check = subtype_type_df.groupby("Subtype")["Type"].nunique()
bad = dup_check[dup_check > 1]
if len(bad) > 0:
    raise ValueError(
        "发现同一个 Subtype 对应多个 Type，无法唯一反推。示例: "
        + ", ".join(bad.index[:10].tolist())
    )

subtype_to_type = dict(zip(subtype_type_df["Subtype"], subtype_type_df["Type"]))

# 2. 反推真实/预测 Type
df["True_Type"] = df["Type"]
df["Pred_Type"] = df["Pred_Subtype"].map(subtype_to_type)

# 检查是否有预测 subtype 无法映射到 type
if df["Pred_Type"].isna().any():
    miss = df.loc[df["Pred_Type"].isna(), "Pred_Subtype"].astype(str).unique().tolist()
    raise ValueError(f"这些 Pred_Subtype 无法映射到 Type: {miss[:10]}")

# 3. 保存逐样本结果
keep_cols = [c for c in ["KEY", "Geneid", "Type", "Subtype", "Pred_Subtype", "True_Type", "Pred_Type"] if c in df.columns]
pred_out = df[keep_cols].copy()
pred_out.to_csv(OUTPUT_PRED_FILE, index=False, encoding="utf-8-sig")

# 4. 计算总体指标
y_true = df["True_Type"].astype(str).values
y_pred = df["Pred_Type"].astype(str).values

overall_metrics = compute_overall_metrics(y_true, y_pred)
overall_df = pd.DataFrame([overall_metrics]).round(4)
overall_df.to_csv(OUTPUT_OVERALL_FILE, index=False, encoding="utf-8-sig")

# 5. 计算每个 type 的指标
per_type_df = compute_per_type_metrics(y_true, y_pred).round(4)
per_type_df.to_csv(OUTPUT_PER_CLASS_FILE, index=False, encoding="utf-8-sig")

print("已保存：")
print(" -", OUTPUT_PRED_FILE)
print(" -", OUTPUT_OVERALL_FILE)
print(" -", OUTPUT_PER_CLASS_FILE)
print("Done.")