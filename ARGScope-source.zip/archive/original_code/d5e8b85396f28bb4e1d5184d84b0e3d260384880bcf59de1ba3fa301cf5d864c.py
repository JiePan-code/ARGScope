"""Read-only source processing for the six ablations and the supplied Full tables."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from docx import Document

ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\消融实验结果")
REFERENCE = Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary materials.docx")
OLD_ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\ARGscope_result_9.16\ARGScope")
OUT = Path(__file__).resolve().parent / "outputs" / "ablation_supplement_20260918"
AVERAGES = ("macro", "weighted", "micro")
METRICS = ("ACC", "Precision", "Recall", "F1", "MCC")
SPECS = [
    (modality, label, f"{prefix}_student_subtype2_newsplit_{suffix}")
    for modality, prefix in (("Protein", "Protein"), ("DNA", "DNA"))
    for label, suffix in (("w/o Gate", "wo_gate"), ("w/o Graph", "wo_graph"),
                         ("w/o Transfer", "wo_transfer" if modality == "Protein" else "wo_transfer_fixed"))
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def divide(a, b):
    return a / b if b else 0.0


def calculate(y, p, binary=False):
    """Same all-sequence/union-label/zero_division=0 definition as the old scripts."""
    if not y or len(y) != len(p):
        raise ValueError("Empty or mismatched truth and prediction")
    n = len(y)
    labels = sorted(set(y) | set(p))
    tc, pc = Counter(y), Counter(p)
    tp = Counter(a for a, b in zip(y, p) if a == b)
    correct = sum(tp.values())
    numerator = n * correct - sum(tc[c] * pc[c] for c in labels)
    denom2 = (n * n - sum(v * v for v in tc.values())) * (n * n - sum(v * v for v in pc.values()))
    mcc = divide(numerator, math.sqrt(denom2))
    per = {c: (divide(tp[c], pc[c]), divide(tp[c], tc[c]),
               divide(2 * tp[c], pc[c] + tc[c])) for c in labels}
    result = []
    for avg in (("ARG-positive",) if binary else AVERAGES):
        if binary:
            prf = per.get("1", (0.0, 0.0, 0.0))
        elif avg == "macro":
            prf = [sum(per[c][k] for c in labels) / len(labels) for k in range(3)]
        elif avg == "weighted":
            prf = [sum(per[c][k] * tc[c] for c in labels) / n for k in range(3)]
        else:
            prf = [correct / n] * 3
        result.append({"Average": avg, **dict(zip(METRICS, (correct / n, *prf, mcc))),
                       "N": n, "n_classes_union": len(labels)})
    return result


def truth_map(rows):
    result = {}
    for i, row in enumerate(rows, 2):
        keys = ("sequence_id", "true_ARG", "predicted_ARG", "true_type", "predicted_type",
                "true_subtype", "predicted_subtype", "split", "sequence_level", "coverage")
        if any(not row.get(k, "").strip() for k in keys):
            raise ValueError(f"Missing value in CSV row {i}")
        sid = row["sequence_id"]
        if sid in result:
            raise ValueError(f"Duplicate ID: {sid}")
        if row["split"] != "test" or row["sequence_level"] != "full_length" or float(row["coverage"]) != 1:
            raise ValueError(f"Not a full-length test row: {sid}")
        for prefix in ("true", "predicted"):
            arg = row[f"{prefix}_ARG"]
            if arg not in ("0", "1"):
                raise ValueError(f"Unexpected binary label: {sid}")
            for level in ("type", "subtype"):
                if (arg == "0") != (row[f"{prefix}_{level}"].casefold() == "nonarg"):
                    raise ValueError(f"Inconsistent binary/{level} labels: {sid}")
        result[sid] = tuple(row[k] for k in ("true_ARG", "true_type", "true_subtype"))
    return result


def get_full_tables():
    doc = Document(REFERENCE)
    result, checks = [], []
    for offset, modality, folder in ((0, "Protein", "protein_result"), (3, "DNA", "DNA_result")):
        old_dir = OLD_ROOT / folder / f"{folder.split('_')[0]}_all_metrics_results_binary_ARG"
        for i, level, old_name in ((0, "ARG/nonARG", "01_ARG_nonARG_binary_five_metrics.csv"),
                                  (1, "Type", "02_type_overall_five_metrics.csv"),
                                  (2, "Subtype", "03_subtype_overall_five_metrics.csv")):
            table = doc.tables[offset + i]
            headers = [c.text.strip() for c in table.rows[0].cells]
            selected = [dict(zip(headers, [c.text.strip() for c in row.cells]))
                        for row in table.rows[1:] if row.cells[0].text.strip() == "100%"]
            if len(selected) != (1 if i == 0 else 3):
                raise ValueError(f"Unexpected reference rows for {modality} {level}")
            old_path = old_dir / old_name
            old_rows = [r for r in read_csv(old_path) if r["condition"] == "100%"]
            for source in selected:
                avg = source.get("Average", "ARG-positive")
                old = [r for r in old_rows if r.get("average", "ARG-positive") == avg]
                if len(old) != 1:
                    raise ValueError("Cannot trace the supplementary row")
                old = old[0]
                for metric, old_metric in zip(METRICS, ("accuracy", "precision", "recall", "f1", "mcc")):
                    if abs(float(source[metric]) - float(old[old_metric])) > 0.0000501:
                        raise ValueError(f"Supplementary/source mismatch: {modality}, {level}, {metric}")
                result.append({"Modality": modality, "Model": "Full (reference)", "Condition": "100%",
                               "Class": level, "Average": avg,
                               **{m: float(source[m]) for m in METRICS},
                               "N": int(old["n_samples"]), "n_classes_union": old.get("n_classes_union", 2),
                               "Source": f"Supplementary materials.docx Table {offset + i + 1}, 100%"})
            checks.append({"path": str(old_path), "sha256": sha(old_path),
                           "check": "All five printed values agree to four decimals; used only for provenance and N"})
    return result, checks


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    full_rows, old_checks = get_full_tables()
    rows, input_checks = [], []
    ref_truth = None
    # Authoritative test list is checked but never rewritten or resplit.
    test_ids_path = ROOT.parent / "test_ids_subtype2.txt"
    test_ids = [s.strip() for s in test_ids_path.read_text(encoding="utf-8-sig").splitlines() if s.strip()]
    if len(test_ids) != len(set(test_ids)):
        raise ValueError("Duplicate IDs in authoritative test list")
    for modality, model, folder in SPECS:
        path = ROOT / folder / "test_sequence_predictions.csv"
        data = read_csv(path)
        truth = truth_map(data)
        if set(truth) != set(test_ids):
            raise ValueError(f"Authoritative test IDs do not match: {folder}")
        if ref_truth is not None and truth != ref_truth:
            raise ValueError(f"Different test IDs or ground truth: {folder}")
        ref_truth = truth
        for level, stem in (("ARG/nonARG", "ARG"), ("Type", "type"), ("Subtype", "subtype")):
            for metric_row in calculate([r[f"true_{stem}"] for r in data],
                                        [r[f"predicted_{stem}"] for r in data], binary=stem == "ARG"):
                rows.append({"Modality": modality, "Model": model, "Condition": "100%", "Class": level,
                             **metric_row, "Source": str(path.relative_to(ROOT))})
        input_checks.append({"modality": modality, "model": model, "path": str(path), "sha256": sha(path),
                             "N": len(data), "ARG": sum(r["true_ARG"] == "1" for r in data),
                             "nonARG": sum(r["true_ARG"] == "0" for r in data),
                             "unique_ids": len(truth), "authoritative_test_ids_match": True})
    ordered = []
    for modality in ("Protein", "DNA"):
        for level in ("ARG/nonARG", "Type", "Subtype"):
            ordered.extend(r for r in full_rows if r["Modality"] == modality and r["Class"] == level)
            ordered.extend(r for r in rows if r["Modality"] == modality and r["Class"] == level)
    assert len(rows) == 42 and len(full_rows) == 14 and len(ordered) == 56
    payload = {"rows": ordered, "notes": [
        "100% sequences only. Full values are copied from the supplied supplementary material, not recalculated.",
        "ARG/nonARG: ARG is positive. Type/Subtype: all test sequences, including nonARG; union of true and predicted labels.",
        "Full reference: N=8,382 (ARG=3,902; nonARG=4,480). Ablations: N=11,140 (ARG=5,570; nonARG=5,570).",
        "Full and ablations use different test populations. These rows are not a matched-test-set ablation comparison.",
        "Five metrics: ACC, Precision, Recall, F1 and MCC. ACC and multiclass MCC do not change with the averaging scheme.",
        "Undefined Precision/Recall/F1 and degenerate MCC use zero, matching the original calculation convention."
    ]}
    (OUT / "reviewed_results.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    fields = ["Modality", "Model", "Condition", "Class", "Average", *METRICS, "N", "Source"]
    with (OUT / "消融结果汇总.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({**r, **{m: f"{r[m]:.4f}" for m in METRICS}} for r in ordered)
    audit = {"created_at": datetime.now(timezone.utc).isoformat(), "full_reference": str(REFERENCE),
             "full_reference_sha256": sha(REFERENCE), "full_metrics_recalculated": False,
             "full_source_trace": old_checks, "ablation_inputs": input_checks,
             "all_six_test_ids_and_truth_equal": True, "test_ids_sha256": sha(test_ids_path),
             "full_and_ablation_same_test_population": False, "notes": payload["notes"]}
    (OUT / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "结果说明.txt").write_text(
        "消融结果汇总\n\n"
        "1. 仅重新计算 Protein 和 DNA 的 w/o Gate、w/o Graph、w/o Transfer，共六组。\n"
        "2. Full 行原样摘录 Supplementary materials.docx 表1至表6的100%结果，没有重新计算Full。\n"
        "3. ARG/nonARG按ARG为阳性类；Type和Subtype包含nonARG，均给macro、weighted、micro三行。\n"
        "4. 指标为ACC、Precision、Recall、F1、MCC，显示四位小数。ACC和MCC不按三种平均方式分别改变。\n"
        "5. 六组消融均有11140条测试序列，ARG和nonARG各5570条；ID和真实标签一致，与权威test_ids一致。\n"
        "6. 重要：原Full结果对应8382条测试序列，ARG=3902、nonARG=4480；与当前消融测试集不同。\n"
        "   Full行仅作为补充材料原始结果参考，不能据此差值直接证明模块贡献；本次未更改划分或训练。\n"
        "7. macro按本次真实与预测标签的并集计算，包含仅被预测到的类别；零分母指标按0处理，与原脚本一致。\n"
        "8. 本次按最新要求仅交付总体结果，不生成逐Type或逐Subtype明细。\n",
        encoding="utf-8-sig")
    print(json.dumps({"output": str(OUT), "ablation_rows": len(rows), "reference_rows": len(full_rows),
                      "source_N": [x["N"] for x in input_checks]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
