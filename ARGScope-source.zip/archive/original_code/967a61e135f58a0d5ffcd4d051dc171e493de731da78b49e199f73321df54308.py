"""Export verified weighted-subtype composites and enforce unchanged other panels."""
from pathlib import Path
import json
import shutil
import zipfile
import numpy as np
from PIL import Image, ImageChops

HERE = Path(__file__).resolve().parent
WORK = HERE / 'outputs/figure2_figure3_weighted_20260924'
RASTERS = WORK / 'a4_raster'
PREVIOUS = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Figure2_Figure3_A4_300DPI_TIF_20260924')
OUT = PREVIOUS.parent / 'Figure2_Figure3_Subtype_weighted_A4_300DPI_20260924'
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'previews').mkdir(exist_ok=True)
(OUT / 'weighted_bar_panels').mkdir(exist_ok=True)
manifest = json.loads((RASTERS / 'render_manifest.json').read_text(encoding='utf-8'))
metrics = json.loads((WORK / 'weighted_metrics_verified.json').read_text(encoding='utf-8'))
verification = []

for record, metric in zip(manifest, metrics):
    name = record['name']
    with Image.open(record['rasterPath']) as image:
        rgba = image.convert('RGBA')
    with Image.open(PREVIOUS / f'{name}_A4_300DPI_transparent.tif') as image:
        previous = image.convert('RGBA')
    assert rgba.size == previous.size == (2480, 3508)
    changed = np.any(np.asarray(rgba) != np.asarray(previous), axis=2)
    yy, xx = np.where(changed)
    bbox = [int(xx.min()), int(yy.min()), int(xx.max()) + 1, int(yy.max()) + 1]
    # Panel B is in the upper-right. All remaining pixels must match exactly.
    outside_B = changed.copy()
    outside_B[0:635, 1180:2480] = False
    mismatch = int(outside_B.sum())
    assert mismatch == 0, f'Unexpected non-B changes: {name}: {mismatch}, bbox={bbox}'
    assert changed.sum() > 0
    for variant in ['transparent', 'white']:
        if variant == 'white':
            pixels = Image.new('RGB', rgba.size, 'white')
            pixels.paste(rgba, mask=rgba.getchannel('A'))
        else:
            pixels = rgba
        destination = OUT / f'{name}_Subtype_weighted_A4_300DPI_{variant}.tif'
        pixels.save(destination, format='TIFF', compression='tiff_lzw', dpi=(300, 300))
        with Image.open(destination) as reopened:
            reopened.load()
            assert reopened.size == (2480, 3508)
            assert tuple(map(float, reopened.info['dpi'])) == (300.0, 300.0)
            assert reopened.tag_v2[296] == 2 and reopened.tag_v2[259] == 5
            assert reopened.tobytes() == pixels.tobytes()
            if variant == 'white':
                preview = reopened.copy()
                preview.thumbnail((1240, 1754), Image.Resampling.LANCZOS)
                preview.save(OUT / 'previews' / f'{name}_preview.png')
                reopened.crop((1180, 0, 2480, 635)).save(OUT / 'previews' / f'{name}_weighted_bar_detail.png')
    # Extra independent B panels, at the same 300-DPI physical scale as the composite.
    for variant in ['transparent', 'white']:
        panel = rgba.crop((1180, 0, 2460, 635))
        if variant == 'white':
            white = Image.new('RGB', panel.size, 'white')
            white.paste(panel, mask=panel.getchannel('A'))
            panel = white
        panel.save(OUT / 'weighted_bar_panels' / f'{name}_B_Subtype_weighted_{variant}.tif',
                   format='TIFF', compression='tiff_lzw', dpi=(300, 300))
    verification.append({'figure': name, 'only_B_changed': True, 'changed_bbox': bbox,
                         'non_B_pixel_differences': mismatch, 'weighted_values': metric['values'],
                         'dimensions': [2480, 3508], 'dpi': [300, 300]})

(OUT / 'verification.json').write_text(json.dumps(verification, indent=2), encoding='utf-8')
shutil.copy2(WORK / 'weighted_metrics_verified.json', OUT / 'weighted_metrics_verified.json')
readme = '''Figure 2 / Figure 3: subtype weighted bars

仅修改 B 子图。五根柱分别为 ACC、Weighted precision、Weighted recall、Weighted F1、MCC。
ACC 和 MCC 保持原值。采用同一批 4574 条测试序列，仍包括 non-ARG 类。
weighted 指标按各参考类别的样本数加权，并用原始逐序列预测结果核对。
与上一版 TIF 逐像素比较，B 子图以外全部像素一致。原图、原始预测和原始指标表均未改动。

主组图：A4 纵向，2480 × 3508 像素，300 DPI，LZW 无损压缩。
transparent：透明背景，white：白色背景。
weighted_bar_panels：两张独立 B 子图，300 DPI，便于单独替换。
previews：查看用 PNG，正式使用请选 TIF。

AA: ACC 0.9434, weighted precision 0.9262, weighted recall 0.9434, weighted F1 0.9313, MCC 0.9241.
NT: ACC 0.9257, weighted precision 0.8992, weighted recall 0.9257, weighted F1 0.9092, MCC 0.8997.
'''
(OUT / 'README.txt').write_text(readme, encoding='utf-8-sig')
with zipfile.ZipFile(OUT / 'Figure2_Figure3_Subtype_weighted_TIF.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.suffix != '.zip':
            archive.write(path, path.relative_to(OUT))
print(json.dumps({'delivery': str(OUT), 'verification': verification}, ensure_ascii=False, indent=2))
