# -*- coding: utf-8 -*-
"""
Batch prediction for 60p-90p protein embedding files using saved ARGScope LongAA model.

This version supports expanded IDs such as:
    originalID_1
    originalID_2
    originalID_3
    originalID_4
    originalID_5

It reports both:
    1. Fragment-level metrics: each _1/_2/_3/_4/_5 sequence is one test sample.
    2. Base-ID-level metrics: five expanded sequences are merged by majority voting.

Put this script inside ARGScope_saved_model folder.

Input files:
    2.60p_ARG_protein_with_label.csv
    2.70p_ARG_protein_with_label.csv
    2.80p_ARG_protein_with_label.csv
    2.90p_ARG_protein_with_label.csv

Required model files:
    argscope_subtype_longaa_checkpoint.pth
    feature_info.joblib
    label_encoder.joblib
    scaler_longaa.joblib

Output folder:
    ARGScope_LongAA_60p_90p_prediction_results
"""

import os
import re
import gc
import joblib
import warnings
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    matthews_corrcoef,
    classification_report,
)

warnings.filterwarnings("ignore")


# =========================================================
# 1. CONFIG
# =========================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = BASE_DIR

INPUT_FILES = {
    "60p": os.path.join(BASE_DIR, "2.60p_ARG_protein_with_label.csv"),
    "70p": os.path.join(BASE_DIR, "2.70p_ARG_protein_with_label.csv"),
    "80p": os.path.join(BASE_DIR, "2.80p_ARG_protein_with_label.csv"),
    "90p": os.path.join(BASE_DIR, "2.90p_ARG_protein_with_label.csv"),
}

OUT_DIR = os.path.join(BASE_DIR, "ARGScope_LongAA_60p_90p_prediction_results")
os.makedirs(OUT_DIR, exist_ok=True)

CHECKPOINT_FILE = os.path.join(MODEL_DIR, "argscope_subtype_longaa_checkpoint.pth")
FEATURE_INFO_FILE = os.path.join(MODEL_DIR, "feature_info.joblib")
LABEL_ENCODER_FILE = os.path.join(MODEL_DIR, "label_encoder.joblib")
SCALER_LONGAA_FILE = os.path.join(MODEL_DIR, "scaler_longaa.joblib")

BATCH_SIZE = 4096
NUM_WORKERS = 0

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# =========================================================
# 2. MODEL DEFINITION
# =========================================================

class LongAAMapper(nn.Module):
    """
    Match checkpoint structure:

    net.0.weight  (1536, 1280)
    net.4.weight  (1024, 1536)
    net.8.weight  (1024, 1024)
    net.12.weight (512, 1024)

    BatchNorm uses track_running_stats=False because checkpoint does not contain:
        running_mean
        running_var
    """

    def __init__(self, input_dim_longaa=1280, proto_dim=512, dropout=0.30):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(input_dim_longaa, 1536),                         # net.0
            nn.BatchNorm1d(1536, track_running_stats=False),           # net.1
            nn.ReLU(inplace=True),                                     # net.2
            nn.Dropout(dropout),                                       # net.3

            nn.Linear(1536, 1024),                                     # net.4
            nn.BatchNorm1d(1024, track_running_stats=False),           # net.5
            nn.ReLU(inplace=True),                                     # net.6
            nn.Dropout(dropout),                                       # net.7

            nn.Linear(1024, 1024),                                     # net.8
            nn.BatchNorm1d(1024, track_running_stats=False),           # net.9
            nn.ReLU(inplace=True),                                     # net.10
            nn.Dropout(dropout),                                       # net.11

            nn.Linear(1024, proto_dim),                                # net.12
        )

    def forward(self, x):
        return self.net(x)


class PrototypeClassifier(nn.Module):
    """
    Match checkpoint structure:

    prototype                  (2825, 512)
    projector.0.weight         (768, 512)
    projector.4.weight         (512, 768)
    projector.8.weight         (512, 512)
    """

    def __init__(self, proto_dim=512, num_classes=2825, scale=30.0, dropout=0.30):
        super().__init__()

        self.prototype = nn.Parameter(torch.randn(num_classes, proto_dim))

        self.projector = nn.Sequential(
            nn.Linear(proto_dim, 768),                                  # projector.0
            nn.BatchNorm1d(768, track_running_stats=False),             # projector.1
            nn.ReLU(inplace=True),                                      # projector.2
            nn.Dropout(dropout),                                        # projector.3

            nn.Linear(768, 512),                                        # projector.4
            nn.BatchNorm1d(512, track_running_stats=False),             # projector.5
            nn.ReLU(inplace=True),                                      # projector.6
            nn.Dropout(dropout),                                        # projector.7

            nn.Linear(512, 512),                                        # projector.8
            nn.BatchNorm1d(512, track_running_stats=False),             # projector.9
            nn.ReLU(inplace=True),                                      # projector.10
        )

        self.scale = float(scale)

    def forward(self, z):
        z = self.projector(z)

        z = F.normalize(z, p=2, dim=1)
        proto = F.normalize(self.prototype, p=2, dim=1)

        logits = self.scale * torch.matmul(z, proto.t())
        return logits


class LongAAOnlyARGScopeModel(nn.Module):
    def __init__(self, input_dim_longaa, proto_dim, num_classes, scale=30.0, dropout=0.30):
        super().__init__()

        self.mapper = LongAAMapper(
            input_dim_longaa=input_dim_longaa,
            proto_dim=proto_dim,
            dropout=dropout,
        )

        self.classifier = PrototypeClassifier(
            proto_dim=proto_dim,
            num_classes=num_classes,
            scale=scale,
            dropout=dropout,
        )

    def forward(self, x_longaa):
        z = self.mapper(x_longaa)
        logits = self.classifier(z)
        return logits


# =========================================================
# 3. DATASET
# =========================================================

class EmbeddingDataset(Dataset):
    def __init__(self, x):
        self.x = torch.tensor(x, dtype=torch.float32)

    def __len__(self):
        return self.x.shape[0]

    def __getitem__(self, idx):
        return self.x[idx]


# =========================================================
# 4. FILE CHECK
# =========================================================

def check_required_files():
    required = [
        CHECKPOINT_FILE,
        FEATURE_INFO_FILE,
        LABEL_ENCODER_FILE,
        SCALER_LONGAA_FILE,
    ]

    print("=" * 80)
    print("Checking required model files")
    print("=" * 80)

    ok = True

    for f in required:
        if os.path.exists(f):
            print("[OK]", f)
        else:
            print("[ERROR missing]", f)
            ok = False

    print()

    for name, f in INPUT_FILES.items():
        if os.path.exists(f):
            print("[OK input]", name, f)
        else:
            print("[ERROR input missing]", name, f)
            ok = False

    print()

    if not ok:
        raise FileNotFoundError("Some required files are missing. Please check paths above.")


# =========================================================
# 5. LABEL AND ID UTILS
# =========================================================

def get_base_id(seq_id):
    """
    Convert expanded ID to original base ID.

    Examples:
        abc_1 -> abc
        abc_2 -> abc
        abc.1 -> abc
        abc-1 -> abc

    Only removes terminal _1/_2/_3/_4/_5, .1/.2/.3/.4/.5, or -1/-2/-3/-4/-5.
    """
    seq_id = str(seq_id)
    return re.sub(r"([_.-][1-5])$", "", seq_id)


def extract_type_from_subtype_label(label):
    label = str(label)

    if "__" in label:
        return label.split("__", 1)[0]

    return "UNKNOWN"


def normalize_true_subtype(row):
    true_type = str(row["Type"])
    true_subtype = str(row["Subtype"])

    if "__" in true_subtype:
        return true_subtype

    return true_type + "__" + true_subtype


# =========================================================
# 6. METRIC UTILS
# =========================================================

def compute_metrics(y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)

    precision_macro, recall_macro, f1_macro, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="macro",
        zero_division=0,
    )

    precision_weighted, recall_weighted, f1_weighted, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="weighted",
        zero_division=0,
    )

    try:
        mcc = matthews_corrcoef(y_true, y_pred)
    except Exception:
        mcc = np.nan

    return {
        "accuracy": acc,
        "macro_precision": precision_macro,
        "macro_recall": recall_macro,
        "macro_f1": f1_macro,
        "weighted_precision": precision_weighted,
        "weighted_recall": recall_weighted,
        "weighted_f1": f1_weighted,
        "mcc": mcc,
    }


def save_classification_report(y_true, y_pred, out_file):
    labels_sorted = sorted(list(set(y_true) | set(y_pred)))

    report_dict = classification_report(
        y_true,
        y_pred,
        labels=labels_sorted,
        output_dict=True,
        zero_division=0,
    )

    report_df = pd.DataFrame(report_dict).T
    report_df.to_csv(out_file, index=True)


# =========================================================
# 7. BASE-ID AGGREGATION
# =========================================================

def majority_vote_with_confidence(group, pred_col, conf_col):
    """
    Majority vote within one base_id group.
    If there is a tie, choose the label with the highest mean confidence.
    """
    tmp = (
        group
        .groupby(pred_col)[conf_col]
        .agg(["count", "mean"])
        .reset_index()
        .sort_values(["count", "mean"], ascending=[False, False])
    )

    return tmp.iloc[0][pred_col]


def first_unique_value(group, col):
    values = group[col].dropna().astype(str).unique()

    if len(values) == 0:
        return "UNKNOWN"

    if len(values) > 1:
        return values[0]

    return values[0]


def aggregate_to_base_id(fragment_df):
    rows = []

    for base_id, group in fragment_df.groupby("base_id", sort=False):
        true_type = first_unique_value(group, "true_type")
        true_subtype = first_unique_value(group, "true_subtype")

        pred_subtype = majority_vote_with_confidence(
            group=group,
            pred_col="pred_subtype",
            conf_col="confidence",
        )

        pred_type = extract_type_from_subtype_label(pred_subtype)

        n_fragments = len(group)
        mean_confidence = group["confidence"].mean()
        max_confidence = group["confidence"].max()

        subtype_vote_count = (group["pred_subtype"] == pred_subtype).sum()
        type_vote_count = (group["pred_type"] == pred_type).sum()

        rows.append({
            "base_id": base_id,
            "n_fragments": n_fragments,
            "true_type": true_type,
            "true_subtype": true_subtype,
            "pred_type": pred_type,
            "pred_subtype": pred_subtype,
            "mean_confidence": mean_confidence,
            "max_confidence": max_confidence,
            "subtype_vote_count": subtype_vote_count,
            "type_vote_count": type_vote_count,
            "correct_type": true_type == pred_type,
            "correct_subtype": true_subtype == pred_subtype,
        })

    return pd.DataFrame(rows)


# =========================================================
# 8. LOAD MODEL
# =========================================================

def load_model(feature_info):
    input_dim_longaa = int(feature_info["input_dim_longaa"])
    proto_dim = int(feature_info["proto_dim"])
    num_classes = int(feature_info["num_classes"])

    ckpt = torch.load(
        CHECKPOINT_FILE,
        map_location="cpu",
        weights_only=False,
    )

    print("Checkpoint keys:", list(ckpt.keys()))
    print()

    if "mapper_state_dict" not in ckpt:
        raise KeyError("mapper_state_dict not found in checkpoint.")

    if "classifier_state_dict" not in ckpt:
        raise KeyError("classifier_state_dict not found in checkpoint.")

    scale = ckpt.get("scale", 30.0)

    print("Checkpoint scale:", scale)
    print("Checkpoint input_dim_longaa:", ckpt.get("input_dim_longaa", "NA"))
    print("Checkpoint proto_dim:", ckpt.get("proto_dim", "NA"))
    print("Checkpoint num_classes:", ckpt.get("num_classes", "NA"))
    print()

    model = LongAAOnlyARGScopeModel(
        input_dim_longaa=input_dim_longaa,
        proto_dim=proto_dim,
        num_classes=num_classes,
        scale=scale,
        dropout=0.30,
    )

    mapper_sd = ckpt["mapper_state_dict"]
    classifier_sd = ckpt["classifier_state_dict"]

    print("Mapper state_dict keys preview:")
    for i, (k, v) in enumerate(mapper_sd.items()):
        if i >= 20:
            break
        if torch.is_tensor(v):
            print(" ", k, tuple(v.shape))
        else:
            print(" ", k, type(v))

    print()

    print("Classifier state_dict keys preview:")
    for i, (k, v) in enumerate(classifier_sd.items()):
        if i >= 20:
            break
        if torch.is_tensor(v):
            print(" ", k, tuple(v.shape))
        else:
            print(" ", k, type(v))

    print()

    model.mapper.load_state_dict(mapper_sd, strict=True)
    print("[OK] mapper_state_dict loaded with strict=True.")

    model.classifier.load_state_dict(classifier_sd, strict=True)
    print("[OK] classifier_state_dict loaded with strict=True.")

    model.to(DEVICE)
    model.eval()

    return model


# =========================================================
# 9. PREDICTION
# =========================================================

def predict_logits(model, x_scaled):
    dataset = EmbeddingDataset(x_scaled)

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=torch.cuda.is_available(),
    )

    pred_indices = []
    pred_probs = []

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE, non_blocking=True)

            # BatchNorm with track_running_stats=False needs batch size > 1.
            # If the final batch has one sample, duplicate it and keep the first result.
            duplicated_single = False
            if batch_x.shape[0] == 1:
                batch_x = torch.cat([batch_x, batch_x], dim=0)
                duplicated_single = True

            logits = model(batch_x)
            probs = torch.softmax(logits, dim=1)

            max_probs, preds = torch.max(probs, dim=1)

            if duplicated_single:
                preds = preds[:1]
                max_probs = max_probs[:1]

            pred_indices.append(preds.cpu().numpy())
            pred_probs.append(max_probs.cpu().numpy())

    pred_indices = np.concatenate(pred_indices)
    pred_probs = np.concatenate(pred_probs)

    return pred_indices, pred_probs


def run_one_file(
    tag,
    input_file,
    model,
    scaler_longaa,
    label_encoder,
    longaa_feature_cols,
):
    print("=" * 80)
    print("Running:", tag)
    print("Input:", input_file)
    print("=" * 80)

    df = pd.read_csv(input_file)
    print("Loaded shape:", df.shape)

    required_base_cols = ["id", "Type", "Subtype"]

    for col in required_base_cols:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    missing_features = [c for c in longaa_feature_cols if c not in df.columns]

    if len(missing_features) > 0:
        raise ValueError(
            f"{tag}: Missing {len(missing_features)} feature columns. "
            f"First missing columns: {missing_features[:20]}"
        )

    print(f"{tag}: using {len(longaa_feature_cols)} LongAA features.")

    x = df[longaa_feature_cols].values.astype(np.float32)
    x_scaled = scaler_longaa.transform(x).astype(np.float32)

    pred_indices, pred_confidence = predict_logits(model, x_scaled)

    pred_subtypes = label_encoder.inverse_transform(pred_indices)
    pred_types = [extract_type_from_subtype_label(x) for x in pred_subtypes]

    true_subtypes = df.apply(normalize_true_subtype, axis=1).astype(str).values
    true_types = df["Type"].astype(str).values

    fragment_df = pd.DataFrame({
        "id": df["id"].astype(str).values,
        "base_id": [get_base_id(x) for x in df["id"].astype(str).values],
        "true_type": true_types,
        "true_subtype": true_subtypes,
        "pred_type": pred_types,
        "pred_subtype": pred_subtypes,
        "confidence": pred_confidence,
        "correct_type": true_types == np.array(pred_types),
        "correct_subtype": true_subtypes == np.array(pred_subtypes),
    })

    # =====================================================
    # Fragment-level output
    # =====================================================

    detail_out = os.path.join(OUT_DIR, f"prediction_detail_{tag}.csv")
    fragment_df.to_csv(detail_out, index=False)
    print("Saved fragment-level detail:", detail_out)

    fragment_subtype_metrics = compute_metrics(
        fragment_df["true_subtype"].values,
        fragment_df["pred_subtype"].values,
    )

    fragment_type_metrics = compute_metrics(
        fragment_df["true_type"].values,
        fragment_df["pred_type"].values,
    )

    fragment_subtype_report_out = os.path.join(
        OUT_DIR,
        f"classification_report_fragment_subtype_{tag}.csv",
    )

    fragment_type_report_out = os.path.join(
        OUT_DIR,
        f"classification_report_fragment_type_{tag}.csv",
    )

    save_classification_report(
        fragment_df["true_subtype"].values,
        fragment_df["pred_subtype"].values,
        fragment_subtype_report_out,
    )

    save_classification_report(
        fragment_df["true_type"].values,
        fragment_df["pred_type"].values,
        fragment_type_report_out,
    )

    print("Saved fragment-level subtype report:", fragment_subtype_report_out)
    print("Saved fragment-level type report:", fragment_type_report_out)

    # =====================================================
    # Base-ID-level output
    # =====================================================

    base_df = aggregate_to_base_id(fragment_df)

    base_out = os.path.join(OUT_DIR, f"prediction_baseid_{tag}.csv")
    base_df.to_csv(base_out, index=False)
    print("Saved base-ID-level detail:", base_out)

    base_subtype_metrics = compute_metrics(
        base_df["true_subtype"].values,
        base_df["pred_subtype"].values,
    )

    base_type_metrics = compute_metrics(
        base_df["true_type"].values,
        base_df["pred_type"].values,
    )

    base_subtype_report_out = os.path.join(
        OUT_DIR,
        f"classification_report_baseid_subtype_{tag}.csv",
    )

    base_type_report_out = os.path.join(
        OUT_DIR,
        f"classification_report_baseid_type_{tag}.csv",
    )

    save_classification_report(
        base_df["true_subtype"].values,
        base_df["pred_subtype"].values,
        base_subtype_report_out,
    )

    save_classification_report(
        base_df["true_type"].values,
        base_df["pred_type"].values,
        base_type_report_out,
    )

    print("Saved base-ID-level subtype report:", base_subtype_report_out)
    print("Saved base-ID-level type report:", base_type_report_out)

    # =====================================================
    # Summary row
    # =====================================================

    summary_row = {
        "dataset": tag,
        "n_fragments": len(fragment_df),
        "n_base_ids": len(base_df),
        "mean_fragments_per_base_id": round(len(fragment_df) / max(len(base_df), 1), 4),
    }

    for k, v in fragment_subtype_metrics.items():
        summary_row[f"fragment_subtype_{k}"] = v

    for k, v in fragment_type_metrics.items():
        summary_row[f"fragment_type_{k}"] = v

    for k, v in base_subtype_metrics.items():
        summary_row[f"baseid_subtype_{k}"] = v

    for k, v in base_type_metrics.items():
        summary_row[f"baseid_type_{k}"] = v

    print()
    print("Fragment-level subtype metrics:")
    for k, v in fragment_subtype_metrics.items():
        print(f"  {k}: {v:.4f}")

    print("Fragment-level type metrics:")
    for k, v in fragment_type_metrics.items():
        print(f"  {k}: {v:.4f}")

    print("Base-ID-level subtype metrics:")
    for k, v in base_subtype_metrics.items():
        print(f"  {k}: {v:.4f}")

    print("Base-ID-level type metrics:")
    for k, v in base_type_metrics.items():
        print(f"  {k}: {v:.4f}")

    print()

    del df, x, x_scaled, fragment_df, base_df
    gc.collect()

    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return summary_row


# =========================================================
# 10. MAIN
# =========================================================

def main():
    print("=" * 80)
    print("ARGScope LongAA batch prediction")
    print("=" * 80)
    print("BASE_DIR:", BASE_DIR)
    print("OUT_DIR:", OUT_DIR)
    print("DEVICE:", DEVICE)
    print()

    check_required_files()

    print("=" * 80)
    print("Loading saved objects")
    print("=" * 80)

    feature_info = joblib.load(FEATURE_INFO_FILE)
    label_encoder = joblib.load(LABEL_ENCODER_FILE)
    scaler_longaa = joblib.load(SCALER_LONGAA_FILE)

    longaa_feature_cols = feature_info["longaa_feature_cols"]

    print("input_dim_longaa:", feature_info["input_dim_longaa"])
    print("Number of longaa_feature_cols:", len(longaa_feature_cols))
    print("num_classes:", feature_info["num_classes"])
    print("label_encoder classes:", len(label_encoder.classes_))
    print("scaler_longaa.n_features_in_:", scaler_longaa.n_features_in_)
    print()

    if len(longaa_feature_cols) != scaler_longaa.n_features_in_:
        raise ValueError(
            "Feature column number does not match scaler_longaa.n_features_in_."
        )

    if int(feature_info["num_classes"]) != len(label_encoder.classes_):
        raise ValueError(
            "feature_info num_classes does not match label_encoder classes."
        )

    model = load_model(feature_info)

    all_summary = []

    for tag, input_file in INPUT_FILES.items():
        row = run_one_file(
            tag=tag,
            input_file=input_file,
            model=model,
            scaler_longaa=scaler_longaa,
            label_encoder=label_encoder,
            longaa_feature_cols=longaa_feature_cols,
        )

        all_summary.append(row)

    summary_df = pd.DataFrame(all_summary)

    metric_cols = [
        c for c in summary_df.columns
        if c not in ["dataset", "n_fragments", "n_base_ids"]
    ]

    for c in metric_cols:
        summary_df[c] = summary_df[c].astype(float).round(4)

    summary_out = os.path.join(OUT_DIR, "summary_metrics_all.csv")
    summary_df.to_csv(summary_out, index=False)

    print("=" * 80)
    print("All finished")
    print("=" * 80)
    print("Saved summary:", summary_out)
    print()
    print(summary_df)


if __name__ == "__main__":
    main()