"""Label-safe replacements only. Preserve all reviewed metrics and styling."""
from pathlib import Path
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.transforms import Bbox
from matplotlib.patches import Patch
from matplotlib.text import Text
import numpy as np
import plot_argscope_subtype_replacement as source

OUT=source.HERE/'outputs/argscope_subtype_argonly_20260922/bar_labels_fixed'
DEST=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\Figure2_Figure3_柱状图文字修正版_20260922')
EDEST=source.RESULTS/'Subtype_ARGonly_20260922/bar_labels_fixed'


def draw(row):
    values=row[source.FIELDS].to_numpy(dtype=float)
    fig,ax=plt.subplots(figsize=(4.6,4.0))
    fig.patch.set_alpha(0)
    ax.set_facecolor('none')
    # Keep almost exactly the previous plotted height while reserving label room.
    fig.subplots_adjust(left=.145,right=.980,bottom=.225,top=.900)
    x=np.arange(5)
    bars=ax.bar(x,values,width=.44,color=source.COLORS[row.Modality],edgecolor=source.EDGE,
                linewidth=.65,hatch=source.HATCHES[row.Modality],zorder=3)
    ax.set_xlim(-.58,4.58)
    ax.set_ylim(0,1.055)
    ax.set_xticks(x,source.XLABELS,fontsize=11)
    ax.set_yticks(np.linspace(0,1,6),[f'{v:.1f}' for v in np.linspace(0,1,6)])
    ax.set_ylabel('Score',fontsize=12,labelpad=6)
    ax.tick_params(axis='x',length=0,pad=7)
    ax.tick_params(axis='y',length=3.2,width=.7,labelsize=10.5)
    ax.set_axisbelow(True)
    ax.grid(axis='y',color='#E9EDF0',linewidth=.65)
    ax.spines[['top','right']].set_visible(False)
    for side in ['left','bottom']:
        ax.spines[side].set_linewidth(.75)
        ax.spines[side].set_color('#626B70')
    for bar,value in zip(bars,values):
        assert bar.get_height()==value
        ax.text(bar.get_x()+bar.get_width()/2,value+.018,f'{value:.4f}',
                ha='center',va='bottom',fontsize=10,color='#30383D',clip_on=False)
    ax.legend(handles=[Patch(facecolor=source.COLORS[row.Modality],edgecolor=source.EDGE,
                             linewidth=.65,hatch=source.HATCHES[row.Modality],label=source.NAMES[row.Modality])],
              loc='lower center',bbox_to_anchor=(.5,1.005),frameon=False,fontsize=11.5,
              handlelength=1.7,handletextpad=.6,borderaxespad=0)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    tight=fig.get_tightbbox(renderer)
    # 2.54 mm below complete glyphs. Keep an origin-zero SVG for importers.
    crop=Bbox.from_extents(tight.x0-.02,tight.y0-.10,tight.x1+.02,tight.y1+.02)
    for artist in fig.findobj(match=Text):
        if artist.get_visible() and artist.get_text():
            assert artist.get_fontfamily()==['Arial']
            bb=artist.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())
            assert bb.x0>=crop.x0 and bb.x1<=crop.x1 and bb.y0>=crop.y0 and bb.y1<=crop.y1
    n=2 if row.Modality=='Protein' else 3
    stem=f'Figure{n}B_{row.Modality}_Subtype_labels_fixed'
    for fonttype,folder in [('path',OUT),('none',OUT/'editable_text')]:
        folder.mkdir(parents=True,exist_ok=True)
        with plt.rc_context({'svg.fonttype':fonttype}):
            fig.savefig(folder/f'{stem}.svg',transparent=True,facecolor='none',edgecolor='none',bbox_inches=crop)
        svg=ET.parse(folder/f'{stem}.svg').getroot()
        assert [float(v) for v in svg.attrib['viewBox'].split()][:2]==[0,0]
        assert not svg.findall('.//{http://www.w3.org/2000/svg}image')
        if fonttype=='path':
            assert not svg.findall('.//{http://www.w3.org/2000/svg}text')
        else:
            texts=[t.text for t in svg.findall('.//{http://www.w3.org/2000/svg}text')]
            assert 'precision' in texts and 'recall' in texts
    fig.savefig(OUT/f'{stem}.png',dpi=300,transparent=True,facecolor='none',edgecolor='none',bbox_inches=crop)
    plt.close(fig)
    return dict(file=f'{stem}.svg',modality=row.Modality,values=dict(zip(source.FIELDS,values.tolist())),
                values_unchanged=True,font='Arial',label_bottom_clearance_pt=7.2,
                transparent=True,main_svg_text_outlined=True,editable_text_alternative=True,viewbox_origin=[0,0])


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'Arial','font.size':11,'text.color':'#30383D',
                         'axes.labelcolor':'#30383D','xtick.color':'#30383D','ytick.color':'#30383D',
                         'hatch.linewidth':.40,'savefig.bbox':None,'pdf.fonttype':42})
    rows=source.reviewed_rows()
    results=[draw(rows[rows.Modality.eq(m)].iloc[0]) for m in ['Protein','DNA']]
    (OUT/'verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    for dest in [DEST,EDEST]:
        shutil.copytree(OUT,dest,dirs_exist_ok=True)
    print(json.dumps(results,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
