#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reference-style independent panels. No UMAP and no changes to source results."""
import argparse
import csv
import hashlib
import json
import textwrap
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator, PercentFormatter, FormatStrFormatter
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASELINES = Path(r"E:\1. ARGmodel\1. NonARG_training\Type_level_performance")
BAR_ROOT = BASELINES.parent / "柱状图结果/柱状图结果"
ORDER = ["beta_lactam", "trimethoprim", "macrolide-lincosamide-streptogramin", "fusidic_acid",
         "fosfomycin", "aminoglycoside", "quinolone", "multidrug", "vancomycin", "chloramphenicol",
         "florfenicol", "rifamycin", "tetracycline", "other_peptide_antibiotics", "bacitracin",
         "sulfonamide", "tetracenomycin_C", "novobiocin", "tunicamycin", "streptothricin",
         "polymyxin", "bleomycin", "puromycin"]
DISPLAY = dict(zip(ORDER, ["Beta-lactams", "Trimethoprim", "MLS", "Fusidic acid", "Fosfomycin",
                          "Aminoglycosides", "Quinolones", "Multidrug", "Vancomycin", "Chloramphenicol",
                          "Florfenicol", "Rifamycin", "Tetracyclines", "Other peptides", "Bacitracin",
                          "Sulfonamide", "Tetracenomycin C", "Novobiocin", "Tunicamycin", "Streptothricin",
                          "Polymyxin", "Bleomycin", "Puromycin"]))
ALIASES = {"MLS": "macrolide-lincosamide-streptogramin"}
MODELS = {"protein": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
          "dna": ["ARGNet", "DeepARG", "ARGScope"]}
CMAPS = {"protein": LinearSegmentedColormap.from_list("protein_blue", ["#fbfdff", "#cde4f4", "#67a8d1", "#175480", "#092b50"]),
         "dna": LinearSegmentedColormap.from_list("dna_orange", ["#fffdf9", "#fde1bc", "#f7b16e", "#d97932", "#844315"])}
TYPE_CORRECT, TYPE_WRONG = "#319b89", "#df7858"
plt.rcParams.update({"font.family": "Arial", "font.size": 8, "axes.titlesize": 10,
                     "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
                     "axes.linewidth": .6, "pdf.fonttype": 42, "ps.fonttype": 42,
                     "svg.fonttype": "none", "figure.facecolor": "white", "axes.unicode_minus": False})
SOURCES, PANELS, QA = {}, [], []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    SOURCES[str(path)] = digest(path)
    return pd.read_csv(path, keep_default_na=False)


def save(fig, target, panel, modality, pct, note):
    target.parent.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    for ext in ("png", "svg", "pdf"):
        fig.savefig(target.with_suffix("." + ext), dpi=600 if ext == "png" else 150,
                    bbox_inches="tight", pad_inches=.055, facecolor="white")
    # A low-resolution copy is for inspection only; the user images are 600 dpi.
    preview = HERE / "_visual_QA" / target.relative_to(HERE).with_suffix(".png")
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview, dpi=150, bbox_inches="tight", pad_inches=.055, facecolor="white")
    PANELS.append({"panel": panel, "modality": modality, "completeness_percent": pct,
                   "PNG": str(target.with_suffix(".png").relative_to(HERE)), "note": note})
    plt.close(fig)


def predictions(modality, pct):
    name = "100%_test_sequence_predictions.csv" if pct == 100 else f"{pct}%_fragment_predictions_test.csv"
    data = read(ROOT / modality / name)
    if data.sequence_id.duplicated().any() or set(data.true_type) != set(ORDER) | {"nonARG"}:
        raise ValueError("Wrong population or duplicate sequence IDs")
    if len(data) != (4574 if pct == 100 else 22870) or set(data.split) != {"test"}:
        raise ValueError("Wrong new test-set count")
    return data


def matrices(data, modality, pct):
    # Retain nonARG during counting. Only its display row/column is omitted.
    all_labels = ORDER + ["nonARG"]
    full = confusion_matrix(data.true_type, data.predicted_type, labels=all_labels)
    if full.sum() != len(data):
        raise ValueError("Unmapped confusion-matrix labels")
    counts = full[:-1, :-1]
    support = full[:-1].sum(axis=1)
    normalized = counts / support[:, None]
    error_counts = counts.copy()
    np.fill_diagonal(error_counts, 0)
    misses = int(full[:-1, -1].sum())
    false_positives = int(full[-1, :-1].sum())
    out = HERE / modality.title() / f"{pct}pct"
    table = HERE / "data" / modality / f"{pct}pct"
    table.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(full, index=all_labels, columns=all_labels).to_csv(table / "full_confusion_counts_audit.csv", encoding="utf-8-sig", index_label="true_type")
    pd.DataFrame(normalized, index=ORDER, columns=ORDER).to_csv(table / "D_row_normalized_23types.csv", encoding="utf-8-sig", index_label="true_type")
    pd.DataFrame(error_counts, index=ORDER, columns=ORDER).to_csv(table / "E_off_diagonal_counts_23types.csv", encoding="utf-8-sig", index_label="true_type")
    for key, array, title, vmax, colorbar_title in (
            ("D", normalized, "Type confusion matrix", 1, "Fraction of true Type"),
            ("E", error_counts.astype(float), "Type misclassification counts", max(1, int(error_counts.max())), "Count")):
        fig, ax = plt.subplots(figsize=(5.4, 5.1))
        fig.subplots_adjust(left=.265, bottom=.26, right=.89, top=.905)
        cmap = CMAPS[modality].copy()
        if key == "E":
            array = np.ma.array(array, mask=np.eye(len(ORDER), dtype=bool))
            cmap.set_bad("#eeeeee")
        image = ax.imshow(array, cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest", aspect="equal")
        ax.set_xticks(range(23), [DISPLAY[t] for t in ORDER], rotation=58, ha="right", rotation_mode="anchor")
        ax.set_yticks(range(23), [DISPLAY[t] for t in ORDER])
        ax.tick_params(length=2, pad=2, labelsize=6.5)
        ax.set_xlabel("Predicted Type", labelpad=6)
        ax.set_ylabel("True Type", labelpad=5)
        ax.set_title(title, pad=9)
        cax = fig.add_axes([.91, .305, .022, .53])
        cb = fig.colorbar(image, cax=cax)
        cb.set_label(colorbar_title, fontsize=7)
        cb.ax.tick_params(labelsize=6.5, length=2)
        if key == "D":
            cb.ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
        else:
            cb.locator = MaxNLocator(nbins=5, integer=True)
            cb.update_ticks()
        fig.text(.5, .985, f"{modality.title() if modality == 'protein' else 'DNA'}, {pct}% completeness", ha="center", va="top", fontsize=8)
        save(fig, out / f"{key}_{modality}_{pct}pct_23types", key, modality, pct,
             "Only 23 ARG Types displayed; row denominator includes nonARG outcomes. NonARG rows are not displayed.")
    QA.append({"modality": modality, "pct": pct, "n_all": len(data), "n_ARG": int(support.sum()),
               "type_correct_ARG": int(np.trace(counts)), "type_cross_errors_ARG": int(error_counts.sum()),
               "ARG_to_nonARG": misses, "nonARG_to_ARG": false_positives,
               "full_accuracy": float(np.trace(full) / full.sum())})
    if np.trace(counts) + error_counts.sum() + misses != support.sum():
        raise ValueError("Type error decomposition does not reconcile")


def short_subtype(value):
    return value.split("__", 1)[1] if "__" in value else value


def errors(data, modality, pct):
    # True nonARG examples are omitted. nonARG remains a possible wrong outcome.
    errors = data[(data.true_type.isin(ORDER)) & (data.true_subtype != data.predicted_subtype)].copy()
    errors["type_correct"] = errors.true_type == errors.predicted_type
    grouped = errors.groupby(["true_subtype", "predicted_subtype", "true_type", "predicted_type"], as_index=False).agg(
        Count=("sequence_id", "size"), Type_correct_count=("type_correct", "sum"))
    grouped["Type_correct_percent"] = 100 * grouped.Type_correct_count / grouped.Count
    grouped = grouped.sort_values(["Count", "true_subtype", "predicted_subtype"], ascending=[False, True, True])
    folder = HERE / "data" / modality / f"{pct}pct"
    grouped.to_csv(folder / "F_all_subtype_error_pairs.csv", index=False, encoding="utf-8-sig")
    show = grouped.head(20).copy()
    show.to_csv(folder / "F_displayed_top20.csv", index=False, encoding="utf-8-sig")
    labels = [textwrap.fill(f"{short_subtype(r.true_subtype)} → {short_subtype(r.predicted_subtype)}", 43,
                           break_long_words=True, break_on_hyphens=False) for r in show.itertuples()]
    fig, ax = plt.subplots(figsize=(6.25, max(4.6, .20 * sum(label.count('\n') + 1 for label in labels) + 1.85)))
    fig.subplots_adjust(left=.46, right=.97, top=.90, bottom=.23)
    y = np.arange(len(show))
    colors = [TYPE_CORRECT if r.Type_correct_percent == 100 else TYPE_WRONG for r in show.itertuples()]
    bars = ax.barh(y, show.Count, color=colors, height=.70, edgecolor="#444444", linewidth=.35)
    for bar, row in zip(bars, show.itertuples()):
        if row.Type_correct_percent != 100:
            bar.set_hatch("///")
        ax.text(bar.get_width() + max(show.Count) * .025, bar.get_y() + bar.get_height()/2,
                f"{row.Count} ({row.Type_correct_percent:.0f}%)", va="center", fontsize=6.8)
    ax.set_yticks(y, labels, fontsize=6.8)
    ax.invert_yaxis()
    ax.set_xlim(0, max(show.Count) * 1.40)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
    ax.set_xlabel("Count")
    ax.set_title("Most frequent subtype errors", pad=9)
    ax.spines[["right", "top"]].set_visible(False)
    ax.grid(axis="x", color="#e8e8e8", linewidth=.4)
    ax.set_axisbelow(True)
    legend = [Patch(facecolor=TYPE_CORRECT, edgecolor="#444444", linewidth=.35, label="Subtype wrong, Type correct"),
              Patch(facecolor=TYPE_WRONG, edgecolor="#444444", linewidth=.35, hatch="///", label="Subtype wrong, Type incorrect")]
    fig.legend(handles=legend, loc="lower right", bbox_to_anchor=(.98, .068), frameon=False, fontsize=7)
    fig.text(.5, .975, f"{modality.title() if modality == 'protein' else 'DNA'}, {pct}% completeness", ha="center", va="top", fontsize=8)
    save(fig, HERE / modality.title() / f"{pct}pct" / f"F_{modality}_{pct}pct_subtype_errors", "F", modality, pct,
         "True ARG from the 23 Types only; nonARG may appear as a wrong prediction, not as a true Type.")


def baseline_path(model, modality, pct):
    if model == "ARGNet":
        return (BASELINES / "ARGnet/ARGnet_LongAA_Type_level_performance" / f"protein_{pct}pct_argnet-l_classification_report_fixed18.csv"
                if modality == "protein" else BASELINES / "ARGnet/ARGnet_LongNT_Type_level_performance" / ("100pct_type_metrics_simple.csv" if pct == 100 else f"{pct}pct_5parts_type_metrics_simple.csv"))
    if model == "DeepARG":
        return BASELINES / "DeepARG" / ("DeepARG_LongAA_Type_level_performance" if modality == "protein" else "DeepARG_LongNT_Type_level_performance") / f"deeparg_type_{modality}_{'all' if pct == 100 else str(pct)+'pct'}_classification_report.csv"
    if model == "FunGeneTyper":
        return BASELINES / "Fungentyper/Fungenetyper_LongAA_results" / f"{pct}p_type_classification_report.csv"
    if model == "PLM-ARG":
        return BASELINES / "PLM_ARG/PLMARG_5conditions_perType_metrics" / f"{pct}p_perType_metrics_ARG_only.csv"
    raise ValueError(model)


def heatmaps(modality, pct):
    models = MODELS[modality]
    mapped, audit = {}, []
    for model in models:
        if model == "ARGScope":
            path = ROOT / "metrics/04_Per_type_five_metrics.csv"
            df = read(path)
            df = df[(df.Modality == ("Protein" if modality == "protein" else "DNA")) & (df.Completeness_percent == pct)]
        else:
            path = baseline_path(model, modality, pct)
            df = read(path)
        columns = {str(k).lower(): k for k in df.columns}
        type_col = columns["type"]
        lookup = {}
        for row in df.to_dict("records"):
            canonical = ALIASES.get(row[type_col], row[type_col])
            if canonical not in ORDER:
                continue
            if canonical in lookup:
                raise ValueError(f"Duplicate canonical Type: {path} / {canonical}")
            values = {}
            for metric in ("Precision", "Recall", "F1"):
                value = row[columns[metric.lower()]]
                values[metric] = float(value) if str(value).strip() not in ("", "NA", "NaN", "nan") else np.nan
                if not np.isnan(values[metric]) and not 0 <= values[metric] <= 1:
                    raise ValueError("Metric outside [0,1]")
            lookup[canonical] = values
        mapped[model] = lookup
        audit.append({"Model": model, "modality": modality, "pct": pct, "source": str(path),
                      "available_requested_types": len(lookup), "missing_requested_types": ";".join(t for t in ORDER if t not in lookup),
                      "population": "new_test" if model == "ARGScope" else "source_provided_baseline_population_not_matched"})
    pd.DataFrame(audit).to_csv(HERE / "data" / modality / f"{pct}pct" / "B_sources.csv", index=False, encoding="utf-8-sig")
    for metric in ("Precision", "Recall", "F1"):
        array = np.array([[mapped[m].get(t, {}).get(metric, np.nan) for m in models] for t in ORDER])
        data_folder = HERE / "data" / modality / f"{pct}pct"
        # Keep the unmodified source scores, including missingness, for traceability.
        pd.DataFrame(array, index=ORDER, columns=models).to_csv(
            data_folder / f"B_{metric}_source_values.csv", encoding="utf-8-sig", index_label="Type")
        other_columns = [i for i, model in enumerate(models) if model != "ARGScope"]
        other_scores = array[:, other_columns]
        keep = np.any(np.isfinite(other_scores) & (other_scores != 0), axis=1)
        kept_types = [typ for typ, kept in zip(ORDER, keep) if kept]
        if not kept_types:
            raise ValueError(f"No Type has a nonzero reference-model score: {modality}, {pct}%, {metric}")
        # Explicit user-selected display convention; these are not measured zeros.
        displayed = np.nan_to_num(array[keep], nan=0.0)
        matrix = np.vstack([displayed.mean(axis=0), displayed])
        n_types, n_rows = len(kept_types), len(kept_types) + 1
        pd.DataFrame(matrix, index=[f"Average_{n_types}_types"] + kept_types, columns=models).to_csv(
            data_folder / f"B_{metric}_values.csv", encoding="utf-8-sig", index_label="Type")
        pd.DataFrame([{
            "Type": typ, "Display": DISPLAY[typ], "kept": bool(keep[i]),
            "reference_nonzero_count": int(np.count_nonzero(np.isfinite(other_scores[i]) & (other_scores[i] != 0))),
            "source_missing_cells": int(np.isnan(array[i]).sum()),
            "missing_cells_displayed_as_zero": int(np.isnan(array[i]).sum()) if keep[i] else 0,
            "reason": "nonzero_reference_score" if keep[i] else "all_reference_scores_zero_or_missing",
        } for i, typ in enumerate(ORDER)]).to_csv(
            data_folder / f"B_{metric}_row_filter_audit.csv", index=False, encoding="utf-8-sig")
        fig, ax = plt.subplots(figsize=(4.15 if modality == "protein" else 3.65, 5.65))
        fig.subplots_adjust(left=.37 if modality == "protein" else .42, right=.88, bottom=.22, top=.895)
        # Two aligned axes create a genuine blank gap, not a fake data row.
        heatmap_bounds = ax.get_position().frozen()
        gap_in_rows = .65
        cell_height = heatmap_bounds.height / (n_rows + gap_in_rows)
        ax.set_position([heatmap_bounds.x0, heatmap_bounds.y0, heatmap_bounds.width, n_types * cell_height])
        average_ax = fig.add_axes([heatmap_bounds.x0, heatmap_bounds.y1 - cell_height,
                                   heatmap_bounds.width, cell_height])
        cmap = CMAPS[modality].copy()
        im = ax.imshow(displayed, cmap=cmap, vmin=0, vmax=1, aspect="auto", interpolation="nearest")
        average_ax.imshow(matrix[:1], cmap=cmap, vmin=0, vmax=1, aspect="auto", interpolation="nearest")
        ax.set_xticks(range(len(models)), models, rotation=53, ha="right", rotation_mode="anchor")
        ax.set_yticks(range(n_types), [DISPLAY[t] for t in kept_types], fontsize=7)
        average_ax.set_xticks([])
        average_ax.set_yticks([0], ["Average"], fontsize=7)
        average_ax.set_title(metric, pad=9)
        for i in range(n_rows):
            target_ax, y = (average_ax, 0) if i == 0 else (ax, i - 1)
            for j in range(len(models)):
                value = matrix[i, j]
                target_ax.text(j, y, f"{value:.4f}", ha="center", va="center",
                               fontsize=5.9, color="white" if value > .62 else "#222222",
                               gid=f"heatmap-value-{i}-{j}")
        for target_ax, rows_on_axis in ((ax, n_types), (average_ax, 1)):
            target_ax.tick_params(length=0, pad=3)
            target_ax.set_xticks(np.arange(-.5, len(models), 1), minor=True)
            target_ax.set_yticks(np.arange(-.5, rows_on_axis, 1), minor=True)
            target_ax.grid(which="minor", color="white", linewidth=.5)
            target_ax.tick_params(which="minor", length=0)
        for tick in ax.get_xticklabels():
            if tick.get_text() == "ARGScope":
                tick.set_color("#b64b3a")
                tick.set_fontweight("bold")
        cax = fig.add_axes([heatmap_bounds.x1 + .03, heatmap_bounds.y0, .025, heatmap_bounds.height])
        cb = fig.colorbar(im, cax=cax, ticks=[0, .25, .5, .75, 1])
        cb.ax.yaxis.set_major_formatter(FormatStrFormatter("%.4f"))
        cb.ax.tick_params(labelsize=6, length=2)
        fig.text(.57, .965, f"{modality.title() if modality == 'protein' else 'DNA'}, {pct}% completeness", ha="center", va="top", fontsize=8)
        fig.canvas.draw()
        colorbar_bounds = cax.get_position()
        average_bounds, type_bounds = average_ax.get_position(), ax.get_position()
        policy = {
            "candidate_types": 23, "displayed_type_count": n_types,
            "retained_types": kept_types, "removed_types": [typ for typ, kept in zip(ORDER, keep) if not kept],
            "filter": "Per metric: remove Type if every non-ARGScope score is missing or exactly zero",
            "missing_display_rule": "Replace missing scores in retained rows with zero for display only",
            "missing_cells_displayed_as_zero": int(np.isnan(array[keep]).sum()),
            "average": "Unweighted mean of displayed retained Types after missing-to-zero substitution",
            "average_label": "Average", "value_unit": "fraction", "annotation_decimal_places": 4,
            "average_gap_in_row_heights": gap_in_rows,
            "average_y_bounds": [average_bounds.y0, average_bounds.y1],
            "type_y_bounds": [type_bounds.y0, type_bounds.y1],
            "heatmap_y_bounds": [heatmap_bounds.y0, heatmap_bounds.y1],
            "colorbar_y_bounds": [colorbar_bounds.y0, colorbar_bounds.y1],
        }
        (data_folder / f"B_{metric}_display_policy.json").write_text(
            json.dumps(policy, indent=2, ensure_ascii=False), encoding="utf-8")
        save(fig, HERE / modality.title() / f"{pct}pct" / f"B_{modality}_{pct}pct_{metric}_23types", "B_"+metric, modality, pct,
             f"Source populations are not aligned. {n_types} of 23 candidate Types retained by reference-model nonzero rule; missing displayed as zero; Average over displayed Types.")


def overall_bars(modality, pct):
    metric_names = ["Accuracy", "Precision", "Recall", "F1", "MCC"]
    model_colors = {"ARGNet": "#e9e2d1", "DeepARG": "#eb8069", "PLM-ARG": "#858585",
                    "FunGeneTyper": "#78aacf", "ARGScope": "#88c1a5"}
    directories = {"ARGNet": ("argnet", "ARGnet"), "DeepARG": ("DeepARG", "DeepARG"),
                   "PLM-ARG": ("PLM-ARG", "PLMARG"), "FunGeneTyper": ("Fungenetyper", "Fungenetyper")}
    rows = []
    for model in MODELS[modality]:
        if model == "ARGScope":
            path = ROOT / "metrics/02_Type_overall_macro_weighted_micro.csv"
            df = read(path)
            pick = df[(df.Modality == ("Protein" if modality == "protein" else "DNA")) &
                      (df.Completeness_percent == pct) & (df.Average == "weighted")]
            definition = "new test; all samples incl nonARG; global Accuracy/MCC, weighted Precision/Recall/F1"
        else:
            mode = "longaa" if modality == "protein" else "longnt"
            directory, prefix = directories[model]
            path = BAR_ROOT / mode / directory / f"{prefix}_{mode}.csv"
            df = read(path)
            condition = df.iloc[:, 0].astype(str).str.strip()
            pick = df[condition.str.startswith("Long") if pct == 100 else condition.eq(f"{pct}%")]
            definition = "original reference-figure summary; original model-specific aggregation retained"
        if len(pick) != 1:
            raise ValueError(f"Ambiguous overall source: {path} / {pct}%")
        selected = pick.iloc[0]
        values = {metric: float(selected["ACC" if metric == "Accuracy" and "ACC" in selected else metric]) for metric in metric_names}
        if any(not np.isfinite(v) or not (-1 if k == "MCC" else 0) <= v <= 1 for k, v in values.items()):
            raise ValueError("Invalid overall score")
        rows.append({"Model": model, "modality": modality, "pct": pct, **values,
                     "source": str(path), "definition": definition})
    pd.DataFrame(rows).to_csv(HERE / "data" / modality / f"{pct}pct" / "A_overall_values_and_sources.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(5.4, 3.55))
    fig.subplots_adjust(left=.12, right=.99, bottom=.19, top=.80)
    x = np.arange(5)
    width = .80 / len(rows)
    for index, row in enumerate(rows):
        ax.bar(x + (index - (len(rows)-1)/2) * width, [row[k] for k in metric_names],
               width=width*.94, color=model_colors[row["Model"]], edgecolor="#666666", linewidth=.55, label=row["Model"])
    ax.set_xticks(x, metric_names, fontsize=8)
    lower = min(0, min(row[k] for row in rows for k in metric_names))
    ax.set_ylim(lower - .05 if lower < 0 else 0, 1.055)
    ax.set_yticks(np.arange(0, 1.01, .2))
    ax.set_ylabel("Score")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e7e7e7", linewidth=.45)
    ax.set_axisbelow(True)
    ax.legend(loc="lower center", bbox_to_anchor=(.5, 1.045), ncol=len(rows), frameon=False,
              fontsize=6.8, handlelength=1.2, handletextpad=.35, columnspacing=.9)
    fig.text(.56, .97, f"{modality.title() if modality == 'protein' else 'DNA'}, {pct}% completeness", ha="center", va="top", fontsize=8)
    save(fig, HERE / modality.title() / f"{pct}pct" / f"A_{modality}_{pct}pct_overall_comparison", "A", modality, pct,
         "Original baseline figure summaries unchanged. ARGScope uses latest global Accuracy/MCC and weighted P/R/F1 including nonARG. Not a matched-test benchmark.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--percentages", nargs="+", type=int, default=[100, 60, 70, 80, 90])
    parser.add_argument("--only", nargs="+", choices=["A", "B", "D", "E", "F"], default=["A", "B", "D", "E", "F"])
    args = parser.parse_args()
    if (HERE / "PANEL_INDEX.csv").exists():
        existing = pd.read_csv(HERE / "PANEL_INDEX.csv").to_dict("records")
        PANELS.extend(row for row in existing if row["panel"].split("_")[0] not in args.only or row["completeness_percent"] not in args.percentages)
        SOURCES.update(json.loads((HERE / "PLOT_MANIFEST.json").read_text(encoding="utf-8"))["sources_sha256"])
    for modality in ("protein", "dna"):
        for pct in args.percentages:
            folder = HERE / "data" / modality / f"{pct}pct"
            folder.mkdir(parents=True, exist_ok=True)
            if any(panel in args.only for panel in ("D", "E", "F")):
                data = predictions(modality, pct)
                if any(panel in args.only for panel in ("D", "E")):
                    matrices(data, modality, pct)
                if "F" in args.only:
                    errors(data, modality, pct)
            if "B" in args.only:
                heatmaps(modality, pct)
            if "A" in args.only:
                overall_bars(modality, pct)
            print(f"DONE {modality} {pct}%: {args.only}", flush=True)
    pd.DataFrame(PANELS).to_csv(HERE / "PANEL_INDEX.csv", index=False, encoding="utf-8-sig")
    if QA:
        pd.DataFrame(QA).to_csv(HERE / "data/ARGScope_population_and_error_audit.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([{"Type": t, "Display": DISPLAY[t]} for t in ORDER]).to_csv(HERE / "data/type_display_mapping.csv", index=False, encoding="utf-8-sig")
    manifest = {"status": "A_B_D_E_F_created", "UMAP_generated": False, "type_count": 23,
                "sources_sha256": SOURCES, "panel_count": len(PANELS), "formats": ["600dpi PNG", "SVG", "PDF"],
                "A_overall_comparison": "Existing reference-figure baseline values; latest ARGScope Type weighted metrics. No per-Type ACC/MCC averaging.",
                "B_warning": "Baseline and ARGScope populations differ; caveats preserved in README and PANEL_INDEX rather than image footers.",
                "image_text_policy": "No panel-letter labels or bottom explanatory footnotes; retain titles, axes, legends and numeric annotations. See README, PANEL_INDEX and data for scope/denominator/missing-value notes.",
                "B_display_policy": "Per metric, drop Types whose non-ARGScope scores are all missing or zero; remaining missing scores displayed as zero; Average recomputed across retained Types. Source values preserved separately.",
                "D_denominator": "All true ARG sequences of each Type, including predictions of nonARG",
                "F_population": "True ARG only; nonARG is retained as a possible wrong prediction"}
    (HERE / "PLOT_MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
