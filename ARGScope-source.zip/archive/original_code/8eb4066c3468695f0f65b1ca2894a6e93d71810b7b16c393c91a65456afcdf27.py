"""Non-mutating ID and exact-sequence overlap audit of the saved ablation splits."""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

B = Path(r"E:\1. ARGmodel\1. NonARG_training")
ROOT = B / "new model result8.24" / "1.training dataset"
RESULTS = ROOT / "消融实验结果"
OUT = Path(__file__).resolve().parent / "outputs" / "ablation_split_audit"


def read_ids(path):
    return [s.strip() for s in path.read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def read_rows(path, sep=","):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return [{k.lower(): v for k, v in r.items()} for r in csv.DictReader(f, delimiter=sep)]


def fasta_hashes(path):
    hashes, lengths = {}, {}
    sid, chunks = None, []

    def flush():
        if sid is None:
            return
        seq = "".join(chunks).upper()
        if sid in hashes or not seq:
            raise ValueError(f"Duplicate FASTA ID or empty sequence: {sid}")
        hashes[sid] = hashlib.sha256(seq.encode("ascii")).hexdigest()
        lengths[sid] = len(seq)

    with path.open(encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                flush()
                sid, chunks = line[1:].split()[0], []
            elif line:
                if sid is None:
                    raise ValueError("Sequence before FASTA header")
                chunks.append("".join(line.split()))
    flush()
    return hashes, lengths


def main():
    all_checks = []
    split_sets = None
    for folder in sorted(p for p in RESULTS.iterdir() if p.is_dir() and "_wo_" in p.name):
        ids = {"train": read_ids(folder / ("model_train_ids.txt" if folder.name.startswith("DNA") else "train_ids.txt")),
               "validation": read_ids(folder / "validation_ids.txt"), "test": read_ids(folder / "test_ids.txt")}
        sets = {s: set(v) for s, v in ids.items()}
        manifest = read_rows(folder / "split_manifest.csv")
        checks = {
            "folder": folder.name, "N": {s: len(v) for s, v in ids.items()},
            "duplicate_ids": {s: len(v) - len(set(v)) for s, v in ids.items()},
            "train_test_overlap": len(sets["train"] & sets["test"]),
            "validation_test_overlap": len(sets["validation"] & sets["test"]),
            "train_validation_overlap": len(sets["train"] & sets["validation"]),
            "manifest_duplicate_ids": len(manifest) - len({r["sequence_id"] for r in manifest}),
            "manifest_matches_lists": all({r["sequence_id"] for r in manifest if r["model_split"] == s} == v for s, v in sets.items()),
        }
        if split_sets is None:
            split_sets = sets
        assert sets == split_sets, "Ablation split differs"
        all_checks.append(checks)
    assert len(all_checks) == 6
    selected = set.union(*split_sets.values())
    structure = read_rows(ROOT / "all_ARG_nonARG_1to1_structure.txt", "\t")
    labels = {r["sarg.seq.id"]: (r["arg.or.nonarg"], r["type"], r["subtype"]) for r in structure}
    old_path = B / "ARGscope_result_9.16" / "ARGScope" / "protein_result" / "100%_test_sequence_predictions.csv"
    old_rows = read_rows(old_path)
    old = {r["sequence_id"] for r in old_rows}
    old_placement = {s: len(old & v) for s, v in split_sets.items()}
    old_placement["excluded"] = len(old - selected)
    source = B / "1. Dataset" / "最后的数据集" / "2. ARG_nonARG_dataset"
    sequence_checks = []
    duplicates = []
    for modality, fname, length_col in (("Protein", "all_ARG_nonARG_1to1_protein.fasta", "protein.length.aa"),
                                         ("DNA", "all_ARG_nonARG_1to1_DNA.fasta", "dna.length.nt")):
        path = source / fname
        hashes, lengths = fasta_hashes(path)
        missing = selected - hashes.keys()
        if missing:
            raise ValueError(f"{modality}: {len(missing)} split IDs missing from FASTA")
        groups = {s: defaultdict(list) for s in split_sets}
        for s, ids in split_sets.items():
            for sid in ids:
                groups[s][hashes[sid]].append(sid)
        cross = {}
        for left, right in (("train", "test"), ("validation", "test"), ("train", "validation")):
            shared = groups[left].keys() & groups[right].keys()
            cross[f"{left}_{right}"] = {
                "identical_sequence_groups": len(shared),
                f"{left}_IDs": sum(len(groups[left][h]) for h in shared),
                f"{right}_IDs": sum(len(groups[right][h]) for h in shared),
                "subtype_conflicting_groups": sum(len({labels[sid][2] for sid in groups[left][h] + groups[right][h]}) > 1 for h in shared),
            }
            for h in sorted(shared):
                duplicates.append({"modality": modality, "comparison": f"{left}_vs_{right}", "sequence_sha256": h,
                                   "left_ids": sorted(groups[left][h]), "right_ids": sorted(groups[right][h])})
        combined = groups["train"].keys() | groups["validation"].keys()
        exposed_test = groups["test"].keys() & combined
        sequence_checks.append({"modality": modality, "path": str(path), "FASTA_records": len(hashes),
                                "all_selected_IDs_present": True,
                                "length_conflicts_with_structure": sum(int(r[length_col]) != lengths[r["sarg.seq.id"]] for r in structure if r["sarg.seq.id"] in selected),
                                "within_split_redundant_sequences": {s: len(split_sets[s]) - len(groups[s]) for s in split_sets},
                                "cross_split_exact_sequences": cross,
                                "test_IDs_identical_to_train_or_validation": sum(len(groups["test"][h]) for h in exposed_test)})
    report = {"id_checks": all_checks, "all_six_splits_identical": True,
              "original_Full_test_placement": old_placement, "sequence_checks": sequence_checks,
              "sequence_definition": "Full sequence, whitespace removed, upper case, SHA256. Stop characters preserved. No homology or reverse-complement search."}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "split_overlap_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "exact_sequence_overlap_ids.json").write_text(json.dumps(duplicates, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"id_checks": all_checks, "old_test_placement": old_placement, "sequence_checks": sequence_checks}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
