import pandas as pd
from sklearn.model_selection import train_test_split


def split_arg_data(
    file_path,
    id_col="id",
    type_col="Type",
    subtype_col="Subtype",
    rare_threshold=20,
    test_ratio=0.2,
    random_state=42
):
    # 1. 读取数据
    df = pd.read_csv(file_path).copy()

    # 2. 检查必要列
    required_cols = [type_col, subtype_col]
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"数据中未找到必要列: {col}")

    df = df.reset_index(drop=True)

    total_n = len(df)
    if total_n == 0:
        raise ValueError("输入数据为空。")

    # 3. 统计每个 Subtype 的数量
    subtype_counts = df[subtype_col].value_counts()

    rare_subtypes = set(subtype_counts[subtype_counts < rare_threshold].index)
    common_subtypes = set(subtype_counts[subtype_counts >= rare_threshold].index)

    # 4. 目标测试集大小
    target_test_n = round(total_n * test_ratio)
    all_types = sorted(df[type_col].dropna().unique())

    if target_test_n < len(all_types):
        raise ValueError(
            f"目标测试集大小为 {target_test_n}，但 Type 数量为 {len(all_types)}，"
            f"无法满足“每个 Type 至少在 test 中出现一次”。"
        )

    # 5. 规则1优先：先给每个 Type 预留 1 个测试样本
    reserved_test_parts = []
    used_indices = set()
    reserved_from_rare = []
    reserved_from_common = []

    for t in all_types:
        type_df = df[df[type_col] == t].copy()

        if len(type_df) == 0:
            continue

        # 优先从 common subtype 中抽
        type_common_df = type_df[type_df[subtype_col].isin(common_subtypes)].copy()

        if len(type_common_df) > 0:
            # 从该 type 内样本最多的 common subtype 抽 1 个
            subtype_freq = type_common_df[subtype_col].value_counts()
            chosen_subtype = subtype_freq.index[0]
            candidate_rows = type_common_df[type_common_df[subtype_col] == chosen_subtype]
            chosen = candidate_rows.sample(n=1, random_state=random_state)
            reserved_from_common.append(t)
        else:
            # 如果该 Type 只能来自 rare subtype，也必须抽 1 个进 test
            subtype_freq = type_df[subtype_col].value_counts()
            chosen_subtype = subtype_freq.index[0]
            candidate_rows = type_df[type_df[subtype_col] == chosen_subtype]
            chosen = candidate_rows.sample(n=1, random_state=random_state)
            reserved_from_rare.append(t)

        reserved_test_parts.append(chosen)
        used_indices.update(chosen.index.tolist())

    reserved_test_df = pd.concat(reserved_test_parts, ignore_index=False)

    # 6. 把剩余样本拆成 rare / common 两部分
    remaining_df = df.drop(index=list(used_indices)).copy()

    remaining_rare_df = remaining_df[remaining_df[subtype_col].isin(rare_subtypes)].copy()
    remaining_common_df = remaining_df[remaining_df[subtype_col].isin(common_subtypes)].copy()

    # 7. rare subtype 默认全部进训练集
    train_rare_df = remaining_rare_df.copy()

    # 8. 还需要从 common 里抽多少到 test
    reserved_n = len(reserved_test_df)
    remaining_test_n = target_test_n - reserved_n

    if remaining_test_n < 0:
        raise ValueError(
            f"预留给每个 Type 的测试样本数 {reserved_n} 已超过目标测试集大小 {target_test_n}。"
        )

    # 9. 从剩余 common 中补足 test
    if remaining_test_n == 0:
        train_common_df = remaining_common_df.copy()
        extra_test_df = remaining_common_df.iloc[0:0].copy()
        split_mode = "No extra split needed"
    else:
        if len(remaining_common_df) < remaining_test_n:
            raise ValueError(
                f"剩余 common subtype 样本数只有 {len(remaining_common_df)}，"
                f"不足以补足测试集需要的 {remaining_test_n} 个样本。"
            )

        # 能否按 Subtype 分层
        remaining_common_subtype_counts = remaining_common_df[subtype_col].value_counts()
        can_stratify = (remaining_common_subtype_counts >= 2).all()

        if can_stratify:
            train_common_df, extra_test_df = train_test_split(
                remaining_common_df,
                test_size=remaining_test_n,
                random_state=random_state,
                stratify=remaining_common_df[subtype_col]
            )
            split_mode = "Subtype stratified"
        else:
            train_common_df, extra_test_df = train_test_split(
                remaining_common_df,
                test_size=remaining_test_n,
                random_state=random_state,
                stratify=None
            )
            split_mode = "Random split (Subtype stratify unavailable)"

    # 10. 合并最终训练集和测试集
    final_train = pd.concat([train_rare_df, train_common_df], ignore_index=True)
    final_test = pd.concat([reserved_test_df, extra_test_df], ignore_index=True)

    # 11. 最终检查：每个 Type 是否都在 test 中至少出现一次
    test_types = set(final_test[type_col].dropna().unique())
    missing_types = sorted(set(all_types) - test_types)
    if len(missing_types) > 0:
        raise RuntimeError(
            "最终测试集中仍缺少以下 Type：\n" + "\n".join(map(str, missing_types))
        )

    # 12. 保存结果
    final_train.to_csv("train_set.csv", index=False)
    final_test.to_csv("test_set.csv", index=False)

    # 13. 输出统计
    print("处理完成！")
    print(f"总样本数: {total_n}")
    print(f"Type 数量: {len(all_types)}")
    print(f"Rare Subtype 阈值: < {rare_threshold}")
    print(f"Rare Subtype 数量: {len(rare_subtypes)}")
    print(f"Common Subtype 数量: {len(common_subtypes)}")
    print(f"目标测试集大小: {target_test_n}")
    print(f"预留给每个 Type 的测试样本数: {reserved_n}")
    print(f"其中从 common subtype 预留的 Type 数: {len(reserved_from_common)}")
    print(f"其中从 rare subtype 预留的 Type 数: {len(reserved_from_rare)}")
    print(f"训练集大小: {len(final_train)}")
    print(f"测试集大小: {len(final_test)}")
    print(f"训练集比例: {len(final_train) / total_n:.4f}")
    print(f"测试集比例: {len(final_test) / total_n:.4f}")
    print(f"补足测试集方式: {split_mode}")

    if len(reserved_from_rare) > 0:
        print("\n以下 Type 为满足规则1，必须从 rare subtype 中抽样进入 test：")
        for t in reserved_from_rare:
            print(t)

    print("\n测试集中各 Type 的样本数：")
    print(final_test[type_col].value_counts().sort_index())

    print("\n测试集中各 Subtype 的样本数（前20个）：")
    print(final_test[subtype_col].value_counts().head(20))


# 执行
split_arg_data("all_arg_nonarg_id_label.csv")