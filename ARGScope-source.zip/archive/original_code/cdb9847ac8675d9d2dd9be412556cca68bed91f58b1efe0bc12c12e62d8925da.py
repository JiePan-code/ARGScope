from Bio import SeqIO

dna_file = "VFDB_matched_dna.fasta"
protein_file = "VFDB_matched_protein.fasta"

# 读取ID列表
dna_records = list(SeqIO.parse(dna_file, "fasta"))
protein_records = list(SeqIO.parse(protein_file, "fasta"))

dna_ids = [record.id for record in dna_records]
protein_ids = [record.id for record in protein_records]

# 1. 检查序列数量
print(f"DNA序列数: {len(dna_ids)}")
print(f"Protein序列数: {len(protein_ids)}")

if len(dna_ids) != len(protein_ids):
    print("❌ 序列数量不一致")
else:
    print("✅ 序列数量一致")

# 2. 按顺序检查ID是否一一对应
mismatch = []
for i, (d_id, p_id) in enumerate(zip(dna_ids, protein_ids)):
    if d_id != p_id:
        mismatch.append((i, d_id, p_id))

if mismatch:
    print(f"❌ 存在 {len(mismatch)} 个位置ID不匹配")
    print("示例（前10个）：")
    for m in mismatch[:10]:
        print(f"位置 {m[0]}: DNA={m[1]} | Protein={m[2]}")
else:
    print("✅ 按顺序ID完全对应")

# 3. 集合层面检查（是否包含完全相同的ID集合）
dna_set = set(dna_ids)
protein_set = set(protein_ids)

if dna_set == protein_set:
    print("✅ 两个文件的ID集合完全一致")
else:
    print("❌ ID集合不一致")

    only_in_dna = dna_set - protein_set
    only_in_protein = protein_set - dna_set

    print(f"仅在DNA中存在: {len(only_in_dna)}")
    print(f"仅在Protein中存在: {len(only_in_protein)}")

    print("示例：")
    print("DNA特有:", list(only_in_dna)[:5])
    print("Protein特有:", list(only_in_protein)[:5])