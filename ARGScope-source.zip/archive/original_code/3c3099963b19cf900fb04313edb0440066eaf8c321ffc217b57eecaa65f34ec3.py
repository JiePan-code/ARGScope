import random
import multiprocessing as mp

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    classification_report,
)


# =========================
# 1. 配置与参数
# =========================

FUSION_FILE = "1.all_fusion_embedding_512_with_label.csv"
LONGAA_FILE = "2_vfdb_protein_with_label.csv"
TRAIN_SPLIT_FILE = "train_set.csv"
TEST_SPLIT_FILE = "test_set.csv"
PROTO_FILE = "3.all_Refined_embeddings_512.csv"

LABEL_COL = "Subtype"
KEY_CANDIDATES = ["Geneid", "geneid", "id", "ID", "Id", "NucleotideID", "ProteinID"]

SEED = 3407

# RTX 5060 显示 8GB 专用显存，推荐 1024；如果显存稳定可改 1536 或 2048
BATCH_SIZE = 1024

MAX_EPOCHS_C = 160
MAX_EPOCHS_M = 200

LR_C = 2e-4
LR_M = 1e-4
WEIGHT_DECAY = 1.5e-4

LAMBDA_MSE = 0.55
LAMBDA_CE = 1.70
LAMBDA_PRIOR = 1.40
LAMBDA_PROTO = 0.65

SCALE = 22.0

VAL_RATIO = 0.15
EARLY_STOP_PATIENCE_C = 25
EARLY_STOP_PATIENCE_M = 35
MIN_DELTA = 1e-5

PRINT_EVERY = 5
SAVE_CLASSIFICATION_REPORT = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# =========================
# 2. 基础函数
# =========================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    if hasattr(torch, "set_float32_matmul_precision"):
        torch.set_float32_matmul_precision("high")


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def get_feature_cols(df):
    exclude_cols = {
        "KEY", "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count"
    }

    return [
        c for c in df.columns
        if c not in exclude_cols and pd.api.types.is_numeric_dtype(df[c])
    ]


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def compute_overall_metrics(y_true, y_pred):
    return {
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true)))
    }


def compute_binary_mcc_for_class(y_true, y_pred, class_id):
    y_true_bin = (y_true == class_id).astype(int)
    y_pred_bin = (y_pred == class_id).astype(int)

    if len(np.unique(y_true_bin)) == 1 and len(np.unique(y_pred_bin)) == 1:
        return 0.0

    return matthews_corrcoef(y_true_bin, y_pred_bin)


def compute_per_class_metrics(
    y_true,
    y_pred,
    class_names,
    label_name,
    split_name,
    split_sample_count,
    split_subtype_count
):
    rows = []
    present_labels = sorted(np.unique(y_true))

    for class_id in present_labels:
        class_name = class_names[class_id]

        support = int((y_true == class_id).sum())
        pred_count = int((y_pred == class_id).sum())
        correct_count = int(((y_true == class_id) & (y_pred == class_id)).sum())

        precision = precision_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        recall = recall_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        f1 = f1_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        class_acc = correct_count / support if support > 0 else 0.0
        class_mcc = compute_binary_mcc_for_class(y_true, y_pred, class_id)

        rows.append({
            "split": split_name,
            "split_sample_count": int(split_sample_count),
            "split_subtype_count": int(split_subtype_count),
            label_name: class_name,
            "class_id": int(class_id),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct_count,
            "ACC": class_acc,
            "PRECISION": precision,
            "RECALL": recall,
            "F1": f1,
            "MCC": class_mcc
        })

    return pd.DataFrame(rows).sort_values(
        by=["support", label_name],
        ascending=[False, True]
    ).reset_index(drop=True)


def make_stratified_train_val_split(y, val_ratio=0.16, seed=42):
    rng = np.random.default_rng(seed)
    y = np.asarray(y)

    train_idx = []
    val_idx = []

    for cls in sorted(np.unique(y)):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)

        n = len(idx)

        if n <= 2:
            train_idx.extend(idx.tolist())
            continue

        n_val = max(1, int(round(n * val_ratio)))

        if n_val >= n:
            n_val = n - 1

        val_idx.extend(idx[:n_val].tolist())
        train_idx.extend(idx[n_val:].tolist())

    rng.shuffle(train_idx)
    rng.shuffle(val_idx)

    return np.array(train_idx), np.array(val_idx)


def build_prior_matrix(prior_df, label_col, label_encoder):
    if label_col not in prior_df.columns:
        raise ValueError(f"PROTO_FILE 缺少标签列: {label_col}")

    feat_cols = get_feature_cols(prior_df)

    if len(feat_cols) == 0:
        raise ValueError("PROTO_FILE 中没有可用数值特征列")

    tmp = prior_df.copy()
    tmp[feat_cols] = tmp[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

    grouped = tmp.groupby(label_col)[feat_cols].mean()

    prior_map = {
        str(k): grouped.loc[k].values.astype(np.float32)
        for k in grouped.index
    }

    missing = [
        lab for lab in label_encoder.classes_
        if lab not in prior_map
    ]

    if len(missing) > 0:
        raise ValueError(f"PROTO_FILE 缺少这些 subtype 的 refined prototype: {missing[:10]}")

    matrix = np.stack(
        [prior_map[lab] for lab in label_encoder.classes_],
        axis=0
    ).astype(np.float32)

    return matrix, feat_cols


def iter_gpu_batches(*tensors, batch_size=1024, shuffle=True):
    n = tensors[0].shape[0]

    if shuffle:
        idx = torch.randperm(n, device=tensors[0].device)
    else:
        idx = torch.arange(n, device=tensors[0].device)

    for start in range(0, n, batch_size):
        batch_idx = idx[start:start + batch_size]
        yield tuple(t[batch_idx] for t in tensors)


def predict_in_batches_classifier(classifier, X_gpu, batch_size=4096):
    classifier.eval()

    preds = []
    confs = []

    with torch.no_grad():
        for (xb,) in iter_gpu_batches(X_gpu, batch_size=batch_size, shuffle=False):
            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                prob = torch.softmax(logits, dim=1)
                conf, pred = prob.max(dim=1)

            preds.append(pred.detach().cpu().numpy())
            confs.append(conf.detach().cpu().numpy())

    return np.concatenate(preds), np.concatenate(confs)


def predict_in_batches_mapper(classifier, mapper, X_gpu, batch_size=4096):
    classifier.eval()
    mapper.eval()

    preds = []
    confs = []

    with torch.no_grad():
        for (xb,) in iter_gpu_batches(X_gpu, batch_size=batch_size, shuffle=False):
            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xb)
                logits = classifier(xf_hat)
                prob = torch.softmax(logits, dim=1)
                conf, pred = prob.max(dim=1)

            preds.append(pred.detach().cpu().numpy())
            confs.append(conf.detach().cpu().numpy())

    return np.concatenate(preds), np.concatenate(confs)


def threshold_scan(y_true, y_pred, conf):
    rows = []

    for th in [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.92, 0.94, 0.95, 0.96, 0.97, 0.98]:
        mask = conf >= th
        kept = int(mask.sum())
        coverage = kept / len(y_true) if len(y_true) > 0 else 0.0

        if kept == 0:
            rows.append({
                "threshold": th,
                "coverage": 0.0,
                "kept_samples": 0,
                "ACC_kept": 0.0,
                "WEIGHTED_PRECISION_kept": 0.0,
                "WEIGHTED_RECALL_kept": 0.0,
                "WEIGHTED_F1_kept": 0.0,
                "MCC_kept": 0.0
            })
            continue

        yt = y_true[mask]
        yp = y_pred[mask]

        rows.append({
            "threshold": th,
            "coverage": coverage,
            "kept_samples": kept,
            "ACC_kept": accuracy_score(yt, yp),
            "WEIGHTED_PRECISION_kept": precision_score(yt, yp, average="weighted", zero_division=0),
            "WEIGHTED_RECALL_kept": recall_score(yt, yp, average="weighted", zero_division=0),
            "WEIGHTED_F1_kept": f1_score(yt, yp, average="weighted", zero_division=0),
            "MCC_kept": matthews_corrcoef(yt, yp)
        })

    return pd.DataFrame(rows)


# =========================
# 3. Loss 和模型
# =========================

class WeightedFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=1.1, label_smoothing=0.04):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    def forward(self, logits, targets):
        ce_loss = nn.functional.cross_entropy(
            logits,
            targets,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing
        )

        pt = torch.exp(-ce_loss)
        return (((1.0 - pt) ** self.gamma) * ce_loss).mean()


class FusionPrototypeClassifier(nn.Module):
    def __init__(self, input_dim, proto_dim, num_classes, prototype_init=None, scale=30.0):
        super().__init__()

        self.projector = nn.Sequential(
            nn.Linear(input_dim, 640),
            nn.LayerNorm(640),
            nn.GELU(),
            nn.Dropout(0.18),

            nn.Linear(640, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.18),

            nn.Linear(512, proto_dim),
            nn.LayerNorm(proto_dim)
        )

        if prototype_init is not None:
            self.prototype = nn.Parameter(torch.tensor(prototype_init, dtype=torch.float32))
        else:
            self.prototype = nn.Parameter(torch.randn(num_classes, proto_dim))

        self.scale = scale

    def forward(self, x, return_embed=False):
        z = self.projector(x)
        z = nn.functional.normalize(z, p=2, dim=1)

        p = nn.functional.normalize(self.prototype, p=2, dim=1)
        logits = self.scale * (z @ p.t())

        if return_embed:
            return z, logits

        return logits


class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.14):
        super().__init__()

        self.block = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(dim, dim),
            nn.LayerNorm(dim)
        )

        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.dropout(self.block(x)))


class LongAAToFusionMapper(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        self.input_proj = nn.Sequential(
            nn.Linear(in_dim, 768),
            nn.LayerNorm(768),
            nn.GELU(),
            nn.Dropout(0.14)
        )

        self.res1 = ResidualBlock(768, dropout=0.14)
        self.res2 = ResidualBlock(768, dropout=0.14)

        self.output_proj = nn.Sequential(
            nn.Linear(768, 640),
            nn.LayerNorm(640),
            nn.GELU(),
            nn.Dropout(0.16),

            nn.Linear(640, out_dim)
        )

    def forward(self, x):
        x = self.input_proj(x)
        x = self.res1(x)
        x = self.res2(x)
        return self.output_proj(x)


class PriorProjector(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        if in_dim == out_dim:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.proj(x)


# =========================
# 4. 主程序
# =========================

def main():
    seed_everything(SEED)

    print("Using device:", DEVICE)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    print("Loading files...")

    fusion_df = pd.read_csv(FUSION_FILE)
    longaa_df = pd.read_csv(LONGAA_FILE)
    train_split_df = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split_df = pd.read_csv(TEST_SPLIT_FILE)
    proto_ref_df = pd.read_csv(PROTO_FILE)

    print("Fusion file shape:", fusion_df.shape)
    print("LongAA file shape:", longaa_df.shape)
    print("Train split shape:", train_split_df.shape)
    print("Test split shape:", test_split_df.shape)
    print("Prototype file shape:", proto_ref_df.shape)

    fusion_key = find_key_col(fusion_df, KEY_CANDIDATES)
    longaa_key = find_key_col(longaa_df, KEY_CANDIDATES)
    train_key = find_key_col(train_split_df, KEY_CANDIDATES)
    test_key = find_key_col(test_split_df, KEY_CANDIDATES)

    if fusion_key is None:
        raise ValueError("FUSION_FILE 中没有找到 key 列")

    if longaa_key is None:
        raise ValueError("LONGAA_FILE 中没有找到 key 列")

    if train_key is None:
        raise ValueError("TRAIN_SPLIT_FILE 中没有找到 key 列")

    if test_key is None:
        raise ValueError("TEST_SPLIT_FILE 中没有找到 key 列")

    for df_, key_ in [
        (fusion_df, fusion_key),
        (longaa_df, longaa_key),
        (train_split_df, train_key),
        (test_split_df, test_key)
    ]:
        df_[key_] = df_[key_].astype(str).str.strip()

    for df_ in [train_split_df, test_split_df]:
        for col in ["Type", "Subtype"]:
            if col not in df_.columns:
                raise ValueError(f"划分文件缺少必要列: {col}")

            df_[col] = df_[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

    for col in ["Type", "Subtype"]:
        if col in fusion_df.columns:
            fusion_df[col] = fusion_df[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

        if col in longaa_df.columns:
            longaa_df[col] = longaa_df[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

        if col in proto_ref_df.columns:
            proto_ref_df[col] = proto_ref_df[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

    for df_name, df_, key_ in [
        ("fusion", fusion_df, fusion_key),
        ("longAA", longaa_df, longaa_key)
    ]:
        dup_n = df_[key_].duplicated().sum()

        if dup_n > 0:
            print(f"Warning: {df_name} file has {dup_n} duplicated keys. Keep first occurrence.")
            df_ = df_.drop_duplicates(subset=[key_], keep="first").copy()

            if df_name == "fusion":
                fusion_df = df_
            else:
                longaa_df = df_

    fusion_df = fusion_df.rename(columns={fusion_key: "KEY"})
    longaa_df = longaa_df.rename(columns={longaa_key: "KEY"})
    train_split_df = train_split_df.rename(columns={train_key: "KEY"})
    test_split_df = test_split_df.rename(columns={test_key: "KEY"})

    train_fusion_df = pd.merge(
        train_split_df,
        fusion_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    train_longaa_df = pd.merge(
        train_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    test_longaa_df = pd.merge(
        test_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    print("\nAfter merge:")
    print("Merged train_fusion samples:", len(train_fusion_df))
    print("Merged train_longAA samples:", len(train_longaa_df))
    print("Merged test_longAA samples:", len(test_longaa_df))

    if len(train_fusion_df) == 0:
        raise ValueError("train split 与 fusion 文件合并后为空，请检查 key 是否一致。")

    if len(train_longaa_df) == 0:
        raise ValueError("train split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    if len(test_longaa_df) == 0:
        raise ValueError("test split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    for df_ in [train_fusion_df, train_longaa_df, test_longaa_df]:
        for col in ["Type", "Subtype"]:
            split_col = f"{col}_split"

            if split_col in df_.columns:
                df_[col] = df_[split_col].astype(str)

        if "Geneid" not in df_.columns:
            df_["Geneid"] = df_["KEY"].astype(str)

    common_train_keys = sorted(set(train_fusion_df["KEY"]) & set(train_longaa_df["KEY"]))

    train_fusion_df = train_fusion_df[train_fusion_df["KEY"].isin(common_train_keys)].copy()
    train_longaa_df = train_longaa_df[train_longaa_df["KEY"].isin(common_train_keys)].copy()

    train_fusion_df.sort_values("KEY", inplace=True)
    train_longaa_df.sort_values("KEY", inplace=True)

    if len(train_fusion_df) != len(train_longaa_df):
        raise ValueError("train_fusion 与 train_longAA 数量不一致")

    if not np.all(train_fusion_df["KEY"].values == train_longaa_df["KEY"].values):
        raise ValueError("train_fusion 与 train_longAA 的 KEY 未对齐")

    valid_subtypes_in_proto = set(proto_ref_df[LABEL_COL].astype(str).unique())

    train_fusion_df = train_fusion_df[train_fusion_df[LABEL_COL].isin(valid_subtypes_in_proto)].copy()
    train_longaa_df = train_longaa_df[train_longaa_df[LABEL_COL].isin(valid_subtypes_in_proto)].copy()
    test_longaa_df = test_longaa_df[test_longaa_df[LABEL_COL].isin(valid_subtypes_in_proto)].copy()

    common_subtypes = (
        set(train_fusion_df[LABEL_COL].astype(str).unique())
        & set(train_longaa_df[LABEL_COL].astype(str).unique())
        & set(test_longaa_df[LABEL_COL].astype(str).unique())
        & set(proto_ref_df[LABEL_COL].astype(str).unique())
    )

    train_fusion_df = train_fusion_df[train_fusion_df[LABEL_COL].isin(common_subtypes)].copy()
    train_longaa_df = train_longaa_df[train_longaa_df[LABEL_COL].isin(common_subtypes)].copy()
    test_longaa_df = test_longaa_df[test_longaa_df[LABEL_COL].isin(common_subtypes)].copy()
    proto_ref_df = proto_ref_df[proto_ref_df[LABEL_COL].isin(common_subtypes)].copy()

    train_fusion_df.reset_index(drop=True, inplace=True)
    train_longaa_df.reset_index(drop=True, inplace=True)
    test_longaa_df.reset_index(drop=True, inplace=True)

    if len(train_fusion_df) == 0:
        raise ValueError("过滤后 train_fusion 为空")

    if len(train_longaa_df) == 0:
        raise ValueError("过滤后 train_longAA 为空")

    if len(test_longaa_df) == 0:
        raise ValueError("过滤后 test_longAA 为空")

    print("\nAfter filtering:")
    print(f"Train_fusion samples: {len(train_fusion_df)}, subtype count: {train_fusion_df[LABEL_COL].nunique()}")
    print(f"Train_longAA samples: {len(train_longaa_df)}, subtype count: {train_longaa_df[LABEL_COL].nunique()}")
    print(f"Test_longAA samples: {len(test_longaa_df)}, subtype count: {test_longaa_df[LABEL_COL].nunique()}")

    le = LabelEncoder()
    le.fit(sorted(train_fusion_df[LABEL_COL].astype(str).unique()))

    num_classes = len(le.classes_)
    valid_class_set = set(le.classes_)

    test_longaa_df = test_longaa_df[
        test_longaa_df[LABEL_COL].isin(valid_class_set)
    ].reset_index(drop=True)

    print(f"Classes in train_fusion: {num_classes}")
    print(f"Test_longAA after unseen-label filter: {len(test_longaa_df)}")

    if len(test_longaa_df) == 0:
        raise ValueError("test_longAA 为空")

    fusion_feature_cols = get_feature_cols(train_fusion_df)
    longaa_feature_cols = get_feature_cols(train_longaa_df)

    if len(fusion_feature_cols) == 0:
        raise ValueError("Fusion 特征列为 0")

    if len(longaa_feature_cols) == 0:
        raise ValueError("LongAA 特征列为 0")

    X_train_fusion = to_float_matrix(train_fusion_df, fusion_feature_cols)
    X_train_longaa = to_float_matrix(train_longaa_df, longaa_feature_cols)
    X_test_longaa = to_float_matrix(test_longaa_df, longaa_feature_cols)

    y_all = le.transform(train_fusion_df[LABEL_COL].astype(str).values).astype(np.int64)
    y_test = le.transform(test_longaa_df[LABEL_COL].astype(str).values).astype(np.int64)

    scaler_fusion = StandardScaler()
    scaler_longaa = StandardScaler()

    X_train_fusion_s = scaler_fusion.fit_transform(X_train_fusion).astype(np.float32)
    X_train_longaa_s = scaler_longaa.fit_transform(X_train_longaa).astype(np.float32)
    X_test_longaa_s = scaler_longaa.transform(X_test_longaa).astype(np.float32)

    input_dim_fusion = X_train_fusion_s.shape[1]
    input_dim_longaa = X_train_longaa_s.shape[1]

    print(f"Fusion feature dim: {input_dim_fusion}")
    print(f"LongAA feature dim: {input_dim_longaa}")

    train_idx, val_idx = make_stratified_train_val_split(
        y_all,
        val_ratio=VAL_RATIO,
        seed=SEED
    )

    print("Internal train samples:", len(train_idx))
    print("Internal val samples:", len(val_idx))

    Xf_train = X_train_fusion_s[train_idx]
    Xa_train = X_train_longaa_s[train_idx]
    y_train = y_all[train_idx]

    Xf_val = X_train_fusion_s[val_idx]
    Xa_val = X_train_longaa_s[val_idx]
    y_val = y_all[val_idx]

    prior_matrix_raw, _ = build_prior_matrix(proto_ref_df, LABEL_COL, le)
    prior_dim = prior_matrix_raw.shape[1]
    PROTO_DIM = prior_dim

    print(f"Refined prior dim: {prior_dim}")

    # 一次性放入 GPU，减少 CPU-GPU 数据搬运
    Xf_train_t = torch.tensor(Xf_train, dtype=torch.float32, device=DEVICE)
    Xa_train_t = torch.tensor(Xa_train, dtype=torch.float32, device=DEVICE)
    y_train_t = torch.tensor(y_train, dtype=torch.long, device=DEVICE)

    Xf_val_t = torch.tensor(Xf_val, dtype=torch.float32, device=DEVICE)
    Xa_val_t = torch.tensor(Xa_val, dtype=torch.float32, device=DEVICE)
    y_val_t = torch.tensor(y_val, dtype=torch.long, device=DEVICE)

    Xf_all_t = torch.tensor(X_train_fusion_s, dtype=torch.float32, device=DEVICE)
    Xt_test_t = torch.tensor(X_test_longaa_s, dtype=torch.float32, device=DEVICE)

    prior_tensor = torch.tensor(prior_matrix_raw, dtype=torch.float32, device=DEVICE)

    classifier = FusionPrototypeClassifier(
        input_dim=input_dim_fusion,
        proto_dim=PROTO_DIM,
        num_classes=num_classes,
        prototype_init=prior_matrix_raw,
        scale=SCALE
    ).to(DEVICE)

    mapper = LongAAToFusionMapper(
        in_dim=input_dim_longaa,
        out_dim=input_dim_fusion
    ).to(DEVICE)

    prior_proj = PriorProjector(
        in_dim=prior_dim,
        out_dim=PROTO_DIM
    ).to(DEVICE)

    print("Classifier device:", next(classifier.parameters()).device)
    print("Mapper device:", next(mapper.parameters()).device)

    class_counts = np.bincount(y_train, minlength=num_classes).astype(np.float32)

    beta = 0.995
    effective_num = 1.0 - np.power(beta, class_counts)
    class_weights = (1.0 - beta) / (effective_num + 1e-8)

    class_weights = class_weights / class_weights.mean()
    class_weights = np.clip(class_weights, 0.6, 2.5)

    class_weights = torch.tensor(
        class_weights,
        dtype=torch.float32,
        device=DEVICE
    )

    criterion_ce = WeightedFocalLoss(
        weight=class_weights,
        gamma=0.8,
        label_smoothing=0.08
    )

    criterion_mse = nn.SmoothL1Loss(beta=0.5)

    optimizer_c = optim.AdamW(
        list(classifier.parameters()) + list(prior_proj.parameters()),
        lr=LR_C,
        weight_decay=WEIGHT_DECAY
    )

    optimizer_m = optim.AdamW(
        mapper.parameters(),
        lr=LR_M,
        weight_decay=WEIGHT_DECAY
    )

    scheduler_c = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_c,
        mode="max",
        factor=0.5,
        patience=6
    )

    scheduler_m = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_m,
        mode="max",
        factor=0.5,
        patience=6
    )

    scaler_amp_c = torch.amp.GradScaler("cuda", enabled=USE_AMP)
    scaler_amp_m = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    # =========================
    # 训练 classifier
    # =========================

    print("\nStarting classifier training on fusion...")

    best_score_c = -1.0
    best_classifier_state = None
    best_prior_proj_state = None
    no_improve_c = 0

    for epoch in range(1, MAX_EPOCHS_C + 1):
        classifier.train()
        prior_proj.train()

        total_loss = 0.0

        for xb, yb in iter_gpu_batches(
            Xf_train_t,
            y_train_t,
            batch_size=BATCH_SIZE,
            shuffle=True
        ):
            optimizer_c.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                loss_ce = criterion_ce(logits, yb)

                prior_proj_mat = prior_proj(prior_tensor)

                proto_now_norm = nn.functional.normalize(classifier.prototype, p=2, dim=1)
                proto_ref_norm = nn.functional.normalize(prior_proj_mat, p=2, dim=1)

                loss_proto = 1.0 - torch.mean(torch.sum(proto_now_norm * proto_ref_norm, dim=1))
                loss = loss_ce + LAMBDA_PROTO * loss_proto

            scaler_amp_c.scale(loss).backward()
            scaler_amp_c.unscale_(optimizer_c)

            torch.nn.utils.clip_grad_norm_(
                list(classifier.parameters()) + list(prior_proj.parameters()),
                1.0
            )

            scaler_amp_c.step(optimizer_c)
            scaler_amp_c.update()

            total_loss += loss.item() * xb.size(0)

        avg_loss = total_loss / Xf_train_t.shape[0]

        y_val_pred_c, _ = predict_in_batches_classifier(
            classifier,
            Xf_val_t,
            batch_size=4096
        )

        val_precision_c = precision_score(y_val, y_val_pred_c, average="weighted", zero_division=0)
        val_f1_c = f1_score(y_val, y_val_pred_c, average="weighted", zero_division=0)
        val_score_c = 0.85 * val_precision_c + 0.15 * val_f1_c

        scheduler_c.step(val_score_c)

        if val_score_c > best_score_c + MIN_DELTA:
            best_score_c = val_score_c
            best_classifier_state = {
                k: v.detach().cpu().clone()
                for k, v in classifier.state_dict().items()
            }
            best_prior_proj_state = {
                k: v.detach().cpu().clone()
                for k, v in prior_proj.state_dict().items()
            }
            no_improve_c = 0
        else:
            no_improve_c += 1

        if epoch % PRINT_EVERY == 0 or epoch == 1:
            lr_now = optimizer_c.param_groups[0]["lr"]
            print(
                f"[Classifier] Epoch {epoch:03d} | lr={lr_now:.2e} | "
                f"loss={avg_loss:.4f} | val_precision={val_precision_c:.4f} | val_f1={val_f1_c:.4f}"
            )

        if no_improve_c >= EARLY_STOP_PATIENCE_C:
            print(f"[Classifier] Early stopping at epoch {epoch}, best score={best_score_c:.4f}")
            break

    classifier.load_state_dict(best_classifier_state)
    prior_proj.load_state_dict(best_prior_proj_state)

    classifier = classifier.to(DEVICE)
    prior_proj = prior_proj.to(DEVICE)

    for p in classifier.parameters():
        p.requires_grad = False

    for p in prior_proj.parameters():
        p.requires_grad = False

    classifier.eval()
    prior_proj.eval()

    # =========================
    # 训练 mapper
    # =========================

    print("\nStarting mapper training: LongAA -> fusion...")

    best_score_m = -1.0
    best_mapper_state = None
    no_improve_m = 0

    for epoch in range(1, MAX_EPOCHS_M + 1):
        mapper.train()

        total_loss = 0.0

        for xa, xf_t, yb in iter_gpu_batches(
            Xa_train_t,
            Xf_train_t,
            y_train_t,
            batch_size=BATCH_SIZE,
            shuffle=True
        ):
            optimizer_m.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xa)

                loss_mse = criterion_mse(xf_hat, xf_t)

                logits = classifier(xf_hat)
                loss_ce = criterion_ce(logits, yb)

                z_hat, _ = classifier(xf_hat, return_embed=True)

                prior_batch = prior_proj(prior_tensor[yb])
                prior_batch = nn.functional.normalize(prior_batch, p=2, dim=1)

                loss_prior = 1.0 - torch.mean(torch.sum(z_hat * prior_batch, dim=1))

                loss = (
                    LAMBDA_MSE * loss_mse
                    + LAMBDA_CE * loss_ce
                    + LAMBDA_PRIOR * loss_prior
                )

            scaler_amp_m.scale(loss).backward()
            scaler_amp_m.unscale_(optimizer_m)

            torch.nn.utils.clip_grad_norm_(mapper.parameters(), 1.0)

            scaler_amp_m.step(optimizer_m)
            scaler_amp_m.update()

            total_loss += loss.item() * xa.size(0)

        avg_loss = total_loss / Xa_train_t.shape[0]

        y_val_pred_m, _ = predict_in_batches_mapper(
            classifier,
            mapper,
            Xa_val_t,
            batch_size=4096
        )

        val_precision_m = precision_score(y_val, y_val_pred_m, average="weighted", zero_division=0)
        val_f1_m = f1_score(y_val, y_val_pred_m, average="weighted", zero_division=0)
        val_score_m = 0.90 * val_precision_m + 0.10 * val_f1_m

        scheduler_m.step(val_score_m)

        if val_score_m > best_score_m + MIN_DELTA:
            best_score_m = val_score_m
            best_mapper_state = {
                k: v.detach().cpu().clone()
                for k, v in mapper.state_dict().items()
            }
            no_improve_m = 0
        else:
            no_improve_m += 1

        if epoch % PRINT_EVERY == 0 or epoch == 1:
            lr_now = optimizer_m.param_groups[0]["lr"]
            print(
                f"[Mapper] Epoch {epoch:03d} | lr={lr_now:.2e} | "
                f"loss={avg_loss:.4f} | val_precision={val_precision_m:.4f} | val_f1={val_f1_m:.4f}"
            )

        if no_improve_m >= EARLY_STOP_PATIENCE_M:
            print(f"[Mapper] Early stopping at epoch {epoch}, best score={best_score_m:.4f}")
            break

    mapper.load_state_dict(best_mapper_state)
    mapper = mapper.to(DEVICE)
    mapper.eval()

    # =========================
    # 评估
    # =========================

    print("\nEvaluating...")

    y_pred_train, _ = predict_in_batches_classifier(
        classifier,
        Xf_all_t,
        batch_size=4096
    )

    y_pred_test, conf_test = predict_in_batches_mapper(
        classifier,
        mapper,
        Xt_test_t,
        batch_size=4096
    )

    train_metrics = compute_overall_metrics(y_all, y_pred_train)
    test_metrics = compute_overall_metrics(y_test, y_pred_test)

    print("\n=== TRAIN_SET RESULT | fusion -> classifier ===")
    for k, v in train_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    print("\n=== TEST_SET RESULT | longAA -> mapper -> fusion -> classifier ===")
    for k, v in test_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    print("\n=== Weighted overall metrics (test_set) ===")
    print(f"Weighted Precision: {test_metrics['WEIGHTED_PRECISION']:.4f}")
    print(f"Weighted Recall:    {test_metrics['WEIGHTED_RECALL']:.4f}")
    print(f"Weighted F1:        {test_metrics['WEIGHTED_F1']:.4f}")
    print(f"Macro F1:           {test_metrics['MACRO_F1']:.4f}")

    if SAVE_CLASSIFICATION_REPORT:
        print("\n=== Classification Report (test_set) ===")
        print(classification_report(
            y_true=le.inverse_transform(y_test),
            y_pred=le.inverse_transform(y_pred_test),
            zero_division=0,
            digits=4
        ))

    # =========================
    # 保存输出
    # =========================

    overall_df = pd.DataFrame([
        {
            "split": "train_set",
            "sample_count": train_metrics["sample_count"],
            "subtype_count": train_metrics["subtype_count"],
            "ACC": train_metrics["ACC"],
            "WEIGHTED_PRECISION": train_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": train_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": train_metrics["WEIGHTED_F1"],
            "MACRO_F1": train_metrics["MACRO_F1"],
            "MCC": train_metrics["MCC"]
        },
        {
            "split": "test_set",
            "sample_count": test_metrics["sample_count"],
            "subtype_count": test_metrics["subtype_count"],
            "ACC": test_metrics["ACC"],
            "WEIGHTED_PRECISION": test_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": test_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": test_metrics["WEIGHTED_F1"],
            "MACRO_F1": test_metrics["MACRO_F1"],
            "MCC": test_metrics["MCC"]
        }
    ]).round(4)

    overall_df.to_csv(
        "subtype_overall_metrics_weighted.csv",
        index=False,
        encoding="utf-8-sig"
    )

    per_class_train_df = compute_per_class_metrics(
        y_true=y_all,
        y_pred=y_pred_train,
        class_names=le.classes_,
        label_name=LABEL_COL,
        split_name="train_set",
        split_sample_count=len(y_all),
        split_subtype_count=len(np.unique(y_all))
    )

    per_class_test_df = compute_per_class_metrics(
        y_true=y_test,
        y_pred=y_pred_test,
        class_names=le.classes_,
        label_name=LABEL_COL,
        split_name="test_set",
        split_sample_count=len(y_test),
        split_subtype_count=len(np.unique(y_test))
    )

    per_class_df = pd.concat(
        [per_class_train_df, per_class_test_df],
        axis=0,
        ignore_index=True
    ).round(4)

    per_class_df.to_csv(
        "subtype_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pred_df = test_longaa_df[["KEY", "Type", "Subtype"]].copy()
    pred_df["Pred_Subtype"] = le.inverse_transform(y_pred_test)
    pred_df["Pred_Confidence"] = conf_test

    pred_df.to_csv(
        "subtype_test_predictions.csv",
        index=False,
        encoding="utf-8-sig"
    )

    threshold_df = threshold_scan(
        y_true=y_test,
        y_pred=y_pred_test,
        conf=conf_test
    ).round(4)

    threshold_df.to_csv(
        "subtype_precision_threshold_scan.csv",
        index=False,
        encoding="utf-8-sig"
    )

    torch.save(
        {
            "classifier": classifier.state_dict(),
            "mapper": mapper.state_dict(),
            "prior_proj": prior_proj.state_dict(),
            "label_classes": le.classes_,
            "fusion_feature_cols": fusion_feature_cols,
            "longaa_feature_cols": longaa_feature_cols,
            "seed": SEED,
            "scale": SCALE,
            "input_dim_fusion": input_dim_fusion,
            "input_dim_longaa": input_dim_longaa,
            "proto_dim": PROTO_DIM
        },
        "subtype_fusion_mapper_model.pt"
    )

    print("\n结果已保存：")
    print(" - subtype_overall_metrics_weighted.csv")
    print(" - subtype_metrics_by_class.csv")
    print(" - subtype_test_predictions.csv")
    print(" - subtype_precision_threshold_scan.csv")
    print(" - subtype_fusion_mapper_model.pt")
    print("Done.")


if __name__ == "__main__":
    mp.freeze_support()
    main()