from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

CSV_FILE = Path(
    r"subtype_metrics_by_class.csv"
)

OUTPUT_DIR = CSV_FILE.parent / "subtype_top_bottom_radar_metrics"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "top10_bottom10_subtype_radar.pdf"
OUTPUT_TIF = OUTPUT_DIR / "top10_bottom10_subtype_radar.tif"
OUTPUT_SUMMARY = OUTPUT_DIR / "top10_bottom10_subtype_summary.csv"


# =========================================================
# 2. 参数设置
# =========================================================

TOP_N = 10
BOTTOM_N = 10

# 新数据集是每个 subtype 的统计结果。
# 原代码中 Accuracy = correct / support，本质上等价于这里的 RECALL。
PERFORMANCE_COL = "RECALL"
PERFORMANCE_LABEL = "Accuracy"

COLOR_TOP = "#3C5488"
COLOR_BOTTOM = "#E64B35"

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取数据
# =========================================================

df = pd.read_csv(CSV_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = [
    "Subtype",
    "support",
    "correct_count",
    "PRECISION",
    "RECALL",
    "F1",
    "MCC",
]

missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"CSV 文件缺少这些列: {missing_cols}")

df["Subtype"] = df["Subtype"].astype(str).str.strip()

numeric_cols = [
    "support",
    "correct_count",
    "PRECISION",
    "RECALL",
    "F1",
    "MCC",
]

for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

if df[numeric_cols].isna().any().any():
    bad_cols = df[numeric_cols].columns[df[numeric_cols].isna().any()].tolist()
    raise ValueError(f"这些数值列存在无法转换的内容: {bad_cols}")

# 兼容 split 列。如果有多个 split，可在这里指定 test split。
if "split" in df.columns:
    df["split"] = df["split"].astype(str).str.strip()

    if df["split"].nunique() > 1:
        # 优先选择名字中包含 test 的 split
        test_splits = [x for x in df["split"].unique() if "test" in x.lower()]

        if len(test_splits) > 0:
            selected_split = test_splits[0]
            df = df[df["split"] == selected_split].copy()
            print(f"Using split: {selected_split}")
        else:
            raise ValueError(
                f"检测到多个 split: {df['split'].unique().tolist()}，请手动指定使用哪个 split。"
            )


# =========================================================
# 4. 整理 summary
# =========================================================

summary = df.copy()

summary = summary.rename(columns={
    "support": "Count",
    "correct_count": "Correct",
    PERFORMANCE_COL: "Accuracy",
})

summary["Count"] = summary["Count"].astype(int)
summary["Correct"] = summary["Correct"].astype(int)
summary["Accuracy"] = summary["Accuracy"].astype(float)

# 单独统计 nonARG，不参与 Top 10 / Bottom 10 筛选
nonarg_summary = summary[summary["Subtype"] == "nonARG"].copy()

# 只用 ARG subtype 选择数量最多和最少的 subtype
arg_summary = summary[summary["Subtype"] != "nonARG"].copy()

if len(arg_summary) == 0:
    raise ValueError("除 nonARG 外没有其他 subtype，无法绘制 ARG subtype 雷达图。")

top10 = (
    arg_summary
    .sort_values(["Count", "Accuracy", "Subtype"], ascending=[False, False, True])
    .head(TOP_N)
    .copy()
)

bottom10 = (
    arg_summary
    .sort_values(["Count", "Accuracy", "Subtype"], ascending=[True, False, True])
    .head(BOTTOM_N)
    .copy()
)

top10["Group"] = "Top 10 abundant ARG subtypes"
bottom10["Group"] = "Bottom 10 abundant ARG subtypes"

if len(nonarg_summary) > 0:
    nonarg_summary["Group"] = "nonARG"
    plot_summary = pd.concat([top10, bottom10, nonarg_summary], axis=0)
else:
    plot_summary = pd.concat([top10, bottom10], axis=0)

keep_cols = [
    "Group",
    "Subtype",
    "Count",
    "Correct",
    "Accuracy",
    "PRECISION",
    "F1",
    "MCC",
]

if "split" in plot_summary.columns:
    keep_cols = ["split"] + keep_cols

plot_summary[keep_cols].to_csv(
    OUTPUT_SUMMARY,
    index=False,
    encoding="utf-8-sig",
)

print("Top 10 abundant ARG subtypes:")
print(top10[["Subtype", "Count", "Correct", "Accuracy", "F1", "MCC"]])

print("\nBottom 10 abundant ARG subtypes:")
print(bottom10[["Subtype", "Count", "Correct", "Accuracy", "F1", "MCC"]])

print("\nnonARG summary:")
if len(nonarg_summary) > 0:
    print(nonarg_summary[["Subtype", "Count", "Correct", "Accuracy", "F1", "MCC"]])
else:
    print("没有找到 nonARG。")


# =========================================================
# 5. 雷达图函数
# =========================================================

def shorten_label(x):
    """
    如果 subtype 名称中有 '__'，只显示后半部分。
    例如 multidrug__tolC -> tolC。
    如果没有 '__'，则保留原名称。
    """
    x = str(x)

    if "__" in x:
        return x.split("__", 1)[1]

    return x


def plot_radar(ax, data, title, line_color):
    labels = [shorten_label(x) for x in data["Subtype"].tolist()]
    values = data["Accuracy"].astype(float).tolist()
    counts = data["Count"].astype(int).tolist()

    n = len(labels)

    if n == 0:
        raise ValueError(f"{title} 没有可绘制的数据。")

    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)

    values_closed = values + values[:1]
    angles_closed = np.concatenate([angles, angles[:1]])

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    ax.plot(
        angles_closed,
        values_closed,
        color=line_color,
        linewidth=2.0,
        marker="o",
        markersize=4.2,
        markeredgecolor="black",
        markeredgewidth=0.35,
        zorder=3,
    )

    ax.fill(
        angles_closed,
        values_closed,
        color=line_color,
        alpha=0.18,
        zorder=2,
    )

    ax.set_xticks(angles)
    ax.set_xticklabels(
        [f"{lab}\n(n={cnt})" for lab, cnt in zip(labels, counts)],
        fontsize=7,
    )

    # 根据当前数据自动设置 y 轴范围，使图更美观
    local_min = min(values)
    local_max = max(values)

    y_min = max(0.0, np.floor((local_min - 0.05) * 10) / 10)
    y_max = min(1.0, np.ceil((local_max + 0.05) * 10) / 10)

    if y_max - y_min < 0.2:
        center = (y_min + y_max) / 2
        y_min = max(0.0, center - 0.1)
        y_max = min(1.0, center + 0.1)

    ax.set_ylim(y_min, y_max)

    yticks = np.linspace(y_min, y_max, 5)
    yticks = np.round(yticks, 2)

    ax.set_yticks(yticks)
    ax.set_yticklabels([f"{x:.2f}" for x in yticks], fontsize=7)

    ax.set_title(title, fontsize=11, pad=20)

    ax.grid(
        True,
        linestyle="-",
        linewidth=0.45,
        alpha=0.45,
    )

    ax.spines["polar"].set_linewidth(1.0)
    ax.spines["polar"].set_color("black")


# =========================================================
# 6. 绘图
# =========================================================

fig, axes = plt.subplots(
    1,
    2,
    figsize=(10.8, 5.3),
    subplot_kw=dict(polar=True),
    dpi=600,
)

plot_radar(
    axes[0],
    top10,
    "Top 10 abundant ARG subtypes",
    COLOR_TOP,
)

plot_radar(
    axes[1],
    bottom10,
    "Bottom 10 abundant ARG subtypes",
    COLOR_BOTTOM,
)

# 不额外添加 A/B 标注。如需 panel label，可自行取消下面注释。
# fig.text(
#     0.03,
#     0.96,
#     "A",
#     fontsize=18,
#     fontweight="bold",
#     ha="left",
#     va="top",
# )

plt.tight_layout()

fig.savefig(OUTPUT_PDF, bbox_inches="tight")
fig.savefig(
    OUTPUT_TIF,
    dpi=600,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 7. 输出路径
# =========================================================

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_SUMMARY)