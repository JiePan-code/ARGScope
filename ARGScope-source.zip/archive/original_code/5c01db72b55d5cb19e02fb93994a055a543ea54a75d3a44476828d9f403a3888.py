#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple


# ============================================================
# 1. Paths
# ============================================================

WORKDIR = Path(__file__).resolve().parent
RESULT_ROOT = WORKDIR / "BLASTN_all_reads_results"
OUTPUT_ROOT = WORKDIR / "BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt"
OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

# ============================================================
# 2. Filtering thresholds
# ============================================================

MAX_EVALUE = 1e-7
MIN_IDENTITY = 80.0
MIN_QUERY_COVERAGE = 75.0
MIN_ALIGNED_AA = 25
MIN_ALIGNED_NT = MIN_ALIGNED_AA * 3  # BLASTN uses nucleotides: 25 aa ~= 75 nt

# Save every filtered hit in addition to the one-best-hit result.
WRITE_ALL_STRICT_HITS = True

# FASTA read counts are used to calculate hit rate.
COUNT_TOTAL_READS_FROM_FASTA = True
READ_COUNT_CACHE = OUTPUT_ROOT / "fasta_read_count_cache.json"

INPUT_COLUMNS = [
    "qseqid",
    "sseqid",
    "pident",
    "length",
    "mismatch",
    "gapopen",
    "qstart",
    "qend",
    "sstart",
    "send",
    "evalue",
    "bitscore",
    "qlen",
    "slen",
]

OUTPUT_COLUMNS = INPUT_COLUMNS + ["qcov_percent"]


def load_count_cache() -> dict:
    if not READ_COUNT_CACHE.exists():
        return {}
    try:
        with READ_COUNT_CACHE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_count_cache(cache: dict) -> None:
    with READ_COUNT_CACHE.open("w", encoding="utf-8") as handle:
        json.dump(cache, handle, ensure_ascii=False, indent=2)


def count_fasta_records(fasta_path: Path, cache: dict) -> int:
    stat = fasta_path.stat()
    key = str(fasta_path.resolve())
    cached = cache.get(key)

    if (
        isinstance(cached, dict)
        and cached.get("size") == stat.st_size
        and cached.get("mtime_ns") == stat.st_mtime_ns
        and isinstance(cached.get("count"), int)
    ):
        print(f"  FASTA count cache: {cached['count']:,}")
        return cached["count"]

    count = 0
    with fasta_path.open("rb") as handle:
        for line in handle:
            if line.startswith(b">"):
                count += 1

    cache[key] = {
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "count": count,
    }
    save_count_cache(cache)
    return count


def parse_hit(fields: List[str]) -> dict:
    if len(fields) != 14:
        raise ValueError(f"expected 14 columns, found {len(fields)}")

    pident = float(fields[2])
    align_length = int(float(fields[3]))
    qstart = int(float(fields[6]))
    qend = int(float(fields[7]))
    evalue = float(fields[10])
    bitscore = float(fields[11])
    qlen = int(float(fields[12]))

    if qlen <= 0:
        raise ValueError("qlen must be > 0")

    query_span = abs(qend - qstart) + 1
    qcov = query_span / qlen * 100.0

    return {
        "fields": fields,
        "qseqid": fields[0],
        "sseqid": fields[1],
        "pident": pident,
        "align_length": align_length,
        "qstart": qstart,
        "qend": qend,
        "evalue": evalue,
        "bitscore": bitscore,
        "qlen": qlen,
        "qcov": qcov,
    }


def passes_strict_filter(hit: dict) -> bool:
    return (
        hit["evalue"] <= MAX_EVALUE
        and hit["pident"] >= MIN_IDENTITY
        and hit["qcov"] >= MIN_QUERY_COVERAGE
        and hit["align_length"] >= MIN_ALIGNED_NT
    )


def best_hit_rank(hit: dict) -> Tuple[float, float, float, float, int, str]:
    """Smaller tuple is better; final field makes ties deterministic."""
    return (
        hit["evalue"],
        -hit["bitscore"],
        -hit["pident"],
        -hit["qcov"],
        -hit["align_length"],
        hit["sseqid"],
    )


def write_hit(writer: csv.writer, hit: dict) -> None:
    writer.writerow(hit["fields"] + [f"{hit['qcov']:.4f}"])


def process_one_dataset(
    tsv_path: Path,
    total_reads: int | None,
) -> Tuple[dict, Counter]:
    sample = tsv_path.parent.name
    sample_out = OUTPUT_ROOT / sample
    sample_out.mkdir(parents=True, exist_ok=True)

    strict_all_path = sample_out / f"{sample}_strict_all_hits.tsv"
    besthit_path = sample_out / f"{sample}_strict_besthit.tsv"
    subject_count_path = sample_out / f"{sample}_strict_subject_counts.csv"

    raw_rows = 0
    strict_rows = 0
    malformed_rows = 0
    raw_query_ids = set()
    best_by_query: Dict[str, dict] = {}

    strict_handle = None
    strict_writer = None

    try:
        if WRITE_ALL_STRICT_HITS:
            strict_handle = strict_all_path.open(
                "w", encoding="utf-8", newline=""
            )
            strict_writer = csv.writer(strict_handle, delimiter="\t")
            strict_writer.writerow(OUTPUT_COLUMNS)

        with tsv_path.open("r", encoding="utf-8", errors="replace") as handle:
            reader = csv.reader(handle, delimiter="\t")

            for fields in reader:
                if not fields:
                    continue

                raw_rows += 1

                try:
                    hit = parse_hit(fields)
                except (ValueError, IndexError):
                    malformed_rows += 1
                    continue

                raw_query_ids.add(hit["qseqid"])

                if not passes_strict_filter(hit):
                    continue

                strict_rows += 1

                if strict_writer is not None:
                    write_hit(strict_writer, hit)

                old = best_by_query.get(hit["qseqid"])
                if old is None or best_hit_rank(hit) < best_hit_rank(old):
                    best_by_query[hit["qseqid"]] = hit
    finally:
        if strict_handle is not None:
            strict_handle.close()

    with besthit_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(OUTPUT_COLUMNS)
        for qseqid in sorted(best_by_query):
            write_hit(writer, best_by_query[qseqid])

    subject_counts = Counter(
        hit["sseqid"] for hit in best_by_query.values()
    )

    strict_unique = len(best_by_query)

    with subject_count_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["sseqid", "count", "percent_of_strict_reads"])
        for sseqid, count in sorted(
            subject_counts.items(), key=lambda item: (-item[1], item[0])
        ):
            percent = count / strict_unique * 100.0 if strict_unique else 0.0
            writer.writerow([sseqid, count, f"{percent:.6f}"])

    raw_unique = len(raw_query_ids)
    unmatched = (
        max(total_reads - strict_unique, 0)
        if total_reads is not None
        else None
    )
    hit_rate = (
        strict_unique / total_reads * 100.0
        if total_reads not in (None, 0)
        else None
    )

    summary = {
        "dataset": sample,
        "total_reads": total_reads,
        "raw_hit_rows": raw_rows,
        "raw_unique_hit_reads": raw_unique,
        "strict_hit_rows": strict_rows,
        "strict_unique_read_count": strict_unique,
        "strict_unmatched_reads": unmatched,
        "strict_hit_rate_percent": hit_rate,
        "malformed_rows": malformed_rows,
        "max_evalue": MAX_EVALUE,
        "min_identity_percent": MIN_IDENTITY,
        "min_query_coverage_percent": MIN_QUERY_COVERAGE,
        "min_aligned_nt": MIN_ALIGNED_NT,
        "equivalent_min_aligned_aa": MIN_ALIGNED_AA,
        "besthit_file": str(besthit_path),
    }
    return summary, subject_counts


def write_dataset_summary(rows: List[dict]) -> Path:
    output = OUTPUT_ROOT / "BLASTN_strict_dataset_count_summary.csv"
    columns = [
        "dataset",
        "total_reads",
        "raw_hit_rows",
        "raw_unique_hit_reads",
        "strict_hit_rows",
        "strict_unique_read_count",
        "strict_unmatched_reads",
        "strict_hit_rate_percent",
        "malformed_rows",
        "max_evalue",
        "min_identity_percent",
        "min_query_coverage_percent",
        "min_aligned_nt",
        "equivalent_min_aligned_aa",
        "besthit_file",
    ]

    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            formatted = dict(row)
            if formatted["strict_hit_rate_percent"] is not None:
                formatted["strict_hit_rate_percent"] = (
                    f"{formatted['strict_hit_rate_percent']:.6f}"
                )
            writer.writerow(formatted)
    return output


def write_subject_count_matrix(
    counts_by_sample: Dict[str, Counter],
) -> Path:
    output = OUTPUT_ROOT / "BLASTN_strict_subject_count_matrix.csv"
    samples = sorted(counts_by_sample)
    all_subjects = sorted(
        {
            subject
            for counter in counts_by_sample.values()
            for subject in counter
        }
    )

    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["sseqid"] + samples)
        for subject in all_subjects:
            writer.writerow(
                [subject]
                + [counts_by_sample[sample].get(subject, 0) for sample in samples]
            )
    return output


def main() -> None:
    print("=" * 100)
    print("BLASTN strict count summary")
    print("=" * 100)
    print(f"Result root             : {RESULT_ROOT}")
    print(f"Output root             : {OUTPUT_ROOT}")
    print(f"E-value                 : <= {MAX_EVALUE}")
    print(f"Identity                : >= {MIN_IDENTITY}%")
    print(f"Query coverage          : >= {MIN_QUERY_COVERAGE}%")
    print(
        f"Aligned length          : >= {MIN_ALIGNED_NT} nt "
        f"(approx. {MIN_ALIGNED_AA} aa)"
    )
    print("Count definition        : unique qseqid with at least one strict hit")
    print("Subject assignment      : one deterministic best hit per qseqid")

    if not RESULT_ROOT.exists():
        print(f"[ERROR] Result directory not found: {RESULT_ROOT}")
        sys.exit(1)

    result_files = sorted(RESULT_ROOT.glob("*/*_blastn.tsv"))
    if not result_files:
        print("[ERROR] No final *_blastn.tsv files were found.")
        sys.exit(1)

    print(f"Final result files found: {len(result_files)}")
    for path in result_files:
        print(f"  {path}")

    cache = load_count_cache()
    summaries: List[dict] = []
    counts_by_sample: Dict[str, Counter] = {}

    for index, tsv_path in enumerate(result_files, start=1):
        sample = tsv_path.parent.name
        print()
        print("-" * 100)
        print(f"[{index}/{len(result_files)}] {sample}")
        print("-" * 100)
        print(f"Input TSV: {tsv_path}")

        total_reads = None
        fasta_path = WORKDIR / f"{sample}_all_reads.fasta"
        if COUNT_TOTAL_READS_FROM_FASTA:
            if fasta_path.exists():
                total_reads = count_fasta_records(fasta_path, cache)
                print(f"  Total FASTA reads: {total_reads:,}")
            else:
                print(f"  [WARNING] FASTA not found: {fasta_path.name}")

        summary, subject_counts = process_one_dataset(tsv_path, total_reads)
        summaries.append(summary)
        counts_by_sample[sample] = subject_counts

        print(f"  Raw hit rows          : {summary['raw_hit_rows']:,}")
        print(f"  Raw unique hit reads  : {summary['raw_unique_hit_reads']:,}")
        print(f"  Strict hit rows       : {summary['strict_hit_rows']:,}")
        print(
            f"  Strict unique count   : "
            f"{summary['strict_unique_read_count']:,}"
        )
        if summary["strict_hit_rate_percent"] is not None:
            print(
                f"  Strict hit rate       : "
                f"{summary['strict_hit_rate_percent']:.6f}%"
            )
        print(f"  Malformed rows        : {summary['malformed_rows']:,}")

    summary_path = write_dataset_summary(summaries)
    matrix_path = write_subject_count_matrix(counts_by_sample)

    print()
    print("=" * 100)
    print("FINISHED")
    print("=" * 100)
    print(f"Dataset summary : {summary_path}")
    print(f"Subject matrix  : {matrix_path}")
    print()
    print("The reported count is strict_unique_read_count, not BLAST row count.")


if __name__ == "__main__":
    main()
