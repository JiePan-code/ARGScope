import random
import multiprocessing as mp
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    classification_report,
)


# ============================================================
# 1. 总配置
# ============================================================

PROJECT_ROOT = Path(".")

DATASET_DIRS = [
    "30aa",
    "30p",
    "40aa",
    "40p",
    "50aa",
    "50p",
    "60p",
    "70p",
    "80p",
]

# 固定使用 30aa 里的 train/test 划分
SPLIT_DIR = PROJECT_ROOT / "30aa"
TRAIN_SPLIT_FILE = SPLIT_DIR / "train_set_shortread.csv"
TEST_SPLIT_FILE = SPLIT_DIR / "test_set_shortread.csv"

FUSION_FILENAME = "1.60p_all_fusion_embedding_512_with_label.csv"
LONGAA_FILENAME = "2.30p_ARG_protein_with_label.csv"
PROTO_FILENAME = "5.Refined_embeddings_512.csv"

OUTPUT_ROOT = PROJECT_ROOT / "all_dataset_training_results"
OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

LABEL_COL = "Subtype"
KEY_CANDIDATES = ["Geneid", "geneid", "id", "ID", "Id", "NucleotideID", "ProteinID"]

SEED = 42

BATCH_SIZE = 256

MAX_EPOCHS_C = 300
MAX_EPOCHS_M = 300

LR_C = 3e-4
LR_M = 2e-4
WEIGHT_DECAY = 3e-5

LAMBDA_MSE = 0.10
LAMBDA_CE = 3.00
LAMBDA_PRIOR = 2.00
LAMBDA_PROTO = 0.70

SCALE = 22.0

EARLY_STOP_PATIENCE_C = 25
EARLY_STOP_PATIENCE_M = 40
MIN_DELTA = 1e-4

NUM_WORKERS = 0
PIN_MEMORY = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# ============================================================
# 2. 基础函数
# ============================================================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def get_feature_cols(df):
    exclude_cols = {
        "KEY", "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count"
    }

    cols = []
    for c in df.columns:
        if c in exclude_cols:
            continue

        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)

    return cols


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def compute_overall_metrics(y_true, y_pred):
    return {
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true)))
    }


def compute_binary_mcc_for_class(y_true, y_pred, class_id):
    y_true_bin = (y_true == class_id).astype(int)
    y_pred_bin = (y_pred == class_id).astype(int)

    if len(np.unique(y_true_bin)) == 1 and len(np.unique(y_pred_bin)) == 1:
        return 0.0

    return matthews_corrcoef(y_true_bin, y_pred_bin)


def compute_per_class_metrics(
    y_true,
    y_pred,
    class_names,
    label_name,
    split_name,
    split_sample_count,
    split_subtype_count
):
    rows = []
    present_labels = sorted(np.unique(y_true))

    for class_id in present_labels:
        class_name = class_names[class_id]

        support = int((y_true == class_id).sum())
        pred_count = int((y_pred == class_id).sum())
        correct_count = int(((y_true == class_id) & (y_pred == class_id)).sum())

        precision = precision_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        recall = recall_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        f1 = f1_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0
        )

        class_acc = correct_count / support if support > 0 else 0.0
        class_mcc = compute_binary_mcc_for_class(y_true, y_pred, class_id)

        rows.append({
            "split": split_name,
            "split_sample_count": int(split_sample_count),
            "split_subtype_count": int(split_subtype_count),
            label_name: class_name,
            "class_id": int(class_id),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct_count,
            "ACC": class_acc,
            "PRECISION": precision,
            "RECALL": recall,
            "F1": f1,
            "MCC": class_mcc
        })

    per_class_df = pd.DataFrame(rows)

    per_class_df = per_class_df.sort_values(
        by=["support", label_name],
        ascending=[False, True]
    ).reset_index(drop=True)

    return per_class_df


def build_prior_matrix(prior_df, label_col, label_encoder):
    if label_col not in prior_df.columns:
        raise ValueError(f"PROTO_FILE 缺少标签列: {label_col}")

    feat_cols = get_feature_cols(prior_df)

    if len(feat_cols) == 0:
        raise ValueError("PROTO_FILE 中没有可用数值特征列")

    tmp = prior_df.copy()
    tmp[feat_cols] = tmp[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

    grouped = tmp.groupby(label_col)[feat_cols].mean()

    prior_map = {
        str(k): grouped.loc[k].values.astype(np.float32)
        for k in grouped.index
    }

    missing = [
        lab for lab in label_encoder.classes_
        if lab not in prior_map
    ]

    if len(missing) > 0:
        raise ValueError(f"PROTO_FILE 缺少这些 subtype 的 refined prototype: {missing[:10]}")

    matrix = np.stack(
        [prior_map[lab] for lab in label_encoder.classes_],
        axis=0
    ).astype(np.float32)

    return matrix, feat_cols


# ============================================================
# 3. Loss 和模型
# ============================================================

class WeightedFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=1.5, label_smoothing=0.02):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    def forward(self, logits, targets):
        ce_loss = nn.functional.cross_entropy(
            logits,
            targets,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing
        )

        pt = torch.exp(-ce_loss)
        focal_loss = ((1.0 - pt) ** self.gamma) * ce_loss

        return focal_loss.mean()


class FusionPrototypeClassifier(nn.Module):
    def __init__(self, input_dim, proto_dim, num_classes, prototype_init=None, scale=22.0):
        super().__init__()

        self.projector = nn.Sequential(
            nn.Linear(input_dim, 768),
            nn.LayerNorm(768),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(768, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(512, proto_dim),
            nn.LayerNorm(proto_dim)
        )

        if prototype_init is not None:
            self.prototype = nn.Parameter(
                torch.tensor(prototype_init, dtype=torch.float32)
            )
        else:
            self.prototype = nn.Parameter(
                torch.randn(num_classes, proto_dim)
            )

        self.scale = scale

    def forward(self, x, return_embed=False):
        z = self.projector(x)
        z = nn.functional.normalize(z, p=2, dim=1)

        p = nn.functional.normalize(self.prototype, p=2, dim=1)
        logits = self.scale * (z @ p.t())

        if return_embed:
            return z, logits

        return logits


class LongAAToFusionMapper(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(in_dim, 1536),
            nn.LayerNorm(1536),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1536, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1024, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1024, out_dim)
        )

    def forward(self, x):
        return self.net(x)


class PriorProjector(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        if in_dim == out_dim:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.proj(x)


# ============================================================
# 4. 单个数据集训练函数
# ============================================================

def train_one_dataset(dataset_name):
    seed_everything(SEED)

    dataset_dir = PROJECT_ROOT / dataset_name
    output_dir = OUTPUT_ROOT / dataset_name
    output_dir.mkdir(parents=True, exist_ok=True)

    fusion_file = dataset_dir / FUSION_FILENAME
    longaa_file = dataset_dir / LONGAA_FILENAME
    proto_file = dataset_dir / PROTO_FILENAME

    print("\n" + "=" * 80)
    print(f"Training dataset: {dataset_name}")
    print("=" * 80)

    for f in [fusion_file, longaa_file, proto_file, TRAIN_SPLIT_FILE, TEST_SPLIT_FILE]:
        if not f.exists():
            raise FileNotFoundError(f"文件不存在: {f}")

    print("Using device:", DEVICE)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    print("Loading files...")

    fusion_df = pd.read_csv(fusion_file)
    longaa_df = pd.read_csv(longaa_file)
    train_split_df = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split_df = pd.read_csv(TEST_SPLIT_FILE)
    proto_ref = pd.read_csv(proto_file)

    print("Fusion file shape:", fusion_df.shape)
    print("LongAA file shape:", longaa_df.shape)
    print("Train split shape:", train_split_df.shape)
    print("Test split shape:", test_split_df.shape)
    print("Prototype file shape:", proto_ref.shape)

    fusion_key = find_key_col(fusion_df, KEY_CANDIDATES)
    longaa_key = find_key_col(longaa_df, KEY_CANDIDATES)
    train_key = find_key_col(train_split_df, KEY_CANDIDATES)
    test_key = find_key_col(test_split_df, KEY_CANDIDATES)

    if fusion_key is None:
        raise ValueError("FUSION_FILE 中没有找到 key 列")

    if longaa_key is None:
        raise ValueError("LONGAA_FILE 中没有找到 key 列")

    if train_key is None:
        raise ValueError("TRAIN_SPLIT_FILE 中没有找到 key 列")

    if test_key is None:
        raise ValueError("TEST_SPLIT_FILE 中没有找到 key 列")

    print(f"Detected key column in fusion file: {fusion_key}")
    print(f"Detected key column in longAA file: {longaa_key}")
    print(f"Detected key column in train split: {train_key}")
    print(f"Detected key column in test split: {test_key}")

    for df_, key_ in [
        (fusion_df, fusion_key),
        (longaa_df, longaa_key),
        (train_split_df, train_key),
        (test_split_df, test_key)
    ]:
        df_[key_] = df_[key_].astype(str).str.strip()

    for df_ in [train_split_df, test_split_df]:
        for col in ["Type", "Subtype"]:
            if col not in df_.columns:
                raise ValueError(f"划分文件缺少必要列: {col}")

            df_[col] = df_[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

    for col in ["Type", "Subtype"]:
        if col in fusion_df.columns:
            fusion_df[col] = fusion_df[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

        if col in longaa_df.columns:
            longaa_df[col] = longaa_df[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

        if col in proto_ref.columns:
            proto_ref[col] = proto_ref[col].astype(str).replace(["nan", "None", "NAN"], "Unknown")

    for df_name, df_, key_ in [
        ("fusion", fusion_df, fusion_key),
        ("longAA", longaa_df, longaa_key)
    ]:
        dup_n = df_[key_].duplicated().sum()

        if dup_n > 0:
            print(f"Warning: {df_name} file has {dup_n} duplicated keys. Keep first occurrence.")

            df_ = df_.drop_duplicates(subset=[key_], keep="first").copy()

            if df_name == "fusion":
                fusion_df = df_
            else:
                longaa_df = df_

    fusion_df = fusion_df.rename(columns={fusion_key: "KEY"})
    longaa_df = longaa_df.rename(columns={longaa_key: "KEY"})
    train_split_df = train_split_df.rename(columns={train_key: "KEY"})
    test_split_df = test_split_df.rename(columns={test_key: "KEY"})

    # =========================
    # 合并 train/test
    # =========================

    train_fusion_df = pd.merge(
        train_split_df,
        fusion_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    train_longaa_df = pd.merge(
        train_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    test_longaa_df = pd.merge(
        test_split_df,
        longaa_df,
        on="KEY",
        how="inner",
        suffixes=("_split", "")
    )

    print("\nAfter merge:")
    print("Merged train_fusion samples:", len(train_fusion_df))
    print("Merged train_longAA samples:", len(train_longaa_df))
    print("Merged test_longAA samples:", len(test_longaa_df))

    if len(train_fusion_df) == 0:
        raise ValueError("train split 与 fusion 文件合并后为空，请检查 key 是否一致。")

    if len(train_longaa_df) == 0:
        raise ValueError("train split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    if len(test_longaa_df) == 0:
        raise ValueError("test split 与 LongAA 文件合并后为空，请检查 key 是否一致。")

    for df_ in [train_fusion_df, train_longaa_df, test_longaa_df]:
        for col in ["Type", "Subtype"]:
            split_col = f"{col}_split"

            if split_col in df_.columns:
                df_[col] = df_[split_col].astype(str)

        if "Geneid" not in df_.columns:
            df_["Geneid"] = df_["KEY"].astype(str)

    common_train_keys = sorted(set(train_fusion_df["KEY"]) & set(train_longaa_df["KEY"]))

    train_fusion_df = train_fusion_df[train_fusion_df["KEY"].isin(common_train_keys)].copy()
    train_longaa_df = train_longaa_df[train_longaa_df["KEY"].isin(common_train_keys)].copy()

    train_fusion_df.sort_values("KEY", inplace=True)
    train_longaa_df.sort_values("KEY", inplace=True)

    if len(train_fusion_df) != len(train_longaa_df):
        raise ValueError("train_fusion 与 train_longAA 数量不一致")

    if not np.all(train_fusion_df["KEY"].values == train_longaa_df["KEY"].values):
        raise ValueError("train_fusion 与 train_longAA 的 KEY 未对齐")

    # =========================
    # subtype 过滤
    # =========================

    valid_subtypes_in_proto = set(proto_ref[LABEL_COL].astype(str).unique())

    train_fusion_df = train_fusion_df[
        train_fusion_df[LABEL_COL].isin(valid_subtypes_in_proto)
    ].copy()

    train_longaa_df = train_longaa_df[
        train_longaa_df[LABEL_COL].isin(valid_subtypes_in_proto)
    ].copy()

    test_longaa_df = test_longaa_df[
        test_longaa_df[LABEL_COL].isin(valid_subtypes_in_proto)
    ].copy()

    common_subtypes = (
        set(train_fusion_df[LABEL_COL].astype(str).unique())
        & set(train_longaa_df[LABEL_COL].astype(str).unique())
        & set(test_longaa_df[LABEL_COL].astype(str).unique())
        & set(proto_ref[LABEL_COL].astype(str).unique())
    )

    train_fusion_df = train_fusion_df[
        train_fusion_df[LABEL_COL].isin(common_subtypes)
    ].copy()

    train_longaa_df = train_longaa_df[
        train_longaa_df[LABEL_COL].isin(common_subtypes)
    ].copy()

    test_longaa_df = test_longaa_df[
        test_longaa_df[LABEL_COL].isin(common_subtypes)
    ].copy()

    proto_ref = proto_ref[
        proto_ref[LABEL_COL].isin(common_subtypes)
    ].copy()

    train_fusion_df.reset_index(drop=True, inplace=True)
    train_longaa_df.reset_index(drop=True, inplace=True)
    test_longaa_df.reset_index(drop=True, inplace=True)

    if len(train_fusion_df) == 0:
        raise ValueError("过滤后 train_fusion 为空")

    if len(train_longaa_df) == 0:
        raise ValueError("过滤后 train_longAA 为空")

    if len(test_longaa_df) == 0:
        raise ValueError("过滤后 test_longAA 为空")

    print("\nAfter filtering:")
    print(f"Train_fusion samples: {len(train_fusion_df)}, subtype count: {train_fusion_df[LABEL_COL].nunique()}")
    print(f"Train_longAA samples: {len(train_longaa_df)}, subtype count: {train_longaa_df[LABEL_COL].nunique()}")
    print(f"Test_longAA samples: {len(test_longaa_df)}, subtype count: {test_longaa_df[LABEL_COL].nunique()}")

    # =========================
    # LabelEncoder
    # =========================

    le = LabelEncoder()
    le.fit(sorted(train_fusion_df[LABEL_COL].astype(str).unique()))

    num_classes = len(le.classes_)
    valid_class_set = set(le.classes_)

    test_longaa_df = test_longaa_df[
        test_longaa_df[LABEL_COL].isin(valid_class_set)
    ].reset_index(drop=True)

    print(f"Classes in train_fusion: {num_classes}")
    print(f"Test_longAA after unseen-label filter: {len(test_longaa_df)}")

    if len(test_longaa_df) == 0:
        raise ValueError("test_longAA 为空")

    # =========================
    # 特征准备
    # =========================

    fusion_feature_cols = get_feature_cols(train_fusion_df)
    longaa_feature_cols = get_feature_cols(train_longaa_df)

    if len(fusion_feature_cols) == 0:
        raise ValueError("Fusion 特征列为 0")

    if len(longaa_feature_cols) == 0:
        raise ValueError("LongAA 特征列为 0")

    X_train_fusion = to_float_matrix(train_fusion_df, fusion_feature_cols)
    X_train_longaa = to_float_matrix(train_longaa_df, longaa_feature_cols)
    X_test_longaa = to_float_matrix(test_longaa_df, longaa_feature_cols)

    y_train = le.transform(train_fusion_df[LABEL_COL].astype(str).values).astype(np.int64)
    y_test = le.transform(test_longaa_df[LABEL_COL].astype(str).values).astype(np.int64)

    scaler_fusion = StandardScaler()
    scaler_longaa = StandardScaler()

    X_train_fusion_s = scaler_fusion.fit_transform(X_train_fusion).astype(np.float32)
    X_train_longaa_s = scaler_longaa.fit_transform(X_train_longaa).astype(np.float32)
    X_test_longaa_s = scaler_longaa.transform(X_test_longaa).astype(np.float32)

    input_dim_fusion = X_train_fusion_s.shape[1]
    input_dim_longaa = X_train_longaa_s.shape[1]

    print(f"Fusion feature dim: {input_dim_fusion}")
    print(f"LongAA feature dim: {input_dim_longaa}")

    prior_matrix_raw, _ = build_prior_matrix(proto_ref, LABEL_COL, le)
    prior_dim = prior_matrix_raw.shape[1]

    prior_tensor = torch.tensor(
        prior_matrix_raw,
        dtype=torch.float32,
        device=DEVICE
    )

    print(f"Refined prior dim: {prior_dim}")

    # =========================
    # DataLoader
    # =========================

    train_classifier_loader = DataLoader(
        TensorDataset(
            torch.tensor(X_train_fusion_s, dtype=torch.float32),
            torch.tensor(y_train, dtype=torch.long)
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=PIN_MEMORY,
        num_workers=NUM_WORKERS
    )

    train_mapper_loader = DataLoader(
        TensorDataset(
            torch.tensor(X_train_longaa_s, dtype=torch.float32),
            torch.tensor(X_train_fusion_s, dtype=torch.float32),
            torch.tensor(y_train, dtype=torch.long)
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=PIN_MEMORY,
        num_workers=NUM_WORKERS
    )

    # =========================
    # 模型
    # =========================

    PROTO_DIM = prior_dim

    classifier = FusionPrototypeClassifier(
        input_dim=input_dim_fusion,
        proto_dim=PROTO_DIM,
        num_classes=num_classes,
        prototype_init=prior_matrix_raw,
        scale=SCALE
    ).to(DEVICE)

    mapper = LongAAToFusionMapper(
        in_dim=input_dim_longaa,
        out_dim=input_dim_fusion
    ).to(DEVICE)

    prior_proj = PriorProjector(
        in_dim=prior_dim,
        out_dim=PROTO_DIM
    ).to(DEVICE)

    print("Classifier device:", next(classifier.parameters()).device)
    print("Mapper device:", next(mapper.parameters()).device)

    # =========================
    # Loss / Optimizer / Scheduler
    # =========================

    class_counts = np.bincount(y_train, minlength=num_classes).astype(np.float32)

    beta = 0.995
    effective_num = 1.0 - np.power(beta, class_counts)
    class_weights = (1.0 - beta) / (effective_num + 1e-8)

    class_weights = class_weights / class_weights.mean()
    class_weights = np.clip(class_weights, 0.5, 3.0)

    class_weights = torch.tensor(
        class_weights,
        dtype=torch.float32,
        device=DEVICE
    )

    criterion_ce = WeightedFocalLoss(
        weight=class_weights,
        gamma=1.5,
        label_smoothing=0.02
    )

    criterion_mse = nn.MSELoss()

    optimizer_c = optim.AdamW(
        list(classifier.parameters()) + list(prior_proj.parameters()),
        lr=LR_C,
        weight_decay=WEIGHT_DECAY
    )

    optimizer_m = optim.AdamW(
        mapper.parameters(),
        lr=LR_M,
        weight_decay=WEIGHT_DECAY
    )

    scheduler_c = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_c,
        mode="min",
        factor=0.5,
        patience=15
    )

    scheduler_m = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_m,
        mode="min",
        factor=0.5,
        patience=15
    )

    scaler_amp_c = torch.amp.GradScaler("cuda", enabled=USE_AMP)
    scaler_amp_m = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    # =========================
    # 训练 fusion classifier
    # =========================

    print("\nStarting classifier training on fusion...")

    best_loss_c = float("inf")
    no_improve_c = 0

    for epoch in range(1, MAX_EPOCHS_C + 1):
        classifier.train()
        prior_proj.train()

        total_loss = 0.0

        for xb, yb in train_classifier_loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer_c.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                loss_ce = criterion_ce(logits, yb)

                prior_proj_mat = prior_proj(prior_tensor)

                proto_now = nn.functional.normalize(
                    classifier.prototype,
                    p=2,
                    dim=1
                )

                proto_ref = nn.functional.normalize(
                    prior_proj_mat,
                    p=2,
                    dim=1
                )

                loss_proto = 1.0 - torch.mean(torch.sum(proto_now * proto_ref, dim=1))
                loss = loss_ce + LAMBDA_PROTO * loss_proto

            scaler_amp_c.scale(loss).backward()
            scaler_amp_c.unscale_(optimizer_c)

            torch.nn.utils.clip_grad_norm_(
                list(classifier.parameters()) + list(prior_proj.parameters()),
                1.0
            )

            scaler_amp_c.step(optimizer_c)
            scaler_amp_c.update()

            total_loss += loss.item() * xb.size(0)

        avg_loss = total_loss / len(train_classifier_loader.dataset)
        scheduler_c.step(avg_loss)

        if avg_loss < best_loss_c - MIN_DELTA:
            best_loss_c = avg_loss
            no_improve_c = 0
        else:
            no_improve_c += 1

        if epoch % 10 == 0 or epoch == 1 or epoch == MAX_EPOCHS_C:
            lr_now = optimizer_c.param_groups[0]["lr"]
            print(f"[Classifier] Epoch {epoch:03d} | lr={lr_now:.2e} | loss={avg_loss:.4f}")

        if no_improve_c >= EARLY_STOP_PATIENCE_C:
            print(f"[Classifier] Early stopping at epoch {epoch}, best loss={best_loss_c:.4f}")
            break

    for p in classifier.parameters():
        p.requires_grad = False

    classifier.eval()
    prior_proj.eval()

    # =========================
    # 训练 mapper
    # =========================

    print("\nStarting mapper training: LongAA -> fusion...")

    best_loss_m = float("inf")
    best_mapper_state = None
    no_improve_m = 0

    for epoch in range(1, MAX_EPOCHS_M + 1):
        mapper.train()

        total_loss = 0.0

        for xa, xf_t, yb in train_mapper_loader:
            xa = xa.to(DEVICE, non_blocking=True)
            xf_t = xf_t.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer_m.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xa)

                loss_mse = criterion_mse(xf_hat, xf_t)

                logits = classifier(xf_hat)
                loss_ce = criterion_ce(logits, yb)

                z_hat, _ = classifier(xf_hat, return_embed=True)

                prior_batch = prior_proj(prior_tensor[yb])
                prior_batch = nn.functional.normalize(prior_batch, p=2, dim=1)

                loss_prior = 1.0 - torch.mean(torch.sum(z_hat * prior_batch, dim=1))

                loss = (
                    LAMBDA_MSE * loss_mse
                    + LAMBDA_CE * loss_ce
                    + LAMBDA_PRIOR * loss_prior
                )

            scaler_amp_m.scale(loss).backward()
            scaler_amp_m.unscale_(optimizer_m)

            torch.nn.utils.clip_grad_norm_(
                mapper.parameters(),
                1.0
            )

            scaler_amp_m.step(optimizer_m)
            scaler_amp_m.update()

            total_loss += loss.item() * xa.size(0)

        avg_loss = total_loss / len(train_mapper_loader.dataset)
        scheduler_m.step(avg_loss)

        if avg_loss < best_loss_m - MIN_DELTA:
            best_loss_m = avg_loss
            best_mapper_state = {
                k: v.detach().cpu().clone()
                for k, v in mapper.state_dict().items()
            }
            no_improve_m = 0
        else:
            no_improve_m += 1

        if epoch % 10 == 0 or epoch == 1 or epoch == MAX_EPOCHS_M:
            lr_now = optimizer_m.param_groups[0]["lr"]
            print(f"[Mapper] Epoch {epoch:03d} | lr={lr_now:.2e} | loss={avg_loss:.4f}")

        if no_improve_m >= EARLY_STOP_PATIENCE_M:
            print(f"[Mapper] Early stopping at epoch {epoch}, best loss={best_loss_m:.4f}")
            break

    if best_mapper_state is not None:
        mapper.load_state_dict(best_mapper_state)
        mapper = mapper.to(DEVICE)
        print(f"Loaded best mapper state, best loss={best_loss_m:.4f}")

    mapper.eval()

    # =========================
    # 评估
    # =========================

    print("\nEvaluating...")

    with torch.no_grad():
        X_train_fusion_t = torch.tensor(
            X_train_fusion_s,
            dtype=torch.float32
        ).to(DEVICE)

        X_test_longaa_t = torch.tensor(
            X_test_longaa_s,
            dtype=torch.float32
        ).to(DEVICE)

        logits_train = classifier(X_train_fusion_t)
        y_pred_train = logits_train.argmax(dim=1).cpu().numpy()

        xf_test_hat = mapper(X_test_longaa_t)
        logits_test = classifier(xf_test_hat)
        y_pred_test = logits_test.argmax(dim=1).cpu().numpy()

    train_metrics = compute_overall_metrics(y_train, y_pred_train)
    test_metrics = compute_overall_metrics(y_test, y_pred_test)

    print("\n=== TRAIN_SET RESULT | fusion -> classifier ===")

    for k, v in train_metrics.items():
        if isinstance(v, float):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")

    print("\n=== TEST_SET RESULT | longAA -> mapper -> fusion -> classifier ===")

    for k, v in test_metrics.items():
        if isinstance(v, float):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")

    print("\n=== Classification Report (test_set) ===")
    report_text = classification_report(
        y_true=le.inverse_transform(y_test),
        y_pred=le.inverse_transform(y_pred_test),
        zero_division=0,
        digits=4
    )
    print(report_text)

    # =========================
    # 保存输出
    # =========================

    overall_df = pd.DataFrame([
        {
            "dataset": dataset_name,
            "split": "train_set",
            "sample_count": train_metrics["sample_count"],
            "subtype_count": train_metrics["subtype_count"],
            "ACC": train_metrics["ACC"],
            "WEIGHTED_PRECISION": train_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": train_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": train_metrics["WEIGHTED_F1"],
            "MCC": train_metrics["MCC"]
        },
        {
            "dataset": dataset_name,
            "split": "test_set",
            "sample_count": test_metrics["sample_count"],
            "subtype_count": test_metrics["subtype_count"],
            "ACC": test_metrics["ACC"],
            "WEIGHTED_PRECISION": test_metrics["WEIGHTED_PRECISION"],
            "WEIGHTED_RECALL": test_metrics["WEIGHTED_RECALL"],
            "WEIGHTED_F1": test_metrics["WEIGHTED_F1"],
            "MCC": test_metrics["MCC"]
        }
    ])

    overall_df = overall_df.round(4)

    overall_df.to_csv(
        output_dir / "subtype_overall_metrics_weighted.csv",
        index=False,
        encoding="utf-8-sig"
    )

    per_class_train_df = compute_per_class_metrics(
        y_true=y_train,
        y_pred=y_pred_train,
        class_names=le.classes_,
        label_name=LABEL_COL,
        split_name="train_set",
        split_sample_count=len(y_train),
        split_subtype_count=len(np.unique(y_train))
    )

    per_class_test_df = compute_per_class_metrics(
        y_true=y_test,
        y_pred=y_pred_test,
        class_names=le.classes_,
        label_name=LABEL_COL,
        split_name="test_set",
        split_sample_count=len(y_test),
        split_subtype_count=len(np.unique(y_test))
    )

    per_class_df = pd.concat(
        [per_class_train_df, per_class_test_df],
        axis=0,
        ignore_index=True
    )

    per_class_df.insert(0, "dataset", dataset_name)
    per_class_df = per_class_df.round(4)

    per_class_df.to_csv(
        output_dir / "subtype_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pred_df = test_longaa_df[["KEY", "Type", "Subtype"]].copy()
    pred_df["Pred_Subtype"] = le.inverse_transform(y_pred_test)
    pred_df.insert(0, "dataset", dataset_name)

    pred_df.to_csv(
        output_dir / "subtype_test_predictions_protein.csv",
        index=False,
        encoding="utf-8-sig"
    )

    with open(output_dir / "classification_report_test.txt", "w", encoding="utf-8") as f:
        f.write(report_text)

    print("\n结果已保存到：", output_dir)

    return {
        "dataset": dataset_name,
        "status": "success",
        "train_sample_count": train_metrics["sample_count"],
        "test_sample_count": test_metrics["sample_count"],
        "train_subtype_count": train_metrics["subtype_count"],
        "test_subtype_count": test_metrics["subtype_count"],
        "test_ACC": test_metrics["ACC"],
        "test_WEIGHTED_PRECISION": test_metrics["WEIGHTED_PRECISION"],
        "test_WEIGHTED_RECALL": test_metrics["WEIGHTED_RECALL"],
        "test_WEIGHTED_F1": test_metrics["WEIGHTED_F1"],
        "test_MCC": test_metrics["MCC"],
    }


# ============================================================
# 5. 主循环
# ============================================================

def main():
    print("Using device:", DEVICE)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    summary_rows = []
    failed_rows = []

    for dataset_name in DATASET_DIRS:
        try:
            result = train_one_dataset(dataset_name)
            summary_rows.append(result)

            # 每个数据集结束后清理显存
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        except Exception as e:
            print("\n" + "!" * 80)
            print(f"Dataset failed: {dataset_name}")
            print("Error:", repr(e))
            print("!" * 80)

            failed_rows.append({
                "dataset": dataset_name,
                "error": repr(e)
            })

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    if len(summary_rows) > 0:
        summary_df = pd.DataFrame(summary_rows)
        summary_df = summary_df.round(4)
        summary_df.to_csv(
            OUTPUT_ROOT / "all_dataset_summary.csv",
            index=False,
            encoding="utf-8-sig"
        )

        print("\nAll dataset summary:")
        print(summary_df)

    if len(failed_rows) > 0:
        failed_df = pd.DataFrame(failed_rows)
        failed_df.to_csv(
            OUTPUT_ROOT / "failed_datasets.csv",
            index=False,
            encoding="utf-8-sig"
        )

        print("\nFailed datasets:")
        print(failed_df)

    print("\n全部数据集训练完成。")
    print("总输出目录:", OUTPUT_ROOT)


if __name__ == "__main__":
    mp.freeze_support()
    main()