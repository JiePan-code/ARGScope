import pandas as pd


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def expand_split_to_shortread(
    original_train_file="train_set.csv",
    original_test_file="test_set.csv",
    key_candidates=("id", "ID", "Id", "Geneid", "geneid", "NucleotideID", "ProteinID"),
    repeat_times=5,
    train_output="train_set_type_shortread.csv",
    test_output="test_set_type_shortread.csv"
):
    # =========================
    # 1. 读取原始 train / test
    # =========================
    train_df = pd.read_csv(original_train_file).copy()
    test_df = pd.read_csv(original_test_file).copy()

    train_key = find_key_col(train_df, key_candidates)
    test_key = find_key_col(test_df, key_candidates)

    if train_key is None:
        raise ValueError(f"train 文件中找不到 ID 列，候选列为: {key_candidates}")

    if test_key is None:
        raise ValueError(f"test 文件中找不到 ID 列，候选列为: {key_candidates}")

    print("Train key column:", train_key)
    print("Test key column:", test_key)

    train_df[train_key] = train_df[train_key].astype(str)
    test_df[test_key] = test_df[test_key].astype(str)

    # =========================
    # 2. 扩增函数
    # =========================
    def expand_df(df, key_col, repeat_times):
        expanded_parts = []

        for i in range(1, repeat_times + 1):
            tmp = df.copy()
            tmp[key_col] = tmp[key_col].astype(str) + f"_{i}"
            tmp["Shortread_index"] = i
            expanded_parts.append(tmp)

        expanded_df = pd.concat(expanded_parts, ignore_index=True)
        return expanded_df

    # =========================
    # 3. 分别扩增 train / test
    # =========================
    train_short = expand_df(train_df, train_key, repeat_times)
    test_short = expand_df(test_df, test_key, repeat_times)

    # =========================
    # 4. 保存
    # =========================
    train_short.to_csv(train_output, index=False, encoding="utf-8-sig")
    test_short.to_csv(test_output, index=False, encoding="utf-8-sig")

    # =========================
    # 5. 输出统计
    # =========================
    print("\n扩增完成")
    print(f"原始 train 样本数: {len(train_df)}")
    print(f"扩增后 train 样本数: {len(train_short)}")

    print(f"\n原始 test 样本数: {len(test_df)}")
    print(f"扩增后 test 样本数: {len(test_short)}")

    print(f"\n扩增倍数: {repeat_times}")

    if "Subtype" in train_df.columns:
        print("\nTrain subtype 数:")
        print("原始:", train_df["Subtype"].nunique())
        print("扩增后:", train_short["Subtype"].nunique())

    if "Subtype" in test_df.columns:
        print("\nTest subtype 数:")
        print("原始:", test_df["Subtype"].nunique())
        print("扩增后:", test_short["Subtype"].nunique())

    print(f"\n已保存扩增 train: {train_output}")
    print(f"已保存扩增 test: {test_output}")

    return train_short, test_short


# =========================
# 执行
# =========================
expand_split_to_shortread(
    original_train_file="train_set.csv",
    original_test_file="test_set.csv",
    repeat_times=5,
    train_output="train_set_subtype_shortread.csv",
    test_output="test_set_subtype_shortread.csv"
)