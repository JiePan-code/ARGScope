# -*- coding: utf-8 -*-
from __future__ import annotations

"""
不看平均指标，而是逐个数据集比较 30 个 ARGScope 组合 与 3 个外部方法。

输出两类图：
1) 3 张差值热图 + 3 张绝对差值热图
   - 行：9 个数据集
   - 列：30 个配置（DIAMOND × gate）
   - 值：
       差值热图 = ARGScope_count - external_count
       绝对差值热图 = |ARGScope_count - external_count|

2) 9 张单数据集配置图
   - 每个数据集一张
   - 30根柱子分别使用30种不同颜色
   - 3 条水平线：DeepARG_ss（红）/ DeepARG_short（橙）/ ARG-OAP 3（绿）

默认根目录：
E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed
"""

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE_DIR = Path(
    r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed"
)
EXTERNAL_FILE = BASE_DIR / "DeepARG_ARGOAP.csv"

GATE_FOLDERS: Dict[float, str] = {
    0.10: "ARGScope_DIAMOND_gate010_realdata_predictions",
    0.20: "ARGScope_DIAMOND_gate020_realdata_predictions",
    0.30: "ARGScope_DIAMOND_gate030_realdata_predictions",
    0.40: "ARGScope_DIAMOND_gate040_realdata_predictions",
    0.50: "ARGScope_DIAMOND_gate050_realdata_predictions",
}
DIAMOND_THRESHOLDS = ["0.2", "0.5", "0.6", "0.7", "0.8", "0.9"]

MATRIX_FILE_NAME = "all_thresholds_final_ARG_count_matrix.csv"
SUMMARY_FILE_NAME = "sample_summary.csv"

OUTPUT_DIR = BASE_DIR / "ARGScope_vs_external_no_average_plots"
PER_SAMPLE_DIR = OUTPUT_DIR / "per_sample"
DIFF_HEATMAP_DIR = OUTPUT_DIR / "difference_heatmaps"
ABS_DIFF_HEATMAP_DIR = OUTPUT_DIR / "absolute_difference_heatmaps"
DPI = 300


def natural_key(text: str) -> Tuple:
    parts = re.split(r"(\d+)", str(text))
    return tuple(int(p) if p.isdigit() else p.lower() for p in parts)


def normalize_sample_name(value: object) -> str:
    text = str(value).strip()
    replacements = {
        "ARGbert": "argbert",
        "Argbert": "argbert",
        "ARGscope": "argscope",
        "Argscope": "argscope",
        "ARGScope": "argscope",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.lower()


def normalize_diamond(value: object) -> str:
    text = str(value).strip().replace("diamond", "")
    return f"{float(text):.1f}"


def normalize_sample_column(df: pd.DataFrame, source_file: Path) -> pd.DataFrame:
    candidates = ["sample_name", "Sample", "sample", "dataset", "Dataset", "Type"]
    sample_column = next((c for c in candidates if c in df.columns), None)
    if sample_column is None:
        first_column = df.columns[0]
        if not str(first_column).startswith("final_ARG_count_diamond"):
            sample_column = first_column
    if sample_column is None:
        raise ValueError(f"无法识别样品列：{source_file}\n现有列：{list(df.columns)}")
    return df.rename(columns={sample_column: "sample_name"})


def extract_diamond_from_column(column_name: str) -> Optional[str]:
    match = re.search(r"(?:final_ARG_count_)?diamond(\d+(?:\.\d+)?)$", str(column_name))
    if not match:
        return None
    return normalize_diamond(match.group(1))


def ordered_combinations() -> List[Tuple[float, str]]:
    return [(gate, diamond) for diamond in DIAMOND_THRESHOLDS for gate in sorted(GATE_FOLDERS)]


def combination_label(gate: float, diamond: str) -> str:
    return f"D{diamond}\nG{gate:.1f}"


def read_one_sample_summary(gate_threshold: float, diamond_threshold: str, summary_file: Path) -> pd.DataFrame:
    df = pd.read_csv(summary_file, encoding="utf-8-sig")
    df = normalize_sample_column(df, summary_file)
    if "final_ARG_count" not in df.columns:
        raise ValueError(f"{summary_file} 中没有 final_ARG_count 列。")

    out = pd.DataFrame({
        "sample_name": df["sample_name"].map(normalize_sample_name),
        "ARG_count": pd.to_numeric(df["final_ARG_count"], errors="coerce"),
    })
    out["gate_threshold"] = float(gate_threshold)
    out["diamond_threshold"] = normalize_diamond(diamond_threshold)
    out = out.dropna(subset=["sample_name", "ARG_count"]).copy()
    out["ARG_count"] = out["ARG_count"].astype(int)
    return out[["gate_threshold", "diamond_threshold", "sample_name", "ARG_count"]]


def read_matrix_fallback(gate_threshold: float, matrix_file: Path) -> pd.DataFrame:
    df = pd.read_csv(matrix_file, encoding="utf-8-sig")
    df = normalize_sample_column(df, matrix_file)
    df = df[df["sample_name"].notna()].copy()
    df["sample_name"] = df["sample_name"].map(normalize_sample_name)

    count_columns = []
    column_to_diamond = {}
    for column in df.columns:
        diamond = extract_diamond_from_column(column)
        if diamond is not None:
            count_columns.append(column)
            column_to_diamond[column] = diamond

    if not count_columns:
        return pd.DataFrame(columns=["gate_threshold", "diamond_threshold", "sample_name", "ARG_count"])

    long_df = df.melt(
        id_vars=["sample_name"],
        value_vars=count_columns,
        var_name="source_column",
        value_name="ARG_count",
    )
    long_df["diamond_threshold"] = long_df["source_column"].map(column_to_diamond)
    long_df["gate_threshold"] = float(gate_threshold)
    long_df["ARG_count"] = pd.to_numeric(long_df["ARG_count"], errors="coerce")
    long_df = long_df.dropna(subset=["sample_name", "diamond_threshold", "ARG_count"]).copy()
    long_df["ARG_count"] = long_df["ARG_count"].astype(int)
    return long_df[["gate_threshold", "diamond_threshold", "sample_name", "ARG_count"]]


def collect_argscope_results() -> pd.DataFrame:
    records: List[pd.DataFrame] = []
    for gate_threshold, folder_name in sorted(GATE_FOLDERS.items()):
        gate_dir = BASE_DIR / folder_name
        if not gate_dir.is_dir():
            print(f"[WARNING] gate目录不存在：{gate_dir}", flush=True)
            continue

        gate_list = []
        for diamond_threshold in DIAMOND_THRESHOLDS:
            summary_file = gate_dir / f"diamond{diamond_threshold}" / SUMMARY_FILE_NAME
            if summary_file.is_file():
                print(f"[READ SUMMARY] gate={gate_threshold:.2f}, diamond={diamond_threshold} | {summary_file}", flush=True)
                gate_list.append(read_one_sample_summary(gate_threshold, diamond_threshold, summary_file))

        if gate_list:
            gate_df = pd.concat(gate_list, ignore_index=True)
        else:
            gate_df = pd.DataFrame(columns=["gate_threshold", "diamond_threshold", "sample_name", "ARG_count"])

        matrix_file = gate_dir / MATRIX_FILE_NAME
        if matrix_file.is_file():
            matrix_df = read_matrix_fallback(gate_threshold, matrix_file)
            if not matrix_df.empty:
                gate_df = pd.concat([gate_df, matrix_df], ignore_index=True)
                gate_df = gate_df.drop_duplicates(
                    subset=["gate_threshold", "diamond_threshold", "sample_name"],
                    keep="first",
                )

        records.append(gate_df)

    if not records:
        raise FileNotFoundError("没有读取到任何 ARGScope 结果。")

    combined = pd.concat(records, ignore_index=True)
    combined = combined.dropna().copy()
    combined["gate_threshold"] = combined["gate_threshold"].astype(float)
    combined["diamond_threshold"] = combined["diamond_threshold"].map(normalize_diamond)
    combined["sample_name"] = combined["sample_name"].map(normalize_sample_name)
    combined["ARG_count"] = pd.to_numeric(combined["ARG_count"], errors="coerce")
    combined = combined.dropna(subset=["ARG_count"]).copy()
    combined["ARG_count"] = combined["ARG_count"].astype(int)
    combined = combined.drop_duplicates(
        subset=["gate_threshold", "diamond_threshold", "sample_name"],
        keep="first",
    )
    return combined


def read_external_results() -> pd.DataFrame:
    if not EXTERNAL_FILE.is_file():
        raise FileNotFoundError(f"找不到外部结果文件：{EXTERNAL_FILE}")

    df = pd.read_csv(EXTERNAL_FILE, encoding="utf-8-sig")
    df = normalize_sample_column(df, EXTERNAL_FILE)

    required_cols = ["DeepARG_Count", "DeepARG_short", "ARG-OAP 3"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"{EXTERNAL_FILE} 缺少列：{missing}")

    out = df[["sample_name"] + required_cols].copy()
    out["sample_name"] = out["sample_name"].map(normalize_sample_name)
    out = out.rename(columns={"DeepARG_Count": "DeepARG_ss"})
    for col in ["DeepARG_ss", "DeepARG_short", "ARG-OAP 3"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna().copy()
    return out


def build_complete_table(argscope_df: pd.DataFrame, external_df: pd.DataFrame) -> pd.DataFrame:
    samples = sorted(external_df["sample_name"].unique(), key=natural_key)
    expected = pd.MultiIndex.from_product(
        [sorted(GATE_FOLDERS), DIAMOND_THRESHOLDS, samples],
        names=["gate_threshold", "diamond_threshold", "sample_name"],
    ).to_frame(index=False)

    complete = expected.merge(
        argscope_df,
        on=["gate_threshold", "diamond_threshold", "sample_name"],
        how="left",
    )
    missing = complete[complete["ARG_count"].isna()].copy()
    if not missing.empty:
        missing_file = OUTPUT_DIR / "missing_combinations.csv"
        missing.to_csv(missing_file, index=False, encoding="utf-8-sig")
        print(f"[WARNING] 有 {len(missing)} 个缺失组合，已输出：{missing_file}", flush=True)

    merged = complete.merge(external_df, on="sample_name", how="left")
    return merged


def annotate_heatmap(axis, matrix: np.ndarray) -> None:
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            value = matrix[i, j]
            text = "NA" if not np.isfinite(value) else f"{int(round(value))}"
            axis.text(j, i, text, ha="center", va="center", fontsize=7)


def plot_difference_heatmap(merged_df: pd.DataFrame, method: str, absolute: bool = False) -> None:
    combinations = ordered_combinations()
    combination_labels = [combination_label(g, d) for g, d in combinations]

    plot_df = merged_df.copy()
    plot_df["difference"] = plot_df["ARG_count"] - plot_df[method]
    if absolute:
        plot_df["difference"] = plot_df["difference"].abs()

    plot_df["combination"] = plot_df.apply(
        lambda row: combination_label(float(row["gate_threshold"]), str(row["diamond_threshold"])),
        axis=1,
    )

    samples = sorted(plot_df["sample_name"].dropna().unique(), key=natural_key)
    pivot = plot_df.pivot(index="sample_name", columns="combination", values="difference")
    pivot = pivot.reindex(index=samples, columns=combination_labels)
    matrix = pivot.to_numpy(dtype=float)

    fig, axis = plt.subplots(figsize=(18, 6.5))
    image = axis.imshow(matrix, aspect="auto")

    axis.set_xticks(np.arange(len(combination_labels)))
    axis.set_xticklabels(combination_labels, fontsize=8)
    axis.set_yticks(np.arange(len(samples)))
    axis.set_yticklabels(samples)
    axis.set_xlabel("30 ARGScope configurations")
    axis.set_ylabel("9 datasets")
    title_prefix = "Absolute difference" if absolute else "Difference"
    axis.set_title(
        f"{title_prefix} heatmap: ARGScope - {method}\nRows = datasets, Columns = 30 configurations"
    )

    annotate_heatmap(axis, matrix)
    colorbar = fig.colorbar(image, ax=axis)
    colorbar.set_label("Absolute difference" if absolute else "Difference")

    fig.tight_layout()
    safe_method = method.replace(" ", "_").replace("-", "_")
    out_dir = ABS_DIFF_HEATMAP_DIR if absolute else DIFF_HEATMAP_DIR
    filename = (
        f"absolute_difference_heatmap_vs_{safe_method}.png"
        if absolute else
        f"difference_heatmap_vs_{safe_method}.png"
    )
    fig.savefig(out_dir / filename, dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def plot_one_sample_profile(merged_df: pd.DataFrame, sample_name: str) -> None:
    subset = merged_df[merged_df["sample_name"] == sample_name].copy()
    combinations = ordered_combinations()
    labels = [combination_label(g, d) for g, d in combinations]

    lookup = {
        (float(row["gate_threshold"]), str(row["diamond_threshold"])): row["ARG_count"]
        for _, row in subset.iterrows()
    }
    values = [lookup.get((gate, diamond), np.nan) for gate, diamond in combinations]

    ext_row = subset[["DeepARG_ss", "DeepARG_short", "ARG-OAP 3"]].dropna().head(1)
    if ext_row.empty:
        return
    ext_row = ext_row.iloc[0]

    x = np.arange(len(combinations))
    fig, axis = plt.subplots(figsize=(18, 6.5))

    # 为30种 gate × DIAMOND 配置分配30种不同颜色。
    # 颜色顺序与横轴配置顺序完全一致。
    bar_colors = plt.cm.turbo(
        np.linspace(
            0.03,
            0.97,
            len(combinations),
        )
    )

    axis.bar(
        x,
        values,
        color=bar_colors,
        edgecolor="black",
        linewidth=0.35,
    )
    axis.axhline(
        ext_row["DeepARG_ss"],
        color="#D62728",
        linestyle="--",
        linewidth=2.2,
        label="DeepARG_ss",
    )
    axis.axhline(
        ext_row["DeepARG_short"],
        color="#FF7F0E",
        linestyle=":",
        linewidth=2.6,
        label="DeepARG_short",
    )
    axis.axhline(
        ext_row["ARG-OAP 3"],
        color="#2CA02C",
        linestyle="-.",
        linewidth=2.2,
        label="ARG-OAP 3",
    )

    for sep in [4.5, 9.5, 14.5, 19.5, 24.5]:
        axis.axvline(sep, linewidth=0.8, alpha=0.35)

    axis.set_xticks(x)
    axis.set_xticklabels(labels, fontsize=8)
    axis.set_xlabel("30 ARGScope configurations")
    axis.set_ylabel("ARG count")
    axis.set_title(f"{sample_name}: 30 ARGScope configurations vs external methods")
    axis.ticklabel_format(style="plain", axis="y")
    axis.grid(True, axis="y", alpha=0.25)
    axis.legend(ncol=3, frameon=False)

    fig.tight_layout()
    fig.savefig(PER_SAMPLE_DIR / f"{sample_name}_30_configurations_vs_external.png", dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    print("=" * 88)
    print("逐个数据集、逐个配置，对比 ARGScope 与外部方法（不做平均）")
    print(f"Base directory: {BASE_DIR}")
    print(f"External file : {EXTERNAL_FILE}")
    print("=" * 88, flush=True)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    PER_SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    DIFF_HEATMAP_DIR.mkdir(parents=True, exist_ok=True)
    ABS_DIFF_HEATMAP_DIR.mkdir(parents=True, exist_ok=True)

    argscope_df = collect_argscope_results()
    external_df = read_external_results()
    merged_df = build_complete_table(argscope_df, external_df)

    for method in ["DeepARG_ss", "DeepARG_short", "ARG-OAP 3"]:
        print(f"[PLOT] difference heatmap vs {method}", flush=True)
        plot_difference_heatmap(merged_df, method, absolute=False)
        print(f"[PLOT] absolute difference heatmap vs {method}", flush=True)
        plot_difference_heatmap(merged_df, method, absolute=True)

    samples = sorted(external_df["sample_name"].unique(), key=natural_key)
    for idx, sample_name in enumerate(samples, start=1):
        print(f"[PLOT {idx}/{len(samples)}] {sample_name}", flush=True)
        plot_one_sample_profile(merged_df, sample_name)

    print("-" * 88)
    print("绘图完成。")
    print(f"输出目录：{OUTPUT_DIR}")
    print(f"单数据集图：{PER_SAMPLE_DIR}")
    print(f"差值热图：{DIFF_HEATMAP_DIR}")
    print(f"绝对差值热图：{ABS_DIFF_HEATMAP_DIR}")
    print("-" * 88)


if __name__ == "__main__":
    main()
