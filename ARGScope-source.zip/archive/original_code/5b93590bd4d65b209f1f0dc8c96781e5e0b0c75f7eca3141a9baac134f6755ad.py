"""Report positive-class binary metrics, leaving multiclass results unchanged."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import math
import shutil
import xml.etree.ElementTree as ET

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT = Path(__file__).resolve().parent
OLD = ROOT/'outputs/vf_bgc_including_negative_20260922'
OUT = ROOT/'outputs/vf_bgc_binary_positive_20260922'
DELIVERY = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/VF_BGC_含非目标类_透明SVG_20260922')
METRICS = ['ACC','Precision','Recall','F1','MCC']
COLORS = {'AA':'#397E9C','NT':'#D69A52'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    with path.open('w',encoding='utf-8-sig',newline='') as handle:
        writer = csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def radar(domain, rows):
    theta = np.linspace(0,2*np.pi,5,endpoint=False)
    angles = np.r_[theta,theta[0]]
    fig = plt.figure(figsize=(6,6.1),facecolor='none')
    ax = fig.add_axes([.16,.18,.68,.66],projection='polar',facecolor='none')
    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    for mod in ['AA','NT']:
        row = next(r for r in rows if r['Model'] == f'{domain}Scope-{mod}')
        values = [row[metric] for metric in METRICS]
        line, = ax.plot(angles,values+[values[0]],color=COLORS[mod],lw=2.1,
                        linestyle='-' if mod=='AA' else '--',
                        marker='o' if mod=='AA' else 's',ms=4.5)
        np.testing.assert_allclose(line.get_ydata()[:-1],values,rtol=0,atol=0)
        ax.fill(angles,values+[values[0]],color=COLORS[mod],alpha=.07)
    ax.set_xticks(theta,METRICS,fontsize=14)
    ax.tick_params(axis='x',pad=7)
    for label, alignment in zip(ax.get_xticklabels(), ['center','left','left','right','right']):
        label.set_horizontalalignment(alignment)
    ax.set_yticks([.25,.5,.75,1],['0.25','0.50','0.75','1.00'],fontsize=10,color='#737B82')
    ax.set_rlabel_position(55)
    ax.set_ylim(0,1)
    ax.grid(color='#DDE2E6',lw=.7)
    ax.spines['polar'].set_color('#9DA7AD')
    ax.set_title(f'{domain}/non-{domain}',pad=21,fontsize=16)
    handles = [Patch(facecolor=COLORS[mod],edgecolor='#4A5661',lw=.55,
                     hatch='--' if mod=='AA' else '//',
                     label='AA (protein)' if mod=='AA' else 'NT (DNA)') for mod in ['AA','NT']]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.045),
               ncol=2,frameon=False,fontsize=12)
    panel = 'A' if domain=='VF' else 'C'
    name = f'Figure5{panel}_{domain}_binary_positive_radar'
    options = dict(bbox_inches='tight',pad_inches=.025,transparent=True)
    with plt.rc_context({'svg.fonttype':'path'}):
        fig.savefig(OUT/(name+'.svg'),**options)
    with plt.rc_context({'svg.fonttype':'none'}):
        fig.savefig(OUT/'editable_text'/(name+'.svg'),**options)
    fig.savefig(OUT/'previews'/(name+'.png'),dpi=170,bbox_inches='tight',pad_inches=.025,
                transparent=False,facecolor='white')
    plt.close(fig)
    for relative in [Path(name+'.svg'),Path('editable_text')/(name+'.svg')]:
        tree = ET.parse(OUT/relative)
        assert not tree.findall('.//{http://www.w3.org/2000/svg}image')
    return name


def main():
    for sub in ['', 'data', 'editable_text', 'previews']:
        (OUT/sub).mkdir(parents=True,exist_ok=True)
    font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':13,'axes.linewidth':.9,
                         'hatch.linewidth':.4,'svg.hashsalt':'vf-bgc-binary-positive'})
    previous = json.loads((OLD/'verification.json').read_text(encoding='utf-8'))
    input_csv = OLD/'data/all_averages_including_negative.csv'
    all_old = read_csv(input_csv)
    immutable = {str(input_csv):sha(input_csv), **previous['Protected_documents']}
    binary, counts, details = {}, [], []
    for source in previous['Population_audit']:
        model = source['Model']
        domain = 'VF' if model.startswith('VF') else 'BGC'
        negative = 'non-VF' if domain=='VF' else 'nonBGC'
        path = Path(source['Source'])
        assert sha(path) == source['SHA256']
        immutable[str(path)] = source['SHA256']
        frame = read_csv(path)
        assert len(frame) == source['N'] == len({r['id'] for r in frame})
        assert {r['split'] for r in frame} == {'test'}
        truth, pred = [], []
        for row in frame:
            assert row['true_binary'] in [domain,negative]
            assert row['predicted_binary'] in [domain,negative]
            for side in ['true','predicted']:
                assert (row[side+'_binary']==negative) == (row[side+'_type']==negative)
                assert (row[side+'_binary']==negative) == (row[side+'_subtype']==negative)
            truth.append(int(row['true_binary']==domain))
            pred.append(int(row['predicted_binary']==domain))
        tally = Counter(zip(truth,pred))
        tp,fn,fp,tn = [tally[pair] for pair in [(1,1),(1,0),(0,1),(0,0)]]
        assert fn==source['False_negative'] and fp==source['False_positive']
        p,r,f = tp/(tp+fp),tp/(tp+fn),2*tp/(2*tp+fp+fn)
        acc = (tp+tn)/len(frame)
        mcc = (tp*tn-fp*fn)/math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
        ref = precision_recall_fscore_support(truth,pred,average='binary',pos_label=1,zero_division=0)
        np.testing.assert_allclose([acc,p,r,f,mcc],
                                  [accuracy_score(truth,pred),*ref[:3],matthews_corrcoef(truth,pred)],
                                  rtol=0,atol=1e-12)
        template = next(row for row in all_old if row['Model']==model and
                        row['Task']=='Binary' and row['Average']=='macro')
        assert abs(acc-float(template['ACC']))<1e-12
        assert abs(mcc-float(template['MCC']))<1e-12
        result = {**template,'Average':'binary','ACC':acc,'MCC':mcc,
                  'Precision':p,'Recall':r,'F1':f}
        binary[model] = result
        counts.append({'Domain':domain,'Model':model,'Positive':domain,'Negative':negative,
                       'N':len(frame),'TP':tp,'FP':fp,'FN':fn,'TN':tn})
        details.append({**counts[-1],'Source':str(path),'SHA256':source['SHA256'],
                        'ACC':acc,'Precision':p,'Recall':r,'F1':f,'MCC':mcc})
    updated = []
    for old in all_old:
        if old['Task'] != 'Binary':
            updated.append(old.copy())
        elif old['Average'] == 'macro':
            updated.append(binary[old['Model']])
    assert len(updated)==28
    assert [r for r in updated if r['Task']!='Binary']==[r for r in all_old if r['Task']!='Binary']
    assert sum(r['Task']=='Binary' for r in updated)==4
    main_rows = [r for r in updated if r['Task']=='Binary' or r['Average']=='macro']
    write_csv(OUT/'data/all_metrics_binary_positive.csv',updated)
    write_csv(OUT/'data/S19_S20_binary_positive_type_subtype_macro.csv',main_rows)
    write_csv(OUT/'data/binary_positive_metrics.csv',list(binary.values()))
    write_csv(OUT/'data/binary_confusion_counts.csv',counts)
    typed = [{k:int(v) if k in ['N','N_labels'] else float(v) if k in METRICS else v
              for k,v in row.items()} for row in updated]
    (OUT/'table_data.json').write_text(json.dumps(typed,ensure_ascii=False,indent=2),encoding='utf-8')
    names = [radar(domain,list(binary.values())) for domain in ['VF','BGC']]
    assert all(sha(Path(path))==value for path,value in immutable.items())
    audit = {'Binary_definition':'VF or BGC = 1, non-VF or nonBGC = 0',
             'Binary_averaging':'positive class only', 'Binary_rows':4,'Total_rows':28,
             'Type_Subtype_rows_unchanged':True,'ACC_MCC_unchanged':True,
             'Sources_and_documents_unmodified':True,'models':details}
    (OUT/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    paths = [p.relative_to(OUT) for p in (OUT/'data').glob('*.csv')]
    paths += [Path(name+'.svg') for name in names]
    paths += [Path('editable_text')/(name+'.svg') for name in names]
    paths += [Path('previews')/(name+'.png') for name in names]
    for relative in paths:
        dest = DELIVERY/relative
        # These unique filenames are owned by this correction run.
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(OUT/relative,dest)
        assert sha(dest)==sha(OUT/relative)
    print(json.dumps(details,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
