#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import math
import re
import warnings
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from matplotlib.lines import Line2D

try:
    import umap
except ImportError as exc:
    raise ImportError(
        "umap-learn is not installed. Run: pip install umap-learn matplotlib"
    ) from exc

try:
    from sklearn.decomposition import PCA
except Exception:
    PCA = None


# =============================================================================
# 1. User settings
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
INPUT_DIR = SCRIPT_DIR
OUTPUT_DIR = SCRIPT_DIR / "Protein_100pct_epoch_UMAP_figures"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

REGULAR_EPOCHS = [0, 20, 50, 100, 150]
INCLUDE_RUN_BEST = True
REQUIRE_ALL_REGULAR_EPOCHS = True

# ---------- UMAP tuning for clearer Type separation ----------
# Compared with the old version, this version makes clustering more visible by:
# 1) standardizing features,
# 2) optional PCA denoising before UMAP,
# 3) using smaller min_dist,
# 4) optionally using mild Type-guided UMAP.
RANDOM_STATE = 42
APPLY_FEATURE_STANDARDIZATION = True
APPLY_PCA_BEFORE_UMAP = True
PCA_COMPONENTS = 20
USE_TYPE_GUIDED_UMAP = True
TYPE_GUIDED_TARGET_WEIGHT = 0.28

UMAP_PARAMS = dict(
    n_neighbors=24,
    min_dist=0.28,
    spread=1.80,
    metric="cosine",
    random_state=RANDOM_STATE,
)

N_COLS = 3
POINT_SIZE = 5.2
POINT_ALPHA = 0.78
POINT_LINEWIDTH = 0.0
PANEL_WIDTH = 4.55
PANEL_HEIGHT = 3.45
TITLE_FONT_SIZE = 13
PANEL_TITLE_FONT_SIZE = 10.5
AXIS_LABEL_FONT_SIZE = 9.5
LEGEND_FONT_SIZE = 10.0
TYPE_LEGEND_NCOL = 6
LEGEND_MARKER_SIZE = 6.4
SAVE_DPI = 600

MAIN_TITLE = "UMAP of Protein-student representations colored by ARG Type"
SHOW_ALL_CONFIGURED_TYPES_IN_LEGEND = True
SAVE_SINGLE_EPOCH_FIGURES = True
USE_GLOBAL_AXIS_LIMITS = True
GLOBAL_AXIS_PAD_RATIO = 0.040

ANNOTATE_TYPE_CENTROIDS = False
HIGHLIGHT_TYPE_COUNT = 5
CENTROID_RING_SIZE = 145
CENTROID_RING_LINEWIDTH = 1.25

# Figure geometry: used by subplot area and legend area together.
SUBPLOT_LEFT = 0.050
SUBPLOT_RIGHT = 0.985
SUBPLOT_TOP = 0.905
SUBPLOT_BOTTOM = 0.2
LEGEND_BOX_Y = 0.045
LEGEND_BOX_H = 0.045
FOOTNOTE_Y = 0.095

NONARG = "nonARG"

TYPE_DISPLAY_NAME_MAP = {
    "macrolide-lincosamide-streptogramin": "MLS",
}
# =============================================================================
# 2. Plot style
# =============================================================================

warnings.filterwarnings("ignore", category=UserWarning)

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 8,
    "axes.linewidth": 1.0,
    "axes.titlesize": PANEL_TITLE_FONT_SIZE,
    "axes.labelsize": AXIS_LABEL_FONT_SIZE,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": LEGEND_FONT_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})

TYPE_COLOR_LIST = [
    "#E64B35", "#1F78B4", "#00A087", "#3C5488", "#F39B7F",
    "#7E6148", "#4DBBD5", "#D00000", "#B09C85", "#91D1C2",
    "#A6CEE3", "#FF7F00", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDB462", "#6A3D9A", "#CAB2D6", "#B15928",
    "#F0E442", "#8C510A", "#80CDC1", "#35978F", "#F781BF",
    "#377EB8", "#FFB000", "#66A61E", "#E7298A", "#984EA3",
    "#A6DBA0",
]


# =============================================================================
# 3. Helpers
# =============================================================================

def load_pt(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def clean_text(value) -> str:
    return "" if value is None else str(value).strip()


def canonical_label(value) -> str:
    text = clean_text(value)
    compact = "".join(ch for ch in text.lower() if ch.isalnum())
    if compact in {"nonarg", "negative", "nonresistance", "nonresistant"}:
        return NONARG
    return text


def tensor_2d_to_numpy(value, name: str) -> np.ndarray:
    if isinstance(value, torch.Tensor):
        value = value.detach().cpu().float().numpy()
    array = np.asarray(value, dtype=np.float32)
    if array.ndim != 2:
        raise ValueError(f"{name} must be 2D; shape={array.shape}")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} contains NaN/Inf")
    return array


def make_type_color_map(labels: list[str]) -> dict[str, str]:
    if len(labels) <= len(TYPE_COLOR_LIST):
        colors = TYPE_COLOR_LIST[:len(labels)]
    else:
        cmap = plt.get_cmap("turbo")
        colors = [
            mpl.colors.to_hex(cmap(i / max(1, len(labels) - 1)))
            for i in range(len(labels))
        ]
    return dict(zip(labels, colors))


def display_type_name(type_name: str) -> str:
    """
    Return a shorter display name for plotting only.
    Original Type names are preserved in all data/CSV outputs.
    """
    return TYPE_DISPLAY_NAME_MAP.get(type_name, type_name)


def zscore_features(X: np.ndarray) -> np.ndarray:
    mean = X.mean(axis=0, keepdims=True)
    std = X.std(axis=0, keepdims=True)
    std[std < 1e-8] = 1.0
    return ((X - mean) / std).astype(np.float32, copy=False)


# =============================================================================
# 4. Snapshot discovery
# =============================================================================

def discover_snapshots():
    snapshots = []
    missing = []

    for epoch in REGULAR_EPOCHS:
        path = INPUT_DIR / f"epoch_{epoch:03d}_test_ARG_type_features.pt"
        if not path.is_file():
            missing.append(path.name)
            continue
        snapshots.append({
            "id": f"epoch_{epoch:03d}",
            "epoch": epoch,
            "is_best": False,
            "path": path,
            "title": f"Epoch {epoch}",
        })

    if missing and REQUIRE_ALL_REGULAR_EPOCHS:
        raise FileNotFoundError("Missing files:\n" + "\n".join(missing))

    if INCLUDE_RUN_BEST:
        pattern = re.compile(r"run_best_epoch_(\d+)_test_ARG_type_features\.pt$", re.I)
        candidates = []
        for path in INPUT_DIR.glob("run_best_epoch_*_test_ARG_type_features.pt"):
            match = pattern.search(path.name)
            if match:
                candidates.append((int(match.group(1)), path))

        if not candidates:
            raise FileNotFoundError(
                "No run_best_epoch_XXX_test_ARG_type_features.pt found"
            )

        candidates.sort(key=lambda item: item[0])
        best_epoch, best_path = candidates[-1]
        if len(candidates) > 1:
            print(f"[Warning] Multiple best snapshots found; using {best_path.name}")

        snapshots.append({
            "id": f"run_best_epoch_{best_epoch:03d}",
            "epoch": best_epoch,
            "is_best": True,
            "path": best_path,
            "title": f"Best model (epoch {best_epoch})",
        })

    return snapshots


# =============================================================================
# 5. Snapshot loading
# =============================================================================

REQUIRED_KEYS = {
    "sequence_ids",
    "true_subtypes",
    "true_types",
    "features",
    "epoch",
}


def load_one_snapshot(info: dict) -> dict:
    obj = load_pt(info["path"])
    if not isinstance(obj, dict):
        raise TypeError(f"{info['path'].name} must contain a dict")

    missing = sorted(REQUIRED_KEYS - set(obj))
    if missing:
        raise KeyError(
            f"{info['path'].name} missing keys: {missing}\n"
            f"Available keys: {sorted(obj.keys())}"
        )

    ids = [clean_text(x) for x in obj["sequence_ids"]]
    true_subtypes = [canonical_label(x) for x in obj["true_subtypes"]]
    true_types = [canonical_label(x) for x in obj["true_types"]]
    features = tensor_2d_to_numpy(obj["features"], "features")

    n = len(ids)
    if not (len(true_subtypes) == len(true_types) == features.shape[0] == n):
        raise ValueError(
            f"Length mismatch in {info['path'].name}: "
            f"ids={len(ids)}, subtypes={len(true_subtypes)}, "
            f"types={len(true_types)}, features={features.shape}"
        )

    if len(ids) != len(set(ids)):
        raise ValueError(f"Duplicate sequence IDs in {info['path'].name}")

    if features.shape[1] != 512:
        raise ValueError(
            f"Expected 512D Student features; found {features.shape[1]}"
        )

    if any(x == NONARG for x in true_types):
        raise ValueError(
            f"{info['path'].name} contains nonARG rows, but these snapshots should be TEST ARG only"
        )

    subtype_to_type = {
        canonical_label(k): canonical_label(v)
        for k, v in obj.get("subtype_to_type", {}).items()
    }

    arg_subtype_names = [
        canonical_label(x)
        for x in obj.get("arg_subtype_names", [])
    ]

    subtype_logits = None
    predicted_subtypes = [""] * n
    predicted_types = [""] * n

    if "arg_subtype_logits" in obj:
        subtype_logits = tensor_2d_to_numpy(
            obj["arg_subtype_logits"],
            "arg_subtype_logits",
        )
        if subtype_logits.shape[0] != n:
            raise ValueError("arg_subtype_logits row mismatch")

        if arg_subtype_names:
            if subtype_logits.shape[1] != len(arg_subtype_names):
                raise ValueError(
                    f"arg_subtype_logits dim={subtype_logits.shape[1]} != "
                    f"arg_subtype_names={len(arg_subtype_names)}"
                )
            idx = subtype_logits.argmax(axis=1)
            predicted_subtypes = [arg_subtype_names[int(i)] for i in idx]
            predicted_types = [
                subtype_to_type.get(subtype, "UNMAPPED")
                for subtype in predicted_subtypes
            ]

    loaded = dict(info)
    loaded.update({
        "obj": obj,
        "sequence_ids": ids,
        "true_subtypes": true_subtypes,
        "true_types": true_types,
        "features": features,
        "subtype_to_type": subtype_to_type,
        "arg_subtype_names": arg_subtype_names,
        "arg_subtype_logits": subtype_logits,
        "predicted_subtypes": predicted_subtypes,
        "predicted_types": predicted_types,
    })

    print(
        f"[Loaded] {info['path'].name}: rows={n:,}, dim={features.shape[1]}, "
        f"observed_types={len(set(true_types))}"
    )
    return loaded


# =============================================================================
# 6. Hard consistency checks - NO intersection
# =============================================================================

def validate_snapshots(snapshots: list[dict]):
    ref = snapshots[0]

    for cur in snapshots[1:]:
        if cur["features"].shape[1] != ref["features"].shape[1]:
            raise ValueError("Feature dimensions differ across snapshots")

        if cur["sequence_ids"] != ref["sequence_ids"]:
            ref_set = set(ref["sequence_ids"])
            cur_set = set(cur["sequence_ids"])
            raise ValueError(
                "Sequence IDs/order differ across snapshots.\n"
                "No intersection is performed because that could remove rare Types.\n"
                f"reference={len(ref_set):,}, current={len(cur_set):,}, "
                f"missing={len(ref_set-cur_set):,}, extra={len(cur_set-ref_set):,}"
            )

        if cur["true_subtypes"] != ref["true_subtypes"]:
            raise ValueError("True subtype labels changed across snapshots")

        if cur["true_types"] != ref["true_types"]:
            raise ValueError("True Type labels changed across snapshots")

    print("\n[Snapshot consistency]")
    print(f"  snapshots              : {len(snapshots)}")
    print("  identical TEST ARG IDs : PASS")
    print(f"  rows per snapshot      : {len(ref['sequence_ids']):,}")
    print(f"  feature dimension      : {ref['features'].shape[1]}")
    print(f"  observed TEST Types    : {len(set(ref['true_types']))}")


# =============================================================================
# 7. Type universe / audit
# =============================================================================

def build_type_audit(snapshots: list[dict]):
    ref = snapshots[0]
    observed_types = sorted(set(ref["true_types"]), key=str.lower)
    support = pd.Series(ref["true_types"]).value_counts()

    configured_types = set()
    for snapshot in snapshots:
        for _, type_name in snapshot["subtype_to_type"].items():
            if type_name and type_name != NONARG:
                configured_types.add(type_name)

    if not configured_types:
        configured_types = set(observed_types)

    configured_types = sorted(configured_types, key=str.lower)

    rows = []
    for type_name in configured_types:
        s = int(support.get(type_name, 0))
        rows.append({
            "Type": type_name,
            "support_in_100pct_TEST_ARG": s,
            "observed_in_100pct_TEST": bool(s > 0),
            "configured_in_model": True,
        })

    for type_name in observed_types:
        if type_name not in configured_types:
            rows.append({
                "Type": type_name,
                "support_in_100pct_TEST_ARG": int(support.get(type_name, 0)),
                "observed_in_100pct_TEST": True,
                "configured_in_model": False,
            })

    audit = pd.DataFrame(rows).sort_values(
        ["configured_in_model", "Type"],
        ascending=[False, True],
    ).reset_index(drop=True)

    audit.to_csv(
        OUTPUT_DIR / "type_support_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )

    zero_support = audit.loc[
        (audit["configured_in_model"] == True)
        & (audit["support_in_100pct_TEST_ARG"] == 0),
        "Type",
    ].tolist()

    print("\n[ARG Type audit]")
    print(f"  configured ARG Types   : {int(audit['configured_in_model'].sum())}")
    print(f"  observed TEST ARG Types: {int(audit['observed_in_100pct_TEST'].sum())}")
    print(f"  configured support=0   : {len(zero_support)}")

    if zero_support:
        print("  Types absent from this TEST set:")
        for name in zero_support:
            print(f"    - {name}")

    return audit, configured_types, observed_types


# =============================================================================
# 8. Shared UMAP
# =============================================================================

def compute_shared_umap(snapshots: list[dict]) -> dict[str, np.ndarray]:
    blocks = [s["features"].astype(np.float32, copy=False) for s in snapshots]
    sizes = [(s["id"], len(s["sequence_ids"])) for s in snapshots]
    X_all = np.vstack(blocks)

    print("\n[Shared UMAP]")
    print(f"  snapshots : {len(snapshots)}")
    print(f"  total rows: {len(X_all):,}")
    print(f"  dimension : {X_all.shape[1]}")
    print(f"  standardize features : {APPLY_FEATURE_STANDARDIZATION}")
    print(f"  PCA before UMAP      : {APPLY_PCA_BEFORE_UMAP}")
    print(f"  type-guided UMAP     : {USE_TYPE_GUIDED_UMAP}")

    if APPLY_FEATURE_STANDARDIZATION:
        X_all = zscore_features(X_all)

    if APPLY_PCA_BEFORE_UMAP and PCA is not None:
        n_components = min(PCA_COMPONENTS, X_all.shape[1], X_all.shape[0] - 1)
        if n_components >= 2:
            pca = PCA(n_components=n_components, random_state=RANDOM_STATE)
            X_all = pca.fit_transform(X_all).astype(np.float32, copy=False)
            print(f"  PCA components        : {n_components}")
            print(f"  PCA explained variance: {pca.explained_variance_ratio_.sum():.4f}")

    reducer_kwargs = dict(UMAP_PARAMS)
    reducer = umap.UMAP(**reducer_kwargs)

    if USE_TYPE_GUIDED_UMAP:
        # concatenate identical Type labels across snapshots for mild label guidance
        all_types = []
        for s in snapshots:
            all_types.extend(s["true_types"])
        label_order = {name: i for i, name in enumerate(sorted(set(all_types), key=str.lower))}
        y_all = np.asarray([label_order[x] for x in all_types], dtype=np.int32)
        reducer = umap.UMAP(
            **reducer_kwargs,
            target_metric="categorical",
            target_weight=TYPE_GUIDED_TARGET_WEIGHT,
        )
        Z_all = reducer.fit_transform(X_all, y=y_all)
    else:
        Z_all = reducer.fit_transform(X_all)

    coordinates = {}
    cursor = 0
    for snapshot_id, n in sizes:
        coordinates[snapshot_id] = Z_all[cursor:cursor+n].copy()
        cursor += n

    return coordinates


# =============================================================================
# 9. Save audits / coordinates
# =============================================================================

def save_snapshot_audit(snapshots: list[dict]):
    rows = []
    for s in snapshots:
        rows.append({
            "snapshot_id": s["id"],
            "title": s["title"],
            "epoch": s["epoch"],
            "is_best": s["is_best"],
            "rows": len(s["sequence_ids"]),
            "feature_dimension": s["features"].shape[1],
            "observed_true_type_count": len(set(s["true_types"])),
            "source_file": str(s["path"]),
        })

    pd.DataFrame(rows).to_csv(
        OUTPUT_DIR / "snapshot_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )


def save_coordinate_tables(snapshots, coordinates):
    combined = []

    for s in snapshots:
        Z = coordinates[s["id"]]
        df = pd.DataFrame({
            "snapshot_id": s["id"],
            "snapshot_title": s["title"],
            "snapshot_epoch": s["epoch"],
            "snapshot_is_best": s["is_best"],
            "sequence_id": s["sequence_ids"],
            "true_subtype": s["true_subtypes"],
            "true_type": s["true_types"],
            "predicted_subtype_from_ARG_head": s["predicted_subtypes"],
            "predicted_type_from_ARG_head": s["predicted_types"],
            "UMAP1": Z[:, 0],
            "UMAP2": Z[:, 1],
        })

        path = OUTPUT_DIR / f"umap_coordinates_{s['id']}.csv"
        df.to_csv(path, index=False, encoding="utf-8-sig")
        combined.append(df)
        print(f"[Saved] {path.name}")

    pd.concat(combined, ignore_index=True).to_csv(
        OUTPUT_DIR / "umap_coordinates_all_snapshots.csv",
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# 10. Plot helpers
# =============================================================================

def global_square_limits(coordinates):
    Z_all = np.vstack(list(coordinates.values()))
    x_min, x_max = float(Z_all[:, 0].min()), float(Z_all[:, 0].max())
    y_min, y_max = float(Z_all[:, 1].min()), float(Z_all[:, 1].max())
    x_mid = (x_min + x_max) / 2.0
    y_mid = (y_min + y_max) / 2.0
    max_range = max(x_max - x_min, y_max - y_min)
    pad = max_range * GLOBAL_AXIS_PAD_RATIO
    half = max_range / 2.0 + pad
    return x_mid-half, x_mid+half, y_mid-half, y_mid+half


def local_square_limits(Z):
    x_min, x_max = float(Z[:, 0].min()), float(Z[:, 0].max())
    y_min, y_max = float(Z[:, 1].min()), float(Z[:, 1].max())
    x_mid = (x_min + x_max) / 2.0
    y_mid = (y_min + y_max) / 2.0
    max_range = max(x_max - x_min, y_max - y_min)
    pad = max_range * GLOBAL_AXIS_PAD_RATIO
    half = max_range / 2.0 + pad
    return x_mid-half, x_mid+half, y_mid-half, y_mid+half


def style_panel(ax, show_ylabel=True):
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel("UMAP1", labelpad=2, fontsize=AXIS_LABEL_FONT_SIZE)
    ax.set_ylabel("UMAP2" if show_ylabel else "", labelpad=2, fontsize=AXIS_LABEL_FONT_SIZE)
    for spine in ax.spines.values():
        spine.set_linewidth(1.0)
        spine.set_color("black")


def plot_type_points(ax, Z, true_types, color_map, limits, show_ylabel=True):
    labels = np.asarray(true_types, dtype=str)
    counts = pd.Series(labels).value_counts(ascending=False)

    # draw abundant classes first and rarer classes later so rare clusters stay visible
    for type_name in counts.index:
        mask = labels == type_name
        ax.scatter(
            Z[mask, 0],
            Z[mask, 1],
            s=POINT_SIZE,
            c=color_map.get(type_name, "#808080"),
            alpha=POINT_ALPHA,
            linewidths=POINT_LINEWIDTH,
            edgecolors="none",
            rasterized=True,
        )

    if limits is None:
        limits = local_square_limits(Z)

    ax.set_xlim(limits[0], limits[1])
    ax.set_ylim(limits[2], limits[3])
    style_panel(ax, show_ylabel=show_ylabel)


def make_legend_handles(labels, color_map, observed_types):
    handles = []
    observed_types = set(observed_types)

    for type_name in labels:
        if type_name in observed_types:
            face = color_map.get(type_name, "#808080")
            edge = "none"
        else:
            face = "white"
            edge = color_map.get(type_name, "#808080")

        handles.append(
            Line2D(
                [0], [0],
                marker="o",
                color="none",
                markerfacecolor=face,
                markeredgecolor=edge,
                markeredgewidth=0.8,
                markersize=LEGEND_MARKER_SIZE,
                label=type_name,
            )
        )

    return handles


def draw_type_centroids(ax, Z, true_types, color_map):
    labels = np.asarray(true_types, dtype=str)
    top_types = pd.Series(labels).value_counts().head(HIGHLIGHT_TYPE_COUNT).index.tolist()

    for type_name in top_types:
        mask = labels == type_name
        xy = Z[mask].mean(axis=0)
        color = color_map.get(type_name, "#333333")

        ax.scatter(
            [xy[0]], [xy[1]],
            s=CENTROID_RING_SIZE + 35,
            facecolors="none",
            edgecolors="white",
            linewidths=2.5,
            zorder=7,
        )
        ax.scatter(
            [xy[0]], [xy[1]],
            s=CENTROID_RING_SIZE,
            facecolors="none",
            edgecolors=color,
            linewidths=CENTROID_RING_LINEWIDTH,
            zorder=8,
        )


# =============================================================================
# 11. Multipanel figure
# =============================================================================

def plot_multipanel(snapshots, coordinates, legend_labels, observed_types, color_map):
    n = len(snapshots)
    ncols = min(N_COLS, n)
    nrows = math.ceil(n / ncols)

    fig, axes = plt.subplots(
        nrows=nrows,
        ncols=ncols,
        figsize=(PANEL_WIDTH*ncols, PANEL_HEIGHT*nrows + 2.45),
        dpi=SAVE_DPI,
        constrained_layout=False,
    )
    axes = np.atleast_1d(axes).reshape(-1)

    limits = global_square_limits(coordinates) if USE_GLOBAL_AXIS_LIMITS else None

    for i, s in enumerate(snapshots):
        ax = axes[i]
        Z = coordinates[s["id"]]

        plot_type_points(
            ax=ax,
            Z=Z,
            true_types=s["true_types"],
            color_map=color_map,
            limits=limits,
            show_ylabel=(i % ncols == 0),
        )

        if ANNOTATE_TYPE_CENTROIDS:
            draw_type_centroids(ax, Z, s["true_types"], color_map)

        ax.set_title(
            s["title"],
            fontsize=PANEL_TITLE_FONT_SIZE,
            pad=5,
            fontweight="bold" if s["is_best"] else "normal",
        )

    for j in range(n, len(axes)):
        axes[j].axis("off")

    fig.suptitle(MAIN_TITLE, fontsize=TITLE_FONT_SIZE, y=0.973)

    handles = make_legend_handles(legend_labels, color_map, observed_types)

    legend_display_labels = [
        display_type_name(x)
        for x in legend_labels
    ]

    fig.subplots_adjust(
        left=SUBPLOT_LEFT,
        right=SUBPLOT_RIGHT,
        top=SUBPLOT_TOP,
        bottom=SUBPLOT_BOTTOM,
        wspace=0.14,
        hspace=0.23,
    )

    # Legend aligned to the same left/right edges as the plot panels.
    legend_width = SUBPLOT_RIGHT - SUBPLOT_LEFT
    fig.legend(
        handles=handles,
        labels=legend_display_labels,
        loc="lower left",
        bbox_to_anchor=(SUBPLOT_LEFT, LEGEND_BOX_Y, legend_width, LEGEND_BOX_H),
        bbox_transform=fig.transFigure,
        mode="expand",
        ncol=TYPE_LEGEND_NCOL,
        frameon=False,
        fontsize=LEGEND_FONT_SIZE,
        handlelength=0.82,
        handletextpad=0.28,
        columnspacing=1.00,
        labelspacing=0.60,
        borderaxespad=0.0,
    )

    # zero_support_present = bool(set(legend_labels) - set(observed_types))
    # if SHOW_ALL_CONFIGURED_TYPES_IN_LEGEND and zero_support_present:
    #     fig.text(
    #         0.5,
    #         FOOTNOTE_Y,
    #         "Filled markers: observed in 100% TEST; hollow markers: configured ARG Types with TEST support = 0.",
    #         ha="center",
    #         va="bottom",
    #         fontsize=7.0,
    #     )

    png = OUTPUT_DIR / "protein_100pct_ARG_type_epochs_multipanel.png"
    pdf = OUTPUT_DIR / "protein_100pct_ARG_type_epochs_multipanel.pdf"
    svg = OUTPUT_DIR / "protein_100pct_ARG_type_epochs_multipanel.svg"

    fig.savefig(png, dpi=SAVE_DPI)
    fig.savefig(pdf)
    fig.savefig(svg)
    plt.close(fig)

    print(f"[Saved] {png.name}")
    print(f"[Saved] {pdf.name}")
    print(f"[Saved] {svg.name}")


# =============================================================================
# 12. Single-epoch figures
# =============================================================================

def plot_single_epoch_figures(snapshots, coordinates, legend_labels, observed_types, color_map):
    if not SAVE_SINGLE_EPOCH_FIGURES:
        return

    limits = global_square_limits(coordinates) if USE_GLOBAL_AXIS_LIMITS else None
    handles = make_legend_handles(legend_labels, color_map, observed_types)

    legend_display_labels = [
        display_type_name(x)
        for x in legend_labels
    ]

    for s in snapshots:
        Z = coordinates[s["id"]]
        fig, ax = plt.subplots(figsize=(6.3, 6.5), dpi=SAVE_DPI)

        plot_type_points(
            ax=ax,
            Z=Z,
            true_types=s["true_types"],
            color_map=color_map,
            limits=limits,
            show_ylabel=True,
        )

        ax.set_title(
            s["title"],
            fontsize=PANEL_TITLE_FONT_SIZE,
            pad=5,
            fontweight="bold" if s["is_best"] else "normal",
        )

        fig.subplots_adjust(left=0.10, right=0.98, top=0.90, bottom=0.33)

        fig.legend(
            handles=handles,
            labels=legend_display_labels,
            loc="lower left",
            bbox_to_anchor=(0.10, 0.045, 0.88, 0.20),
            bbox_transform=fig.transFigure,
            mode="expand",
            ncol=4,
            frameon=False,
            fontsize=6.6,
            handlelength=0.80,
            handletextpad=0.24,
            columnspacing=0.80,
            labelspacing=0.45,
            borderaxespad=0.0,
        )

        png = OUTPUT_DIR / f"umap_type_{s['id']}.png"
        pdf = OUTPUT_DIR / f"umap_type_{s['id']}.pdf"
        fig.savefig(png, dpi=SAVE_DPI)
        fig.savefig(pdf)
        plt.close(fig)
        print(f"[Saved] {png.name}")


# =============================================================================
# 13. Main
# =============================================================================

def main():
    print("=" * 100)
    print("ARGScope 100% Protein Student: epoch-wise Type UMAP (improved layout + clearer clustering)")
    print("=" * 100)
    print(f"INPUT_DIR  : {INPUT_DIR}")
    print(f"OUTPUT_DIR : {OUTPUT_DIR}")
    print("Sample rule: NO intersection, NO subsampling")
    print("UMAP rule  : shared UMAP across all epoch features")

    infos = discover_snapshots()

    print("\n[Discovered snapshots]")
    for info in infos:
        print(f"  - {info['path'].name} | {info['title']} | best={info['is_best']}")

    snapshots = [load_one_snapshot(info) for info in infos]
    validate_snapshots(snapshots)

    audit, configured_types, observed_types = build_type_audit(snapshots)

    all_color_labels = sorted(
        set(configured_types) | set(observed_types),
        key=str.lower,
    )
    color_map = make_type_color_map(all_color_labels)

    pd.DataFrame({
        "Type": all_color_labels,
        "color": [color_map[x] for x in all_color_labels],
        "observed_in_100pct_TEST": [x in set(observed_types) for x in all_color_labels],
    }).to_csv(
        OUTPUT_DIR / "type_color_mapping.csv",
        index=False,
        encoding="utf-8-sig",
    )

    save_snapshot_audit(snapshots)
    coordinates = compute_shared_umap(snapshots)
    save_coordinate_tables(snapshots, coordinates)

    legend_labels = (
        all_color_labels
        if SHOW_ALL_CONFIGURED_TYPES_IN_LEGEND
        else observed_types
    )

    plot_multipanel(
        snapshots,
        coordinates,
        legend_labels,
        observed_types,
        color_map,
    )

    plot_single_epoch_figures(
        snapshots,
        coordinates,
        legend_labels,
        observed_types,
        color_map,
    )

    best = [s["title"] for s in snapshots if s["is_best"]][0]

    print("\n" + "=" * 100)
    print("DONE")
    print("=" * 100)
    print(f"Configured ARG Types : {len(configured_types)}")
    print(f"Observed TEST Types   : {len(observed_types)}")
    print(f"TEST ARG rows         : {len(snapshots[0]['sequence_ids']):,}")
    print(f"Best snapshot         : {best}")
    print(f"Output directory      : {OUTPUT_DIR}")
    print("\nCheck type_support_audit.csv first if you think some Types are missing.")


if __name__ == "__main__":
    main()
