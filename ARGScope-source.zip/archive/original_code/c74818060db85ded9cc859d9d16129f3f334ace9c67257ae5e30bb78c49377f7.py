#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independently inspect the exported fixed-canvas figures and source hashes."""
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image

HERE = Path(__file__).resolve().parent
SVG = "{http://www.w3.org/2000/svg}"
report = json.loads((HERE / "LAYOUT_VALIDATION.json").read_text(encoding="utf-8"))
assert report["figures"] == 54 and report["exports"] == 162
validated, heatmaps, umaps = 0, 0, 0

for panel in report["panels"]:
    for rel in panel["files"]:
        path = HERE / rel
        assert path.is_file() and path.stat().st_size > 1000, rel
        validated += 1
    path = HERE / next(f for f in panel["files"] if f.endswith(".svg"))
    root = ET.parse(path).getroot()
    text = ["".join(t.itertext()) for t in root.iter(SVG + "text")]
    assert not any(t in list("ABCDEF") for t in text), str(path)
    assert not any("completeness" in t.lower() or t in {"NA", "NaN"} for t in text), str(path)
    assert not any(t.startswith(("Reported Type", "Reference-model", "True ARG only",
                                 "Only 23", "Protein |", "DNA |")) for t in text), str(path)
    assert abs(float(root.attrib["width"].removesuffix("pt")) * 25.4 / 72 - panel["width_mm"]) < .01
    assert abs(float(root.attrib["height"].removesuffix("pt")) * 25.4 / 72 - panel["height_mm"]) < .01

    if panel["panel"] in {"heatmaps", "assembled"}:
        actual = {}
        for group in root.iter(SVG + "g"):
            if group.attrib.get("id", "").startswith("heatmap-"):
                contents = "".join("".join(t.itertext()) for t in group.iter(SVG + "text"))
                actual[group.attrib["id"]] = contents
        expected = {}
        base = HERE / "data" / panel["modality"] / f"{panel['completeness_percent']}pct"
        for metric in ["Precision", "Recall", "F1"]:
            data = pd.read_csv(base / f"B_{metric}_values.csv", index_col=0, float_precision="round_trip")
            for i, row in enumerate(data.to_numpy()):
                for j, value in enumerate(row):
                    expected[f"heatmap-{metric}-{i}-{j}"] = f"{value:.4f}"
        assert actual == expected, str(path)
        assert text.count("Average") == 1, str(path)
        assert all(re.fullmatch(r"\d\.\d{4}", s) for s in actual.values()), str(path)
        heatmaps += 1

    if panel["panel"] in {"umap", "assembled"}:
        collections = [g for g in root.iter(SVG + "g")
                       if g.attrib.get("id", "").startswith("PathCollection_")]
        assert len(collections) == 4, (str(path), len(collections))
        sizes = [len(list(group.iter(SVG + "use"))) for group in collections]
        assert sizes == [2287] * 4, (str(path), sizes)
        epoch = 135 if panel["modality"] == "protein" else 132
        assert f"Best model (epoch {epoch})" in text
        umaps += 1

    png = HERE / next(f for f in panel["files"] if f.endswith(".png"))
    with Image.open(png) as im:
        assert abs(im.width - panel["width_mm"] / 25.4 * 600) < 2
        assert abs(im.height - panel["height_mm"] / 25.4 * 600) < 2
        assert im.mode in {"RGB", "RGBA"}
        # Check that the image is populated, not an empty white canvas.
        im.thumbnail((160, 160))
        assert np.asarray(im.convert("RGB")).std() > 10

fingerprints = json.loads((HERE / "source_fingerprints.json").read_text(encoding="utf-8"))
checked, unavailable = 0, []
for name, expected in fingerprints.items():
    path = Path(name)
    if path.is_file():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
        checked += 1
    else:
        unavailable.append(name)
refit_root = HERE / "data/umap_reference_refit"
refit = json.loads((refit_root / "REFIT_VALIDATION.json").read_text(encoding="utf-8"))
assert refit["status"] == "PASS" and refit["n_fits"] == 8
assert refit["params"]["n_neighbors"] == 50 and refit["params"]["min_dist"] == .50
for fit in refit["fits"]:
    path = refit_root / "coordinates" / f"{fit['modality']}_epoch_{fit['epoch']:03d}.csv"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == fit["coordinates_sha256"]
    assert fit["labels_used_in_fit"] is False
    assert fit["points_removed"] == 0 and fit["n_samples"] == 2287
    new = pd.read_csv(path)
    old = pd.read_csv(HERE / "data/umap/coordinates" / path.name)
    pd.testing.assert_frame_equal(new[["sequence_id", "Type", "Subtype"]], old[["sequence_id", "Type", "Subtype"]])
result = {"status": "PASS", "files_checked": validated,
          "combined_heatmaps_checked": heatmaps, "umap_figures_checked": umaps,
          "original_source_hashes_checked": checked, "unavailable_original_sources": unavailable,
          "exact_heatmap_strings_match": True, "umap_points_per_epoch": 2287,
          "no_panel_letters_or_modality_completeness_descriptions": True,
          "fixed_physical_sizes_confirmed": True}
result["umap_layout_profile"] = refit["profile"]
result["refit_coordinate_files_checked"] = 8
result["refit_labels_and_cohorts_unchanged"] = True
(HERE / "EXPORTED_FIGURE_VALIDATION.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(result, ensure_ascii=False, indent=2))
