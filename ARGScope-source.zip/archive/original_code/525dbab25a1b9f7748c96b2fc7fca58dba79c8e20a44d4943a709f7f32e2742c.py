"""Independent checks for the standard-library metric implementation."""
import csv
import importlib.util
import math
import random
import tempfile
import unittest
import warnings
from pathlib import Path

SCRIPT = Path(__file__).with_name("calculate_new_full_ablation_metrics.py")
spec = importlib.util.spec_from_file_location("ablation_metrics", SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class MetricTests(unittest.TestCase):
    def assert_metrics_equal(self, actual, expected):
        for field, value in expected.items():
            self.assertAlmostEqual(actual[field], value, places=11, msg=field)

    def test_binary_known_confusion(self):
        truth = [1]*4 + [0]*6
        pred = [1, 1, 1, 0, 1, 1, 0, 0, 0, 0]
        row = m.per_label_metrics(truth, pred, [1])[0]
        self.assert_metrics_equal(row, {"Accuracy": .7, "Precision": .6, "Recall": .75, "F1": 2/3, "MCC": 10/math.sqrt(600)})
        self.assertEqual([row[k] for k in ("TP", "FP", "FN", "TN")], [3, 2, 1, 4])

    def test_arg_only_does_not_drop_false_negatives(self):
        row = m.overall_metrics(["A", "B"], ["A", "nonARG"], "micro", ["A", "B"])
        self.assert_metrics_equal(row, {"Accuracy": .5, "Precision": 1., "Recall": .5, "F1": 2/3})

    def test_macro_f1_is_mean_of_class_f1(self):
        truth = ["A"]*8 + ["B"]*2
        pred = ["A"]*10
        row = m.overall_metrics(truth, pred, "macro")
        self.assertAlmostEqual(row["F1"], (16/18)/2)

    def test_constant_label_mcc_zero(self):
        self.assertEqual(m.global_accuracy_mcc([0, 0], [0, 0]), (1., 0.))

    def test_randomized_agreement_with_sklearn(self):
        from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support
        rng = random.Random(20260918)
        for number in range(100):
            k = rng.randrange(2, 15)
            n = rng.randrange(3, 150)
            truth = [rng.randrange(k) for _ in range(n)]
            pred = [rng.randrange(k+1) for _ in range(n)]
            for labels in (list(range(k+2)), list(range(k))):
                for average in m.AVERAGES:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        p, r, f, _ = precision_recall_fscore_support(truth, pred, labels=labels, average=average, zero_division=0)
                        expected = {"Accuracy": accuracy_score(truth, pred), "Precision": p, "Recall": r, "F1": f, "MCC": matthews_corrcoef(truth, pred)}
                    self.assert_metrics_equal(m.overall_metrics(truth, pred, average, labels), expected)
            for cls in range(k+1):
                y, p = [int(t == cls) for t in truth], [int(t == cls) for t in pred]
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    pp, rr, ff, _ = precision_recall_fscore_support(y, p, average="binary", zero_division=0)
                    expected = {"Accuracy": accuracy_score(y, p), "Precision": pp, "Recall": rr, "F1": ff, "MCC": matthews_corrcoef(y, p)}
                self.assert_metrics_equal(m.per_label_metrics(truth, pred, [cls])[0], expected)


class FileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="metric_test_", dir=Path(__file__).parent)
        self.root = Path(self.temp.name).resolve()
        self.assertEqual(self.root.parent, Path(__file__).resolve().parent)

    def tearDown(self):
        self.temp.cleanup()

    def fixture_rows(self):
        return [{"sequence_id": sid, "true_subtype": s, "predicted_subtype": s,
                 "true_type": t, "predicted_type": t, "true_ARG": int(s != "nonARG"),
                 "predicted_ARG": int(s != "nonARG"), "split": "test"}
                for sid, s, t in (("a,quoted", "a", "A"), ("b", "b", "B"), ("n1", "nonARG", "nonARG"), ("n2", "nonARG", "nonARG"))]

    def write(self, path, rows):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    def populate(self, screenshot_layout=False):
        for variant in m.VARIANTS:
            for modality in m.MODALITIES:
                path = self.root / variant / modality.lower() / "test_sequence_predictions.csv"
                if screenshot_layout and variant == "full":
                    path = self.root / f"{modality}_full_test_sequence_predictions.csv"
                self.write(path, self.fixture_rows())

    def test_screenshot_layout_and_eight_runs(self):
        self.populate(True)
        files = m.discover_files(self.root)
        self.assertEqual(len(files), 8)
        runs = {k: m.read_predictions(p) for k, p in files.items()}
        self.assertEqual(len(m.validate_runs(runs, 4, 2, 2)), 4)

    def test_original_layout(self):
        self.populate()
        self.assertEqual(len(m.discover_files(self.root)), 8)

    def test_missing_model_rejected(self):
        self.write(self.root / "DNA_full_test_sequence_predictions.csv", self.fixture_rows())
        with self.assertRaisesRegex(ValueError, "Missing model"):
            m.discover_files(self.root)

    def test_duplicate_model_rejected(self):
        self.populate()
        self.write(self.root / "DNA_full_test_sequence_predictions.csv", self.fixture_rows())
        with self.assertRaisesRegex(ValueError, "Duplicate input"):
            m.discover_files(self.root)

    def test_output_folder_is_ignored(self):
        self.populate()
        self.write(self.root / "new_ablation_metrics_old" / "DNA_full_test_sequence_predictions.csv", self.fixture_rows())
        self.assertEqual(len(m.discover_files(self.root)), 8)

    def test_duplicate_id_rejected(self):
        path = self.root / "DNA_full_test_sequence_predictions.csv"
        self.write(path, self.fixture_rows() + [self.fixture_rows()[0]])
        with self.assertRaisesRegex(ValueError, "duplicate sequence_id"):
            m.read_predictions(path)

    def test_inconsistent_binary_rejected(self):
        rows = self.fixture_rows()
        rows[0]["predicted_ARG"] = 0
        path = self.root / "DNA_full_test_sequence_predictions.csv"
        self.write(path, rows)
        with self.assertRaisesRegex(ValueError, "disagree"):
            m.read_predictions(path)

    def test_mismatched_test_sets_rejected(self):
        self.populate()
        files = m.discover_files(self.root)
        runs = {k: m.read_predictions(p) for k, p in files.items()}
        runs[("wo_gate", "DNA")].pop("b")
        with self.assertRaisesRegex(ValueError, "Different test IDs"):
            m.validate_runs(runs, 4, 2, 2)

    def test_changed_truth_rejected(self):
        self.populate()
        files = m.discover_files(self.root)
        runs = {k: m.read_predictions(p) for k, p in files.items()}
        runs[("wo_gate", "DNA")]["b"]["true_subtype"] = "wrong"
        with self.assertRaisesRegex(ValueError, "Ground-truth mismatch"):
            m.validate_runs(runs, 4, 2, 2)

    def test_full_pipeline_and_no_overwrite(self):
        self.populate(True)
        target = self.root / "new_ablation_metrics_test"
        m.calculate(self.root, target, 4, 2, 2)
        self.assertEqual(len(list((target / "per_type").glob("*.csv"))), 3)
        with (target / "02_Type_overall_macro_weighted_micro.csv").open(encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 24)
        self.assertTrue(all(float(row["Accuracy"]) == 1 for row in rows))
        with self.assertRaises(FileExistsError):
            m.calculate(self.root, target, 4, 2, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
