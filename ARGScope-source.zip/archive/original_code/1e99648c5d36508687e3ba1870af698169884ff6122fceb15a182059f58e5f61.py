# -*- coding: utf-8 -*-
"""
Plot subtype performance for the most and least frequent subtypes.

Input:
type_test_predictions.csv

Required columns:
Subtype
Pred_Subtype
Type

Output:
subtype_performance_most15_least15.png
subtype_performance_most15_least15.pdf
subtype_performance_most15_least15.tif
subtype_performance_all_metrics.csv
subtype_performance_most15_least15_metrics.csv
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score


# =========================================================
# 1. CONFIG
# =========================================================

INPUT_FILE = "type_test_predictions.csv"

OUTDIR = "subtype_performance_most_least_outputs"
os.makedirs(OUTDIR, exist_ok=True)

TOP_N = 15
BOTTOM_N = 15

TRUE_SUBTYPE_COL = "Subtype"
PRED_SUBTYPE_COL = "Pred_Subtype"
TYPE_COL = "Type"

# 是否去掉 nonARG
REMOVE_NONARG = True

# 最小样本数。这里建议保持 1，因为你要画“数量最少”的 subtype
MIN_SUPPORT = 1

DPI = 600

plt.rcParams["font.family"] = "Arial"
plt.rcParams["axes.unicode_minus"] = False


# =========================================================
# 2. Type colors and display names
# =========================================================

TYPE_COLORS = {
    "MLS": "#666666",
    "macrolide-lincosamide-streptogramin": "#666666",
    "macrolide_lincosamide_streptogramin": "#666666",

    "multidrug": "#4C78A8",
    "fosfomycin": "#F28E2B",
    "bacitracin": "#C49A6C",
    "polymyxin": "#2CA02C",
    "beta_lactam": "#8CD17D",
    "quinolone": "#E45756",
    "aminoglycoside": "#9467BD",
    "tetracycline": "#E7969C",
    "chloramphenicol": "#17BECF",
    "sulfonamide": "#BCBD22",
    "trimethoprim": "#FF9DA7",
    "rifamycin": "#9C755F",
    "vancomycin": "#BAB0AC",
    "bleomycin": "#A0CBE8",
    "streptothricin": "#FFBE7D",
    "peptide": "#76B7B2",
    "other_peptide_antibiotics": "#8DA0CB",
    "pleuromutilin_tiamulin": "#B07AA1",
    "puromycin": "#EDC948",
    "novobiocin": "#59A14F",
    "mupirocin": "#9C755F",
    "edeine": "#B6992D",
    "defensin": "#86BCB6",
    "bicyclomycin": "#D37295",
    "factumycin": "#FABFD2",
    "florfenicol": "#9EDAE5",
    "nitroimidazole": "#C7C7C7",
    "nonARG": "#999999",
    "Unknown": "#666666",
}

DEFAULT_TYPE_COLOR = "#666666"

TYPE_DISPLAY_NAMES = {
    "macrolide-lincosamide-streptogramin": "MLS",
    "macrolide_lincosamide_streptogramin": "MLS",
    "MLS": "MLS",
}


# =========================================================
# 3. Helper functions
# =========================================================

def clean_text(x):
    if pd.isna(x):
        return ""
    return str(x).strip()


def display_type_name(type_name):
    """
    Display name for Type.
    Example:
    macrolide-lincosamide-streptogramin -> MLS
    """
    type_name = clean_text(type_name)
    return TYPE_DISPLAY_NAMES.get(type_name, type_name)


def display_subtype_label(subtype):
    """
    Display name for Subtype on x-axis.
    Example:
    macrolide-lincosamide-streptogramin__macB -> MLS__macB
    """
    subtype = clean_text(subtype)

    for long_name, short_name in TYPE_DISPLAY_NAMES.items():
        if subtype.startswith(long_name + "__"):
            return subtype.replace(long_name + "__", short_name + "__", 1)

    return subtype


def infer_type_from_subtype(subtype):
    """
    如果 Type 列缺失，尝试从 subtype 名称中推断 Type。
    例如 beta_lactam__ADC-25 -> beta_lactam
    """
    subtype = clean_text(subtype)

    if "__" in subtype:
        return display_type_name(subtype.split("__")[0])

    return "Unknown"


def compute_subtype_metrics(df):
    """
    对每个真实 subtype 计算 Precision / Recall / F1-score。
    support = 真实标签中该 subtype 的样本数量。
    Top/Bottom 是按 support 排序，而不是按 F1 排序。
    """
    y_true = df[TRUE_SUBTYPE_COL].astype(str).values
    y_pred = df[PRED_SUBTYPE_COL].astype(str).values

    # 只以真实 subtype 为统计对象
    labels = sorted(set(y_true))

    rows = []

    for lab in labels:
        true_bin = (y_true == lab).astype(int)
        pred_bin = (y_pred == lab).astype(int)

        support = int(true_bin.sum())
        pred_count = int(pred_bin.sum())
        correct_count = int(((y_true == lab) & (y_pred == lab)).sum())

        if support < MIN_SUPPORT:
            continue

        precision = precision_score(true_bin, pred_bin, zero_division=0)
        recall = recall_score(true_bin, pred_bin, zero_division=0)
        f1 = f1_score(true_bin, pred_bin, zero_division=0)

        if TYPE_COL in df.columns:
            true_type_values = df.loc[
                df[TRUE_SUBTYPE_COL].astype(str) == lab,
                TYPE_COL
            ].astype(str)

            if len(true_type_values) > 0:
                type_name = true_type_values.value_counts().index[0]
            else:
                type_name = infer_type_from_subtype(lab)
        else:
            type_name = infer_type_from_subtype(lab)

        type_name = display_type_name(type_name)

        rows.append({
            "Subtype": lab,
            "Subtype_display": display_subtype_label(lab),
            "Type": type_name,
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct_count,
            "Precision": precision,
            "Recall": recall,
            "F1-score": f1,
        })

    out = pd.DataFrame(rows)

    if out.empty:
        raise ValueError("没有可用的 subtype 指标，请检查输入文件或 MIN_SUPPORT 设置。")

    return out


def shorten_label(x, max_len=50):
    x = str(x)
    if len(x) <= max_len:
        return x
    return x[:max_len - 3] + "..."


# =========================================================
# 4. Load data
# =========================================================

df = pd.read_csv(INPUT_FILE)
df.columns = [clean_text(c) for c in df.columns]

required_cols = [TRUE_SUBTYPE_COL, PRED_SUBTYPE_COL]
for c in required_cols:
    if c not in df.columns:
        raise ValueError(f"输入文件缺少必要列: {c}")

df[TRUE_SUBTYPE_COL] = df[TRUE_SUBTYPE_COL].astype(str).str.strip()
df[PRED_SUBTYPE_COL] = df[PRED_SUBTYPE_COL].astype(str).str.strip()

if TYPE_COL in df.columns:
    df[TYPE_COL] = df[TYPE_COL].astype(str).str.strip()
else:
    df[TYPE_COL] = df[TRUE_SUBTYPE_COL].apply(infer_type_from_subtype)

# 统一缩写 Type 名称，例如 macrolide-lincosamide-streptogramin -> MLS
df[TYPE_COL] = df[TYPE_COL].apply(display_type_name)

if REMOVE_NONARG:
    df = df[
        (df[TRUE_SUBTYPE_COL].str.lower() != "nonarg") &
        (df[TYPE_COL].str.lower() != "nonarg")
    ].copy()

if df.empty:
    raise ValueError("过滤 nonARG 后数据为空，请把 REMOVE_NONARG 改成 False。")


# =========================================================
# 5. Compute metrics
# =========================================================

metrics_df = compute_subtype_metrics(df)

metrics_df.to_csv(
    os.path.join(OUTDIR, "subtype_performance_all_metrics.csv"),
    index=False,
    encoding="utf-8-sig"
)

# =========================================================
# 关键逻辑：
# Top 15 = 真实样本数量最多的 subtype
# Bottom 15 = 真实样本数量最少的 subtype
# =========================================================

top_df = (
    metrics_df
    .sort_values(["support", "F1-score"], ascending=[False, False])
    .head(TOP_N)
    .copy()
)

bottom_df = (
    metrics_df
    .sort_values(["support", "F1-score"], ascending=[True, False])
    .head(BOTTOM_N)
    .copy()
)

plot_df = pd.concat([top_df, bottom_df], axis=0, ignore_index=True)

# 防止数据类别太少时 Top 和 Bottom 有重复
plot_df = (
    plot_df
    .drop_duplicates(subset=["Subtype"], keep="first")
    .reset_index(drop=True)
)

plot_df.to_csv(
    os.path.join(OUTDIR, "subtype_performance_most15_least15_metrics.csv"),
    index=False,
    encoding="utf-8-sig"
)


# =========================================================
# 6. Plot
# =========================================================

n = len(plot_df)
x = np.arange(n)

fig_w = max(14, n * 0.46)
fig_h = 7.4

fig, ax = plt.subplots(figsize=(fig_w, fig_h))

ax.grid(
    axis="y",
    linestyle="--",
    linewidth=0.6,
    alpha=0.35,
    color="#999999"
)
ax.set_axisbelow(True)

# Precision: 蓝色空心圆
ax.scatter(
    x,
    plot_df["Precision"],
    s=44,
    facecolors="white",
    edgecolors="#1976D2",
    linewidths=1.7,
    label="Precision",
    zorder=4
)

# Recall: 灰色竖线
for idx, (xi, yi) in enumerate(zip(x, plot_df["Recall"].values)):
    ax.vlines(
        xi,
        max(0, yi - 0.06),
        min(1.08, yi + 0.06),
        color="#7A7A7A",
        linewidth=2.1,
        label="Recall" if idx == 0 else None,
        zorder=3
    )

# F1-score: 黑色实心圆
ax.scatter(
    x,
    plot_df["F1-score"],
    s=36,
    color="black",
    label="F1-score",
    zorder=5
)

# support 标注 n=
for xi, row in plot_df.iterrows():
    ymax = max(row["Precision"], row["Recall"], row["F1-score"])

    ax.text(
        xi,
        min(1.075, ymax + 0.04),
        f"n={int(row['support'])}",
        ha="center",
        va="bottom",
        fontsize=7,
        rotation=90
    )

# Top / Bottom 分割线和区域标题
if len(top_df) > 0 and len(bottom_df) > 0:
    split_x = len(top_df) - 0.5

    ax.axvline(
        split_x,
        linestyle="--",
        color="#999999",
        linewidth=1.0
    )

    ax.text(
        (len(top_df) - 1) / 2,
        1.115,
        f"Most frequent {TOP_N}",
        ha="center",
        va="bottom",
        fontsize=11,
        fontweight="bold"
    )

    ax.text(
        len(top_df) + (len(bottom_df) - 1) / 2,
        1.115,
        f"Least frequent {BOTTOM_N}",
        ha="center",
        va="bottom",
        fontsize=11,
        fontweight="bold"
    )

# x tick labels
labels = [shorten_label(display_subtype_label(s)) for s in plot_df["Subtype"].values]

ax.set_xticks(x)
ax.set_xticklabels(
    labels,
    rotation=60,
    ha="right",
    fontsize=8,
    fontweight="bold"
)

# 按 Type 给 x 轴文字上色
for tick_label, type_name in zip(ax.get_xticklabels(), plot_df["Type"].values):
    type_name = display_type_name(type_name)
    tick_label.set_color(TYPE_COLORS.get(type_name, DEFAULT_TYPE_COLOR))

# y axis
ax.set_ylim(0, 1.18)
ax.set_yticks(np.arange(0, 1.01, 0.2))
ax.set_yticklabels(
    [f"{v:.1f}" for v in np.arange(0, 1.01, 0.2)],
    fontsize=10,
    fontweight="bold"
)

ax.set_ylabel(
    "Score",
    fontsize=13,
    fontweight="bold"
)

ax.set_title(
    "Subtype performance of the most and least frequent subtypes",
    fontsize=16,
    fontweight="bold",
    pad=14
)

# =========================================================
# Combined legend: Metrics + Type
# =========================================================

metric_handles = [
    plt.Line2D(
        [0], [0],
        marker="o",
        linestyle="",
        markersize=7,
        markerfacecolor="white",
        markeredgecolor="#1976D2",
        markeredgewidth=1.7,
        label="Precision"
    ),
    plt.Line2D(
        [0], [0],
        linestyle="-",
        color="#7A7A7A",
        linewidth=2.1,
        label="Recall"
    ),
    plt.Line2D(
        [0], [0],
        marker="o",
        linestyle="",
        markersize=7,
        markerfacecolor="black",
        markeredgecolor="black",
        label="F1-score"
    ),
]

used_types = []
for t in plot_df["Type"].values:
    t_display = display_type_name(t)
    if t_display not in used_types:
        used_types.append(t_display)

type_handles = []
for t in used_types:
    type_handles.append(
        plt.Line2D(
            [0], [0],
            marker="s",
            linestyle="",
            markersize=8,
            markerfacecolor=TYPE_COLORS.get(t, DEFAULT_TYPE_COLOR),
            markeredgecolor="black",
            markeredgewidth=0.5,
            label=t
        )
    )

all_handles = metric_handles + type_handles

combined_legend = ax.legend(
    handles=all_handles,
    loc="upper left",
    bbox_to_anchor=(0.02, 0.4),
    frameon=True,
    title="Metrics and Type",
    fontsize=8,
    title_fontsize=10,
    ncol=3,
    columnspacing=1.1,
    handletextpad=0.5,
    borderpad=0.8
)

combined_legend.get_title().set_fontweight("bold")

# border
for spine in ax.spines.values():
    spine.set_linewidth(1.0)
    spine.set_color("#333333")

plt.subplots_adjust(
    left=0.07,
    right=0.99,
    top=0.88,
    bottom=0.36
)

# =========================================================
# 7. Save
# =========================================================

out_png = os.path.join(OUTDIR, "subtype_performance_most15_least15.png")
out_pdf = os.path.join(OUTDIR, "subtype_performance_most15_least15.pdf")
out_tif = os.path.join(OUTDIR, "subtype_performance_most15_least15.tif")

plt.savefig(out_png, dpi=DPI, bbox_inches="tight")
plt.savefig(out_pdf, dpi=DPI, bbox_inches="tight")
plt.savefig(out_tif, dpi=DPI, bbox_inches="tight")

plt.close(fig)

print("Saved:")
print(out_png)
print(out_pdf)
print(out_tif)
print(os.path.join(OUTDIR, "subtype_performance_all_metrics.csv"))
print(os.path.join(OUTDIR, "subtype_performance_most15_least15_metrics.csv"))

print("\nSelected subtypes:")
print(
    plot_df[
        ["Subtype", "Subtype_display", "Type", "support", "Precision", "Recall", "F1-score"]
    ].to_string(index=False)
)