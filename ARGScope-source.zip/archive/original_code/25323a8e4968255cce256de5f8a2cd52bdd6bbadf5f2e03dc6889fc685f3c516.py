#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARGScope multi-length protein student
=====================================

Purpose
-------
Train one protein-only ARG subtype model that is robust to:
    100p: full protein sequence, one view per parent sequence
     90p: 90% sequence-length crops, five views per parent sequence
     80p: 80% sequence-length crops, five views per parent sequence
     70p: 70% sequence-length crops, five views per parent sequence
     60p: 60% sequence-length crops, five views per parent sequence

Training-time information
-------------------------
1. Protein ESM-2 embeddings from 100p and 60p-90p.
2. Same-view Fusion embeddings from 100p and 60p-90p.
3. Parent 100p Fusion embedding for every short crop.
4. 100p refined subtype prototypes as a weak classifier-center prior.
5. Parent ID and length ratio.

Inference-time information
--------------------------
Only protein embedding and sequence completeness ratio are required.

Core losses
-----------
Fusion teacher:
    subtype ArcFace CE
    + supervised contrastive loss
    + weak refined-prototype anchor

Protein student:
    subtype ArcFace CE
    + supervised contrastive loss
    + same-view Fusion embedding alignment
    + parent-100p Fusion embedding alignment
    + same-view Fusion logit distillation
    + parent-100p Fusion logit distillation
    + weak refined-prototype anchor

Data leakage prevention
-----------------------
- train/test are inherited from the original 100p parent IDs.
- validation is created only from the original 100p training parents.
- all 60p-90p crops from the same parent remain in exactly one split.
- scalers are fitted only on training parents.
- validation is used for early stopping.
- test is used only after model selection.

Expected files in --data-dir
----------------------------
1.100p_all_fusion_embedding_512_with_label.csv
1.60p_all_fusion_embedding_512_with_label.csv
1.70p_all_fusion_embedding_512_with_label.csv
1.80p_all_fusion_embedding_512_with_label.csv
1.90p_all_fusion_embedding_512_with_label.csv

2.100p_ARG_protein_with_label.csv
2.60p_ARG_protein_with_label.csv
2.70p_ARG_protein_with_label.csv
2.80p_ARG_protein_with_label.csv
2.90p_ARG_protein_with_label.csv

4.100p_all_Refined_embeddings_512.csv
train_set.csv
test_set.csv
expanded_id_table_5x2.csv

Optional cross-check files:
train_set_shortread.csv
test_set_shortread.csv
"""

from __future__ import annotations

import argparse
import copy
import gc
import json
import math
import os
import random
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
)
from sklearn.preprocessing import LabelEncoder, StandardScaler
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler


# =============================================================================
# Configuration
# =============================================================================

LENGTH_ORDER = ["60p", "70p", "80p", "90p", "100p"]
LENGTH_RATIO = {
    "60p": 0.60,
    "70p": 0.70,
    "80p": 0.80,
    "90p": 0.90,
    "100p": 1.00,
}

PROTEIN_FILES = {
    "100p": "2.100p_ARG_protein_with_label.csv",
    "90p": "2.90p_ARG_protein_with_label.csv",
    "80p": "2.80p_ARG_protein_with_label.csv",
    "70p": "2.70p_ARG_protein_with_label.csv",
    "60p": "2.60p_ARG_protein_with_label.csv",
}

FUSION_FILES = {
    "100p": "1.100p_all_fusion_embedding_512_with_label.csv",
    "90p": "1.90p_all_fusion_embedding_512_with_label.csv",
    "80p": "1.80p_all_fusion_embedding_512_with_label.csv",
    "70p": "1.70p_all_fusion_embedding_512_with_label.csv",
    "60p": "1.60p_all_fusion_embedding_512_with_label.csv",
}

REFINED_DEFAULT = "4.100p_all_Refined_embeddings_512.csv"
TRAIN_SPLIT_DEFAULT = "train_set.csv"
TEST_SPLIT_DEFAULT = "test_set.csv"
EXPANDED_ID_DEFAULT = "expanded_id_table_5x2.csv"

EXPECTED_PROTEIN_DIM = 1280
EXPECTED_FUSION_DIM = 512
EXPECTED_SUBTYPE_COUNT = 2825

SCRIPT_VERSION = "ARGScope_MultiLength_OverlapFix_V2_2026-08-04"

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id",
]
TYPE_CANDIDATES = ["Type", "type", "TYPE"]
SUBTYPE_CANDIDATES = ["Subtype", "subtype", "SUBTYPE"]

PARENT_CANDIDATES = [
    "parent_id", "ParentID", "parent", "Parent",
    "original_id", "OriginalID", "source_id", "SourceID",
    "full_id", "FullID", "base_id", "BaseID",
]


@dataclass
class Config:
    data_dir: str
    output_dir: str
    refined_file: str
    train_split_file: str
    test_split_file: str
    expanded_id_file: str

    seed: int = 281
    val_ratio: float = 0.12

    batch_size: int = 512
    eval_batch_size: int = 2048
    num_workers: int = 8

    teacher_hidden_dim: int = 768
    student_hidden_dim: int = 1024
    embed_dim: int = 512
    residual_blocks: int = 2
    dropout: float = 0.18

    teacher_epochs: int = 120
    student_epochs: int = 220
    teacher_patience: int = 20
    student_patience: int = 35
    teacher_lr: float = 3e-4
    student_lr: float = 1.5e-4
    weight_decay: float = 5e-5
    min_delta: float = 1e-5

    arcface_margin: float = 0.15
    logit_scale: float = 28.0
    label_smoothing: float = 0.003
    supcon_temperature: float = 0.10
    kd_temperature: float = 3.0

    teacher_ce_weight: float = 1.00
    teacher_supcon_weight: float = 0.20
    teacher_refined_weight: float = 0.02

    student_ce_weight: float = 1.00
    student_supcon_weight: float = 0.18
    same_view_align_weight: float = 0.22
    parent_align_weight: float = 0.14
    same_view_kd_weight: float = 0.12
    parent_kd_weight: float = 0.06
    student_refined_weight: float = 0.02

    use_refined_anchor: bool = True
    use_ema: bool = True
    ema_decay: float = 0.995

    class_weight_power: float = 0.18
    class_weight_clip_min: float = 0.85
    class_weight_clip_max: float = 1.50

    sampler_class_power: float = 0.20
    sampler_class_clip_min: float = 0.70
    sampler_class_clip_max: float = 2.00

    eval_every_teacher: int = 2
    eval_every_student: int = 2

    device: str = "auto"
    amp: bool = True
    validate_only: bool = False


def parse_args() -> Config:
    p = argparse.ArgumentParser(
        description="ARGScope multi-length Fusion-teacher Protein-student training"
    )
    p.add_argument(
        "--data-dir",
        default="/scratch/users/ntu/pan.jie/work/ARGSCOPE_newmodel/traingdata",
    )
    p.add_argument(
        "--output-dir",
        default=(
            "/scratch/users/ntu/pan.jie/work/ARGSCOPE_newmodel/"
            "ARGScope_multilength_protein_student_outputs"
        ),
    )
    p.add_argument("--refined-file", default=REFINED_DEFAULT)
    p.add_argument("--train-split-file", default=TRAIN_SPLIT_DEFAULT)
    p.add_argument("--test-split-file", default=TEST_SPLIT_DEFAULT)
    p.add_argument("--expanded-id-file", default=EXPANDED_ID_DEFAULT)

    p.add_argument("--seed", type=int, default=281)
    p.add_argument("--val-ratio", type=float, default=0.12)
    p.add_argument("--batch-size", type=int, default=512)
    p.add_argument("--eval-batch-size", type=int, default=2048)
    p.add_argument("--num-workers", type=int, default=8)
    p.add_argument("--teacher-epochs", type=int, default=120)
    p.add_argument("--student-epochs", type=int, default=220)
    p.add_argument("--teacher-patience", type=int, default=20)
    p.add_argument("--student-patience", type=int, default=35)
    p.add_argument("--teacher-lr", type=float, default=3e-4)
    p.add_argument("--student-lr", type=float, default=1.5e-4)
    p.add_argument("--device", default="auto")
    p.add_argument("--no-amp", action="store_true")
    p.add_argument("--no-refined-anchor", action="store_true")
    p.add_argument("--validate-only", action="store_true")

    a = p.parse_args()
    return Config(
        data_dir=a.data_dir,
        output_dir=a.output_dir,
        refined_file=a.refined_file,
        train_split_file=a.train_split_file,
        test_split_file=a.test_split_file,
        expanded_id_file=a.expanded_id_file,
        seed=a.seed,
        val_ratio=a.val_ratio,
        batch_size=a.batch_size,
        eval_batch_size=a.eval_batch_size,
        num_workers=a.num_workers,
        teacher_epochs=a.teacher_epochs,
        student_epochs=a.student_epochs,
        teacher_patience=a.teacher_patience,
        student_patience=a.student_patience,
        teacher_lr=a.teacher_lr,
        student_lr=a.student_lr,
        device=a.device,
        amp=not a.no_amp,
        use_refined_anchor=not a.no_refined_anchor,
        validate_only=a.validate_only,
    )


# =============================================================================
# Utilities
# =============================================================================

def seed_everything(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def resolve_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(value)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but torch.cuda.is_available() is False")
    return device


def save_json(obj: object, path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2)


def natural_key(value: object):
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", str(value))
    ]


def normalize_text_series(series: pd.Series) -> pd.Series:
    return series.astype(str).str.replace("\ufeff", "", regex=False).str.strip()


def find_column(df: pd.DataFrame, candidates: Sequence[str]) -> Optional[str]:
    lower_map = {str(c).strip().casefold(): c for c in df.columns}
    for candidate in candidates:
        actual = lower_map.get(str(candidate).strip().casefold())
        if actual is not None:
            return actual
    return None


def require_file(path: Path, description: str) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"{description} not found: {path}")


def get_feature_cols(df: pd.DataFrame) -> List[str]:
    exclude = {
        "key", "id", "geneid", "nucleotideid", "proteinid", "protein_id",
        "type", "subtype", "split", "count", "subtype_index", "type_index",
        "parent_id", "length_name", "length_ratio", "crop_index",
    }
    cols = []
    for c in df.columns:
        c_text = str(c).strip()
        if c_text.casefold() in exclude:
            continue
        if c_text.casefold().startswith("unnamed:"):
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return sorted(cols, key=natural_key)


def ensure_numeric_matrix(
    df: pd.DataFrame,
    cols: Sequence[str],
    name: str,
    expected_dim: int,
) -> np.ndarray:
    if len(cols) != expected_dim:
        raise ValueError(
            f"{name}: expected {expected_dim} feature columns, found {len(cols)}"
        )
    numeric = df[list(cols)].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        bad = np.argwhere(numeric.isna().to_numpy())[:10].tolist()
        raise ValueError(f"{name}: nonnumeric or missing values at {bad}")
    matrix = numeric.to_numpy(dtype=np.float32, copy=True)
    if not np.isfinite(matrix).all():
        raise ValueError(f"{name}: contains NaN/Inf")
    if np.any(np.linalg.norm(matrix, axis=1) <= 1e-12):
        raise ValueError(f"{name}: contains all-zero rows")
    return matrix


def chunked_transform(
    scaler: StandardScaler,
    x: np.ndarray,
    chunk_size: int = 50000,
) -> np.ndarray:
    out = np.empty_like(x, dtype=np.float32)
    for start in range(0, len(x), chunk_size):
        end = min(start + chunk_size, len(x))
        out[start:end] = scaler.transform(x[start:end]).astype(np.float32)
    return out


def l2_normalize_np(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), eps)


def make_grad_scaler(enabled: bool):
    return torch.amp.GradScaler("cuda", enabled=enabled)


def amp_autocast(enabled: bool):
    return torch.amp.autocast(device_type="cuda", enabled=enabled)


# =============================================================================
# ID and split handling
# =============================================================================

def read_split_ids(path: Path, name: str) -> pd.DataFrame:
    require_file(path, name)
    df = pd.read_csv(path, low_memory=False)
    key_col = find_column(df, KEY_CANDIDATES)
    if key_col is None:
        raise ValueError(f"{name}: no ID column; columns={df.columns.tolist()}")
    type_col = find_column(df, TYPE_CANDIDATES)
    subtype_col = find_column(df, SUBTYPE_CANDIDATES)

    out = pd.DataFrame({"parent_id": normalize_text_series(df[key_col])})
    if type_col is not None:
        out["Type"] = normalize_text_series(df[type_col])
    if subtype_col is not None:
        out["Subtype"] = normalize_text_series(df[subtype_col])

    if out["parent_id"].duplicated().any():
        examples = out.loc[
            out["parent_id"].duplicated(keep=False), "parent_id"
        ].head(20).tolist()
        raise ValueError(f"{name}: duplicated parent IDs: {examples}")
    return out


def build_parent_split(
    parent_label_df: pd.DataFrame,
    train_split_path: Path,
    test_split_path: Path,
    val_ratio: float,
    seed: int,
) -> pd.DataFrame:
    """Build leakage-aware parent splits for the project's overlap design.

    In the current ARGScope split, train_set.csv and test_set.csv intentionally
    overlap for singleton/rare Subtypes. Those overlap IDs are required in the
    training reference so that all 2,825 Subtypes remain learnable. Therefore:

    - overlap IDs remain in the training pool;
    - validation is sampled only from train-only IDs, never from overlap IDs;
    - independent test consists only of test IDs absent from train_set.csv;
    - the complete test_set.csv is retained separately as a coverage set,
      explicitly marked as containing training overlap.

    This preserves the original all-Subtype coverage evaluation while also
    producing an uncontaminated independent-test result.
    """
    train_file = read_split_ids(train_split_path, "train_set.csv")
    test_file = read_split_ids(test_split_path, "test_set.csv")

    train_ids = set(train_file["parent_id"])
    coverage_test_ids = set(test_file["parent_id"])
    overlap_ids = train_ids & coverage_test_ids
    independent_test_ids = coverage_test_ids - train_ids

    print("\nOriginal parent-set relationships:")
    print(f"  train_set parents:                 {len(train_ids):,}")
    print(f"  test_set coverage parents:         {len(coverage_test_ids):,}")
    print(f"  train/test overlap parents:        {len(overlap_ids):,}")
    print(f"  independent test-only parents:     {len(independent_test_ids):,}")
    if overlap_ids:
        print(
            "  NOTE: overlap is retained as training + coverage evaluation; "
            "it is excluded from independent-test metrics."
        )

    all_parent_ids = set(parent_label_df["parent_id"])
    missing_train = sorted(train_ids - all_parent_ids)
    missing_test = sorted(coverage_test_ids - all_parent_ids)
    if missing_train or missing_test:
        raise ValueError(
            "100p split IDs are absent from 100p protein data. "
            f"missing_train={len(missing_train)}, missing_test={len(missing_test)}, "
            f"train_examples={missing_train[:10]}, test_examples={missing_test[:10]}"
        )

    uncovered = sorted(all_parent_ids - train_ids - coverage_test_ids)
    if uncovered:
        raise ValueError(
            f"{len(uncovered)} 100p parent IDs are not assigned by train_set/test_set. "
            f"Examples={uncovered[:20]}"
        )

    # Validation candidates must be train-only parents. Overlap parents remain
    # training-only because they are commonly singleton/rare Subtype supports.
    validation_candidate_ids = train_ids - overlap_ids
    train_parent_df = parent_label_df[
        parent_label_df["parent_id"].isin(validation_candidate_ids)
    ].copy()

    rng = np.random.default_rng(seed)
    val_ids: List[str] = []

    for subtype, group in train_parent_df.groupby("Subtype", sort=True):
        ids = group["parent_id"].to_numpy(copy=True)
        rng.shuffle(ids)
        n = len(ids)

        # Rare Subtypes remain training-only, preserving complete class coverage.
        if n < 5:
            continue

        # Count all train supports for this Subtype, including overlap supports.
        total_train_support = int(
            (
                parent_label_df["parent_id"].isin(train_ids)
                & (parent_label_df["Subtype"] == subtype)
            ).sum()
        )
        n_val = max(1, int(round(n * val_ratio)))
        # Always leave at least one train-only candidate and at least one total
        # training support after validation removal.
        n_val = min(n_val, n - 1, total_train_support - 1)
        if n_val > 0:
            val_ids.extend(ids[:n_val].tolist())

    val_ids_set = set(val_ids)
    effective_train = train_ids - val_ids_set

    split_rows = []
    for row in parent_label_df.itertuples(index=False):
        parent_id = row.parent_id
        in_train_file = parent_id in train_ids
        in_coverage_test = parent_id in coverage_test_ids
        is_overlap = parent_id in overlap_ids

        if parent_id in val_ids_set:
            split = "val"
        elif in_train_file:
            split = "train"
        elif parent_id in independent_test_ids:
            split = "test"
        else:
            raise RuntimeError(f"Unassigned parent: {parent_id}")

        split_rows.append(
            {
                "parent_id": parent_id,
                "Type": row.Type,
                "Subtype": row.Subtype,
                "split": split,
                "in_train_file": bool(in_train_file),
                "in_coverage_test": bool(in_coverage_test),
                "is_train_test_overlap": bool(is_overlap),
                "evaluation_scope": (
                    "train_and_coverage_overlap"
                    if is_overlap
                    else "independent_test"
                    if parent_id in independent_test_ids
                    else "validation"
                    if parent_id in val_ids_set
                    else "train_only"
                ),
            }
        )

    out = pd.DataFrame(split_rows)

    train_subtypes = set(out.loc[out["split"] == "train", "Subtype"])
    val_subtypes = set(out.loc[out["split"] == "val", "Subtype"])
    independent_subtypes = set(out.loc[out["split"] == "test", "Subtype"])
    missing = sorted((val_subtypes | independent_subtypes) - train_subtypes)
    if missing:
        raise ValueError(
            "Validation/independent test contain Subtypes absent from effective "
            f"training. Examples={missing[:20]}"
        )

    print("\nEffective parent split:")
    print(
        out.groupby("split")
        .agg(
            parents=("parent_id", "size"),
            Types=("Type", "nunique"),
            Subtypes=("Subtype", "nunique"),
        )
        .reset_index()
        .to_string(index=False)
    )
    print(
        f"Coverage evaluation parents: {int(out['in_coverage_test'].sum()):,} "
        f"(overlap={int(out['is_train_test_overlap'].sum()):,}, "
        f"independent={len(independent_test_ids):,})"
    )
    return out


def read_expanded_id_map(
    path: Path,
    known_parent_ids: set,
) -> pd.DataFrame:
    require_file(path, "expanded_id_table_5x2.csv")
    df = pd.read_csv(path, low_memory=False)
    key_col = find_column(df, KEY_CANDIDATES)
    if key_col is None:
        raise ValueError(
            f"expanded ID table has no ID column; columns={df.columns.tolist()}"
        )

    parent_col = find_column(df, PARENT_CANDIDATES)
    type_col = find_column(df, TYPE_CANDIDATES)
    subtype_col = find_column(df, SUBTYPE_CANDIDATES)

    out = pd.DataFrame({"KEY": normalize_text_series(df[key_col])})

    if parent_col is not None:
        out["parent_id"] = normalize_text_series(df[parent_col])
    else:
        out["parent_id"] = out["KEY"].str.replace(
            r"_([1-5])$", "", regex=True
        )

    out["crop_index"] = pd.to_numeric(
        out["KEY"].str.extract(r"_([1-5])$", expand=False),
        errors="coerce",
    ).fillna(-1).astype(int)

    if type_col is not None:
        out["Type_map"] = normalize_text_series(df[type_col])
    if subtype_col is not None:
        out["Subtype_map"] = normalize_text_series(df[subtype_col])

    if out["KEY"].duplicated().any():
        examples = out.loc[
            out["KEY"].duplicated(keep=False), "KEY"
        ].head(20).tolist()
        raise ValueError(f"expanded ID table has duplicate IDs: {examples}")

    bad_parent = out.loc[~out["parent_id"].isin(known_parent_ids), "parent_id"]
    if len(bad_parent) > 0:
        # Secondary inference: remove common crop suffix forms.
        candidate = out["KEY"].str.replace(
            r"(?:_part|_crop|_fragment)?[_-]?([1-5])$",
            "",
            regex=True,
            case=False,
        )
        replace_mask = ~out["parent_id"].isin(known_parent_ids) & candidate.isin(
            known_parent_ids
        )
        out.loc[replace_mask, "parent_id"] = candidate[replace_mask]

    bad_parent = out.loc[~out["parent_id"].isin(known_parent_ids), "parent_id"]
    if len(bad_parent) > 0:
        examples = bad_parent.head(20).tolist()
        raise ValueError(
            f"Cannot map {len(bad_parent)} expanded IDs to 100p parent IDs. "
            f"Examples={examples}. The expanded table needs a parent/original ID "
            "column, or short IDs must end in _1 ... _5."
        )

    return out


# =============================================================================
# Reading and aligning embedding files
# =============================================================================

def prepare_embedding_frame(
    path: Path,
    name: str,
) -> Tuple[pd.DataFrame, List[str], str, str, str]:
    require_file(path, name)
    print(f"Reading {name}: {path}")
    df = pd.read_csv(path, low_memory=False)
    df.columns = [str(c).replace("\ufeff", "").strip() for c in df.columns]

    key_col = find_column(df, KEY_CANDIDATES)
    type_col = find_column(df, TYPE_CANDIDATES)
    subtype_col = find_column(df, SUBTYPE_CANDIDATES)

    if key_col is None:
        raise ValueError(f"{name}: no ID column; columns={df.columns.tolist()}")
    if type_col is None or subtype_col is None:
        raise ValueError(
            f"{name}: Type/Subtype columns required; columns={df.columns.tolist()}"
        )

    df[key_col] = normalize_text_series(df[key_col])
    df[type_col] = normalize_text_series(df[type_col])
    df[subtype_col] = normalize_text_series(df[subtype_col])

    if df[key_col].duplicated().any():
        examples = df.loc[
            df[key_col].duplicated(keep=False), key_col
        ].head(20).tolist()
        raise ValueError(f"{name}: duplicate IDs: {examples}")

    feat_cols = get_feature_cols(df)
    return df, feat_cols, key_col, type_col, subtype_col


def load_one_length(
    data_dir: Path,
    length_name: str,
    expanded_map: Optional[pd.DataFrame],
    known_parent_ids: set,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    protein_path = data_dir / PROTEIN_FILES[length_name]
    fusion_path = data_dir / FUSION_FILES[length_name]

    protein_df, protein_cols, p_key, p_type, p_sub = prepare_embedding_frame(
        protein_path, f"{length_name} protein"
    )
    fusion_df, fusion_cols, f_key, f_type, f_sub = prepare_embedding_frame(
        fusion_path, f"{length_name} Fusion"
    )

    if len(protein_cols) != EXPECTED_PROTEIN_DIM:
        raise ValueError(
            f"{protein_path.name}: protein dim={len(protein_cols)}, "
            f"expected={EXPECTED_PROTEIN_DIM}"
        )
    if len(fusion_cols) != EXPECTED_FUSION_DIM:
        raise ValueError(
            f"{fusion_path.name}: Fusion dim={len(fusion_cols)}, "
            f"expected={EXPECTED_FUSION_DIM}"
        )

    p_meta = protein_df[[p_key, p_type, p_sub]].copy()
    p_meta.columns = ["KEY", "Type_protein", "Subtype_protein"]
    f_meta = fusion_df[[f_key, f_type, f_sub]].copy()
    f_meta.columns = ["KEY", "Type_fusion", "Subtype_fusion"]

    # Align without relying on original row order.
    p_order = pd.Series(np.arange(len(protein_df)), index=p_meta["KEY"])
    f_order = pd.Series(np.arange(len(fusion_df)), index=f_meta["KEY"])

    protein_keys = set(p_meta["KEY"])
    fusion_keys = set(f_meta["KEY"])
    if protein_keys != fusion_keys:
        raise ValueError(
            f"{length_name}: protein/Fusion ID mismatch; "
            f"protein_only={len(protein_keys - fusion_keys)}, "
            f"fusion_only={len(fusion_keys - protein_keys)}"
        )

    ordered_keys = p_meta["KEY"].tolist()
    p_idx = p_order.loc[ordered_keys].to_numpy(dtype=np.int64)
    f_idx = f_order.loc[ordered_keys].to_numpy(dtype=np.int64)

    p_meta_aligned = p_meta.iloc[p_idx].reset_index(drop=True)
    f_meta_aligned = f_meta.iloc[f_idx].reset_index(drop=True)

    bad_type = (
        p_meta_aligned["Type_protein"].to_numpy()
        != f_meta_aligned["Type_fusion"].to_numpy()
    )
    bad_sub = (
        p_meta_aligned["Subtype_protein"].to_numpy()
        != f_meta_aligned["Subtype_fusion"].to_numpy()
    )
    if bad_type.any() or bad_sub.any():
        raise ValueError(
            f"{length_name}: protein/Fusion label mismatch; "
            f"type={int(bad_type.sum())}, subtype={int(bad_sub.sum())}"
        )

    protein_matrix = ensure_numeric_matrix(
        protein_df.iloc[p_idx].reset_index(drop=True),
        protein_cols,
        f"{length_name} protein",
        EXPECTED_PROTEIN_DIM,
    )
    fusion_matrix = ensure_numeric_matrix(
        fusion_df.iloc[f_idx].reset_index(drop=True),
        fusion_cols,
        f"{length_name} Fusion",
        EXPECTED_FUSION_DIM,
    )

    meta = pd.DataFrame(
        {
            "KEY": p_meta_aligned["KEY"],
            "Type": p_meta_aligned["Type_protein"],
            "Subtype": p_meta_aligned["Subtype_protein"],
            "length_name": length_name,
            "length_ratio": LENGTH_RATIO[length_name],
        }
    )

    if length_name == "100p":
        meta["parent_id"] = meta["KEY"]
        meta["crop_index"] = 0
        if not meta["parent_id"].isin(known_parent_ids).all():
            bad = meta.loc[
                ~meta["parent_id"].isin(known_parent_ids), "parent_id"
            ].head(20).tolist()
            raise ValueError(f"100p IDs disagree with parent set: {bad}")
    else:
        if expanded_map is None:
            raise RuntimeError("expanded_map is required for short datasets")
        meta = meta.merge(
            expanded_map,
            on="KEY",
            how="left",
            validate="one_to_one",
        )
        if meta["parent_id"].isna().any():
            examples = meta.loc[meta["parent_id"].isna(), "KEY"].head(20).tolist()
            raise ValueError(
                f"{length_name}: IDs missing from expanded_id_table: {examples}"
            )

        if "Type_map" in meta.columns:
            bad = meta["Type"].astype(str) != meta["Type_map"].astype(str)
            if bad.any():
                examples = meta.loc[
                    bad, ["KEY", "Type", "Type_map"]
                ].head(20).to_dict("records")
                raise ValueError(
                    f"{length_name}: Type differs from expanded table: {examples}"
                )
        if "Subtype_map" in meta.columns:
            bad = meta["Subtype"].astype(str) != meta["Subtype_map"].astype(str)
            if bad.any():
                examples = meta.loc[
                    bad, ["KEY", "Subtype", "Subtype_map"]
                ].head(20).to_dict("records")
                raise ValueError(
                    f"{length_name}: Subtype differs from expanded table: {examples}"
                )

        keep = [
            "KEY", "Type", "Subtype", "length_name", "length_ratio",
            "parent_id", "crop_index",
        ]
        meta = meta[keep].copy()

    print(
        f"{length_name}: rows={len(meta):,}, parents={meta['parent_id'].nunique():,}, "
        f"protein_dim={protein_matrix.shape[1]}, fusion_dim={fusion_matrix.shape[1]}"
    )

    del protein_df, fusion_df, p_meta, f_meta
    gc.collect()

    return meta.reset_index(drop=True), protein_matrix, fusion_matrix


def load_all_data(
    cfg: Config,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, pd.DataFrame]:
    data_dir = Path(cfg.data_dir)

    # Read only 100p metadata first to establish the authoritative parent list.
    p100_path = data_dir / PROTEIN_FILES["100p"]
    p100_df, p100_cols, p100_key, p100_type, p100_sub = prepare_embedding_frame(
        p100_path, "100p protein metadata"
    )
    if len(p100_cols) != EXPECTED_PROTEIN_DIM:
        raise ValueError(
            f"100p protein dim={len(p100_cols)}, expected={EXPECTED_PROTEIN_DIM}"
        )

    parent_labels = pd.DataFrame(
        {
            "parent_id": normalize_text_series(p100_df[p100_key]),
            "Type": normalize_text_series(p100_df[p100_type]),
            "Subtype": normalize_text_series(p100_df[p100_sub]),
        }
    )
    if parent_labels["parent_id"].duplicated().any():
        raise ValueError("100p protein file contains duplicated parent IDs")

    subtype_type_n = parent_labels.groupby("Subtype")["Type"].nunique()
    conflicts = subtype_type_n[subtype_type_n > 1]
    if len(conflicts) > 0:
        raise ValueError(
            f"{len(conflicts)} Subtypes map to multiple Types in 100p data"
        )

    known_parent_ids = set(parent_labels["parent_id"])
    del p100_df
    gc.collect()

    parent_split = build_parent_split(
        parent_label_df=parent_labels,
        train_split_path=data_dir / cfg.train_split_file,
        test_split_path=data_dir / cfg.test_split_file,
        val_ratio=cfg.val_ratio,
        seed=cfg.seed,
    )

    expanded_map = read_expanded_id_map(
        data_dir / cfg.expanded_id_file,
        known_parent_ids=known_parent_ids,
    )

    meta_parts: List[pd.DataFrame] = []
    protein_parts: List[np.ndarray] = []
    fusion_parts: List[np.ndarray] = []

    for length_name in ["100p", "90p", "80p", "70p", "60p"]:
        meta, protein, fusion = load_one_length(
            data_dir=data_dir,
            length_name=length_name,
            expanded_map=None if length_name == "100p" else expanded_map,
            known_parent_ids=known_parent_ids,
        )
        meta_parts.append(meta)
        protein_parts.append(protein)
        fusion_parts.append(fusion)

    meta_all = pd.concat(meta_parts, ignore_index=True)
    protein_all = np.concatenate(protein_parts, axis=0).astype(np.float32)
    fusion_all = np.concatenate(fusion_parts, axis=0).astype(np.float32)

    meta_all = meta_all.merge(
        parent_split[
            [
                "parent_id",
                "split",
                "in_train_file",
                "in_coverage_test",
                "is_train_test_overlap",
                "evaluation_scope",
            ]
        ],
        on="parent_id",
        how="left",
        validate="many_to_one",
    )
    if meta_all["split"].isna().any():
        examples = meta_all.loc[
            meta_all["split"].isna(), ["KEY", "parent_id"]
        ].head(20).to_dict("records")
        raise ValueError(f"Rows without inherited parent split: {examples}")

    # Parent labels must be identical across all crops and lengths.
    parent_consistency = (
        meta_all.groupby("parent_id")
        .agg(Type_n=("Type", "nunique"), Subtype_n=("Subtype", "nunique"))
    )
    bad = parent_consistency[
        (parent_consistency["Type_n"] != 1)
        | (parent_consistency["Subtype_n"] != 1)
    ]
    if len(bad) > 0:
        raise ValueError(
            f"{len(bad)} parents have inconsistent labels across views"
        )

    # Every short length should have five crops per parent.
    count_table = (
        meta_all.groupby(["parent_id", "length_name"])
        .size()
        .unstack(fill_value=0)
    )
    for length_name in ["60p", "70p", "80p", "90p"]:
        if length_name not in count_table.columns:
            raise ValueError(f"Missing length dataset: {length_name}")
        wrong = count_table[count_table[length_name] != 5]
        if len(wrong) > 0:
            examples = wrong[length_name].head(20).to_dict()
            raise ValueError(
                f"{length_name}: expected five crops per parent; "
                f"{len(wrong)} parents differ. Examples={examples}"
            )
    wrong_100 = count_table[count_table["100p"] != 1]
    if len(wrong_100) > 0:
        raise ValueError(
            f"100p: expected one row per parent; {len(wrong_100)} parents differ"
        )

    del meta_parts, protein_parts, fusion_parts, expanded_map
    gc.collect()

    print("\nCombined primary dataset:")
    print(
        meta_all.groupby(["split", "length_name"])
        .agg(
            rows=("KEY", "size"),
            parents=("parent_id", "nunique"),
            subtypes=("Subtype", "nunique"),
        )
        .reset_index()
        .to_string(index=False)
    )

    print("\nCoverage-test dataset, including intentional train overlap:")
    coverage_meta = meta_all[meta_all["in_coverage_test"]].copy()
    coverage_meta["overlap_parent_id"] = coverage_meta["parent_id"].where(
        coverage_meta["is_train_test_overlap"]
    )
    print(
        coverage_meta.groupby("length_name")
        .agg(
            rows=("KEY", "size"),
            parents=("parent_id", "nunique"),
            overlap_parents=("overlap_parent_id", "nunique"),
            subtypes=("Subtype", "nunique"),
        )
        .reset_index()
        .to_string(index=False)
    )

    return meta_all, protein_all, fusion_all, parent_split


# =============================================================================
# Labels, scalers, refined prototypes
# =============================================================================

def build_label_objects(
    meta_all: pd.DataFrame,
    out_dir: Path,
) -> Tuple[LabelEncoder, np.ndarray, Dict[str, str]]:
    train_subtypes = sorted(
        meta_all.loc[meta_all["split"] == "train", "Subtype"].unique()
    )
    encoder = LabelEncoder()
    encoder.fit(train_subtypes)

    if len(encoder.classes_) != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Effective training contains {len(encoder.classes_)} Subtypes; "
            f"expected {EXPECTED_SUBTYPE_COUNT}. Validation splitting may have "
            "removed a rare subtype from training."
        )

    unseen = sorted(set(meta_all["Subtype"]) - set(encoder.classes_))
    if unseen:
        raise ValueError(f"Nontraining data contain unseen Subtypes: {unseen[:20]}")

    y = encoder.transform(meta_all["Subtype"]).astype(np.int64)

    mapping = (
        meta_all[["Subtype", "Type"]]
        .drop_duplicates()
        .sort_values(["Type", "Subtype"])
    )
    if mapping["Subtype"].duplicated().any():
        raise ValueError("A Subtype maps to multiple Types")
    subtype_to_type = dict(zip(mapping["Subtype"], mapping["Type"]))

    mapping.to_csv(
        out_dir / "subtype_type_map.csv",
        index=False,
        encoding="utf-8-sig",
    )
    joblib.dump(encoder, out_dir / "subtype_encoder.joblib")
    return encoder, y, subtype_to_type


def balanced_scaler_fit_indices(meta_all: pd.DataFrame) -> np.ndarray:
    train_meta = meta_all[meta_all["split"] == "train"].copy()
    # One representative crop per parent and length prevents fivefold short-view
    # expansion from dominating scaler statistics.
    selected = (
        train_meta.sort_values(["parent_id", "length_name", "crop_index", "KEY"])
        .groupby(["parent_id", "length_name"], sort=False)
        .head(1)
        .index
        .to_numpy(dtype=np.int64)
    )
    return selected


def fit_and_apply_scalers(
    meta_all: pd.DataFrame,
    protein_raw: np.ndarray,
    fusion_raw: np.ndarray,
    out_dir: Path,
) -> Tuple[np.ndarray, np.ndarray, StandardScaler, StandardScaler]:
    fit_idx = balanced_scaler_fit_indices(meta_all)
    print(f"\nScaler fitting rows (length-balanced): {len(fit_idx):,}")

    protein_scaler = StandardScaler()
    fusion_scaler = StandardScaler()

    protein_scaler.fit(protein_raw[fit_idx])
    fusion_scaler.fit(fusion_raw[fit_idx])

    protein_scaled = chunked_transform(protein_scaler, protein_raw)
    fusion_scaled = chunked_transform(fusion_scaler, fusion_raw)

    joblib.dump(protein_scaler, out_dir / "protein_scaler.joblib")
    joblib.dump(fusion_scaler, out_dir / "fusion_scaler.joblib")

    return protein_scaled, fusion_scaled, protein_scaler, fusion_scaler


def build_refined_proto(
    path: Path,
    encoder: LabelEncoder,
    use_anchor: bool,
) -> Optional[np.ndarray]:
    if not use_anchor:
        print("Refined anchor disabled.")
        return None

    if not path.is_file():
        print(
            f"WARNING: refined prototype file not found: {path}. "
            "Training will continue without refined anchor."
        )
        return None

    df = pd.read_csv(path, low_memory=False)
    subtype_col = find_column(df, SUBTYPE_CANDIDATES)
    if subtype_col is None:
        raise ValueError(f"Refined file has no Subtype column: {path}")

    df[subtype_col] = normalize_text_series(df[subtype_col])
    feat_cols = get_feature_cols(df)
    if len(feat_cols) != EXPECTED_FUSION_DIM:
        raise ValueError(
            f"Refined prototype dim={len(feat_cols)}, "
            f"expected={EXPECTED_FUSION_DIM}"
        )

    numeric = df[feat_cols].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        raise ValueError("Refined prototype contains nonnumeric/missing values")
    tmp = pd.concat(
        [df[[subtype_col]].rename(columns={subtype_col: "Subtype"}), numeric],
        axis=1,
    )
    grouped = tmp.groupby("Subtype")[feat_cols].mean()

    missing = [name for name in encoder.classes_ if name not in grouped.index]
    if missing:
        raise ValueError(
            f"Refined file misses {len(missing)} training Subtypes; "
            f"examples={missing[:20]}"
        )

    proto = np.stack(
        [grouped.loc[name].to_numpy(dtype=np.float32) for name in encoder.classes_],
        axis=0,
    )
    proto = l2_normalize_np(proto).astype(np.float32)
    print(f"Loaded refined prototypes: {proto.shape}")
    return proto


def build_parent_fusion_table(
    meta_all: pd.DataFrame,
    fusion_scaled: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    parent_ids = sorted(meta_all["parent_id"].unique())
    parent_to_index = {parent_id: i for i, parent_id in enumerate(parent_ids)}

    p100 = meta_all[meta_all["length_name"] == "100p"].copy()
    p100["row_index"] = p100.index
    p100 = p100.set_index("parent_id").loc[parent_ids]

    parent_fusion = fusion_scaled[p100["row_index"].to_numpy(dtype=np.int64)]
    parent_index = (
        meta_all["parent_id"].map(parent_to_index).to_numpy(dtype=np.int64)
    )
    return parent_fusion.astype(np.float32), parent_index, parent_ids


# =============================================================================
# Dataset and sampling
# =============================================================================

class MultiLengthDataset(Dataset):
    def __init__(
        self,
        protein: np.ndarray,
        fusion: np.ndarray,
        labels: np.ndarray,
        lengths: np.ndarray,
        parent_index: np.ndarray,
        parent_fusion: np.ndarray,
        selected_indices: np.ndarray,
    ) -> None:
        self.protein = torch.from_numpy(protein)
        self.fusion = torch.from_numpy(fusion)
        self.labels = torch.from_numpy(labels.astype(np.int64))
        self.lengths = torch.from_numpy(lengths.astype(np.float32))
        self.parent_index = torch.from_numpy(parent_index.astype(np.int64))
        self.parent_fusion = torch.from_numpy(parent_fusion)
        self.selected_indices = torch.from_numpy(
            selected_indices.astype(np.int64)
        )

    def __len__(self) -> int:
        return len(self.selected_indices)

    def __getitem__(self, i: int):
        idx = self.selected_indices[i]
        pidx = self.parent_index[idx]
        return (
            self.protein[idx],
            self.fusion[idx],
            self.labels[idx],
            self.lengths[idx],
            self.parent_fusion[pidx],
            idx,
        )


def mild_class_weights(
    y_train: np.ndarray,
    num_classes: int,
    power: float,
    clip_min: float,
    clip_max: float,
) -> np.ndarray:
    counts = np.bincount(y_train, minlength=num_classes).astype(np.float64)
    if np.any(counts == 0):
        missing = np.where(counts == 0)[0].tolist()
        raise ValueError(f"Training lacks classes: {missing[:20]}")
    weights = (counts.mean() / counts) ** power
    weights = weights / weights.mean()
    return np.clip(weights, clip_min, clip_max).astype(np.float32)


def make_balanced_sampler(
    meta_all: pd.DataFrame,
    y: np.ndarray,
    selected_indices: np.ndarray,
    cfg: Config,
) -> WeightedRandomSampler:
    meta = meta_all.loc[selected_indices].copy()
    meta["selected_position"] = np.arange(len(meta))
    meta["class_id"] = y[selected_indices]

    crop_counts = (
        meta.groupby(["parent_id", "length_name"])["KEY"]
        .transform("size")
        .to_numpy(dtype=np.float64)
    )
    length_balance = 1.0 / np.maximum(crop_counts, 1.0)

    parent_label = (
        meta[["parent_id", "class_id"]]
        .drop_duplicates("parent_id")
    )
    parent_counts = (
        parent_label["class_id"]
        .value_counts()
        .to_dict()
    )
    mean_count = float(np.mean(list(parent_counts.values())))
    class_factor_map = {
        cid: np.clip(
            (mean_count / count) ** cfg.sampler_class_power,
            cfg.sampler_class_clip_min,
            cfg.sampler_class_clip_max,
        )
        for cid, count in parent_counts.items()
    }
    class_factor = meta["class_id"].map(class_factor_map).to_numpy(dtype=float)

    weights = length_balance * class_factor

    n_parents = meta["parent_id"].nunique()
    n_lengths = meta["length_name"].nunique()
    num_samples = n_parents * n_lengths

    print(
        f"Balanced sampler: source_rows={len(meta):,}, "
        f"parents={n_parents:,}, lengths={n_lengths}, "
        f"samples_per_epoch={num_samples:,}"
    )

    return WeightedRandomSampler(
        weights=torch.tensor(weights, dtype=torch.double),
        num_samples=int(num_samples),
        replacement=True,
    )


def make_loader(
    dataset: Dataset,
    batch_size: int,
    device: torch.device,
    num_workers: int,
    sampler=None,
    shuffle: bool = False,
) -> DataLoader:
    kwargs = {
        "dataset": dataset,
        "batch_size": batch_size,
        "sampler": sampler,
        "shuffle": shuffle if sampler is None else False,
        "num_workers": num_workers,
        "pin_memory": device.type == "cuda",
        "drop_last": False,
    }
    if num_workers > 0:
        kwargs["persistent_workers"] = True
        kwargs["prefetch_factor"] = 2
    return DataLoader(**kwargs)


# =============================================================================
# Models and losses
# =============================================================================

class ResidualBlock(nn.Module):
    def __init__(self, dim: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.gelu(x + self.net(x))


class Encoder(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        embed_dim: int,
        dropout: float,
        blocks: int,
    ) -> None:
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(
            *[ResidualBlock(hidden_dim, dropout) for _ in range(blocks)]
        )
        self.output = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.input(x)
        h = self.blocks(h)
        z = self.output(h)
        return F.normalize(z, p=2, dim=1)


class LengthConditionedProteinEncoder(nn.Module):
    def __init__(
        self,
        protein_dim: int,
        hidden_dim: int,
        embed_dim: int,
        dropout: float,
        blocks: int,
    ) -> None:
        super().__init__()
        self.protein_input = nn.Sequential(
            nn.Linear(protein_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.length_encoder = nn.Sequential(
            nn.Linear(1, 32),
            nn.GELU(),
            nn.Linear(32, 64),
            nn.LayerNorm(64),
            nn.GELU(),
        )
        self.merge = nn.Sequential(
            nn.Linear(hidden_dim + 64, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(
            *[ResidualBlock(hidden_dim, dropout) for _ in range(blocks)]
        )
        self.output = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        protein: torch.Tensor,
        length_ratio: torch.Tensor,
    ) -> torch.Tensor:
        hp = self.protein_input(protein)
        hl = self.length_encoder(length_ratio.view(-1, 1))
        h = self.merge(torch.cat([hp, hl], dim=1))
        h = self.blocks(h)
        z = self.output(h)
        return F.normalize(z, p=2, dim=1)


class ArcMarginHead(nn.Module):
    def __init__(
        self,
        embed_dim: int,
        num_classes: int,
        scale: float,
        margin: float,
    ) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.empty(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = float(scale)
        self.margin = float(margin)
        self.cos_m = math.cos(margin)
        self.sin_m = math.sin(margin)
        self.th = math.cos(math.pi - margin)
        self.mm = math.sin(math.pi - margin) * margin

    def forward(
        self,
        z: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        z = F.normalize(z, p=2, dim=1)
        w = F.normalize(self.weight, p=2, dim=1)
        cosine = F.linear(z, w)

        if labels is None:
            return cosine * self.scale

        cosine_f = cosine.float()
        sine = torch.sqrt(
            torch.clamp(1.0 - cosine_f.pow(2), min=1e-7)
        )
        phi = cosine_f * self.cos_m - sine * self.sin_m
        phi = torch.where(
            cosine_f > self.th,
            phi,
            cosine_f - self.mm,
        )

        one_hot = torch.zeros_like(cosine_f)
        one_hot.scatter_(1, labels.view(-1, 1), 1.0)
        output = one_hot * phi + (1.0 - one_hot) * cosine_f
        return output * self.scale

    def normalized_weight(self) -> torch.Tensor:
        return F.normalize(self.weight.float(), p=2, dim=1)


class FusionTeacher(nn.Module):
    def __init__(self, cfg: Config, num_classes: int) -> None:
        super().__init__()
        self.encoder = Encoder(
            input_dim=EXPECTED_FUSION_DIM,
            hidden_dim=cfg.teacher_hidden_dim,
            embed_dim=cfg.embed_dim,
            dropout=cfg.dropout,
            blocks=cfg.residual_blocks,
        )
        self.head = ArcMarginHead(
            cfg.embed_dim,
            num_classes,
            cfg.logit_scale,
            cfg.arcface_margin,
        )

    def forward(
        self,
        fusion: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ):
        z = self.encoder(fusion)
        margin_logits = self.head(z, labels)
        plain_logits = self.head(z, None)
        return margin_logits, plain_logits, z


class ProteinStudent(nn.Module):
    def __init__(self, cfg: Config, num_classes: int) -> None:
        super().__init__()
        self.encoder = LengthConditionedProteinEncoder(
            protein_dim=EXPECTED_PROTEIN_DIM,
            hidden_dim=cfg.student_hidden_dim,
            embed_dim=cfg.embed_dim,
            dropout=cfg.dropout,
            blocks=cfg.residual_blocks,
        )
        self.head = ArcMarginHead(
            cfg.embed_dim,
            num_classes,
            cfg.logit_scale,
            cfg.arcface_margin,
        )

    def forward(
        self,
        protein: torch.Tensor,
        length_ratio: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ):
        z = self.encoder(protein, length_ratio)
        margin_logits = self.head(z, labels)
        plain_logits = self.head(z, None)
        return margin_logits, plain_logits, z


def supervised_contrastive_loss(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    with torch.amp.autocast(
        device_type=embeddings.device.type,
        enabled=False,
    ):
        z = F.normalize(embeddings.float(), p=2, dim=1)
        labels = labels.long()
        logits = (z @ z.T) / float(temperature)
        n = logits.size(0)
        eye = torch.eye(n, dtype=torch.bool, device=logits.device)
        logits = logits.masked_fill(eye, -1.0e9)

        same = labels.unsqueeze(0).eq(labels.unsqueeze(1)) & ~eye
        pos_count = same.sum(dim=1)
        valid = pos_count > 0
        if not bool(valid.any()):
            return logits.new_zeros(())

        log_prob = logits - torch.logsumexp(logits, dim=1, keepdim=True)
        positive = torch.where(same, log_prob, torch.zeros_like(log_prob))
        mean_pos = positive.sum(dim=1) / pos_count.clamp_min(1)
        return -mean_pos[valid].mean()


def cosine_pull_loss(
    z: torch.Tensor,
    target: torch.Tensor,
    sample_weight: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    z = F.normalize(z.float(), p=2, dim=1)
    target = F.normalize(target.float(), p=2, dim=1)
    loss = 1.0 - torch.sum(z * target, dim=1)
    if sample_weight is not None:
        weight = sample_weight.float()
        return torch.sum(loss * weight) / weight.sum().clamp_min(1e-8)
    return loss.mean()


def kd_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
    sample_weight: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    s = F.log_softmax(student_logits.float() / temperature, dim=1)
    t = F.softmax(teacher_logits.float().detach() / temperature, dim=1)
    per_row = F.kl_div(s, t, reduction="none").sum(dim=1)
    per_row = per_row * (temperature ** 2)
    if sample_weight is not None:
        w = sample_weight.float()
        return torch.sum(per_row * w) / w.sum().clamp_min(1e-8)
    return per_row.mean()


def refined_anchor_loss(
    head: ArcMarginHead,
    refined_proto: Optional[torch.Tensor],
) -> torch.Tensor:
    if refined_proto is None:
        return head.weight.new_zeros(())
    w = head.normalized_weight()
    r = F.normalize(refined_proto.float(), p=2, dim=1)
    if w.shape != r.shape:
        raise ValueError(
            f"Classifier head/refined shape mismatch: {w.shape} vs {r.shape}"
        )
    return (1.0 - torch.sum(w * r, dim=1)).mean()


def length_parent_weight(length_ratio: torch.Tensor) -> torch.Tensor:
    # Stronger parent-100p alignment for more complete sequences.
    # 100p=1.00, 90p=0.80, 80p=0.60, 70p=0.40, 60p=0.25
    r = length_ratio.float()
    weight = torch.where(r >= 0.999, torch.ones_like(r), torch.zeros_like(r))
    weight = torch.where((r >= 0.899) & (r < 0.999), 0.80, weight)
    weight = torch.where((r >= 0.799) & (r < 0.899), 0.60, weight)
    weight = torch.where((r >= 0.699) & (r < 0.799), 0.40, weight)
    weight = torch.where(r < 0.699, 0.25, weight)
    return weight


class EMA:
    def __init__(self, model: nn.Module, decay: float) -> None:
        self.decay = decay
        self.shadow = {
            name: p.detach().clone()
            for name, p in model.named_parameters()
            if p.requires_grad
        }
        self.backup: Dict[str, torch.Tensor] = {}

    def update(self, model: nn.Module) -> None:
        for name, p in model.named_parameters():
            if p.requires_grad:
                self.shadow[name] = (
                    self.decay * self.shadow[name]
                    + (1.0 - self.decay) * p.detach()
                )

    def apply_shadow(self, model: nn.Module) -> None:
        self.backup = {}
        for name, p in model.named_parameters():
            if p.requires_grad:
                self.backup[name] = p.detach().clone()
                p.data.copy_(self.shadow[name].data)

    def restore(self, model: nn.Module) -> None:
        for name, p in model.named_parameters():
            if name in self.backup:
                p.data.copy_(self.backup[name].data)
        self.backup = {}


# =============================================================================
# Metrics and evaluation
# =============================================================================

def metric_dict(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    p_w, r_w, f_w, _ = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )
    p_m, r_m, f_m, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    return {
        "N": int(len(y_true)),
        "class_count": int(len(np.unique(y_true))),
        "ACC": float(accuracy_score(y_true, y_pred)),
        "Precision_weighted": float(p_w),
        "Recall_weighted": float(r_w),
        "F1_weighted": float(f_w),
        "Precision_macro": float(p_m),
        "Recall_macro": float(r_m),
        "F1_macro": float(f_m),
        "MCC": float(
            matthews_corrcoef(y_true, y_pred)
            if len(np.unique(y_true)) > 1
            else 0.0
        ),
    }


def model_selection_score(metrics_by_length: Dict[str, Dict[str, float]]) -> float:
    rows = [metrics_by_length[name] for name in LENGTH_ORDER if name in metrics_by_length]
    mean_wp = float(np.mean([r["Precision_weighted"] for r in rows]))
    mean_acc = float(np.mean([r["ACC"] for r in rows]))
    mean_f1 = float(np.mean([r["F1_weighted"] for r in rows]))
    worst_acc = float(np.min([r["ACC"] for r in rows]))

    # Precision and ACC are the main objectives.
    return (
        0.55 * mean_wp
        + 0.25 * mean_acc
        + 0.10 * mean_f1
        + 0.10 * worst_acc
    )


@torch.no_grad()
def predict_fusion_teacher(
    model: FusionTeacher,
    fusion: np.ndarray,
    labels: np.ndarray,
    meta: pd.DataFrame,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> Tuple[np.ndarray, Dict[str, Dict[str, float]]]:
    model.eval()
    pred = np.empty(len(selected_indices), dtype=np.int64)

    for start in range(0, len(selected_indices), batch_size):
        end = min(start + batch_size, len(selected_indices))
        idx = selected_indices[start:end]
        xb = torch.from_numpy(fusion[idx]).to(device)
        _, logits, _ = model(xb, None)
        pred[start:end] = logits.argmax(dim=1).cpu().numpy()

    true = labels[selected_indices]
    meta_sel = meta.loc[selected_indices].reset_index(drop=True)
    metrics = {}
    for length_name in LENGTH_ORDER:
        mask = meta_sel["length_name"].to_numpy() == length_name
        if mask.any():
            metrics[length_name] = metric_dict(true[mask], pred[mask])
    return pred, metrics


@torch.no_grad()
def predict_student_indices(
    model: ProteinStudent,
    protein: np.ndarray,
    lengths: np.ndarray,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
    return_probs: bool = False,
):
    model.eval()
    pred_parts = []
    confidence_parts = []
    margin_parts = []
    prob_parts = [] if return_probs else None

    for start in range(0, len(selected_indices), batch_size):
        end = min(start + batch_size, len(selected_indices))
        idx = selected_indices[start:end]
        xp = torch.from_numpy(protein[idx]).to(device)
        lr = torch.from_numpy(lengths[idx]).to(device)
        _, logits, _ = model(xp, lr, None)
        probs = torch.softmax(logits.float(), dim=1)
        top2 = torch.topk(probs, k=2, dim=1)

        pred_parts.append(top2.indices[:, 0].cpu().numpy())
        confidence_parts.append(top2.values[:, 0].cpu().numpy())
        margin_parts.append(
            (top2.values[:, 0] - top2.values[:, 1]).cpu().numpy()
        )
        if return_probs:
            prob_parts.append(probs.cpu().numpy().astype(np.float32))

    result = {
        "pred": np.concatenate(pred_parts),
        "confidence": np.concatenate(confidence_parts),
        "margin": np.concatenate(margin_parts),
    }
    if return_probs:
        result["probs"] = np.concatenate(prob_parts)
    return result


def evaluate_student_balanced(
    model: ProteinStudent,
    protein: np.ndarray,
    lengths: np.ndarray,
    labels: np.ndarray,
    meta: pd.DataFrame,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> Dict[str, Dict[str, float]]:
    out = predict_student_indices(
        model=model,
        protein=protein,
        lengths=lengths,
        selected_indices=selected_indices,
        batch_size=batch_size,
        device=device,
        return_probs=False,
    )
    true = labels[selected_indices]
    meta_sel = meta.loc[selected_indices].reset_index(drop=True)

    metrics = {}
    for length_name in LENGTH_ORDER:
        mask = meta_sel["length_name"].to_numpy() == length_name
        if mask.any():
            metrics[length_name] = metric_dict(
                true[mask], out["pred"][mask]
            )
    return metrics


def print_length_metrics(
    title: str,
    metrics: Dict[str, Dict[str, float]],
) -> None:
    print("\n" + title)
    for length_name in LENGTH_ORDER:
        if length_name not in metrics:
            continue
        m = metrics[length_name]
        print(
            f"{length_name:>4s} | N={m['N']:>7d} | "
            f"ACC={m['ACC']:.4f} | WP={m['Precision_weighted']:.4f} | "
            f"WF1={m['F1_weighted']:.4f} | MCC={m['MCC']:.4f}"
        )


# =============================================================================
# Training
# =============================================================================

def train_fusion_teacher(
    cfg: Config,
    fusion: np.ndarray,
    labels: np.ndarray,
    meta: pd.DataFrame,
    train_indices: np.ndarray,
    val_indices: np.ndarray,
    refined_proto_t: Optional[torch.Tensor],
    device: torch.device,
    out_dir: Path,
) -> FusionTeacher:
    print("\n" + "=" * 80)
    print("Stage 1: train multi-length Fusion teacher")
    print("=" * 80)

    train_dataset = MultiLengthDataset(
        protein=np.zeros((len(fusion), 1), dtype=np.float32),
        fusion=fusion,
        labels=labels,
        lengths=meta["length_ratio"].to_numpy(dtype=np.float32),
        parent_index=np.zeros(len(fusion), dtype=np.int64),
        parent_fusion=np.zeros((1, EXPECTED_FUSION_DIM), dtype=np.float32),
        selected_indices=train_indices,
    )
    sampler = make_balanced_sampler(meta, labels, train_indices, cfg)
    loader = make_loader(
        train_dataset,
        cfg.batch_size,
        device,
        cfg.num_workers,
        sampler=sampler,
    )

    num_classes = int(labels.max()) + 1
    model = FusionTeacher(cfg, num_classes).to(device)

    # The refined prototypes have already been transformed with the training-only
    # Fusion scaler. They therefore define the teacher output coordinate system.
    if refined_proto_t is not None:
        if tuple(refined_proto_t.shape) != tuple(model.head.weight.shape):
            raise ValueError(
                f"Refined/head shape mismatch: {refined_proto_t.shape} vs "
                f"{model.head.weight.shape}"
            )
        with torch.no_grad():
            model.head.weight.copy_(refined_proto_t)
        print("Initialized Fusion teacher ArcFace centers from scaled 100p refined prototypes.")

    train_parent_mask = (
        meta.loc[train_indices]
        .drop_duplicates("parent_id")
        .index
        .to_numpy(dtype=np.int64)
    )
    class_w_np = mild_class_weights(
        labels[train_parent_mask],
        num_classes,
        cfg.class_weight_power,
        cfg.class_weight_clip_min,
        cfg.class_weight_clip_max,
    )
    class_w = torch.tensor(class_w_np, device=device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.teacher_lr,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=5,
        min_lr=1e-6,
    )
    amp_enabled = cfg.amp and device.type == "cuda"
    scaler = make_grad_scaler(amp_enabled)

    best_score = -np.inf
    best_state = None
    best_epoch = 0
    no_improve = 0
    history = []

    for epoch in range(1, cfg.teacher_epochs + 1):
        model.train()
        running = {
            "loss": 0.0,
            "ce": 0.0,
            "supcon": 0.0,
            "refined": 0.0,
            "n": 0,
        }

        for _, xf, yb, _, _, _ in loader:
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            with amp_autocast(amp_enabled):
                logits_margin, _, z = model(xf, yb)
                loss_ce = F.cross_entropy(
                    logits_margin,
                    yb,
                    weight=class_w,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_sup = supervised_contrastive_loss(
                    z, yb, cfg.supcon_temperature
                )
                loss_ref = refined_anchor_loss(model.head, refined_proto_t)
                loss = (
                    cfg.teacher_ce_weight * loss_ce
                    + cfg.teacher_supcon_weight * loss_sup
                    + cfg.teacher_refined_weight * loss_ref
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()

            bs = len(yb)
            running["loss"] += float(loss.item()) * bs
            running["ce"] += float(loss_ce.item()) * bs
            running["supcon"] += float(loss_sup.item()) * bs
            running["refined"] += float(loss_ref.item()) * bs
            running["n"] += bs

        evaluate_now = (
            epoch == 1
            or epoch % cfg.eval_every_teacher == 0
            or epoch == cfg.teacher_epochs
        )
        if evaluate_now:
            _, val_metrics = predict_fusion_teacher(
                model, fusion, labels, meta, val_indices,
                cfg.eval_batch_size, device
            )
            score = model_selection_score(val_metrics)
            scheduler.step(score)

            if score > best_score + cfg.min_delta:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                best_epoch = epoch
                no_improve = 0
            else:
                no_improve += 1
        else:
            val_metrics = {}
            score = float("nan")

        row = {
            "epoch": epoch,
            "train_loss": running["loss"] / max(running["n"], 1),
            "train_ce": running["ce"] / max(running["n"], 1),
            "train_supcon": running["supcon"] / max(running["n"], 1),
            "train_refined": running["refined"] / max(running["n"], 1),
            "validation_score": score,
            "lr": optimizer.param_groups[0]["lr"],
        }
        for length_name, m in val_metrics.items():
            row[f"{length_name}_ACC"] = m["ACC"]
            row[f"{length_name}_WP"] = m["Precision_weighted"]
            row[f"{length_name}_WF1"] = m["F1_weighted"]
        history.append(row)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Teacher {epoch:03d}] "
                f"loss={row['train_loss']:.4f} "
                f"score={score:.4f} "
                f"lr={row['lr']:.2e}"
            )
            if val_metrics:
                print_length_metrics("Teacher validation", val_metrics)

        if evaluate_now and no_improve >= cfg.teacher_patience:
            print(
                f"Teacher early stopping at epoch {epoch}; "
                f"best_epoch={best_epoch}, best_score={best_score:.4f}"
            )
            break

    if best_state is None:
        raise RuntimeError("Fusion teacher produced no checkpoint")
    model.load_state_dict(best_state)
    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "fusion_teacher_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "best_validation_score": best_score,
            "config": asdict(cfg),
        },
        out_dir / "fusion_teacher_best.pth",
    )
    return model


def train_protein_student(
    cfg: Config,
    teacher: FusionTeacher,
    protein: np.ndarray,
    fusion: np.ndarray,
    labels: np.ndarray,
    meta: pd.DataFrame,
    parent_index: np.ndarray,
    parent_fusion: np.ndarray,
    train_indices: np.ndarray,
    val_indices: np.ndarray,
    refined_proto_t: Optional[torch.Tensor],
    device: torch.device,
    out_dir: Path,
) -> ProteinStudent:
    print("\n" + "=" * 80)
    print("Stage 2: train shared 60p-100p Protein student")
    print("=" * 80)

    lengths = meta["length_ratio"].to_numpy(dtype=np.float32)
    train_dataset = MultiLengthDataset(
        protein=protein,
        fusion=fusion,
        labels=labels,
        lengths=lengths,
        parent_index=parent_index,
        parent_fusion=parent_fusion,
        selected_indices=train_indices,
    )
    sampler = make_balanced_sampler(meta, labels, train_indices, cfg)
    loader = make_loader(
        train_dataset,
        cfg.batch_size,
        device,
        cfg.num_workers,
        sampler=sampler,
    )

    num_classes = int(labels.max()) + 1
    model = ProteinStudent(cfg, num_classes).to(device)

    # Transfer the teacher's subtype class geometry.
    with torch.no_grad():
        model.head.weight.copy_(teacher.head.weight.detach())
    print("Initialized Protein student ArcFace head from Fusion teacher.")

    for p in teacher.parameters():
        p.requires_grad = False
    teacher.eval()

    train_parent_rows = (
        meta.loc[train_indices]
        .drop_duplicates("parent_id")
        .index
        .to_numpy(dtype=np.int64)
    )
    class_w_np = mild_class_weights(
        labels[train_parent_rows],
        num_classes,
        cfg.class_weight_power,
        cfg.class_weight_clip_min,
        cfg.class_weight_clip_max,
    )
    class_w = torch.tensor(class_w_np, device=device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.student_lr,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=7,
        min_lr=1e-6,
    )
    amp_enabled = cfg.amp and device.type == "cuda"
    scaler = make_grad_scaler(amp_enabled)
    ema = EMA(model, cfg.ema_decay) if cfg.use_ema else None

    best_score = -np.inf
    best_state = None
    best_ema = None
    best_epoch = 0
    no_improve = 0
    history = []

    for epoch in range(1, cfg.student_epochs + 1):
        model.train()
        running = {
            "loss": 0.0,
            "ce": 0.0,
            "supcon": 0.0,
            "same_align": 0.0,
            "parent_align": 0.0,
            "same_kd": 0.0,
            "parent_kd": 0.0,
            "refined": 0.0,
            "n": 0,
        }

        for xp, xf, yb, lr, xf_parent, _ in loader:
            xp = xp.to(device, non_blocking=True)
            xf = xf.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            lr = lr.to(device, non_blocking=True)
            xf_parent = xf_parent.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.no_grad():
                _, teacher_same_logits, z_teacher_same = teacher(xf, None)
                _, teacher_parent_logits, z_teacher_parent = teacher(
                    xf_parent, None
                )

            with amp_autocast(amp_enabled):
                student_margin, student_plain, z_student = model(
                    xp, lr, yb
                )

                loss_ce = F.cross_entropy(
                    student_margin,
                    yb,
                    weight=class_w,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_sup = supervised_contrastive_loss(
                    z_student, yb, cfg.supcon_temperature
                )
                loss_same_align = cosine_pull_loss(
                    z_student, z_teacher_same
                )

                parent_weight = length_parent_weight(lr)
                loss_parent_align = cosine_pull_loss(
                    z_student,
                    z_teacher_parent,
                    sample_weight=parent_weight,
                )

                loss_same_kd = kd_loss(
                    student_plain,
                    teacher_same_logits,
                    cfg.kd_temperature,
                )
                loss_parent_kd = kd_loss(
                    student_plain,
                    teacher_parent_logits,
                    cfg.kd_temperature,
                    sample_weight=parent_weight,
                )
                loss_ref = refined_anchor_loss(
                    model.head, refined_proto_t
                )

                loss = (
                    cfg.student_ce_weight * loss_ce
                    + cfg.student_supcon_weight * loss_sup
                    + cfg.same_view_align_weight * loss_same_align
                    + cfg.parent_align_weight * loss_parent_align
                    + cfg.same_view_kd_weight * loss_same_kd
                    + cfg.parent_kd_weight * loss_parent_kd
                    + cfg.student_refined_weight * loss_ref
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()

            if ema is not None:
                ema.update(model)

            bs = len(yb)
            running["loss"] += float(loss.item()) * bs
            running["ce"] += float(loss_ce.item()) * bs
            running["supcon"] += float(loss_sup.item()) * bs
            running["same_align"] += float(loss_same_align.item()) * bs
            running["parent_align"] += float(loss_parent_align.item()) * bs
            running["same_kd"] += float(loss_same_kd.item()) * bs
            running["parent_kd"] += float(loss_parent_kd.item()) * bs
            running["refined"] += float(loss_ref.item()) * bs
            running["n"] += bs

        evaluate_now = (
            epoch == 1
            or epoch % cfg.eval_every_student == 0
            or epoch == cfg.student_epochs
        )
        if evaluate_now:
            if ema is not None:
                ema.apply_shadow(model)
            val_metrics = evaluate_student_balanced(
                model=model,
                protein=protein,
                lengths=lengths,
                labels=labels,
                meta=meta,
                selected_indices=val_indices,
                batch_size=cfg.eval_batch_size,
                device=device,
            )
            score = model_selection_score(val_metrics)
            if ema is not None:
                ema.restore(model)

            scheduler.step(score)

            if score > best_score + cfg.min_delta:
                best_score = score
                best_state = copy.deepcopy(model.state_dict())
                if ema is not None:
                    best_ema = {
                        k: v.detach().cpu().clone()
                        for k, v in ema.shadow.items()
                    }
                best_epoch = epoch
                no_improve = 0
            else:
                no_improve += 1
        else:
            val_metrics = {}
            score = float("nan")

        n = max(running["n"], 1)
        row = {
            "epoch": epoch,
            "train_loss": running["loss"] / n,
            "train_ce": running["ce"] / n,
            "train_supcon": running["supcon"] / n,
            "train_same_align": running["same_align"] / n,
            "train_parent_align": running["parent_align"] / n,
            "train_same_kd": running["same_kd"] / n,
            "train_parent_kd": running["parent_kd"] / n,
            "train_refined": running["refined"] / n,
            "validation_score": score,
            "lr": optimizer.param_groups[0]["lr"],
        }
        for length_name, m in val_metrics.items():
            row[f"{length_name}_ACC"] = m["ACC"]
            row[f"{length_name}_WP"] = m["Precision_weighted"]
            row[f"{length_name}_WF1"] = m["F1_weighted"]
            row[f"{length_name}_MCC"] = m["MCC"]
        history.append(row)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Student {epoch:03d}] loss={row['train_loss']:.4f} | "
                f"ce={row['train_ce']:.4f} | "
                f"same_align={row['train_same_align']:.4f} | "
                f"parent_align={row['train_parent_align']:.4f} | "
                f"score={score:.4f} | lr={row['lr']:.2e}"
            )
            if val_metrics:
                print_length_metrics("Protein student validation", val_metrics)

        if evaluate_now and no_improve >= cfg.student_patience:
            print(
                f"Student early stopping at epoch {epoch}; "
                f"best_epoch={best_epoch}, best_score={best_score:.4f}"
            )
            break

    if best_state is None:
        raise RuntimeError("Protein student produced no checkpoint")
    model.load_state_dict(best_state)

    if ema is not None and best_ema is not None:
        ema.shadow = best_ema
        ema.apply_shadow(model)
        print("Loaded best EMA Protein student.")

    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "protein_student_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )

    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "best_validation_score": best_score,
            "config": asdict(cfg),
        },
        out_dir / "protein_student_best.pth",
    )
    return model


# =============================================================================
# Final reporting
# =============================================================================

def one_vs_rest_per_class(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
    dataset: str,
    level: str,
) -> pd.DataFrame:
    rows = []
    for cid in sorted(np.unique(y_true)):
        true_bin = (y_true == cid).astype(int)
        pred_bin = (y_pred == cid).astype(int)
        p, r, f, _ = precision_recall_fscore_support(
            true_bin,
            pred_bin,
            average="binary",
            zero_division=0,
        )
        rows.append(
            {
                "dataset": dataset,
                "level": level,
                "class_id": int(cid),
                "class_name": class_names[cid],
                "support": int(true_bin.sum()),
                "pred_count": int(pred_bin.sum()),
                "correct_count": int(
                    ((y_true == cid) & (y_pred == cid)).sum()
                ),
                "precision": float(p),
                "recall": float(r),
                "f1": float(f),
                "mcc": float(
                    matthews_corrcoef(true_bin, pred_bin)
                    if len(np.unique(true_bin)) > 1
                    or len(np.unique(pred_bin)) > 1
                    else 0.0
                ),
            }
        )
    return pd.DataFrame(rows)


def evaluate_and_save_split(
    model: ProteinStudent,
    split_name: str,
    protein: np.ndarray,
    labels: np.ndarray,
    meta: pd.DataFrame,
    encoder: LabelEncoder,
    subtype_to_type: Dict[str, str],
    cfg: Config,
    device: torch.device,
    out_dir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    split_dir = out_dir / f"{split_name}_evaluation"
    split_dir.mkdir(parents=True, exist_ok=True)

    lengths = meta["length_ratio"].to_numpy(dtype=np.float32)
    overall_rows = []
    parent_rows = []
    per_class_parts = []

    if split_name == "coverage":
        # Full test_set.csv coverage evaluation. This intentionally contains
        # train/test-overlap parents and must not be reported as independent test.
        split_mask = meta["in_coverage_test"].to_numpy(dtype=bool)
    else:
        split_mask = meta["split"].to_numpy() == split_name

    subtype_classes = list(encoder.classes_)
    type_classes = sorted(set(subtype_to_type.values()))
    type_encoder = LabelEncoder()
    type_encoder.fit(type_classes)

    for length_name in LENGTH_ORDER:
        idx = np.where(
            split_mask
            & (meta["length_name"].to_numpy() == length_name)
        )[0]
        if len(idx) == 0:
            continue

        pred_out = predict_student_indices(
            model=model,
            protein=protein,
            lengths=lengths,
            selected_indices=idx,
            batch_size=cfg.eval_batch_size,
            device=device,
            return_probs=True,
        )
        y_true = labels[idx]
        y_pred = pred_out["pred"]
        probs = pred_out["probs"]

        subtype_metrics = metric_dict(y_true, y_pred)
        overall_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": "Subtype_fragment",
                **subtype_metrics,
            }
        )

        true_sub_names = encoder.inverse_transform(y_true)
        pred_sub_names = encoder.inverse_transform(y_pred)
        true_type_names = np.asarray(
            [subtype_to_type[x] for x in true_sub_names]
        )
        pred_type_names = np.asarray(
            [subtype_to_type[x] for x in pred_sub_names]
        )
        y_true_type = type_encoder.transform(true_type_names)
        y_pred_type = type_encoder.transform(pred_type_names)
        type_metrics = metric_dict(y_true_type, y_pred_type)
        overall_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": "Type_from_Subtype_fragment",
                **type_metrics,
            }
        )

        pred_df = meta.loc[
            idx,
            [
                "KEY", "parent_id", "crop_index", "length_name",
                "length_ratio", "Type", "Subtype", "split",
                "in_train_file", "in_coverage_test",
                "is_train_test_overlap", "evaluation_scope",
            ],
        ].copy()
        pred_df["Pred_Subtype"] = pred_sub_names
        pred_df["Pred_Type"] = pred_type_names
        pred_df["subtype_confidence"] = pred_out["confidence"]
        pred_df["subtype_margin"] = pred_out["margin"]
        pred_df["Subtype_correct"] = y_true == y_pred
        pred_df["Type_correct"] = true_type_names == pred_type_names
        pred_df.to_csv(
            split_dir / f"{length_name}_fragment_predictions.csv",
            index=False,
            encoding="utf-8-sig",
            float_format="%.8f",
        )

        per_class_parts.append(
            one_vs_rest_per_class(
                y_true, y_pred, subtype_classes,
                dataset=length_name,
                level="Subtype_fragment",
            )
        )

        # Parent-level five-crop probability aggregation.
        parent_ids = meta.loc[idx, "parent_id"].to_numpy()
        parent_frame = pd.DataFrame(
            {
                "parent_id": parent_ids,
                "row_pos": np.arange(len(idx)),
            }
        )
        group_indices = parent_frame.groupby("parent_id")["row_pos"].apply(list)

        parent_true = []
        parent_pred = []
        parent_conf = []
        parent_margin = []
        parent_id_order = []

        for parent_id, positions in group_indices.items():
            positions_arr = np.asarray(positions, dtype=np.int64)
            mean_prob = probs[positions_arr].mean(axis=0)
            top2 = np.argpartition(-mean_prob, kth=1)[:2]
            top2 = top2[np.argsort(-mean_prob[top2])]
            parent_id_order.append(parent_id)
            parent_true.append(int(y_true[positions_arr[0]]))
            parent_pred.append(int(top2[0]))
            parent_conf.append(float(mean_prob[top2[0]]))
            parent_margin.append(
                float(mean_prob[top2[0]] - mean_prob[top2[1]])
            )

        parent_true = np.asarray(parent_true, dtype=np.int64)
        parent_pred = np.asarray(parent_pred, dtype=np.int64)

        parent_metrics = metric_dict(parent_true, parent_pred)
        parent_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": "Subtype_parent_aggregated",
                **parent_metrics,
            }
        )

        parent_true_sub = encoder.inverse_transform(parent_true)
        parent_pred_sub = encoder.inverse_transform(parent_pred)
        parent_true_type = np.asarray(
            [subtype_to_type[x] for x in parent_true_sub]
        )
        parent_pred_type = np.asarray(
            [subtype_to_type[x] for x in parent_pred_sub]
        )
        parent_type_metrics = metric_dict(
            type_encoder.transform(parent_true_type),
            type_encoder.transform(parent_pred_type),
        )
        parent_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": "Type_from_Subtype_parent_aggregated",
                **parent_type_metrics,
            }
        )

        parent_pred_df = pd.DataFrame(
            {
                "parent_id": parent_id_order,
                "length_name": length_name,
                "true_Subtype": parent_true_sub,
                "pred_Subtype": parent_pred_sub,
                "true_Type": parent_true_type,
                "pred_Type": parent_pred_type,
                "confidence": parent_conf,
                "margin": parent_margin,
                "Subtype_correct": parent_true == parent_pred,
                "Type_correct": parent_true_type == parent_pred_type,
            }
        )
        parent_pred_df.to_csv(
            split_dir / f"{length_name}_parent_aggregated_predictions.csv",
            index=False,
            encoding="utf-8-sig",
            float_format="%.8f",
        )

        del probs, pred_out
        gc.collect()

    overall_df = pd.DataFrame(overall_rows)
    parent_df = pd.DataFrame(parent_rows)
    per_class_df = pd.concat(per_class_parts, ignore_index=True)

    overall_df.to_csv(
        split_dir / "fragment_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    parent_df.to_csv(
        split_dir / "parent_aggregated_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    per_class_df.to_csv(
        split_dir / "fragment_subtype_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    return overall_df, parent_df


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    cfg = parse_args()
    seed_everything(cfg.seed)
    device = resolve_device(cfg.device)

    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(asdict(cfg), out_dir / "run_config.json")

    print("=" * 80)
    print("ARGScope multi-length Fusion-teacher Protein-student")
    print(f"Script version: {SCRIPT_VERSION}")
    print("=" * 80)
    print(f"Data directory: {Path(cfg.data_dir).resolve()}")
    print(f"Output directory: {out_dir.resolve()}")
    print(f"Device: {device}")
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"CUDA: {torch.version.cuda}")

    start_time = time.time()

    meta_all, protein_raw, fusion_raw, parent_split = load_all_data(cfg)

    parent_split.to_csv(
        out_dir / "parent_train_val_test_split.csv",
        index=False,
        encoding="utf-8-sig",
    )
    meta_all.to_csv(
        out_dir / "all_view_metadata.csv",
        index=False,
        encoding="utf-8-sig",
    )

    encoder, labels, subtype_to_type = build_label_objects(
        meta_all, out_dir
    )

    refined_proto_np = build_refined_proto(
        Path(cfg.data_dir) / cfg.refined_file,
        encoder,
        cfg.use_refined_anchor,
    )

    if cfg.validate_only:
        print("\nValidation-only mode completed successfully.")
        print(f"Rows: {len(meta_all):,}")
        print(f"Parents: {meta_all['parent_id'].nunique():,}")
        print(f"Subtypes: {len(encoder.classes_):,}")
        return

    protein, fusion, protein_scaler, fusion_scaler = fit_and_apply_scalers(
        meta_all,
        protein_raw,
        fusion_raw,
        out_dir,
    )
    del protein_raw, fusion_raw
    gc.collect()

    # Refined prototypes were generated in the original Fusion coordinate space.
    # Apply the same training-only Fusion scaler used for all teacher inputs,
    # then normalize them before using them as ArcFace centers.
    if refined_proto_np is not None:
        refined_scaled_np = fusion_scaler.transform(
            refined_proto_np
        ).astype(np.float32)
        refined_scaled_np = l2_normalize_np(refined_scaled_np).astype(np.float32)
        refined_proto_t = torch.tensor(
            refined_scaled_np, dtype=torch.float32, device=device
        )
    else:
        refined_proto_t = None

    parent_fusion, parent_index, parent_ids = build_parent_fusion_table(
        meta_all, fusion
    )
    joblib.dump(parent_ids, out_dir / "parent_id_order.joblib")

    train_indices = np.where(
        meta_all["split"].to_numpy() == "train"
    )[0].astype(np.int64)
    val_indices = np.where(
        meta_all["split"].to_numpy() == "val"
    )[0].astype(np.int64)
    test_indices = np.where(
        meta_all["split"].to_numpy() == "test"
    )[0].astype(np.int64)

    print(
        f"\nIndex counts: train={len(train_indices):,}, "
        f"val={len(val_indices):,}, test={len(test_indices):,}"
    )
    if len(val_indices) == 0:
        raise ValueError("Validation split is empty")

    teacher = train_fusion_teacher(
        cfg=cfg,
        fusion=fusion,
        labels=labels,
        meta=meta_all,
        train_indices=train_indices,
        val_indices=val_indices,
        refined_proto_t=refined_proto_t,
        device=device,
        out_dir=out_dir,
    )

    student = train_protein_student(
        cfg=cfg,
        teacher=teacher,
        protein=protein,
        fusion=fusion,
        labels=labels,
        meta=meta_all,
        parent_index=parent_index,
        parent_fusion=parent_fusion,
        train_indices=train_indices,
        val_indices=val_indices,
        refined_proto_t=refined_proto_t,
        device=device,
        out_dir=out_dir,
    )

    print("\n" + "=" * 80)
    print("Final validation, independent test, and all-Subtype coverage evaluation")
    print("=" * 80)

    val_fragment, val_parent = evaluate_and_save_split(
        model=student,
        split_name="val",
        protein=protein,
        labels=labels,
        meta=meta_all,
        encoder=encoder,
        subtype_to_type=subtype_to_type,
        cfg=cfg,
        device=device,
        out_dir=out_dir,
    )
    test_fragment, test_parent = evaluate_and_save_split(
        model=student,
        split_name="test",
        protein=protein,
        labels=labels,
        meta=meta_all,
        encoder=encoder,
        subtype_to_type=subtype_to_type,
        cfg=cfg,
        device=device,
        out_dir=out_dir,
    )
    coverage_fragment, coverage_parent = evaluate_and_save_split(
        model=student,
        split_name="coverage",
        protein=protein,
        labels=labels,
        meta=meta_all,
        encoder=encoder,
        subtype_to_type=subtype_to_type,
        cfg=cfg,
        device=device,
        out_dir=out_dir,
    )

    combined_summary = pd.concat(
        [
            val_fragment,
            val_parent,
            test_fragment,
            test_parent,
            coverage_fragment,
            coverage_parent,
        ],
        ignore_index=True,
    )
    combined_summary.to_csv(
        out_dir / "all_length_evaluation_summary.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    checkpoint = {
        "model_name": "ARGScope_multilength_protein_student",
        "student_state_dict": student.state_dict(),
        "teacher_state_dict": teacher.state_dict(),
        "protein_dim": EXPECTED_PROTEIN_DIM,
        "fusion_dim": EXPECTED_FUSION_DIM,
        "embed_dim": cfg.embed_dim,
        "num_classes": len(encoder.classes_),
        "subtype_classes": encoder.classes_.tolist(),
        "subtype_to_type": subtype_to_type,
        "length_ratios": LENGTH_RATIO,
        "config": asdict(cfg),
        "files": {
            "protein_files": PROTEIN_FILES,
            "fusion_files": FUSION_FILES,
            "refined_file": cfg.refined_file,
            "train_split_file": cfg.train_split_file,
            "test_split_file": cfg.test_split_file,
            "expanded_id_file": cfg.expanded_id_file,
        },
        "evaluation_notes": {
            "test": (
                "Independent test only: parents present in test_set.csv but absent "
                "from train_set.csv."
            ),
            "coverage": (
                "Full test_set.csv all-Subtype coverage evaluation. It intentionally "
                "includes train/test-overlap parents and is not independent."
            ),
        },
        "warning": (
            "Inference uses the Protein student only. Fusion teacher and refined "
            "prototype are training-time components."
        ),
    }
    torch.save(checkpoint, out_dir / "argscope_multilength_checkpoint.pth")

    elapsed = time.time() - start_time
    save_json(
        {
            "runtime_seconds": elapsed,
            "runtime_hours": elapsed / 3600.0,
            "rows": len(meta_all),
            "parents": int(meta_all["parent_id"].nunique()),
            "subtypes": len(encoder.classes_),
            "main_summary": "all_length_evaluation_summary.csv",
            "checkpoint": "argscope_multilength_checkpoint.pth",
            "protein_scaler": "protein_scaler.joblib",
            "subtype_encoder": "subtype_encoder.joblib",
        },
        out_dir / "run_manifest.json",
    )

    print("\n" + "=" * 80)
    print("Training completed")
    print("=" * 80)
    print(test_fragment.to_string(index=False))
    print("\nParent-aggregated independent-test results:")
    print(test_parent.to_string(index=False))
    print("\nCoverage results, including intentional train overlap:")
    print(coverage_fragment.to_string(index=False))
    print(f"\nResults: {out_dir.resolve()}")
    print("Main summary: all_length_evaluation_summary.csv")
    print("Model: argscope_multilength_checkpoint.pth")
    print("Protein scaler: protein_scaler.joblib")
    print("Subtype encoder: subtype_encoder.joblib")
    print(f"Runtime: {elapsed / 3600.0:.2f} h")


if __name__ == "__main__":
    main()
