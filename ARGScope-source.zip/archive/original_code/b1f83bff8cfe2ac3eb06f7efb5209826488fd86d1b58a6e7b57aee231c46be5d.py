#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Draw a radar chart (23 ARG Types together) from per-Type metrics CSV files.

Default behavior:
- automatically scans the current folder and all subfolders for CSV files
- selects ONE target result table by model / modality / completeness
- plots Precision and Recall for the final 23 ARG Types on one radar chart

This script is designed as a replacement for the previous heatmap workflow.
It is robust to slightly different CSV formats used by ARGScope / ARGNet /
DeepARG / Fungenetyper / PLM-ARG, as long as the table contains a Type column
and Precision / Recall columns.

Typical use:
1) put this script in the same root folder that contains your result folders
2) modify TARGET_MODEL / TARGET_MODALITY / TARGET_LENGTH below
3) run it

Outputs:
- Type_radar_23types/<model>_<modality>_<length>_type_radar.png
- Type_radar_23types/<model>_<modality>_<length>_type_radar.pdf
- Type_radar_23types/<model>_<modality>_<length>_type_radar.svg
"""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ============================================================
# User settings
# ============================================================
ROOT_DIR = Path(__file__).resolve().parent
OUTDIR = ROOT_DIR / "Type_radar_23types_FIXED"
OUTDIR.mkdir(parents=True, exist_ok=True)

# ---- choose the target result ----
TARGET_MODEL = "ARGScope"      # ARGScope / ARGNet / DeepARG / Fungenetyper / PLM-ARG
TARGET_MODALITY = "LongAA"     # LongAA / LongNT
TARGET_LENGTH = "100p"         # 60p / 70p / 80p / 90p / 100p

# ---- figure appearance ----
DPI = 600
FIGSIZE = (8.2, 8.2)
SAVE_PNG = True
SAVE_PDF = True
SAVE_SVG = True

# font size controls
LABEL_FONT_SIZE = 9.0          # 23个 type 标签大小
RADIAL_TICK_FONT_SIZE = 9.0    # 0.2 / 0.4 / ... / 1.0 这些刻度大小
LEGEND_FONT_SIZE = 10.0        # 图例字体大小
TITLE_FONT_SIZE = 11        # 标题字体大小；若不要标题可设 USE_TITLE=False
USE_TITLE = False

# line / marker controls
PRECISION_COLOR = "#E41A1C"
RECALL_COLOR = "#377EB8"
LINE_WIDTH = 1.8
MARKER_SIZE = 4.6
FILL_ALPHA = 0.12

# polar layout controls
START_AT_TOP = True
CLOCKWISE = True
THETA_OFFSET_DEG = 0.0         # 额外整体旋转角度，想整体转一点可以改这里
RMIN = 0.8
RMAX = 1.0
RTICKS = [0.8, 1.0]

# If True, uses the final 23-Type universe defined below and keeps the order fixed.
USE_FIXED_23_TYPE_ORDER = True


# ============================================================
# Style
# ============================================================
plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 9.0,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "savefig.facecolor": "white",
    "savefig.edgecolor": "white",
})


# ============================================================
# Canonical type definitions
# ============================================================
TYPE_MAPPING = {
    "mls": "MLS",
    "macrolide_lincosamide_streptogramin": "MLS",
    "macrolide-lincosamide-streptogramin": "MLS",
    "multidrug": "multidrug",
    "multi_drug_resistance": "multidrug",
    "mupirocin": "mupirocin",
    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "pleuromutilin": "pleuromutilin_tiamulin",
    "pleuromutilin_tiamulin": "pleuromutilin_tiamulin",
    "polymyxin": "polymyxin",
    "rifamycin": "rifamycin",
    "sulfonamide": "sulfonamide",
    "tetracenomycin_c": "tetracenomycin_C",
    "tetracycline": "tetracycline",
    "fosfomycin": "fosfomycin",
    "fusidic_acid": "fusidic_acid",
    "aminoglycoside": "aminoglycoside",
    "antibacterial_free_fatty_acids": "antibacterial_fatty_acid",
    "antibacterial_fatty_acid": "antibacterial_fatty_acid",
    "bacitracin": "bacitracin",
    "beta_lactam": "beta_lactam",
    "quinolone": "quinolone",
    "trimethoprim": "trimethoprim",
    "non_arg": "nonARG",
    "nonarg": "nonARG",
}

EXCLUDED_TYPES = {
    "antibacterial_fatty_acid",
    "bicyclomycin",
    "defensin",
    "edeine",
    "factumycin",
    "mupirocin",
    "pleuromutilin_tiamulin",
}

FIXED_23_TYPES = [
    "novobiocin",
    "MLS",
    "beta_lactam",
    "multidrug",
    "sulfonamide",
    "tetracycline",
    "aminoglycoside",
    "rifamycin",
    "fosfomycin",
    "vancomycin",
    "polymyxin",
    "other_peptide_antibiotics",
    "quinolone",
    "bleomycin",
    "chloramphenicol",
    "trimethoprim",
    "tetracenomycin_C",
    "florfenicol",
    "bacitracin",
    "fusidic_acid",
    "tunicamycin",
    "puromycin",
    "streptothricin",
]

TYPE_DISPLAY = {
    "novobiocin": "Novobiocin",
    "MLS": "MLS",
    "beta_lactam": "Betalactams",
    "multidrug": "Multi-drug",
    "sulfonamide": "Sulfonamide",
    "tetracycline": "Tetracyclines",
    "aminoglycoside": "Aminoglycosides",
    "rifamycin": "Rifampin",
    "fosfomycin": "Fosfomycin",
    "vancomycin": "Glycopeptides",
    "polymyxin": "Peptide",
    "other_peptide_antibiotics": "Other peptide antibiotics",
    "quinolone": "Fluoroquinolones",
    "bleomycin": "Bleomycin",
    "chloramphenicol": "Phenicol",
    "trimethoprim": "Trimethoprim",
    "tetracenomycin_C": "Tetracenomycin C",
    "florfenicol": "Florfenicol",
    "bacitracin": "Bacitracin",
    "fusidic_acid": "Fusidic acid",
    "tunicamycin": "Tunicamycin",
    "puromycin": "Puromycin",
    "streptothricin": "Streptothricin",
}

TYPE_CANDIDATES = ["Type", "type", "class_name", "class", "label", "category", "arg_type"]
PRECISION_CANDIDATES = ["Precision", "precision", "prec"]
RECALL_CANDIDATES = ["Recall", "recall", "rec"]
TRUE_TYPE_CANDIDATES = ["true_type", "True_Type", "true Type", "trueType"]
PRED_TYPE_CANDIDATES = ["predicted_type", "Predicted_Type", "pred_type", "prediction_type"]
SKIP_PATH_TOKENS = {
    "__pycache__",
    "precision_combined_heatmaps",
    "type_radar_23types",
    "type_radar",
}


# ============================================================
# Helper functions
# ============================================================
def clean_text(value):
    if pd.isna(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def canonical_token(value):
    text = clean_text(value).lower()
    text = text.replace("%", "pct")
    text = re.sub(r"[\s/_-]+", "_", text)
    text = re.sub(r"[^a-z0-9_]", "", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def canonical_type(value):
    raw = clean_text(value)
    token = canonical_token(raw)
    return TYPE_MAPPING.get(token, raw)


def is_nonarg_type(value):
    token = canonical_token(value)
    return token in {"nonarg", "non_arg", "nonresistance", "negative"}


def is_summary_row(value):
    token = canonical_token(value)
    if token in {
        "", "0", "0_0", "accuracy", "overall", "all", "total", "mean",
        "macro_avg", "micro_avg", "weighted_avg", "macro_average",
        "micro_average", "weighted_average", "nan", "none", "null", "average"
    }:
        return True
    for keyword in ["macro", "micro", "weighted", "overall", "average"]:
        if keyword in token:
            return True
    return False


def find_column(columns, candidates):
    mapping = {canonical_token(c): str(c) for c in columns}
    for candidate in candidates:
        key = canonical_token(candidate)
        if key in mapping:
            return mapping[key]
    return None


def detect_type_column(df):
    found = find_column(df.columns, TYPE_CANDIDATES)
    if found is not None:
        return found
    for column in df.columns:
        if df[column].dtype == object:
            values = df[column].dropna().map(clean_text)
            if values.nunique() > 5:
                return str(column)
    return None


def numeric_series(series):
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    return pd.to_numeric(series.astype(str).str.strip().str.replace("%", "", regex=False), errors="coerce")


def normalize_metric_scale(series, metric_name, path):
    values = pd.to_numeric(series, errors="coerce")
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return values
    max_abs = float(np.nanmax(np.abs(finite.to_numpy(dtype=float))))
    if max_abs > 1.5:
        if max_abs <= 100.5:
            print(f"  [scale] {metric_name} in {path.name} appears to be 0-100; dividing by 100.")
            return values / 100.0
        raise ValueError(f"Metric {metric_name} in {path} has unexpected scale (max abs={max_abs:.6g}).")
    return values


def infer_model(path: Path):
    text = str(path).lower()
    token_text = canonical_token(str(path))
    if "argscope" in text:
        return "ARGScope"
    if "argnet" in text:
        return "ARGNet"
    if "deeparg" in text:
        return "DeepARG"
    if ("fungenetyper" in text) or ("fungentyper" in text):
        return "Fungenetyper"
    if ("plm-arg" in text) or ("plm_arg" in text) or ("plmarg" in text) or ("plm_arg" in token_text) or ("plmarg" in token_text):
        return "PLM-ARG"
    return "Unknown"


def infer_modality(path: Path):
    full_text = str(path).lower()
    filename = path.name.lower()
    if "longaa" in full_text:
        return "LongAA"
    if "longnt" in full_text:
        return "LongNT"
    if ("plm-arg" in full_text) or ("plm_arg" in full_text) or ("plmarg" in full_text):
        return "LongAA"
    if "argscope" in full_text:
        if filename.startswith("protein_") or ("protein_" in filename):
            return "LongAA"
        if filename.startswith("dna_") or ("dna_" in filename):
            return "LongNT"
    if any(token in filename for token in ["_prot_", "protein_"]):
        return "LongAA"
    if any(token in filename for token in ["_dna_", "dna_"]):
        return "LongNT"
    return "Unknown"


def infer_length(path: Path, modality: str):
    """Infer 60/70/80/90/100% from file name or parent folders."""
    if modality not in {"LongAA", "LongNT"}:
        return "Unknown"

    # Use the whole path so names such as plmarg_eval_outputs_100p also work.
    text = str(path).lower().replace(" ", "")

    for value in [100, 90, 80, 70, 60]:
        patterns = [
            # IMPORTANT: this is a raw f-string, so one literal % is enough.
            rf"(?<!\d){value}%(?!\d)",
            rf"(?<!\d){value}pct(?!\d)",
            rf"(?<!\d){value}percent(?!\d)",
            rf"(?<!\d){value}p(?![a-z0-9])",
        ]
        if any(re.search(pattern, text) for pattern in patterns):
            return f"{value}p"

    # Full-length names without an explicit numeric percentage.
    name_token = canonical_token(path.stem)
    if modality == "LongAA" and name_token in {"longaa", "long_aa", "full_length_aa"}:
        return "100p"
    if modality == "LongNT" and name_token in {"longnt", "long_nt", "full_length_nt"}:
        return "100p"

    return "Unknown"


def read_csv_flexible(path: Path):
    messages = []
    for encoding in ["utf-8-sig", "utf-8", "gbk", "latin-1"]:
        try:
            df = pd.read_csv(path, sep=None, engine="python", encoding=encoding)
            df.columns = [clean_text(c) for c in df.columns]
            return df
        except Exception as error:
            messages.append(f"{encoding}: {type(error).__name__}: {error}")
    raise RuntimeError(f"Cannot read: {path}\n" + "\n".join(messages))


def is_plmarg_path(path: Path):
    tokens = {canonical_token(part) for part in path.parts}
    return bool(tokens & {"plm_arg", "plmarg", "plm_arg_model", "plmarg_model"})


def should_skip(path: Path):
    tokens = set(canonical_token(part) for part in path.parts)
    if bool(tokens & SKIP_PATH_TOKENS):
        return True

    # For PLM-ARG use only the ARG-only per-Type metric tables generated by
    # summarize_PLMARG_5conditions_perType_5metrics.py.  This prevents the
    # including_nonARG and raw/intermediate files from being mixed in.
    if is_plmarg_path(path):
        stem = canonical_token(path.stem)
        wanted = {
            "60p_pertype_metrics_arg_only",
            "70p_pertype_metrics_arg_only",
            "80p_pertype_metrics_arg_only",
            "90p_pertype_metrics_arg_only",
            "100p_pertype_metrics_arg_only",
        }
        return stem not in wanted

    return False


def precision_recall_from_prediction_table(raw: pd.DataFrame, path: Path) -> pd.DataFrame:
    """Derive one-vs-rest per-Type Precision and Recall from sequence predictions."""
    true_col = find_column(raw.columns, TRUE_TYPE_CANDIDATES)
    pred_col = find_column(raw.columns, PRED_TYPE_CANDIDATES)

    if true_col is None or pred_col is None:
        raise ValueError(
            "Precision/Recall columns are missing and true_type/predicted_type "
            f"cannot be found. Columns={raw.columns.tolist()}"
        )

    true_values = raw[true_col].map(clean_text).map(canonical_type)
    pred_values = raw[pred_col].map(clean_text).map(canonical_type)
    valid = true_values.ne("") & pred_values.ne("")
    true_values = true_values[valid].reset_index(drop=True)
    pred_values = pred_values[valid].reset_index(drop=True)

    classes = sorted(set(true_values.tolist()) | set(pred_values.tolist()))
    rows = []
    for type_name in classes:
        if is_summary_row(type_name) or is_nonarg_type(type_name):
            continue
        if type_name in EXCLUDED_TYPES:
            continue

        true_positive = true_values.eq(type_name)
        pred_positive = pred_values.eq(type_name)
        tp = int((true_positive & pred_positive).sum())
        fp = int((~true_positive & pred_positive).sum())
        fn = int((true_positive & ~pred_positive).sum())

        precision = tp / float(tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / float(tp + fn) if (tp + fn) > 0 else 0.0
        rows.append({"Type": type_name, "Precision": precision, "Recall": recall})

    if not rows:
        raise ValueError(f"No usable Type rows could be derived from {path}")

    print(f"  [derive] {path.name}: calculated per-Type Precision and Recall from true/predicted Type.")
    return pd.DataFrame(rows)


def standardize_file(path: Path):
    model = infer_model(path)
    modality = infer_modality(path)
    length = infer_length(path, modality)
    if model == "Unknown" or modality == "Unknown" or length == "Unknown":
        raise ValueError(f"Cannot infer metadata: model={model}, modality={modality}, length={length}")

    raw = read_csv_flexible(path)
    type_col = detect_type_column(raw)
    precision_col = find_column(raw.columns, PRECISION_CANDIDATES)
    recall_col = find_column(raw.columns, RECALL_CANDIDATES)

    if type_col is not None and precision_col is not None and recall_col is not None:
        out = pd.DataFrame({
            "Type": raw[type_col].map(clean_text).map(canonical_type),
            "Precision": normalize_metric_scale(numeric_series(raw[precision_col]), "Precision", path),
            "Recall": normalize_metric_scale(numeric_series(raw[recall_col]), "Recall", path),
        })
    elif model == "ARGScope":
        # Some ARGScope completeness levels may only have a sequence-level
        # prediction CSV; derive both metrics directly when needed.
        out = precision_recall_from_prediction_table(raw, path)
    else:
        raise ValueError(
            "Missing required columns. "
            f"type={type_col}, precision={precision_col}, recall={recall_col}, columns={raw.columns.tolist()}"
        )

    out = out[~out["Type"].map(is_summary_row)].copy()
    out = out[out["Type"].ne("")].copy()
    out = out[~out["Type"].map(is_nonarg_type)].copy()
    out = out[~out["Type"].isin(EXCLUDED_TYPES)].copy()
    out = out[out["Precision"].notna() & out["Recall"].notna()].copy()

    out["model"] = model
    out["modality"] = modality
    out["length"] = length
    out["source_file"] = str(path.resolve())

    out = (
        out.groupby(["model", "modality", "length", "Type"], as_index=False)
        .agg({"Precision": "mean", "Recall": "mean", "source_file": "first"})
    )
    return out


def build_master_table(root_dir: Path):
    files = sorted(path for path in root_dir.rglob("*.csv") if path.is_file() and not should_skip(path))
    parts = []

    print("=" * 100)
    print("Scanning CSV files for radar plot")
    print("=" * 100)
    print(f"ROOT_DIR: {root_dir}")
    print(f"Files found: {len(files)}")

    for idx, path in enumerate(files, start=1):
        rel = path.relative_to(root_dir)
        print(f"[{idx:03d}/{len(files):03d}] {rel}")
        try:
            table = standardize_file(path)
            parts.append(table)
        except Exception as error:
            print(f"  SKIPPED: {type(error).__name__}: {error}")

    if not parts:
        raise RuntimeError("No usable per-Type files with both Precision and Recall were found.")

    master = pd.concat(parts, ignore_index=True)
    master = master.drop_duplicates(subset=["model", "modality", "length", "Type"], keep="first")
    return master


def prepare_target_table(master: pd.DataFrame):
    subset = master[
        (master["model"] == TARGET_MODEL)
        & (master["modality"] == TARGET_MODALITY)
        & (master["length"] == TARGET_LENGTH)
    ].copy()

    if subset.empty:
        available = (
            master[["model", "modality", "length"]]
            .drop_duplicates()
            .sort_values(["model", "modality", "length"])
        )
        raise RuntimeError(
            f"No matching file found for model={TARGET_MODEL}, modality={TARGET_MODALITY}, length={TARGET_LENGTH}.\n"
            f"Available combinations:\n{available.to_string(index=False)}"
        )

    if USE_FIXED_23_TYPE_ORDER:
        ordered_types = FIXED_23_TYPES
    else:
        ordered_types = subset["Type"].drop_duplicates().tolist()

    subset = (
        subset.set_index("Type")
        .reindex(ordered_types)
        .reset_index()
    )

    missing = subset[subset[["Precision", "Recall"]].isna().any(axis=1)]["Type"].tolist()
    if missing:
        print("\n[Warning] Missing metrics for these Types in the selected file:")
        print("  " + ", ".join(missing))
        print("They will be filled with 0.0 in the radar chart.")
        subset["Precision"] = subset["Precision"].fillna(0.0)
        subset["Recall"] = subset["Recall"].fillna(0.0)

    return subset, ordered_types


def make_radar_plot(table: pd.DataFrame, ordered_types: list[str]):
    labels = [TYPE_DISPLAY.get(t, t) for t in ordered_types]
    precision = table["Precision"].astype(float).tolist()
    recall = table["Recall"].astype(float).tolist()

    n = len(labels)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False).tolist()

    # close the polygon
    angles_closed = angles + angles[:1]
    precision_closed = precision + precision[:1]
    recall_closed = recall + recall[:1]

    fig = plt.figure(figsize=FIGSIZE)
    ax = plt.subplot(111, projection="polar")

    if START_AT_TOP:
        ax.set_theta_offset(np.pi / 2.0 + np.deg2rad(THETA_OFFSET_DEG))
    else:
        ax.set_theta_offset(np.deg2rad(THETA_OFFSET_DEG))

    if CLOCKWISE:
        ax.set_theta_direction(-1)
    else:
        ax.set_theta_direction(1)

    # category labels
    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=LABEL_FONT_SIZE)
    ax.tick_params(axis="x", pad=10)

    # radial axis
    ax.set_ylim(RMIN, RMAX)
    ax.set_yticks(RTICKS)
    ax.set_yticklabels([f"{x:.1f}" for x in RTICKS], fontsize=RADIAL_TICK_FONT_SIZE, color="#666666")
    ax.set_rlabel_position(22.5)

    # grid / spine styling
    ax.grid(True, linestyle="-", linewidth=0.8, color="#CFCFCF", alpha=0.9)
    ax.spines["polar"].set_color("#333333")
    ax.spines["polar"].set_linewidth(1.1)

    # precision / recall curves
    ax.plot(angles_closed, precision_closed, color=PRECISION_COLOR, linewidth=LINE_WIDTH,
            marker="o", markersize=MARKER_SIZE, label="Precision")
    ax.fill(angles_closed, precision_closed, color=PRECISION_COLOR, alpha=FILL_ALPHA)

    ax.plot(angles_closed, recall_closed, color=RECALL_COLOR, linewidth=LINE_WIDTH,
            marker="o", markersize=MARKER_SIZE, label="Recall")
    ax.fill(angles_closed, recall_closed, color=RECALL_COLOR, alpha=FILL_ALPHA)

    if USE_TITLE:
        ax.set_title(f"{TARGET_MODEL} | {TARGET_MODALITY} | {TARGET_LENGTH}", va="bottom", fontsize=TITLE_FONT_SIZE, pad=26)

    legend = ax.legend(loc="upper right", bbox_to_anchor=(1.18, 1.10), frameon=True, fontsize=LEGEND_FONT_SIZE)
    legend.get_frame().set_edgecolor("#BFBFBF")
    legend.get_frame().set_linewidth(0.8)

    # leave room for long labels and legend
    plt.subplots_adjust(left=0.08, right=0.83, top=0.90, bottom=0.08)
    return fig


def save_figure(fig):
    stem = f"{TARGET_MODEL}_{TARGET_MODALITY}_{TARGET_LENGTH}_type_radar"
    stem = stem.replace(" ", "_")
    if SAVE_PNG:
        fig.savefig(OUTDIR / f"{stem}.png", dpi=DPI, bbox_inches="tight")
    if SAVE_PDF:
        fig.savefig(OUTDIR / f"{stem}.pdf", bbox_inches="tight")
    if SAVE_SVG:
        fig.savefig(OUTDIR / f"{stem}.svg", bbox_inches="tight")
    print(f"\nSaved figure to: {OUTDIR.resolve()}")


def main():
    print("=" * 100)
    print("23-Type radar plot")
    print("=" * 100)
    print(f"Target model   : {TARGET_MODEL}")
    print(f"Target modality: {TARGET_MODALITY}")
    print(f"Target length  : {TARGET_LENGTH}")

    master = build_master_table(ROOT_DIR)
    table, ordered_types = prepare_target_table(master)

    print("\nSelected source rows:")
    print(table[["Type", "Precision", "Recall"]].to_string(index=False))

    fig = make_radar_plot(table, ordered_types)
    save_figure(fig)
    plt.close(fig)

    print("Done.")


if __name__ == "__main__":
    main()
