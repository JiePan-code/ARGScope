"""CPU/stdlib-only syntax, preservation, split and provenance regression checks."""
import ast
import copy
import json
import py_compile
import random
import tempfile
from collections import defaultdict
from pathlib import Path
import newsplit_contract as c

ROOT = Path(__file__).resolve().parent

def definitions(path):
    return {n.name: n for n in ast.parse(path.read_text(encoding='utf-8-sig')).body if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))}

def must_fail(fn):
    try:
        fn()
    except (ValueError, KeyError):
        return
    raise AssertionError('Expected rejection')

def main():
    syntax = []
    for path in ROOT.glob('*.py'):
        py_compile.compile(str(path), doraise=True)
        syntax.append(path.name)
    preservation = {}
    permitted = {
        '01': {'main', 'parse_args', 'align_inputs', 'derive_validation', 'generate_fused'},
        '02': {'main', 'load_and_validate_input'},
        '03': {'main', 'load_inputs'},
        '04': {'main', 'load_and_align_data', 'parse_args'},
        '05': {'main', 'load_and_align_data'},
    }
    for path in (ROOT / 'reference').glob('*.py'):
        old, new = definitions(path), definitions(ROOT / path.name)
        unchanged = []
        for name, node in old.items():
            if name not in permitted[path.name[:2]]:
                assert ast.dump(node) == ast.dump(new[name]), (path.name, name)
                unchanged.append(name)
        preservation[path.name] = unchanged
    # Compare against the ACTUAL functions extracted from both supplied Students.
    originals = []
    for name in ('04_protein_student.py', '05_dna_student.py'):
        node = definitions(ROOT / 'reference' / name)['build_model_splits_from_new_ids']
        scope = {'random': random, 'defaultdict': defaultdict, 'is_nonarg': c.is_nonarg}
        exec(compile(ast.Module(body=[node], type_ignores=[]), name, 'exec'), scope)
        originals.append(scope['build_model_splits_from_new_ids'])
    for trial in range(30):
        labels = [f'S{k}' for k, n in enumerate((1, 2, 3, 5, 8, 17, 25)) for _ in range(n)] + ['nonARG'] * 70
        ids = [f'train_{i}' for i in range(len(labels))]
        train = set(ids)
        for k in range(7):
            ids.append(f'test_{k}')
            labels.append(f'S{k}')
        ids.append('test_neg'); labels.append('nonARG')
        test = set(ids) - train
        pairs = list(zip(ids, labels))
        random.Random(trial).shuffle(pairs)
        ids, labels = map(list, zip(*pairs))
        args = (ids, labels, train, test, .20, 20260822)
        model, external = c.build_model_splits_from_new_ids(*args)
        for fn in originals:
            assert (model, external) == fn(*args)
        assert {x for x,s in zip(ids, model) if s == 'test'} == test
        assert sum(s == 'validation' and l == 'nonARG' for l,s in zip(labels, model)) == sum(s == 'validation' and l != 'nonARG' for l,s in zip(labels, model))
    with tempfile.TemporaryDirectory() as temporary:
        folder = Path(temporary)
        train_path, test_path, structure = folder/'train.txt', folder/'test.txt', folder/'structure.tsv'
        train_path.write_text('\n'.join(sorted(train)))
        test_path.write_text('\n'.join(sorted(test)))
        structure.write_text('Subtype\tType\n' + '\n'.join(f'S{k}\tT{k%2}' for k in range(7)))
        fused = {'ids': ids, 'subtypes': labels, 'model_splits': model, 'splits': external}
        c.stamp_fusion(fused, structure, train_path, test_path, folder/'fusion.pt')
        assert c.use_saved_splits(fused, *args) == (model, external)
        must_fail(lambda: c.validate_fusion({}))
        bad = copy.deepcopy(fused); bad['model_splits'][0] = 'test' if model[0] != 'test' else 'train'
        must_fail(lambda: c.validate_fusion(bad))
        must_fail(lambda: c.use_saved_splits(fused, ids, labels, train | test, set(), .20, 20260822))
        must_fail(lambda: c.build_model_splits_from_new_ids(ids, labels, train, test, .15, 20260822))
        # File content fingerprint must reject a different fusion with identical IDs.
        fusion_path = folder/'fusion.pt'; fusion_path.write_bytes(b'fusion-run-one')
        derived = {'arg_subtype_names': [f'S{k}' for k in range(7)]}
        c.stamp_derived(derived, fused, fusion_path, 'raw')
        c.validate_derived(derived, fused, fusion_path, 'raw')
        fusion_path.write_bytes(b'fusion-run-two')
        must_fail(lambda: c.validate_derived(derived, fused, fusion_path, 'raw'))
    result = {'syntax_passed': syntax, 'unchanged_definitions': preservation,
              'original_student_split_equivalence_trials': 30,
              'provenance_and_negative_tests': 'PASS',
              'GPU_training': 'NOT RUN: local environment has no PyTorch/CUDA or dataset'}
    (ROOT/'verification_report.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('PASS: syntax, scientific definitions preserved, 30 split-equivalence trials, provenance rejection checks')

if __name__ == '__main__':
    main()
