#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重新验证最终 SARG DNA 与 protein 的翻译对应关系，并提取 subtype >= 3 的数据。

计数规则
--------
Subtype 阈值按“拥有至少一条验证通过 DNA 的唯一 protein ID 数量”计算，
不是按 DNA 总条数计算。一个 protein 对应多条 DNA 时只计作一个 protein。

输出两套 DNA 数据
--------------
1. all_variants：保留每个合格 protein 的全部验证通过天然 DNA。
2. one_per_protein：每个 protein 只保留一条代表 DNA；DNA FASTA 第一字段
   重命名为 protein ID，因此与 protein FASTA 的ID集合、数量和顺序完全一致。

接受标准
--------
- DNA 必须在正向第0阅读框完整翻译为映射的 protein；
- 允许目标 protein 中 X/B/Z/J/U/O/? 等模糊氨基酸；
- 无内部终止密码子；
- DNA 长度必须为 protein长度*3，或额外包含一个终止密码子。

只使用 Python 标准库，可直接在 PyCharm 运行。
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


# =============================================================================
# 只需要修改这里；脚本放在截图中的 SARG_subtype_ge3_with_DNA 根目录时
# 默认路径无需修改。
# =============================================================================
PROTEIN_FASTA = "SARG_protein_subtype_ge3.fasta"
PROTEIN_STRUCTURE = "SARG_protein_subtype_ge3_structure.txt"

FINAL_DNA_FASTA = (
    "SARG_missing_DNA_NCBI_retrieval/SARG_final_merged_DNA_results/"
    "SARG_all_available_natural_DNA.fasta"
)
FINAL_DNA_MAPPING = (
    "SARG_missing_DNA_NCBI_retrieval/SARG_final_merged_DNA_results/"
    "SARG_all_available_natural_DNA_mapping.csv"
)

# 每个 subtype 至少需要多少个不同 protein 拥有验证通过的 DNA。
MIN_PROTEINS_PER_SUBTYPE = 3

# 允许 protein 序列中的模糊氨基酸与任意翻译残基相容。
ALLOW_AMBIGUOUS_PROTEIN_RESIDUES = True

OUTPUT_DIR = "SARG_verified_DNA_protein_pairs_subtype_ge3"


SCRIPT_DIR = Path(__file__).resolve().parent
AMBIGUOUS_AA = set("XBZJUO?")

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}
BACTERIAL_START_CODONS = {"ATG", "GTG", "TTG", "CTG", "ATT", "ATC", "ATA"}
COMPLEMENT = str.maketrans(
    "ACGTRYMKBDHVNacgtrymkbdhvn",
    "TGCAYRKMVHDBNtgcayrkmvhdbn",
)


def resolve_required_file(value: str, description: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(
            f"找不到 {description}：\n{path}\n请修改代码顶部对应路径。"
        )
    return path


def clean_protein(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("-", "").rstrip("*")


def clean_dna(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("U", "T").replace("-", "")


def read_fasta(path: Path, molecule: str):
    order = []
    records = {}
    current_id = None
    header = ""
    chunks = []

    def save():
        nonlocal current_id, header, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"{path.name} 存在重复 FASTA ID：{current_id}")
        raw_sequence = "".join(chunks)
        sequence = clean_protein(raw_sequence) if molecule == "protein" else clean_dna(raw_sequence)
        records[current_id] = {"header": header, "sequence": sequence}
        order.append(current_id)

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_no, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                save()
                header = line[1:].strip()
                if not header:
                    raise ValueError(f"{path.name} 第 {line_no} 行 FASTA 标题为空")
                current_id = header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(f"{path.name} 第 {line_no} 行在标题前出现序列")
                chunks.append(line)
        save()
    return order, records


def read_tsv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        required = {"SARG.Seq.ID", "Type", "Subtype"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{path.name} 缺少列：{sorted(missing)}")
        return list(reader.fieldnames), list(reader)


def read_mapping(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头")
        required = {"DNA_id", "protein_id", "Type", "Subtype", "DNA_source"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{path.name} 缺少列：{sorted(missing)}")
        rows = list(reader)
    return rows


def reverse_complement(sequence: str) -> str:
    return sequence.translate(COMPLEMENT)[::-1]


def translate_frame(dna: str, frame: int = 0, reverse: bool = False,
                    target_starts_m: bool = False):
    dna = clean_dna(dna)
    oriented = reverse_complement(dna) if reverse else dna
    aa = []
    for position in range(frame, len(oriented) - 2, 3):
        aa.append(CODON_TABLE.get(oriented[position:position + 3], "X"))
    if (aa and target_starts_m and frame == 0
            and oriented[:3] in BACTERIAL_START_CODONS):
        aa[0] = "M"
    raw = "".join(aa)
    internal_stops = raw.rstrip("*").count("*")
    return raw.rstrip("*"), internal_stops


def residue_compatible(target_aa: str, translated_aa: str) -> bool:
    return (
        target_aa == translated_aa
        or (ALLOW_AMBIGUOUS_PROTEIN_RESIDUES and target_aa in AMBIGUOUS_AA)
    )


def full_length_identity(target: str, translated: str) -> float:
    denominator = max(len(target), len(translated))
    if denominator == 0:
        return 1.0
    matches = sum(
        residue_compatible(a, b) for a, b in zip(target, translated)
    )
    return matches / denominator


def check_translation(protein: str, dna: str):
    protein = clean_protein(protein)
    dna = clean_dna(dna)
    invalid_dna = sorted(set(dna) - set("ACGTRYSWKMBDHVN"))
    expected_length = len(dna) in {3 * len(protein), 3 * (len(protein) + 1)}

    translated0, internal_stops0 = translate_frame(
        dna, 0, False, target_starts_m=protein.startswith("M")
    )
    strict_exact = translated0 == protein
    compatible_exact = (
        len(translated0) == len(protein)
        and all(residue_compatible(a, b) for a, b in zip(protein, translated0))
    )
    accepted = (
        not invalid_dna
        and expected_length
        and compatible_exact
        and internal_stops0 == 0
    )

    best_frame = "+0"
    best_identity = full_length_identity(protein, translated0)
    best_internal_stops = internal_stops0
    if not accepted:
        for reverse in (False, True):
            strand = "-" if reverse else "+"
            for frame in range(3):
                if not reverse and frame == 0:
                    continue
                translated, stops = translate_frame(
                    dna, frame, reverse, target_starts_m=protein.startswith("M")
                )
                identity = full_length_identity(protein, translated)
                if identity > best_identity:
                    best_identity = identity
                    best_frame = f"{strand}{frame}"
                    best_internal_stops = stops

    if invalid_dna:
        result = "INVALID_DNA_CHARACTERS"
    elif accepted and strict_exact:
        result = "EXACT_FORWARD_FRAME0"
    elif accepted:
        result = "COMPATIBLE_EXACT_FORWARD_FRAME0"
    elif best_identity == 1.0:
        result = "EXACT_OTHER_FRAME_OR_LENGTH"
    else:
        result = "NOT_MATCHED"

    return {
        "translation_result": result,
        "accepted": accepted,
        "strict_exact": strict_exact and expected_length and internal_stops0 == 0,
        "compatible_exact": compatible_exact and expected_length and internal_stops0 == 0,
        "protein_length_aa": len(protein),
        "DNA_length_nt": len(dna),
        "expected_DNA_length": expected_length,
        "forward_frame0_identity": round(full_length_identity(protein, translated0), 8),
        "forward_frame0_internal_stops": internal_stops0,
        "best_frame": best_frame,
        "best_frame_identity": round(best_identity, 8),
        "best_frame_internal_stops": best_internal_stops,
        "invalid_DNA_characters": "".join(invalid_dna),
    }


def wrap_sequence(sequence: str, width: int = 80):
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def write_csv(path: Path, fieldnames, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_structure(path: Path, fieldnames, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def safe_header_value(value) -> str:
    return str(value).replace(" ", "_").replace("[", "(").replace("]", ")")


def main():
    if MIN_PROTEINS_PER_SUBTYPE < 1:
        raise ValueError("MIN_PROTEINS_PER_SUBTYPE 必须大于等于1")

    protein_fasta_path = resolve_required_file(PROTEIN_FASTA, "protein FASTA")
    protein_structure_path = resolve_required_file(PROTEIN_STRUCTURE, "protein structure")
    dna_fasta_path = resolve_required_file(FINAL_DNA_FASTA, "最终天然 DNA FASTA")
    dna_mapping_path = resolve_required_file(FINAL_DNA_MAPPING, "最终 DNA 映射表")
    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 100)
    print("Verify and extract SARG DNA-protein pairs with subtype >= 3 proteins")
    print("=" * 100)
    print(f"Protein FASTA    : {protein_fasta_path}")
    print(f"Protein structure: {protein_structure_path}")
    print(f"DNA FASTA        : {dna_fasta_path}")
    print(f"DNA mapping      : {dna_mapping_path}")
    print(f"Output directory : {output_dir}")

    protein_order, proteins = read_fasta(protein_fasta_path, "protein")
    dna_order, dna_records = read_fasta(dna_fasta_path, "DNA")
    structure_fields, structure_rows = read_tsv(protein_structure_path)
    mapping_rows = read_mapping(dna_mapping_path)

    structure_by_id = {}
    for row in structure_rows:
        protein_id = row["SARG.Seq.ID"].strip()
        if not protein_id:
            raise ValueError("Protein structure 存在空 SARG.Seq.ID")
        if protein_id in structure_by_id:
            raise ValueError(f"Protein structure 存在重复ID：{protein_id}")
        structure_by_id[protein_id] = row
    if set(proteins) != set(structure_by_id):
        raise ValueError(
            "Protein FASTA 与 structure ID 不一致："
            f"仅FASTA={len(set(proteins)-set(structure_by_id))}，"
            f"仅structure={len(set(structure_by_id)-set(proteins))}"
        )

    mapping_by_dna = {}
    mapping_order = []
    for row in mapping_rows:
        dna_id = row["DNA_id"].strip()
        protein_id = row["protein_id"].strip()
        if not dna_id or not protein_id:
            raise ValueError("DNA mapping 存在空 DNA_id 或 protein_id")
        if dna_id in mapping_by_dna:
            raise ValueError(f"DNA mapping 存在重复 DNA_id：{dna_id}")
        mapping_by_dna[dna_id] = row
        mapping_order.append(dna_id)
    if set(dna_records) != set(mapping_by_dna):
        raise ValueError(
            "DNA FASTA 与 mapping ID 不一致："
            f"仅FASTA={len(set(dna_records)-set(mapping_by_dna))}，"
            f"仅mapping={len(set(mapping_by_dna)-set(dna_records))}"
        )

    audit_rows = []
    label_mismatch_count = 0
    missing_protein_count = 0
    protein_to_valid_dna = defaultdict(list)

    for index, dna_id in enumerate(mapping_order, 1):
        mapping = mapping_by_dna[dna_id]
        protein_id = mapping["protein_id"].strip()
        audit_base = {
            "DNA_id": dna_id,
            "protein_id": protein_id,
            "Type": mapping["Type"].strip(),
            "Subtype": mapping["Subtype"].strip(),
            "DNA_source": mapping.get("DNA_source", "").strip(),
            "nucleotide_accession": mapping.get("nucleotide_accession", "").strip(),
            "retrieval_round": mapping.get("retrieval_round", "").strip(),
        }

        if protein_id not in proteins:
            missing_protein_count += 1
            audit_rows.append({
                **audit_base,
                "protein_found": False,
                "labels_consistent": False,
                "translation_result": "MAPPED_PROTEIN_NOT_IN_FASTA",
                "accepted": False,
            })
            continue

        structure = structure_by_id[protein_id]
        labels_consistent = (
            mapping["Type"].strip() == structure["Type"].strip()
            and mapping["Subtype"].strip() == structure["Subtype"].strip()
        )
        if not labels_consistent:
            label_mismatch_count += 1

        result = check_translation(
            proteins[protein_id]["sequence"],
            dna_records[dna_id]["sequence"],
        )
        audit_row = {
            **audit_base,
            "protein_found": True,
            "labels_consistent": labels_consistent,
            **result,
        }
        audit_rows.append(audit_row)
        if result["accepted"] and labels_consistent:
            protein_to_valid_dna[protein_id].append(audit_row)

        if index == 1 or index % 1000 == 0:
            print(f"Checked DNA records: {index}/{len(mapping_order)}")

    audit_fields = [
        "DNA_id", "protein_id", "Type", "Subtype", "DNA_source",
        "nucleotide_accession", "retrieval_round", "protein_found",
        "labels_consistent", "translation_result", "accepted", "strict_exact",
        "compatible_exact", "protein_length_aa", "DNA_length_nt",
        "expected_DNA_length", "forward_frame0_identity",
        "forward_frame0_internal_stops", "best_frame", "best_frame_identity",
        "best_frame_internal_stops", "invalid_DNA_characters",
    ]
    audit_path = output_dir / "SARG_all_DNA_protein_translation_audit.csv"
    write_csv(audit_path, audit_fields, audit_rows)

    matched_protein_ids = set(protein_to_valid_dna)
    subtype_to_matched_proteins = defaultdict(list)
    subtype_to_type = {}
    for protein_id in protein_order:
        if protein_id not in matched_protein_ids:
            continue
        row = structure_by_id[protein_id]
        subtype = row["Subtype"].strip()
        subtype_to_matched_proteins[subtype].append(protein_id)
        subtype_to_type[subtype] = row["Type"].strip()

    all_structure_subtypes = {}
    for row in structure_rows:
        subtype = row["Subtype"].strip()
        all_structure_subtypes[subtype] = row["Type"].strip()

    retained_subtypes = {
        subtype for subtype, ids in subtype_to_matched_proteins.items()
        if len(ids) >= MIN_PROTEINS_PER_SUBTYPE
    }
    retained_protein_ids = {
        protein_id for protein_id in matched_protein_ids
        if structure_by_id[protein_id]["Subtype"].strip() in retained_subtypes
    }

    subtype_rows = []
    for subtype, type_name in all_structure_subtypes.items():
        matched_ids = subtype_to_matched_proteins.get(subtype, [])
        valid_dna_count = sum(len(protein_to_valid_dna[p]) for p in matched_ids)
        subtype_rows.append({
            "Type": type_name,
            "Subtype": subtype,
            "verified_unique_protein_count": len(matched_ids),
            "verified_DNA_sequence_count": valid_dna_count,
            "retained_ge3_unique_proteins": "Yes" if subtype in retained_subtypes else "No",
            "verified_protein_ids": ";".join(matched_ids),
        })
    subtype_rows.sort(key=lambda row: (
        -row["verified_unique_protein_count"], row["Type"], row["Subtype"]
    ))
    subtype_fields = [
        "Type", "Subtype", "verified_unique_protein_count",
        "verified_DNA_sequence_count", "retained_ge3_unique_proteins",
        "verified_protein_ids",
    ]
    subtype_counts_path = output_dir / "SARG_verified_subtype_counts.csv"
    excluded_subtypes_path = output_dir / "SARG_excluded_subtypes_fewer_than3_verified_proteins.csv"
    write_csv(subtype_counts_path, subtype_fields, subtype_rows)
    write_csv(
        excluded_subtypes_path,
        subtype_fields,
        [row for row in subtype_rows if row["retained_ge3_unique_proteins"] == "No"],
    )

    # 输出验证通过且 subtype >=3 的唯一 protein FASTA/structure。
    protein_output_path = output_dir / "SARG_verified_paired_protein_subtype_ge3.fasta"
    protein_structure_output_path = output_dir / "SARG_verified_paired_protein_subtype_ge3_structure.txt"
    retained_structure_rows = [
        row for row in structure_rows if row["SARG.Seq.ID"].strip() in retained_protein_ids
    ]
    with protein_output_path.open("w", encoding="utf-8", newline="\n") as handle:
        written_protein_ids = []
        for protein_id in protein_order:
            if protein_id not in retained_protein_ids:
                continue
            record = proteins[protein_id]
            handle.write(f">{record['header']}\n{wrap_sequence(record['sequence'])}\n")
            written_protein_ids.append(protein_id)
    write_structure(protein_structure_output_path, structure_fields, retained_structure_rows)
    if set(written_protein_ids) != retained_protein_ids:
        raise RuntimeError("筛选后 protein FASTA 写出ID不一致")

    # 保留全部验证通过 DNA 变体。
    retained_all_variant_rows = [
        row for row in audit_rows
        if row.get("accepted") is True
        and row.get("labels_consistent") is True
        and row["protein_id"] in retained_protein_ids
    ]
    retained_all_variant_ids = {row["DNA_id"] for row in retained_all_variant_rows}
    all_variants_fasta_path = output_dir / "SARG_verified_paired_DNA_all_variants_subtype_ge3.fasta"
    all_variants_mapping_path = output_dir / "SARG_verified_paired_DNA_all_variants_subtype_ge3_mapping.csv"
    with all_variants_fasta_path.open("w", encoding="utf-8", newline="\n") as handle:
        written_all_variant_ids = set()
        for dna_id in dna_order:
            if dna_id not in retained_all_variant_ids:
                continue
            record = dna_records[dna_id]
            handle.write(f">{record['header']}\n{wrap_sequence(record['sequence'])}\n")
            written_all_variant_ids.add(dna_id)
    if written_all_variant_ids != retained_all_variant_ids:
        raise RuntimeError("全部DNA变体 FASTA 写出ID不一致")
    write_csv(all_variants_mapping_path, audit_fields, retained_all_variant_rows)

    # 每个 protein 选一条代表DNA；严格一致优先，其次保持统一映射表原始顺序。
    mapping_rank = {dna_id: index for index, dna_id in enumerate(mapping_order)}
    representative_by_protein = {}
    for protein_id in written_protein_ids:
        candidates = protein_to_valid_dna[protein_id]
        candidates = sorted(
            candidates,
            key=lambda row: (0 if row["strict_exact"] else 1, mapping_rank[row["DNA_id"]]),
        )
        representative_by_protein[protein_id] = candidates[0]

    one_to_one_fasta_path = output_dir / "SARG_verified_paired_DNA_one_per_protein_subtype_ge3.fasta"
    one_to_one_mapping_path = output_dir / "SARG_verified_paired_DNA_one_per_protein_subtype_ge3_mapping.csv"
    one_to_one_rows = []
    with one_to_one_fasta_path.open("w", encoding="utf-8", newline="\n") as handle:
        written_one_to_one_ids = []
        for protein_id in written_protein_ids:
            candidate = representative_by_protein[protein_id]
            original_dna_id = candidate["DNA_id"]
            dna_sequence = dna_records[original_dna_id]["sequence"]
            handle.write(
                f">{protein_id} original_DNA_id={safe_header_value(original_dna_id)} "
                f"source={safe_header_value(candidate['DNA_source'])}\n"
                f"{wrap_sequence(dna_sequence)}\n"
            )
            written_one_to_one_ids.append(protein_id)
            one_to_one_rows.append({
                "output_DNA_id": protein_id,
                "original_DNA_id": original_dna_id,
                "protein_id": protein_id,
                "Type": candidate["Type"],
                "Subtype": candidate["Subtype"],
                "DNA_source": candidate["DNA_source"],
                "nucleotide_accession": candidate["nucleotide_accession"],
                "retrieval_round": candidate["retrieval_round"],
                "translation_result": candidate["translation_result"],
                "protein_length_aa": candidate["protein_length_aa"],
                "DNA_length_nt": candidate["DNA_length_nt"],
            })
    if written_one_to_one_ids != written_protein_ids:
        raise RuntimeError("一对一 DNA FASTA 与 protein FASTA 顺序不一致")
    write_csv(
        one_to_one_mapping_path,
        ["output_DNA_id", "original_DNA_id", "protein_id", "Type", "Subtype",
         "DNA_source", "nucleotide_accession", "retrieval_round",
         "translation_result", "protein_length_aa", "DNA_length_nt"],
        one_to_one_rows,
    )

    # 不匹配和无可用DNA的诊断清单。
    unmatched_rows = [row for row in audit_rows if row.get("accepted") is not True]
    unmatched_path = output_dir / "SARG_unmatched_DNA_protein_pairs.csv"
    write_csv(unmatched_path, audit_fields, unmatched_rows)
    proteins_without_valid_dna = [
        protein_id for protein_id in protein_order if protein_id not in matched_protein_ids
    ]
    no_dna_rows = []
    for protein_id in proteins_without_valid_dna:
        row = structure_by_id[protein_id]
        no_dna_rows.append({
            "protein_id": protein_id,
            "Type": row["Type"].strip(),
            "Subtype": row["Subtype"].strip(),
            "reason": "No translation-verified DNA mapping",
        })
    no_dna_path = output_dir / "SARG_proteins_without_verified_DNA.csv"
    write_csv(no_dna_path, ["protein_id", "Type", "Subtype", "reason"], no_dna_rows)

    result_counts = Counter(row["translation_result"] for row in audit_rows)
    strict_pair_count = sum(row.get("strict_exact") is True for row in audit_rows)
    compatible_pair_count = sum(
        row.get("accepted") is True and row.get("strict_exact") is not True
        for row in audit_rows
    )
    summary_lines = [
        f"input_protein_records\t{len(proteins)}",
        f"input_protein_subtypes\t{len(all_structure_subtypes)}",
        f"input_DNA_records\t{len(dna_records)}",
        f"input_mapping_rows\t{len(mapping_rows)}",
        f"strict_exact_DNA_protein_pairs\t{strict_pair_count}",
        f"compatible_exact_pairs_with_ambiguous_protein_residues\t{compatible_pair_count}",
        f"accepted_translation_verified_DNA_pairs\t{sum(len(v) for v in protein_to_valid_dna.values())}",
        f"unique_proteins_with_verified_DNA\t{len(matched_protein_ids)}",
        f"subtypes_with_at_least_{MIN_PROTEINS_PER_SUBTYPE}_verified_proteins\t{len(retained_subtypes)}",
        f"subtypes_excluded_fewer_than_{MIN_PROTEINS_PER_SUBTYPE}_verified_proteins\t{len(all_structure_subtypes) - len(retained_subtypes)}",
        f"final_unique_protein_records\t{len(written_protein_ids)}",
        f"final_all_variant_DNA_records\t{len(retained_all_variant_ids)}",
        f"final_one_to_one_DNA_records\t{len(one_to_one_rows)}",
        f"final_one_to_one_protein_DNA_ID_sets_identical\t{set(written_one_to_one_ids) == set(written_protein_ids)}",
        f"final_one_to_one_protein_DNA_order_identical\t{written_one_to_one_ids == written_protein_ids}",
        f"unmatched_DNA_mapping_rows\t{len(unmatched_rows)}",
        f"proteins_without_verified_DNA\t{len(proteins_without_valid_dna)}",
        f"mapping_Type_Subtype_mismatches\t{label_mismatch_count}",
        f"mapped_protein_IDs_not_in_FASTA\t{missing_protein_count}",
    ]
    for result, count in sorted(result_counts.items()):
        summary_lines.append(f"translation_result::{result}\t{count}")
    summary_path = output_dir / "SARG_verified_pairing_summary.txt"
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n" + "=" * 100)
    print("VERIFICATION AND EXTRACTION COMPLETED")
    print("=" * 100)
    print(f"Input proteins                         : {len(proteins)}")
    print(f"Input DNA                              : {len(dna_records)}")
    print(f"Accepted DNA-protein pairs             : {sum(len(v) for v in protein_to_valid_dna.values())}")
    print(f"Unique proteins with verified DNA      : {len(matched_protein_ids)}")
    print(f"Retained subtypes (>= {MIN_PROTEINS_PER_SUBTYPE} proteins)       : {len(retained_subtypes)}")
    print(f"Excluded subtypes (< {MIN_PROTEINS_PER_SUBTYPE} proteins)        : {len(all_structure_subtypes) - len(retained_subtypes)}")
    print(f"Final unique proteins                  : {len(written_protein_ids)}")
    print(f"Final DNA all variants                 : {len(retained_all_variant_ids)}")
    print(f"Final DNA one per protein              : {len(one_to_one_rows)}")
    print(f"One-to-one protein/DNA IDs identical   : {set(written_one_to_one_ids) == set(written_protein_ids)}")
    print(f"One-to-one protein/DNA order identical : {written_one_to_one_ids == written_protein_ids}")
    print(f"Unmatched DNA mappings                 : {len(unmatched_rows)}")
    print(f"Label mismatches                       : {label_mismatch_count}")
    print("\nOutput directory:")
    print(f"  {output_dir}")
    print("\nKey files:")
    for path in [
        protein_output_path, protein_structure_output_path,
        one_to_one_fasta_path, one_to_one_mapping_path,
        all_variants_fasta_path, all_variants_mapping_path,
        subtype_counts_path, excluded_subtypes_path, audit_path, summary_path,
    ]:
        print(f"  {path}")


if __name__ == "__main__":
    main()
