#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LongAA 100% Type-level comparison heatmaps
==========================================

用途
----
只比较 LongAA / Protein 的 100% full-length 结果。
将 5 个 Type-level 指标分别画成 5 个并排热图，并放在同一张图中：

    Accuracy | Precision | Recall | F1 | MCC

每个热图：
- 行 = ARGScope 与 DeepARG 可对应的固定18个 ARG Type
- 列 = ARGNet / DeepARG / Fungenetyper / PLM-ARG / ARGScope
- 非支持 / 缺失值 = 灰色
- ARGScope 列名红色高亮

输入
----
脚本会在当前目录及其子目录自动搜索 LongAA 100% 的 per-Type CSV。
优先兼容当前项目目录，例如：

ARGnet/ARGnet_LongAA_Type_level_performance/
    protein_100pct_argnet-l_classification_report_fixed18.csv

DeepARG/DeepARG_LongAA_Type_level_performance/
    protein_100pct_5parts_deeparg_SS_prot_classification_report_macro_micro_weighted.csv

Fungentyper/Fungenetyper_LongAA_results/
    100p_type_classification_report.csv

PLM_ARG/PLMARG_5conditions_perType_metrics/
    100p_perType_metrics_ARG_only.csv

ARGscope/
    protein_100%_type_level_metrics.csv

输出
----
LongAA_100pct_5metrics_heatmap/
    LongAA_100pct_5metrics_heatmaps.png
    LongAA_100pct_5metrics_heatmaps.tif
    LongAA_100pct_5metrics_heatmaps.pdf
    LongAA_100pct_5metrics_heatmaps.svg
    LongAA_100pct_5metrics_values_long.csv
    LongAA_100pct_selected_source_files.csv
"""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =============================================================================
# 1. Paths / output
# =============================================================================
ROOT_DIR = Path(__file__).resolve().parent
OUTDIR = ROOT_DIR / "LongAA_100pct_5metrics_heatmap"
OUTDIR.mkdir(parents=True, exist_ok=True)

DPI = 600
SAVE_PNG = True
SAVE_TIF = True
SAVE_PDF = True
SAVE_SVG = True
TRANSPARENT_BG = True


# =============================================================================
# 2. Figure settings
# =============================================================================
FIG_WIDTH = 11.6
FIG_HEIGHT = 6.15

FONT_FAMILY = "Arial"
PANEL_TITLE_SIZE = 8.5
TYPE_LABEL_SIZE = 7.0
MODEL_LABEL_SIZE = 6.8
ANNOTATION_SIZE = 4.8
COLORBAR_LABEL_SIZE = 7.5
COLORBAR_TICK_SIZE = 6.5

ANNOTATION_DECIMALS = 3
VMIN = 0.0
VMAX = 1.0
CMAP_NAME = "Blues"
MISSING_COLOR = "#E6E6E6"
CELL_GRID_LINEWIDTH = 0.35
PANEL_BORDER_LINEWIDTH = 0.55

# 模型顺序。如要把 PLM-ARG 放第一个，可改成：
# ["PLM-ARG", "ARGNet", "DeepARG", "Fungenetyper", "ARGScope"]
MODEL_ORDER = ["ARGNet", "DeepARG", "Fungenetyper", "PLM-ARG", "ARGScope"]

# 5 个指标 = 5 组并排热图
METRIC_ORDER = ["Precision", "Recall", "F1"]


# =============================================================================
# 3. Final common 18 ARG Types
# =============================================================================
TYPE_ORDER = [
    "vancomycin",
    "trimethoprim",
    "tetracycline",
    "sulfonamide",
    "streptothricin",
    "rifamycin",
    "quinolone",
    "polymyxin",
    "novobiocin",
    "multidrug",
    "MLS",
    "fusidic_acid",
    "fosfomycin",
    "chloramphenicol",
    "bleomycin",
    "beta_lactam",
    "bacitracin",
    "aminoglycoside",
]
# 显示名称：默认尽量保持你的项目命名。
TYPE_DISPLAY = {
    "novobiocin": "novobiocin",
    "MLS": "MLS",
    "beta_lactam": "beta_lactam",
    "multidrug": "multidrug",
    "sulfonamide": "sulfonamide",
    "tetracycline": "tetracycline",
    "aminoglycoside": "aminoglycoside",
    "rifamycin": "rifamycin",
    "fosfomycin": "fosfomycin",
    "vancomycin": "vancomycin",
    "polymyxin": "polymyxin",
    "other_peptide_antibiotics": "other_peptide_antibiotics",
    "quinolone": "quinolone",
    "bleomycin": "bleomycin",
    "chloramphenicol": "chloramphenicol",
    "trimethoprim": "trimethoprim",
    "tetracenomycin_C": "tetracenomycin_C",
    "florfenicol": "florfenicol",
    "bacitracin": "bacitracin",
    "fusidic_acid": "fusidic_acid",
    "tunicamycin": "tunicamycin",
    "puromycin": "puromycin",
    "streptothricin": "streptothricin",
}


# =============================================================================
# 4. Type mapping
# =============================================================================
TYPE_MAPPING = {
    # MLS
    "mls": "MLS",
    "macrolide_lincosamide_streptogramin": "MLS",
    "macrolide_lincosamide_streptogramins": "MLS",

    # beta-lactam
    "beta_lactam": "beta_lactam",
    "beta_lactams": "beta_lactam",
    "betalactam": "beta_lactam",
    "betalactams": "beta_lactam",

    # multidrug
    "multidrug": "multidrug",
    "multi_drug": "multidrug",
    "multi_drug_resistance": "multidrug",

    # sulfonamide
    "sulfonamide": "sulfonamide",
    "sulfonamides": "sulfonamide",

    # tetracycline
    "tetracycline": "tetracycline",
    "tetracyclines": "tetracycline",

    # aminoglycoside
    "aminoglycoside": "aminoglycoside",
    "aminoglycosides": "aminoglycoside",

    # rifamycin
    "rifamycin": "rifamycin",
    "rifampin": "rifamycin",
    "rifampicin": "rifamycin",

    # fosfomycin
    "fosfomycin": "fosfomycin",

    # vancomycin / glycopeptide
    "vancomycin": "vancomycin",
    "glycopeptide": "vancomycin",
    "glycopeptides": "vancomycin",

    # polymyxin
    "polymyxin": "polymyxin",
    "polymyxins": "polymyxin",

    # other peptide antibiotics
    "other_peptide_antibiotics": "other_peptide_antibiotics",
    "other_peptide_antibiotic": "other_peptide_antibiotics",
    "peptide": "other_peptide_antibiotics",
    "peptide_antibiotics": "other_peptide_antibiotics",

    # quinolone / fluoroquinolone
    "quinolone": "quinolone",
    "quinolones": "quinolone",
    "fluoroquinolone": "quinolone",
    "fluoroquinolones": "quinolone",

    # phenicol / chloramphenicol
    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "phenicols": "chloramphenicol",

    # trimethoprim / diaminopyrimidine
    "trimethoprim": "trimethoprim",
    "diaminopyrimidine": "trimethoprim",
    "diaminopyrimidines": "trimethoprim",

    # others
    "novobiocin": "novobiocin",
    "bleomycin": "bleomycin",
    "tetracenomycin_c": "tetracenomycin_C",
    "florfenicol": "florfenicol",
    "bacitracin": "bacitracin",
    "fusidic_acid": "fusidic_acid",
    "fusidicacid": "fusidic_acid",
    "tunicamycin": "tunicamycin",
    "puromycin": "puromycin",
    "streptothricin": "streptothricin",
}


# =============================================================================
# 5. Column names
# =============================================================================
TYPE_CANDIDATES = [
    "Type", "type", "class_name", "class", "label", "category", "arg_type"
]

METRIC_CANDIDATES = {
    # "Accuracy": ["ACC", "Accuracy", "accuracy", "acc"],
    "Precision": ["Precision", "precision", "PRECISION", "prec"],
    "Recall": ["Recall", "recall", "RECALL", "rec"],
    "F1": ["F1", "f1", "F1-score", "f1-score", "f1_score", "F1_score"],
    # "MCC": ["MCC", "mcc"],
}

COUNT_CANDIDATES = {
    "TP": ["TP", "tp"],
    "FP": ["FP", "fp"],
    "FN": ["FN", "fn"],
    "TN": ["TN", "tn"],
}


# =============================================================================
# 6. Basic helpers
# =============================================================================
def clean_text(value):
    if pd.isna(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def canonical_token(value):
    text = clean_text(value).lower()
    text = text.replace("%", "pct")
    text = re.sub(r"[\s/:._-]+", "_", text)
    text = re.sub(r"[^a-z0-9_]", "", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def canonical_type(value):
    raw = clean_text(value)
    token = canonical_token(raw)
    return TYPE_MAPPING.get(token, raw)


def is_summary_row(value):
    token = canonical_token(value)
    if token in {
        "", "accuracy", "overall", "all", "total", "mean",
        "macro_avg", "micro_avg", "weighted_avg",
        "macro_average", "micro_average", "weighted_average",
        "average", "nan", "none", "null", "nonarg", "non_arg",
    }:
        return True
    return any(x in token for x in ["macro", "micro", "weighted", "overall", "average"])


def find_column(columns, candidates):
    mapping = {canonical_token(c): str(c) for c in columns}
    for candidate in candidates:
        token = canonical_token(candidate)
        if token in mapping:
            return mapping[token]
    return None


def numeric_series(series):
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    return pd.to_numeric(
        series.astype(str).str.strip().str.replace("%", "", regex=False),
        errors="coerce",
    )


def normalize_metric_scale(series):
    values = pd.to_numeric(series, errors="coerce")
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return values
    max_abs = float(np.nanmax(np.abs(finite.to_numpy(dtype=float))))
    if 1.5 < max_abs <= 100.5:
        return values / 100.0
    return values


def read_csv_flexible(path: Path):
    errors = []
    for encoding in ["utf-8-sig", "utf-8", "gbk", "latin-1"]:
        try:
            df = pd.read_csv(path, sep=None, engine="python", encoding=encoding)
            df.columns = [clean_text(c) for c in df.columns]
            return df
        except Exception as exc:
            errors.append(f"{encoding}: {type(exc).__name__}: {exc}")
    raise RuntimeError("Cannot read: %s\n%s" % (path, "\n".join(errors)))


def detect_type_column(df):
    found = find_column(df.columns, TYPE_CANDIDATES)
    if found is not None:
        return found

    # fallback: first object column with many unique values
    for column in df.columns:
        if df[column].dtype == object:
            values = df[column].dropna().map(clean_text)
            if values.nunique() >= 5:
                return str(column)
    return None


# =============================================================================
# 7. File metadata
# =============================================================================
def infer_model(path: Path):
    text = str(path).lower()
    token_text = canonical_token(str(path))

    if "argscope" in text:
        return "ARGScope"
    if "argnet" in text:
        return "ARGNet"
    if "deeparg" in text:
        return "DeepARG"
    if "fungenetyper" in text or "fungentyper" in text:
        return "Fungenetyper"
    if (
        "plm-arg" in text
        or "plm_arg" in text
        or "plmarg" in text
        or "plm_arg" in token_text
        or "plmarg" in token_text
    ):
        return "PLM-ARG"
    return None


def is_longaa_100pct(path: Path, model: str | None):
    text = str(path).lower()
    name = path.name.lower().replace(" ", "")

    # Only LongAA / protein.
    # PLM-ARG is protein-only in this comparison.
    is_longaa = (
        "longaa" in text
        or "protein" in name
        or model == "PLM-ARG"
        or "fungenetyper_longaa" in text
    )
    if not is_longaa:
        return False

    # 100% / full-length recognition.
    # DeepARG's new fixed18 output uses "protein_all" instead of "100p".
    is_100 = bool(
        re.search(r"(?<!\d)100%(?!\d)", name)
        or re.search(r"(?<!\d)100pct(?!\d)", name)
        or re.search(r"(?<!\d)100p(?![a-z0-9])", name)
        or "longaa" in name
        or "protein_all" in name
    )
    return is_100


def candidate_score(path: Path, model: str):
    """Higher score = preferred 100% input for that model."""
    name = path.name.lower()
    full = str(path).lower()
    score = 0

    # Exact current-project preferred files.
    preferred = {
        "ARGNet": ["protein_100pct_argnet-l_classification_report_fixed18.csv"],
        "DeepARG": [
            "deeparg_type_protein_all_classification_report.csv",
            "deeparg_type_protein_all_per_class_metrics.csv",
            "protein_100pct_5parts_deeparg_ss_prot_classification_report_macro_micro_weighted.csv",
        ],
        "Fungenetyper": ["100p_type_classification_report.csv"],
        "PLM-ARG": ["100p_pertype_metrics_arg_only.csv"],
        "ARGScope": [
            "protein_100%_type_level_metrics.csv",
            "100p_coverage_type_metrics.csv",
        ],
    }

    if name in preferred.get(model, []):
        score += 100

    if "100" in name:
        score += 20
    if "type" in name:
        score += 10
    if "metric" in name:
        score += 10
    if "arg_only" in name:
        score += 15
    if "including_nonarg" in name:
        score -= 50
    if "prediction" in name:
        score -= 20
    if "summary" in name:
        score -= 10

    # Prefer known LongAA folders.
    if "longaa" in full:
        score += 10

    return score


def collect_100pct_files(root_dir: Path):
    by_model = {m: [] for m in MODEL_ORDER}

    for path in root_dir.rglob("*.csv"):
        if not path.is_file():
            continue

        # Do not recursively ingest our own outputs.
        if OUTDIR in path.parents:
            continue

        model = infer_model(path)
        if model not in by_model:
            continue

        if is_longaa_100pct(path, model):
            by_model[model].append(path)

    selected = {}
    for model in MODEL_ORDER:
        candidates = by_model[model]
        if not candidates:
            continue
        candidates = sorted(
            candidates,
            key=lambda p: (candidate_score(p, model), -len(p.parts), str(p)),
            reverse=True,
        )
        selected[model] = candidates[0]

    return selected, by_model


# =============================================================================
# 8. Read one per-Type table
# =============================================================================
def derive_acc_mcc_from_confusion(output: pd.DataFrame):
    """Fill Accuracy/MCC when TP/FP/FN/TN are available."""
    if not all(c in output.columns for c in ["TP", "FP", "FN", "TN"]):
        return output

    tp = pd.to_numeric(output["TP"], errors="coerce")
    fp = pd.to_numeric(output["FP"], errors="coerce")
    fn = pd.to_numeric(output["FN"], errors="coerce")
    tn = pd.to_numeric(output["TN"], errors="coerce")

    total = tp + fp + fn + tn
    acc = (tp + tn) / total.replace(0, np.nan)

    denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = ((tp * tn) - (fp * fn)) / denom.replace(0, np.nan)

    if "Accuracy" not in output.columns:
        output["Accuracy"] = acc
    else:
        output["Accuracy"] = output["Accuracy"].fillna(acc)

    if "MCC" not in output.columns:
        output["MCC"] = mcc
    else:
        output["MCC"] = output["MCC"].fillna(mcc)

    return output


def standardize_per_type_file(path: Path, model: str):
    raw = read_csv_flexible(path)
    type_col = detect_type_column(raw)
    if type_col is None:
        raise ValueError("No Type column found. Columns=%s" % raw.columns.tolist())

    output = pd.DataFrame({
        "Type": raw[type_col].map(clean_text).map(canonical_type),
    })

    # 5 metrics
    for metric in METRIC_ORDER:
        col = find_column(raw.columns, METRIC_CANDIDATES[metric])
        if col is not None:
            output[metric] = normalize_metric_scale(numeric_series(raw[col]))
        else:
            output[metric] = np.nan

    # Optional confusion-count columns. Used to reconstruct ACC/MCC when needed.
    for count_name, candidates in COUNT_CANDIDATES.items():
        col = find_column(raw.columns, candidates)
        if col is not None:
            output[count_name] = numeric_series(raw[col])

    output = derive_acc_mcc_from_confusion(output)

    # Clean rows.
    output = output[~output["Type"].map(is_summary_row)].copy()
    output = output[output["Type"].isin(TYPE_ORDER)].copy()

    # If duplicated Type rows exist, average numerical metrics.
    metric_cols = [m for m in METRIC_ORDER if m in output.columns]
    output = output.groupby("Type", as_index=False)[metric_cols].mean()

    output["model"] = model
    output["source_file"] = str(path.resolve())
    return output


# =============================================================================
# 9. Build master table
# =============================================================================
def build_master(root_dir: Path):
    selected, all_candidates = collect_100pct_files(root_dir)

    print("=" * 110)
    print("LongAA 100% Type-level 5-metric heatmaps")
    print("=" * 110)
    print("ROOT_DIR:", root_dir)
    print("OUTDIR  :", OUTDIR)
    print()

    print("Selected 100% LongAA files:")
    for model in MODEL_ORDER:
        if model in selected:
            print("  %-13s %s" % (model + ":", selected[model]))
        else:
            print("  %-13s NOT FOUND" % (model + ":"))

    rows = []
    source_rows = []

    for model in MODEL_ORDER:
        path = selected.get(model)
        if path is None:
            continue

        try:
            table = standardize_per_type_file(path, model)
            rows.append(table)
            source_rows.append({
                "model": model,
                "selected_file": str(path),
                "n_types_read": int(table["Type"].nunique()),
                "available_metrics": ";".join(
                    [m for m in METRIC_ORDER if table[m].notna().any()]
                ),
            })
        except Exception as exc:
            print("[ERROR] %s: %s: %s" % (model, type(exc).__name__, exc))

    if not rows:
        raise RuntimeError("No usable LongAA 100% per-Type files were read.")

    master = pd.concat(rows, ignore_index=True)

    # Save source audit.
    pd.DataFrame(source_rows).to_csv(
        OUTDIR / "LongAA_100pct_selected_source_files.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return master


# =============================================================================
# 10. Make one metric matrix
# =============================================================================
def build_metric_matrix(master: pd.DataFrame, metric: str):
    subset = master[["Type", "model", metric]].copy()
    pivot = subset.pivot_table(
        index="Type",
        columns="model",
        values=metric,
        aggfunc="mean",
    )
    pivot = pivot.reindex(index=TYPE_ORDER, columns=MODEL_ORDER)
    return pivot


# =============================================================================
# 11. Draw one panel
# =============================================================================
def draw_heatmap_panel(ax, heat: pd.DataFrame, metric: str, show_ylabels: bool):
    arr = heat.to_numpy(dtype=float)
    masked = np.ma.masked_invalid(arr)

    cmap = plt.get_cmap(CMAP_NAME).copy()
    cmap.set_bad(MISSING_COLOR)

    im = ax.imshow(
        masked,
        cmap=cmap,
        vmin=VMIN,
        vmax=VMAX,
        aspect="auto",
        interpolation="nearest",
    )

    ax.set_title(metric, fontsize=PANEL_TITLE_SIZE, pad=4.0)

    ax.set_xticks(np.arange(len(MODEL_ORDER)))
    ax.set_xticklabels(
        MODEL_ORDER,
        rotation=45,
        ha="right",
        va="top",
        rotation_mode="anchor",
        fontsize=MODEL_LABEL_SIZE,
    )

    ax.set_yticks(np.arange(len(TYPE_ORDER)))
    if show_ylabels:
        ax.set_yticklabels(
            [TYPE_DISPLAY.get(t, t) for t in TYPE_ORDER],
            fontsize=TYPE_LABEL_SIZE,
        )
    else:
        ax.set_yticklabels([])

    ax.tick_params(axis="x", which="major", length=0, pad=2.0)
    ax.tick_params(axis="y", which="major", length=0, pad=2.5)

    # cell borders
    ax.set_xticks(np.arange(-0.5, len(MODEL_ORDER), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(TYPE_ORDER), 1), minor=True)
    ax.grid(
        which="minor",
        color="black",
        linestyle="-",
        linewidth=CELL_GRID_LINEWIDTH,
        alpha=0.9,
    )
    ax.tick_params(which="minor", bottom=False, left=False)

    # annotations
    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            value = arr[i, j]
            if np.isnan(value):
                continue

            text_color = "white" if value >= 0.62 else "#1F1F1F"
            fontweight = "bold" if MODEL_ORDER[j] == "ARGScope" else "normal"

            ax.text(
                j,
                i,
                f"{value:.{ANNOTATION_DECIMALS}f}",
                ha="center",
                va="center",
                fontsize=ANNOTATION_SIZE,
                color=text_color,
                fontweight=fontweight,
                clip_on=True,
            )

    # ARGScope x-label highlight
    for tick in ax.get_xticklabels():
        if tick.get_text() == "ARGScope":
            tick.set_color("#D62728")
            tick.set_fontweight("bold")

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(PANEL_BORDER_LINEWIDTH)
        spine.set_edgecolor("#000000")

    return im


# =============================================================================
# 12. Plot all 5 metrics in one figure
# =============================================================================
def plot_all_metrics(master: pd.DataFrame):
    heatmaps = {metric: build_metric_matrix(master, metric) for metric in METRIC_ORDER}

    # long-format values for audit / reuse
    long_rows = []
    for metric, heat in heatmaps.items():
        for type_name in heat.index:
            for model in heat.columns:
                long_rows.append({
                    "Metric": metric,
                    "Type": type_name,
                    "Model": model,
                    "Value": heat.loc[type_name, model],
                })
    pd.DataFrame(long_rows).to_csv(
        OUTDIR / "LongAA_100pct_5metrics_values_long.csv",
        index=False,
        encoding="utf-8-sig",
    )

    fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT))
    if TRANSPARENT_BG:
        fig.patch.set_alpha(0.0)

    # 5 panels + one narrow colorbar column
    gs = fig.add_gridspec(
        nrows=1,
        ncols=6,
        width_ratios=[1, 1, 1, 1, 1, 0.045],
        left=0.12,
        right=0.965,
        top=0.95,
        bottom=0.16,
        wspace=0.10,
    )

    axes = [fig.add_subplot(gs[0, i]) for i in range(5)]
    cax = fig.add_subplot(gs[0, 5])

    last_im = None
    for idx, metric in enumerate(METRIC_ORDER):
        last_im = draw_heatmap_panel(
            axes[idx],
            heatmaps[metric],
            metric=metric,
            show_ylabels=(idx == 0),
        )

    cbar = fig.colorbar(
        last_im,
        cax=cax,
        ticks=np.linspace(VMIN, VMAX, 6),
    )
    cbar.set_label("Score", fontsize=COLORBAR_LABEL_SIZE, labelpad=4)
    cbar.ax.tick_params(
        labelsize=COLORBAR_TICK_SIZE,
        length=2.5,
        width=0.5,
        pad=2.0,
    )
    cbar.outline.set_linewidth(0.5)

    base = OUTDIR / "LongAA_100pct_5metrics_heatmaps"

    save_common = dict(
        bbox_inches="tight",
        pad_inches=0.03,
        transparent=TRANSPARENT_BG,
    )

    if SAVE_PNG:
        fig.savefig(str(base) + ".png", dpi=DPI, **save_common)
    if SAVE_TIF:
        fig.savefig(str(base) + ".tif", dpi=DPI, **save_common)
    if SAVE_PDF:
        fig.savefig(str(base) + ".pdf", **save_common)
    if SAVE_SVG:
        fig.savefig(str(base) + ".svg", **save_common)

    plt.close(fig)

    print()
    print("[Saved]")
    print(" ", str(base) + ".png")
    print(" ", str(base) + ".tif")
    print(" ", str(base) + ".pdf")
    print(" ", str(base) + ".svg")


# =============================================================================
# 13. Main
# =============================================================================
def main():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [FONT_FAMILY, "DejaVu Sans", "Liberation Sans"],
        "font.size": 7.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
        "savefig.facecolor": "none" if TRANSPARENT_BG else "white",
        "savefig.edgecolor": "none" if TRANSPARENT_BG else "white",
    })

    master = build_master(ROOT_DIR)

    print()
    print("[Per-model data summary]")
    summary = (
        master.groupby("model")
        .agg(
            n_types=("Type", "nunique"),
            # Accuracy=("Accuracy", lambda x: int(x.notna().sum())),
            Precision=("Precision", lambda x: int(x.notna().sum())),
            Recall=("Recall", lambda x: int(x.notna().sum())),
            F1=("F1", lambda x: int(x.notna().sum())),
            # MCC=("MCC", lambda x: int(x.notna().sum())),
        )
        .reindex(MODEL_ORDER)
    )
    print(summary.to_string())

    plot_all_metrics(master)

    print()
    print("Done.")
    print("Output directory:", OUTDIR)


if __name__ == "__main__":
    main()
