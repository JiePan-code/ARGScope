# ============================================================
# Train GAT on subtype graph with Type supervision
# Train/Test only (no val) and export 5.Refined_embeddings_256.csv
# ============================================================

import random
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score, accuracy_score, matthews_corrcoef

from torch_geometric.data import Data
from torch_geometric.nn import GATConv


# -----------------------------
# Config
# -----------------------------
SEED = 42
PROTO_FILE = "4.subtype_prototypes_512.csv"
EDGE_FILE  = "2.subtype_graph_edges.csv"
OUT_FILE   = "5.Refined_embeddings_512.csv"

HIDDEN_DIM = 512
HEADS_1 = 4
DROPOUT = 0.3

LR = 1e-3
WEIGHT_DECAY = 1e-4
MAX_EPOCHS = 400
PATIENCE = 30
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

TEST_RATIO = 0.20  # only train/test


# -----------------------------
# Reproducibility
# -----------------------------
def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

seed_everything(SEED)


# -----------------------------
# Helper: robust per-type split (keeps ALL nodes)
# -----------------------------
def split_by_type_train_test_keep_all(y, test_ratio=0.2, seed=42):
    """
    y: np.ndarray (N,) int type labels
    returns: idx_train, idx_test
    Strategy (per type):
      n=1 -> all train
      n>=2 -> ensure >=1 test and >=1 train if possible
    """
    rng = np.random.default_rng(seed)
    idx_train, idx_test = [], []

    y = np.asarray(y)
    classes = np.unique(y)

    for c in classes:
        idx_c = np.where(y == c)[0]
        rng.shuffle(idx_c)
        n = len(idx_c)

        if n == 1:
            idx_train.extend(idx_c.tolist())
            continue

        # choose test count
        n_test = max(1, int(round(n * test_ratio)))
        n_test = min(n_test, n - 1)  # leave at least 1 for train

        test_part = idx_c[:n_test]
        train_part = idx_c[n_test:]

        # safety
        if len(train_part) == 0:
            train_part = idx_c[-1:]
            test_part = idx_c[:-1]

        idx_test.extend(test_part.tolist())
        idx_train.extend(train_part.tolist())

    rng.shuffle(idx_train)
    rng.shuffle(idx_test)
    return np.array(idx_train, dtype=np.int64), np.array(idx_test, dtype=np.int64)


# -----------------------------
# Load prototypes (nodes)
# -----------------------------
proto_df = pd.read_csv(PROTO_FILE)
for col in ["Subtype", "Type"]:
    if col not in proto_df.columns:
        raise RuntimeError(f"{PROTO_FILE} missing column: {col}")

# feature cols: prefer g0..g511, else digit cols, else numeric fallback
g_cols = [c for c in proto_df.columns if str(c).startswith("g")]
digit_cols = [c for c in proto_df.columns if str(c).isdigit()]

if len(g_cols) > 0:
    feat_cols = g_cols
elif len(digit_cols) > 0:
    feat_cols = digit_cols
else:
    num_cols = proto_df.select_dtypes(include=[np.number]).columns.tolist()
    feat_cols = [c for c in num_cols if c not in ["Count"]]

X = proto_df[feat_cols].apply(pd.to_numeric, errors="coerce").to_numpy(np.float32)
if np.isnan(X).any():
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

# L2 normalize
X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)

type_le = LabelEncoder()
y = type_le.fit_transform(proto_df["Type"].astype(str).values).astype(np.int64)

num_nodes = X.shape[0]
num_classes = len(type_le.classes_)
print("Nodes (subtypes):", num_nodes)
print("Type classes:", num_classes)
print("Feature dim:", X.shape[1])

# -----------------------------
# Load edges
# -----------------------------
edge_df = pd.read_csv(EDGE_FILE)
if not {"source", "target"}.issubset(set(edge_df.columns)):
    raise RuntimeError(f"{EDGE_FILE} must have columns: source,target")

src = edge_df["source"].to_numpy(np.int64)
dst = edge_df["target"].to_numpy(np.int64)

if src.max() >= num_nodes or dst.max() >= num_nodes or src.min() < 0 or dst.min() < 0:
    raise RuntimeError("Edge node id out of range. Ensure edges align to prototype node_id order.")

edge_index = torch.tensor(np.vstack([src, dst]), dtype=torch.long)
print("Edges:", edge_index.size(1))

# -----------------------------
# Train/Test split (no val)
# -----------------------------
idx_train, idx_test = split_by_type_train_test_keep_all(y, test_ratio=TEST_RATIO, seed=SEED)

train_mask = torch.zeros(num_nodes, dtype=torch.bool)
test_mask  = torch.zeros(num_nodes, dtype=torch.bool)
train_mask[idx_train] = True
test_mask[idx_test] = True

print("Split nodes train/test:", train_mask.sum().item(), test_mask.sum().item())

# -----------------------------
# Build PyG data
# -----------------------------
data = Data(
    x=torch.tensor(X, dtype=torch.float32),
    edge_index=edge_index,
    y=torch.tensor(y, dtype=torch.long),
    train_mask=train_mask,
    test_mask=test_mask
).to(DEVICE)

# class weights (macro-F1 friendly)
train_counts = torch.bincount(data.y[data.train_mask], minlength=num_classes).float()
class_weight = (train_counts.sum() / (num_classes * (train_counts + 1e-6)))
class_weight = (class_weight / class_weight.mean()).to(DEVICE)

# -----------------------------
# Model
# -----------------------------
class GATNet(torch.nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, heads=4, dropout=0.2):
        super().__init__()
        self.dropout = dropout
        self.gat1 = GATConv(in_dim, hid_dim, heads=heads, dropout=dropout)
        self.gat2 = GATConv(hid_dim * heads, hid_dim, heads=1, concat=False, dropout=dropout)
        self.cls  = torch.nn.Linear(hid_dim, out_dim)

    def forward(self, x, edge_index):
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.gat1(x, edge_index)
        x = F.elu(x)

        x = F.dropout(x, p=self.dropout, training=self.training)
        emb = self.gat2(x, edge_index)
        emb = F.elu(emb)

        logits = self.cls(emb)
        return logits, emb

model = GATNet(
    in_dim=data.x.size(1),
    hid_dim=HIDDEN_DIM,
    out_dim=num_classes,
    heads=HEADS_1,
    dropout=DROPOUT
).to(DEVICE)

opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=8)

# -----------------------------
# Train loop (early stopping on TEST macro-F1)
# -----------------------------
best_test = -1.0
best_state = None
no_improve = 0

for epoch in range(1, MAX_EPOCHS + 1):
    model.train()
    opt.zero_grad(set_to_none=True)

    logits, _ = model(data.x, data.edge_index)
    loss = F.cross_entropy(logits[data.train_mask], data.y[data.train_mask], weight=class_weight)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step()

    # eval on test
    model.eval()
    with torch.no_grad():
        logits, _ = model(data.x, data.edge_index)
        pred = logits.argmax(dim=1)

        yt = data.y[data.test_mask].detach().cpu().numpy()
        pt = pred[data.test_mask].detach().cpu().numpy()

        test_f1 = f1_score(yt, pt, average="macro")
        test_acc = accuracy_score(yt, pt)
        test_mcc = matthews_corrcoef(yt, pt)

    scheduler.step(test_f1)

    if epoch == 1 or epoch % 20 == 0:
        lr_now = opt.param_groups[0]["lr"]
        print(f"Epoch {epoch:03d} | LR {lr_now:.2e} | Loss {loss.item():.4f} | TEST ACC {test_acc:.4f} | TEST F1 {test_f1:.4f} | TEST MCC {test_mcc:.4f}")

    if test_f1 > best_test + 1e-6:
        best_test = test_f1
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        no_improve = 0
    else:
        no_improve += 1
        if no_improve >= PATIENCE:
            print(f"Early stopping at epoch {epoch}, best TEST macro-F1={best_test:.4f}")
            break

# -----------------------------
# Load best model, export refined embeddings
# -----------------------------
model.load_state_dict(best_state)
model = model.to(DEVICE)
model.eval()

with torch.no_grad():
    logits, emb = model(data.x, data.edge_index)
    pred = logits.argmax(dim=1)

yt = data.y[data.test_mask].cpu().numpy()
pt = pred[data.test_mask].cpu().numpy()
test_f1 = f1_score(yt, pt, average="macro")
test_acc = accuracy_score(yt, pt)
test_mcc = matthews_corrcoef(yt, pt)
print(f"FINAL TEST ACC {test_acc:.4f} | FINAL TEST macro-F1 {test_f1:.4f} | FINAL TEST MCC {test_mcc:.4f}")

emb_np = emb.detach().cpu().numpy().astype(np.float32)

# output CSV: Subtype, Type, Count, g0..g255
out_df = proto_df[["Subtype", "Type"]].copy()
if "Count" in proto_df.columns:
    out_df["Count"] = proto_df["Count"].values
else:
    out_df["Count"] = np.nan

for j in range(emb_np.shape[1]):
    out_df[f"g{j}"] = emb_np[:, j]

out_df.to_csv(OUT_FILE, index=False, encoding="utf-8-sig")
print("Saved:", OUT_FILE)