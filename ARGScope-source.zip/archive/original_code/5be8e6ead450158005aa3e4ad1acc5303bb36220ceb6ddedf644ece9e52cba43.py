"""Protein supervised Student only: no learned Teacher-to-Student transfer."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, disable_learned_transfer, load_base, mark_saved_ablation, set_common_student_defaults

DATA = Path(__file__).resolve().parents[3]
m = load_base("04_protein_student.py", "protein_wo_transfer_base")
set_common_student_defaults(m, DATA, "protein", "Protein_student_subtype2_newsplit_wo_transfer")
disable_learned_transfer(m)
mark_saved_ablation(m, "w/o Knowledge Transfer", "trained Teacher, KD, feature alignment, prototype alignment and head anchor")
add_default_structure(DATA)
m.main()
