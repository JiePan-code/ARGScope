"""Save and independently reopen the A4 rasters as lossless 300-DPI TIFFs."""
from pathlib import Path
import hashlib
import json
import zipfile
from PIL import Image, ImageChops, ImageDraw

WORK = Path(__file__).resolve().parent / 'outputs/figure2_figure3_a4_tif_20260924'
OUT = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Figure2_Figure3_A4_300DPI_TIF_20260924')
OUT.mkdir(parents=True, exist_ok=True)
PREVIEW = OUT / 'previews'
PREVIEW.mkdir(exist_ok=True)
records = json.loads((WORK / 'render_manifest.json').read_text(encoding='utf-8'))
checks = []
preview_images = []

for record in records:
    with Image.open(record['rasterPath']) as original:
        rgba = original.convert('RGBA')
    assert rgba.size == (2480, 3508)
    alpha = rgba.getchannel('A')
    assert alpha.getextrema() == (0, 255)
    bounds = alpha.getbbox()
    assert bounds[0] > 0 and bounds[1] > 0 and bounds[2] < 2480 and bounds[3] < 3508
    rgb = Image.new('RGB', rgba.size, 'white')
    rgb.paste(rgba, mask=alpha)
    for variant, pixels in [('transparent', rgba), ('white', rgb)]:
        name = f"{record['name']}_A4_300DPI_{variant}.tif"
        destination = OUT / name
        pixels.save(destination, format='TIFF', compression='tiff_lzw', dpi=(300, 300))
        with Image.open(destination) as reopened:
            reopened.load()
            assert reopened.format == 'TIFF'
            assert reopened.size == (2480, 3508)
            assert reopened.mode == pixels.mode
            assert tuple(reopened.info['dpi']) == (300.0, 300.0)
            assert reopened.tag_v2[296] == 2
            assert reopened.tag_v2[259] == 5
            assert reopened.tobytes() == pixels.tobytes()
            checks.append({
                'file': name, 'pixels': list(reopened.size), 'mode': reopened.mode,
                'dpi': [float(v) for v in reopened.info['dpi']], 'compression': 'LZW lossless',
                'page_mm': [2480 / 300 * 25.4, 3508 / 300 * 25.4],
                'content_bbox': list(bounds), 'round_trip_pixels_identical': True,
                'source_sha256': record['source_sha256'],
                'source_unchanged': hashlib.sha256(Path(record['sourcePath']).read_bytes()).hexdigest() == record['source_sha256'],
            })
            if variant == 'white':
                preview = reopened.copy()
                preview.thumbnail((1240, 1754), Image.Resampling.LANCZOS)
                preview.save(PREVIEW / f"{record['name']}_preview.png")
                preview_images.append(preview)
                # A native-pixel crop of the type heatmap for a legibility check.
                reopened.crop((0, 700, 2480, 1580)).save(WORK / f"{record['name']}_heatmap_QA.png")

assert all(c['source_unchanged'] for c in checks)
(OUT / 'export_verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
readme = '''Figure 2 / Figure 3 — A4, 300 DPI TIFF

两张独立组图，A4 纵向，2480 × 3508 像素，300 DPI，LZW 无损压缩。
transparent.tif：透明背景 RGBA 版本，沿用此前透明背景要求。
white.tif：白色背景 RGB 版本，适合通常的投稿和打印用途。
两种背景版本的图形、布局、数值完全一致。

直接由 20260923 最新多色版 SVG 渲染。保留纵横比例，没有拉伸或重新计算数据。
Figure 2 和 Figure 3 均采用已确认的紧凑组图，UMAP 显示 Epoch 0 和 Best epoch，错误对显示 Top 10。
原有 SVG 及完整单独子图未修改。根据后续指示，本次没有制作 Figure 4。
previews 文件夹仅为预览，正式使用请选 TIF 文件。
'''
(OUT / 'README.txt').write_text(readme, encoding='utf-8-sig')
with zipfile.ZipFile(OUT / 'Figure2_Figure3_A4_300DPI_TIF.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(OUT.rglob('*')):
        if file.is_file() and file.suffix != '.zip':
            archive.write(file, file.relative_to(OUT))
print(json.dumps({'output': str(OUT), 'checks': checks}, ensure_ascii=False, indent=2))
