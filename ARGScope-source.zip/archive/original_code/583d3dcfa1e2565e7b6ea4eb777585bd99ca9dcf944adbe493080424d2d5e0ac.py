#!/usr/bin/env python3
"""Validate cached calculations, actual box geometry and exports; build ZIP."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image
from matplotlib.cbook import boxplot_stats

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
DATA=ROOT/'data'
METRICS=['Accuracy','Precision','Recall','F1','MCC']
KEY=['Modality','Model','Completeness','Level']


def main():
    for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
    render=json.loads((ROOT/'render_status.json').read_text())
    assert render['status']=='COMPLETE'
    assert render['script_sha256']==hashlib.sha256((ROOT/'plot_all_model_boxplots.py').read_bytes()).hexdigest()
    figdir=ROOT/render['figure_directory']
    hashes=json.loads((DATA/'input_hashes.json').read_text())
    for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
    sources=pd.read_csv(DATA/'baseline_source_audit.csv')
    for row in sources.itertuples():assert hashes[row.Path]==row.SHA256
    boot=pd.read_csv(DATA/'all_model_parent_bootstrap.csv')
    summary=pd.read_csv(DATA/'all_model_points_and_intervals.csv')
    stats=pd.read_csv(DATA/'plotted_box_statistics.csv')
    checks=pd.read_csv(DATA/'baseline_independent_sklearn_checks.csv')
    assert len(boot)==80000 and len(summary)==200 and len(checks)==72
    assert checks.Max_abs_error.max()<1e-10
    assert np.isfinite(boot[METRICS].to_numpy()).all()
    assert np.allclose(boot.Accuracy,boot.Recall,rtol=0,atol=1e-12)
    for metric in METRICS:assert boot[metric].between(-1 if metric=='MCC' else 0,1).all()
    assert boot.groupby(KEY).ngroups==40
    for _,group in boot.groupby(KEY):assert len(group)==2000 and set(group.Bootstrap)==set(range(1,2001))
    assert set(boot.loc[boot.Level.eq('Subtype'),'Model'])=={'ARGScope'}
    for mod,expected in [('protein',{'ARGNet','DeepARG','PLM-ARG','FunGeneTyper','ARGScope'}),('dna',{'ARGNet','DeepARG','ARGScope'})]:
        assert set(boot.loc[boot.Level.eq('Type')&boot.Modality.eq(mod),'Model'])==expected
    own=pd.read_csv(SOURCE/'violin_revision/data/ARGScope_parent_bootstrap_five_metrics.csv')
    oldcols=list(own.columns)
    pd.testing.assert_frame_equal(boot[boot.Model.eq('ARGScope')][oldcols].reset_index(drop=True),own,check_exact=False,rtol=0,atol=1e-12)
    assert len(stats)==400
    for row in summary.itertuples():
        pick=boot[(boot.Modality==row.Modality)&(boot.Model==row.Model)&(boot.Level==row.Level)&(boot.Completeness==row.Completeness)][row.Metric]
        assert np.allclose([row.CI_low,row.Q1,row.Median,row.Q3,row.CI_high],pick.quantile([.025,.25,.5,.75,.975]),rtol=0,atol=1e-10)
        assert abs(row.Bootstrap_mean-pick.mean())<1e-10
        actual=boxplot_stats(pick,whis=1.5)[0]
        drawn=stats[(stats.Modality==row.Modality)&(stats.Model==row.Model)&(stats.Level==row.Level)&(stats.Completeness==row.Completeness)&(stats.Metric==row.Metric)]
        assert len(drawn)==2
        for c in ['q1','med','q3','whislo','whishi']:assert np.allclose(drawn[c],actual[c],rtol=0,atol=1e-10)
        assert drawn.N_fliers.eq(len(actual['fliers'])).all()
    filt=pd.read_csv(SOURCE/'violin_revision/data/network_Type_display_filter.csv')
    assert filt.Keep.sum()==22 and filt.loc[~filt.Keep,'Type'].tolist()==['puromycin']
    layout=json.loads((ROOT/'layout_validation.json').read_text())
    manifest=json.loads((ROOT/'figure_manifest.json').read_text())
    assert len(layout)==4 and all(not r['visible_text_outside_canvas'] for r in layout)
    assert len(manifest)==12
    outputs={}
    for r in manifest:
        p=figdir/r['file']
        assert p.stat().st_mtime>=render['started']-1
        assert p.stat().st_size>1000
        if p.suffix=='.png':
            with Image.open(p) as im:im.verify()
        elif p.suffix=='.svg':assert ET.parse(p).getroot().tag.endswith('svg')
        elif p.suffix=='.pdf':assert p.read_bytes().startswith(b'%PDF') and b'%%EOF' in p.read_bytes()[-100:]
        outputs[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    report=dict(status='PASS',bootstrap_rows=80000,score_distributions=200,baseline_sklearn_checks=72,
                baseline_max_abs_error=float(checks.Max_abs_error.max()),ARGScope_bootstrap_unchanged=True,
                same_test_cohort_across_models=False,DeepARG_population='selected_ARG_hits_only',
                global_bootstrap_zero_sample_filter=False,network_zero_type_hidden='puromycin',
                designs=4,exported_formats=12,text_clipping_failures=0,figure_sha256=outputs)
    (ROOT/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    # Only current manifest figures are shipped; exclude superseded previews.
    members=[p for p in ROOT.rglob('*') if not {'figures','final_figures'} & set(p.relative_to(ROOT).parts)]
    members += [figdir/r['file'] for r in manifest]
    members += [figdir/'all_models_boxplot_and_Type_network_main_preview.png']
    members += [SOURCE/'plot_fragment_figure.py',SOURCE/'type_level_revision/plot_type_network_revision.py',SOURCE/'violin_revision/bootstrap_overall_metrics.py']
    for directory in ['data','type_level_revision/data','violin_revision/data']:
        members += list((SOURCE/directory).glob('*.csv'))+list((SOURCE/directory).glob('*.json'))
    archive=SOURCE.parent/'ARGScope_all_models_boxplot_revision.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(members)):
            if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(SOURCE.parent))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        print(f'PASS: {len(z.namelist())} files, {archive.stat().st_size/2**20:.2f} MiB',flush=True)
    print(archive)
    print(json.dumps({k:v for k,v in report.items() if k!='figure_sha256'},indent=2))


if __name__=='__main__':main()
