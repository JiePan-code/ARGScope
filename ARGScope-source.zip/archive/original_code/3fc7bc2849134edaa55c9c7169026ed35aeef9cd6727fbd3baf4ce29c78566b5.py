#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算 PLM-ARG Protein 60%、70%、80%、90%、100% 的评价指标。

使用方法：
1. 将本脚本、5 个 PLM-ARG 结果 TSV、expanded_id_table_5x.csv
   和 all_arg_nonarg_id_label.csv
   放在同一个文件夹。
2. 直接运行本脚本。
3. 结果会写入同目录下的 PLMARG_Protein_metrics_results 文件夹。

也可以从命令行指定路径：
python calculate_PLMARG_Protein_metrics.py \
    --input-dir "PLMARG结果文件夹" \
    --labels "expanded_id_table_5x.csv"

输出内容：
- ARG/nonARG 的 macro、weighted、micro 三行总体五指标；
- macro、weighted、micro 三行 Type 总体五指标；
- 每个 Type 的 one-vs-rest 五指标；
- 实际使用的类别对应表；
- 无法严格对应的 PLMARG 类别统计；
- ID 与结构表匹配审计；
- 含真实 Type 和映射后预测 Type 的逐条结果。

指标：Accuracy、Precision、Recall、F1、MCC。

重要说明：
- ARG 列概率大于或等于 0.5 时预测为 ARG，否则预测为 nonARG。
- ARG 预测为 nonARG 时，Type 统一映射为 nonARG。
- 多标签 pred 若全部对应同一个目标 Type，则合并到该 Type；否则映射为
  multidrug。
- 对 PLMARG 与本数据集无法一一对应的类别，不会删除样本，也不会根据
  测试集真实标签强行决定映射，而是统一记为 __PLMARG_UNMAPPED__。
- Accuracy 和 multiclass MCC 是全局指标，因此会在 macro、weighted、
  micro 三行中重复显示；这与 ARGScope 指标脚本的处理一致。
- 代码只使用 Python 标准库，不需要 pandas 或 scikit-learn。
"""

from __future__ import annotations

import argparse
import csv
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, Sequence


INPUT_FILES = (
    ("60%", "protein_60pct_5parts_plmarg_result.tsv"),
    ("70%", "protein_70pct_5parts_plmarg_result.tsv"),
    ("80%", "protein_80pct_5parts_plmarg_result.tsv"),
    ("90%", "protein_90pct_5parts_plmarg_result.tsv"),
    ("100%", "protein_100pct_plmarg_result.tsv"),
)

LABEL_FILE_CANDIDATES = (
    "expanded_id_table_5x.csv",
    "all_arg_nonarg_id_label.csv",
)

OUTPUT_DIR_NAME = "PLMARG_Protein_metrics_results"
AVERAGES = ("macro", "weighted", "micro")
METRIC_COLUMNS = ("accuracy", "precision", "recall", "f1", "mcc")
UNMAPPED_LABEL = "__PLMARG_UNMAPPED__"
ARG_THRESHOLD = 0.5


# PLM-ARG pred token -> 本数据集 Type。
# 仅定义能够严格解释的一一对应或明确命名层级对应。
TYPE_MAPPING: dict[str, tuple[str, str, str]] = {
    "aminocoumarin": (
        "novobiocin",
        "ontology_alignment",
        "本数据集以代表性 aminocoumarin 药物 novobiocin 命名。",
    ),
    "aminoglycoside": (
        "aminoglycoside",
        "exact",
        "类别名称一致。",
    ),
    "beta-lactam": (
        "beta_lactam",
        "name_normalization",
        "仅连字符与下划线写法不同。",
    ),
    "diaminopyrimidine": (
        "trimethoprim",
        "ontology_alignment",
        "本数据集以代表性 diaminopyrimidine 药物 trimethoprim 命名。",
    ),
    "fluoroquinolone": (
        "quinolone",
        "ontology_alignment",
        "目标数据集使用更上层的 quinolone Type。",
    ),
    "glycopeptide": (
        "vancomycin",
        "ontology_alignment",
        "本数据集以代表性 glycopeptide 药物 vancomycin 命名。",
    ),
    "lincosamide": (
        "macrolide-lincosamide-streptogramin",
        "ontology_alignment",
        "目标数据集将该类别并入 MLS Type。",
    ),
    "macrolide": (
        "macrolide-lincosamide-streptogramin",
        "ontology_alignment",
        "目标数据集将该类别并入 MLS Type。",
    ),
    "streptogramin": (
        "macrolide-lincosamide-streptogramin",
        "ontology_alignment",
        "目标数据集将该类别并入 MLS Type。",
    ),
    "pleuromutilin": (
        "pleuromutilin_tiamulin",
        "ontology_alignment",
        "本数据集对应 Type 为 pleuromutilin_tiamulin。",
    ),
    "rifamycin": ("rifamycin", "exact", "类别名称一致。"),
    "sulfonamide": ("sulfonamide", "exact", "类别名称一致。"),
    "tetracycline": ("tetracycline", "exact", "类别名称一致。"),
}


# 这些 PLM-ARG 单标签类别覆盖多个目标 Type，或不存在严格同义 Type。
UNMAPPED_REASONS: dict[str, str] = {
    "alkaloids_with_antibiotic_activity": (
        "目标 Type 表中没有严格同义的对应类别。"
    ),
    "disinfecting_agents_and_antiseptics": (
        "该类别可对应多种消毒剂或耐药机制，不能与一个目标 Type 等同。"
    ),
    "nitroimidazole": "目标 Type 表中没有严格同义的 nitroimidazole 类别。",
    "nucleoside": (
        "Nucleoside 可覆盖 streptothricin、tunicamycin、puromycin 等"
        "多个目标 Type。"
    ),
    "peptide": (
        "Peptide 可覆盖 polymyxin、defensin、other_peptide_antibiotics "
        "等多个目标 Type。"
    ),
    "phenicol": (
        "Phenicol 同时覆盖 chloramphenicol 和 florfenicol，"
        "而目标数据集将二者分开。"
    ),
    "sulfone": "目标 Type 表中没有严格同义的 sulfone 类别。",
    "others": "PLM-ARG 的 others 不是目标数据集中的单一 Type。",
}


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="计算 PLM-ARG Protein 五个完整度结果的评价指标。"
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=script_dir,
        help="5 个 PLM-ARG TSV 所在目录；默认是脚本所在目录。",
    )
    parser.add_argument(
        "--labels",
        type=Path,
        default=None,
        help=(
            "结构表路径；默认在输入目录中依次寻找 "
            + ", ".join(LABEL_FILE_CANDIDATES)
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=f"输出目录；默认是输入目录下的 {OUTPUT_DIR_NAME}。",
    )
    return parser.parse_args()


def safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def header_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.strip().casefold())


def clean_text(value: object) -> str:
    return "" if value is None else str(value).strip()


def strip_fragment_suffix(sequence_id: str) -> str:
    return re.sub(r"_[1-5]$", "", sequence_id)


def normalize_category(value: str) -> str:
    return value.strip().casefold().replace(" ", "_")


def detect_delimiter(path: Path) -> str:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(65536)
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;").delimiter
    except csv.Error:
        return "\t" if path.suffix.casefold() in {".txt", ".tsv"} else ","


def read_dict_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    delimiter = detect_delimiter(path)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=delimiter)
        if reader.fieldnames is None:
            raise ValueError(f"{path.name} 没有表头。")
        fieldnames = [clean_text(name) for name in reader.fieldnames]
        rows: list[dict[str, str]] = []
        for row in reader:
            cleaned: dict[str, str] = {}
            for key, value in row.items():
                if key is not None:
                    cleaned[clean_text(key)] = clean_text(value)
            rows.append(cleaned)
    if not rows:
        raise ValueError(f"{path.name} 没有数据行。")
    return fieldnames, rows


def resolve_column(
    fieldnames: Sequence[str],
    accepted_keys: Sequence[str],
    description: str,
    path: Path,
    required: bool = True,
) -> str | None:
    lookup = {header_key(name): name for name in fieldnames}
    for candidate in accepted_keys:
        if candidate in lookup:
            return lookup[candidate]
    if required:
        raise ValueError(
            f"{path.name} 找不到 {description} 列。现有列："
            + ", ".join(fieldnames)
        )
    return None


def find_label_file(input_dir: Path, specified: Path | None) -> Path:
    if specified is not None:
        path = specified.expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"结构表不存在：{path}")
        return path

    for filename in LABEL_FILE_CANDIDATES:
        path = input_dir / filename
        if path.is_file():
            return path

    raise FileNotFoundError(
        "输入目录中没有找到结构表。请把 expanded_id_table_5x.csv "
        "放到脚本同目录，或使用 --labels 指定结构表路径。"
    )


def load_label_indexes(
    label_path: Path,
) -> tuple[
    dict[str, tuple[str, str]],
    dict[str, tuple[str, str]],
    dict[str, int],
]:
    fieldnames, rows = read_dict_rows(label_path)
    id_column = resolve_column(
        fieldnames,
        ("id", "testid", "sargseqid", "sequenceid", "seqid"),
        "ID",
        label_path,
    )
    type_column = resolve_column(
        fieldnames,
        ("type", "truetype", "resistancetype"),
        "Type",
        label_path,
    )
    subtype_column = resolve_column(
        fieldnames,
        ("subtype", "truesubtype"),
        "Subtype",
        label_path,
        required=False,
    )
    assert id_column is not None
    assert type_column is not None

    direct: dict[str, tuple[str, str]] = {}
    base_groups: dict[str, set[tuple[str, str]]] = defaultdict(set)
    suffix_counter: Counter[str] = Counter()

    for row_number, row in enumerate(rows, start=2):
        sequence_id = clean_text(row.get(id_column, ""))
        true_type = clean_text(row.get(type_column, ""))
        true_subtype = (
            clean_text(row.get(subtype_column, ""))
            if subtype_column is not None
            else ""
        )

        if not sequence_id:
            raise ValueError(f"{label_path.name} 第 {row_number} 行 ID 为空。")
        if not true_type:
            raise ValueError(
                f"{label_path.name} 第 {row_number} 行 Type 为空。"
            )
        label = (true_type, true_subtype)

        if sequence_id in direct:
            raise ValueError(
                f"{label_path.name} 存在重复 ID：{sequence_id!r}"
            )
        direct[sequence_id] = label

        base_id = strip_fragment_suffix(sequence_id)
        base_groups[base_id].add(label)
        if base_id != sequence_id:
            suffix_counter[sequence_id[-1]] += 1

    inconsistent_bases = [
        base_id for base_id, labels in base_groups.items() if len(labels) != 1
    ]
    if inconsistent_bases:
        examples = ", ".join(inconsistent_bases[:5])
        raise ValueError(
            "同一原始 ID 的扩增记录存在不同 Type/Subtype。示例：" + examples
        )

    base = {
        base_id: next(iter(labels)) for base_id, labels in base_groups.items()
    }
    metadata = {
        "label_rows": len(rows),
        "unique_label_ids": len(direct),
        "unique_base_ids": len(base),
        "ids_with_fragment_suffix": sum(suffix_counter.values()),
    }
    return direct, base, metadata


def normalize_arg_prediction(value: str, path: Path, row_number: int) -> str:
    key = re.sub(r"[\s_-]+", "", value.casefold())
    if key in {"arg", "positive", "pos", "1", "true"}:
        return "ARG"
    if key in {"nonarg", "negative", "neg", "0", "false"}:
        return "nonARG"
    raise ValueError(
        f"{path.name} 第 {row_number} 行 ARG_prediction 无法识别：{value!r}"
    )


def map_plmarg_prediction(
    arg_prediction: str,
    raw_category: str,
) -> tuple[str, str, str]:
    if arg_prediction == "nonARG":
        return (
            "nonARG",
            "binary_nonARG",
            "PLMARG 判定为 non-ARG，因此目标 Type 为 nonARG。",
        )

    keys: list[str] = []
    seen: set[str] = set()
    for token in raw_category.split(";"):
        key = normalize_category(token)
        if key and key not in seen:
            keys.append(key)
            seen.add(key)

    if len(keys) > 1:
        known_targets = {
            TYPE_MAPPING[key][0] for key in keys if key in TYPE_MAPPING
        }
        all_tokens_are_known = all(key in TYPE_MAPPING for key in keys)
        if all_tokens_are_known and len(known_targets) == 1:
            target = next(iter(known_targets))
            return (
                target,
                "multi_label_same_target",
                "多个 PLM-ARG 标签均对应同一个目标 Type。",
            )
        return (
            "multidrug",
            "multi_label_to_multidrug",
            "PLM-ARG 同时预测多个不同耐药类别，映射为 multidrug。",
        )

    key = keys[0] if keys else ""
    if key in TYPE_MAPPING:
        return TYPE_MAPPING[key]

    if key in UNMAPPED_REASONS:
        return (
            UNMAPPED_LABEL,
            "unmapped_ambiguous",
            UNMAPPED_REASONS[key],
        )

    if not key:
        reason = "ARG 概率达到阈值，但 pred 为空。"
    else:
        reason = "该 PLMARG 类别不在预先定义的严格对应表中。"
    return UNMAPPED_LABEL, "unmapped_unknown", reason


def resolve_true_label(
    test_id: str,
    direct_labels: dict[str, tuple[str, str]],
    base_labels: dict[str, tuple[str, str]],
) -> tuple[tuple[str, str] | None, str]:
    if test_id in direct_labels:
        return direct_labels[test_id], "direct_id"

    stripped = strip_fragment_suffix(test_id)
    if stripped in direct_labels:
        return direct_labels[stripped], "fragment_to_full_id"
    if test_id in base_labels:
        return base_labels[test_id], "full_id_to_expanded_base"
    if stripped in base_labels:
        return base_labels[stripped], "fragment_to_expanded_base"
    return None, "unmatched"


def sorted_labels(
    y_true: Iterable[str],
    y_pred: Iterable[str],
) -> list[str]:
    labels = set(y_true) | set(y_pred)
    return sorted(labels, key=lambda value: (value.casefold(), value))


def calculate_multiclass_mcc(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    labels: Sequence[str],
) -> float:
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    correct = sum(true == pred for true, pred in zip(y_true, y_pred))

    sum_true_pred = sum(
        true_counts[label] * predicted_counts[label] for label in labels
    )
    sum_true_squared = sum(true_counts[label] ** 2 for label in labels)
    sum_pred_squared = sum(predicted_counts[label] ** 2 for label in labels)

    numerator = correct * n_samples - sum_true_pred
    denominator = math.sqrt(
        (n_samples**2 - sum_pred_squared)
        * (n_samples**2 - sum_true_squared)
    )
    return safe_divide(numerator, denominator)


def calculate_overall_metrics(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    level_name: str,
    condition: str,
    source_file: str,
) -> list[dict[str, object]]:
    if len(y_true) != len(y_pred):
        raise ValueError(f"{source_file} 的真实标签与预测标签数量不一致。")
    if not y_true:
        raise ValueError(f"{source_file} 没有可计算记录。")

    labels = sorted_labels(y_true, y_pred)
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive = Counter(
        true for true, pred in zip(y_true, y_pred) if true == pred
    )

    correct = sum(true_positive.values())
    accuracy = safe_divide(correct, n_samples)
    mcc = calculate_multiclass_mcc(y_true, y_pred, labels)

    per_class: dict[str, dict[str, float]] = {}
    for label in labels:
        tp = true_positive[label]
        fp = predicted_counts[label] - tp
        fn = true_counts[label] - tp
        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)
        per_class[label] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": true_counts[label],
        }

    result: list[dict[str, object]] = []
    for average in AVERAGES:
        if average == "macro":
            precision = safe_divide(
                sum(per_class[label]["precision"] for label in labels),
                len(labels),
            )
            recall = safe_divide(
                sum(per_class[label]["recall"] for label in labels),
                len(labels),
            )
            f1 = safe_divide(
                sum(per_class[label]["f1"] for label in labels),
                len(labels),
            )
        elif average == "weighted":
            precision = safe_divide(
                sum(
                    per_class[label]["precision"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            recall = safe_divide(
                sum(
                    per_class[label]["recall"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            f1 = safe_divide(
                sum(
                    per_class[label]["f1"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
        else:  # micro
            micro_tp = correct
            micro_fp = n_samples - correct
            micro_fn = n_samples - correct
            precision = safe_divide(micro_tp, micro_tp + micro_fp)
            recall = safe_divide(micro_tp, micro_tp + micro_fn)
            f1 = safe_divide(2 * precision * recall, precision + recall)

        result.append(
            {
                "condition": condition,
                "source_file": source_file,
                "level": level_name,
                "average": average,
                "n_samples": n_samples,
                "n_classes_union": len(labels),
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": mcc,
            }
        )
    return result


def calculate_binary_mcc(tp: int, fp: int, fn: int, tn: int) -> float:
    numerator = tp * tn - fp * fn
    denominator = math.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    )
    return safe_divide(numerator, denominator)


def calculate_each_type_metrics(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    condition: str,
    source_file: str,
) -> list[dict[str, object]]:
    labels = sorted_labels(y_true, y_pred)
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive = Counter(
        true for true, pred in zip(y_true, y_pred) if true == pred
    )

    result: list[dict[str, object]] = []
    for label in labels:
        tp = true_positive[label]
        fp = predicted_counts[label] - tp
        fn = true_counts[label] - tp
        tn = n_samples - tp - fp - fn
        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)

        result.append(
            {
                "condition": condition,
                "source_file": source_file,
                "type": label,
                "is_true_target_type": label in true_counts,
                "n_samples": n_samples,
                "true_support": tp + fn,
                "predicted_count": tp + fp,
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "tn": tn,
                "accuracy": safe_divide(tp + tn, n_samples),
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": calculate_binary_mcc(tp, fp, fn, tn),
            }
        )

    result.sort(
        key=lambda row: (
            not bool(row["is_true_target_type"]),
            -int(row["true_support"]),
            str(row["type"]).casefold(),
        )
    )
    return result


def rounded_row(row: dict[str, object]) -> dict[str, object]:
    result = dict(row)
    for column in METRIC_COLUMNS:
        if column in result:
            result[column] = round(float(result[column]), 6)
    return result


def save_csv(
    rows: Sequence[dict[str, object]],
    output_path: Path,
    fieldnames: Sequence[str],
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rounded_row(row) for row in rows)


def process_result_file(
    result_path: Path,
    condition: str,
    direct_labels: dict[str, tuple[str, str]],
    base_labels: dict[str, tuple[str, str]],
    mapped_output_dir: Path,
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, object],
    list[dict[str, object]],
    list[dict[str, object]],
]:
    fieldnames, rows = read_dict_rows(result_path)
    id_column = resolve_column(
        fieldnames,
        ("seqid", "testid", "id", "sequenceid"),
        "seq_id",
        result_path,
    )
    arg_column = resolve_column(
        fieldnames,
        ("arg", "argscore", "argprobability"),
        "ARG score",
        result_path,
    )
    category_column = resolve_column(
        fieldnames,
        ("pred", "prediction", "predictedcategory", "category"),
        "pred",
        result_path,
    )
    assert id_column is not None
    assert arg_column is not None
    assert category_column is not None

    seen_ids: set[str] = set()
    y_true_arg: list[str] = []
    y_pred_arg: list[str] = []
    y_true: list[str] = []
    y_pred: list[str] = []
    mapped_rows: list[dict[str, object]] = []
    join_counter: Counter[str] = Counter()
    mapping_counter: Counter[tuple[str, str, str, str]] = Counter()

    unmatched_examples: list[str] = []
    for row_number, row in enumerate(rows, start=2):
        test_id = clean_text(row.get(id_column, ""))
        if not test_id:
            raise ValueError(
                f"{result_path.name} 第 {row_number} 行 test_id 为空。"
            )
        if test_id in seen_ids:
            raise ValueError(
                f"{result_path.name} 存在重复 test_id：{test_id!r}"
            )
        seen_ids.add(test_id)

        true_label, join_mode = resolve_true_label(
            test_id, direct_labels, base_labels
        )
        join_counter[join_mode] += 1
        if true_label is None:
            if len(unmatched_examples) < 10:
                unmatched_examples.append(test_id)
            continue

        arg_score_text = clean_text(row.get(arg_column, ""))
        try:
            arg_score = float(arg_score_text)
        except ValueError as error:
            raise ValueError(
                f"{result_path.name} 第 {row_number} 行 ARG 概率无法解析："
                f"{arg_score_text!r}"
            ) from error
        if not math.isfinite(arg_score) or not 0.0 <= arg_score <= 1.0:
            raise ValueError(
                f"{result_path.name} 第 {row_number} 行 ARG 概率超出 [0, 1]："
                f"{arg_score_text!r}"
            )
        arg_prediction = "ARG" if arg_score >= ARG_THRESHOLD else "nonARG"
        raw_category = clean_text(row.get(category_column, ""))
        predicted_type, mapping_status, mapping_reason = map_plmarg_prediction(
            arg_prediction, raw_category
        )
        true_type, true_subtype = true_label

        category_for_audit = raw_category if raw_category else "<blank>"
        mapping_counter[
            (
                category_for_audit,
                predicted_type,
                mapping_status,
                mapping_reason,
            )
        ] += 1

        y_true_arg.append(
            "nonARG" if true_type.casefold() == "nonarg" else "ARG"
        )
        y_pred_arg.append(arg_prediction)
        y_true.append(true_type)
        y_pred.append(predicted_type)
        mapped_rows.append(
            {
                "condition": condition,
                "source_file": result_path.name,
                "test_id": test_id,
                "base_id": strip_fragment_suffix(test_id),
                "label_join_mode": join_mode,
                "true_type": true_type,
                "true_subtype": true_subtype,
                "ARG_prediction": arg_prediction,
                "raw_pred": raw_category,
                "predicted_type": predicted_type,
                "mapping_status": mapping_status,
                "mapping_reason": mapping_reason,
                "ARG_score": arg_score_text,
            }
        )

    if join_counter["unmatched"]:
        raise ValueError(
            f"{result_path.name} 有 {join_counter['unmatched']} 个 ID 无法在结构表中找到。"
            "为防止用部分交集产生偏差，脚本已停止。示例："
            + ", ".join(unmatched_examples)
        )

    arg_overall_rows = calculate_overall_metrics(
        y_true_arg,
        y_pred_arg,
        "ARG_nonARG",
        condition,
        result_path.name,
    )
    type_overall_rows = calculate_overall_metrics(
        y_true,
        y_pred,
        "type",
        condition,
        result_path.name,
    )
    each_type_rows = calculate_each_type_metrics(
        y_true, y_pred, condition, result_path.name
    )

    mapped_columns = (
        "condition",
        "source_file",
        "test_id",
        "base_id",
        "label_join_mode",
        "true_type",
        "true_subtype",
        "ARG_prediction",
        "raw_pred",
        "predicted_type",
        "mapping_status",
        "mapping_reason",
        "ARG_score",
    )
    save_csv(
        mapped_rows,
        mapped_output_dir / f"{result_path.stem}_mapped_type_predictions.csv",
        mapped_columns,
    )

    mapping_rows: list[dict[str, object]] = []
    unmapped_rows: list[dict[str, object]] = []
    for (category, target, status, reason), count in sorted(
        mapping_counter.items(),
        key=lambda item: (
            item[0][0].casefold(),
            item[0][1].casefold(),
        ),
    ):
        audit_row = {
            "condition": condition,
            "source_file": result_path.name,
            "PLMARG_pred": category,
            "mapped_target_type": target,
            "mapping_status": status,
            "mapping_reason": reason,
            "prediction_count": count,
        }
        mapping_rows.append(audit_row)
        if target == UNMAPPED_LABEL:
            unmapped_rows.append(audit_row)

    audit_row = {
        "condition": condition,
        "source_file": result_path.name,
        "ARG_threshold": ARG_THRESHOLD,
        "result_rows": len(rows),
        "unique_result_ids": len(seen_ids),
        "matched_rows": len(y_true),
        "unmatched_rows": join_counter["unmatched"],
        "direct_id_matches": join_counter["direct_id"],
        "fragment_to_full_id_matches": join_counter["fragment_to_full_id"],
        "full_id_to_expanded_base_matches": join_counter[
            "full_id_to_expanded_base"
        ],
        "fragment_to_expanded_base_matches": join_counter[
            "fragment_to_expanded_base"
        ],
        "unmapped_prediction_rows": sum(
            count
            for (_, target, _, _), count in mapping_counter.items()
            if target == UNMAPPED_LABEL
        ),
        "true_type_count": len(set(y_true)),
        "prediction_type_count": len(set(y_pred)),
        "union_type_count": len(set(y_true) | set(y_pred)),
    }
    return (
        arg_overall_rows,
        type_overall_rows,
        each_type_rows,
        audit_row,
        mapping_rows,
        unmapped_rows,
    )


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.expanduser().resolve()
    if not input_dir.is_dir():
        raise NotADirectoryError(f"输入目录不存在：{input_dir}")

    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else input_dir / OUTPUT_DIR_NAME
    )
    label_path = find_label_file(input_dir, args.labels)

    missing_files = [
        filename
        for _, filename in INPUT_FILES
        if not (input_dir / filename).is_file()
    ]
    if missing_files:
        raise FileNotFoundError(
            "以下 PLMARG 输入文件不存在：\n- "
            + "\n- ".join(missing_files)
        )

    direct_labels, base_labels, label_metadata = load_label_indexes(label_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    mapped_output_dir = output_dir / "mapped_predictions"

    all_arg_overall: list[dict[str, object]] = []
    all_type_overall: list[dict[str, object]] = []
    all_each_type: list[dict[str, object]] = []
    all_audit: list[dict[str, object]] = []
    all_mapping: list[dict[str, object]] = []
    all_unmapped: list[dict[str, object]] = []

    print(f"结构表：{label_path}")
    print(
        "结构表记录数 = {label_rows}，唯一 ID = {unique_label_ids}，"
        "原始 ID = {unique_base_ids}".format(**label_metadata)
    )

    for condition, filename in INPUT_FILES:
        result_path = input_dir / filename
        (
            arg_overall_rows,
            type_overall_rows,
            each_type_rows,
            audit_row,
            mapping_rows,
            unmapped_rows,
        ) = process_result_file(
            result_path,
            condition,
            direct_labels,
            base_labels,
            mapped_output_dir,
        )
        audit_row["label_file"] = label_path.name
        audit_row.update(label_metadata)

        all_arg_overall.extend(arg_overall_rows)
        all_type_overall.extend(type_overall_rows)
        all_each_type.extend(each_type_rows)
        all_audit.append(audit_row)
        all_mapping.extend(mapping_rows)
        all_unmapped.extend(unmapped_rows)
        print(
            f"已完成 {condition}: {filename}，记录数 = "
            f"{audit_row['matched_rows']}"
        )

    overall_columns = (
        "condition",
        "source_file",
        "level",
        "average",
        "n_samples",
        "n_classes_union",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )
    each_type_columns = (
        "condition",
        "source_file",
        "type",
        "is_true_target_type",
        "n_samples",
        "true_support",
        "predicted_count",
        "tp",
        "fp",
        "fn",
        "tn",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )
    audit_columns = (
        "condition",
        "source_file",
        "ARG_threshold",
        "label_file",
        "result_rows",
        "unique_result_ids",
        "matched_rows",
        "unmatched_rows",
        "direct_id_matches",
        "fragment_to_full_id_matches",
        "full_id_to_expanded_base_matches",
        "fragment_to_expanded_base_matches",
        "unmapped_prediction_rows",
        "true_type_count",
        "prediction_type_count",
        "union_type_count",
        "label_rows",
        "unique_label_ids",
        "unique_base_ids",
        "ids_with_fragment_suffix",
    )
    mapping_columns = (
        "condition",
        "source_file",
        "PLMARG_pred",
        "mapped_target_type",
        "mapping_status",
        "mapping_reason",
        "prediction_count",
    )

    save_csv(
        all_arg_overall + all_type_overall,
        output_dir / "00_all_levels_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_arg_overall,
        output_dir / "01_ARG_nonARG_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_type_overall,
        output_dir / "02_type_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_each_type,
        output_dir / "03_each_type_one_vs_rest_five_metrics.csv",
        each_type_columns,
    )
    save_csv(
        all_mapping,
        output_dir / "04_PLMARG_to_ARGScope_type_mapping_used.csv",
        mapping_columns,
    )
    save_csv(
        all_unmapped,
        output_dir / "05_unmapped_PLMARG_category_counts.csv",
        mapping_columns,
    )
    save_csv(
        all_audit,
        output_dir / "06_ID_and_label_join_audit.csv",
        audit_columns,
    )

    print("\n全部计算完成。")
    print(f"结果目录：{output_dir}")
    print("ARG/nonARG 指标：01_ARG_nonARG_overall_five_metrics.csv")
    print("Type 总体指标：02_type_overall_five_metrics.csv")
    print("逐 Type 指标：03_each_type_one_vs_rest_five_metrics.csv")


if __name__ == "__main__":
    main()
