#!/usr/bin/env python3
"""Paired, ARG/nonARG-stratified parent bootstrap of saved fragment predictions.

One sampled parent contributes all five fragments. The same parent weights are
used for both modalities, all completeness conditions and both label levels.
Only inference outputs are read; nothing is retrained or threshold-tuned.
"""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, matthews_corrcoef

ROOT=Path(__file__).resolve().parent
APP=ROOT.parent.parent
OUT=ROOT/'data'
B=2000
SEED=20260919
METRICS=['Accuracy','Precision','Recall','F1','MCC']
SOURCES={}


def read(path):
    SOURCES[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    return pd.read_csv(path)


def score_counts(y,p,w,k):
    """Exact global ACC/MCC and weighted P/R/F1 from weighted confusion margins."""
    support=np.bincount(y,weights=w,minlength=k)
    predicted=np.bincount(p,weights=w,minlength=k)
    correct=y==p
    tp=np.bincount(y[correct],weights=w[correct],minlength=k)
    total=support.sum()
    trace=tp.sum()
    precision=np.divide(tp,predicted,out=np.zeros(k),where=predicted>0)
    f1=np.divide(2*tp,support+predicted,out=np.zeros(k),where=(support+predicted)>0)
    cov=total*trace-np.dot(support,predicted)
    denominator=np.sqrt(max(0,total**2-np.dot(support,support))*max(0,total**2-np.dot(predicted,predicted)))
    return np.array([trace/total,np.dot(support,precision)/total,trace/total,
                     np.dot(support,f1)/total,cov/denominator if denominator>0 else 0.])


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    full=read(APP/'protein/100%_test_sequence_predictions.csv').set_index('parent_sequence_id')
    full=full.sort_index()
    assert full.index.is_unique and len(full)==4574
    parents=full.index
    arg=np.flatnonzero(full.true_ARG.eq(1))
    nonarg=np.flatnonzero(full.true_ARG.eq(0))
    assert len(arg)==len(nonarg)==2287
    rng=np.random.default_rng(SEED)
    weights=np.zeros((B,len(parents)),dtype=np.uint16)
    weights[:,arg]=rng.multinomial(len(arg),np.full(len(arg),1/len(arg)),size=B)
    weights[:,nonarg]=rng.multinomial(len(nonarg),np.full(len(nonarg),1/len(nonarg)),size=B)
    assert np.all(weights[:,arg].sum(axis=1)==2287)
    assert np.all(weights[:,nonarg].sum(axis=1)==2287)
    plan_hash=hashlib.sha256(weights.tobytes()).hexdigest()
    full[['true_ARG','true_type','true_subtype']].to_csv(OUT/'ordered_test_parents.csv',encoding='utf-8-sig')
    results=[]
    summaries=[]
    checks=[]
    for mod in ['protein','dna']:
        for pct in [60,70,80,90]:
            start=time.monotonic()
            df=read(APP/mod/f'{pct}%_fragment_predictions_test.csv')
            assert len(df)==22870 and df.sequence_id.is_unique
            assert df.parent_sequence_id.nunique()==4574
            assert df.groupby('parent_sequence_id').size().eq(5).all()
            assert df.groupby('parent_sequence_id').replicate.apply(lambda v:set(v)=={1,2,3,4,5}).all()
            assert df.completeness_percent.eq(pct).all()
            parent_index=parents.get_indexer(df.parent_sequence_id)
            assert np.min(parent_index)>=0
            for col in ['true_ARG','true_type','true_subtype']:
                assert np.array_equal(df[col].to_numpy(),full.iloc[parent_index][col].to_numpy())
            for level in ['Type','Subtype']:
                y_name,p_name=f'true_{level.lower()}',f'predicted_{level.lower()}'
                assert df[[y_name,p_name]].notna().all().all()
                labels=sorted(set(df[y_name])|set(df[p_name]))
                lookup={v:i for i,v in enumerate(labels)}
                y=df[y_name].map(lookup).to_numpy()
                p=df[p_name].map(lookup).to_numpy()
                k=len(labels)
                point=score_counts(y,p,np.ones(len(df)),k)
                pr,re,f1,_=precision_recall_fscore_support(y,p,average='weighted',zero_division=0)
                sklearn_point=np.array([accuracy_score(y,p),pr,re,f1,matthews_corrcoef(y,p)])
                assert np.allclose(point,sklearn_point,atol=1e-12)
                boot=np.empty((B,5))
                for b in range(B):
                    fragment_weights=weights[b,parent_index]
                    assert fragment_weights.sum()==22870
                    boot[b]=score_counts(y,p,fragment_weights,k)
                # Independent weighted sklearn checks on actual bootstrap replicates.
                for b in [0,499,1999]:
                    fw=weights[b,parent_index]
                    bp,br,bf,_=precision_recall_fscore_support(y,p,average='weighted',sample_weight=fw,zero_division=0)
                    direct=np.array([accuracy_score(y,p,sample_weight=fw),bp,br,bf,matthews_corrcoef(y,p,sample_weight=fw)])
                    error=float(np.max(np.abs(boot[b]-direct)))
                    assert error<1e-10
                    checks.append(dict(Modality=mod,Completeness=pct,Level=level,Replicate=b+1,Max_abs_error=error))
                part=pd.DataFrame(boot,columns=METRICS)
                part.insert(0,'Bootstrap',np.arange(1,B+1))
                part.insert(0,'Level',level)
                part.insert(0,'Completeness',pct)
                part.insert(0,'Modality',mod)
                results.append(part)
                for j,metric in enumerate(METRICS):
                    summaries.append(dict(Modality=mod,Completeness=pct,Level=level,Metric=metric,
                                          Point_estimate=point[j],Bootstrap_mean=boot[:,j].mean(),
                                          CI_low=np.quantile(boot[:,j],.025),CI_high=np.quantile(boot[:,j],.975),
                                          Bootstrap_SD=boot[:,j].std(ddof=1),N_bootstrap=B,N_parents=4574,
                                          N_fragments=22870,Average='weighted' if metric in ['Precision','Recall','F1'] else 'global',
                                          Population='all_test_including_nonARG',Resampling_unit='parent_with_all_5_fragments',
                                          Strata='true_ARG/nonARG',Pairing='same_weights_across_modalities_conditions_levels'))
            print(f'{mod} {pct}%: both levels completed ({time.monotonic()-start:.1f}s)',flush=True)
    pd.concat(results,ignore_index=True).to_csv(OUT/'ARGScope_parent_bootstrap_five_metrics.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    summary=pd.DataFrame(summaries)
    summary.to_csv(OUT/'ARGScope_point_and_95CI.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    pd.DataFrame(checks).to_csv(OUT/'independent_sklearn_checks.csv',index=False,encoding='utf-8-sig')
    old=read(ROOT.parent/'data/ARGScope_all_five_metrics.csv')
    for (mod,pct,level),part in summary.groupby(['Modality','Completeness','Level']):
        oldrow=old[(old.Modality==mod)&(old.Completeness==pct)&(old.Level==level)&(old.Average=='weighted')].iloc[0]
        for row in part.itertuples():assert abs(row.Point_estimate-oldrow[row.Metric])<1e-10
    plan=dict(seed=SEED,bootstrap_repeats=B,parents=4574,ARG_parents=2287,nonARG_parents=2287,
              fragments_per_parent=5,strata='ARG/nonARG',parent_weights_sha256=plan_hash,
              numpy_version=np.__version__,unit='parent sequence',paired_across_all_conditions=True,
              filtering='none; retain zero-performing Types and all test parents',
              interval='2.5th and 97.5th bootstrap percentiles; conditional on model and fixed ARG prevalence',
              scope='test-sampling uncertainty only; not retraining uncertainty or homology-cluster uncertainty')
    (OUT/'bootstrap_plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
    (OUT/'source_hashes.json').write_text(json.dumps(SOURCES,indent=2),encoding='utf-8')
    for path,h in SOURCES.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
    print('PASS: 2000 paired parent bootstrap replicates; all point estimates match previous overall metrics.')


if __name__=='__main__':main()
