"""Check editable SVG text, exact raster correspondence, resolution and packaging."""
from pathlib import Path
import json
import zipfile
import xml.etree.ElementTree as ET
from PIL import Image, ImageChops

out = Path(__file__).resolve().parent / 'outputs' / 'argscope_method_diagrams_20260926'
ns = {'s': 'http://www.w3.org/2000/svg'}
checks = {
    'ARGScope_overview': ['Paired inputs', 'ARG + non-ARG', 'Standardization', 'OR', 'Fixed subtype mapping'],
    'ARGScope_AA_NT_training': ['Binary KD: OFF (selected weight = 0)', 'Binary KD: all samples',
                               'Classifier-head anchoring', '1280 → 1536 → 1024', '768 → 1024',
                               'Non-ARG → separate center', 'Teacher head initialization']
}
results = []
for name, tokens in checks.items():
    svg = ET.parse(out / (name+'.svg'))
    text = ' '.join(e.text or '' for e in svg.findall('.//s:text', ns))
    assert all(t in text for t in tokens)
    assert not svg.findall('.//s:image', ns), 'SVG must remain vector, not a raster wrapper'
    png = Image.open(out / (name+'.png')).convert('RGB')
    tif = Image.open(out / (name+'_A4_300DPI.tif'))
    dpi = [float(v) for v in tif.info['dpi']]
    assert all(abs(v-300)<.01 for v in dpi)
    assert ImageChops.difference(png, tif.convert('RGB')).getbbox() is None
    results.append({'figure': name, 'size': list(tif.size), 'dpi': dpi, 'identical_png_tiff_pixels': True,
                    'editable_text_elements': len(svg.findall('.//s:text', ns))})
provenance = json.loads((out/'figure_provenance.json').read_text(encoding='utf-8'))
assert all(c['text_overflows']==0 for c in provenance['checks'])
(out/'final_QA.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
package = out/'ARGScope_two_method_figures.zip'
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for n in checks:
        for suffix in ['.svg', '.png', '_A4_300DPI.tif']:
            z.write(out/(n+suffix),arcname=n+suffix)
    for name in ['README.md','figure_provenance.json','render_validation.json','final_QA.json']:
        z.write(out/name,arcname=name)
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
print(json.dumps({'checks':results,'zip':str(package),'package_bytes':package.stat().st_size}))
