"""Source-coordinate alignment and vector tracing for the colors-only redraw."""
import xml.etree.ElementTree as ET
from pathlib import Path
import math, re, zlib, base64
from urllib.parse import quote
import numpy as np
from PIL import Image

SOURCE=Path(r'C:\Users\JIEPAN~1\AppData\Local\Temp\codex-clipboard-c936a1f6-2610-4280-a05f-ad308012a98e.png')

def trace_rings(mask):
    """Trace oriented pixel boundaries; holes retain their opposite winding."""
    hh,ww=mask.shape
    edges={}
    for y,x in zip(*np.where(mask)):
        for ok,a,b in [(y==0 or not mask[y-1,x],(x,y),(x+1,y)),
                        (x==ww-1 or not mask[y,x+1],(x+1,y),(x+1,y+1)),
                        (y==hh-1 or not mask[y+1,x],(x+1,y+1),(x,y+1)),
                        (x==0 or not mask[y,x-1],(x,y+1),(x,y))]:
            if ok:edges.setdefault(a,[]).append(b)
    rings=[]
    while edges:
        start=next(iter(edges));p=start;ring=[]
        for _ in range(100000):
            ring.append(p)
            q=edges[p].pop()
            if not edges[p]:del edges[p]
            p=q
            if p==start:break
        if len(ring)>=4:
            # Remove collinear grid steps without shifting the traced silhouette.
            keep=[]
            for i,p in enumerate(ring):
                a=ring[i-1];b=ring[(i+1)%len(ring)]
                if (p[0]-a[0])*(b[1]-p[1])!=(p[1]-a[1])*(b[0]-p[0]):keep.append(p)
            if len(keep)>2:rings.append(keep)
    return rings

def encoded_shape(name,foreground,w=100,h=100):
    shape=ET.Element('shape',name=name,w=str(w),h=str(h),aspect='variable',strokewidth='inherit')
    ET.SubElement(shape,'connections')
    shape.append(foreground)
    raw=quote(ET.tostring(shape,encoding='unicode'),safe="~()*!.'-").encode()
    z=zlib.compressobj(wbits=-15)
    return 'shape=stencil('+base64.b64encode(z.compress(raw)+z.flush()).decode()+');'

def traced_glyph(name,bbox,role='blue'):
    crop=Image.open(SOURCE).convert('RGB').crop(bbox)
    # Supersampling gives smooth contour positions without introducing a bitmap
    # into the draw.io document. Very pale panel tints are treated as background.
    up=3
    im=np.asarray(crop.resize((crop.width*up,crop.height*up),Image.Resampling.BICUBIC)).astype(float)
    lo=im.min(axis=2);hi=im.max(axis=2);sat=hi-lo
    # Molecular illustrations are colored; remove the white/off-white canvas.
    lum=.2126*im[:,:,0]+.7152*im[:,:,1]+.0722*im[:,:,2]
    base=((sat>25)&(lum<210))|((lum<150)&(sat<=25))
    if 'network' in name:
        row_background=np.median(lum,axis=1,keepdims=True)
        base=(lum<row_background-7)|(lum<145)
    dark,light=('#9673A6','#E1D5E7') if role=='purple' else ('#6C8EBF','#DAE8FC')
    masks=[(base,dark),(base&(lum>148),light)]
    fg=ET.Element('foreground')
    for mask,color in masks:
        ET.SubElement(fg,'fillcolor',color=color)
        path=ET.SubElement(fg,'path')
        for ring in trace_rings(mask):
            x,y=ring[0];ET.SubElement(path,'move',x=str(x/up),y=str(y/up))
            for x,y in ring[1:]:ET.SubElement(path,'line',x=str(x/up),y=str(y/up))
            ET.SubElement(path,'close')
        ET.SubElement(fg,'fill')
    return encoded_shape(name,fg,bbox[2]-bbox[0],bbox[3]-bbox[1])

def match_reference(root,boxes,manifest,model,S,out):
    cells={c.get('id'):c for c in root.findall('mxCell')}
    nodes={n['id']:n for n in manifest['nodes']}
    edges={e['id']:e for e in manifest['edges']}
    deleted=set()
    def descendants(id):
        found={id}
        changed=True
        while changed:
            changed=False
            for c in root.findall('mxCell'):
                if c.get('parent') in found and c.get('id') not in found:
                    found.add(c.get('id'));changed=True
        return found
    def delete(id):
        for d in descendants(id):
            if d in cells:root.remove(cells[d]);deleted.add(d)
    def style(id,**attrs):
        c=cells[id];st=c.get('style','')
        for k,v in attrs.items():
            st=re.sub(r'(?:(?<=;)|^)'+re.escape(k)+r'=[^;]*;', '',st)
            st+=f'{k}={v};'
        c.set('style',st)
    def setbox(id,x,y,w,h):
        boxes[id]=(x,y,w,h)
        if id in nodes:nodes[id]['box']=[x,y,w,h]
    def place_group(id,new):
        ox,oy,ow,oh=boxes[id];nx,ny,nw,nh=new
        kx,ky=nw/ow,nh/oh
        def point(p):return (nx+(p[0]-ox)*kx,ny+(p[1]-oy)*ky)
        for child in descendants(id):
            if child in boxes:
                x,y,w,h=boxes[child];xx,yy=point((x,y));setbox(child,xx,yy,w*kx,h*ky)
            if child in edges:edges[child]['points']=[point(p) for p in edges[child]['points']]
    def route(id,pts):
        c=cells[id]
        c.attrib.pop('source',None);c.attrib.pop('target',None)
        edges[id]['source']=edges[id]['target']=None
        edges[id]['points']=pts
    def addline(id,pts,color='#9673A6',dash=True,arrow=True,width=1.1,parent='A'):
        c=ET.SubElement(root,'mxCell',id=id,value='',style=f'edgeStyle=none;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;strokeColor={color};strokeWidth={width*S};endArrow={"block" if arrow else "none"};endSize={5*S};endFill=1;dashed={int(dash)};dashPattern=7 4;',edge='1',parent=parent)
        ET.SubElement(c,'mxGeometry',relative='1',attrib={'as':'geometry'})
        cells[id]=c
        e=dict(id=id,points=pts,parent=parent,source=None,target=None,kind='flow',curved=False)
        edges[id]=e;manifest['edges'].append(e)
    def addtext(id,value,bbox,size=14,parent='A',bold=False):
        x,y,w,h=bbox
        c=ET.SubElement(root,'mxCell',id=id,value=value,style=f'fillColor=none;strokeColor=none;whiteSpace=wrap;html=1;fontFamily=Arial Narrow;fontSize={size*S};fontColor=#000000;align=center;verticalAlign=middle;spacing=0;fontStyle={int(bold)};',vertex='1',parent=parent)
        ET.SubElement(c,'mxGeometry',attrib={'as':'geometry'})
        cells[id]=c;setbox(id,x,y,w,h)
        n=dict(id=id,value=value,box=[x,y,w,h],parent=parent,role='clear',container=False)
        nodes[id]=n;manifest['nodes'].append(n)
    def addcircle(id,cx,cy,r,role='blue',parent='A',label=''):
        addtext(id,label,(cx-r,cy-r,r*2,r*2),12,parent)
        f,st=('#E1D5E7','#9673A6') if role=='purple' else ('#DAE8FC','#6C8EBF')
        style(id,shape='ellipse',fillColor=f,strokeColor=st,strokeWidth=.85*S)
    def glyph(id,bbox,crop,role='blue'):
        for d in descendants(id)-{id}:
            if d in cells:root.remove(cells[d]);deleted.add(d)
        cells[id].set('style',traced_glyph(id,crop,role)+'fillColor=#DAE8FC;strokeColor=none;')
        setbox(id,*bbox)

    # Convert the initial proportional grid to the exact source-image canvas.
    kx,ky=1160/1200,871/900
    for id,(x,y,w,h) in list(boxes.items()):setbox(id,x*kx,y*ky,w*kx,h*ky)
    for e in manifest['edges']:e['points']=[(x*kx,y*ky) for x,y in e['points']]
    model.set('pageWidth',str(1160*S));model.set('pageHeight',str(871*S))
    for id,c in cells.items():
        if c.get('vertex')=='1':
            style(id,fontFamily='Arial Narrow')
            # Match the small corner radius in the supplied image.
            if 'rounded=1;' in c.get('style',''):style(id,arcSize=5)

    # Exact anchors measured from the reference, retaining its irregular graph panel.
    for id,new in {
        'paired':(15,59,184,289),'shared':(448,90,270,173),
        'teacher':(724,204,116,170),'transfer':(852,144,100,200),
        'student-aa':(1004,66,142,157),'student-nt':(1004,290,142,154),
        'graph-learning':(100,355,700,245),
        'infer-aa-input':(27,655,211,87),'infer-nt-input':(27,755,211,96),
        'infer-student-aa':(603,646,194,89),'infer-student-nt':(603,751,194,100),
        'annotation':(953,647,187,149),
    }.items():place_group(id,new)
    # The source's graph panel has a notch around the teacher, not a rectangle.
    fg=ET.Element('foreground');p=ET.SubElement(fg,'path')
    for cmd,args in [('move',(6,0)),('line',(602,0)),('quad',(608,0,608,6)),
                     ('line',(608,25)),('quad',(608,31,614,31)),('line',(694,31)),
                     ('quad',(700,31,700,37)),('line',(700,239)),('quad',(700,245,694,245)),
                     ('line',(6,245)),('quad',(0,245,0,239)),('line',(0,6)),('quad',(0,0,6,0))]:
        keys=['x1','y1','x2','y2'] if cmd=='quad' else ['x','y']
        ET.SubElement(p,cmd,dict(zip(keys,map(str,args))))
    ET.SubElement(p,'close');ET.SubElement(fg,'fillstroke')
    style('graph-learning',shape='stencil('+encoded_shape('notch',fg,700,245).split('stencil(')[1].split(');')[0]+')',rounded=0)

    # Box geometry and labels: retain the reference's line breaks.
    for id,new in {
        'aa-encoder':(224,102,113,88),'nt-encoder':(224,239,116,89),
        'aa-encoder-title':(229,129,105,22),'aa-encoder-sub':(226,151,111,20),
        'nt-encoder-title':(230,268,105,22),'nt-encoder-sub':(226,289,112,20),
        'aa-rep':(364,97,44,74),'nt-rep':(365,250,44,56),
        'aa-rep-label':(329,57,104,36),'nt-rep-label':(334,211,105,34),
        'shared-title':(456,98,255,26),'projection':(454,137,96,126),
        'gate':(563,158,83,90),'gate-label':(567,167,74,36),
        'gate-sigma':(589,208,31,31),'fused-title':(645,128,78,37),
        'fused':(671,170,32,68),'transfer-title':(844,95,111,39),
        'paired-title':(25,68,170,23),'paired-protein-label':(33,107,156,22),
        'paired-nt-label':(33,241,160,22),
        'A-letter':(14,3,30,35),'A-title':(67,6,114,34),'A-bar':(181,8,13,28),
        'A-subtitle':(200,11,567,29),
        'B-letter':(15,616,34,34),'B-title':(68,619,126,31),'B-bar':(194,621,14,28),
        'B-subtitle':(215,622,520,30),
        'infer-aa-encoder':(291,662,112,72),'infer-nt-encoder':(291,766,112,73),
        'infer-aa-encoder-title':(299,681,97,21),'infer-aa-encoder-sub':(294,701,106,19),
        'infer-nt-encoder-title':(297,782,103,21),'infer-nt-encoder-sub':(293,803,109,20),
        'infer-aa-embedding-label':(444,644,86,34),'infer-nt-embedding-label':(441,748,89,34),
        'infer-aa-embedding':(459,679,46,40),'infer-nt-embedding':(459,781,46,45),
        'annotation-title':(964,651,164,24),
        'annotation-0':(967,678,161,30),'annotation-1':(967,715,161,29),'annotation-2':(967,756,161,29),
        'legend-forward-label':(946,807,195,21),'legend-supervision-label':(946,826,201,21),
        'construction':(110,387,245,203),'knn':(362,387,222,203),'gat':(592,387,197,203),
    }.items():
        if id in ['aa-rep','nt-rep','fused','infer-aa-embedding','infer-nt-embedding','projection','gate','construction','knn','gat']:
            place_group(id,new)
        else:setbox(id,*new)
    # Original font metrics are condensed. Titles fit on one line as in the image.
    for id,size in {'paired-title':17,'shared-title':18,'A-title':29,'A-subtitle':20,'B-title':29,'B-subtitle':20,
                    'gate-label':13.5,'construction-title':13,'knn-title':13,'gat-title':13,
                    'legend-supervision-label':14,'legend-forward-label':14}.items():style(id,fontSize=size*S)
    for id in ['aa-encoder-sub','nt-encoder-sub','infer-aa-encoder-sub','infer-nt-encoder-sub']:style(id,fontSize=13*S)
    # Restore all ellipsis locations and count exactly; projection input has none.
    delete('projection-in-dots')
    for id,new in {'aa-rep-dots':(365,173,44,16),'nt-rep-dots':(365,308,44,16),
                   'projection-out-dots':(514,242,27,16),'fused-dots':(670,238,34,16),
                   'infer-aa-embedding-dots':(459,719,46,16),'infer-nt-embedding-dots':(459,826,46,16)}.items():setbox(id,*new)

    # Trace the actual source glyphs into native vector paths, preserving their
    # silhouettes and orientation rather than substituting a generic icon.
    glyph('paired-protein-glyph',(27,130,39,81),(27,130,66,211))
    glyph('paired-nt-glyph',(35,265,30,74),(35,265,65,339))
    glyph('infer-aa-input-glyph',(47,682,42,61),(47,682,89,743))
    glyph('infer-nt-input-glyph',(55,781,31,66),(55,781,86,847))
    # Preserve the literal network silhouettes, including the central overlapping
    # lobes and uneven attention arrows in this supplied raster.
    for id,crop in {
        'teacher-network':(750,211,812,279),
        'student-aa-network':(1033,122,1123,201),
        'student-nt-network':(1033,347,1123,425),
        'infer-student-aa-network':(657,684,732,733),
        'infer-student-nt-network':(657,791,732,842),
    }.items():glyph(id,(crop[0],crop[1],crop[2]-crop[0],crop[3]-crop[1]),crop,'purple')
    # The four sample clusters have different point counts and tilted outlines.
    # Retain that exact composition as one native vector icon, rather than impose
    # repeated circles or a newly regularized graph.
    for id in [f'cluster-{i}' for i in range(4)]+[f'cluster-{i}-sample{j}' for i in range(4) for j in range(6)]+[f'cluster-{i}-centroid' for i in range(4)]+['cluster-construction-arrow']:
        delete(id)
    addtext('source-cluster-glyph','',(122,417,139,116),parent='construction')
    glyph('source-cluster-glyph',(122,417,139,116),(122,417,261,533),'blue')
    for prefix in ('knn-solid-','knn-nonedge-','knn-p','gat-attention-','gat-p'):
        for id in list(cells):
            if id.startswith(prefix):delete(id)
    addtext('source-knn-glyph','',(380,419,135,113),parent='knn')
    glyph('source-knn-glyph',(380,419,135,113),(380,419,515,532),'blue')
    addtext('source-gat-glyph','',(606,419,137,116),parent='gat')
    glyph('source-gat-glyph',(606,419,137,116),(606,419,743,535),'purple')

    # Separate per-objective dashed routes from the attached raster. There are
    # five visible objective-to-student arrows, with no blue route into NT.
    for id in ['teacher-supervision-bus','teacher-to-transfer','student-supervision-bus',
               'teacher-to-prediction','teacher-to-feature','teacher-to-prototype',
               'prediction-to-bus','feature-to-bus','prototype-to-bus','supervision-AA','supervision-NT',
               'supervision-junction-0','supervision-junction-1','supervision-junction-2']:delete(id)
    for id,new in {'transfer-prediction':(863,151,83,55),'transfer-feature':(863,219,83,49),
                   'transfer-prototype':(863,282,83,51)}.items():setbox(id,*new)
    for id,pts in {
        'teacher-prediction':[(839,273),(843,273),(843,179),(863,179)],
        'teacher-feature':[(839,282),(848,282),(848,243),(863,243)],
        'teacher-prototype':[(839,290),(848,290),(848,309),(863,309)],
        'prediction-aa':[(945,177),(968,177),(968,122),(1003,117)],
        'prediction-nt':[(968,177),(968,378),(1003,378)],
        'feature-aa':[(945,243),(958,243),(958,223),(978,223),(978,159),(1003,154)],
        'prototype-aa':[(945,307),(985,307),(985,194),(1003,194)],
        'prototype-nt':[(985,307),(985,342),(1003,342)]}.items():addline(id,pts)

    # Native graph geometry and formula layout remain the same as the reference.
    route('panel-divider',[(13,613),(1148,613)])
    for id,pts in {
        'aa-input':[(199,146),(222,146)],'nt-input':[(199,285),(222,285)],
        'aa-encode':[(339,146),(360,146)],'nt-encode':[(340,283),(361,283)],
        'aa-project':[(413,137),(431,137),(431,185),(450,185)],
        'nt-project':[(414,282),(432,282),(432,217),(450,217)],
        'projection-gate':[(550,202),(560,202)],'gate-fused':[(648,202),(668,202)],
        'fused-teacher':[(720,137),(781,137),(781,200)],
        'gate-to-graph':[(604,248),(604,352)],
        'refinement-to-teacher':[(800,484),(819,484),(819,376)],
        'infer-aa-input-flow':[(240,697),(288,697)],'infer-nt-input-flow':[(240,800),(288,800)],
        'infer-aa-encode':[(406,697),(451,697)],'infer-nt-encode':[(406,799),(451,799)],
        'infer-aa-student':[(517,697),(600,697)],'infer-nt-student':[(517,799),(600,799)],
        'infer-aa-result':[(798,687),(873,687),(873,724)],
        'infer-nt-result':[(798,802),(873,802),(873,724)],
        'infer-annotation-flow':[(873,724),(950,724)],
        'annotation-arrow-0':[(1047,708),(1047,715)],'annotation-arrow-1':[(1047,744),(1047,756)],
        'legend-forward':[(875,817),(934,817)],'legend-supervision':[(875,837),(934,837)],
    }.items():route(id,pts)
    # Keep the original dashed group boundary behind the teacher, with no overlap.
    setbox('graph-title',252,361,445,23)
    style('graph-title',fontSize=17*S)
    for n in manifest['nodes']:
        if n['id'].startswith(('mean-','adj-','residual-formula')) and n['id'] not in deleted:
            style(n['id'],fontFamily='Times New Roman')
    # Exact figure has square-ish small corners and very light neutral panels.
    for id in ['paired','shared','graph-learning','construction','knn','gat','infer-aa-input','infer-nt-input','annotation']:
        style(id,fillColor='#F5F5F5',strokeWidth=.8*S)
    for id in ['A-letter','A-title','B-letter','B-title']:style(id,fontFamily='Arial')
    for id in ['paired-protein-seq','paired-nt-seq','infer-aa-input-seq','infer-nt-input-seq']:
        style(id,fontFamily='Consolas',fontSize=12.5*S)
        cells[id].set('value',cells[id].get('value').replace('•••','…'))

    # Reconstruct the simple circular glyphs on their original centers. This
    # preserves the source point counts while keeping curves clean and editable.
    delete('source-cluster-glyph')
    cluster_specs=[(151,450,58,55,-24,(150,452),[(155,433),(139,442),(134,452),(171,446),(152,466)]),
                   (219,445,62,50,-13,(219,444),[(214,428),(234,435),(204,444),(238,449),(215,458)]),
                   (157,506,64,52,-18,(157,508),[(156,495),(169,491),(141,503),(170,511),(149,522)]),
                   (228,504,62,50,15,(229,503),[(223,483),(239,486),(214,493),(247,506),(214,510),(233,518)])]
    for i,(cx,cy,w,h,angle,(sx,sy),points) in enumerate(cluster_specs):
        id=f'exact-cluster-{i}'
        addtext(id,'',(cx-w/2,cy-h/2,w,h),parent='construction')
        style(id,shape='ellipse',fillColor='#DAE8FC',fillOpacity=30,strokeColor='#6C8EBF',strokeOpacity=45,strokeWidth=.65*S,dashed=1,dashPattern='4 4',rotation=angle)
        for j,(x,y) in enumerate(points):addcircle(id+f'-sample{j}',x,y,3.7,parent='construction')
        sid=id+'-star';addtext(sid,'',(sx-7.5,sy-7.5,15,15),parent='construction')
        fg=ET.Element('foreground');p=ET.SubElement(fg,'path')
        for j in range(10):
            ang=-math.pi/2+j*math.pi/5;rr=50 if j%2==0 else 21
            ET.SubElement(p,'move' if j==0 else 'line',x=str(50+rr*math.cos(ang)),y=str(50+rr*math.sin(ang)))
        ET.SubElement(p,'close');ET.SubElement(fg,'fillstroke')
        cells[sid].set('style',encoded_shape(sid,fg)+'fillColor=#9673A6;strokeColor=#9673A6;strokeWidth=0.5;')
    addline('exact-cluster-arrow',[(179,465),(202,484)],color='#000000',dash=False,width=1,parent='construction')
    for prefix,coords,role,parent in [
        ('knn',[(451,434),(403,470),(491,470),(454,517),(395,517),(501,517)],'blue','knn'),
        ('gat',[(678,434),(629,470),(718,470),(679,517),(619,517),(729,517)],'purple','gat')]:
        for i,(x,y) in enumerate(coords):
            addcircle('exact-'+prefix+'-p'+str(i+1),x,y,11.3,role,parent,
                      f'P<sub>{i+1}</sub>' if prefix=='knn' or i<4 else '')

    place_group('prototype-legend',(267,430,75,63))
    setbox('legend-sample',274,442,6.5,6.5)
    addcircle('legend-sample-second',285,445,3.2,parent='prototype-legend')
    setbox('legend-sample-label',294,437,43,18)
    setbox('legend-centroid',274,462,13,14)
    setbox('legend-centroid-label',293,460,43,28)
    place_group('knn-legend',(512,438,67,63))
    setbox('legend-knn-text',531,442,44,26)
    setbox('legend-nonedge-text',531,474,45,19)
    route('legend-knn-edge',[(517,454),(529,454)])
    route('legend-nonedge',[(517,484),(529,484)])
    setbox('attention-label',742,423,46,31)
    for i in range(12):setbox('attention-scale-'+str(i),751,462+i*4.8,10,4.8)
    setbox('attention-high',766,456,26,18)
    setbox('attention-low',766,510,26,18)

    for id,bbox in {'formula-one':(122,536,223,50),'formula-two':(373,543,203,45),'formula-three':(602,547,186,41)}.items():place_group(id,bbox)
    for id,bbox in {
        'mean-lhs':(143,549,39,27),'mean-frac-top':(184,538,24,17),'mean-frac-bot':(184,555,24,24),
        'mean-sum':(210,548,27,28),'mean-sum-upper':(215,536,20,14),'mean-sum-lower':(207,570,32,14),
        'mean-term':(240,549,101,27),
        'adj-lhs':(377,552,37,25),'adj-brace':(408,545,14,39),'adj-one':(421,546,16,20),
        'adj-neighbors':(440,546,132,20),'adj-zero':(421,566,147,20),
        'residual-formula':(604,551,182,31),
    }.items():setbox(id,*bbox)
    route('mean-fraction',[(186,555),(208,555)])
    for id,size in {'mean-lhs':16,'mean-frac-top':14,'mean-frac-bot':14,'mean-sum':27,'mean-sum-upper':12,
                    'mean-sum-lower':10.5,'mean-term':16,'adj-lhs':14,'adj-neighbors':11.7,
                    'adj-one':12.5,'adj-zero':12.5,'residual-formula':14}.items():style(id,fontSize=size*S)
    setbox('mean-sum',210,546,27,25);style('mean-sum',fontSize=23*S)
    setbox('mean-sum-lower',207,573,32,11)
    style('legend-centroid',fillColor='#9673A6')

    # A native white canvas pins export bounds to the reference's 1160×871 ratio.
    addtext('export-canvas','',(0,0,1160,871),parent='1')
    style('export-canvas',fillColor='#FFFFFF',strokeColor='none')
    root.remove(cells['export-canvas']);root.insert(2,cells['export-canvas'])

    # Internal graph arrow tips end at node boundaries, as in the raster.
    for e in manifest['edges']:
        if e['id'] in deleted:continue
        if e.get('kind')=='graph':
            pts=e['points']
            if len(pts)>1:
                a,b=pts[0],pts[1];d=math.dist(a,b)
                if d>0:pts[0]=(a[0]+(b[0]-a[0])*10/d,a[1]+(b[1]-a[1])*10/d)
                a,b=pts[-1],pts[-2];d=math.dist(a,b)
                if d>0:pts[-1]=(a[0]+(b[0]-a[0])*10/d,a[1]+(b[1]-a[1])*10/d)

    # Regenerate relative geometry from final absolute source coordinates.
    for c in list(root.findall('mxCell')):
        id=c.get('id')
        if id in ('0','1') or id in deleted:continue
        parent=c.get('parent','1');px,py,*_=boxes[parent]
        g=c.find('mxGeometry')
        if c.get('vertex')=='1':
            x,y,w,h=boxes[id]
            for key,v in zip(['x','y','width','height'],[(x-px)*S,(y-py)*S,w*S,h*S]):g.set(key,str(round(v,5)))
        elif c.get('edge')=='1':
            for ch in list(g):g.remove(ch)
            e=edges[id];pts=list(e['points'])
            if not e.get('source'):
                x,y=pts.pop(0);ET.SubElement(g,'mxPoint',x=str((x-px)*S),y=str((y-py)*S),attrib={'as':'sourcePoint'})
            if not e.get('target'):
                x,y=pts.pop();ET.SubElement(g,'mxPoint',x=str((x-px)*S),y=str((y-py)*S),attrib={'as':'targetPoint'})
            if pts:
                arr=ET.SubElement(g,'Array',attrib={'as':'points'})
                for x,y in pts:ET.SubElement(arr,'mxPoint',x=str((x-px)*S),y=str((y-py)*S))
    manifest['nodes']=[n for n in manifest['nodes'] if n['id'] not in deleted]
    manifest['edges']=[e for e in manifest['edges'] if e['id'] not in deleted]
    manifest['source_canvas']=[1160,871]
    manifest['color_only_reference_alignment']=True
