# -*- coding: utf-8 -*-
"""
Batch-extract DNABERT-2 embeddings for DIAMOND candidate FASTA files.

This script reads FASTA sequences from:
    <RESULT_ROOT>\diamond0.5\candidate_reads
    <RESULT_ROOT>\diamond0.8\candidate_reads

It does NOT encode candidate_ids/*.txt, because those files contain IDs only.

Default result root:
    E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed\
    merged_fasta\DIAMOND_all_reads_separate_0.2_0.6_0.7_0.9_results

Default output:
    <RESULT_ROOT>\dnabert2_candidate_embeddings_pt\diamond0.5\
    <RESULT_ROOT>\dnabert2_candidate_embeddings_pt\diamond0.8\

Each PT file contains:
    sample_name
    threshold
    ids
    embeddings
    embedding_dim
    num_sequences
    source_fasta
    model_name
"""

from __future__ import annotations

import argparse
import csv
import gc
import os
import time
import traceback
from pathlib import Path

import torch
from transformers import AutoModel, AutoTokenizer


MODEL_NAME = "zhihan1996/DNABERT-2-117M"

DEFAULT_RESULT_ROOT = Path(
    r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed"
    r"\merged_fasta\DIAMOND_all_reads_separate_0.2_0.6_0.7_0.9_results"
)

DEFAULT_THRESHOLDS = ["0.5", "0.8"]
FASTA_PATTERN = "*_candidate_reads.fasta"

DEFAULT_BATCH_SIZE = 64
DEFAULT_MODEL_MAX_LENGTH = 128
DEFAULT_PRINT_EVERY = 5000

SAVE_FLOAT16 = True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract DNABERT-2 embeddings for DIAMOND candidate_reads FASTA "
            "files from diamond0.5 and diamond0.8."
        )
    )

    parser.add_argument(
        "--result-root",
        type=Path,
        default=DEFAULT_RESULT_ROOT,
    )
    parser.add_argument(
        "--thresholds",
        nargs="+",
        default=DEFAULT_THRESHOLDS,
        help="Example: --thresholds 0.5 0.8",
    )
    parser.add_argument(
        "--model-name",
        default=MODEL_NAME,
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=DEFAULT_BATCH_SIZE,
    )
    parser.add_argument(
        "--model-max-length",
        type=int,
        default=DEFAULT_MODEL_MAX_LENGTH,
    )
    parser.add_argument(
        "--print-every",
        type=int,
        default=DEFAULT_PRINT_EVERY,
    )
    parser.add_argument(
        "--max-records-per-fasta",
        type=int,
        default=None,
        help="Testing only. Omit for full encoding.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Recompute existing PT files.",
    )

    return parser.parse_args()


def normalize_threshold(value: str) -> str:
    text = str(value).strip().lower().replace("diamond", "")
    number = float(text)

    if not 0 < number <= 1:
        raise ValueError(
            f"Invalid threshold: {value}. Use values such as 0.2 or 0.9."
        )

    return f"{number:.1f}"


def setup_speed_options() -> None:
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True

        try:
            torch.set_float32_matmul_precision("high")
        except Exception:
            pass


def read_fasta_generator(fasta_file: Path):
    seq_id = None
    seq_lines: list[str] = []

    with fasta_file.open(
        "r",
        encoding="utf-8",
        errors="ignore",
    ) as handle:
        for line in handle:
            line = line.strip()

            if not line:
                continue

            if line.startswith(">"):
                if seq_id is not None:
                    yield seq_id, "".join(seq_lines).upper()

                seq_id = line[1:].split()[0]
                seq_lines = []
            else:
                seq_lines.append(line)

        if seq_id is not None:
            yield seq_id, "".join(seq_lines).upper()


def count_fasta_records(fasta_file: Path) -> int:
    count = 0

    with fasta_file.open(
        "r",
        encoding="utf-8",
        errors="ignore",
    ) as handle:
        for line in handle:
            if line.startswith(">"):
                count += 1

    return count


def clean_dna(sequence: str) -> str:
    allowed = {"A", "C", "G", "T", "N"}

    return "".join(
        base if base in allowed else "N"
        for base in sequence.upper()
    )


def mean_pooling(
    hidden_states: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).expand(
        hidden_states.size()
    ).float()

    summed = torch.sum(hidden_states * mask, dim=1)
    counts = torch.clamp(mask.sum(dim=1), min=1e-9)

    return summed / counts


def sample_name_from_fasta(
    fasta_path: Path,
    threshold: str,
) -> str:
    suffix = f"_diamond{threshold}_candidate_reads"

    if fasta_path.stem.endswith(suffix):
        return fasta_path.stem[: -len(suffix)]

    if fasta_path.stem.endswith("_candidate_reads"):
        return fasta_path.stem[: -len("_candidate_reads")]

    return fasta_path.stem


SUMMARY_FIELDS = [
    "threshold",
    "sample_name",
    "fasta_file",
    "status",
    "num_sequences",
    "embedding_dim",
    "embedding_file",
    "file_size_gb",
    "time_min",
    "error_message",
]


def load_summary_rows(
    summary_csv: Path,
) -> dict[tuple[str, str], dict]:
    rows: dict[tuple[str, str], dict] = {}

    if not summary_csv.exists():
        return rows

    with summary_csv.open(
        "r",
        newline="",
        encoding="utf-8-sig",
    ) as handle:
        reader = csv.DictReader(handle)

        for row in reader:
            key = (
                row.get("threshold", ""),
                row.get("sample_name", ""),
            )
            rows[key] = row

    return rows


def update_summary(
    summary_csv: Path,
    row: dict,
) -> None:
    rows = load_summary_rows(summary_csv)

    key = (
        str(row.get("threshold", "")),
        str(row.get("sample_name", "")),
    )

    rows[key] = {
        field: row.get(field, "")
        for field in SUMMARY_FIELDS
    }

    summary_csv.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temporary = summary_csv.with_name(
        summary_csv.name + ".tmp"
    )

    with temporary.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=SUMMARY_FIELDS,
        )
        writer.writeheader()

        for saved_row in sorted(
            rows.values(),
            key=lambda item: (
                str(item.get("threshold", "")),
                str(item.get("sample_name", "")),
            ),
        ):
            writer.writerow(saved_row)

    os.replace(temporary, summary_csv)


def extract_one_fasta(
    input_fasta: Path,
    output_pt: Path,
    threshold: str,
    tokenizer,
    model,
    device: str,
    args: argparse.Namespace,
    summary_csv: Path,
) -> None:
    sample_name = sample_name_from_fasta(
        input_fasta,
        threshold,
    )

    fasta_count = count_fasta_records(input_fasta)

    if output_pt.exists() and not args.overwrite:
        print(
            f"[SKIP] diamond{threshold} | {sample_name} | "
            f"existing PT: {output_pt}",
            flush=True,
        )

        try:
            old_object = torch.load(
                output_pt,
                map_location="cpu",
                weights_only=False,
            )
            sequence_count = old_object.get(
                "num_sequences",
                "",
            )
            embedding_dim = old_object.get(
                "embedding_dim",
                "",
            )
        except Exception:
            sequence_count = ""
            embedding_dim = ""

        update_summary(
            summary_csv,
            {
                "threshold": threshold,
                "sample_name": sample_name,
                "fasta_file": str(input_fasta),
                "status": "skipped_existing",
                "num_sequences": sequence_count,
                "embedding_dim": embedding_dim,
                "embedding_file": str(output_pt),
                "file_size_gb": (
                    output_pt.stat().st_size
                    / 1024
                    / 1024
                    / 1024
                ),
                "time_min": "",
                "error_message": "",
            },
        )
        return

    print("=" * 88)
    print(f"Threshold: diamond{threshold}")
    print(f"Sample: {sample_name}")
    print(f"Input FASTA: {input_fasta}")
    print(f"FASTA records: {fasta_count:,}")
    print(f"Output PT: {output_pt}")
    print("=" * 88, flush=True)

    start_time = time.time()
    total_count = 0

    batch_ids: list[str] = []
    batch_sequences: list[str] = []
    all_ids: list[str] = []
    embedding_batches: list[torch.Tensor] = []

    def process_batch(
        ids: list[str],
        sequences: list[str],
    ) -> None:
        nonlocal total_count

        inputs = tokenizer(
            sequences,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=args.model_max_length,
        )

        inputs = {
            key: value.to(
                device,
                non_blocking=True,
            )
            for key, value in inputs.items()
        }

        with torch.inference_mode():
            if device == "cuda":
                with torch.autocast(
                    device_type="cuda",
                    dtype=torch.float16,
                ):
                    outputs = model(**inputs)
                    hidden_states = outputs[0]
                    embeddings = mean_pooling(
                        hidden_states,
                        inputs["attention_mask"],
                    )
            else:
                outputs = model(**inputs)
                hidden_states = outputs[0]
                embeddings = mean_pooling(
                    hidden_states,
                    inputs["attention_mask"],
                )

        embeddings = embeddings.detach().cpu()

        all_ids.extend(ids)
        embedding_batches.append(embeddings)
        total_count += len(ids)

        if (
            args.print_every > 0
            and (
                total_count % args.print_every < len(ids)
                or total_count == fasta_count
            )
        ):
            elapsed = time.time() - start_time
            speed = (
                total_count / elapsed
                if elapsed > 0
                else 0.0
            )
            progress = (
                total_count / fasta_count * 100.0
                if fasta_count > 0
                else 0.0
            )

            print(
                f"diamond{threshold} | {sample_name} | "
                f"{total_count:,}/{fasta_count:,} "
                f"({progress:.1f}%) | "
                f"{elapsed / 60:.2f} min | "
                f"{speed:.2f} seq/s",
                flush=True,
            )

    try:
        for sequence_id, sequence in read_fasta_generator(
            input_fasta
        ):
            if (
                args.max_records_per_fasta is not None
                and total_count + len(batch_ids)
                >= args.max_records_per_fasta
            ):
                break

            batch_ids.append(sequence_id)
            batch_sequences.append(clean_dna(sequence))

            if len(batch_ids) >= args.batch_size:
                process_batch(
                    batch_ids,
                    batch_sequences,
                )
                batch_ids = []
                batch_sequences = []

        if batch_ids:
            process_batch(
                batch_ids,
                batch_sequences,
            )

        output_pt.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        if total_count == 0:
            embeddings = torch.empty(
                (0, 768),
                dtype=(
                    torch.float16
                    if SAVE_FLOAT16
                    else torch.float32
                ),
            )
        else:
            print(
                "Concatenating embeddings...",
                flush=True,
            )

            embeddings = torch.cat(
                embedding_batches,
                dim=0,
            )

            embeddings = (
                embeddings.half()
                if SAVE_FLOAT16
                else embeddings.float()
            )

        save_object = {
            "sample_name": sample_name,
            "threshold": threshold,
            "threshold_label": f"diamond{threshold}",
            "ids": all_ids,
            "embeddings": embeddings,
            "embedding_dim": (
                int(embeddings.shape[1])
                if embeddings.ndim == 2
                else ""
            ),
            "dtype": str(embeddings.dtype),
            "num_sequences": len(all_ids),
            "source_fasta": str(input_fasta.resolve()),
            "model_name": args.model_name,
            "model_max_length": args.model_max_length,
            "pooling": "mean_pooling_with_attention_mask",
            "input_type": "DIAMOND_candidate_reads",
            "diamond_identity_fraction": float(threshold),
            "diamond_identity_percent": float(threshold) * 100.0,
        }

        temporary_pt = output_pt.with_name(
            output_pt.name + ".tmp"
        )

        print(
            f"Saving temporary file: {temporary_pt}",
            flush=True,
        )

        torch.save(
            save_object,
            temporary_pt,
        )
        os.replace(
            temporary_pt,
            output_pt,
        )

        total_time = time.time() - start_time
        file_size_gb = (
            output_pt.stat().st_size
            / 1024
            / 1024
            / 1024
        )

        update_summary(
            summary_csv,
            {
                "threshold": threshold,
                "sample_name": sample_name,
                "fasta_file": str(input_fasta),
                "status": "finished",
                "num_sequences": total_count,
                "embedding_dim": (
                    int(embeddings.shape[1])
                    if embeddings.ndim == 2
                    else ""
                ),
                "embedding_file": str(output_pt),
                "file_size_gb": file_size_gb,
                "time_min": total_time / 60,
                "error_message": "",
            },
        )

        print("-" * 88)
        print(
            f"Finished diamond{threshold} | "
            f"{sample_name}"
        )
        print(f"Sequences encoded: {total_count:,}")
        print(f"Embedding shape: {tuple(embeddings.shape)}")
        print(f"File size: {file_size_gb:.3f} GB")
        print(f"Time: {total_time / 60:.2f} min")

        if total_time > 0:
            print(
                f"Average speed: "
                f"{total_count / total_time:.2f} seq/s"
            )

        print("-" * 88, flush=True)

    except Exception as error:
        total_time = time.time() - start_time
        error_message = str(error)

        print(f"[ERROR] {input_fasta}")
        print(error_message)
        traceback.print_exc()

        update_summary(
            summary_csv,
            {
                "threshold": threshold,
                "sample_name": sample_name,
                "fasta_file": str(input_fasta),
                "status": "error",
                "num_sequences": total_count,
                "embedding_dim": "",
                "embedding_file": str(output_pt),
                "file_size_gb": "",
                "time_min": total_time / 60,
                "error_message": error_message,
            },
        )

    finally:
        del batch_ids
        del batch_sequences
        del all_ids
        del embedding_batches

        gc.collect()

        if device == "cuda":
            torch.cuda.empty_cache()


def main() -> None:
    args = parse_args()
    setup_speed_options()

    result_root = args.result_root.resolve()

    if not result_root.is_dir():
        raise FileNotFoundError(
            f"Result root not found: {result_root}"
        )

    thresholds = [
        normalize_threshold(value)
        for value in args.thresholds
    ]

    output_root = (
        result_root
        / "dnabert2_candidate_embeddings_pt"
    )
    summary_csv = (
        result_root
        / "dnabert2_candidate_embedding_summary.csv"
    )

    task_list: list[
        tuple[str, Path, Path]
    ] = []

    print("=" * 88)
    print("Searching candidate_reads FASTA files")
    print(f"Result root: {result_root}")
    print(
        "Thresholds: "
        + ", ".join(
            f"diamond{threshold}"
            for threshold in thresholds
        )
    )
    print("=" * 88)

    for threshold in thresholds:
        candidate_reads_dir = (
            result_root
            / f"diamond{threshold}"
            / "candidate_reads"
        )

        if not candidate_reads_dir.is_dir():
            print(
                f"[WARNING] Folder does not exist; skipped: "
                f"{candidate_reads_dir}",
                flush=True,
            )
            continue

        fasta_files = sorted(
            candidate_reads_dir.glob(
                FASTA_PATTERN
            )
        )

        print(
            f"diamond{threshold}: "
            f"{len(fasta_files)} FASTA files"
        )

        threshold_output_dir = (
            output_root
            / f"diamond{threshold}"
        )

        for fasta_file in fasta_files:
            sample_name = sample_name_from_fasta(
                fasta_file,
                threshold,
            )

            output_pt = (
                threshold_output_dir
                / (
                    f"{sample_name}_diamond{threshold}"
                    f"_candidate_reads_dnabert2.pt"
                )
            )

            task_list.append(
                (
                    threshold,
                    fasta_file,
                    output_pt,
                )
            )

    if not task_list:
        raise FileNotFoundError(
            "No candidate_reads FASTA files were found."
        )

    print("-" * 88)
    print(f"Total embedding tasks: {len(task_list)}")

    for threshold, fasta_file, output_pt in task_list:
        print(
            f"  diamond{threshold} | "
            f"{fasta_file.name} -> {output_pt.name}"
        )

    print("-" * 88)

    device = (
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print(f"Device: {device}")

    if device == "cuda":
        print(
            f"GPU: {torch.cuda.get_device_name(0)}"
        )
        print(
            f"CUDA capability: "
            f"{torch.cuda.get_device_capability(0)}"
        )
    else:
        print(
            "Warning: CUDA is unavailable. "
            "CPU extraction will be slow."
        )

    print("Loading tokenizer...", flush=True)

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name,
        trust_remote_code=True,
    )

    print("Loading DNABERT-2 model...", flush=True)

    model = AutoModel.from_pretrained(
        args.model_name,
        trust_remote_code=True,
    )
    model.to(device)
    model.eval()

    all_start = time.time()

    for task_index, (
        threshold,
        input_fasta,
        output_pt,
    ) in enumerate(task_list, start=1):
        print(
            f"\n[TASK {task_index}/{len(task_list)}] "
            f"diamond{threshold} | {input_fasta.name}",
            flush=True,
        )

        extract_one_fasta(
            input_fasta=input_fasta,
            output_pt=output_pt,
            threshold=threshold,
            tokenizer=tokenizer,
            model=model,
            device=device,
            args=args,
            summary_csv=summary_csv,
        )

    all_time = time.time() - all_start

    print("#" * 88)
    print("All requested candidate FASTA files finished.")
    print(f"Total tasks: {len(task_list)}")
    print(f"Total time: {all_time / 60:.2f} min")
    print(f"Output root: {output_root}")
    print(f"Summary CSV: {summary_csv}")
    print("#" * 88)


if __name__ == "__main__":
    main()
