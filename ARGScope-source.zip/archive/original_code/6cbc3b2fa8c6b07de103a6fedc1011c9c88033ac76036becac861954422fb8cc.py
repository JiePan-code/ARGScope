"""Update ARG type/subtype tables in a new copy, preserving all other tables."""
from pathlib import Path
import csv
import hashlib
import json
import re
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.paragraph import Paragraph

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs/argscope_including_nonARG_20260922'
SOURCE=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary materials.docx')
DEST=OUT/'Supplementary_materials_including_nonARG_20260922.docx'
FIELDS=['Accuracy','Precision','Recall','F1','MCC']
TABLES={2:('Protein','ARGScope','Type'),3:('Protein','ARGScope','Subtype'),
        5:('DNA','ARGScope','Type'),6:('DNA','ARGScope','Subtype'),
        8:('Protein','ARGNet','Type'),10:('DNA','ARGNet','Type'),
        12:('Protein','FunGeneTyper','Type'),14:('Protein','PLM-ARG','Type'),
        16:('Protein','DeepARG','Type'),18:('DNA','DeepARG','Type')}
TYPE_NOTE=('Type evaluation includes the 23 ARG types and non-ARG as 24 classes. '
    'Reference sequences outside these 24 classes are excluded. Unmatched type predictions remain errors. '
    'Macro, weighted and micro precision, recall and F1 are calculated over these 24 classes. '
    'ACC and MCC use all retained predictions. For DeepARG, inputs without a reported ARG hit are assigned non-ARG.')
SUBTYPE_NOTE=('Note: Subtype evaluation includes 820 ARG subtype labels and non-ARG. '
    'All reference ARG and non-ARG sequences are retained. Macro, weighted and micro precision, '
    'recall and F1 are calculated over these 821 classes. ACC and MCC use all evaluated sequences.')


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def replace(cell,text):
    p=cell.paragraphs[0]
    if p.runs:
        p.runs[0].text=text
        for r in p.runs[1:]: r.text=''
    else: p.add_run(text)


def note_after(element,parent,text):
    node=OxmlElement('w:p'); element.addnext(node)
    p=Paragraph(node,parent)
    p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(7)
    p.paragraph_format.line_spacing=1; p.paragraph_format.keep_together=True
    r=p.add_run(text); r.font.name='Times New Roman'; r.font.size=Pt(10.5)
    r._r.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Times New Roman')
    return p


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    initial_hash=digest(SOURCE)
    doc=Document(SOURCE)
    assert len(doc.tables)==20
    originals=[[[c.text for c in row.cells] for row in t.rows] for t in doc.tables]
    with (OUT/'data/all_metrics_including_nonARG.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    changes=[]
    for number,(mod,model,level) in TABLES.items():
        table=doc.tables[number-1]
        for ri,row in enumerate(table.rows[1:],1):
            pct=int(row.cells[0].text.strip().replace('%',''))
            avg=row.cells[2].text.strip()
            values=[r for r in rows if r['Modality']==mod and r['Model']==model and r['Level']==level
                    and int(r['Completeness'])==pct and r['Average']==avg]
            assert len(values)==1,(number,pct,avg)
            assert int(values[0]['N_labels_averaged'])==(24 if level=='Type' else 821)
            for ci,field in enumerate(FIELDS,3):
                before=row.cells[ci].text.strip(); after=f"{float(values[0][field]):.4f}"
                replace(row.cells[ci],after)
                changes.append(dict(Table=number,Modality=mod,Model=model,Level=level,
                                    Completeness=pct,Average=avg,Metric=field,Before=before,After=after))
    # Remove only superseded ARG-only subtype scope notes.
    removed=[]
    for p in list(doc.paragraphs):
        if p.text.startswith('Note: Subtype evaluation includes reference ARG sequences only.'):
            removed.append(p.text); p._p.getparent().remove(p._p)
    title=next(p for p in doc.paragraphs if p.text.strip()=='Supplementary Material')
    note_after(title._p,title._parent,TYPE_NOTE)
    for ti in (2,5): note_after(doc.tables[ti]._tbl,doc.tables[ti]._parent,SUBTYPE_NOTE)
    for ti,t in enumerate(doc.tables):
        header=t.rows[0]._tr.get_or_add_trPr()
        if header.find(qn('w:tblHeader')) is None: header.append(OxmlElement('w:tblHeader'))
        for ri,row in enumerate(t.rows):
            pr=row._tr.get_or_add_trPr()
            if pr.find(qn('w:cantSplit')) is None: pr.append(OxmlElement('w:cantSplit'))
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.keep_together=True
                    p.paragraph_format.keep_with_next=ri<len(t.rows)-1 or ti in (2,5)
    for p in doc.paragraphs:
        match=re.match(r'Table\s+(\d+)\.',p.text.strip())
        if match:
            p.paragraph_format.keep_with_next=True
            p.paragraph_format.page_break_before=int(match.group(1)) in (3,5,7,9,11,13,15,17,19)
    doc.save(DEST)
    verified=Document(DEST)
    assert len(verified.tables)==20
    for ti,table in enumerate(verified.tables,1):
        actual=[[c.text for c in row.cells] for row in table.rows]
        if ti not in TABLES:
            assert actual==originals[ti-1],f'Unrelated table {ti} changed'
        else:
            assert actual[0]==originals[ti-1][0]
            for ri in range(1,len(actual)): assert actual[ri][:3]==originals[ti-1][ri][:3]
    assert digest(SOURCE)==initial_hash
    assert len(changes)==750
    with (OUT/'data/supplement_numeric_changes.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(changes[0])); writer.writeheader(); writer.writerows(changes)
    record=dict(source=str(SOURCE),source_sha256=initial_hash,output=str(DEST),output_sha256=digest(DEST),
        updated_tables=sorted(TABLES),verified_numeric_cells=750,other_ten_tables_unchanged=True,
        VF_BGC_tables_unchanged=True,superseded_notes_removed=len(removed),type_scope=TYPE_NOTE,subtype_scope=SUBTYPE_NOTE)
    (OUT/'data/document_verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(DEST)
    print('PASS: 750 numeric cells verified. Ten other tables unchanged. Source DOCX preserved.')


if __name__=='__main__': main()
