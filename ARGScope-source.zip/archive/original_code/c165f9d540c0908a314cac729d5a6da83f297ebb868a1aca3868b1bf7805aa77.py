"""w/o Graph Prior: use train-only raw centroids, never GAT-refined prototypes."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, load_base, raw_as_refined, set_common_student_defaults, mark_saved_ablation

DATA = Path(__file__).resolve().parents[3]
m = load_base("05_dna_student.py", "dna_wo_graph_base")
set_common_student_defaults(m, DATA, "dna", "DNA_student_subtype2_newsplit_wo_graph")
raw = DATA / "Raw_subtype_prototypes_subtype2_newsplit" / "raw_ARG_subtype_prototypes_and_baseline.pt"
m.DEFAULT_REFINED_PT = raw
raw_as_refined(m, raw)
mark_saved_ablation(m, "w/o Graph Prior", "Mutual-KNN + residual GAT refinement; raw train-only centroids are used")
add_default_structure(DATA)
m.main()
