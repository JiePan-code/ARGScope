import random
import multiprocessing as mp
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    classification_report,
)


# =========================
# 1. Config
# =========================

FUSION_FILE = "novel gene/1.all_fusion_embedding_512_with_label.csv"
DNA_FILE = "1_ARG_DNA_PCA512_with_label.csv"
REFINED_FILE = "novel gene/3.all_Refined_embeddings_512.csv"

TRAIN_SPLIT_FILE = "train_set.csv"
TEST_SPLIT_FILE = "test_set.csv"

LABEL_COL = "Subtype"
KEY_CANDIDATES = ["Geneid", "geneid", "id", "ID", "Id", "NucleotideID", "ProteinID", "KEY"]

OUTPUT_DIR = Path("ARGScope_fusion_train_dna_test_refined_anchor")
OUTPUT_DIR.mkdir(exist_ok=True)

CHECKPOINT_FILE = OUTPUT_DIR / "fusion_train_dna_test_refined_anchor.pth"
SCALER_MAIN_FILE = OUTPUT_DIR / "scaler_main.joblib"
LABEL_ENCODER_FILE = OUTPUT_DIR / "label_encoder.joblib"
FEATURE_INFO_FILE = OUTPUT_DIR / "feature_info.joblib"
CLASS_INFO_FILE = OUTPUT_DIR / "subtype_class_info.csv"

SEED = 42
BATCH_SIZE = 256
MAX_EPOCHS = 200
LR = 3e-4
WEIGHT_DECAY = 3e-5
PATIENCE = 40
MIN_DELTA = 1e-4

DROPOUT = 0.15
SCALE = 22.0

LAMBDA_CE = 1.0
LAMBDA_CENTER = 0.20

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# =========================
# 2. Utils
# =========================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = True


def find_key_col(df):
    for c in KEY_CANDIDATES:
        if c in df.columns:
            return c
    return None


def standardize_key(df, name):
    key = find_key_col(df)

    if key is None:
        raise ValueError(f"{name} 找不到 KEY 列，需要 Geneid/id/NucleotideID/ProteinID/KEY 之一")

    df[key] = df[key].astype(str).str.strip()
    df = df.rename(columns={key: "KEY"})

    return df


def clean_label(s):
    return s.astype(str).replace(["nan", "None", "NAN"], "Unknown")


def get_feature_cols(df):
    exclude = {
        "KEY",
        "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "Type", "Subtype",
        "Type_split", "Subtype_split",
        "Count",
    }

    return [
        c for c in df.columns
        if c not in exclude and pd.api.types.is_numeric_dtype(df[c])
    ]


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def normalize_np(x, eps=1e-8):
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + eps)


def compute_metrics(y_true, y_pred):
    return {
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true))),
    }


def per_class_metrics(y_true, y_pred, class_names, split):
    rows = []

    for cid in sorted(np.unique(y_true)):
        yt = (y_true == cid).astype(int)
        yp = (y_pred == cid).astype(int)

        support = int(yt.sum())
        pred_count = int(yp.sum())
        correct = int(((y_true == cid) & (y_pred == cid)).sum())

        if len(np.unique(yt)) == 1 and len(np.unique(yp)) == 1:
            mcc = 0.0
        else:
            mcc = matthews_corrcoef(yt, yp)

        rows.append({
            "split": split,
            "Subtype": class_names[cid],
            "class_id": int(cid),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct,
            "ACC": correct / support if support > 0 else 0.0,
            "PRECISION": precision_score(yt, yp, zero_division=0),
            "RECALL": recall_score(yt, yp, zero_division=0),
            "F1": f1_score(yt, yp, zero_division=0),
            "MCC": mcc,
        })

    return pd.DataFrame(rows).sort_values(
        ["support", "Subtype"],
        ascending=[False, True]
    ).reset_index(drop=True)


# =========================
# 3. Loss and model
# =========================

class WeightedFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=1.5, label_smoothing=0.02):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    def forward(self, logits, target):
        ce = nn.functional.cross_entropy(
            logits,
            target,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing,
        )

        pt = torch.exp(-ce)
        return (((1.0 - pt) ** self.gamma) * ce).mean()


class EmbeddingToRefinedPrototype(nn.Module):
    def __init__(self, input_dim, proto_dim):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(input_dim, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(DROPOUT),

            nn.Linear(1024, 768),
            nn.LayerNorm(768),
            nn.GELU(),
            nn.Dropout(DROPOUT),

            nn.Linear(768, proto_dim),
            nn.LayerNorm(proto_dim),
        )

    def forward(self, x):
        z = self.net(x)
        z = nn.functional.normalize(z, p=2, dim=1)
        return z


# =========================
# 4. Data
# =========================

def load_data():
    fusion_df = pd.read_csv(FUSION_FILE)
    dna_df = pd.read_csv(DNA_FILE)
    refined_df = pd.read_csv(REFINED_FILE)
    train_split = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split = pd.read_csv(TEST_SPLIT_FILE)

    print("Raw shapes:")
    print("fusion:", fusion_df.shape)
    print("dna:", dna_df.shape)
    print("refined:", refined_df.shape)
    print("train_split:", train_split.shape)
    print("test_split:", test_split.shape)

    fusion_df = standardize_key(fusion_df, "fusion file")
    dna_df = standardize_key(dna_df, "DNA file")
    train_split = standardize_key(train_split, "train split")
    test_split = standardize_key(test_split, "test split")

    fusion_df = fusion_df.drop_duplicates(subset=["KEY"], keep="first").copy()
    dna_df = dna_df.drop_duplicates(subset=["KEY"], keep="first").copy()

    for df in [fusion_df, dna_df, refined_df, train_split, test_split]:
        for col in ["Type", "Subtype"]:
            if col in df.columns:
                df[col] = clean_label(df[col])

    if LABEL_COL not in refined_df.columns:
        raise ValueError(f"refined 文件缺少标签列: {LABEL_COL}")

    train_fusion = pd.merge(
        train_split,
        fusion_df,
        on="KEY",
        how="inner",
        suffixes=("_split", ""),
    )

    test_dna = pd.merge(
        test_split,
        dna_df,
        on="KEY",
        how="inner",
        suffixes=("_split", ""),
    )

    for df in [train_fusion, test_dna]:
        for col in ["Type", "Subtype"]:
            split_col = f"{col}_split"
            if split_col in df.columns:
                df[col] = df[split_col].astype(str)

        if "Geneid" not in df.columns:
            df["Geneid"] = df["KEY"].astype(str)

    print("\nAfter merge:")
    print("train_fusion:", len(train_fusion))
    print("test_dna:", len(test_dna))

    if len(train_fusion) == 0:
        raise ValueError("train_set 与 fusion 文件 merge 后为空，请检查 KEY 是否一致")

    if len(test_dna) == 0:
        raise ValueError("test_set 与 DNA 文件 merge 后为空，请检查 KEY 是否一致")

    common_subtypes = (
        set(train_fusion[LABEL_COL].astype(str).unique())
        & set(test_dna[LABEL_COL].astype(str).unique())
        & set(refined_df[LABEL_COL].astype(str).unique())
    )

    train_fusion = train_fusion[train_fusion[LABEL_COL].isin(common_subtypes)].reset_index(drop=True)
    test_dna = test_dna[test_dna[LABEL_COL].isin(common_subtypes)].reset_index(drop=True)
    refined_df = refined_df[refined_df[LABEL_COL].isin(common_subtypes)].reset_index(drop=True)

    print("\nAfter subtype filtering:")
    print("train_fusion:", len(train_fusion), "subtypes:", train_fusion[LABEL_COL].nunique())
    print("test_dna:", len(test_dna), "subtypes:", test_dna[LABEL_COL].nunique())
    print("refined prototypes:", refined_df[LABEL_COL].nunique())

    if len(train_fusion) == 0 or len(test_dna) == 0:
        raise ValueError("subtype 过滤后 train/test 为空")

    return train_fusion, test_dna, refined_df


def build_refined_prototypes(refined_df, refined_cols, le):
    tmp = refined_df.copy()
    tmp[refined_cols] = tmp[refined_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

    grouped = tmp.groupby(LABEL_COL)[refined_cols].mean()

    missing = [x for x in le.classes_ if x not in grouped.index]
    if missing:
        raise ValueError(f"refined prototype 缺少这些 subtype: {missing[:10]}")

    proto = np.stack(
        [grouped.loc[x].values.astype(np.float32) for x in le.classes_],
        axis=0,
    )

    proto = normalize_np(proto)

    return proto


# =========================
# 5. Main
# =========================

def main():
    seed_everything(SEED)

    print("Device:", DEVICE)

    train_fusion, test_dna, refined_df = load_data()

    le = LabelEncoder()
    le.fit(sorted(train_fusion[LABEL_COL].astype(str).unique()))

    valid_classes = set(le.classes_)

    train_fusion = train_fusion[train_fusion[LABEL_COL].isin(valid_classes)].reset_index(drop=True)
    test_dna = test_dna[test_dna[LABEL_COL].isin(valid_classes)].reset_index(drop=True)
    refined_df = refined_df[refined_df[LABEL_COL].isin(valid_classes)].reset_index(drop=True)

    fusion_cols = get_feature_cols(train_fusion)
    dna_cols = get_feature_cols(test_dna)
    refined_cols = get_feature_cols(refined_df)

    if len(fusion_cols) == 0:
        raise ValueError("fusion 特征列为 0")
    if len(dna_cols) == 0:
        raise ValueError("DNA 特征列为 0")
    if len(refined_cols) == 0:
        raise ValueError("refined 特征列为 0")

    if len(fusion_cols) != len(dna_cols):
        raise ValueError(
            f"fusion dim 和 DNA dim 不一致: {len(fusion_cols)} vs {len(dna_cols)}。"
            f"如果不一致，需要加一个额外 projector，或者先把 DNA embedding 生成到同维度。"
        )

    print("\nFeature dims:")
    print("fusion dim:", len(fusion_cols))
    print("DNA dim:", len(dna_cols))
    print("refined prototype dim:", len(refined_cols))

    y_train = le.transform(train_fusion[LABEL_COL].astype(str).values).astype(np.int64)
    y_test = le.transform(test_dna[LABEL_COL].astype(str).values).astype(np.int64)

    X_train = to_float_matrix(train_fusion, fusion_cols)
    X_test = to_float_matrix(test_dna, dna_cols)

    scaler_main = StandardScaler()
    X_train = scaler_main.fit_transform(X_train).astype(np.float32)
    X_test = scaler_main.transform(X_test).astype(np.float32)

    refined_proto_np = build_refined_prototypes(refined_df, refined_cols, le)

    proto_dim = refined_proto_np.shape[1]
    num_classes = len(le.classes_)

    refined_proto = torch.tensor(refined_proto_np, dtype=torch.float32, device=DEVICE)
    refined_proto = nn.functional.normalize(refined_proto, p=2, dim=1)

    print("\nClasses:", num_classes)
    print("Prototype dim:", proto_dim)

    class_counts = np.bincount(y_train, minlength=num_classes).astype(np.float32)

    beta = 0.995
    effective_num = 1.0 - np.power(beta, class_counts)
    weights = (1.0 - beta) / (effective_num + 1e-8)
    weights = weights / weights.mean()
    weights = np.clip(weights, 0.5, 3.0)
    weights = torch.tensor(weights, dtype=torch.float32, device=DEVICE)

    criterion_ce = WeightedFocalLoss(
        weight=weights,
        gamma=1.5,
        label_smoothing=0.02,
    )

    criterion_center = nn.MSELoss()

    train_loader = DataLoader(
        TensorDataset(
            torch.tensor(X_train, dtype=torch.float32),
            torch.tensor(y_train, dtype=torch.long),
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    model = EmbeddingToRefinedPrototype(
        input_dim=X_train.shape[1],
        proto_dim=proto_dim,
    ).to(DEVICE)

    optimizer = optim.AdamW(
        model.parameters(),
        lr=LR,
        weight_decay=WEIGHT_DECAY,
    )

    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",
        factor=0.5,
        patience=15,
    )

    scaler_amp = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    best_loss = float("inf")
    best_state = None
    wait = 0

    print("\nTraining:")
    print("Train input: fusion embedding")
    print("Anchor: refined subtype prototypes")
    print("Test input: DNA embedding")

    for epoch in range(1, MAX_EPOCHS + 1):
        model.train()
        total_loss = 0.0

        for xb, yb in train_loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                z = model(xb)

                logits = SCALE * (z @ refined_proto.t())

                loss_ce = criterion_ce(logits, yb)
                loss_center = criterion_center(z, refined_proto[yb])

                loss = LAMBDA_CE * loss_ce + LAMBDA_CENTER * loss_center

            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)

            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            scaler_amp.step(optimizer)
            scaler_amp.update()

            total_loss += loss.item() * xb.size(0)

        avg_loss = total_loss / len(train_loader.dataset)
        scheduler.step(avg_loss)

        if avg_loss < best_loss - MIN_DELTA:
            best_loss = avg_loss
            best_state = {
                k: v.detach().cpu().clone()
                for k, v in model.state_dict().items()
            }
            wait = 0
        else:
            wait += 1

        if epoch == 1 or epoch % 10 == 0:
            lr_now = optimizer.param_groups[0]["lr"]
            print(f"Epoch {epoch:03d} | lr={lr_now:.2e} | loss={avg_loss:.4f} | best={best_loss:.4f}")

        if wait >= PATIENCE:
            print(f"Early stopping at epoch {epoch}, best loss={best_loss:.4f}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)
        model.to(DEVICE)

    model.eval()

    print("\nEvaluating...")

    with torch.no_grad():
        X_train_t = torch.tensor(X_train, dtype=torch.float32, device=DEVICE)
        X_test_t = torch.tensor(X_test, dtype=torch.float32, device=DEVICE)

        z_train = model(X_train_t)
        logits_train = SCALE * (z_train @ refined_proto.t())
        pred_train = logits_train.argmax(dim=1).cpu().numpy()

        z_test = model(X_test_t)
        logits_test = SCALE * (z_test @ refined_proto.t())
        pred_test = logits_test.argmax(dim=1).cpu().numpy()

    train_metrics = compute_metrics(y_train, pred_train)
    test_metrics = compute_metrics(y_test, pred_test)

    print("\n=== TRAIN RESULT | fusion -> refined prototype ===")
    for k, v in train_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    print("\n=== TEST RESULT | DNA -> refined prototype ===")
    for k, v in test_metrics.items():
        print(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}")

    print("\n=== TEST CLASSIFICATION REPORT ===")
    print(classification_report(
        le.inverse_transform(y_test),
        le.inverse_transform(pred_test),
        zero_division=0,
        digits=4,
    ))

    overall_df = pd.DataFrame([
        {"split": "train_set_fusion_refined_anchor", **train_metrics},
        {"split": "test_set_dna_refined_anchor", **test_metrics},
    ]).round(4)

    overall_df.to_csv(
        "fusion_train_dna_test_refined_anchor_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    per_class_df = pd.concat([
        per_class_metrics(y_train, pred_train, le.classes_, "train_set_fusion_refined_anchor"),
        per_class_metrics(y_test, pred_test, le.classes_, "test_set_dna_refined_anchor"),
    ], axis=0).round(4)

    per_class_df.to_csv(
        "fusion_train_dna_test_refined_anchor_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig",
    )

    pred_df = test_dna[["KEY", "Type", "Subtype"]].copy()
    pred_df["Pred_Subtype"] = le.inverse_transform(pred_test)

    pred_df.to_csv(
        "fusion_train_dna_test_refined_anchor_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    checkpoint = {
        "model_name": "fusion_train_dna_test_refined_anchor",
        "model_state_dict": model.state_dict(),

        "refined_prototypes": refined_proto_np,

        "input_dim": int(X_train.shape[1]),
        "proto_dim": int(proto_dim),
        "num_classes": int(num_classes),
        "scale": float(SCALE),

        "label_classes": le.classes_.tolist(),

        "fusion_feature_cols": fusion_cols,
        "dna_feature_cols": dna_cols,
        "refined_feature_cols": refined_cols,

        "best_loss": float(best_loss),
        "train_metrics": train_metrics,
        "test_metrics": test_metrics,
    }

    torch.save(checkpoint, CHECKPOINT_FILE)
    joblib.dump(scaler_main, SCALER_MAIN_FILE)
    joblib.dump(le, LABEL_ENCODER_FILE)

    feature_info = {
        "fusion_feature_cols": fusion_cols,
        "dna_feature_cols": dna_cols,
        "refined_feature_cols": refined_cols,
        "input_dim": int(X_train.shape[1]),
        "proto_dim": int(proto_dim),
        "num_classes": int(num_classes),
        "label_classes": le.classes_.tolist(),
        "scale": float(SCALE),
    }

    joblib.dump(feature_info, FEATURE_INFO_FILE)

    pd.DataFrame({
        "class_id": list(range(num_classes)),
        "Subtype": le.classes_,
    }).to_csv(
        CLASS_INFO_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print("\nSaved:")
    print(" - fusion_train_dna_test_refined_anchor_overall_metrics.csv")
    print(" - fusion_train_dna_test_refined_anchor_metrics_by_class.csv")
    print(" - fusion_train_dna_test_refined_anchor_predictions.csv")
    print(f" - {CHECKPOINT_FILE}")
    print(f" - {SCALER_MAIN_FILE}")
    print(f" - {LABEL_ENCODER_FILE}")
    print(f" - {FEATURE_INFO_FILE}")
    print(f" - {CLASS_INFO_FILE}")


if __name__ == "__main__":
    mp.freeze_support()
    main()