#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Protein + DNA 100% Type-level PRF heatmaps
==========================================

输出两张独立图：
1. LongAA / Protein 100%: Precision | Recall | F1
2. LongNT / DNA     100%: Precision | Recall | F1

统一规则：
- Average 仍按固定 18 个 ARG Type 计算；主热图不显示 bleomycin，因此主图显示 17 个 Type；
- 每张图包含 3 个并排热图：Precision、Recall、F1；
- 每个指标热图顶部额外显示一行 Average，与主 Type 热图留出间隔；
- Average = 该模型在当前指标下固定18个 Type 数值的算术平均（仍包含 bleomycin）；
- LongAA 默认模型顺序：ARGNet, DeepARG, Fungenetyper, PLM-ARG, ARGScope；
- LongNT 默认模型顺序：ARGNet, DeepARG, Fungenetyper, ARGScope；
- 实际不存在的模型不会画空白列，而是自动跳过；
- 缺失的 Type-level 数值显示为灰色；
- ARGScope x 轴标签以红色突出；
- Protein 使用原有蓝色；DNA 使用淡橙色；
- PNG/TIF 600 dpi，同时输出 PDF/SVG；
- 透明背景。

脚本放在 Type_level_performance 根目录运行，会递归搜索当前目录下的 CSV。
"""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd


# =============================================================================
# 1. Paths / output
# =============================================================================
ROOT_DIR = Path(__file__).resolve().parent
OUTDIR = ROOT_DIR / "Protein_DNA_100pct_PRF_heatmaps_noBleomycin_Average18"
OUTDIR.mkdir(parents=True, exist_ok=True)

DPI = 600
SAVE_PNG = True
SAVE_TIF = True
SAVE_PDF = True
SAVE_SVG = True
TRANSPARENT_BG = True


# =============================================================================
# 2. Plot settings
# =============================================================================
FONT_FAMILY = "Arial"
PANEL_TITLE_SIZE = 12
TYPE_LABEL_SIZE = 11.0
MODEL_LABEL_SIZE = 11
ANNOTATION_SIZE = 7.8
COLORBAR_LABEL_SIZE = 7.5
COLORBAR_TICK_SIZE = 6.5

ANNOTATION_DECIMALS = 3
VMIN = 0.0
VMAX = 1.0
MISSING_COLOR = "#E6E6E6"
CELL_GRID_LINEWIDTH = 0.35
PANEL_BORDER_LINEWIDTH = 0.55

# Average row settings.
# Average is calculated independently for every metric/model as:
# sum(Type metric values) / number of available displayed Types.
AVERAGE_LABEL = "Average"
AVERAGE_GAP = 0.22
AVERAGE_LABEL_SIZE = 12
AVERAGE_ANNOTATION_SIZE = 7.8

METRIC_ORDER = ["Precision", "Recall", "F1"]

# DNA uses a restrained light-orange gradient.
# Protein remains the original Matplotlib "Blues" colormap.
DNA_LIGHT_ORANGE_CMAP = LinearSegmentedColormap.from_list(
    "DNA_LightOrange",
    [
        "#FFF9F4",
        "#FCEBDD",
        "#F8D7BE",
        "#F3BE96",
        "#EDA36F",
    ],
)

MODALITY_SETTINGS = {
    "LongAA": {
        "display": "Protein",
        "models": ["ARGNet", "DeepARG", "Fungenetyper", "PLM-ARG", "ARGScope"],
        "cmap": "Blues",
    },
    "LongNT": {
        "display": "DNA",
        "models": ["ARGNet", "DeepARG", "Fungenetyper", "ARGScope"],
        "cmap": DNA_LIGHT_ORANGE_CMAP,
    },
}


# =============================================================================
# 3. Fixed common 18 ARG Types
# =============================================================================
TYPE_ORDER = [
    "vancomycin",
    "trimethoprim",
    "tetracycline",
    "sulfonamide",
    "streptothricin",
    "rifamycin",
    "quinolone",
    "polymyxin",
    "novobiocin",
    "multidrug",
    "MLS",
    "fusidic_acid",
    "fosfomycin",
    "chloramphenicol",
    "bleomycin",
    "beta_lactam",
    "bacitracin",
    "aminoglycoside",
]

# IMPORTANT:
# Average 仍然使用上面的 18 个 Type（包括 bleomycin）。
# 这里只控制主热图实际显示的 Type，bleomycin 不画出来。
DISPLAY_TYPE_ORDER = [
    type_name for type_name in TYPE_ORDER
    if type_name != "bleomycin"
]

TYPE_DISPLAY = {x: x for x in TYPE_ORDER}


# =============================================================================
# 4. Type-name normalization
# =============================================================================
TYPE_MAPPING = {
    "mls": "MLS",
    "macrolide_lincosamide_streptogramin": "MLS",
    "macrolide_lincosamide_streptogramins": "MLS",

    "beta_lactam": "beta_lactam",
    "beta_lactams": "beta_lactam",
    "betalactam": "beta_lactam",
    "betalactams": "beta_lactam",

    "multidrug": "multidrug",
    "multi_drug": "multidrug",
    "multi_drug_resistance": "multidrug",

    "sulfonamide": "sulfonamide",
    "sulfonamides": "sulfonamide",

    "tetracycline": "tetracycline",
    "tetracyclines": "tetracycline",

    "aminoglycoside": "aminoglycoside",
    "aminoglycosides": "aminoglycoside",

    "rifamycin": "rifamycin",
    "rifampin": "rifamycin",
    "rifampicin": "rifamycin",

    "fosfomycin": "fosfomycin",

    "vancomycin": "vancomycin",
    "glycopeptide": "vancomycin",
    "glycopeptides": "vancomycin",

    "polymyxin": "polymyxin",
    "polymyxins": "polymyxin",

    "quinolone": "quinolone",
    "quinolones": "quinolone",
    "fluoroquinolone": "quinolone",
    "fluoroquinolones": "quinolone",

    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "phenicols": "chloramphenicol",

    "trimethoprim": "trimethoprim",
    "diaminopyrimidine": "trimethoprim",
    "diaminopyrimidines": "trimethoprim",

    "novobiocin": "novobiocin",
    "bleomycin": "bleomycin",
    "bacitracin": "bacitracin",
    "fusidic_acid": "fusidic_acid",
    "fusidicacid": "fusidic_acid",
    "streptothricin": "streptothricin",
}

TYPE_CANDIDATES = [
    "Type", "type", "class_name", "class", "label", "category", "arg_type"
]

METRIC_CANDIDATES = {
    "Precision": ["Precision", "precision", "PRECISION", "prec"],
    "Recall": ["Recall", "recall", "RECALL", "rec"],
    "F1": ["F1", "f1", "F1-score", "f1-score", "f1_score", "F1_score"],
}


# =============================================================================
# 5. Helpers
# =============================================================================
def clean_text(value):
    if pd.isna(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def canonical_token(value):
    text = clean_text(value).lower()
    text = text.replace("%", "pct")
    text = re.sub(r"[\s/:._-]+", "_", text)
    text = re.sub(r"[^a-z0-9_]", "", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def canonical_type(value):
    raw = clean_text(value)
    token = canonical_token(raw)
    return TYPE_MAPPING.get(token, raw)


def is_summary_row(value):
    token = canonical_token(value)
    if token in {
        "", "accuracy", "overall", "all", "total", "mean",
        "macro_avg", "micro_avg", "weighted_avg",
        "macro_average", "micro_average", "weighted_average",
        "average", "nan", "none", "null", "nonarg", "non_arg",
    }:
        return True
    return any(x in token for x in ["macro", "micro", "weighted", "overall", "average"])


def find_column(columns, candidates):
    mapping = {canonical_token(c): str(c) for c in columns}
    for candidate in candidates:
        key = canonical_token(candidate)
        if key in mapping:
            return mapping[key]
    return None


def numeric_series(series):
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    return pd.to_numeric(
        series.astype(str).str.strip().str.replace("%", "", regex=False),
        errors="coerce",
    )


def normalize_metric_scale(series):
    values = pd.to_numeric(series, errors="coerce")
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return values
    max_abs = float(np.nanmax(np.abs(finite.to_numpy(dtype=float))))
    if 1.5 < max_abs <= 100.5:
        return values / 100.0
    return values


def read_csv_flexible(path: Path):
    messages = []
    for encoding in ["utf-8-sig", "utf-8", "gbk", "latin-1"]:
        try:
            df = pd.read_csv(path, sep=None, engine="python", encoding=encoding)
            df.columns = [clean_text(c) for c in df.columns]
            return df
        except Exception as exc:
            messages.append(f"{encoding}: {type(exc).__name__}: {exc}")
    raise RuntimeError("Cannot read: %s\n%s" % (path, "\n".join(messages)))


def detect_type_column(df):
    found = find_column(df.columns, TYPE_CANDIDATES)
    if found is not None:
        return found

    for column in df.columns:
        if df[column].dtype == object:
            values = df[column].dropna().map(clean_text)
            if values.nunique() >= 5:
                return str(column)
    return None


# =============================================================================
# 6. File metadata
# =============================================================================
def infer_model(path: Path):
    text = str(path).lower()
    token_text = canonical_token(str(path))

    if "argscope" in text:
        return "ARGScope"
    if "argnet" in text:
        return "ARGNet"
    if "deeparg" in text:
        return "DeepARG"
    if "fungenetyper" in text or "fungentyper" in text:
        return "Fungenetyper"
    if (
        "plm-arg" in text
        or "plm_arg" in text
        or "plmarg" in text
        or "plm_arg" in token_text
        or "plmarg" in token_text
    ):
        return "PLM-ARG"
    return None


def infer_modality(path: Path, model: str | None):
    text = str(path).lower()
    name = path.name.lower()

    # Strong folder/file signals first.
    if "longaa" in text:
        return "LongAA"
    if "longnt" in text:
        return "LongNT"

    if "protein" in name:
        return "LongAA"
    if "dna" in name:
        return "LongNT"

    # PLM-ARG is protein-only in this comparison.
    if model == "PLM-ARG":
        return "LongAA"

    return None


def is_100pct_file(path: Path, modality: str):
    name = path.name.lower().replace(" ", "")

    explicit_100 = bool(
        re.search(r"(?<!\d)100%(?!\d)", name)
        or re.search(r"(?<!\d)100pct(?!\d)", name)
        or re.search(r"(?<!\d)100p(?![a-z0-9])", name)
    )

    # New DeepARG full-length fixed18 names.
    if modality == "LongAA" and "protein_all" in name:
        return True
    if modality == "LongNT" and "dna_all" in name:
        return True

    # Some full-length summary files use longaa/longnt in the file name.
    if modality == "LongAA" and "longaa" in name:
        return True
    if modality == "LongNT" and "longnt" in name:
        return True

    return explicit_100


def candidate_score(path: Path, model: str, modality: str):
    name = path.name.lower()
    full = str(path).lower()
    score = 0

    preferred = {
        ("LongAA", "ARGNet"): [
            "protein_100pct_argnet-l_classification_report_fixed18.csv",
        ],
        ("LongNT", "ARGNet"): [
            "dna_100pct_argnet-l_classification_report_fixed18.csv",
        ],
        ("LongAA", "DeepARG"): [
            "deeparg_type_protein_all_classification_report.csv",
            "deeparg_type_protein_all_per_type_5metrics.csv",
            "deeparg_type_protein_all_per_class_metrics.csv",
        ],
        ("LongNT", "DeepARG"): [
            "deeparg_type_dna_all_classification_report.csv",
            "deeparg_type_dna_all_per_type_5metrics.csv",
            "deeparg_type_dna_all_per_class_metrics.csv",
        ],
        ("LongAA", "Fungenetyper"): [
            "100p_type_classification_report.csv",
        ],
        ("LongNT", "Fungenetyper"): [
            "100p_type_classification_report.csv",
        ],
        ("LongAA", "PLM-ARG"): [
            "100p_pertype_metrics_arg_only.csv",
        ],
        ("LongAA", "ARGScope"): [
            "protein_100%_type_level_metrics.csv",
            "protein_100pct_type_level_metrics.csv",
            "100p_coverage_type_metrics.csv",
        ],
        ("LongNT", "ARGScope"): [
            "dna_100%_type_level_metrics.csv",
            "dna_100pct_type_level_metrics.csv",
            "dna_100%_per_type_metrics.csv",
            "dna_100pct_per_type_metrics.csv",
            "100p_coverage_type_metrics.csv",
        ],
    }

    if name in preferred.get((modality, model), []):
        score += 200

    if "100" in name:
        score += 30
    if "_all" in name:
        score += 25
    if "type" in name:
        score += 15
    if "metric" in name:
        score += 12
    if "classification_report" in name:
        score += 10
    if "arg_only" in name:
        score += 15

    if modality == "LongAA" and "longaa" in full:
        score += 20
    if modality == "LongNT" and "longnt" in full:
        score += 20

    # Penalize raw/intermediate outputs.
    if "including_nonarg" in name:
        score -= 80
    if "prediction" in name:
        score -= 40
    if "confusion" in name:
        score -= 50
    if "summary" in name and "metric" not in name:
        score -= 15

    return score


def collect_100pct_files(root_dir: Path):
    by_key = {}

    for modality, settings in MODALITY_SETTINGS.items():
        for model in settings["models"]:
            by_key[(modality, model)] = []

    for path in root_dir.rglob("*.csv"):
        if not path.is_file():
            continue
        if OUTDIR in path.parents:
            continue

        model = infer_model(path)
        if model is None:
            continue

        modality = infer_modality(path, model)
        if modality not in MODALITY_SETTINGS:
            continue
        if model not in MODALITY_SETTINGS[modality]["models"]:
            continue
        if not is_100pct_file(path, modality):
            continue

        by_key[(modality, model)].append(path)

    selected = {}

    for key, candidates in by_key.items():
        modality, model = key
        if not candidates:
            continue

        candidates = sorted(
            candidates,
            key=lambda p: (
                candidate_score(p, model, modality),
                -len(p.parts),
                str(p),
            ),
            reverse=True,
        )
        selected[key] = candidates[0]

    return selected, by_key


# =============================================================================
# 7. Standardize one per-Type file
# =============================================================================
def standardize_per_type_file(path: Path, model: str, modality: str):
    raw = read_csv_flexible(path)
    type_col = detect_type_column(raw)
    if type_col is None:
        raise ValueError("No Type column found. Columns=%s" % raw.columns.tolist())

    output = pd.DataFrame({
        "Type": raw[type_col].map(clean_text).map(canonical_type),
    })

    for metric in METRIC_ORDER:
        col = find_column(raw.columns, METRIC_CANDIDATES[metric])
        if col is None:
            output[metric] = np.nan
        else:
            output[metric] = normalize_metric_scale(numeric_series(raw[col]))

    output = output[~output["Type"].map(is_summary_row)].copy()
    output = output[output["Type"].isin(TYPE_ORDER)].copy()

    output = (
        output.groupby("Type", as_index=False)[METRIC_ORDER]
        .mean()
    )

    output["model"] = model
    output["modality"] = modality
    output["source_file"] = str(path.resolve())
    return output


# =============================================================================
# 8. Build master table
# =============================================================================
def build_master(root_dir: Path):
    selected, all_candidates = collect_100pct_files(root_dir)

    print("=" * 112)
    print("Protein + DNA 100% Type-level Precision / Recall / F1 heatmaps")
    print("=" * 112)
    print("ROOT_DIR:", root_dir)
    print("OUTDIR  :", OUTDIR)

    rows = []
    audit_rows = []

    for modality, settings in MODALITY_SETTINGS.items():
        print("\nSelected %s 100%% files:" % settings["display"])

        for model in settings["models"]:
            key = (modality, model)
            path = selected.get(key)

            if path is None:
                print("  %-14s NOT FOUND" % (model + ":"))
                audit_rows.append({
                    "modality": modality,
                    "model": model,
                    "selected_file": "",
                    "n_types_read": 0,
                    "available_metrics": "",
                })
                continue

            print("  %-14s %s" % (model + ":", path))

            try:
                table = standardize_per_type_file(path, model, modality)
                rows.append(table)

                audit_rows.append({
                    "modality": modality,
                    "model": model,
                    "selected_file": str(path),
                    "n_types_read": int(table["Type"].nunique()),
                    "available_metrics": ";".join(
                        metric
                        for metric in METRIC_ORDER
                        if table[metric].notna().any()
                    ),
                })
            except Exception as exc:
                print("    [ERROR] %s: %s" % (type(exc).__name__, exc))
                audit_rows.append({
                    "modality": modality,
                    "model": model,
                    "selected_file": str(path),
                    "n_types_read": 0,
                    "available_metrics": "ERROR: %s" % exc,
                })

    if not rows:
        raise RuntimeError("No usable Protein/DNA 100% per-Type CSV files were read.")

    master = pd.concat(rows, ignore_index=True)

    pd.DataFrame(audit_rows).to_csv(
        OUTDIR / "Protein_DNA_100pct_selected_source_files.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return master


# =============================================================================
# 9. Heatmap matrix
# =============================================================================
def present_models(master: pd.DataFrame, modality: str):
    preferred = MODALITY_SETTINGS[modality]["models"]
    present = set(
        master.loc[master["modality"] == modality, "model"].astype(str)
    )
    return [model for model in preferred if model in present]


def build_metric_matrix(master: pd.DataFrame, modality: str, metric: str, models):
    subset = master[
        (master["modality"] == modality)
    ][["Type", "model", metric]].copy()

    pivot = subset.pivot_table(
        index="Type",
        columns="model",
        values=metric,
        aggfunc="mean",
    )

    return pivot.reindex(index=TYPE_ORDER, columns=models)


# =============================================================================
# 10. Draw main Type heatmap + separated Average row
# =============================================================================
def _make_cmap(cmap_spec):
    # cmap_spec may be either a Matplotlib colormap name (Protein)
    # or a custom Colormap object (DNA).
    if isinstance(cmap_spec, str):
        cmap = plt.get_cmap(cmap_spec).copy()
    else:
        cmap = cmap_spec.copy()
    cmap.set_bad(MISSING_COLOR)
    return cmap


def _annotation_color(value: float) -> str:
    return "white" if value >= 0.62 else "#1F1F1F"


def draw_average_row(
    ax,
    average_values: pd.Series,
    metric: str,
    models,
    cmap_name: str,
    show_ylabel: bool,
):
    """Draw one separated Average row above the main Type heatmap."""
    arr = np.asarray(
        [[average_values.get(model, np.nan) for model in models]],
        dtype=float,
    )
    masked = np.ma.masked_invalid(arr)

    im = ax.imshow(
        masked,
        cmap=_make_cmap(cmap_name),
        vmin=VMIN,
        vmax=VMAX,
        aspect="auto",
        interpolation="nearest",
    )

    # Metric title is attached to the Average row so the title remains above
    # the complete panel (Average + main Type heatmap).
    ax.set_title(metric, fontsize=PANEL_TITLE_SIZE, pad=4.0)

    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels([])
    ax.tick_params(axis="x", which="major", length=0)

    ax.set_yticks([0])
    if show_ylabel:
        ax.set_yticklabels([AVERAGE_LABEL], fontsize=AVERAGE_LABEL_SIZE)
    else:
        ax.set_yticklabels([])
    ax.tick_params(axis="y", which="major", length=0, pad=2.5)

    # Cell borders, identical to the main heatmap.
    ax.set_xticks(np.arange(-0.5, len(models), 1), minor=True)
    ax.set_yticks([-0.5, 0.5], minor=True)
    ax.grid(
        which="minor",
        color="black",
        linestyle="-",
        linewidth=CELL_GRID_LINEWIDTH,
        alpha=0.9,
    )
    ax.tick_params(which="minor", bottom=False, left=False)

    for j, model in enumerate(models):
        value = arr[0, j]
        if np.isnan(value):
            continue

        ax.text(
            j,
            0,
            f"{value:.{ANNOTATION_DECIMALS}f}",
            ha="center",
            va="center",
            fontsize=AVERAGE_ANNOTATION_SIZE,
            color=_annotation_color(value),
            fontweight="bold" if model == "ARGScope" else "normal",
            clip_on=True,
        )

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(PANEL_BORDER_LINEWIDTH)
        spine.set_edgecolor("#000000")

    return im


def draw_heatmap_panel(
    ax,
    heat: pd.DataFrame,
    models,
    cmap_name: str,
    show_ylabels: bool,
):
    """Draw the visible-Type main heatmap below the separated Average row."""
    arr = heat.to_numpy(dtype=float)
    masked = np.ma.masked_invalid(arr)

    im = ax.imshow(
        masked,
        cmap=_make_cmap(cmap_name),
        vmin=VMIN,
        vmax=VMAX,
        aspect="auto",
        interpolation="nearest",
    )

    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels(
        models,
        rotation=45,
        ha="right",
        va="top",
        rotation_mode="anchor",
        fontsize=MODEL_LABEL_SIZE,
    )

    visible_types = heat.index.tolist()
    ax.set_yticks(np.arange(len(visible_types)))
    if show_ylabels:
        ax.set_yticklabels(
            [TYPE_DISPLAY.get(t, t) for t in visible_types],
            fontsize=TYPE_LABEL_SIZE,
        )
    else:
        ax.set_yticklabels([])

    ax.tick_params(axis="x", which="major", length=0, pad=2.0)
    ax.tick_params(axis="y", which="major", length=0, pad=2.5)

    ax.set_xticks(np.arange(-0.5, len(models), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(visible_types), 1), minor=True)
    ax.grid(
        which="minor",
        color="black",
        linestyle="-",
        linewidth=CELL_GRID_LINEWIDTH,
        alpha=0.9,
    )
    ax.tick_params(which="minor", bottom=False, left=False)

    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            value = arr[i, j]
            if np.isnan(value):
                continue

            ax.text(
                j,
                i,
                f"{value:.{ANNOTATION_DECIMALS}f}",
                ha="center",
                va="center",
                fontsize=ANNOTATION_SIZE,
                color=_annotation_color(value),
                fontweight="bold" if models[j] == "ARGScope" else "normal",
                clip_on=True,
            )

    for tick in ax.get_xticklabels():
        if tick.get_text() == "ARGScope":
            tick.set_color("#D62728")
            tick.set_fontweight("bold")

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(PANEL_BORDER_LINEWIDTH)
        spine.set_edgecolor("#000000")

    return im


def calculate_average_row(heat: pd.DataFrame) -> pd.Series:
    """
    Arithmetic mean across the fixed 18-Type set for each model.

    IMPORTANT:
    - Average calculation still uses all 18 Types, including bleomycin.
    - bleomycin is removed only from the visible main heatmap.

    Formula for one model/metric:
        Average = sum(valid values across the fixed 18 Types) / number of valid values

    Missing cells are not included in the denominator.
    """
    numeric = heat.apply(pd.to_numeric, errors="coerce")
    sums = numeric.sum(axis=0, skipna=True)
    counts = numeric.notna().sum(axis=0)
    return sums.div(counts.replace(0, np.nan))


# =============================================================================
# 11. Plot one modality -> one figure
# =============================================================================
def plot_one_modality(master: pd.DataFrame, modality: str):
    settings = MODALITY_SETTINGS[modality]
    display = settings["display"]
    models = present_models(master, modality)

    if not models:
        print("\n[Skip] No usable %s data." % display)
        return

    heatmaps = {
        metric: build_metric_matrix(master, modality, metric, models)
        for metric in METRIC_ORDER
    }

    # -------------------------------------------------------------------------
    # Average row: one arithmetic mean for each metric/model.
    # -------------------------------------------------------------------------
    averages = {
        metric: calculate_average_row(heat)
        for metric, heat in heatmaps.items()
    }

    # Main figure only: hide bleomycin AFTER Average has been calculated.
    # Therefore removing bleomycin from the figure does not change Average.
    display_heatmaps = {
        metric: heat.reindex(index=DISPLAY_TYPE_ORDER)
        for metric, heat in heatmaps.items()
    }

    average_rows = []
    for metric in METRIC_ORDER:
        for model in models:
            average_rows.append({
                "Modality": modality,
                "Metric": metric,
                "Model": model,
                "Average": averages[metric].get(model, np.nan),
                "N_Types_used": int(heatmaps[metric][model].notna().sum()),
            })

    pd.DataFrame(average_rows).to_csv(
        OUTDIR / f"{display}_100pct_PRF_Average_values.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Save the complete plotting values, including a distinct Average row.
    long_rows = []
    for metric, heat in display_heatmaps.items():
        for model in heat.columns:
            long_rows.append({
                "Modality": modality,
                "Metric": metric,
                "Type": AVERAGE_LABEL,
                "Model": model,
                "Value": averages[metric].get(model, np.nan),
            })

        for type_name in heat.index:
            for model in heat.columns:
                long_rows.append({
                    "Modality": modality,
                    "Metric": metric,
                    "Type": type_name,
                    "Model": model,
                    "Value": heat.loc[type_name, model],
                })

    pd.DataFrame(long_rows).to_csv(
        OUTDIR / f"{display}_100pct_PRF_values_with_Average_long.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n[%s Average rows]" % display)
    print(
        pd.DataFrame(average_rows)
        .pivot(index="Model", columns="Metric", values="Average")
        .reindex(models)
        .reindex(columns=METRIC_ORDER)
        .to_string(float_format=lambda x: f"{x:.4f}")
    )

    # Dynamic width: Protein normally has 5 models, DNA normally 3-4.
    panel_width = max(1.35, 0.34 * len(models))
    fig_width = 1.55 + 3 * panel_width + 0.45

    # Average remains based on 18 Types, while the visible main heatmap has 17 rows.
    fig_height = 6.55

    fig = plt.figure(figsize=(fig_width, fig_height))
    if TRANSPARENT_BG:
        fig.patch.set_alpha(0.0)

    # Two rows:
    #   row 0 = Average (one-cell high)
    #   row 1 = visible 17-Type main heatmap (bleomycin hidden)
    # A real GridSpec hspace creates a visible white/transparent gap, so the
    # Average row does not look attached to the main heatmap.
    gs = fig.add_gridspec(
        nrows=2,
        ncols=4,
        height_ratios=[1.0, float(len(DISPLAY_TYPE_ORDER))],
        width_ratios=[1, 1, 1, 0.045],
        left=min(0.22, 1.25 / fig_width),
        right=0.965,
        top=0.955,
        bottom=0.15,
        wspace=0.12,
        hspace=AVERAGE_GAP,
    )

    avg_axes = [fig.add_subplot(gs[0, i]) for i in range(3)]
    main_axes = [fig.add_subplot(gs[1, i]) for i in range(3)]
    cax = fig.add_subplot(gs[:, 3])

    last_im = None
    for idx, metric in enumerate(METRIC_ORDER):
        draw_average_row(
            avg_axes[idx],
            averages[metric],
            metric,
            models,
            settings["cmap"],
            show_ylabel=(idx == 0),
        )

        last_im = draw_heatmap_panel(
            main_axes[idx],
            display_heatmaps[metric],
            models,
            settings["cmap"],
            show_ylabels=(idx == 0),
        )

    cbar = fig.colorbar(
        last_im,
        cax=cax,
        ticks=np.linspace(VMIN, VMAX, 6),
    )
    cbar.set_label("Score", fontsize=COLORBAR_LABEL_SIZE, labelpad=4)
    cbar.ax.tick_params(
        labelsize=COLORBAR_TICK_SIZE,
        length=2.5,
        width=0.5,
        pad=2.0,
    )
    cbar.outline.set_linewidth(0.5)

    base = OUTDIR / f"{display}_100pct_PRF_heatmaps_noBleomycin_Average18"

    save_common = dict(
        bbox_inches="tight",
        pad_inches=0.03,
        transparent=TRANSPARENT_BG,
    )

    if SAVE_PNG:
        fig.savefig(str(base) + ".png", dpi=DPI, **save_common)
    if SAVE_TIF:
        fig.savefig(str(base) + ".tif", dpi=DPI, **save_common)
    if SAVE_PDF:
        fig.savefig(str(base) + ".pdf", **save_common)
    if SAVE_SVG:
        fig.savefig(str(base) + ".svg", **save_common)

    plt.close(fig)

    print("\n[Saved %s]" % display)
    print("  Models:", ", ".join(models))
    print(" ", str(base) + ".png")
    print(" ", str(base) + ".tif")
    print(" ", str(base) + ".pdf")
    print(" ", str(base) + ".svg")


# =============================================================================
# 12. Main
# =============================================================================
def main():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [FONT_FAMILY, "DejaVu Sans", "Liberation Sans"],
        "font.size": 7.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
        "savefig.facecolor": "none" if TRANSPARENT_BG else "white",
        "savefig.edgecolor": "none" if TRANSPARENT_BG else "white",
    })

    master = build_master(ROOT_DIR)

    print("\n[Per-model PRF data summary]")
    summary = (
        master.groupby(["modality", "model"])
        .agg(
            n_types=("Type", "nunique"),
            Precision=("Precision", lambda x: int(x.notna().sum())),
            Recall=("Recall", lambda x: int(x.notna().sum())),
            F1=("F1", lambda x: int(x.notna().sum())),
        )
        .reset_index()
    )
    print(summary.to_string(index=False))

    plot_one_modality(master, "LongAA")
    plot_one_modality(master, "LongNT")

    print("\n" + "=" * 112)
    print("Done.")
    print("Output directory:", OUTDIR)
    print("=" * 112)


if __name__ == "__main__":
    main()
