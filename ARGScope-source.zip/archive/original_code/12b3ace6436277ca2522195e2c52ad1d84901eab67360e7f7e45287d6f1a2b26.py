# -*- coding: utf-8 -*-
"""
ARGScope 150nt open-set ARG detector with in-dataset hard-negative mining
=======================================================================

Purpose
-------
Keep the existing 150nt ARGScope subtype model frozen and train a small,
independent binary detector for ARG/nonARG rejection.

This first version uses the nonARG rows already present in:
    3.150nt_ARG_DNA_with_label.csv

Main steps
----------
1. Load the frozen 150nt DNA student model and its scaler/encoder/prototypes.
2. Split the original training base IDs into detector-fit / early-validation /
   threshold-calibration groups.
3. Extract low-dimensional detection features from the frozen model.
4. Build a multi-center nonARG prototype bank from detector-fit nonARG rows.
5. Mine hard negatives among detector-fit nonARG rows.
6. Train a lightweight MLP detector with extra weight on hard negatives.
7. Select the best epoch using recall at low FPR on early-validation data.
8. Calibrate strict operating thresholds in false positives per million (FPM)
   on a separate calibration subset.
9. Evaluate the frozen detector on the existing short-read test split.

Important limitation
--------------------
This version reuses the current nonARG distribution. It improves the training
objective and calibration logic, but it cannot replace a future external,
large-scale hard-negative collection from real microbial background genes.

Expected files
--------------
BASE_DIR/
    train_set_shortread.csv
    test_set_shortread.csv
    3.150nt_ARG_DNA_with_label.csv
    ARGScope_150nt_DNA_gate_subtype_conservative_model/
        model_checkpoint.pth
        scaler_dna.joblib
        subtype_encoder.joblib
        dna_subtype_prototypes_512.csv   optional; checkpoint copy is preferred

Outputs
-------
BASE_DIR/ARGScope_150nt_open_set_detector_hardnegative/
    open_set_detector_checkpoint.pth
    detector_feature_scaler.joblib
    nonarg_prototypes_512.csv
    hard_negative_training_rows.csv
    detector_training_history.csv
    detector_thresholds_fppm.csv
    detector_metrics_summary.csv
    detector_early_validation_predictions.csv
    detector_calibration_predictions.csv
    detector_test_predictions.csv
    detector_feature_names.json
    run_info.json
"""

import os
import re
import json
import time
import copy
import random
import multiprocessing as mp
from pathlib import Path
from collections import Counter

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    roc_auc_score,
    average_precision_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# =========================================================
# 1. CONFIG
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

SOURCE_MODEL_DIR = BASE_DIR / "ARGScope_150nt_DNA_gate_subtype_conservative_model"
CHECKPOINT_FILE = SOURCE_MODEL_DIR / "model_checkpoint.pth"
SCALER_DNA_FILE = SOURCE_MODEL_DIR / "scaler_dna.joblib"
ENCODER_FILE = SOURCE_MODEL_DIR / "subtype_encoder.joblib"
ARG_PROTOTYPE_FILE = SOURCE_MODEL_DIR / "dna_subtype_prototypes_512.csv"

TRAIN_SPLIT_FILE = BASE_DIR / "train_set_shortread.csv"
TEST_SPLIT_FILE = BASE_DIR / "test_set_shortread.csv"
DNA_FEATURE_FILE = BASE_DIR / "3.150nt_ARG_DNA_with_label.csv"

OUTPUT_DIR = BASE_DIR / "ARGScope_150nt_open_set_detector_hardnegative"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SEED = 42

# Base-ID grouped detector split inside the original training set.
EARLY_VAL_BASE_RATIO = 0.15
CALIBRATION_BASE_RATIO = 0.15

# Frozen-model feature extraction.
EXTRACT_BATCH_SIZE = 512
NUM_WORKERS = 4
PIN_MEMORY = True

# nonARG prototype bank.
NONARG_PROTOTYPE_COUNT = 128
KMEANS_BATCH_SIZE = 8192
KMEANS_MAX_ITER = 200

# Hard-negative mining.
HARD_NEGATIVE_FRACTION = 0.40
HARD_NEGATIVE_WEIGHT = 4.0
MAX_HARD_NEGATIVE_ROWS_TO_SAVE = 50000

# Detector MLP.
DETECTOR_HIDDEN_1 = 64
DETECTOR_HIDDEN_2 = 32
DETECTOR_DROPOUT = 0.15
DETECTOR_BATCH_SIZE = 2048
DETECTOR_EPOCHS = 200
DETECTOR_LR = 3e-4
DETECTOR_WEIGHT_DECAY = 1e-4
DETECTOR_PATIENCE = 30
DETECTOR_MIN_DELTA = 1e-5

# Best epoch is selected using recall under this empirical validation FPR.
EARLY_STOP_TARGET_FPR = 0.001

# Final calibration operating points.
TARGET_FP_PER_MILLION = [10, 100, 1000, 5000]

# Save prediction tables rounded to this many decimals.
SAVE_DECIMALS = 8

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id",
    "Original_ID", "original_id", "read_id", "Read_ID",
]
SUBTYPE_COL = "Subtype"
TYPE_COL = "Type"

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()


# =========================================================
# 2. BASIC UTILS
# =========================================================

def log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True
    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def dataloader_kwargs():
    if NUM_WORKERS > 0:
        return {
            "num_workers": NUM_WORKERS,
            "pin_memory": PIN_MEMORY,
            "persistent_workers": True,
            "prefetch_factor": 2,
        }
    return {"num_workers": 0, "pin_memory": PIN_MEMORY}


def read_table(path, usecols=None, nrows=None):
    path = Path(path)
    sep = "\t" if path.suffix.lower() in [".tsv", ".txt"] else ","
    return pd.read_csv(path, sep=sep, usecols=usecols, nrows=nrows)


def find_key_col(columns_or_df):
    columns = columns_or_df.columns if hasattr(columns_or_df, "columns") else columns_or_df
    for c in KEY_CANDIDATES:
        if c in columns:
            return c
    return None


def normalize_key(s):
    return s.astype(str).str.strip()


def normalize_base_id_one(x):
    s = str(x).strip()
    s = re.sub(r"\s+", "", s)

    patterns = [
        r"(_90nt|_120nt|_150nt|_90bp|_120bp|_150bp)?(_part)[0-9]+$",
        r"(_nt90|_nt120|_nt150)?(_part)[0-9]+$",
        r"(_bp90|_bp120|_bp150)?(_part)[0-9]+$",
        r"(_frag)[0-9]+$",
        r"(_fragment)[0-9]+$",
        r"(_window)[0-9]+$",
        r"(_piece)[0-9]+$",
        r"(_segment)[0-9]+$",
        r"(_seg)[0-9]+$",
        r"(\.part)[0-9]+$",
        r"(-part)[0-9]+$",
        r"(_[1-5])$",
    ]

    for p in patterns:
        s2 = re.sub(p, "", s, flags=re.IGNORECASE)
        if s2 != s and len(s2) > 0:
            return s2
    return s


def infer_type_from_subtype(subtype):
    s = str(subtype)
    if s == "nonARG":
        return "nonARG"
    if "__" in s:
        return s.split("__", 1)[0]
    return "Unknown"


def l2_normalize_np(x, eps=1e-12):
    x = np.asarray(x, dtype=np.float32)
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + eps)


def make_binary_arg_labels(subtypes, types=None):
    subtypes = np.asarray(subtypes).astype(str)
    if types is None:
        types = np.array([infer_type_from_subtype(x) for x in subtypes], dtype=object)
    else:
        types = np.asarray(types).astype(str)

    return np.array([
        0 if (st == "nonARG" or tp == "nonARG") else 1
        for st, tp in zip(subtypes, types)
    ], dtype=np.int64)


def safe_json_value(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    return x


# =========================================================
# 3. FROZEN ARGScope MODEL
# =========================================================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])
        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = F.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=12.0, margin=0.10):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)
        self.scale = float(scale)
        self.margin = float(margin)

    def forward(self, z, labels=None):
        z = F.normalize(z, p=2, dim=1)
        w = F.normalize(self.weight, p=2, dim=1)
        return F.linear(z, w) * self.scale


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dim,
        num_classes,
        dna_hidden_dim,
        embed_dim,
        num_res_blocks,
        dropout,
        logit_scale,
        arcface_margin,
    ):
        super().__init__()
        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=dna_hidden_dim,
            embed_dim=embed_dim,
            dropout=dropout,
            num_blocks=num_res_blocks,
        )
        self.head = ArcMarginHead(
            embed_dim,
            num_classes,
            scale=logit_scale,
            margin=arcface_margin,
        )
        self.gate_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.LayerNorm(embed_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim // 2, 1),
        )

    def forward(self, x):
        z = self.encoder(x)
        logits_plain = self.head(z, labels=None)
        gate_logit = self.gate_head(z).squeeze(1)
        return logits_plain, z, gate_logit


class OpenSetDetector(nn.Module):
    def __init__(self, input_dim, hidden1=64, hidden2=32, dropout=0.15):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden1),
            nn.LayerNorm(hidden1),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2),
            nn.LayerNorm(hidden2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden2, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)


def load_frozen_model():
    if not CHECKPOINT_FILE.exists():
        raise FileNotFoundError(CHECKPOINT_FILE)
    if not SCALER_DNA_FILE.exists():
        raise FileNotFoundError(SCALER_DNA_FILE)
    if not ENCODER_FILE.exists():
        raise FileNotFoundError(ENCODER_FILE)

    checkpoint = torch.load(
        CHECKPOINT_FILE,
        map_location="cpu",
        weights_only=False,
    )
    scaler_dna = joblib.load(SCALER_DNA_FILE)
    encoder = joblib.load(ENCODER_FILE)

    model = DNAStudent(
        dna_dim=int(checkpoint["dna_dim"]),
        num_classes=int(checkpoint["num_classes"]),
        dna_hidden_dim=int(checkpoint.get("dna_hidden_dim", 1024)),
        embed_dim=int(checkpoint.get("embed_dim", 512)),
        num_res_blocks=int(checkpoint.get("num_res_blocks", 2)),
        dropout=float(checkpoint.get("dropout", 0.18)),
        logit_scale=float(checkpoint.get("logit_scale", 12.0)),
        arcface_margin=float(checkpoint.get("arcface_margin", 0.10)),
    )

    state_list = checkpoint.get("student_state_dicts")
    if not state_list:
        raise ValueError("Checkpoint has no student_state_dicts.")

    model.load_state_dict(state_list[0], strict=True)
    model.to(DEVICE)
    model.eval()
    for p in model.parameters():
        p.requires_grad = False

    feature_cols = list(checkpoint["dna_feature_cols"])
    subtype_classes = np.asarray(encoder.classes_).astype(str)

    if "dna_subtype_prototypes" in checkpoint:
        arg_prototypes_all = np.asarray(
            checkpoint["dna_subtype_prototypes"],
            dtype=np.float32,
        )
    elif ARG_PROTOTYPE_FILE.exists():
        proto_df = pd.read_csv(ARG_PROTOTYPE_FILE)
        dim_cols = [c for c in proto_df.columns if c.startswith("dim_")]
        arg_prototypes_all = proto_df[dim_cols].values.astype(np.float32)
    else:
        raise FileNotFoundError(
            "No dna_subtype_prototypes in checkpoint and no prototype CSV found."
        )

    arg_prototypes_all = l2_normalize_np(arg_prototypes_all)

    nonarg_matches = np.where(subtype_classes == "nonARG")[0]
    nonarg_class_id = int(nonarg_matches[0]) if len(nonarg_matches) > 0 else None

    arg_class_ids = np.array([
        i for i, st in enumerate(subtype_classes)
        if str(st) != "nonARG"
    ], dtype=np.int64)

    if len(arg_class_ids) == 0:
        raise ValueError("No ARG subtype classes remain after excluding nonARG.")

    temperature = float(
        checkpoint.get("config", {}).get("SUBTYPE_SOFTMAX_TEMPERATURE", 2.0)
    )

    log(f"Frozen model loaded from: {CHECKPOINT_FILE}")
    log(f"DNA dim: {checkpoint['dna_dim']}")
    log(f"Subtype classes: {len(subtype_classes)}")
    log(f"nonARG class id: {nonarg_class_id}")
    log(f"ARG class count: {len(arg_class_ids)}")
    log(f"Subtype softmax temperature: {temperature}")

    return {
        "checkpoint": checkpoint,
        "model": model,
        "scaler_dna": scaler_dna,
        "encoder": encoder,
        "feature_cols": feature_cols,
        "subtype_classes": subtype_classes,
        "arg_prototypes_all": arg_prototypes_all,
        "arg_class_ids": arg_class_ids,
        "nonarg_class_id": nonarg_class_id,
        "temperature": temperature,
    }


# =========================================================
# 4. DATA LOADING AND GROUPED SPLIT
# =========================================================

def load_split_file(path):
    df = read_table(path)
    key_col = find_key_col(df)
    if key_col is None:
        raise ValueError(f"No key column in {path}")
    df = df.rename(columns={key_col: "KEY"})
    df["KEY"] = normalize_key(df["KEY"])
    df["base_id"] = df["KEY"].map(normalize_base_id_one)

    if SUBTYPE_COL not in df.columns:
        raise ValueError(f"{path.name} has no {SUBTYPE_COL} column.")

    df[SUBTYPE_COL] = df[SUBTYPE_COL].astype(str).str.strip()
    if TYPE_COL not in df.columns:
        df[TYPE_COL] = df[SUBTYPE_COL].map(infer_type_from_subtype)
    else:
        df[TYPE_COL] = df[TYPE_COL].astype(str).str.strip()

    df = df.drop_duplicates(subset=["KEY"], keep="first").reset_index(drop=True)
    df["Arg_true"] = make_binary_arg_labels(df[SUBTYPE_COL], df[TYPE_COL])
    return df


def load_feature_table(feature_cols, train_split, test_split):
    header = read_table(DNA_FEATURE_FILE, nrows=0)
    key_col = find_key_col(header)
    if key_col is None:
        raise ValueError(f"No key column in {DNA_FEATURE_FILE}")

    missing = [c for c in feature_cols if c not in header.columns]
    if missing:
        raise ValueError(
            f"DNA feature file is missing {len(missing)} checkpoint feature columns. "
            f"First missing columns: {missing[:10]}"
        )

    usecols = [key_col] + feature_cols
    log(f"Reading DNA feature table with {len(usecols)} columns...")
    feat = read_table(DNA_FEATURE_FILE, usecols=usecols)
    feat = feat.rename(columns={key_col: "KEY"})
    feat["KEY"] = normalize_key(feat["KEY"])
    feat["base_id"] = feat["KEY"].map(normalize_base_id_one)

    if feat["KEY"].duplicated().any():
        log("Warning: duplicated feature KEY values detected; keeping first occurrence.")
        feat = feat.drop_duplicates(subset=["KEY"], keep="first").reset_index(drop=True)

    train_map = train_split[["KEY", "base_id", TYPE_COL, SUBTYPE_COL, "Arg_true"]].copy()
    test_map = test_split[["KEY", "base_id", TYPE_COL, SUBTYPE_COL, "Arg_true"]].copy()

    train_df = feat.merge(
        train_map.drop(columns=["base_id"]),
        on="KEY",
        how="inner",
        validate="one_to_one",
    )
    test_df = feat.merge(
        test_map.drop(columns=["base_id"]),
        on="KEY",
        how="inner",
        validate="one_to_one",
    )

    log(f"Feature rows total: {len(feat)}")
    log(f"Matched train rows: {len(train_df)} / {len(train_split)}")
    log(f"Matched test rows: {len(test_df)} / {len(test_split)}")
    log(f"Train ARG/nonARG: {int(train_df['Arg_true'].sum())}/{int((train_df['Arg_true']==0).sum())}")
    log(f"Test ARG/nonARG: {int(test_df['Arg_true'].sum())}/{int((test_df['Arg_true']==0).sum())}")

    if len(train_df) == 0 or len(test_df) == 0:
        raise ValueError("Feature matching produced an empty train or test table.")

    return train_df.reset_index(drop=True), test_df.reset_index(drop=True)


def make_detector_base_splits(train_df):
    base_table = (
        train_df.groupby("base_id", as_index=False)
        .agg(
            Arg_true=("Arg_true", lambda x: int(Counter(x.astype(int).tolist()).most_common(1)[0][0])),
            row_count=("KEY", "size"),
            label_unique=("Arg_true", "nunique"),
        )
    )

    inconsistent = int((base_table["label_unique"] > 1).sum())
    if inconsistent > 0:
        log(f"Warning: {inconsistent} base IDs have inconsistent binary labels; majority label used.")

    base_ids = base_table["base_id"].astype(str).values
    base_y = base_table["Arg_true"].astype(int).values

    temp_ratio = EARLY_VAL_BASE_RATIO + CALIBRATION_BASE_RATIO
    fit_ids, temp_ids, fit_y, temp_y = train_test_split(
        base_ids,
        base_y,
        test_size=temp_ratio,
        random_state=SEED,
        stratify=base_y,
    )

    cal_share_of_temp = CALIBRATION_BASE_RATIO / temp_ratio
    early_ids, cal_ids, _, _ = train_test_split(
        temp_ids,
        temp_y,
        test_size=cal_share_of_temp,
        random_state=SEED + 1,
        stratify=temp_y,
    )

    fit_ids = set(map(str, fit_ids))
    early_ids = set(map(str, early_ids))
    cal_ids = set(map(str, cal_ids))

    if fit_ids & early_ids or fit_ids & cal_ids or early_ids & cal_ids:
        raise RuntimeError("Detector base-ID split overlap detected.")

    train_df = train_df.copy()
    b = train_df["base_id"].astype(str)
    train_df["Detector_split"] = np.where(
        b.isin(fit_ids),
        "fit",
        np.where(b.isin(early_ids), "early_val", "calibration"),
    )

    for split_name in ["fit", "early_val", "calibration"]:
        sub = train_df[train_df["Detector_split"] == split_name]
        log(
            f"Detector {split_name}: rows={len(sub)}, base_ids={sub['base_id'].nunique()}, "
            f"ARG={int(sub['Arg_true'].sum())}, nonARG={int((sub['Arg_true']==0).sum())}"
        )

    return train_df


def to_scaled_matrix(df, feature_cols, scaler_dna):
    x = (
        df[feature_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )
    return scaler_dna.transform(x).astype(np.float32)


# =========================================================
# 5. FROZEN FEATURE EXTRACTION
# =========================================================

def extract_frozen_outputs(
    model,
    X,
    subtype_classes,
    arg_class_ids,
    nonarg_class_id,
    arg_prototypes_all,
    temperature,
):
    arg_prototypes = arg_prototypes_all[arg_class_ids]
    arg_proto_t = torch.tensor(arg_prototypes, dtype=torch.float32, device=DEVICE)

    nonarg_proto_t = None
    if nonarg_class_id is not None:
        nonarg_proto_t = torch.tensor(
            arg_prototypes_all[nonarg_class_id],
            dtype=torch.float32,
            device=DEVICE,
        )

    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=EXTRACT_BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs(),
    )

    chunks = {
        "z": [],
        "gate_logit": [],
        "gate_probability": [],
        "p_nonarg": [],
        "arg_probability_mass": [],
        "top1_arg_probability": [],
        "top2_arg_probability": [],
        "arg_probability_margin": [],
        "arg_vs_nonarg_probability_margin": [],
        "normalized_entropy": [],
        "predicted_arg_class_id": [],
        "predicted_arg_subtype": [],
        "max_arg_similarity": [],
        "second_arg_similarity": [],
        "arg_similarity_margin": [],
        "prob_pred_arg_similarity": [],
        "single_nonarg_class_similarity": [],
    }

    model.eval()
    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            logits, z, gate_logit = model(xb)
            logits = logits.float()
            z = z.float()
            gate_logit = gate_logit.float()

            probs = torch.softmax(logits / float(temperature), dim=1)
            arg_probs = probs[:, arg_class_ids]
            top2_arg = torch.topk(arg_probs, k=2, dim=1)

            top1_arg_prob = top2_arg.values[:, 0]
            top2_arg_prob = top2_arg.values[:, 1]
            top1_arg_local = top2_arg.indices[:, 0]
            top1_arg_global = torch.tensor(arg_class_ids, device=DEVICE)[top1_arg_local]

            if nonarg_class_id is not None:
                p_nonarg = probs[:, nonarg_class_id]
            else:
                p_nonarg = torch.zeros_like(top1_arg_prob)

            arg_mass = arg_probs.sum(dim=1)
            entropy = -torch.sum(probs * torch.log(probs + 1e-12), dim=1)
            entropy = entropy / np.log(probs.shape[1])

            arg_sims = torch.matmul(z, arg_proto_t.T)
            top2_sim = torch.topk(arg_sims, k=2, dim=1)
            max_arg_sim = top2_sim.values[:, 0]
            second_arg_sim = top2_sim.values[:, 1]

            prob_pred_proto = arg_proto_t[top1_arg_local]
            prob_pred_sim = torch.sum(z * prob_pred_proto, dim=1)

            if nonarg_proto_t is not None:
                single_nonarg_sim = torch.sum(z * nonarg_proto_t.view(1, -1), dim=1)
            else:
                single_nonarg_sim = torch.zeros_like(max_arg_sim)

            pred_subtypes = subtype_classes[top1_arg_global.detach().cpu().numpy()]

            chunks["z"].append(z.cpu().numpy().astype(np.float32))
            chunks["gate_logit"].append(gate_logit.cpu().numpy())
            chunks["gate_probability"].append(torch.sigmoid(gate_logit).cpu().numpy())
            chunks["p_nonarg"].append(p_nonarg.cpu().numpy())
            chunks["arg_probability_mass"].append(arg_mass.cpu().numpy())
            chunks["top1_arg_probability"].append(top1_arg_prob.cpu().numpy())
            chunks["top2_arg_probability"].append(top2_arg_prob.cpu().numpy())
            chunks["arg_probability_margin"].append((top1_arg_prob - top2_arg_prob).cpu().numpy())
            chunks["arg_vs_nonarg_probability_margin"].append((top1_arg_prob - p_nonarg).cpu().numpy())
            chunks["normalized_entropy"].append(entropy.cpu().numpy())
            chunks["predicted_arg_class_id"].append(top1_arg_global.cpu().numpy())
            chunks["predicted_arg_subtype"].append(pred_subtypes)
            chunks["max_arg_similarity"].append(max_arg_sim.cpu().numpy())
            chunks["second_arg_similarity"].append(second_arg_sim.cpu().numpy())
            chunks["arg_similarity_margin"].append((max_arg_sim - second_arg_sim).cpu().numpy())
            chunks["prob_pred_arg_similarity"].append(prob_pred_sim.cpu().numpy())
            chunks["single_nonarg_class_similarity"].append(single_nonarg_sim.cpu().numpy())

    out = {}
    for k, v in chunks.items():
        if k == "predicted_arg_subtype":
            out[k] = np.concatenate(v).astype(object)
        else:
            out[k] = np.concatenate(v)
    return out


def build_nonarg_prototypes(z_fit, y_fit):
    z_neg = z_fit[y_fit == 0]
    if len(z_neg) == 0:
        raise ValueError("No detector-fit nonARG embeddings available.")

    n_clusters = min(NONARG_PROTOTYPE_COUNT, len(z_neg))
    log(f"Building {n_clusters} nonARG prototypes from {len(z_neg)} fit negatives...")

    km = MiniBatchKMeans(
        n_clusters=n_clusters,
        random_state=SEED,
        batch_size=min(KMEANS_BATCH_SIZE, max(256, len(z_neg))),
        max_iter=KMEANS_MAX_ITER,
        n_init=3,
        reassignment_ratio=0.01,
        verbose=0,
    )
    km.fit(z_neg)
    centers = l2_normalize_np(km.cluster_centers_.astype(np.float32))

    proto_df = pd.DataFrame(
        centers,
        columns=[f"dim_{i}" for i in range(centers.shape[1])],
    )
    proto_df.insert(0, "prototype_id", np.arange(len(proto_df)))
    proto_df.to_csv(
        OUTPUT_DIR / "nonarg_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    return centers


def nearest_nonarg_similarity(z, nonarg_prototypes, batch_size=4096):
    proto_t = torch.tensor(nonarg_prototypes, dtype=torch.float32, device=DEVICE)
    outputs = []
    for start in range(0, len(z), batch_size):
        zb = torch.tensor(z[start:start + batch_size], dtype=torch.float32, device=DEVICE)
        sims = torch.matmul(zb, proto_t.T)
        outputs.append(sims.max(dim=1).values.cpu().numpy())
    return np.concatenate(outputs).astype(np.float32)


DETECTOR_FEATURE_NAMES = [
    "gate_logit",
    "gate_probability",
    "p_nonarg",
    "arg_probability_mass",
    "top1_arg_probability",
    "top2_arg_probability",
    "arg_probability_margin",
    "arg_vs_nonarg_probability_margin",
    "normalized_entropy",
    "max_arg_similarity",
    "second_arg_similarity",
    "arg_similarity_margin",
    "prob_pred_arg_similarity",
    "single_nonarg_class_similarity",
    "nearest_nonarg_bank_similarity",
    "arg_minus_nonarg_bank_similarity",
    "pred_arg_minus_nonarg_bank_similarity",
]


def assemble_detector_features(frozen_out, nonarg_prototypes):
    nearest_neg = nearest_nonarg_similarity(
        frozen_out["z"],
        nonarg_prototypes,
    )

    feature_dict = {
        "gate_logit": frozen_out["gate_logit"],
        "gate_probability": frozen_out["gate_probability"],
        "p_nonarg": frozen_out["p_nonarg"],
        "arg_probability_mass": frozen_out["arg_probability_mass"],
        "top1_arg_probability": frozen_out["top1_arg_probability"],
        "top2_arg_probability": frozen_out["top2_arg_probability"],
        "arg_probability_margin": frozen_out["arg_probability_margin"],
        "arg_vs_nonarg_probability_margin": frozen_out["arg_vs_nonarg_probability_margin"],
        "normalized_entropy": frozen_out["normalized_entropy"],
        "max_arg_similarity": frozen_out["max_arg_similarity"],
        "second_arg_similarity": frozen_out["second_arg_similarity"],
        "arg_similarity_margin": frozen_out["arg_similarity_margin"],
        "prob_pred_arg_similarity": frozen_out["prob_pred_arg_similarity"],
        "single_nonarg_class_similarity": frozen_out["single_nonarg_class_similarity"],
        "nearest_nonarg_bank_similarity": nearest_neg,
        "arg_minus_nonarg_bank_similarity": frozen_out["max_arg_similarity"] - nearest_neg,
        "pred_arg_minus_nonarg_bank_similarity": frozen_out["prob_pred_arg_similarity"] - nearest_neg,
    }

    X = np.column_stack([feature_dict[n] for n in DETECTOR_FEATURE_NAMES]).astype(np.float32)
    return X, feature_dict


# =========================================================
# 6. HARD-NEGATIVE MINING
# =========================================================

def rank01(x):
    s = pd.Series(np.asarray(x, dtype=float))
    return s.rank(method="average", pct=True).values.astype(np.float32)


def mine_hard_negatives(df_fit, feature_dict_fit):
    y = df_fit["Arg_true"].astype(int).values
    neg_idx = np.where(y == 0)[0]
    if len(neg_idx) == 0:
        raise ValueError("No nonARG rows for hard-negative mining.")

    hardness = (
        0.30 * rank01(feature_dict_fit["gate_probability"][neg_idx])
        + 0.25 * rank01(feature_dict_fit["top1_arg_probability"][neg_idx])
        + 0.25 * rank01(feature_dict_fit["max_arg_similarity"][neg_idx])
        + 0.20 * rank01(feature_dict_fit["arg_minus_nonarg_bank_similarity"][neg_idx])
    )

    n_hard = max(1, int(round(len(neg_idx) * HARD_NEGATIVE_FRACTION)))
    hard_local_order = np.argsort(hardness)[::-1]
    hard_neg_idx = neg_idx[hard_local_order[:n_hard]]

    hard_mask = np.zeros(len(df_fit), dtype=bool)
    hard_mask[hard_neg_idx] = True

    sample_weights = np.ones(len(df_fit), dtype=np.float32)
    sample_weights[hard_mask] = float(HARD_NEGATIVE_WEIGHT)

    save_order = hard_local_order[:min(n_hard, MAX_HARD_NEGATIVE_ROWS_TO_SAVE)]
    save_idx = neg_idx[save_order]

    hard_df = df_fit.iloc[save_idx][
        ["KEY", "base_id", TYPE_COL, SUBTYPE_COL, "Arg_true", "Detector_split"]
    ].copy()
    hard_df["hardness_score"] = hardness[save_order]

    for name in [
        "gate_probability",
        "p_nonarg",
        "top1_arg_probability",
        "arg_probability_margin",
        "max_arg_similarity",
        "nearest_nonarg_bank_similarity",
        "arg_minus_nonarg_bank_similarity",
    ]:
        hard_df[name] = feature_dict_fit[name][save_idx]

    hard_df = hard_df.sort_values("hardness_score", ascending=False).reset_index(drop=True)
    hard_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "hard_negative_training_rows.csv",
        index=False,
        encoding="utf-8-sig",
    )

    log(
        f"Hard negatives mined: {int(hard_mask.sum())} / {len(neg_idx)} nonARG "
        f"({HARD_NEGATIVE_FRACTION:.1%}); weight={HARD_NEGATIVE_WEIGHT}"
    )
    return hard_mask, sample_weights


# =========================================================
# 7. METRICS AND THRESHOLD CALIBRATION
# =========================================================

def binary_metrics(y_true, scores, threshold=0.5):
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)
    pred = (scores >= threshold).astype(int)

    tn = int(((y_true == 0) & (pred == 0)).sum())
    fp = int(((y_true == 0) & (pred == 1)).sum())
    fn = int(((y_true == 1) & (pred == 0)).sum())
    tp = int(((y_true == 1) & (pred == 1)).sum())

    fpr = fp / (fp + tn) if (fp + tn) > 0 else np.nan
    tpr = tp / (tp + fn) if (tp + fn) > 0 else np.nan

    try:
        roc_auc = roc_auc_score(y_true, scores)
    except Exception:
        roc_auc = np.nan
    try:
        auprc = average_precision_score(y_true, scores)
    except Exception:
        auprc = np.nan

    return {
        "threshold": float(threshold),
        "sample_count": int(len(y_true)),
        "positive_count": int((y_true == 1).sum()),
        "negative_count": int((y_true == 0).sum()),
        "pred_positive_count": int(pred.sum()),
        "ACC": accuracy_score(y_true, pred),
        "PRECISION": precision_score(y_true, pred, zero_division=0),
        "RECALL": recall_score(y_true, pred, zero_division=0),
        "F1": f1_score(y_true, pred, zero_division=0),
        "MCC": matthews_corrcoef(y_true, pred)
        if (len(np.unique(y_true)) > 1 or len(np.unique(pred)) > 1)
        else 0.0,
        "ROC_AUC": roc_auc,
        "AUPRC": auprc,
        "FPR": fpr,
        "TPR": tpr,
        "FP_per_million_negative": fpr * 1e6 if np.isfinite(fpr) else np.nan,
        "TP": tp,
        "FP": fp,
        "TN": tn,
        "FN": fn,
    }


def threshold_for_allowed_fp(y_true, scores, allowed_fp):
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)
    neg_scores = np.sort(scores[y_true == 0])[::-1]

    if len(neg_scores) == 0:
        raise ValueError("No negatives available for threshold calibration.")

    allowed_fp = int(max(0, min(allowed_fp, len(neg_scores))))

    if allowed_fp <= 0:
        threshold = float(np.nextafter(neg_scores[0], np.inf))
    elif allowed_fp >= len(neg_scores):
        threshold = float(-np.inf)
    else:
        # Threshold just above the (allowed_fp + 1)-th highest negative score.
        threshold = float(np.nextafter(neg_scores[allowed_fp], np.inf))

    return threshold


def calibrate_fppm_thresholds(y_true, scores, split_name="calibration"):
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)
    n_neg = int((y_true == 0).sum())
    if n_neg == 0:
        raise ValueError("Calibration set has no nonARG rows.")

    rows = []
    empirical_resolution_fpm = 1e6 / n_neg

    for target_fpm in TARGET_FP_PER_MILLION:
        target_fpr = target_fpm / 1e6
        allowed_fp = int(np.floor(target_fpr * n_neg + 1e-12))
        threshold = threshold_for_allowed_fp(y_true, scores, allowed_fp)
        row = binary_metrics(y_true, scores, threshold=threshold)
        row.update({
            "split": split_name,
            "target_FP_per_million": int(target_fpm),
            "target_FPR": float(target_fpr),
            "allowed_FP_by_sample_size": int(allowed_fp),
            "negative_count_for_calibration": n_neg,
            "empirical_resolution_FP_per_million": float(empirical_resolution_fpm),
            "resolution_limited": bool(target_fpm < empirical_resolution_fpm),
            "selection_rule": "maximum_recall_with_FP_not_exceeding_allowed_count",
        })
        rows.append(row)

    # Also save the conventional maximum-F1 threshold for diagnostic purposes.
    unique_scores = np.unique(scores)
    if len(unique_scores) > 5000:
        candidates = np.quantile(unique_scores, np.linspace(0, 1, 5000))
    else:
        candidates = unique_scores

    best = None
    for thr in candidates:
        m = binary_metrics(y_true, scores, threshold=float(thr))
        if best is None or (m["F1"], m["MCC"]) > (best["F1"], best["MCC"]):
            best = m
    best.update({
        "split": split_name,
        "target_FP_per_million": "max_F1_diagnostic",
        "target_FPR": np.nan,
        "allowed_FP_by_sample_size": np.nan,
        "negative_count_for_calibration": n_neg,
        "empirical_resolution_FP_per_million": float(empirical_resolution_fpm),
        "resolution_limited": False,
        "selection_rule": "maximum_F1_diagnostic_only",
    })
    rows.append(best)

    return pd.DataFrame(rows)


def low_fpr_recall_score(y_true, scores, target_fpr=0.001):
    y_true = np.asarray(y_true).astype(int)
    n_neg = int((y_true == 0).sum())
    if n_neg == 0:
        return 0.0, 0.0, np.inf

    allowed_fp = int(np.floor(target_fpr * n_neg + 1e-12))
    threshold = threshold_for_allowed_fp(y_true, scores, allowed_fp)
    m = binary_metrics(y_true, scores, threshold)
    return float(m["RECALL"]), float(m["AUPRC"]), float(threshold)


# =========================================================
# 8. DETECTOR TRAINING
# =========================================================

def make_detector_loader(X, y, sample_weights, shuffle=True):
    ds = TensorDataset(
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.float32),
        torch.tensor(sample_weights, dtype=torch.float32),
    )
    return DataLoader(
        ds,
        batch_size=DETECTOR_BATCH_SIZE,
        shuffle=shuffle,
        **dataloader_kwargs(),
    )


def predict_detector(model, X):
    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=DETECTOR_BATCH_SIZE,
        shuffle=False,
        **dataloader_kwargs(),
    )
    out = []
    model.eval()
    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            logits = model(xb)
            out.append(torch.sigmoid(logits.float()).cpu().numpy())
    return np.concatenate(out).astype(np.float32)


def train_detector(X_fit, y_fit, sw_fit, X_early, y_early):
    model = OpenSetDetector(
        input_dim=X_fit.shape[1],
        hidden1=DETECTOR_HIDDEN_1,
        hidden2=DETECTOR_HIDDEN_2,
        dropout=DETECTOR_DROPOUT,
    ).to(DEVICE)

    n_pos = max(1, int((y_fit == 1).sum()))
    n_neg = max(1, int((y_fit == 0).sum()))
    pos_weight_value = n_neg / n_pos
    pos_weight = torch.tensor(pos_weight_value, dtype=torch.float32, device=DEVICE)

    loader = make_detector_loader(X_fit, y_fit, sw_fit, shuffle=True)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=DETECTOR_LR,
        weight_decay=DETECTOR_WEIGHT_DECAY,
    )
    amp_scaler = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    best_score = -np.inf
    best_state = None
    no_improve = 0
    history = []

    for epoch in range(1, DETECTOR_EPOCHS + 1):
        model.train()
        total_loss = 0.0
        total_n = 0

        for xb, yb, wb in loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)
            wb = wb.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = model(xb)
                loss_each = F.binary_cross_entropy_with_logits(
                    logits.float(),
                    yb.float(),
                    pos_weight=pos_weight,
                    reduction="none",
                )
                loss = (loss_each * wb).mean()

            amp_scaler.scale(loss).backward()
            amp_scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            amp_scaler.step(optimizer)
            amp_scaler.update()

            total_loss += loss.item() * xb.size(0)
            total_n += xb.size(0)

        early_scores = predict_detector(model, X_early)
        low_recall, auprc, selected_thr = low_fpr_recall_score(
            y_early,
            early_scores,
            target_fpr=EARLY_STOP_TARGET_FPR,
        )
        early_m = binary_metrics(y_early, early_scores, threshold=selected_thr)

        # Low-FPR recall dominates model selection. AUPRC is a small tie-breaker.
        score = low_recall + 0.05 * auprc

        history.append({
            "epoch": epoch,
            "train_loss": total_loss / max(total_n, 1),
            "selection_score": score,
            "early_target_FPR": EARLY_STOP_TARGET_FPR,
            "early_threshold": selected_thr,
            "early_RECALL": early_m["RECALL"],
            "early_PRECISION": early_m["PRECISION"],
            "early_FPR": early_m["FPR"],
            "early_FP_per_million_negative": early_m["FP_per_million_negative"],
            "early_AUPRC": early_m["AUPRC"],
            "early_ROC_AUC": early_m["ROC_AUC"],
            "early_MCC": early_m["MCC"],
        })

        if score > best_score + DETECTOR_MIN_DELTA:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
            no_improve = 0
        else:
            no_improve += 1

        if epoch == 1 or epoch % 10 == 0 or epoch == DETECTOR_EPOCHS:
            log(
                f"Detector epoch {epoch:03d} | loss={total_loss/max(total_n,1):.6f} | "
                f"recall@FPR<={EARLY_STOP_TARGET_FPR:.4g}={early_m['RECALL']:.4f} | "
                f"precision={early_m['PRECISION']:.4f} | FPR={early_m['FPR']:.6f} | "
                f"AUPRC={early_m['AUPRC']:.4f}"
            )

        if no_improve >= DETECTOR_PATIENCE:
            log(f"Detector early stop at epoch {epoch}; best score={best_score:.6f}")
            break

    if best_state is None:
        raise RuntimeError("Detector training did not produce a best state.")
    model.load_state_dict(best_state)

    history_df = pd.DataFrame(history)
    history_df.to_csv(
        OUTPUT_DIR / "detector_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    return model, history_df, float(pos_weight_value)


# =========================================================
# 9. OUTPUT TABLES
# =========================================================

def make_prediction_table(df, frozen_out, feature_dict, detector_scores, split_name):
    out = df[["KEY", "base_id", TYPE_COL, SUBTYPE_COL, "Arg_true"]].copy()
    out.insert(0, "split", split_name)
    out["predicted_arg_subtype"] = frozen_out["predicted_arg_subtype"]

    for name in DETECTOR_FEATURE_NAMES:
        out[name] = feature_dict[name]

    out["open_set_detector_probability"] = detector_scores
    return out


def metrics_at_threshold_table(y_true, scores, thresholds_df, split_name):
    rows = []
    for _, thr_row in thresholds_df.iterrows():
        threshold = float(thr_row["threshold"])
        m = binary_metrics(y_true, scores, threshold=threshold)
        m.update({
            "split": split_name,
            "threshold_source": "calibration",
            "target_FP_per_million": thr_row["target_FP_per_million"],
            "calibration_resolution_limited": thr_row["resolution_limited"],
        })
        rows.append(m)
    return pd.DataFrame(rows)


# =========================================================
# 10. MAIN
# =========================================================

def main():
    seed_everything(SEED)

    log("============================================================")
    log("ARGScope 150nt open-set detector with hard-negative mining")
    log("Frozen source subtype model; no real metagenomic samples used")
    log("============================================================")
    log(f"BASE_DIR: {BASE_DIR}")
    log(f"OUTPUT_DIR: {OUTPUT_DIR}")
    log(f"DEVICE: {DEVICE}")
    if torch.cuda.is_available():
        log(f"GPU: {torch.cuda.get_device_name(0)}")
        log(f"CUDA: {torch.version.cuda}")

    frozen = load_frozen_model()

    train_split = load_split_file(TRAIN_SPLIT_FILE)
    test_split = load_split_file(TEST_SPLIT_FILE)
    log(f"Train split rows: {len(train_split)}, base IDs: {train_split['base_id'].nunique()}")
    log(f"Test split rows: {len(test_split)}, base IDs: {test_split['base_id'].nunique()}")

    train_df, test_df = load_feature_table(
        frozen["feature_cols"],
        train_split,
        test_split,
    )
    train_df = make_detector_base_splits(train_df)
    test_df["Detector_split"] = "test"

    # Scale the frozen DNA embeddings with the original scaler.
    log("Scaling original 768-dimensional DNA embeddings...")
    X_train_dna = to_scaled_matrix(
        train_df,
        frozen["feature_cols"],
        frozen["scaler_dna"],
    )
    X_test_dna = to_scaled_matrix(
        test_df,
        frozen["feature_cols"],
        frozen["scaler_dna"],
    )

    # Extract frozen model outputs once for train and test.
    log("Extracting frozen ARGScope outputs for training rows...")
    train_frozen = extract_frozen_outputs(
        frozen["model"],
        X_train_dna,
        frozen["subtype_classes"],
        frozen["arg_class_ids"],
        frozen["nonarg_class_id"],
        frozen["arg_prototypes_all"],
        frozen["temperature"],
    )

    log("Extracting frozen ARGScope outputs for test rows...")
    test_frozen = extract_frozen_outputs(
        frozen["model"],
        X_test_dna,
        frozen["subtype_classes"],
        frozen["arg_class_ids"],
        frozen["nonarg_class_id"],
        frozen["arg_prototypes_all"],
        frozen["temperature"],
    )

    split_arr = train_df["Detector_split"].astype(str).values
    fit_mask = split_arr == "fit"
    early_mask = split_arr == "early_val"
    cal_mask = split_arr == "calibration"

    y_train_all = train_df["Arg_true"].astype(int).values
    y_test = test_df["Arg_true"].astype(int).values

    # Build nonARG prototype bank from fit negatives only.
    nonarg_prototypes = build_nonarg_prototypes(
        train_frozen["z"][fit_mask],
        y_train_all[fit_mask],
    )

    log("Assembling detector features for training rows...")
    X_detector_all, feature_dict_train = assemble_detector_features(
        train_frozen,
        nonarg_prototypes,
    )
    log("Assembling detector features for test rows...")
    X_detector_test, feature_dict_test = assemble_detector_features(
        test_frozen,
        nonarg_prototypes,
    )

    with open(OUTPUT_DIR / "detector_feature_names.json", "w", encoding="utf-8") as f:
        json.dump(DETECTOR_FEATURE_NAMES, f, indent=2, ensure_ascii=False)

    # Fit feature scaler on detector-fit rows only.
    detector_scaler = StandardScaler()
    X_fit = detector_scaler.fit_transform(X_detector_all[fit_mask]).astype(np.float32)
    X_early = detector_scaler.transform(X_detector_all[early_mask]).astype(np.float32)
    X_cal = detector_scaler.transform(X_detector_all[cal_mask]).astype(np.float32)
    X_test = detector_scaler.transform(X_detector_test).astype(np.float32)
    joblib.dump(detector_scaler, OUTPUT_DIR / "detector_feature_scaler.joblib")

    y_fit = y_train_all[fit_mask]
    y_early = y_train_all[early_mask]
    y_cal = y_train_all[cal_mask]

    df_fit = train_df.loc[fit_mask].reset_index(drop=True)
    feature_dict_fit = {
        k: np.asarray(v)[fit_mask]
        for k, v in feature_dict_train.items()
    }

    hard_mask_fit, sample_weights_fit = mine_hard_negatives(
        df_fit,
        feature_dict_fit,
    )

    log("Training independent open-set detector...")
    detector, history_df, pos_weight_value = train_detector(
        X_fit,
        y_fit,
        sample_weights_fit,
        X_early,
        y_early,
    )

    scores_fit = predict_detector(detector, X_fit)
    scores_early = predict_detector(detector, X_early)
    scores_cal = predict_detector(detector, X_cal)
    scores_test = predict_detector(detector, X_test)

    # Strict threshold calibration on a subset not used for detector fitting or early stopping.
    thresholds_df = calibrate_fppm_thresholds(
        y_cal,
        scores_cal,
        split_name="calibration",
    )
    thresholds_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "detector_thresholds_fppm.csv",
        index=False,
        encoding="utf-8-sig",
    )

    log("Calibrated detector thresholds:")
    print(thresholds_df.to_string(index=False), flush=True)

    # Save prediction tables.
    early_df = train_df.loc[early_mask].reset_index(drop=True)
    cal_df = train_df.loc[cal_mask].reset_index(drop=True)

    early_frozen = {k: np.asarray(v)[early_mask] for k, v in train_frozen.items()}
    cal_frozen = {k: np.asarray(v)[cal_mask] for k, v in train_frozen.items()}
    early_features = {k: np.asarray(v)[early_mask] for k, v in feature_dict_train.items()}
    cal_features = {k: np.asarray(v)[cal_mask] for k, v in feature_dict_train.items()}

    early_pred_df = make_prediction_table(
        early_df,
        early_frozen,
        early_features,
        scores_early,
        "early_val",
    )
    cal_pred_df = make_prediction_table(
        cal_df,
        cal_frozen,
        cal_features,
        scores_cal,
        "calibration",
    )
    test_pred_df = make_prediction_table(
        test_df.reset_index(drop=True),
        test_frozen,
        feature_dict_test,
        scores_test,
        "test",
    )

    early_pred_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "detector_early_validation_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    cal_pred_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "detector_calibration_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    test_pred_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "detector_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Metrics at every calibrated operating point.
    metrics_parts = [
        metrics_at_threshold_table(y_cal, scores_cal, thresholds_df, "calibration"),
        metrics_at_threshold_table(y_test, scores_test, thresholds_df, "test"),
    ]

    # Add conventional 0.5 diagnostics for fit and early validation.
    for split_name, y_s, score_s in [
        ("fit", y_fit, scores_fit),
        ("early_val", y_early, scores_early),
    ]:
        m = binary_metrics(y_s, score_s, threshold=0.5)
        m.update({
            "split": split_name,
            "threshold_source": "fixed_0.5_diagnostic",
            "target_FP_per_million": "fixed_0.5",
            "calibration_resolution_limited": False,
        })
        metrics_parts.append(pd.DataFrame([m]))

    metrics_df = pd.concat(metrics_parts, ignore_index=True, sort=False)
    metrics_df.round(SAVE_DECIMALS).to_csv(
        OUTPUT_DIR / "detector_metrics_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Save checkpoint for later real-data inference.
    checkpoint_out = {
        "model_name": "ARGScope_150nt_open_set_detector_hardnegative",
        "source_model_checkpoint": str(CHECKPOINT_FILE),
        "detector_state_dict": detector.state_dict(),
        "detector_input_dim": int(X_fit.shape[1]),
        "detector_hidden_1": int(DETECTOR_HIDDEN_1),
        "detector_hidden_2": int(DETECTOR_HIDDEN_2),
        "detector_dropout": float(DETECTOR_DROPOUT),
        "detector_feature_names": DETECTOR_FEATURE_NAMES,
        "nonarg_prototypes": nonarg_prototypes.astype(np.float32),
        "arg_class_ids": frozen["arg_class_ids"].astype(np.int64),
        "nonarg_class_id": frozen["nonarg_class_id"],
        "subtype_classes": frozen["subtype_classes"].tolist(),
        "subtype_softmax_temperature": float(frozen["temperature"]),
        "thresholds_fppm": thresholds_df.to_dict(orient="records"),
        "hard_negative_fraction": float(HARD_NEGATIVE_FRACTION),
        "hard_negative_weight": float(HARD_NEGATIVE_WEIGHT),
        "binary_pos_weight": float(pos_weight_value),
        "seed": int(SEED),
    }
    torch.save(
        checkpoint_out,
        OUTPUT_DIR / "open_set_detector_checkpoint.pth",
    )

    run_info = {
        "base_dir": str(BASE_DIR),
        "output_dir": str(OUTPUT_DIR),
        "source_model_dir": str(SOURCE_MODEL_DIR),
        "dna_feature_file": str(DNA_FEATURE_FILE),
        "train_split_file": str(TRAIN_SPLIT_FILE),
        "test_split_file": str(TEST_SPLIT_FILE),
        "device": str(DEVICE),
        "train_rows": int(len(train_df)),
        "test_rows": int(len(test_df)),
        "detector_fit_rows": int(fit_mask.sum()),
        "detector_early_val_rows": int(early_mask.sum()),
        "detector_calibration_rows": int(cal_mask.sum()),
        "detector_fit_ARG": int(y_fit.sum()),
        "detector_fit_nonARG": int((y_fit == 0).sum()),
        "hard_negative_count": int(hard_mask_fit.sum()),
        "nonarg_prototype_count": int(len(nonarg_prototypes)),
        "detector_feature_count": int(len(DETECTOR_FEATURE_NAMES)),
        "detector_feature_names": DETECTOR_FEATURE_NAMES,
        "early_stop_target_fpr": float(EARLY_STOP_TARGET_FPR),
        "target_fp_per_million": TARGET_FP_PER_MILLION,
        "calibration_negative_count": int((y_cal == 0).sum()),
        "calibration_empirical_resolution_fpm": float(1e6 / max(1, int((y_cal == 0).sum()))),
        "limitation": (
            "This version mines hard negatives only from the existing 150nt nonARG rows. "
            "External diverse microbial hard negatives are still required for stronger "
            "real-metagenome FPR calibration."
        ),
    }

    with open(OUTPUT_DIR / "run_info.json", "w", encoding="utf-8") as f:
        json.dump(
            run_info,
            f,
            indent=2,
            ensure_ascii=False,
            default=safe_json_value,
        )

    log("============================================================")
    log("Done.")
    log(f"Saved outputs to: {OUTPUT_DIR}")
    log("Key outputs:")
    log(" - open_set_detector_checkpoint.pth")
    log(" - detector_feature_scaler.joblib")
    log(" - nonarg_prototypes_512.csv")
    log(" - hard_negative_training_rows.csv")
    log(" - detector_thresholds_fppm.csv")
    log(" - detector_metrics_summary.csv")
    log(" - detector_test_predictions.csv")
    log("============================================================")


if __name__ == "__main__":
    mp.freeze_support()
    main()
