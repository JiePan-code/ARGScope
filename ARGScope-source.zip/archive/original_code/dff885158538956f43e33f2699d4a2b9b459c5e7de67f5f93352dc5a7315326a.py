"""One-off final pipeline stage: await seed completion, aggregate and verify artifacts."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
SEEDS=(20260915,20261006,20261007)


def finished(seed):
    path=ROOT/f"seed_{seed}"/"completion.json"
    if not path.exists():
        return False
    try:
        obj=json.loads(path.read_text(encoding="utf-8"))
        return obj.get("complete") is True and obj.get("seed")==seed
    except json.JSONDecodeError:
        return False


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--check-now",action="store_true")
    args=parser.parse_args()
    pending=[s for s in SEEDS if not finished(s)]
    if args.check_now:
        print(json.dumps({"completed_seeds":[s for s in SEEDS if finished(s)],"pending_seeds":pending}))
        return
    results=ROOT/"Results"
    status_path=results/"finalization_status.json"
    status={"state":"awaiting_completed_seed_runs","complete":False,"seeds":list(SEEDS),
            "finalizer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    status_path.write_text(json.dumps(status,indent=2),encoding="utf-8")
    begun=time.monotonic()
    while not all(finished(s) for s in SEEDS):
        if time.monotonic()-begun>3*3600:
            raise TimeoutError("Seed runs did not all finish within the one-off pipeline limit.")
        time.sleep(10)
    environment=os.environ.copy()
    environment["PYTHONUTF8"]="1"
    environment["OMP_NUM_THREADS"]="2"
    steps=[("aggregate",["-c","import sys; sys.path.insert(0,sys.argv[1]); from run_bgc_normalized import aggregate; aggregate()",str(ROOT)]),
           ("independent_verification",[str(ROOT/"Verification/verify_results.py")]),
           ("readable_report",[str(ROOT/"Verification/write_readable_report.py")])]
    for name,arguments in steps:
        print("Final pipeline stage:",name,flush=True)
        with (results/f"{name}.log").open("w",encoding="utf-8") as log:
            subprocess.run([sys.executable,"-u","-X","utf8",*arguments],env=environment,
                           stdout=log,stderr=subprocess.STDOUT,check=True)
    status.update(state="complete_and_independently_verified",complete=True,
                  readable_report=str(results/"BGC规范化重跑结果.md"),
                  verification_utility_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/"Verification").glob("*.py")})
    status_path.write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
    print("ALL THREE SEEDS COMPLETED; RESULT REPORT INDEPENDENTLY VERIFIED.",flush=True)


if __name__=="__main__":
    try:
        main()
    except BaseException as error:
        path=ROOT/"Results/finalization_status.json"
        if path.exists():
            obj=json.loads(path.read_text(encoding="utf-8"))
            obj.update(state="failed_finalization",complete=False,error=repr(error))
            path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
        raise
