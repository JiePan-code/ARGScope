# -*- coding: utf-8 -*-
"""
Apply trained ARGScope multi-length DNA student model to 60p-90p DNA embeddings.

Input folder:
fusion_teacher_multilength_dna_student_outputs/

Required files:
- model_checkpoint.pth
- scaler_dna.joblib
- subtype_encoder.joblib
- 3.60p_ARG_DNA_with_label.csv
- 3.70p_ARG_DNA_with_label.csv
- 3.80p_ARG_DNA_with_label.csv
- 3.90p_ARG_DNA_with_label.csv

Output:
apply_multilength_model_60_90p_outputs/
"""

import random
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    classification_report,
)


# =========================================================
# 1. CONFIG
# =========================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# 如果脚本放在 fusion_teacher_multilength_dna_student_outputs 目录内
if (SCRIPT_DIR / "model_checkpoint.pth").exists():
    MODEL_DIR = SCRIPT_DIR
else:
    # 如果脚本放在上一级目录
    MODEL_DIR = SCRIPT_DIR / "fusion_teacher_multilength_dna_student_outputs"

OUTPUT_DIR = MODEL_DIR / "apply_multilength_model_60_90p_outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DNA_TEST_FILES = {
    "60p": MODEL_DIR / "3.60p_ARG_DNA_with_label.csv",
    "70p": MODEL_DIR / "3.70p_ARG_DNA_with_label.csv",
    "80p": MODEL_DIR / "3.80p_ARG_DNA_with_label.csv",
    "90p": MODEL_DIR / "3.90p_ARG_DNA_with_label.csv",
}

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id"
]

SUBTYPE_COL = "Subtype"
TYPE_COL = "Type"

BATCH_SIZE = 1024
NUM_WORKERS = 0
SEED = 42

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# =========================================================
# 2. Model parameters must match training code
# =========================================================

DNA_HIDDEN_DIM = 1024
EMBED_DIM = 512
NUM_RES_BLOCKS = 2
DROPOUT = 0.18

USE_ARCFACE = True
ARCFACE_MARGIN = 0.18
COSFACE_MARGIN = 0.18
LOGIT_SCALE = 30.0


# =========================================================
# 3. Utilities
# =========================================================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def normalize_key(s):
    return s.astype(str).str.strip()


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def compute_metrics(y_true, y_pred):
    return {
        "sample_count": int(len(y_true)),
        "subtype_count": int(len(np.unique(y_true))),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MICRO_PRECISION": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_RECALL": recall_score(y_true, y_pred, average="micro", zero_division=0),
        "MICRO_F1": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def print_metrics(title, metrics):
    print("\n" + title)
    for k, v in metrics.items():
        if isinstance(v, float) or isinstance(v, np.floating):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")


# =========================================================
# 4. Model definition
# =========================================================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()

        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])

        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = nn.functional.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=30.0, margin=0.20, easy_margin=False):
        super().__init__()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = scale
        self.margin = margin
        self.easy_margin = easy_margin

        self.cos_m = np.cos(margin)
        self.sin_m = np.sin(margin)
        self.th = np.cos(np.pi - margin)
        self.mm = np.sin(np.pi - margin) * margin

    def forward(self, z, labels=None):
        z = nn.functional.normalize(z, p=2, dim=1)
        w = nn.functional.normalize(self.weight, p=2, dim=1)

        cosine = nn.functional.linear(z, w)

        if labels is None:
            return cosine * self.scale

        cosine_float = cosine.float()

        if USE_ARCFACE:
            sine = torch.sqrt(torch.clamp(1.0 - torch.pow(cosine_float, 2), min=1e-7))
            phi = cosine_float * self.cos_m - sine * self.sin_m

            if self.easy_margin:
                phi = torch.where(cosine_float > 0, phi, cosine_float)
            else:
                phi = torch.where(cosine_float > self.th, phi, cosine_float - self.mm)
        else:
            phi = cosine_float - COSFACE_MARGIN

        one_hot = torch.zeros_like(cosine_float)
        one_hot.scatter_(1, labels.view(-1, 1), 1.0)

        output = (one_hot * phi) + ((1.0 - one_hot) * cosine_float)
        output = output * self.scale
        return output


class DNAStudent(nn.Module):
    def __init__(self, dna_dim, num_classes):
        super().__init__()

        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=DNA_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )

        self.head = ArcMarginHead(
            EMBED_DIM,
            num_classes,
            scale=LOGIT_SCALE,
            margin=ARCFACE_MARGIN,
        )

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


# =========================================================
# 5. Data loading
# =========================================================

def load_dna_file(path):
    if not path.exists():
        raise FileNotFoundError(f"Cannot find DNA test file: {path}")

    df = pd.read_csv(path)

    key_col = find_key_col(df, KEY_CANDIDATES)
    if key_col is None:
        raise ValueError(f"No key column found in {path.name}")

    df[key_col] = normalize_key(df[key_col])
    df = df.rename(columns={key_col: "KEY"})

    if df["KEY"].duplicated().sum() > 0:
        print(f"Warning: duplicated KEY in {path.name}: {df['KEY'].duplicated().sum()}, keep first.")
        df = df.drop_duplicates(subset=["KEY"], keep="first").copy()

    for col in [SUBTYPE_COL, TYPE_COL]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .replace(["nan", "None", "NAN", ""], "Unknown")
            )

    return df


# =========================================================
# 6. Prediction
# =========================================================

def predict_ensemble(models, X):
    probs_all = []

    loader = DataLoader(
        TensorDataset(torch.tensor(X, dtype=torch.float32)),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=torch.cuda.is_available(),
    )

    for model in models:
        model.eval()
        probs_this = []

        with torch.no_grad():
            for (xb,) in loader:
                xb = xb.to(DEVICE, non_blocking=True)

                _, logits_plain, _ = model(xb, labels=None)
                probs = torch.softmax(logits_plain.float(), dim=1)
                probs_this.append(probs.cpu().numpy())

        probs_all.append(np.concatenate(probs_this, axis=0))

    mean_probs = np.mean(np.stack(probs_all, axis=0), axis=0)
    pred = mean_probs.argmax(axis=1)

    sorted_probs = np.sort(mean_probs, axis=1)[:, ::-1]
    confidence = sorted_probs[:, 0]
    margin = sorted_probs[:, 0] - sorted_probs[:, 1]

    return pred, confidence, margin


# =========================================================
# 7. Main
# =========================================================

def main():
    seed_everything(SEED)

    print("Using device:", DEVICE)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    checkpoint_path = MODEL_DIR / "model_checkpoint.pth"
    scaler_path = MODEL_DIR / "scaler_dna.joblib"
    encoder_path = MODEL_DIR / "subtype_encoder.joblib"

    print("\nPath check:")
    print("MODEL_DIR:", MODEL_DIR)
    print("checkpoint:", checkpoint_path)
    print("scaler:", scaler_path)
    print("encoder:", encoder_path)

    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Cannot find checkpoint: {checkpoint_path}")
    if not scaler_path.exists():
        raise FileNotFoundError(f"Cannot find scaler: {scaler_path}")
    if not encoder_path.exists():
        raise FileNotFoundError(f"Cannot find encoder: {encoder_path}")

    print("\nLoading model checkpoint...")
    checkpoint = torch.load(
        checkpoint_path,
        map_location=DEVICE,
        weights_only=False,
    )

    scaler_dna = joblib.load(scaler_path)
    subtype_encoder = joblib.load(encoder_path)

    dna_feature_cols = checkpoint.get("dna_feature_cols", None)
    if dna_feature_cols is None:
        raise ValueError("checkpoint does not contain dna_feature_cols.")

    subtype_classes = list(subtype_encoder.classes_)
    num_classes = len(subtype_classes)
    dna_dim = int(checkpoint.get("dna_dim", len(dna_feature_cols)))

    print("DNA dim:", dna_dim)
    print("Feature columns:", len(dna_feature_cols))
    print("Subtype classes:", num_classes)

    student_state_dicts = checkpoint.get("student_state_dicts", None)
    if student_state_dicts is None:
        raise ValueError("checkpoint does not contain student_state_dicts.")

    models = []
    for i, sd in enumerate(student_state_dicts):
        model = DNAStudent(dna_dim=dna_dim, num_classes=num_classes).to(DEVICE)
        model.load_state_dict(sd, strict=True)
        model.eval()
        models.append(model)
        print(f"Loaded student model {i + 1}/{len(student_state_dicts)}")

    summary_rows = []

    for tag, path in DNA_TEST_FILES.items():
        print("\n============================================================")
        print(f"Testing {tag}: {path.name}")
        print("============================================================")

        df = load_dna_file(path)

        missing_cols = [c for c in dna_feature_cols if c not in df.columns]
        if len(missing_cols) > 0:
            raise ValueError(
                f"{path.name} missing {len(missing_cols)} feature columns. "
                f"Examples: {missing_cols[:10]}"
            )

        X_raw = to_float_matrix(df, dna_feature_cols)
        X = scaler_dna.transform(X_raw).astype(np.float32)

        print("Input shape:", df.shape)
        print("X:", X.shape)

        pred_ids, confidence, margin = predict_ensemble(models, X)
        pred_subtypes = subtype_encoder.inverse_transform(pred_ids)

        keep_cols = ["KEY"]
        if TYPE_COL in df.columns:
            keep_cols.append(TYPE_COL)
        if SUBTYPE_COL in df.columns:
            keep_cols.append(SUBTYPE_COL)

        pred_df = df[keep_cols].copy()
        pred_df["Pred_Subtype"] = pred_subtypes
        pred_df["subtype_confidence"] = confidence
        pred_df["subtype_margin"] = margin

        has_label = SUBTYPE_COL in pred_df.columns

        if has_label:
            known_mask = pred_df[SUBTYPE_COL].astype(str).isin(set(subtype_classes))
            before = len(pred_df)
            pred_df = pred_df[known_mask].reset_index(drop=True)

            if before != len(pred_df):
                print(f"Filtered unseen subtype: {before} -> {len(pred_df)}")

            y_true = subtype_encoder.transform(pred_df[SUBTYPE_COL].astype(str).values)
            y_pred = subtype_encoder.transform(pred_df["Pred_Subtype"].astype(str).values)

            pred_df["Subtype_correct"] = (
                pred_df[SUBTYPE_COL].astype(str).values
                == pred_df["Pred_Subtype"].astype(str).values
            )

            metrics = compute_metrics(y_true, y_pred)
            print_metrics(f"=== {tag} metrics ===", metrics)

            report = classification_report(
                pred_df[SUBTYPE_COL].astype(str).values,
                pred_df["Pred_Subtype"].astype(str).values,
                zero_division=0,
                digits=4,
                output_dict=True,
            )

            report_df = (
                pd.DataFrame(report)
                .T
                .reset_index()
                .rename(columns={"index": "Subtype"})
            )

            report_df.to_csv(
                OUTPUT_DIR / f"classification_report_{tag}.csv",
                index=False,
                encoding="utf-8-sig",
            )

        else:
            print(f"{tag} has no Subtype column. Only prediction file will be saved.")
            metrics = {
                "sample_count": len(pred_df),
                "subtype_count": np.nan,
                "ACC": np.nan,
                "WEIGHTED_PRECISION": np.nan,
                "WEIGHTED_RECALL": np.nan,
                "WEIGHTED_F1": np.nan,
                "MACRO_PRECISION": np.nan,
                "MACRO_RECALL": np.nan,
                "MACRO_F1": np.nan,
                "MICRO_PRECISION": np.nan,
                "MICRO_RECALL": np.nan,
                "MICRO_F1": np.nan,
                "MCC": np.nan,
            }

        pred_df.round(6).to_csv(
            OUTPUT_DIR / f"predictions_{tag}.csv",
            index=False,
            encoding="utf-8-sig",
        )

        summary_rows.append({
            "test_data": tag,
            "input_file": path.name,
            **metrics,
        })

    summary_df = pd.DataFrame(summary_rows).round(4)
    summary_df.to_csv(
        OUTPUT_DIR / "summary_metrics_60_90p.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n============================================================")
    print("Saved outputs to:", OUTPUT_DIR.resolve())
    print("Main outputs:")
    print(" - summary_metrics_60_90p.csv")
    print(" - predictions_60p.csv")
    print(" - predictions_70p.csv")
    print(" - predictions_80p.csv")
    print(" - predictions_90p.csv")
    print(" - classification_report_60p.csv / 70p / 80p / 90p")
    print("Done.")
    print("============================================================")


if __name__ == "__main__":
    main()