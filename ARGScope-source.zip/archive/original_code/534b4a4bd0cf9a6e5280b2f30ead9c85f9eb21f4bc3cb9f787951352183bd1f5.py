import random
import pandas as pd

# =========================
# 输入输出文件
# =========================
PROTEIN_FASTA = "nonARG_protein.fasta"
DNA_FASTA = "nonARG_dna.fasta"

OUTPUT_PROTEIN_FASTA = "sampled_protein_13439.fasta"
OUTPUT_DNA_FASTA = "sampled_dna_13439.fasta"
OUTPUT_LABEL_CSV = "sampled_id_label_13439.csv"

# =========================
# 参数
# =========================
SAMPLE_N = 13439
RANDOM_SEED = 42

TYPE_VALUE = "nonARG"
SUBTYPE_VALUE = "nonARG"


def read_fasta(fasta_file):
    """
    读取 FASTA，返回:
    records: dict[id] = sequence
    """
    records = {}
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    seq_id = header.split()[0]
                    seq = "".join(seq_lines)
                    records[seq_id] = seq
                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line)

        if header is not None:
            seq_id = header.split()[0]
            seq = "".join(seq_lines)
            records[seq_id] = seq

    return records


def write_fasta(records, output_file, width=60):
    """
    records: list of (id, seq)
    """
    with open(output_file, "w", encoding="utf-8") as f:
        for seq_id, seq in records:
            f.write(f">{seq_id}\n")
            for i in range(0, len(seq), width):
                f.write(seq[i:i+width] + "\n")


def main():
    protein_dict = read_fasta(PROTEIN_FASTA)
    dna_dict = read_fasta(DNA_FASTA)

    protein_ids = set(protein_dict.keys())
    dna_ids = set(dna_dict.keys())

    common_ids = sorted(protein_ids & dna_ids)

    print(f"Protein records: {len(protein_dict)}")
    print(f"DNA records: {len(dna_dict)}")
    print(f"Common IDs: {len(common_ids)}")

    if len(common_ids) < SAMPLE_N:
        raise ValueError(
            f"共有 {len(common_ids)} 条可对应记录，小于要求抽取的 {SAMPLE_N} 条。"
        )

    random.seed(RANDOM_SEED)
    sampled_ids = random.sample(common_ids, SAMPLE_N)

    sampled_protein_records = [(seq_id, protein_dict[seq_id]) for seq_id in sampled_ids]
    sampled_dna_records = [(seq_id, dna_dict[seq_id]) for seq_id in sampled_ids]

    # 输出 fasta
    write_fasta(sampled_protein_records, OUTPUT_PROTEIN_FASTA)
    write_fasta(sampled_dna_records, OUTPUT_DNA_FASTA)

    # 输出 label 文件
    label_df = pd.DataFrame({
        "id": sampled_ids,
        "type": [TYPE_VALUE] * len(sampled_ids),
        "subtype": [SUBTYPE_VALUE] * len(sampled_ids)
    })
    label_df.to_csv(OUTPUT_LABEL_CSV, index=False)

    print("抽样完成。")
    print(f"Sampled: {len(sampled_ids)}")
    print(f"Protein FASTA: {OUTPUT_PROTEIN_FASTA}")
    print(f"DNA FASTA: {OUTPUT_DNA_FASTA}")
    print(f"Label CSV: {OUTPUT_LABEL_CSV}")


if __name__ == "__main__":
    main()