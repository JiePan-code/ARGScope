#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量计算 DNA 模型 60%、70%、80%、90% 和 100% 测试结果。

使用方法：
1. 把本脚本放在 5 个预测 CSV 所在的同一文件夹。
2. 直接运行本脚本。
3. 脚本会在同一目录创建 DNA_all_metrics_results 文件夹。

输出指标：Accuracy、Precision、Recall、F1、MCC。

总体结果：
- ARG/nonARG：macro、weighted、micro
- Type：macro、weighted、micro
- Subtype：macro、weighted、micro

逐 Type 结果：
- 每个 Type 采用 one-vs-rest 计算五种指标。

说明：
- 每个序列比例分别计算，不会把不同文件混在一起。
- 60%～90% 文件中的所有片段行都会进入相应比例的计算。
- Accuracy 和 multiclass MCC 是全局指标，不区分平均方式，
  所以在 macro、weighted、micro 三行中数值相同。
- 代码只使用 Python 标准库，不需要 pandas 或 scikit-learn。
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path
from typing import Iterable, Sequence


INPUT_FILES = (
    ("60%", "60%_fragment_predictions_test.csv"),
    ("70%", "70%_fragment_predictions_test.csv"),
    ("80%", "80%_fragment_predictions_test.csv"),
    ("90%", "90%_fragment_predictions_test.csv"),
    ("100%", "100%_test_sequence_predictions.csv"),
)

OUTPUT_DIR_NAME = "DNA_all_metrics_results"

REQUIRED_COLUMNS = (
    "true_ARG",
    "predicted_ARG",
    "true_type",
    "predicted_type",
    "true_subtype",
    "predicted_subtype",
)

AVERAGES = ("macro", "weighted", "micro")
METRIC_COLUMNS = ("accuracy", "precision", "recall", "f1", "mcc")


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description=(
            "批量计算 DNA 60%、70%、80%、90%、100% 的五种评价指标。"
        )
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=script_dir,
        help="五个输入 CSV 所在目录；默认是脚本所在目录。",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "结果目录；默认在输入目录下创建 "
            f"{OUTPUT_DIR_NAME}。"
        ),
    )
    return parser.parse_args()


def safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def sorted_labels(
    y_true: Iterable[str],
    y_pred: Iterable[str],
) -> list[str]:
    labels = set(y_true) | set(y_pred)
    return sorted(labels, key=lambda value: (value.casefold(), value))


def normalize_text_labels(
    values: Sequence[object],
    column_name: str,
    source_name: str,
) -> list[str]:
    result: list[str] = []
    for row_number, value in enumerate(values, start=2):
        if value is None or str(value).strip() == "":
            raise ValueError(
                f"{source_name} 的 {column_name!r} 列在 CSV 第 "
                f"{row_number} 行存在空标签。"
            )
        result.append(str(value).strip())
    return result


def normalize_arg_labels(
    values: Sequence[object],
    column_name: str,
    source_name: str,
) -> list[str]:
    """把常见二分类写法统一成 ARG 和 nonARG。"""
    arg_values = {
        "1",
        "1.0",
        "true",
        "arg",
        "positive",
        "pos",
        "yes",
    }
    nonarg_values = {
        "0",
        "0.0",
        "false",
        "nonarg",
        "non-arg",
        "negative",
        "neg",
        "no",
    }

    normalized: list[str] = []
    for row_number, value in enumerate(values, start=2):
        if value is None or str(value).strip() == "":
            raise ValueError(
                f"{source_name} 的 {column_name!r} 列在 CSV 第 "
                f"{row_number} 行存在空标签。"
            )

        text = str(value).strip()
        key = text.casefold().replace("_", "").replace(" ", "")
        if key in arg_values:
            normalized.append("ARG")
        elif key in nonarg_values:
            normalized.append("nonARG")
        else:
            raise ValueError(
                f"{source_name} 的 {column_name!r} 列在 CSV 第 "
                f"{row_number} 行存在无法识别的标签：{text!r}"
            )
    return normalized


def calculate_multiclass_mcc(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    labels: Sequence[str],
) -> float:
    """使用标准混淆矩阵公式计算 multiclass MCC。"""
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    correct = sum(true == pred for true, pred in zip(y_true, y_pred))

    sum_true_pred = sum(
        true_counts[label] * predicted_counts[label] for label in labels
    )
    sum_true_squared = sum(true_counts[label] ** 2 for label in labels)
    sum_pred_squared = sum(predicted_counts[label] ** 2 for label in labels)

    numerator = correct * n_samples - sum_true_pred
    denominator = math.sqrt(
        (n_samples**2 - sum_pred_squared)
        * (n_samples**2 - sum_true_squared)
    )
    return safe_divide(numerator, denominator)


def calculate_overall_metrics(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    level_name: str,
    condition: str,
    source_file: str,
) -> list[dict[str, object]]:
    """计算 macro、weighted、micro 三行总体指标。"""
    if len(y_true) != len(y_pred):
        raise ValueError(f"{source_file} 的真实标签与预测标签数量不一致。")
    if not y_true:
        raise ValueError(f"{source_file} 没有可计算的预测记录。")

    labels = sorted_labels(y_true, y_pred)
    n_samples = len(y_true)
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive = Counter(
        true for true, pred in zip(y_true, y_pred) if true == pred
    )

    correct = sum(true_positive.values())
    accuracy = safe_divide(correct, n_samples)
    mcc = calculate_multiclass_mcc(y_true, y_pred, labels)

    per_class: dict[str, dict[str, float]] = {}
    for label in labels:
        tp = true_positive[label]
        fp = predicted_counts[label] - tp
        fn = true_counts[label] - tp
        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)
        per_class[label] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": true_counts[label],
        }

    result: list[dict[str, object]] = []
    for average in AVERAGES:
        if average == "macro":
            precision = safe_divide(
                sum(per_class[label]["precision"] for label in labels),
                len(labels),
            )
            recall = safe_divide(
                sum(per_class[label]["recall"] for label in labels),
                len(labels),
            )
            f1 = safe_divide(
                sum(per_class[label]["f1"] for label in labels),
                len(labels),
            )
        elif average == "weighted":
            precision = safe_divide(
                sum(
                    per_class[label]["precision"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            recall = safe_divide(
                sum(
                    per_class[label]["recall"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
            f1 = safe_divide(
                sum(
                    per_class[label]["f1"]
                    * per_class[label]["support"]
                    for label in labels
                ),
                n_samples,
            )
        else:  # micro
            micro_tp = correct
            micro_fp = n_samples - correct
            micro_fn = n_samples - correct
            precision = safe_divide(micro_tp, micro_tp + micro_fp)
            recall = safe_divide(micro_tp, micro_tp + micro_fn)
            f1 = safe_divide(2 * precision * recall, precision + recall)

        result.append(
            {
                "condition": condition,
                "source_file": source_file,
                "level": level_name,
                "average": average,
                "n_samples": n_samples,
                "n_classes_union": len(labels),
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": mcc,
            }
        )

    return result


def calculate_binary_mcc(tp: int, fp: int, fn: int, tn: int) -> float:
    numerator = tp * tn - fp * fn
    denominator = math.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    )
    return safe_divide(numerator, denominator)


def calculate_each_type_metrics(
    true_type: Sequence[str],
    predicted_type: Sequence[str],
    condition: str,
    source_file: str,
) -> list[dict[str, object]]:
    """将每个 Type 分别作为正类，计算 one-vs-rest 五指标。"""
    labels = sorted_labels(true_type, predicted_type)
    n_samples = len(true_type)
    result: list[dict[str, object]] = []

    for label in labels:
        tp = fp = fn = tn = 0
        for true, pred in zip(true_type, predicted_type):
            true_is_label = true == label
            pred_is_label = pred == label

            if true_is_label and pred_is_label:
                tp += 1
            elif not true_is_label and pred_is_label:
                fp += 1
            elif true_is_label and not pred_is_label:
                fn += 1
            else:
                tn += 1

        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2 * precision * recall, precision + recall)

        result.append(
            {
                "condition": condition,
                "source_file": source_file,
                "type": label,
                "n_samples": n_samples,
                "true_support": tp + fn,
                "predicted_count": tp + fp,
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "tn": tn,
                "accuracy": safe_divide(tp + tn, n_samples),
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": calculate_binary_mcc(tp, fp, fn, tn),
            }
        )

    result.sort(
        key=lambda row: (
            -int(row["true_support"]),
            str(row["type"]).casefold(),
            str(row["type"]),
        )
    )
    return result


def read_prediction_rows(input_csv: Path) -> list[dict[str, str]]:
    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"{input_csv.name} 没有 CSV 表头。")

        fieldnames = [name.strip() for name in reader.fieldnames]
        missing_columns = [
            column for column in REQUIRED_COLUMNS if column not in fieldnames
        ]
        if missing_columns:
            raise ValueError(
                f"{input_csv.name} 缺少必要列："
                + ", ".join(missing_columns)
            )

        rows = list(reader)

    if not rows:
        raise ValueError(f"{input_csv.name} 没有数据行。")

    # 100% 文件含 split 列时只保留 test。片段文件没有 split 列，全部使用。
    if "split" in fieldnames:
        test_rows = [
            row
            for row in rows
            if str(row.get("split", "")).strip().casefold() == "test"
        ]
        if test_rows:
            rows = test_rows

    return rows


def rounded_row(row: dict[str, object]) -> dict[str, object]:
    result = dict(row)
    for column in METRIC_COLUMNS:
        if column in result:
            result[column] = round(float(result[column]), 6)
    return result


def save_csv(
    rows: Sequence[dict[str, object]],
    output_path: Path,
    fieldnames: Sequence[str],
) -> None:
    with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rounded_row(row) for row in rows)


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.expanduser().resolve()
    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else input_dir / OUTPUT_DIR_NAME
    )

    if not input_dir.is_dir():
        raise NotADirectoryError(f"输入目录不存在：{input_dir}")

    missing_files = [
        filename
        for _, filename in INPUT_FILES
        if not (input_dir / filename).is_file()
    ]
    if missing_files:
        raise FileNotFoundError(
            "以下输入文件不存在：\n- " + "\n- ".join(missing_files)
        )

    all_overall: list[dict[str, object]] = []
    all_arg: list[dict[str, object]] = []
    all_type: list[dict[str, object]] = []
    all_subtype: list[dict[str, object]] = []
    all_each_type: list[dict[str, object]] = []

    for condition, filename in INPUT_FILES:
        input_csv = input_dir / filename
        rows = read_prediction_rows(input_csv)

        true_arg = normalize_arg_labels(
            [row["true_ARG"] for row in rows],
            "true_ARG",
            filename,
        )
        predicted_arg = normalize_arg_labels(
            [row["predicted_ARG"] for row in rows],
            "predicted_ARG",
            filename,
        )
        true_type = normalize_text_labels(
            [row["true_type"] for row in rows],
            "true_type",
            filename,
        )
        predicted_type = normalize_text_labels(
            [row["predicted_type"] for row in rows],
            "predicted_type",
            filename,
        )
        true_subtype = normalize_text_labels(
            [row["true_subtype"] for row in rows],
            "true_subtype",
            filename,
        )
        predicted_subtype = normalize_text_labels(
            [row["predicted_subtype"] for row in rows],
            "predicted_subtype",
            filename,
        )

        arg_metrics = calculate_overall_metrics(
            true_arg,
            predicted_arg,
            "ARG_nonARG",
            condition,
            filename,
        )
        type_metrics = calculate_overall_metrics(
            true_type,
            predicted_type,
            "type",
            condition,
            filename,
        )
        subtype_metrics = calculate_overall_metrics(
            true_subtype,
            predicted_subtype,
            "subtype",
            condition,
            filename,
        )
        each_type_metrics = calculate_each_type_metrics(
            true_type,
            predicted_type,
            condition,
            filename,
        )

        all_arg.extend(arg_metrics)
        all_type.extend(type_metrics)
        all_subtype.extend(subtype_metrics)
        all_each_type.extend(each_type_metrics)
        all_overall.extend(arg_metrics + type_metrics + subtype_metrics)

        print(
            f"已完成 {condition}: {filename}，记录数 = {len(rows)}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)

    overall_columns = (
        "condition",
        "source_file",
        "level",
        "average",
        "n_samples",
        "n_classes_union",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )
    each_type_columns = (
        "condition",
        "source_file",
        "type",
        "n_samples",
        "true_support",
        "predicted_count",
        "tp",
        "fp",
        "fn",
        "tn",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
    )

    save_csv(
        all_overall,
        output_dir / "00_all_levels_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_arg,
        output_dir / "01_ARG_nonARG_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_type,
        output_dir / "02_type_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_subtype,
        output_dir / "03_subtype_overall_five_metrics.csv",
        overall_columns,
    )
    save_csv(
        all_each_type,
        output_dir / "04_each_type_one_vs_rest_five_metrics.csv",
        each_type_columns,
    )

    print("\n全部计算完成。")
    print(f"结果目录：{output_dir}")
    print("共生成 5 个结果 CSV。")


if __name__ == "__main__":
    main()
