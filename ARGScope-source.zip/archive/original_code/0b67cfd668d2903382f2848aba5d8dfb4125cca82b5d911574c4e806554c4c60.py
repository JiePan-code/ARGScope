"""Regression checks for PLM-ARG report selection; no plotting dependencies."""
import csv
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import plot_precision_60_90 as plot


class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.folder = self.root / 'PLM_ARG' / 'PLMARG_5conditions_perType_metrics'
        self.folder.mkdir(parents=True)
        self.args = SimpleNamespace(root=self.root, manifest=None, score_scale='fraction')

    def report(self, name, value, batch=False):
        path = self.folder / name
        with path.open('w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['dataset', 'Type', 'precision'])
            for pct in (60, 70, 80, 90) if batch else (60,):
                writer.writerow([f'{pct}p', 'MLS', value])
                writer.writerow([f'{pct}p', 'bleomycin', 0])
        return path

    def discover(self):
        return plot.discover(self.args, self.root / 'output')

    def test_reported_four_file_conflict_and_batch_fallback(self):
        individual = self.report('60p_perType_metrics_ARG_only.csv', .8)
        self.report('60p_perType_metrics_including_nonARG.csv', .2)
        batch = self.report('PLMARG_perType_metrics_ARG_only_long.csv', .6, True)
        self.report('PLMARG_perType_metrics_including_nonARG_long.csv', .1, True)
        result = self.discover()
        self.assertEqual(result[('Protein', 'PLM-ARG', 60)][0], individual)
        self.assertEqual(result[('Protein', 'PLM-ARG', 70)][0], batch)
        self.assertEqual(plot.average(result[('Protein', 'PLM-ARG', 60)][1]), (.4, 2))
        self.assertEqual({c[2] for c in result}, {60, 70, 80, 90})

    def test_equal_priority_conflict_still_errors(self):
        self.report('60p_perType_metrics_ARG_only.csv', .8)
        self.report('60p_perType_metrics_ARG_only_backup.csv', .3)
        with self.assertRaisesRegex(ValueError, 'Ambiguous files'):
            self.discover()

    def test_manifest_overrides_preference(self):
        self.report('60p_perType_metrics_ARG_only.csv', .8)
        other = self.report('60p_perType_metrics_including_nonARG.csv', .2)
        self.args.manifest = self.root / 'manifest.csv'
        with self.args.manifest.open('w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['modality', 'model', 'completeness', 'path'])
            writer.writerow(['Protein', 'PLM-ARG', 60, str(other.relative_to(self.root))])
        self.assertEqual(self.discover()[('Protein', 'PLM-ARG', 60)][0], other)

    def test_other_models_keep_conflict_detection(self):
        options = [(Path('60p_ARG_only.csv'), {'MLS': .8}),
                   (Path('60p_including_nonARG.csv'), {'MLS': .2})]
        self.assertEqual(plot.preferred_candidates(('DNA', 'ARGScope', 60), options), options)


if __name__ == '__main__':
    unittest.main()
