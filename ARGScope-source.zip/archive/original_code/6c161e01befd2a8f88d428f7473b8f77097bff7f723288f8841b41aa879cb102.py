#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
import re

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D


# =============================================================================
# 1. Paths
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = SCRIPT_DIR / "DNA_count_recovery_all23types_noTitle"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DNA_CANDIDATES = [
    "test_sequence_predictions.csv",
    "DNA_test_sequence_predictions.csv",
    "dna_test_sequence_predictions.csv",
    "sequence_predictions.csv",
    "DNA_sequence_predictions.csv",
    "dna_sequence_predictions.csv",
    "test_predictions.csv",
    "test_sequence_predictions(5).csv",
]


# =============================================================================
# 2. User settings
# =============================================================================

USE_ONLY_TEST_SPLIT = True
TEST_SPLIT_NAME = "test"
FILTER_SEQUENCE_LEVEL = None

# Only draw subtypes with observed support >= this threshold
MIN_TRUE_SUPPORT = 5

POINT_SIZE = 72

FIG_WIDTH = 8.3
FIG_HEIGHT = 5.5
DPI = 600

FONT_FAMILY = "Arial"
AXIS_LABEL_SIZE = 12.0
TICK_SIZE = 8.0
LEGEND_SIZE = 7.0
TABLE_FONT_SIZE = 7.2

POINT_ALPHA = 0.78
POINT_EDGE_WIDTH = 0.55

GRID_COLOR = "#D2D2D2"
GRID_WIDTH = 0.7

SAVE_PNG = True
SAVE_PDF = True
SAVE_SVG = True
TRANSPARENT_BG = False


# =============================================================================
# 3. Style
# =============================================================================

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": [FONT_FAMILY, "DejaVu Sans", "Liberation Sans"],
    "font.size": 8,
    "axes.labelsize": AXIS_LABEL_SIZE,
    "xtick.labelsize": TICK_SIZE,
    "ytick.labelsize": TICK_SIZE,
    "legend.fontsize": LEGEND_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "axes.unicode_minus": False,
    "savefig.facecolor": "none" if TRANSPARENT_BG else "white",
    "savefig.edgecolor": "none" if TRANSPARENT_BG else "white",
})


# =============================================================================
# 4. Display names / colors
# =============================================================================

TYPE_DISPLAY_MAP = {
    "macrolide-lincosamide-streptogramin": "MLS",
}

# Keep exactly the same type colors as the previous Protein plot.
TYPE_COLOR_LIST = [
    "#4DBBD5", "#E64B35", "#00A087", "#3C5488", "#F39B7F",
    "#91D1C2", "#8491B4", "#7E6148", "#DC0000", "#B09C85",
    "#6A3D9A", "#1B9E77", "#D95F02", "#7570B3", "#E7298A",
    "#66A61E", "#E6AB02", "#A6761D", "#666666", "#A6CEE3",
    "#FB9A99", "#CAB2D6", "#FDBF6F", "#B2DF8A", "#8DD3C7",
    "#80B1D3", "#B3DE69", "#FCCDE5", "#BC80BD", "#CCEBC5",
]

FALLBACK_COLOR = "#9E9E9E"


# =============================================================================
# 5. Helpers
# =============================================================================

def clean_text(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).strip()


def normalize_nonarg(text: str) -> bool:
    key = re.sub(r"[\s_\-]+", "", clean_text(text).lower())
    return key in {"nonarg", "nonargs"}


def display_type_name(type_name: str) -> str:
    type_name = clean_text(type_name)
    return TYPE_DISPLAY_MAP.get(type_name, type_name)


def find_input_file() -> Path:
    for name in DNA_CANDIDATES:
        path = SCRIPT_DIR / name
        if path.is_file():
            return path

    hits = []
    for name in DNA_CANDIDATES:
        hits.extend([p for p in SCRIPT_DIR.glob(f"**/{name}") if p.is_file()])

    hits = sorted(set(hits))
    valid_hits = []
    for p in hits:
        try:
            header = pd.read_csv(p, nrows=0)
            required = {"true_subtype", "predicted_subtype", "true_type", "predicted_type"}
            if required.issubset(header.columns):
                valid_hits.append(p)
        except Exception:
            pass

    if len(valid_hits) == 1:
        return valid_hits[0]
    if len(valid_hits) > 1:
        priority = [
            p for p in valid_hits
            if ("test" in p.name.lower() and "prediction" in p.name.lower())
        ]
        if len(priority) >= 1:
            print(f"[Warning] Multiple DNA files found; using {priority[0]}")
            return priority[0]
        print(f"[Warning] Multiple DNA files found; using {valid_hits[0]}")
        return valid_hits[0]

    raise FileNotFoundError(
        "Cannot find DNA prediction CSV. Expected one of:\n  - "
        + "\n  - ".join(DNA_CANDIDATES)
        + "\n\nThe CSV must contain columns: true_subtype, predicted_subtype, true_type, predicted_type"
    )


def safe_true_arg_mask(df: pd.DataFrame) -> pd.Series:
    if "true_ARG" in df.columns:
        s = df["true_ARG"]
        if pd.api.types.is_numeric_dtype(s):
            return pd.to_numeric(s, errors="coerce").fillna(0).astype(float) > 0
        values = s.astype(str).str.strip().str.lower()
        return values.isin({"1", "true", "yes", "y", "t"})
    return ~df["true_type"].map(normalize_nonarg)


def filter_input(df: pd.DataFrame) -> pd.DataFrame:
    required = {"true_subtype", "predicted_subtype", "true_type", "predicted_type"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    out = df.copy()

    if USE_ONLY_TEST_SPLIT and "split" in out.columns:
        out = out[
            out["split"].astype(str).str.strip().str.lower()
            == TEST_SPLIT_NAME.lower()
        ].copy()

    if FILTER_SEQUENCE_LEVEL is not None and "sequence_level" in out.columns:
        out = out[
            out["sequence_level"].astype(str).str.strip()
            == FILTER_SEQUENCE_LEVEL
        ].copy()

    for col in required:
        out[col] = out[col].map(clean_text)

    valid = (
        out["true_subtype"].ne("")
        & out["predicted_subtype"].ne("")
        & out["true_type"].ne("")
        & out["predicted_type"].ne("")
    )
    return out.loc[valid].copy()


# =============================================================================
# 6. Build subtype count table
# =============================================================================

def build_subtype_table(df: pd.DataFrame):
    true_arg_mask = safe_true_arg_mask(df)
    arg_df = df[true_arg_mask].copy()
    arg_df = arg_df[~arg_df["true_type"].map(normalize_nonarg)].copy()

    true_counts = arg_df["true_subtype"].value_counts()
    pred_counts = df["predicted_subtype"].value_counts()

    subtype_to_type = (
        arg_df[["true_subtype", "true_type"]]
        .drop_duplicates()
        .groupby("true_subtype")["true_type"]
        .agg(lambda x: x.iloc[0])
        .to_dict()
    )

    all_true_types = sorted(set(arg_df["true_type"].astype(str)))

    rows = []
    for subtype, true_count in true_counts.items():
        predicted_count = int(pred_counts.get(subtype, 0))
        rows.append({
            "true_subtype": subtype,
            "true_type": subtype_to_type.get(subtype, ""),
            "true_count": int(true_count),
            "predicted_count": predicted_count,
            "count_error": predicted_count - int(true_count),
            "absolute_count_error": abs(predicted_count - int(true_count)),
        })

    table = pd.DataFrame(rows).sort_values(
        by=["true_count", "true_subtype"],
        ascending=[False, True],
    ).reset_index(drop=True)

    return table, all_true_types


# =============================================================================
# 7. Type-color mapping
# =============================================================================

def assign_all_type_colors(ordered_types: list[str]) -> dict:
    color_map = {}
    for i, t in enumerate(ordered_types):
        color_map[t] = TYPE_COLOR_LIST[i % len(TYPE_COLOR_LIST)]
    return color_map


# =============================================================================
# 8. Plot
# =============================================================================

def plot_count_recovery(full_table: pd.DataFrame, all_true_types: list[str]) -> None:
    plot_df = full_table[full_table["true_count"] >= MIN_TRUE_SUPPORT].copy()
    if plot_df.empty:
        raise ValueError("No subtype remains after MIN_TRUE_SUPPORT filtering.")

    type_support_full = (
        full_table.groupby("true_type")["true_count"]
        .sum()
        .sort_values(ascending=False)
    )
    legend_types = type_support_full.index.tolist()
    color_map = assign_all_type_colors(legend_types)

    if (
        len(plot_df) >= 2
        and plot_df["true_count"].nunique() > 1
        and plot_df["predicted_count"].nunique() > 1
    ):
        r = float(np.corrcoef(plot_df["true_count"], plot_df["predicted_count"])[0, 1])
    else:
        r = np.nan

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_HEIGHT), facecolor="white")

    for type_name, group_df in plot_df.groupby("true_type", sort=False):
        ax.scatter(
            group_df["true_count"],
            group_df["predicted_count"],
            s=POINT_SIZE,
            facecolor=color_map.get(type_name, FALLBACK_COLOR),
            edgecolor="white",
            linewidth=POINT_EDGE_WIDTH,
            alpha=POINT_ALPHA,
            zorder=3,
        )

    max_value = float(max(plot_df["true_count"].max(), plot_df["predicted_count"].max()))
    axis_max = max_value * 1.08

    ax.plot(
        [0, axis_max],
        [0, axis_max],
        linestyle=(0, (5, 5)),
        linewidth=2.0,
        color="#7A7A7A",
        zorder=1,
    )

    ax.set_xlim(-0.02 * axis_max, axis_max)
    ax.set_ylim(-0.02 * axis_max, axis_max)
    ax.set_aspect("equal", adjustable="box")

    ax.set_xlabel("Observed subtype count", fontsize=AXIS_LABEL_SIZE)
    ax.set_ylabel("Predicted subtype count", fontsize=AXIS_LABEL_SIZE)

    ax.grid(axis="both", color=GRID_COLOR, linewidth=GRID_WIDTH, alpha=0.72)
    ax.set_axisbelow(True)

    for spine in ax.spines.values():
        spine.set_linewidth(0.9)
        spine.set_color("#4F4F4F")

    # Upper-left summary table (same paper-style logic, adapted for DNA)
    r_text = f"{r:.3f}" if np.isfinite(r) else "NA"
    table1_data = [
        ["subtypes", f"{len(full_table):,}"],
        ["types", f"{len(all_true_types):,}"],
        ["plotted", f"{len(plot_df):,}"],
        ["r (plotted)", r_text],
    ]

    table1 = ax.table(
        cellText=table1_data,
        cellLoc="center",
        colWidths=[0.19, 0.12],
        bbox=[0.03, 0.74, 0.34, 0.22],
        zorder=8,
    )
    table1.auto_set_font_size(False)
    table1.set_fontsize(TABLE_FONT_SIZE)

    for (row, col), cell in table1.get_celld().items():
        cell.set_linewidth(0.7)
        cell.set_edgecolor("#555555")
        cell.set_facecolor((1, 1, 1, 0.86))
        cell.get_text().set_ha("center")
        cell.get_text().set_va("center")
        if col == 0:
            cell.get_text().set_fontstyle("italic")

    type_handles = []
    for t in legend_types:
        type_handles.append(
            Line2D(
                [0], [0],
                marker="o", linestyle="none",
                markersize=5.8,
                markerfacecolor=color_map[t],
                markeredgecolor="white",
                markeredgewidth=0.55,
                label=display_type_name(t),
            )
        )

    type_legend = ax.legend(
        handles=type_handles,
        loc="center left",
        bbox_to_anchor=(1.02, 0.50),
        # title="Type",
        frameon=False,
        fontsize=LEGEND_SIZE,
        title_fontsize=LEGEND_SIZE + 1.2,
        borderaxespad=0.0,
        labelspacing=1.18,
        handletextpad=0.30,
        ncol=1,
        columnspacing=0.5,
    )
    ax.add_artist(type_legend)

    fig.subplots_adjust(left=0.10, right=0.72, bottom=0.12, top=0.98)

    base = OUTPUT_DIR / "DNA_subtype_count_recovery_all23types_noTitle"
    if SAVE_PNG:
        fig.savefig(base.with_suffix(".png"), dpi=DPI, transparent=TRANSPARENT_BG)
    if SAVE_PDF:
        fig.savefig(base.with_suffix(".pdf"), transparent=TRANSPARENT_BG)
    if SAVE_SVG:
        fig.savefig(base.with_suffix(".svg"), transparent=TRANSPARENT_BG)

    plt.close(fig)

    plot_df.to_csv(
        OUTPUT_DIR / "DNA_subtype_count_recovery_all23types_noTitle_data.csv",
        index=False,
        encoding="utf-8-sig",
    )
    full_table.to_csv(
        OUTPUT_DIR / "DNA_subtype_count_recovery_all23types_full_table.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(f"[Saved] {base.with_suffix('.png')}")
    print(f"[Info] Total ARG Types in full DNA test set: {len(legend_types)}")


# =============================================================================
# 9. Main
# =============================================================================

def main():
    print("=" * 92)
    print("DNA subtype count recovery (no title + full-height single legend)")
    print("=" * 92)

    input_csv = find_input_file()
    print(f"Input  : {input_csv}")
    print(f"Output : {OUTPUT_DIR}")

    raw = pd.read_csv(input_csv)
    df = filter_input(raw)

    table, all_true_types = build_subtype_table(df)

    print(f"All ARG subtypes in test   : {len(table):,}")
    print(f"Plotted subtypes           : {(table['true_count'] >= MIN_TRUE_SUPPORT).sum():,}")
    print(f"All ARG Types in full test : {len(all_true_types):,}")

    plot_count_recovery(
        full_table=table,
        all_true_types=all_true_types,
    )

    print("\nDone.")


if __name__ == "__main__":
    main()
