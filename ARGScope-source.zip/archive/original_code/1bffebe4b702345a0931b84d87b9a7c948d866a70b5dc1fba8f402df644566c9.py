#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARGScope end-to-end ESM-2 protein + DNABERT-2 DNA Fusion and Refined pipeline.

Design goals
------------
1. Train a reproducible fusion network for ESM-2 protein and DNABERT-2 DNA embeddings.
2. Keep train/validation/test strictly separated.
3. Build subtype prototypes from training data only for unbiased evaluation.
4. Refine subtype prototypes with a residual hierarchical GAT.
5. Optimize the refiner for subtype discrimination, not only Type prediction.
6. Use validation data only for early stopping and threshold estimation.
7. Use the test set once for final evaluation.
8. Export a separate all-reference deployment prototype set. Deployment outputs
   must not be used to report independent test performance.

Required packages
-----------------
- numpy
- pandas
- scikit-learn
- torch

Input embedding format
----------------------
Protein and DNA files are tab-separated text files without a header:
    column 0: sequence ID
    columns 1..N: numeric embedding dimensions

Label format
------------
CSV with ID, Type, and Subtype columns. Column names are configurable.

Optional split file
-------------------
CSV with columns:
    id, split
where split is one of: train, val, test
If omitted, a deterministic subtype-stratified split is generated. Every
Subtype is retained in training. Singleton Subtypes are train-only and are not
independently evaluable.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import os
import random
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
)
from torch.utils.data import DataLoader, Dataset



# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

# Verified project inputs. The old 1024-dimensional DNA/NT file is rejected.
EXPECTED_ROWS = 26878
EXPECTED_PROTEIN_DIM = 1280
EXPECTED_DNABERT2_DIM = 768
EXPECTED_SUBTYPE_COUNT = 2825
EXPECTED_TYPE_COUNT = 31


@dataclass
class Config:
    aa_file: str
    nt_file: str
    label_file: str
    output_dir: str
    split_file: Optional[str] = None

    label_id_col: str = "id"
    label_type_col: str = "type"
    label_subtype_col: str = "subtype"
    split_id_col: str = "id"
    split_col: str = "split"

    seed: int = 42
    train_ratio: float = 0.70
    val_ratio: float = 0.15
    test_ratio: float = 0.15

    fusion_dim: int = 512
    fusion_hidden_dim: int = 768
    fusion_dropout: float = 0.20
    fusion_batch_size: int = 512
    fusion_epochs: int = 150
    fusion_patience: int = 20
    fusion_lr: float = 2e-4
    fusion_weight_decay: float = 1e-4
    fusion_type_loss_weight: float = 0.25
    fusion_supcon_loss_weight: float = 0.10
    fusion_supcon_temperature: float = 0.10
    label_smoothing: float = 0.05
    class_weight_beta: float = 0.999
    max_class_weight: float = 10.0
    num_workers: int = 4

    support_fraction: float = 0.80
    graph_knn_k: int = 5
    graph_knn_min_cosine: float = 0.30
    graph_hidden_dim: int = 512
    graph_heads: int = 4
    graph_dropout: float = 0.20
    graph_max_residual_alpha: float = 0.30
    graph_epochs: int = 300
    graph_patience: int = 30
    graph_lr: float = 5e-4
    graph_weight_decay: float = 1e-4
    graph_type_loss_weight: float = 0.20
    graph_reconstruction_weight: float = 0.20
    graph_separation_weight: float = 0.05
    graph_same_type_max_cosine: float = 0.90
    graph_pair_sample_size: int = 20000

    threshold_min_subtype_correct: int = 3
    threshold_min_type_correct: int = 10
    prediction_batch_size: int = 2048

    device: str = "auto"
    amp: bool = True


# -----------------------------------------------------------------------------
# General utilities
# -----------------------------------------------------------------------------


def parse_args() -> Config:
    parser = argparse.ArgumentParser(
        description="ARGScope end-to-end Fusion and Refined prototype pipeline"
    )
    parser.add_argument("--aa-file", required=True)
    parser.add_argument(
        "--dna-file",
        "--nt-file",
        dest="nt_file",
        required=True,
        help=(
            "DNABERT-2 DNA embedding file: one ID column followed by exactly "
            "768 numeric dimensions. --nt-file is retained only as a legacy alias."
        ),
    )
    parser.add_argument("--label-file", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--split-file", default=None)

    parser.add_argument("--label-id-col", default="id")
    parser.add_argument("--label-type-col", default="Type")
    parser.add_argument("--label-subtype-col", default="Subtype")
    parser.add_argument("--split-id-col", default="id")
    parser.add_argument("--split-col", default="split")

    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--fusion-dim", type=int, default=512)
    parser.add_argument("--fusion-hidden-dim", type=int, default=768)
    parser.add_argument("--fusion-batch-size", type=int, default=512)
    parser.add_argument("--fusion-epochs", type=int, default=150)
    parser.add_argument("--fusion-patience", type=int, default=20)
    parser.add_argument("--fusion-lr", type=float, default=2e-4)
    parser.add_argument("--num-workers", type=int, default=4)

    parser.add_argument("--graph-knn-k", type=int, default=5)
    parser.add_argument("--graph-knn-min-cosine", type=float, default=0.30)
    parser.add_argument("--graph-hidden-dim", type=int, default=512)
    parser.add_argument("--graph-heads", type=int, default=4)
    parser.add_argument("--graph-epochs", type=int, default=300)
    parser.add_argument("--graph-patience", type=int, default=30)
    parser.add_argument("--graph-lr", type=float, default=5e-4)

    parser.add_argument(
        "--device",
        default="auto",
        help="auto, cpu, cuda, cuda:0, ...",
    )
    parser.add_argument(
        "--no-amp",
        action="store_true",
        help="Disable automatic mixed precision",
    )
    args = parser.parse_args()

    return Config(
        aa_file=args.aa_file,
        nt_file=args.nt_file,
        label_file=args.label_file,
        output_dir=args.output_dir,
        split_file=args.split_file,
        label_id_col=args.label_id_col,
        label_type_col=args.label_type_col,
        label_subtype_col=args.label_subtype_col,
        split_id_col=args.split_id_col,
        split_col=args.split_col,
        seed=args.seed,
        fusion_dim=args.fusion_dim,
        fusion_hidden_dim=args.fusion_hidden_dim,
        fusion_batch_size=args.fusion_batch_size,
        fusion_epochs=args.fusion_epochs,
        fusion_patience=args.fusion_patience,
        fusion_lr=args.fusion_lr,
        num_workers=args.num_workers,
        graph_knn_k=args.graph_knn_k,
        graph_knn_min_cosine=args.graph_knn_min_cosine,
        graph_hidden_dim=args.graph_hidden_dim,
        graph_heads=args.graph_heads,
        graph_epochs=args.graph_epochs,
        graph_patience=args.graph_patience,
        graph_lr=args.graph_lr,
        device=args.device,
        amp=not args.no_amp,
    )


def seed_everything(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def resolve_device(device_arg: str) -> torch.device:
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device_arg)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is False")
    return device


def ensure_finite(name: str, array: np.ndarray) -> None:
    bad = ~np.isfinite(array)
    if bad.any():
        positions = np.argwhere(bad)
        preview = positions[:10].tolist()
        raise ValueError(
            f"{name} contains {int(bad.sum())} NaN/Inf values. "
            f"First positions: {preview}"
        )


def l2_normalize_numpy(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    zero_rows = np.where(norms[:, 0] < eps)[0]
    if len(zero_rows) > 0:
        raise ValueError(
            f"Found {len(zero_rows)} zero-norm vectors. First rows: "
            f"{zero_rows[:10].tolist()}"
        )
    return x / np.maximum(norms, eps)


def save_json(obj: object, path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2)


def current_lr(optimizer: torch.optim.Optimizer) -> float:
    return float(optimizer.param_groups[0]["lr"])


def make_grad_scaler(enabled: bool):
    # PyTorch 2.x API; AMP is disabled automatically on CPU.
    return torch.amp.GradScaler("cuda", enabled=enabled)


def amp_autocast(enabled: bool):
    return torch.amp.autocast(device_type="cuda", enabled=enabled)


# -----------------------------------------------------------------------------
# Data loading and validation
# -----------------------------------------------------------------------------


def read_embedding_txt(
    path: str,
    name: str,
    expected_dim: int,
) -> Tuple[List[str], np.ndarray]:
    """
    Read ID + embedding text files robustly.

    Supported delimiters:
    - tab
    - comma
    - one or more spaces/tabs

    The previous implementation forced tab separation. The verified DNABERT-2
    file is whitespace-delimited, so pandas read the whole row as one column.
    """
    print(f"Reading {name}: {path}")

    embedding_path = Path(path)
    if not embedding_path.is_file():
        raise FileNotFoundError(f"{name} embedding file not found: {embedding_path}")

    with embedding_path.open("r", encoding="utf-8", errors="ignore") as handle:
        first_line = handle.readline().strip()

    if not first_line:
        raise ValueError(f"{name} embedding file is empty: {embedding_path}")

    if "\t" in first_line:
        separator = "\t"
        engine = "c"
        first_tokens = first_line.split("\t")
        separator_name = "TAB"
    elif "," in first_line:
        separator = ","
        engine = "c"
        first_tokens = first_line.split(",")
        separator_name = "COMMA"
    else:
        separator = r"\s+"
        engine = "python"
        first_tokens = first_line.split()
        separator_name = "WHITESPACE"

    if len(first_tokens) < 2:
        raise ValueError(
            f"{name} first row cannot be split into ID + features. "
            f"Detected separator={separator_name}; preview={first_line[:200]!r}"
        )

    try:
        float(first_tokens[1])
        has_header = False
    except ValueError:
        has_header = True

    print(
        f"{name} parser: separator={separator_name}, "
        f"header={has_header}, engine={engine}"
    )

    df = pd.read_csv(
        embedding_path,
        sep=separator,
        header=0 if has_header else None,
        engine=engine,
    )

    if df.shape[1] < 2:
        raise ValueError(
            f"{name} embedding file must contain ID + feature columns; "
            f"detected shape={df.shape}, separator={separator_name}"
        )

    ids = df.iloc[:, 0].astype(str).str.strip()
    if ids.eq("").any():
        raise ValueError(f"{name} embedding file contains empty IDs")
    if ids.duplicated().any():
        duplicated = ids[ids.duplicated(keep=False)].unique()[:20].tolist()
        raise ValueError(f"{name} embedding file contains duplicate IDs: {duplicated}")

    numeric = df.iloc[:, 1:].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        bad = np.argwhere(numeric.isna().to_numpy())
        raise ValueError(
            f"{name} embedding file contains non-numeric or missing values. "
            f"First positions: {bad[:10].tolist()}"
        )

    matrix = numeric.to_numpy(dtype=np.float32, copy=True)
    ensure_finite(name, matrix)

    if len(ids) != EXPECTED_ROWS:
        raise ValueError(
            f"{name} row-count error: expected {EXPECTED_ROWS}, got {len(ids)}"
        )
    if matrix.shape[1] != expected_dim:
        raise ValueError(
            f"{name} dimension error: expected {expected_dim}, "
            f"got {matrix.shape[1]}. The old 1024-dimensional DNA/NT file "
            "must not be used in this pipeline."
        )
    if np.any(np.linalg.norm(matrix, axis=1) <= 1e-12):
        raise ValueError(f"{name} contains one or more all-zero vectors")

    print(
        f"{name}: rows={len(ids)}, dim={matrix.shape[1]} "
        "[STRICT DIMENSION CHECK PASSED]"
    )
    return ids.tolist(), matrix


def load_and_align_data(cfg: Config) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    label_df = pd.read_csv(cfg.label_file, low_memory=False)

    # Normalize header whitespace/BOM, then resolve requested names case-insensitively.
    label_df.columns = [str(c).replace("\ufeff", "").strip() for c in label_df.columns]
    casefold_to_actual = {}
    for column in label_df.columns:
        key = column.casefold()
        if key in casefold_to_actual and casefold_to_actual[key] != column:
            raise ValueError(
                "Label file has columns that differ only by case: "
                f"{casefold_to_actual[key]!r} and {column!r}"
            )
        casefold_to_actual[key] = column

    requested = [cfg.label_id_col, cfg.label_type_col, cfg.label_subtype_col]
    resolved = []
    missing = []
    for column in requested:
        actual = casefold_to_actual.get(str(column).strip().casefold())
        if actual is None:
            missing.append(column)
        else:
            resolved.append(actual)

    if missing:
        raise ValueError(
            f"Label file is missing columns: {missing}. "
            f"Available columns: {label_df.columns.tolist()}"
        )

    print(
        "Resolved label columns: "
        f"id={resolved[0]!r}, Type={resolved[1]!r}, Subtype={resolved[2]!r}"
    )
    label_df = label_df[resolved].copy()
    label_df.columns = ["id", "Type", "Subtype"]
    for col in ["id", "Type", "Subtype"]:
        if label_df[col].isna().any():
            raise ValueError(f"Label column {col} contains missing values")
        label_df[col] = label_df[col].astype(str).str.strip()
        if label_df[col].eq("").any():
            raise ValueError(f"Label column {col} contains empty strings")

    if label_df["id"].duplicated().any():
        duplicated = (
            label_df.loc[label_df["id"].duplicated(keep=False), "id"]
            .unique()[:20]
            .tolist()
        )
        raise ValueError(f"Label file contains duplicate IDs: {duplicated}")

    if len(label_df) != EXPECTED_ROWS:
        raise ValueError(
            f"Label row-count error: expected {EXPECTED_ROWS}, got {len(label_df)}"
        )
    if label_df["Subtype"].nunique() != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Subtype-count error: expected {EXPECTED_SUBTYPE_COUNT}, "
            f"got {label_df['Subtype'].nunique()}"
        )
    if label_df["Type"].nunique() != EXPECTED_TYPE_COUNT:
        raise ValueError(
            f"Type-count error: expected {EXPECTED_TYPE_COUNT}, "
            f"got {label_df['Type'].nunique()}"
        )

    subtype_type_n = label_df.groupby("Subtype")["Type"].nunique()
    conflicts = subtype_type_n[subtype_type_n > 1]
    if len(conflicts) > 0:
        detail = (
            label_df[label_df["Subtype"].isin(conflicts.index)]
            .groupby(["Subtype", "Type"])
            .size()
            .reset_index(name="Count")
        )
        preview = detail.head(30).to_dict(orient="records")
        raise ValueError(
            f"Found {len(conflicts)} Subtypes mapped to multiple Types. "
            f"Examples: {preview}"
        )

    aa_ids, aa_matrix = read_embedding_txt(
        cfg.aa_file,
        "ESM-2 protein embedding",
        EXPECTED_PROTEIN_DIM,
    )
    nt_ids, nt_matrix = read_embedding_txt(
        cfg.nt_file,
        "DNABERT-2 DNA embedding",
        EXPECTED_DNABERT2_DIM,
    )

    aa_pos = {seq_id: i for i, seq_id in enumerate(aa_ids)}
    nt_pos = {seq_id: i for i, seq_id in enumerate(nt_ids)}

    label_ids = label_df["id"].tolist()
    missing_aa = [seq_id for seq_id in label_ids if seq_id not in aa_pos]
    missing_nt = [seq_id for seq_id in label_ids if seq_id not in nt_pos]
    label_id_set = set(label_ids)
    extra_aa = [seq_id for seq_id in aa_ids if seq_id not in label_id_set]
    extra_nt = [seq_id for seq_id in nt_ids if seq_id not in label_id_set]

    if missing_aa or missing_nt:
        raise ValueError(
            "Embedding/label ID mismatch. "
            f"Missing AA={len(missing_aa)}, missing NT={len(missing_nt)}. "
            f"AA examples={missing_aa[:10]}, NT examples={missing_nt[:10]}"
        )

    if extra_aa or extra_nt:
        raise ValueError(
            "Embedding files contain IDs absent from the label file. "
            f"extra_ESM2_protein={len(extra_aa)}, "
            f"extra_DNABERT2_DNA={len(extra_nt)}"
        )

    aa_aligned = np.stack([aa_matrix[aa_pos[seq_id]] for seq_id in label_ids])
    nt_aligned = np.stack([nt_matrix[nt_pos[seq_id]] for seq_id in label_ids])
    ensure_finite("aligned AA", aa_aligned)
    ensure_finite("aligned NT", nt_aligned)

    # Row-wise normalization gives both modalities a stable input scale.
    aa_aligned = l2_normalize_numpy(aa_aligned.astype(np.float32, copy=False))
    nt_aligned = l2_normalize_numpy(nt_aligned.astype(np.float32, copy=False))

    print(
        f"Aligned dataset: rows={len(label_df)}, AA dim={aa_aligned.shape[1]}, "
        f"NT dim={nt_aligned.shape[1]}, Types={label_df['Type'].nunique()}, "
        f"Subtypes={label_df['Subtype'].nunique()}"
    )
    if aa_aligned.shape != (EXPECTED_ROWS, EXPECTED_PROTEIN_DIM):
        raise ValueError(
            f"Aligned ESM-2 protein matrix has unexpected shape: {aa_aligned.shape}"
        )
    if nt_aligned.shape != (EXPECTED_ROWS, EXPECTED_DNABERT2_DIM):
        raise ValueError(
            f"Aligned DNABERT-2 DNA matrix has unexpected shape: {nt_aligned.shape}"
        )

    print("Verified aligned inputs:")
    print(f"  ESM-2 protein embedding: {aa_aligned.shape}")
    print(f"  DNABERT-2 DNA embedding: {nt_aligned.shape}")

    return label_df.reset_index(drop=True), aa_aligned, nt_aligned


# -----------------------------------------------------------------------------
# Train/validation/test split
# -----------------------------------------------------------------------------


def deterministic_subtype_split(
    labels: pd.DataFrame,
    seed: int,
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
) -> pd.Series:
    if not math.isclose(train_ratio + val_ratio + test_ratio, 1.0, rel_tol=1e-6):
        raise ValueError("train_ratio + val_ratio + test_ratio must equal 1")

    rng = np.random.default_rng(seed)
    split = np.full(len(labels), "", dtype=object)

    # Rotate n=2 classes between validation and test so that both sets remain useful.
    two_class_counter = 0

    for subtype, idx_series in labels.groupby("Subtype", sort=True).groups.items():
        idx = np.asarray(list(idx_series), dtype=np.int64)
        rng.shuffle(idx)
        n = len(idx)

        if n == 1:
            split[idx] = "train"
            continue

        if n == 2:
            split[idx[0]] = "train"
            split[idx[1]] = "val" if two_class_counter % 2 == 0 else "test"
            two_class_counter += 1
            continue

        n_val = max(1, int(round(n * val_ratio)))
        n_test = max(1, int(round(n * test_ratio)))
        while n_val + n_test > n - 1:
            if n_test >= n_val and n_test > 1:
                n_test -= 1
            elif n_val > 1:
                n_val -= 1
            else:
                break
        n_train = n - n_val - n_test
        if n_train < 1:
            raise RuntimeError(f"Internal split error for subtype={subtype}, n={n}")

        split[idx[:n_train]] = "train"
        split[idx[n_train : n_train + n_val]] = "val"
        split[idx[n_train + n_val :]] = "test"

    if np.any(split == ""):
        raise RuntimeError("Some rows were not assigned to a split")
    return pd.Series(split, index=labels.index, name="split")


def assign_splits(cfg: Config, labels: pd.DataFrame, out_dir: Path) -> pd.DataFrame:
    split_df = labels[["id", "Type", "Subtype"]].copy()

    if cfg.split_file:
        provided = pd.read_csv(cfg.split_file, low_memory=False)
        required = [cfg.split_id_col, cfg.split_col]
        missing = [c for c in required if c not in provided.columns]
        if missing:
            raise ValueError(f"Split file is missing columns: {missing}")
        provided = provided[required].copy()
        provided.columns = ["id", "split"]
        provided["id"] = provided["id"].astype(str).str.strip()
        provided["split"] = provided["split"].astype(str).str.strip().str.lower()
        if provided["id"].duplicated().any():
            raise ValueError("Split file contains duplicate IDs")
        allowed = {"train", "val", "test"}
        invalid = sorted(set(provided["split"]) - allowed)
        if invalid:
            raise ValueError(f"Invalid split names: {invalid}; allowed={sorted(allowed)}")
        split_df = split_df.merge(provided, on="id", how="left", validate="one_to_one")
        if split_df["split"].isna().any():
            missing_ids = split_df.loc[split_df["split"].isna(), "id"].head(20).tolist()
            raise ValueError(f"Split file is missing dataset IDs: {missing_ids}")
    else:
        split_df["split"] = deterministic_subtype_split(
            labels,
            seed=cfg.seed,
            train_ratio=cfg.train_ratio,
            val_ratio=cfg.val_ratio,
            test_ratio=cfg.test_ratio,
        )

    train_subtypes = set(split_df.loc[split_df["split"] == "train", "Subtype"])
    nontrain_subtypes = set(split_df.loc[split_df["split"] != "train", "Subtype"])
    missing_train_support = sorted(nontrain_subtypes - train_subtypes)
    if missing_train_support:
        raise ValueError(
            "Validation/test contain Subtypes absent from training. "
            f"Examples: {missing_train_support[:20]}"
        )

    split_df.to_csv(out_dir / "data_splits.csv", index=False, encoding="utf-8-sig")

    summary = (
        split_df.groupby("split")
        .agg(
            rows=("id", "size"),
            Types=("Type", "nunique"),
            Subtypes=("Subtype", "nunique"),
        )
        .reset_index()
    )
    summary.to_csv(out_dir / "split_summary.csv", index=False, encoding="utf-8-sig")
    print(summary.to_string(index=False))
    return split_df


# -----------------------------------------------------------------------------
# Label indexing
# -----------------------------------------------------------------------------


def build_label_maps(labels: pd.DataFrame, out_dir: Path):
    subtype_names = sorted(labels["Subtype"].unique().tolist())
    type_names = sorted(labels["Type"].unique().tolist())
    subtype_to_idx = {name: i for i, name in enumerate(subtype_names)}
    type_to_idx = {name: i for i, name in enumerate(type_names)}

    mapping_df = (
        labels[["Subtype", "Type"]]
        .drop_duplicates()
        .sort_values(["Type", "Subtype"])
        .reset_index(drop=True)
    )
    mapping_df["subtype_index"] = mapping_df["Subtype"].map(subtype_to_idx)
    mapping_df["type_index"] = mapping_df["Type"].map(type_to_idx)
    mapping_df = mapping_df.sort_values("subtype_index").reset_index(drop=True)
    mapping_df.to_csv(
        out_dir / "subtype_type_label_map.csv", index=False, encoding="utf-8-sig"
    )

    subtype_to_type_idx = np.empty(len(subtype_names), dtype=np.int64)
    for row in mapping_df.itertuples(index=False):
        subtype_to_type_idx[int(row.subtype_index)] = int(row.type_index)

    return (
        subtype_names,
        type_names,
        subtype_to_idx,
        type_to_idx,
        subtype_to_type_idx,
        mapping_df,
    )


# -----------------------------------------------------------------------------
# Dataset and fusion model
# -----------------------------------------------------------------------------


class MultimodalDataset(Dataset):
    def __init__(
        self,
        aa: np.ndarray,
        nt: np.ndarray,
        subtype_y: np.ndarray,
        type_y: np.ndarray,
        indices: np.ndarray,
    ) -> None:
        self.aa = torch.from_numpy(aa[indices]).float()
        self.nt = torch.from_numpy(nt[indices]).float()
        self.subtype_y = torch.from_numpy(subtype_y[indices]).long()
        self.type_y = torch.from_numpy(type_y[indices]).long()
        self.indices = torch.from_numpy(indices.astype(np.int64))

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        return (
            self.aa[idx],
            self.nt[idx],
            self.subtype_y[idx],
            self.type_y[idx],
            self.indices[idx],
        )


class GatedFusionNet(nn.Module):
    """Fusion model for one ESM-2 protein vector and one DNABERT-2 DNA vector."""

    def __init__(
        self,
        aa_dim: int,
        nt_dim: int,
        fusion_dim: int,
        hidden_dim: int,
        num_subtypes: int,
        num_types: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.aa_encoder = nn.Sequential(
            nn.Linear(aa_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
        )
        self.nt_encoder = nn.Sequential(
            nn.Linear(nt_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
        )

        self.gate = nn.Sequential(
            nn.Linear(fusion_dim * 2, fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_dim, fusion_dim),
            nn.Sigmoid(),
        )
        self.interaction = nn.Sequential(
            nn.Linear(fusion_dim * 4, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, fusion_dim),
        )
        self.output_norm = nn.LayerNorm(fusion_dim)
        self.subtype_head = nn.Linear(fusion_dim, num_subtypes)
        self.type_head = nn.Linear(fusion_dim, num_types)

    def forward(self, aa: torch.Tensor, nt: torch.Tensor):
        h_aa = self.aa_encoder(aa)
        h_nt = self.nt_encoder(nt)
        gate = self.gate(torch.cat([h_aa, h_nt], dim=-1))
        interaction_input = torch.cat(
            [h_aa, h_nt, torch.abs(h_aa - h_nt), h_aa * h_nt], dim=-1
        )
        interaction = self.interaction(interaction_input)
        fused = self.output_norm(
            gate * h_aa + (1.0 - gate) * h_nt + 0.5 * interaction
        )
        fused_normalized = F.normalize(fused, p=2, dim=-1)
        subtype_logits = self.subtype_head(fused)
        type_logits = self.type_head(fused)
        return subtype_logits, type_logits, fused_normalized, gate


def effective_number_weights(
    y: np.ndarray,
    num_classes: int,
    beta: float,
    max_weight: float,
) -> torch.Tensor:
    counts = np.bincount(y, minlength=num_classes).astype(np.float64)
    if np.any(counts == 0):
        missing = np.where(counts == 0)[0].tolist()
        raise ValueError(f"Training labels are missing classes: {missing[:20]}")
    effective = 1.0 - np.power(beta, counts)
    weights = (1.0 - beta) / np.maximum(effective, 1e-12)
    weights = weights / weights.mean()
    weights = np.minimum(weights, max_weight)
    return torch.tensor(weights, dtype=torch.float32)


def supervised_contrastive_loss(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    """Supervised contrastive loss computed strictly in FP32.

    AMP may cast the Fusion embedding and similarity matrix to float16.  The
    previous diagonal mask value (-1e9) cannot be represented by float16 and
    causes an overflow on CUDA.  Contrastive similarity/log-sum-exp is also
    more numerically stable in float32, so autocast is disabled locally.
    """
    if temperature <= 0:
        raise ValueError(f"temperature must be > 0, got {temperature}")

    device_type = embeddings.device.type
    with torch.amp.autocast(device_type=device_type, enabled=False):
        z = F.normalize(embeddings.float(), p=2, dim=1)
        labels = labels.long()

        logits = (z @ z.T) / float(temperature)
        n = logits.size(0)
        eye = torch.eye(n, dtype=torch.bool, device=logits.device)

        # logits is guaranteed to be FP32 here, so -1e9 is representable.
        logits = logits.masked_fill(eye, -1.0e9)

        same = labels.unsqueeze(0).eq(labels.unsqueeze(1)) & ~eye
        positive_counts = same.sum(dim=1)
        valid = positive_counts > 0
        if not bool(valid.any()):
            return logits.new_zeros(())

        log_prob = logits - torch.logsumexp(logits, dim=1, keepdim=True)

        # Avoid expressions such as (-inf * 0), which can create NaNs.
        positive_log_prob = torch.where(
            same,
            log_prob,
            torch.zeros_like(log_prob),
        )
        mean_log_prob_pos = (
            positive_log_prob.sum(dim=1)
            / positive_counts.clamp_min(1).to(log_prob.dtype)
        )
        return -mean_log_prob_pos[valid].mean()


def make_loader(
    dataset: Dataset,
    batch_size: int,
    shuffle: bool,
    num_workers: int,
    device: torch.device,
) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        drop_last=False,
        persistent_workers=num_workers > 0,
    )


@torch.no_grad()
def evaluate_fusion_head(
    model: GatedFusionNet,
    loader: DataLoader,
    device: torch.device,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    model.eval()
    true_sub, pred_sub, true_type, pred_type = [], [], [], []
    for aa, nt, subtype_y, type_y, _ in loader:
        aa = aa.to(device, non_blocking=True)
        nt = nt.to(device, non_blocking=True)
        subtype_logits, type_logits, _, _ = model(aa, nt)
        true_sub.append(subtype_y.numpy())
        pred_sub.append(subtype_logits.argmax(dim=1).cpu().numpy())
        true_type.append(type_y.numpy())
        pred_type.append(type_logits.argmax(dim=1).cpu().numpy())
    return (
        np.concatenate(true_sub),
        np.concatenate(pred_sub),
        np.concatenate(true_type),
        np.concatenate(pred_type),
    )


def train_fusion_model(
    cfg: Config,
    aa: np.ndarray,
    nt: np.ndarray,
    subtype_y: np.ndarray,
    type_y: np.ndarray,
    split_df: pd.DataFrame,
    num_subtypes: int,
    num_types: int,
    out_dir: Path,
    device: torch.device,
) -> Tuple[GatedFusionNet, int]:
    train_idx = np.where(split_df["split"].to_numpy() == "train")[0]
    val_idx = np.where(split_df["split"].to_numpy() == "val")[0]
    if len(val_idx) == 0:
        raise ValueError("Validation set is empty; fusion early stopping requires validation data")

    train_ds = MultimodalDataset(aa, nt, subtype_y, type_y, train_idx)
    val_ds = MultimodalDataset(aa, nt, subtype_y, type_y, val_idx)
    train_loader = make_loader(
        train_ds, cfg.fusion_batch_size, True, cfg.num_workers, device
    )
    val_loader = make_loader(
        val_ds, cfg.fusion_batch_size, False, cfg.num_workers, device
    )

    model = GatedFusionNet(
        aa_dim=aa.shape[1],
        nt_dim=nt.shape[1],
        fusion_dim=cfg.fusion_dim,
        hidden_dim=cfg.fusion_hidden_dim,
        num_subtypes=num_subtypes,
        num_types=num_types,
        dropout=cfg.fusion_dropout,
    ).to(device)

    subtype_weights = effective_number_weights(
        subtype_y[train_idx],
        num_classes=num_subtypes,
        beta=cfg.class_weight_beta,
        max_weight=cfg.max_class_weight,
    ).to(device)
    type_weights = effective_number_weights(
        type_y[train_idx],
        num_classes=num_types,
        beta=cfg.class_weight_beta,
        max_weight=cfg.max_class_weight,
    ).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg.fusion_lr, weight_decay=cfg.fusion_weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=5, min_lr=1e-6
    )
    amp_enabled = cfg.amp and device.type == "cuda"
    scaler = make_grad_scaler(amp_enabled)

    best_score = -np.inf
    best_state = None
    best_epoch = 0
    no_improve = 0
    history: List[Dict[str, float]] = []

    print("\n=== Stage 1: train gated Fusion model ===")
    for epoch in range(1, cfg.fusion_epochs + 1):
        model.train()
        running_loss = 0.0
        running_n = 0

        for aa_b, nt_b, sub_b, type_b, _ in train_loader:
            aa_b = aa_b.to(device, non_blocking=True)
            nt_b = nt_b.to(device, non_blocking=True)
            sub_b = sub_b.to(device, non_blocking=True)
            type_b = type_b.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            with amp_autocast(amp_enabled):
                sub_logits, type_logits, fused, _ = model(aa_b, nt_b)
                loss_sub = F.cross_entropy(
                    sub_logits,
                    sub_b,
                    weight=subtype_weights,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_type = F.cross_entropy(
                    type_logits,
                    type_b,
                    weight=type_weights,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_supcon = supervised_contrastive_loss(
                    fused, sub_b, temperature=cfg.fusion_supcon_temperature
                )
                loss = (
                    loss_sub
                    + cfg.fusion_type_loss_weight * loss_type
                    + cfg.fusion_supcon_loss_weight * loss_supcon
                )

            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()

            running_loss += float(loss.item()) * len(sub_b)
            running_n += len(sub_b)

        yt_sub, yp_sub, yt_type, yp_type = evaluate_fusion_head(
            model, val_loader, device
        )
        val_weighted_f1 = f1_score(yt_sub, yp_sub, average="weighted", zero_division=0)
        val_macro_f1 = f1_score(yt_sub, yp_sub, average="macro", zero_division=0)
        val_acc = accuracy_score(yt_sub, yp_sub)
        val_type_f1 = f1_score(
            yt_type, yp_type, average="weighted", zero_division=0
        )
        scheduler.step(val_weighted_f1)

        row = {
            "epoch": epoch,
            "train_loss": running_loss / max(running_n, 1),
            "val_subtype_acc": val_acc,
            "val_subtype_macro_f1": val_macro_f1,
            "val_subtype_weighted_f1": val_weighted_f1,
            "val_type_weighted_f1_aux_head": val_type_f1,
            "lr": current_lr(optimizer),
        }
        history.append(row)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"Fusion epoch {epoch:03d} | loss={row['train_loss']:.4f} | "
                f"val ACC={val_acc:.4f} | val macro-F1={val_macro_f1:.4f} | "
                f"val weighted-F1={val_weighted_f1:.4f} | lr={row['lr']:.2e}"
            )

        if val_weighted_f1 > best_score + 1e-6:
            best_score = val_weighted_f1
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= cfg.fusion_patience:
                print(
                    f"Fusion early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, best val weighted-F1={best_score:.4f}"
                )
                break

    if best_state is None:
        raise RuntimeError("Fusion training did not produce a checkpoint")
    model.load_state_dict(best_state)
    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "fusion_training_history.csv", index=False, encoding="utf-8-sig"
    )
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "protein_esm2_dim": aa.shape[1],
            "dna_dnabert2_dim": nt.shape[1],
            "fusion_dim": cfg.fusion_dim,
            "fusion_hidden_dim": cfg.fusion_hidden_dim,
            "num_subtypes": num_subtypes,
            "num_types": num_types,
            "config": asdict(cfg),
        },
        out_dir / "fusion_model_best.pt",
    )
    return model, best_epoch


@torch.no_grad()
def encode_all_fusion(
    model: GatedFusionNet,
    aa: np.ndarray,
    nt: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> Tuple[np.ndarray, np.ndarray]:
    model.eval()
    all_fused: List[np.ndarray] = []
    all_gate: List[np.ndarray] = []
    for start in range(0, len(aa), batch_size):
        end = min(start + batch_size, len(aa))
        aa_b = torch.from_numpy(aa[start:end]).float().to(device)
        nt_b = torch.from_numpy(nt[start:end]).float().to(device)
        _, _, fused, gate = model(aa_b, nt_b)
        all_fused.append(fused.cpu().numpy().astype(np.float32))
        all_gate.append(gate.cpu().numpy().astype(np.float32))
    fused_np = np.concatenate(all_fused, axis=0)
    gate_np = np.concatenate(all_gate, axis=0)
    ensure_finite("Fusion embeddings", fused_np)
    return fused_np, gate_np


def save_sequence_fusion_embeddings(
    labels: pd.DataFrame,
    split_df: pd.DataFrame,
    fused: np.ndarray,
    gate: np.ndarray,
    out_dir: Path,
) -> None:
    feature_cols = [f"fusion_{i}" for i in range(fused.shape[1])]
    fusion_df = pd.DataFrame(fused, columns=feature_cols)
    fusion_df.insert(0, "split", split_df["split"].to_numpy())
    fusion_df.insert(0, "Subtype", labels["Subtype"].to_numpy())
    fusion_df.insert(0, "Type", labels["Type"].to_numpy())
    fusion_df.insert(0, "id", labels["id"].to_numpy())
    fusion_df.to_csv(
        out_dir / "sequence_fusion_embeddings_512.csv",
        index=False,
        encoding="utf-8-sig",
    )

    gate_summary = pd.DataFrame(
        {
            "id": labels["id"],
            "Type": labels["Type"],
            "Subtype": labels["Subtype"],
            "split": split_df["split"],
            "mean_ESM2_protein_gate": gate.mean(axis=1),
            "mean_DNABERT2_DNA_gate": 1.0 - gate.mean(axis=1),
        }
    )
    gate_summary.to_csv(
        out_dir / "fusion_gate_summary.csv", index=False, encoding="utf-8-sig"
    )


# -----------------------------------------------------------------------------
# Prototype construction
# -----------------------------------------------------------------------------


def support_query_split(
    train_indices: np.ndarray,
    subtype_y: np.ndarray,
    support_fraction: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    support: List[int] = []
    query: List[int] = []

    train_y = subtype_y[train_indices]
    for subtype_idx in np.unique(train_y):
        idx = train_indices[train_y == subtype_idx].copy()
        rng.shuffle(idx)
        n = len(idx)
        if n == 1:
            support.extend(idx.tolist())
            continue
        n_support = max(1, int(round(n * support_fraction)))
        n_support = min(n_support, n - 1)
        support.extend(idx[:n_support].tolist())
        query.extend(idx[n_support:].tolist())

    rng.shuffle(support)
    rng.shuffle(query)
    return np.asarray(support, dtype=np.int64), np.asarray(query, dtype=np.int64)


def compute_subtype_prototypes(
    embeddings: np.ndarray,
    subtype_y: np.ndarray,
    selected_indices: np.ndarray,
    num_subtypes: int,
) -> Tuple[np.ndarray, np.ndarray]:
    dim = embeddings.shape[1]
    sums = np.zeros((num_subtypes, dim), dtype=np.float64)
    counts = np.zeros(num_subtypes, dtype=np.int64)

    for idx in selected_indices:
        cls = int(subtype_y[idx])
        sums[cls] += embeddings[idx]
        counts[cls] += 1

    missing = np.where(counts == 0)[0]
    if len(missing) > 0:
        raise ValueError(
            f"Cannot build prototypes; {len(missing)} Subtypes have zero support. "
            f"First indices: {missing[:20].tolist()}"
        )

    prototypes = (sums / counts[:, None]).astype(np.float32)
    prototypes = l2_normalize_numpy(prototypes)
    return prototypes, counts


def prototype_dataframe(
    prototypes: np.ndarray,
    counts: np.ndarray,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
) -> pd.DataFrame:
    feature_cols = [f"g{i}" for i in range(prototypes.shape[1])]
    df = pd.DataFrame(prototypes, columns=feature_cols)
    df.insert(0, "Count", counts)
    df.insert(0, "Type", [type_names[i] for i in subtype_to_type_idx])
    df.insert(0, "Subtype", list(subtype_names))
    df.insert(0, "subtype_index", np.arange(len(subtype_names), dtype=np.int64))
    return df


# -----------------------------------------------------------------------------
# Hierarchical graph and residual GAT refiner
# -----------------------------------------------------------------------------


def build_hierarchical_graph(
    raw_subtype_prototypes: np.ndarray,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    k: int,
    min_cosine: float,
) -> Tuple[np.ndarray, torch.Tensor, pd.DataFrame]:
    num_subtypes, dim = raw_subtype_prototypes.shape
    num_types = len(type_names)

    type_features = np.zeros((num_types, dim), dtype=np.float32)
    for type_idx in range(num_types):
        members = np.where(subtype_to_type_idx == type_idx)[0]
        if len(members) == 0:
            raise ValueError(f"Type {type_names[type_idx]} has no Subtype nodes")
        type_features[type_idx] = raw_subtype_prototypes[members].mean(axis=0)
    type_features = l2_normalize_numpy(type_features)
    node_features = np.vstack([raw_subtype_prototypes, type_features]).astype(np.float32)

    edge_records: List[Dict[str, object]] = []
    directed_edges = set()

    def add_edge(
        src: int,
        dst: int,
        edge_type: str,
        cosine: Optional[float],
        src_name: str,
        dst_name: str,
    ) -> None:
        key = (int(src), int(dst))
        if key in directed_edges:
            return
        directed_edges.add(key)
        edge_records.append(
            {
                "source": int(src),
                "target": int(dst),
                "edge_type": edge_type,
                "cosine_similarity": np.nan if cosine is None else float(cosine),
                "source_name": src_name,
                "target_name": dst_name,
            }
        )

    # Explicit known hierarchy: Subtype <-> parent Type.
    for subtype_idx, type_idx in enumerate(subtype_to_type_idx):
        type_node = num_subtypes + int(type_idx)
        add_edge(
            subtype_idx,
            type_node,
            "subtype_to_type",
            None,
            subtype_names[subtype_idx],
            f"TYPE::{type_names[type_idx]}",
        )
        add_edge(
            type_node,
            subtype_idx,
            "type_to_subtype",
            None,
            f"TYPE::{type_names[type_idx]}",
            subtype_names[subtype_idx],
        )

    # Conservative mutual KNN among Subtypes within the same known Type.
    for type_idx, type_name in enumerate(type_names):
        members = np.where(subtype_to_type_idx == type_idx)[0]
        n = len(members)
        if n <= 1 or k <= 0:
            continue
        x = raw_subtype_prototypes[members]
        sim = x @ x.T
        np.fill_diagonal(sim, -np.inf)
        k_eff = min(k, n - 1)
        topk = np.argpartition(-sim, kth=k_eff - 1, axis=1)[:, :k_eff]
        topk_sets = [set(row.tolist()) for row in topk]

        for i_local in range(n):
            for j_local in topk[i_local]:
                j_local = int(j_local)
                if i_local not in topk_sets[j_local]:
                    continue
                score = float(sim[i_local, j_local])
                if score < min_cosine:
                    continue
                src = int(members[i_local])
                dst = int(members[j_local])
                add_edge(
                    src,
                    dst,
                    "mutual_knn_same_type",
                    score,
                    subtype_names[src],
                    subtype_names[dst],
                )

    if not directed_edges:
        raise RuntimeError("Graph construction produced no edges")

    sorted_edges = sorted(directed_edges)
    edge_index = torch.tensor(np.asarray(sorted_edges).T, dtype=torch.long)
    edge_df = pd.DataFrame(edge_records).sort_values(
        ["edge_type", "source", "target"]
    )
    return node_features, edge_index, edge_df


class EdgeGATLayer(nn.Module):
    """Sparse edge-list GAT layer implemented only with core PyTorch.

    It aggregates source-node messages into target nodes. Attention is
    normalized over all incoming edges of each target node. This removes the
    torch-geometric dependency while preserving the required GAT behavior.
    """

    def __init__(
        self,
        in_dim: int,
        out_dim: int,
        heads: int = 1,
        concat: bool = True,
        dropout: float = 0.0,
        negative_slope: float = 0.2,
        add_self_loops: bool = True,
    ) -> None:
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.heads = heads
        self.concat = concat
        self.dropout = dropout
        self.negative_slope = negative_slope
        self.add_self_loops = add_self_loops

        self.weight = nn.Parameter(torch.empty(heads, in_dim, out_dim))
        self.att_src = nn.Parameter(torch.empty(heads, out_dim))
        self.att_dst = nn.Parameter(torch.empty(heads, out_dim))
        bias_dim = heads * out_dim if concat else out_dim
        self.bias = nn.Parameter(torch.zeros(bias_dim))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.weight)
        nn.init.xavier_uniform_(self.att_src.unsqueeze(-1))
        nn.init.xavier_uniform_(self.att_dst.unsqueeze(-1))
        nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        num_nodes = x.size(0)
        src = edge_index[0]
        dst = edge_index[1]

        if self.add_self_loops:
            loops = torch.arange(num_nodes, device=x.device, dtype=torch.long)
            src = torch.cat([src, loops], dim=0)
            dst = torch.cat([dst, loops], dim=0)

        # [N, H, D]
        projected = torch.einsum("ni,hio->nho", x, self.weight)
        scores = (projected[src] * self.att_src.unsqueeze(0)).sum(dim=-1)
        scores = scores + (projected[dst] * self.att_dst.unsqueeze(0)).sum(dim=-1)
        scores = F.leaky_relu(scores, negative_slope=self.negative_slope)

        # Stable segment softmax over incoming edges for every target and head.
        scatter_index = dst.unsqueeze(1).expand(-1, self.heads)
        max_per_target = torch.full(
            (num_nodes, self.heads),
            -torch.inf,
            dtype=scores.dtype,
            device=scores.device,
        )
        max_per_target.scatter_reduce_(
            0, scatter_index, scores, reduce="amax", include_self=True
        )
        exp_scores = torch.exp(scores - max_per_target[dst])
        sum_per_target = torch.zeros(
            (num_nodes, self.heads), dtype=scores.dtype, device=scores.device
        )
        sum_per_target.scatter_add_(0, scatter_index, exp_scores)
        attention = exp_scores / (sum_per_target[dst] + 1e-12)
        attention = F.dropout(attention, p=self.dropout, training=self.training)

        messages = attention.unsqueeze(-1) * projected[src]
        out = torch.zeros(
            (num_nodes, self.heads, self.out_dim),
            dtype=messages.dtype,
            device=messages.device,
        )
        out.index_add_(0, dst, messages)

        if self.concat:
            out = out.reshape(num_nodes, self.heads * self.out_dim)
        else:
            out = out.mean(dim=1)
        return out + self.bias


class ResidualHierarchicalGAT(nn.Module):
    def __init__(
        self,
        dim: int,
        hidden_dim: int,
        heads: int,
        dropout: float,
        max_residual_alpha: float,
    ) -> None:
        super().__init__()
        if hidden_dim % heads != 0:
            raise ValueError("graph_hidden_dim must be divisible by graph_heads")
        self.dropout = dropout
        self.max_residual_alpha = max_residual_alpha
        self.gat1 = EdgeGATLayer(
            dim,
            hidden_dim // heads,
            heads=heads,
            concat=True,
            dropout=dropout,
            add_self_loops=True,
        )
        self.gat2 = EdgeGATLayer(
            hidden_dim,
            dim,
            heads=1,
            concat=False,
            dropout=dropout,
            add_self_loops=True,
        )
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(dim)
        self.alpha_logit = nn.Parameter(torch.tensor(-1.0))
        self.logit_scale = nn.Parameter(torch.tensor(math.log(10.0)))

    def forward(
        self,
        node_x: torch.Tensor,
        edge_index: torch.Tensor,
        num_subtypes: int,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        h = F.dropout(node_x, p=self.dropout, training=self.training)
        h = self.gat1(h, edge_index)
        h = self.norm1(F.elu(h))
        h = F.dropout(h, p=self.dropout, training=self.training)
        delta = self.gat2(h, edge_index)
        delta = self.norm2(delta)

        alpha = self.max_residual_alpha * torch.sigmoid(self.alpha_logit)
        refined_all = F.normalize(node_x + alpha * delta, p=2, dim=1)
        refined_subtypes = refined_all[:num_subtypes]
        scale = self.logit_scale.exp().clamp(max=100.0)
        return refined_subtypes, refined_all, scale


def sample_same_type_pairs(
    subtype_to_type_idx: np.ndarray,
    max_pairs: int,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    pairs: List[Tuple[int, int]] = []
    for type_idx in np.unique(subtype_to_type_idx):
        members = np.where(subtype_to_type_idx == type_idx)[0]
        n = len(members)
        if n < 2:
            continue
        possible = n * (n - 1) // 2
        local_budget = min(possible, max(10, max_pairs // max(1, len(np.unique(subtype_to_type_idx)))))
        if possible <= local_budget:
            for i in range(n):
                for j in range(i + 1, n):
                    pairs.append((int(members[i]), int(members[j])))
        else:
            seen = set()
            while len(seen) < local_budget:
                a, b = rng.choice(members, size=2, replace=False)
                key = tuple(sorted((int(a), int(b))))
                seen.add(key)
            pairs.extend(sorted(seen))
    if len(pairs) > max_pairs:
        chosen = rng.choice(len(pairs), size=max_pairs, replace=False)
        pairs = [pairs[i] for i in chosen]
    return np.asarray(pairs, dtype=np.int64)


def subtype_logits_to_type_logits(
    subtype_logits: torch.Tensor,
    type_member_tensors: Sequence[torch.Tensor],
) -> torch.Tensor:
    return torch.stack(
        [
            torch.logsumexp(subtype_logits[:, members], dim=1)
            - math.log(max(int(members.numel()), 1))
            for members in type_member_tensors
        ],
        dim=1,
    )


@torch.no_grad()
def prototype_predict_tensor(
    embeddings: torch.Tensor,
    prototypes: torch.Tensor,
    scale: torch.Tensor,
) -> torch.Tensor:
    return (scale * (embeddings @ prototypes.T)).argmax(dim=1)


def train_graph_refiner(
    cfg: Config,
    fusion_embeddings: np.ndarray,
    subtype_y: np.ndarray,
    type_y: np.ndarray,
    split_df: pd.DataFrame,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    out_dir: Path,
    device: torch.device,
) -> Tuple[ResidualHierarchicalGAT, np.ndarray, np.ndarray, int]:
    print("\n=== Stage 2: build support prototypes and train residual graph refiner ===")
    train_idx = np.where(split_df["split"].to_numpy() == "train")[0]
    val_idx = np.where(split_df["split"].to_numpy() == "val")[0]
    support_idx, query_idx = support_query_split(
        train_idx,
        subtype_y,
        support_fraction=cfg.support_fraction,
        seed=cfg.seed + 101,
    )
    if len(query_idx) == 0:
        raise ValueError("No training query samples were created for graph refinement")

    support_raw, support_counts = compute_subtype_prototypes(
        fusion_embeddings,
        subtype_y,
        support_idx,
        num_subtypes=len(subtype_names),
    )
    node_x_np, edge_index, edge_df = build_hierarchical_graph(
        support_raw,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        k=cfg.graph_knn_k,
        min_cosine=cfg.graph_knn_min_cosine,
    )
    edge_df.to_csv(
        out_dir / "graph_edges_support.csv", index=False, encoding="utf-8-sig"
    )
    prototype_dataframe(
        support_raw,
        support_counts,
        subtype_names,
        type_names,
        subtype_to_type_idx,
    ).to_csv(
        out_dir / "support_raw_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )

    node_x = torch.from_numpy(node_x_np).float().to(device)
    edge_index = edge_index.to(device)
    query_z = torch.from_numpy(fusion_embeddings[query_idx]).float().to(device)
    query_y = torch.from_numpy(subtype_y[query_idx]).long().to(device)
    query_type_y = torch.from_numpy(type_y[query_idx]).long().to(device)
    val_z = torch.from_numpy(fusion_embeddings[val_idx]).float().to(device)
    val_y_np = subtype_y[val_idx]

    type_member_tensors = [
        torch.from_numpy(np.where(subtype_to_type_idx == t)[0]).long().to(device)
        for t in range(len(type_names))
    ]
    pair_np = sample_same_type_pairs(
        subtype_to_type_idx,
        max_pairs=cfg.graph_pair_sample_size,
        seed=cfg.seed + 202,
    )
    pair_tensor = (
        torch.from_numpy(pair_np).long().to(device)
        if len(pair_np) > 0
        else None
    )

    train_counts = np.bincount(
        subtype_y[train_idx], minlength=len(subtype_names)
    ).astype(np.int64)
    subtype_weights = effective_number_weights(
        np.repeat(np.arange(len(train_counts)), train_counts),
        num_classes=len(subtype_names),
        beta=cfg.class_weight_beta,
        max_weight=cfg.max_class_weight,
    ).to(device)

    model = ResidualHierarchicalGAT(
        dim=cfg.fusion_dim,
        hidden_dim=cfg.graph_hidden_dim,
        heads=cfg.graph_heads,
        dropout=cfg.graph_dropout,
        max_residual_alpha=cfg.graph_max_residual_alpha,
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg.graph_lr, weight_decay=cfg.graph_weight_decay
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=8, min_lr=1e-6
    )

    best_score = -np.inf
    best_state = None
    best_epoch = 0
    no_improve = 0
    history: List[Dict[str, float]] = []
    raw_support_tensor = torch.from_numpy(support_raw).float().to(device)

    for epoch in range(1, cfg.graph_epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        refined, _, scale = model(node_x, edge_index, len(subtype_names))
        subtype_logits = scale * (query_z @ refined.T)
        loss_sub = F.cross_entropy(
            subtype_logits,
            query_y,
            weight=subtype_weights,
            label_smoothing=cfg.label_smoothing,
        )
        type_logits = subtype_logits_to_type_logits(
            subtype_logits, type_member_tensors
        )
        loss_type = F.cross_entropy(type_logits, query_type_y)
        loss_recon = (1.0 - F.cosine_similarity(refined, raw_support_tensor, dim=1)).mean()

        if pair_tensor is not None and len(pair_tensor) > 0:
            pair_sim = (refined[pair_tensor[:, 0]] * refined[pair_tensor[:, 1]]).sum(dim=1)
            loss_sep = F.relu(pair_sim - cfg.graph_same_type_max_cosine).mean()
        else:
            loss_sep = refined.new_tensor(0.0)

        loss = (
            loss_sub
            + cfg.graph_type_loss_weight * loss_type
            + cfg.graph_reconstruction_weight * loss_recon
            + cfg.graph_separation_weight * loss_sep
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        model.eval()
        with torch.no_grad():
            refined_eval, _, scale_eval = model(
                node_x, edge_index, len(subtype_names)
            )
            val_pred = prototype_predict_tensor(
                val_z, refined_eval, scale_eval
            ).cpu().numpy()
            val_weighted_f1 = f1_score(
                val_y_np, val_pred, average="weighted", zero_division=0
            )
            val_macro_f1 = f1_score(
                val_y_np, val_pred, average="macro", zero_division=0
            )
            val_acc = accuracy_score(val_y_np, val_pred)
            alpha_value = float(
                cfg.graph_max_residual_alpha * torch.sigmoid(model.alpha_logit).item()
            )
            scale_value = float(scale_eval.item())

        scheduler.step(val_weighted_f1)
        row = {
            "epoch": epoch,
            "loss_total": float(loss.item()),
            "loss_subtype": float(loss_sub.item()),
            "loss_type": float(loss_type.item()),
            "loss_reconstruction": float(loss_recon.item()),
            "loss_separation": float(loss_sep.item()),
            "val_acc": val_acc,
            "val_macro_f1": val_macro_f1,
            "val_weighted_f1": val_weighted_f1,
            "residual_alpha": alpha_value,
            "logit_scale": scale_value,
            "lr": current_lr(optimizer),
        }
        history.append(row)

        if epoch == 1 or epoch % 10 == 0:
            print(
                f"Graph epoch {epoch:03d} | loss={row['loss_total']:.4f} | "
                f"val ACC={val_acc:.4f} | val macro-F1={val_macro_f1:.4f} | "
                f"val weighted-F1={val_weighted_f1:.4f} | "
                f"alpha={alpha_value:.4f} | lr={row['lr']:.2e}"
            )

        if val_weighted_f1 > best_score + 1e-6:
            best_score = val_weighted_f1
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= cfg.graph_patience:
                print(
                    f"Graph early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, best val weighted-F1={best_score:.4f}"
                )
                break

    if best_state is None:
        raise RuntimeError("Graph refinement did not produce a checkpoint")
    model.load_state_dict(best_state)
    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "graph_refiner_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "fusion_dim": cfg.fusion_dim,
            "graph_hidden_dim": cfg.graph_hidden_dim,
            "graph_heads": cfg.graph_heads,
            "graph_dropout": cfg.graph_dropout,
            "graph_max_residual_alpha": cfg.graph_max_residual_alpha,
            "config": asdict(cfg),
        },
        out_dir / "graph_refiner_best.pt",
    )

    # Rebuild evaluation prototypes from every training sequence, then apply the
    # fixed best refiner. Validation and test are not used in these prototypes.
    train_raw, train_counts = compute_subtype_prototypes(
        fusion_embeddings,
        subtype_y,
        train_idx,
        num_subtypes=len(subtype_names),
    )
    train_node_x_np, train_edge_index, train_edge_df = build_hierarchical_graph(
        train_raw,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        k=cfg.graph_knn_k,
        min_cosine=cfg.graph_knn_min_cosine,
    )
    train_edge_df.to_csv(
        out_dir / "graph_edges_train_only_final.csv",
        index=False,
        encoding="utf-8-sig",
    )

    with torch.no_grad():
        refined_train, _, _ = model(
            torch.from_numpy(train_node_x_np).float().to(device),
            train_edge_index.to(device),
            len(subtype_names),
        )
    refined_train_np = refined_train.cpu().numpy().astype(np.float32)

    prototype_dataframe(
        train_raw,
        train_counts,
        subtype_names,
        type_names,
        subtype_to_type_idx,
    ).to_csv(
        out_dir / "evaluation_train_only_raw_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    prototype_dataframe(
        refined_train_np,
        train_counts,
        subtype_names,
        type_names,
        subtype_to_type_idx,
    ).to_csv(
        out_dir / "evaluation_train_only_refined_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return model, train_raw, refined_train_np, best_epoch


# -----------------------------------------------------------------------------
# Evaluation, reports, and validation thresholds
# -----------------------------------------------------------------------------


def metric_row(y_true: np.ndarray, y_pred: np.ndarray, level: str, split: str):
    p_micro, r_micro, f_micro, _ = precision_recall_fscore_support(
        y_true, y_pred, average="micro", zero_division=0
    )
    p_macro, r_macro, f_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    p_weighted, r_weighted, f_weighted, _ = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )
    return {
        "split": split,
        "level": level,
        "N": len(y_true),
        "ACC": accuracy_score(y_true, y_pred),
        "Precision_micro": p_micro,
        "Recall_micro": r_micro,
        "F1_micro": f_micro,
        "Precision_macro": p_macro,
        "Recall_macro": r_macro,
        "F1_macro": f_macro,
        "Precision_weighted": p_weighted,
        "Recall_weighted": r_weighted,
        "F1_weighted": f_weighted,
        "MCC": matthews_corrcoef(y_true, y_pred) if len(np.unique(y_true)) > 1 else 0.0,
    }


def batched_similarity_predictions(
    embeddings: np.ndarray,
    prototypes: np.ndarray,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    predictions: List[np.ndarray] = []
    top1_scores: List[np.ndarray] = []
    top2_scores: List[np.ndarray] = []

    for start in range(0, len(embeddings), batch_size):
        end = min(start + batch_size, len(embeddings))
        sim = embeddings[start:end] @ prototypes.T
        if prototypes.shape[0] < 2:
            raise ValueError("At least two subtype prototypes are required")
        top2_idx = np.argpartition(-sim, kth=1, axis=1)[:, :2]
        top2_vals = np.take_along_axis(sim, top2_idx, axis=1)
        order = np.argsort(-top2_vals, axis=1)
        sorted_idx = np.take_along_axis(top2_idx, order, axis=1)
        sorted_vals = np.take_along_axis(top2_vals, order, axis=1)
        predictions.append(sorted_idx[:, 0])
        top1_scores.append(sorted_vals[:, 0])
        top2_scores.append(sorted_vals[:, 1])

    pred = np.concatenate(predictions).astype(np.int64)
    top1 = np.concatenate(top1_scores).astype(np.float32)
    top2 = np.concatenate(top2_scores).astype(np.float32)
    margin = top1 - top2
    return pred, top1, top2, margin


def save_classification_report_csv(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    target_names: Sequence[str],
    path: Path,
) -> None:
    labels = np.arange(len(target_names))
    report = classification_report(
        y_true,
        y_pred,
        labels=labels,
        target_names=list(target_names),
        output_dict=True,
        zero_division=0,
    )
    pd.DataFrame(report).T.to_csv(path, encoding="utf-8-sig")


def evaluate_prototypes(
    labels: pd.DataFrame,
    split_df: pd.DataFrame,
    fusion_embeddings: np.ndarray,
    prototypes: np.ndarray,
    prototype_name: str,
    subtype_y: np.ndarray,
    type_y: np.ndarray,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    cfg: Config,
    out_dir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    metric_rows = []
    prediction_parts = []

    for split_name in ["val", "test"]:
        idx = np.where(split_df["split"].to_numpy() == split_name)[0]
        if len(idx) == 0:
            continue
        pred_sub, top1, top2, margin = batched_similarity_predictions(
            fusion_embeddings[idx], prototypes, cfg.prediction_batch_size
        )
        true_sub = subtype_y[idx]
        true_type = type_y[idx]
        pred_type = subtype_to_type_idx[pred_sub]

        metric_rows.append(metric_row(true_sub, pred_sub, "Subtype", split_name))
        metric_rows.append(metric_row(true_type, pred_type, "Type_from_Subtype", split_name))

        pred_df = pd.DataFrame(
            {
                "id": labels.iloc[idx]["id"].to_numpy(),
                "split": split_name,
                "true_Subtype": [subtype_names[i] for i in true_sub],
                "pred_Subtype": [subtype_names[i] for i in pred_sub],
                "true_Type": [type_names[i] for i in true_type],
                "pred_Type": [type_names[i] for i in pred_type],
                "top1_cosine": top1,
                "top2_cosine": top2,
                "margin": margin,
                "correct_Subtype": pred_sub == true_sub,
                "correct_Type": pred_type == true_type,
                "true_subtype_index": true_sub,
                "pred_subtype_index": pred_sub,
                "true_type_index": true_type,
                "pred_type_index": pred_type,
                "prototype_set": prototype_name,
            }
        )
        prediction_parts.append(pred_df)

        save_classification_report_csv(
            true_sub,
            pred_sub,
            subtype_names,
            out_dir / f"{prototype_name}_{split_name}_subtype_classification_report.csv",
        )
        save_classification_report_csv(
            true_type,
            pred_type,
            type_names,
            out_dir / f"{prototype_name}_{split_name}_type_classification_report.csv",
        )

    metric_df = pd.DataFrame(metric_rows)
    prediction_df = pd.concat(prediction_parts, ignore_index=True)
    metric_df.to_csv(
        out_dir / f"{prototype_name}_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    prediction_df.to_csv(
        out_dir / f"{prototype_name}_predictions.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.8f",
    )
    return metric_df, prediction_df


def quantile_or_nan(values: np.ndarray, q: float) -> float:
    if len(values) == 0:
        return float("nan")
    return float(np.quantile(values, q))


def build_validation_thresholds(
    val_predictions: pd.DataFrame,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    cfg: Config,
    out_path: Path,
) -> pd.DataFrame:
    val = val_predictions[val_predictions["split"] == "val"].copy()
    correct = val[val["correct_Subtype"]].copy()
    global_sim = correct["top1_cosine"].to_numpy(dtype=float)
    global_margin = correct["margin"].to_numpy(dtype=float)
    if len(global_sim) == 0:
        raise ValueError("No correct validation predictions; cannot estimate thresholds")

    rows = []
    for subtype_idx, subtype_name in enumerate(subtype_names):
        type_idx = int(subtype_to_type_idx[subtype_idx])
        type_name = type_names[type_idx]

        subtype_correct = correct[
            correct["true_subtype_index"] == subtype_idx
        ]
        type_correct = correct[correct["true_type_index"] == type_idx]

        if len(subtype_correct) >= cfg.threshold_min_subtype_correct:
            source = "subtype_correct_validation"
            sim_values = subtype_correct["top1_cosine"].to_numpy(dtype=float)
            margin_values = subtype_correct["margin"].to_numpy(dtype=float)
        elif len(type_correct) >= cfg.threshold_min_type_correct:
            source = "type_correct_validation_fallback"
            sim_values = type_correct["top1_cosine"].to_numpy(dtype=float)
            margin_values = type_correct["margin"].to_numpy(dtype=float)
        else:
            source = "global_correct_validation_fallback"
            sim_values = global_sim
            margin_values = global_margin

        rows.append(
            {
                "subtype_index": subtype_idx,
                "Subtype": subtype_name,
                "Type": type_name,
                "subtype_correct_val_count": len(subtype_correct),
                "type_correct_val_count": len(type_correct),
                "threshold_source": source,
                "similarity_q0.10": quantile_or_nan(sim_values, 0.10),
                "similarity_q0.20": quantile_or_nan(sim_values, 0.20),
                "similarity_q0.30": quantile_or_nan(sim_values, 0.30),
                "margin_q0.10": quantile_or_nan(margin_values, 0.10),
                "margin_q0.20": quantile_or_nan(margin_values, 0.20),
                "margin_q0.30": quantile_or_nan(margin_values, 0.30),
            }
        )

    threshold_df = pd.DataFrame(rows)
    threshold_df.to_csv(out_path, index=False, encoding="utf-8-sig", float_format="%.8f")
    return threshold_df


# -----------------------------------------------------------------------------
# Deployment outputs
# -----------------------------------------------------------------------------


def build_deployment_prototypes(
    cfg: Config,
    fusion_embeddings: np.ndarray,
    subtype_y: np.ndarray,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    refiner: ResidualHierarchicalGAT,
    output_dir: Path,
    device: torch.device,
) -> None:
    deploy_dir = output_dir / "deployment_all_reference"
    deploy_dir.mkdir(parents=True, exist_ok=True)
    all_idx = np.arange(len(fusion_embeddings), dtype=np.int64)
    raw, counts = compute_subtype_prototypes(
        fusion_embeddings,
        subtype_y,
        all_idx,
        num_subtypes=len(subtype_names),
    )
    node_x_np, edge_index, edge_df = build_hierarchical_graph(
        raw,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        k=cfg.graph_knn_k,
        min_cosine=cfg.graph_knn_min_cosine,
    )
    refiner.eval()
    with torch.no_grad():
        refined, _, scale = refiner(
            torch.from_numpy(node_x_np).float().to(device),
            edge_index.to(device),
            len(subtype_names),
        )
    refined_np = refined.cpu().numpy().astype(np.float32)

    prototype_dataframe(
        raw, counts, subtype_names, type_names, subtype_to_type_idx
    ).to_csv(
        deploy_dir / "raw_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    prototype_dataframe(
        refined_np, counts, subtype_names, type_names, subtype_to_type_idx
    ).to_csv(
        deploy_dir / "refined_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    edge_df.to_csv(
        deploy_dir / "graph_edges_all_reference.csv",
        index=False,
        encoding="utf-8-sig",
    )
    save_json(
        {
            "warning": (
                "These prototypes use every labeled reference sequence. They are for "
                "deployment/real-data inference only and must not be used to report "
                "the independent test metrics produced by this run."
            ),
            "num_reference_sequences": len(fusion_embeddings),
            "num_subtypes": len(subtype_names),
            "num_types": len(type_names),
            "logit_scale": float(scale.item()),
        },
        deploy_dir / "DEPLOYMENT_ONLY_manifest.json",
    )




def build_official_train_reference_prototypes(
    cfg: Config,
    fusion_embeddings: np.ndarray,
    subtype_y: np.ndarray,
    split_df: pd.DataFrame,
    subtype_names: Sequence[str],
    type_names: Sequence[str],
    subtype_to_type_idx: np.ndarray,
    refiner: ResidualHierarchicalGAT,
    output_dir: Path,
    device: torch.device,
) -> None:
    """Build final downstream-training prototypes from original train+val only.

    The externally supplied official split treats train+val as the complete
    original training set and test as the untouched independent test set.
    These prototypes may be used by the downstream LongAA mapper/classifier.
    """
    reference_dir = output_dir / "official_train_reference"
    reference_dir.mkdir(parents=True, exist_ok=True)

    split_values = split_df["split"].astype(str).str.lower().to_numpy()
    selected_idx = np.where(split_values != "test")[0].astype(np.int64)
    if len(selected_idx) == 0:
        raise ValueError("No train+val sequences available for official train reference")

    raw, counts = compute_subtype_prototypes(
        fusion_embeddings,
        subtype_y,
        selected_idx,
        num_subtypes=len(subtype_names),
    )
    node_x_np, edge_index, edge_df = build_hierarchical_graph(
        raw,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        k=cfg.graph_knn_k,
        min_cosine=cfg.graph_knn_min_cosine,
    )

    refiner.eval()
    with torch.no_grad():
        refined, _, scale = refiner(
            torch.from_numpy(node_x_np).float().to(device),
            edge_index.to(device),
            len(subtype_names),
        )
    refined_np = refined.cpu().numpy().astype(np.float32)

    prototype_dataframe(
        raw, counts, subtype_names, type_names, subtype_to_type_idx
    ).to_csv(
        reference_dir / "raw_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    prototype_dataframe(
        refined_np, counts, subtype_names, type_names, subtype_to_type_idx
    ).to_csv(
        reference_dir / "refined_subtype_prototypes_512.csv",
        index=False,
        encoding="utf-8-sig",
    )
    edge_df.to_csv(
        reference_dir / "graph_edges_official_train.csv",
        index=False,
        encoding="utf-8-sig",
    )
    save_json(
        {
            "purpose": (
                "Use this refined prototype file as PROTO_FILE for downstream "
                "training/evaluation that uses the original train_set.csv and "
                "test_set.csv. It includes original train IDs (internal train+val) "
                "and excludes every official test ID."
            ),
            "num_reference_sequences": int(len(selected_idx)),
            "num_subtypes": int(len(subtype_names)),
            "num_types": int(len(type_names)),
            "logit_scale": float(scale.item()),
            "included_splits": ["train", "val"],
            "excluded_splits": ["test"],
        },
        reference_dir / "OFFICIAL_TRAIN_REFERENCE_manifest.json",
    )

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main() -> None:
    cfg = parse_args()
    seed_everything(cfg.seed)
    device = resolve_device(cfg.device)

    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(asdict(cfg), out_dir / "run_config.json")

    print("=" * 80)
    print("ARGScope ESM-2 1280D + DNABERT-2 768D Fusion + Refined pipeline")
    print("=" * 80)
    print(f"Device: {device}")
    print(f"Output directory: {out_dir.resolve()}")
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    print(f"Expected ESM-2 protein dimension: {EXPECTED_PROTEIN_DIM}")
    print(f"Expected DNABERT-2 DNA dimension: {EXPECTED_DNABERT2_DIM}")
    print("The old 1024-dimensional DNA/NT input will be rejected.")

    labels, aa, nt = load_and_align_data(cfg)
    split_df = assign_splits(cfg, labels, out_dir)

    (
        subtype_names,
        type_names,
        subtype_to_idx,
        type_to_idx,
        subtype_to_type_idx,
        mapping_df,
    ) = build_label_maps(labels, out_dir)

    subtype_y = labels["Subtype"].map(subtype_to_idx).to_numpy(dtype=np.int64)
    type_y = labels["Type"].map(type_to_idx).to_numpy(dtype=np.int64)

    fusion_model, fusion_best_epoch = train_fusion_model(
        cfg,
        aa,
        nt,
        subtype_y,
        type_y,
        split_df,
        num_subtypes=len(subtype_names),
        num_types=len(type_names),
        out_dir=out_dir,
        device=device,
    )

    fusion_embeddings, gate = encode_all_fusion(
        fusion_model,
        aa,
        nt,
        batch_size=cfg.prediction_batch_size,
        device=device,
    )
    save_sequence_fusion_embeddings(labels, split_df, fusion_embeddings, gate, out_dir)

    refiner, raw_train_proto, refined_train_proto, graph_best_epoch = train_graph_refiner(
        cfg,
        fusion_embeddings,
        subtype_y,
        type_y,
        split_df,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        out_dir,
        device,
    )

    raw_metrics, raw_predictions = evaluate_prototypes(
        labels,
        split_df,
        fusion_embeddings,
        raw_train_proto,
        "raw_train_only_prototype",
        subtype_y,
        type_y,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        cfg,
        out_dir,
    )
    refined_metrics, refined_predictions = evaluate_prototypes(
        labels,
        split_df,
        fusion_embeddings,
        refined_train_proto,
        "refined_train_only_prototype",
        subtype_y,
        type_y,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        cfg,
        out_dir,
    )

    combined_metrics = pd.concat(
        [
            raw_metrics.assign(prototype_set="raw_train_only"),
            refined_metrics.assign(prototype_set="refined_train_only"),
        ],
        ignore_index=True,
    )
    combined_metrics = combined_metrics[
        ["prototype_set"] + [c for c in combined_metrics.columns if c != "prototype_set"]
    ]
    combined_metrics.to_csv(
        out_dir / "raw_vs_refined_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    build_validation_thresholds(
        refined_predictions,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        cfg,
        out_dir / "prototype_similarity_thresholds_validation_only.csv",
    )

    build_official_train_reference_prototypes(
        cfg,
        fusion_embeddings,
        subtype_y,
        split_df,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        refiner,
        out_dir,
        device,
    )

    build_deployment_prototypes(
        cfg,
        fusion_embeddings,
        subtype_y,
        subtype_names,
        type_names,
        subtype_to_type_idx,
        refiner,
        out_dir,
        device,
    )

    manifest = {
        "fusion_best_epoch": fusion_best_epoch,
        "graph_best_epoch": graph_best_epoch,
        "num_sequences": len(labels),
        "num_types": len(type_names),
        "num_subtypes": len(subtype_names),
        "protein_esm2_dim": aa.shape[1],
        "dna_dnabert2_dim": nt.shape[1],
        "fusion_dim": cfg.fusion_dim,
        "evaluation_prototypes": {
            "raw": "evaluation_train_only_raw_subtype_prototypes_512.csv",
            "refined": "evaluation_train_only_refined_subtype_prototypes_512.csv",
            "note": "Built from training sequences only.",
        },
        "official_train_reference": {
            "raw": "official_train_reference/raw_subtype_prototypes_512.csv",
            "refined": "official_train_reference/refined_subtype_prototypes_512.csv",
            "note": (
                "Built from official train+val and excludes official test. "
                "Use the refined file as PROTO_FILE in the downstream LongAA training code."
            ),
        },
        "deployment_prototypes": {
            "raw": "deployment_all_reference/raw_subtype_prototypes_512.csv",
            "refined": "deployment_all_reference/refined_subtype_prototypes_512.csv",
            "note": "Built from all labeled references; not for independent test reporting.",
        },
        "thresholds": "prototype_similarity_thresholds_validation_only.csv",
        "test_usage": (
            "The test split is used only for final raw/refined prototype evaluation. "
            "It is not used for fusion training, graph training, early stopping, "
            "prototype construction, or threshold estimation."
        ),
    }
    save_json(manifest, out_dir / "pipeline_manifest.json")

    print("\n" + "=" * 80)
    print("Pipeline completed")
    print("=" * 80)
    print(combined_metrics.to_string(index=False))
    print(f"\nResults: {out_dir.resolve()}")
    print(
        "For downstream LongAA training with the original train/test split, use: "
        "official_train_reference/refined_subtype_prototypes_512.csv"
    )
    print(
        "For real-data inference after final evaluation, use: "
        "deployment_all_reference/refined_subtype_prototypes_512.csv"
    )
    print(
        "For similarity filtering, use: "
        "prototype_similarity_thresholds_validation_only.csv"
    )


if __name__ == "__main__":
    main()
