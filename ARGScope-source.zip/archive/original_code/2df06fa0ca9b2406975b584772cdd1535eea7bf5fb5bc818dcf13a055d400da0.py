"""Replot the exact Figure 3C/4C data as editable blue/orange vector SVGs.

No inputs are modified. Original per-class values are retained. Average rows
are recomputed as unweighted means of the displayed classes, including nonARG.
Displayed numeric labels use two decimals, with exact zeros shown as 0.
Subunit values that round to 1.00 are labeled 0.99 so 1.00 is reserved for
exactly perfect scores. Colors use original unrounded scores on a linear 0-1 scale.
"""

from __future__ import annotations

import csv
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
import math
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

DEST = Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\结果图\SVG素材\Figure3_Figure4_type_heatmaps_20261013")
BUILD = DEST / ".build"
sys.path.insert(0, str(BUILD / "plot_runtime"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.cm import ScalarMappable
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Rectangle
from matplotlib.text import Text
from matplotlib.ticker import FormatStrFormatter
import numpy as np

ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW\Including_nonARG_20260922")
METRICS = ("Precision", "Recall", "F1")
COMMON_TYPES = [
    "beta_lactam", "trimethoprim", "macrolide-lincosamide-streptogramin",
    "fusidic_acid", "fosfomycin", "aminoglycoside", "quinolone", "multidrug",
    "chloramphenicol", "rifamycin", "tetracycline", "bacitracin", "sulfonamide",
]
SETTINGS = {
    "Protein": {
        "stem": "Figure3C_type_heatmap_blue_displayed_average",
        "palette": "blue",
        "models": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
        "types": COMMON_TYPES + ["tetracenomycin_C", "tunicamycin", "streptothricin", "polymyxin", "bleomycin", "nonARG"],
        "averages": {
            "Precision": [.7268, .4884, .1997, .4438, .9333],
            "Recall": [.7022, .4397, .1532, .4199, .9503],
            "F1": [.6892, .4599, .1653, .4194, .9383],
        },
    },
    "DNA": {
        "stem": "Figure4C_type_heatmap_orange_displayed_average",
        "palette": "orange",
        "models": ["ARGNet", "DeepARG", "ARGScope"],
        "types": COMMON_TYPES + ["polymyxin", "nonARG"],
        "averages": {
            "Precision": [.0773, .3751, .8777],
            "Recall": [.0730, .3451, .8248],
            "F1": [.0745, .3582, .8414],
        },
    },
}
DISPLAY = {
    "beta_lactam": "Beta-lactams", "trimethoprim": "Trimethoprim",
    "macrolide-lincosamide-streptogramin": "MLS", "fusidic_acid": "Fusidic acid",
    "fosfomycin": "Fosfomycin", "aminoglycoside": "Aminoglycosides",
    "quinolone": "Quinolones", "multidrug": "Multidrug",
    "chloramphenicol": "Chloramphenicol", "rifamycin": "Rifamycin",
    "tetracycline": "Tetracyclines", "bacitracin": "Bacitracin",
    "sulfonamide": "Sulfonamide", "tetracenomycin_C": "Tetracenomycin C",
    "tunicamycin": "Tunicamycin", "streptothricin": "Streptothricin",
    "polymyxin": "Polymyxin", "bleomycin": "Bleomycin", "nonARG": "Non-ARG",
}

# Single-hue sequential palettes. Both use the same linear 0-1 score range.
CMAPS = {
    "blue": LinearSegmentedColormap.from_list(
        "ARGScope_single_blue",
        ["#f7fbff", "#dceaf5", "#b9d5e9", "#82b4d7", "#468cbe", "#1b619d", "#08376d"],
        N=1024,
    ),
    "orange": LinearSegmentedColormap.from_list(
        "ARGScope_single_orange",
        ["#fff8f1", "#fde8d0", "#fbd2a5", "#f9b36f", "#f79343", "#de7024", "#a94d0a"],
        N=1024,
    ),
}
NORM = Normalize(vmin=0, vmax=1)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def display_score(value: float) -> str:
    if value == 0:
        return "0"
    rounded = Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if value < 1 and rounded == Decimal("1.00"):
        return "0.99"
    return f"{rounded:.2f}"


def annotation_color(value: float, cmap) -> str:
    rgb = np.asarray(cmap(NORM(value))[:3])
    linear = np.where(rgb <= .04045, rgb / 12.92, ((rgb + .055) / 1.055) ** 2.4)
    luminance = float(linear @ np.asarray([.2126, .7152, .0722]))
    return "white" if luminance < .20 else "#111111"


def validate_and_load(modality: str) -> tuple[dict, dict]:
    settings = SETTINGS[modality]
    source = ROOT / "Figure2_Figure3_SVG" / "plot_data" / modality / "C_heatmap_values.csv"
    per_source = ROOT / "data" / modality / "Per_Type_23_ARG_plus_nonARG_60_100.csv"
    average_source = ROOT / "data" / modality / "Type_macro_weighted_micro_60_100.csv"
    rows = read_csv(source)
    lookup = {}
    for row in rows:
        assert row["Modality"] == modality
        key = (row["Metric"], row["Type"], row["Model"])
        assert key not in lookup, ("duplicate cell", key)
        value = float(row["Value"])
        assert math.isfinite(value) and 0 <= value <= 1, (key, value)
        lookup[key] = value
    expected_keys = {
        (metric, typ, model)
        for metric in METRICS
        for typ in ["Average"] + settings["types"]
        for model in settings["models"]
    }
    assert set(lookup) == expected_keys, (
        "unexpected/missing display cells", set(lookup) ^ expected_keys
    )
    for metric, expected in settings["averages"].items():
        assert [round(lookup[metric, "Average", model], 4) for model in settings["models"]] == expected

    # Independently check each plotted cell against the full-label count table.
    full_rows = [row for row in read_csv(per_source) if float(row["Completeness"]) == 100]
    per_lookup = {(row["Model"], row["Type"]): row for row in full_rows}
    average_lookup = {
        row["Model"]: row for row in read_csv(average_source)
        if float(row["Completeness"]) == 100 and row["Average"] == "macro"
    }
    for (metric, typ, model), value in lookup.items():
        if typ == "Average":
            reference = average_lookup[model]
            assert int(reference["N_labels_averaged"]) == 24
            assert reference["Scope"] == "including_nonARG_fixed24"
            target = float(reference[metric])
        else:
            reference = per_lookup[model, typ]
            target = float(reference[metric])
            tp, fp, fn = (float(reference[field]) for field in ("TP", "FP", "FN"))
            numerator, denominator = {
                "Precision": (tp, tp + fp), "Recall": (tp, tp + fn),
                "F1": (2 * tp, 2 * tp + fp + fn),
            }[metric]
            recomputed = numerator / denominator if denominator else 0
            assert math.isclose(target, recomputed, rel_tol=0, abs_tol=2e-12), (metric, typ, model)
        assert math.isclose(value, target, rel_tol=0, abs_tol=2e-12), (metric, typ, model, value, target)

    if modality == "Protein":
        assert round(lookup["Recall", "fosfomycin", "DeepARG"], 4) == .9604
        assert round(lookup["F1", "beta_lactam", "FunGeneTyper"], 4) == .9983

    # The original all-24 macro values above are validated but not plotted as
    # Average in this version. Recompute from full-precision displayed rows only.
    original_averages = {
        metric: {model: lookup[metric, "Average", model] for model in settings["models"]}
        for metric in METRICS
    }
    assert "nonARG" in settings["types"]
    for metric in METRICS:
        for model in settings["models"]:
            values = [lookup[metric, typ, model] for typ in settings["types"]]
            shown_average = math.fsum(values) / len(settings["types"])
            from_counts = []
            for typ in settings["types"]:
                reference = per_lookup[model, typ]
                tp, fp, fn = (float(reference[field]) for field in ("TP", "FP", "FN"))
                numerator, denominator = {
                    "Precision": (tp, tp + fp), "Recall": (tp, tp + fn),
                    "F1": (2 * tp, 2 * tp + fp + fn),
                }[metric]
                from_counts.append(numerator / denominator if denominator else 0)
            independent_average = math.fsum(from_counts) / len(settings["types"])
            assert math.isclose(shown_average, independent_average, rel_tol=0, abs_tol=2e-12)
            lookup[metric, "Average", model] = shown_average

    provenance = {
        "modality": modality,
        "display_source": str(source), "display_source_sha256": file_sha(source),
        "per_type_source": str(per_source), "per_type_source_sha256": file_sha(per_source),
        "average_source": str(average_source), "average_source_sha256": file_sha(average_source),
        "source_populations": {
            model: {"N": int(average_lookup[model]["N"]), "prediction_source": average_lookup[model]["Source"]}
            for model in settings["models"]
        },
        "shown_types": settings["types"], "methods": settings["models"],
        "cell_count": len(lookup), "average_label_count": len(settings["types"]),
        "average_scope": "displayed classes only, including nonARG",
        "average_weighting": "equal weight per displayed class; unrounded values",
        "original_full_label_macro_count": 24,
        "original_full_label_macro_values": original_averages,
        "displayed_average_values": {
            model: {metric: lookup[metric, "Average", model] for metric in METRICS}
            for model in settings["models"]
        },
        "per_class_values_unchanged": True, "average_rows_recomputed": True,
        "per_class_values_verified_against_TP_FP_FN": True,
        "original_full_label_macro_values_verified": True,
        "displayed_averages_verified_against_count_derived_class_metrics": True,
    }
    return lookup, provenance


def draw(modality: str) -> dict:
    settings = SETTINGS[modality]
    cmap = CMAPS[settings["palette"]]
    models, types = settings["models"], settings["types"]
    lookup, provenance = validate_and_load(modality)
    width = 12.0
    left, right, bottom, top = 1.94, .55, .94, .38
    row_h, average_gap, panel_gap, color_gap, color_w = .25, .14, .23, .16, .12
    panel_w = (width - left - right - 2 * panel_gap - color_gap - color_w) / 3
    heat_h = len(types) * row_h
    total_h = heat_h + average_gap + row_h
    height = bottom + total_h + top
    fig = plt.figure(figsize=(width, height), facecolor="none")
    annotations = []
    audit_rows = []

    def axes_rect(x: float, y: float, w: float, h: float) -> list[float]:
        return [x / width, y / height, w / width, h / height]

    for idx, metric in enumerate(METRICS):
        x = left + idx * (panel_w + panel_gap)
        ax = fig.add_axes(axes_rect(x, bottom, panel_w, heat_h))
        avg_ax = fig.add_axes(axes_rect(x, bottom + heat_h + average_gap, panel_w, row_h))
        for current, row_names in ((ax, types), (avg_ax, ["Average"])):
            is_average = current is avg_ax
            for i, typ in enumerate(row_names):
                for j, model in enumerate(models):
                    value = lookup[metric, typ, model]
                    current.add_patch(Rectangle(
                        (j - .5, i - .5), 1, 1, facecolor=cmap(NORM(value)),
                        edgecolor="white", linewidth=.70, zorder=0,
                    ))
                    label = display_score(value)
                    assert (label == "1.00") == (value == 1), (metric, typ, model, value, label)
                    text = current.text(
                        j, i, label, ha="center", va="center", fontsize=11,
                        fontweight="bold" if is_average else "normal",
                        color=annotation_color(value, cmap), clip_on=False,
                    )
                    annotations.append((current, text, j, i))
                    audit_rows.append({
                        "Modality": modality, "Metric": metric, "Type": typ,
                        "Model": model, "Raw_value": repr(value), "Display_value": label,
                    })
            current.set_xlim(-.5, len(models) - .5)
            current.set_ylim(len(row_names) - .5, -.5)
            current.tick_params(which="both", length=0)
            for spine in current.spines.values():
                spine.set_visible(False)

        avg_ax.set_title(metric, fontsize=14, fontweight="bold", pad=8)
        avg_ax.set_xticks([])
        avg_ax.set_yticks([0], ["Average" if idx == 0 else ""], fontsize=12, fontweight="bold")
        avg_ax.tick_params(axis="y", pad=7)
        ax.set_yticks(range(len(types)), [DISPLAY[t] for t in types] if idx == 0 else [""] * len(types), fontsize=12)
        ax.tick_params(axis="y", pad=7)
        ax.set_xticks(range(len(models)), models, fontsize=11.5, rotation=45,
                      rotation_mode="anchor", ha="right")
        ax.tick_params(axis="x", pad=6)
        for label in ax.get_xticklabels():
            if label.get_text() == "ARGScope":
                label.set_fontweight("bold")

    color_x = left + 3 * panel_w + 2 * panel_gap + color_gap
    cax = fig.add_axes(axes_rect(color_x, bottom, color_w, total_h))
    cb = fig.colorbar(ScalarMappable(norm=NORM, cmap=cmap), cax=cax, ticks=[0, .25, .5, .75, 1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    cb.ax.tick_params(labelsize=10.5, length=2, width=.55, pad=4)
    cb.outline.set_visible(False)
    cb.solids.set_rasterized(False)

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for ax, text, j, i in annotations:
        box = text.get_window_extent(renderer)
        corners = ax.transData.transform([[j - .5, i - .5], [j + .5, i + .5]])
        assert box.x0 > corners[:, 0].min() and box.x1 < corners[:, 0].max(), text.get_text()
        assert box.y0 > corners[:, 1].min() and box.y1 < corners[:, 1].max(), text.get_text()
    for artist in fig.findobj(match=Text):
        if artist.get_visible() and artist.get_text():
            assert artist.get_fontfamily() == ["Arial"]

    svg = DEST / f"{settings['stem']}.svg"
    pdf = BUILD / f"{settings['stem']}.pdf"
    png = BUILD / f"{settings['stem']}_preview.png"
    save_options = {"bbox_inches": "tight", "pad_inches": .035}
    metadata = {"Title": f"{modality} resistance-type precision, recall and F1",
                "Description": f"Per-class original scores unchanged. Average is the unweighted mean of the {len(types)} displayed classes, including non-ARG, computed before label formatting. Linear 0-1 {settings['palette']} colors use full-precision plotted values. Two-decimal labels: zero shown as 0; values below 1 that would round to 1.00 are shown as 0.99; 1.00 is reserved for raw scores exactly equal to 1."}
    fig.savefig(svg, transparent=True, metadata=metadata, **save_options)
    fig.savefig(pdf, transparent=True, **save_options)
    fig.savefig(png, dpi=300, facecolor="white", transparent=False, **save_options)
    plt.close(fig)

    root = ET.parse(svg).getroot()
    ns = {"svg": "http://www.w3.org/2000/svg"}
    assert not root.findall(".//svg:image", ns), "Raster image embedded in SVG"
    texts = ["".join(item.itertext()) for item in root.findall(".//svg:text", ns)]
    assert len(texts) >= len(annotations)
    assert all(item["Display_value"] in texts for item in audit_rows)
    assert all(display_score(0) == "0" for _ in [0])
    assert "0.0000" not in texts and "1.0000" not in texts
    assert all(label in texts for label in METRICS)
    assert not any(label in {"A", "B", "C", "D"} for label in texts)

    audit = BUILD / f"{modality}_plotted_values_displayed_average.csv"
    with audit.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(audit_rows[0]))
        writer.writeheader()
        writer.writerows(audit_rows)
    provenance.update({
        "svg": str(svg), "preview": str(png), "pdf": str(pdf),
        "svg_sha256": file_sha(svg), "svg_text_count": len(texts),
        "pure_vector_no_embedded_images": True, "font": "Arial",
        "editable_text": True, "annotation_font_pt": 11,
        "number_format": "0 for exact zero; round half up to two decimals, but subunit values that would round to 1.00 are capped at 0.99; only raw 1 is shown as 1.00",
        "colors_use_unrounded_original_values": True,
        "all_1_00_labels_verified_as_raw_1": True,
        "labels_prevented_from_rounding_to_1": sum(
            float(row["Raw_value"]) < 1
            and Decimal(row["Raw_value"]).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) == Decimal("1.00")
            for row in audit_rows
        ),
        "palette": f"single {settings['palette']}", "color_range": [0, 1], "color_normalization": "linear",
        "transparent_svg_background": True, "annotation_bounds_checked": True,
    })
    return provenance


def main() -> None:
    DEST.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(exist_ok=True)
    font_manager.findfont("Arial", fallback_to_default=False)
    plt.rcParams.update({
        "font.family": "Arial", "svg.fonttype": "none", "pdf.fonttype": 42,
        "text.color": "#111111", "axes.unicode_minus": False,
    })
    audits = [draw(modality) for modality in SETTINGS]
    verification = BUILD / "verification_displayed_average.json"
    with verification.open("w", encoding="utf-8") as handle:
        json.dump(audits, handle, ensure_ascii=False, indent=2)
    for audit in audits:
        print(f"{audit['modality']}: Average over {audit['average_label_count']} displayed classes, including nonARG.")
        for model, values in audit["displayed_average_values"].items():
            print(f"  {model}: " + ", ".join(f"{metric}={values[metric]:.4f}" for metric in METRICS))


if __name__ == "__main__":
    main()
