from pathlib import Path
from zipfile import ZipFile
from docx import Document
import json

base = Path(__file__).resolve().parent
source = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\1. ARGScope_manuscript_Abstract_v2_20260921.docx')
with ZipFile(source) as z:
    (base/'workflow.png').write_bytes(z.read('word/media/image1.png'))
doc = Document(source)
(base/'manuscript_text.txt').write_text('\n'.join(p.text for p in doc.paragraphs),encoding='utf-8')
print(base/'workflow.png')

supp = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary_materials_including_nonARG_20260922.docx')
tables = Document(supp).tables
records = []
for idx, model, task in [(0,'AA','ARG/non-ARG'),(3,'NT','ARG/non-ARG'),(1,'AA','Type / macro'),(4,'NT','Type / macro'),(2,'AA','Subtype / macro'),(5,'NT','Subtype / macro')]:
    rows = [[c.text.strip() for c in r.cells] for r in tables[idx].rows]
    row = next(r for r in rows if r[0]=='100%' and ('macro' in r or task=='ARG/non-ARG'))
    records.append([task,model,*row[-5:]])
assert records[0][2:] == ['0.9976','0.9978','0.9974','0.9976','0.9952']
assert records[2][5] == '0.9383'
(base/'supplement_key_metrics.json').write_text(json.dumps({'source':str(supp),'rows':records},ensure_ascii=False,indent=2),encoding='utf-8')
