#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Calculate all five-metric summaries for the six ARGScope ablations.

Right-click usage
-----------------
Put this script in the same folder as these six files and run it directly:

    DNA_wograph_test_sequence_predictions.csv
    DNA_wotransfer_test_sequence_predictions.csv
    DNA_wogate_test_sequence_predictions.csv
    protein_wograph_test_sequence_predictions.csv
    protein_wotransfer_test_sequence_predictions.csv
    protein_wogate_test_sequence_predictions.csv

The default output folder is:

    ablation_all_metrics_results

The five metrics are Accuracy, Precision, Recall, F1 and MCC.

Evaluation scopes
-----------------
1. ARG/nonARG: all test sequences; ARG=1 is the positive class.
2. Type/subtype, all_sequences: all test sequences; nonARG is a class.
3. Type/subtype, true_ARG_only_end_to_end: only true ARG sequences are
   selected, but a predicted nonARG is retained and counted as an error.
4. Per-Type and per-subtype tables: one-vs-rest over all test sequences,
   matching the model's class-level result-table convention.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

import sklearn
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)


SCRIPT_VERSION = "2026-09-16-ablation-all-five-metrics-v1"
HERE = Path(__file__).resolve().parent
DEFAULT_OUTPUT_NAME = "ablation_all_metrics_results"

REQUIRED_COLUMNS = (
    "sequence_id",
    "true_subtype",
    "predicted_subtype",
    "true_type",
    "predicted_type",
    "true_ARG",
    "predicted_ARG",
)

AVERAGES = ("macro", "weighted", "micro")
METRIC_NAMES = ("accuracy", "precision", "recall", "f1", "mcc")


@dataclass(frozen=True)
class ModelSpec:
    model: str
    modality: str
    ablation: str
    filename: str


MODEL_SPECS = (
    ModelSpec(
        "DNA_wograph",
        "DNA",
        "w/o Graph",
        "DNA_wograph_test_sequence_predictions.csv",
    ),
    ModelSpec(
        "DNA_wotransfer",
        "DNA",
        "w/o Knowledge Transfer",
        "DNA_wotransfer_test_sequence_predictions.csv",
    ),
    ModelSpec(
        "DNA_wogate",
        "DNA",
        "w/o Adaptive Gating",
        "DNA_wogate_test_sequence_predictions.csv",
    ),
    ModelSpec(
        "protein_wograph",
        "Protein",
        "w/o Graph",
        "protein_wograph_test_sequence_predictions.csv",
    ),
    ModelSpec(
        "protein_wotransfer",
        "Protein",
        "w/o Knowledge Transfer",
        "protein_wotransfer_test_sequence_predictions.csv",
    ),
    ModelSpec(
        "protein_wogate",
        "Protein",
        "w/o Adaptive Gating",
        "protein_wogate_test_sequence_predictions.csv",
    ),
)


@dataclass
class PredictionData:
    spec: ModelSpec
    path: Path
    rows: list[dict[str, str]]
    sequence_ids: list[str]
    true_arg: list[int]
    predicted_arg: list[int]
    true_type: list[str]
    predicted_type: list[str]
    true_subtype: list[str]
    predicted_subtype: list[str]
    truth_inconsistencies: int
    prediction_inconsistencies: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Calculate all metrics for six DNA/Protein ablation CSV files."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=HERE,
        help="Folder containing the six prediction CSV files (default: script folder).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Output folder. Default: <input-dir>/ablation_all_metrics_results"
        ),
    )
    return parser.parse_args()


def clean_text(value: object) -> str:
    return "" if value is None else str(value).strip()


def is_nonarg(value: str) -> bool:
    return clean_text(value).lower() == "nonarg"


def parse_binary(value: object, column: str, row_number: int, path: Path) -> int:
    text = clean_text(value).lower()
    if text in {"1", "1.0", "arg", "true", "yes"}:
        return 1
    if text in {"0", "0.0", "nonarg", "false", "no"}:
        return 0
    raise ValueError(
        f"{path.name}: invalid {column} value at CSV row {row_number}: {value!r}"
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_prediction_file(spec: ModelSpec, input_dir: Path) -> PredictionData:
    path = input_dir / spec.filename
    if not path.is_file():
        raise FileNotFoundError(f"Missing required prediction file: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"CSV has no header: {path}")
        missing_columns = [
            column for column in REQUIRED_COLUMNS if column not in reader.fieldnames
        ]
        if missing_columns:
            raise KeyError(
                f"{path.name} is missing columns: {', '.join(missing_columns)}"
            )
        rows = list(reader)

    if not rows:
        raise ValueError(f"Prediction CSV is empty: {path}")

    sequence_ids: list[str] = []
    true_arg: list[int] = []
    predicted_arg: list[int] = []
    true_type: list[str] = []
    predicted_type: list[str] = []
    true_subtype: list[str] = []
    predicted_subtype: list[str] = []
    truth_inconsistencies = 0
    prediction_inconsistencies = 0

    for row_number, row in enumerate(rows, start=2):
        values = {column: clean_text(row.get(column)) for column in REQUIRED_COLUMNS}
        empty_columns = [column for column, value in values.items() if not value]
        if empty_columns:
            raise ValueError(
                f"{path.name}: empty required value(s) at CSV row {row_number}: "
                + ", ".join(empty_columns)
            )

        if "split" in row and clean_text(row.get("split")).lower() != "test":
            raise ValueError(
                f"{path.name}: non-test row found at CSV row {row_number}"
            )

        y_arg = parse_binary(row["true_ARG"], "true_ARG", row_number, path)
        p_arg = parse_binary(
            row["predicted_ARG"], "predicted_ARG", row_number, path
        )

        y_type = values["true_type"]
        p_type = values["predicted_type"]
        y_subtype = values["true_subtype"]
        p_subtype = values["predicted_subtype"]

        if (y_arg == 0) != (is_nonarg(y_type) and is_nonarg(y_subtype)):
            truth_inconsistencies += 1
        if (p_arg == 0) != (is_nonarg(p_type) and is_nonarg(p_subtype)):
            prediction_inconsistencies += 1

        sequence_ids.append(values["sequence_id"])
        true_arg.append(y_arg)
        predicted_arg.append(p_arg)
        true_type.append(y_type)
        predicted_type.append(p_type)
        true_subtype.append(y_subtype)
        predicted_subtype.append(p_subtype)

    duplicate_count = len(sequence_ids) - len(set(sequence_ids))
    if duplicate_count:
        raise ValueError(
            f"{path.name}: found {duplicate_count} duplicate sequence_id row(s)"
        )
    if truth_inconsistencies:
        raise ValueError(
            f"{path.name}: {truth_inconsistencies} true-label hierarchy "
            "inconsistency row(s)"
        )
    if prediction_inconsistencies:
        raise ValueError(
            f"{path.name}: {prediction_inconsistencies} predicted-label hierarchy "
            "inconsistency row(s)"
        )

    return PredictionData(
        spec=spec,
        path=path,
        rows=rows,
        sequence_ids=sequence_ids,
        true_arg=true_arg,
        predicted_arg=predicted_arg,
        true_type=true_type,
        predicted_type=predicted_type,
        true_subtype=true_subtype,
        predicted_subtype=predicted_subtype,
        truth_inconsistencies=truth_inconsistencies,
        prediction_inconsistencies=prediction_inconsistencies,
    )


def validate_same_test_set(all_data: Sequence[PredictionData]) -> None:
    if not all_data:
        raise ValueError("No prediction data loaded")

    reference = all_data[0]
    reference_truth = {
        sequence_id: (true_arg, true_type, true_subtype)
        for sequence_id, true_arg, true_type, true_subtype in zip(
            reference.sequence_ids,
            reference.true_arg,
            reference.true_type,
            reference.true_subtype,
        )
    }

    for data in all_data[1:]:
        if set(data.sequence_ids) != set(reference.sequence_ids):
            missing = len(set(reference.sequence_ids) - set(data.sequence_ids))
            extra = len(set(data.sequence_ids) - set(reference.sequence_ids))
            raise ValueError(
                f"{data.path.name}: test ID set differs from {reference.path.name}; "
                f"missing={missing}, extra={extra}"
            )

        current_truth = {
            sequence_id: (true_arg, true_type, true_subtype)
            for sequence_id, true_arg, true_type, true_subtype in zip(
                data.sequence_ids,
                data.true_arg,
                data.true_type,
                data.true_subtype,
            )
        }
        mismatches = sum(
            current_truth[sequence_id] != reference_truth[sequence_id]
            for sequence_id in reference_truth
        )
        if mismatches:
            raise ValueError(
                f"{data.path.name}: {mismatches} ground-truth row(s) differ from "
                f"{reference.path.name}"
            )


def metric_value(value: float) -> float:
    return round(float(value), 6)


def model_columns(data: PredictionData) -> dict[str, object]:
    return {
        "model": data.spec.model,
        "modality": data.spec.modality,
        "ablation": data.spec.ablation,
        "prediction_source": data.path.name,
    }


def binary_metric_row(data: PredictionData) -> dict[str, object]:
    y_true = data.true_arg
    y_pred = data.predicted_arg
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        **model_columns(data),
        "level": "ARG_nonARG",
        "scope": "all_sequences",
        "positive_class": "ARG",
        "negative_class": "nonARG",
        "accuracy": metric_value(accuracy_score(y_true, y_pred)),
        "precision": metric_value(
            precision_score(y_true, y_pred, pos_label=1, zero_division=0)
        ),
        "recall": metric_value(
            recall_score(y_true, y_pred, pos_label=1, zero_division=0)
        ),
        "f1": metric_value(f1_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "mcc": metric_value(matthews_corrcoef(y_true, y_pred)),
        "n_sequences": len(y_true),
        "ARG_support": int(sum(y_true)),
        "nonARG_support": int(len(y_true) - sum(y_true)),
        "TP": int(tp),
        "FP": int(fp),
        "FN": int(fn),
        "TN": int(tn),
    }


def multiclass_metric_rows(
    data: PredictionData,
    level: str,
    scope: str,
    y_true: Sequence[str],
    y_pred: Sequence[str],
    evaluation_labels: Sequence[str],
) -> list[dict[str, object]]:
    if not y_true or len(y_true) != len(y_pred):
        raise ValueError(f"Invalid {data.spec.model} {level} {scope} arrays")
    if not evaluation_labels:
        raise ValueError(f"No evaluation labels for {level} {scope}")

    accuracy = metric_value(accuracy_score(y_true, y_pred))
    mcc = metric_value(matthews_corrcoef(y_true, y_pred))
    rows: list[dict[str, object]] = []

    for average in AVERAGES:
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            labels=list(evaluation_labels),
            average=average,
            zero_division=0,
        )
        rows.append(
            {
                **model_columns(data),
                "level": level,
                "scope": scope,
                "average": average,
                "accuracy": accuracy,
                "precision": metric_value(precision),
                "recall": metric_value(recall),
                "f1": metric_value(f1),
                "mcc": mcc,
                "n_sequences": len(y_true),
                "n_true_classes": len(set(y_true)),
                "n_evaluation_labels": len(evaluation_labels),
                "predicted_nonARG_count": sum(is_nonarg(value) for value in y_pred),
            }
        )
    return rows


def one_vs_rest_rows(
    data: PredictionData,
    level: str,
    y_true: Sequence[str],
    y_pred: Sequence[str],
) -> list[dict[str, object]]:
    labels = sorted(set(y_true) | set(y_pred), key=lambda value: value.lower())
    matrix = confusion_matrix(y_true, y_pred, labels=labels)
    row_totals = matrix.sum(axis=1)
    column_totals = matrix.sum(axis=0)
    total = int(matrix.sum())
    rows: list[dict[str, object]] = []

    for index, label in enumerate(labels):
        tp = int(matrix[index, index])
        fn = int(row_totals[index] - tp)
        fp = int(column_totals[index] - tp)
        tn = int(total - tp - fn - fp)

        accuracy = (tp + tn) / total if total else 0.0
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = (
            2.0 * precision * recall / (precision + recall)
            if (precision + recall)
            else 0.0
        )
        mcc_denominator = math.sqrt(
            (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
        )
        mcc = (
            ((tp * tn) - (fp * fn)) / mcc_denominator
            if mcc_denominator
            else 0.0
        )

        rows.append(
            {
                **model_columns(data),
                "level": level,
                "scope": "all_sequences_one_vs_rest",
                "class": label,
                "accuracy": metric_value(accuracy),
                "precision": metric_value(precision),
                "recall": metric_value(recall),
                "f1": metric_value(f1),
                "mcc": metric_value(mcc),
                "support": int(row_totals[index]),
                "predicted_count": int(column_totals[index]),
                "correct_count": int(tp),
                "wrong_count": int(fp + fn),
                "TP": int(tp),
                "FP": int(fp),
                "FN": int(fn),
                "TN": int(tn),
                "total_samples": total,
            }
        )
    return rows


def select_metric_row(
    rows: Iterable[dict[str, object]],
    model: str,
    scope: str,
    average: str,
) -> dict[str, object]:
    matches = [
        row
        for row in rows
        if row["model"] == model
        and row["scope"] == scope
        and row["average"] == average
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"Expected one metric row for {model}, {scope}, {average}; "
            f"found {len(matches)}"
        )
    return matches[0]


def write_csv(path: Path, rows: Sequence[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    fieldnames = list(rows[0].keys())
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def main() -> None:
    args = parse_args()
    input_dir = args.input_dir.expanduser().resolve()
    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else input_dir / DEFAULT_OUTPUT_NAME
    )

    if not input_dir.is_dir():
        raise NotADirectoryError(f"Input directory does not exist: {input_dir}")

    print(f"Input folder : {input_dir}", flush=True)
    print(f"Output folder: {output_dir}", flush=True)

    all_data = [load_prediction_file(spec, input_dir) for spec in MODEL_SPECS]
    validate_same_test_set(all_data)

    binary_rows: list[dict[str, object]] = []
    type_rows: list[dict[str, object]] = []
    subtype_rows: list[dict[str, object]] = []
    per_type_rows: list[dict[str, object]] = []
    per_subtype_rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []

    for data in all_data:
        binary_rows.append(binary_metric_row(data))

        arg_indices = [
            index for index, value in enumerate(data.true_arg) if value == 1
        ]
        true_arg_type = [data.true_type[index] for index in arg_indices]
        predicted_arg_type = [data.predicted_type[index] for index in arg_indices]
        true_arg_subtype = [data.true_subtype[index] for index in arg_indices]
        predicted_arg_subtype = [
            data.predicted_subtype[index] for index in arg_indices
        ]

        type_all_labels = sorted(
            set(data.true_type) | set(data.predicted_type),
            key=lambda value: value.lower(),
        )
        subtype_all_labels = sorted(
            set(data.true_subtype) | set(data.predicted_subtype),
            key=lambda value: value.lower(),
        )
        type_arg_labels = sorted(
            set(true_arg_type), key=lambda value: value.lower()
        )
        subtype_arg_labels = sorted(
            set(true_arg_subtype), key=lambda value: value.lower()
        )

        type_rows.extend(
            multiclass_metric_rows(
                data,
                "Type",
                "all_sequences_including_nonARG",
                data.true_type,
                data.predicted_type,
                type_all_labels,
            )
        )
        type_rows.extend(
            multiclass_metric_rows(
                data,
                "Type",
                "true_ARG_only_end_to_end",
                true_arg_type,
                predicted_arg_type,
                type_arg_labels,
            )
        )

        subtype_rows.extend(
            multiclass_metric_rows(
                data,
                "subtype",
                "all_sequences_including_nonARG",
                data.true_subtype,
                data.predicted_subtype,
                subtype_all_labels,
            )
        )
        subtype_rows.extend(
            multiclass_metric_rows(
                data,
                "subtype",
                "true_ARG_only_end_to_end",
                true_arg_subtype,
                predicted_arg_subtype,
                subtype_arg_labels,
            )
        )

        per_type_rows.extend(
            one_vs_rest_rows(
                data, "Type", data.true_type, data.predicted_type
            )
        )
        per_subtype_rows.extend(
            one_vs_rest_rows(
                data, "subtype", data.true_subtype, data.predicted_subtype
            )
        )

        audit_rows.append(
            {
                **model_columns(data),
                "sha256": sha256_file(data.path),
                "rows": len(data.rows),
                "unique_sequence_ids": len(set(data.sequence_ids)),
                "duplicate_sequence_ids": len(data.sequence_ids)
                - len(set(data.sequence_ids)),
                "true_ARG": int(sum(data.true_arg)),
                "true_nonARG": int(len(data.true_arg) - sum(data.true_arg)),
                "true_types_including_nonARG": len(set(data.true_type)),
                "true_subtypes_including_nonARG": len(set(data.true_subtype)),
                "predicted_ARG": int(sum(data.predicted_arg)),
                "predicted_nonARG": int(
                    len(data.predicted_arg) - sum(data.predicted_arg)
                ),
                "truth_hierarchy_inconsistencies": data.truth_inconsistencies,
                "prediction_hierarchy_inconsistencies": (
                    data.prediction_inconsistencies
                ),
                "same_test_IDs_as_reference": True,
                "same_ground_truth_as_reference": True,
            }
        )

    compact_rows: list[dict[str, object]] = []
    binary_by_model = {row["model"]: row for row in binary_rows}
    for data in all_data:
        binary = binary_by_model[data.spec.model]
        type_macro = select_metric_row(
            type_rows,
            data.spec.model,
            "true_ARG_only_end_to_end",
            "macro",
        )
        subtype_weighted = select_metric_row(
            subtype_rows,
            data.spec.model,
            "true_ARG_only_end_to_end",
            "weighted",
        )
        compact = {
            **model_columns(data),
            "ARG_nonARG_accuracy": binary["accuracy"],
            "ARG_nonARG_precision_ARG_positive": binary["precision"],
            "ARG_nonARG_recall_ARG_positive": binary["recall"],
            "ARG_nonARG_f1_ARG_positive": binary["f1"],
            "ARG_nonARG_mcc": binary["mcc"],
        }
        for metric in METRIC_NAMES:
            compact[f"Type_ARG_only_macro_{metric}"] = type_macro[metric]
        for metric in METRIC_NAMES:
            compact[f"subtype_ARG_only_weighted_{metric}"] = (
                subtype_weighted[metric]
            )
        compact_rows.append(compact)

    output_dir.mkdir(parents=True, exist_ok=True)
    outputs = {
        "00_input_audit.csv": audit_rows,
        "01_ARG_nonARG_ARG_positive_five_metrics.csv": binary_rows,
        "02_Type_overall_macro_weighted_micro.csv": type_rows,
        "03_subtype_overall_macro_weighted_micro.csv": subtype_rows,
        "04_each_Type_one_vs_rest_five_metrics.csv": per_type_rows,
        "05_each_subtype_one_vs_rest_five_metrics.csv": per_subtype_rows,
        "06_compact_ablation_summary.csv": compact_rows,
    }
    for filename, rows in outputs.items():
        write_csv(output_dir / filename, rows)
        print(f"Wrote: {filename} ({len(rows):,} rows)", flush=True)

    readme = """ARGScope ablation metric outputs

Five metrics
Accuracy, Precision, Recall, F1 and MCC.

ARG/nonARG
ARG is the positive class and nonARG is the negative class. This is one binary
result row per model; macro/weighted/micro averaging is intentionally not used.

Type and subtype overall tables
Each model has macro, weighted and micro rows for two clearly separated scopes:

1. all_sequences_including_nonARG
   Uses all 11,140 test sequences and treats nonARG as a class.

2. true_ARG_only_end_to_end
   Uses the 5,570 true ARG test sequences. A prediction of nonARG is retained
   and counted as an end-to-end hierarchical error. Macro/weighted/micro labels
   are the true ARG Type or subtype classes; nonARG is not averaged as a target
   class in this scope.

Per-class tables
Each Type or subtype is evaluated one-vs-rest over all test sequences. This
matches the model class-level table convention. Accuracy can be high for rare
classes because true negatives dominate; Precision, Recall, F1 and MCC should
also be considered.

Compact summary
The compact table uses the reporting choices discussed for the manuscript:
ARG/nonARG with ARG positive, Type=true-ARG-only macro, and
subtype=true-ARG-only weighted.

Accuracy and MCC in multiclass tables are global quantities and therefore are
repeated across the macro, weighted and micro rows. Averaging changes only
Precision, Recall and F1.
"""
    write_text(output_dir / "README_metrics.txt", readme)

    manifest = {
        "script_version": SCRIPT_VERSION,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "python_version": platform.python_version(),
        "scikit_learn_version": sklearn.__version__,
        "input_directory": str(input_dir),
        "output_directory": str(output_dir),
        "reference_prediction_file": all_data[0].path.name,
        "all_files_share_identical_test_ids_and_truth": True,
        "input_files": [
            {
                "model": data.spec.model,
                "filename": data.path.name,
                "sha256": sha256_file(data.path),
                "rows": len(data.rows),
            }
            for data in all_data
        ],
        "output_files": [
            *outputs.keys(),
            "README_metrics.txt",
            "calculation_manifest.json",
        ],
    }
    write_text(
        output_dir / "calculation_manifest.json",
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
    )

    print("All six ablation result files were calculated successfully.", flush=True)


if __name__ == "__main__":
    main()
