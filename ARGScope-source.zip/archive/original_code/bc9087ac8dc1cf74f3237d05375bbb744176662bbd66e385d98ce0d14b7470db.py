#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查 ARG/nonARG 的 DNA-protein 翻译对应关系，随机抽取与 ARG 等量的
合格 nonARG，最后生成平衡的 ARG+nonARG 数据集。

脚本放在包含以下6个输入文件的文件夹内，默认无需修改路径：
  nonARG_protein.fasta
  nonARG_dna.fasta
  SARG_verified_paired_protein_subtype_ge3.fasta
  SARG_verified_paired_DNA_one_per_protein_subtype_ge3.fasta
  SARG_verified_paired_protein_subtype_ge3_structure.txt

只生成3个最终文件：protein FASTA、DNA FASTA、structure TXT。
只使用 Python 标准库。
"""

from __future__ import annotations

import csv
import random
from collections import Counter
from pathlib import Path


# =============================================================================
# 配置区：脚本与输入文件放在同一目录时无需修改
# =============================================================================
ARG_PROTEIN_FASTA = "SARG_verified_paired_protein_subtype_ge3.fasta"
ARG_DNA_FASTA = "SARG_verified_paired_DNA_one_per_protein_subtype_ge3.fasta"
ARG_STRUCTURE = "SARG_verified_paired_protein_subtype_ge3_structure.txt"

NONARG_PROTEIN_FASTA = "nonARG_protein.fasta"
NONARG_DNA_FASTA = "nonARG_dna.fasta"

RANDOM_SEED = 20260815
OUTPUT_DIR = "ARG_nonARG_balanced_final"

OUTPUT_PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
OUTPUT_DNA_FASTA = "all_arg_nonarg_dna.fasta"
OUTPUT_STRUCTURE = "all_arg_nonarg_structure.txt"

# 允许 protein 中的这些模糊残基与任意翻译氨基酸对应。
AMBIGUOUS_PROTEIN_RESIDUES = set("XBZJUO?")


SCRIPT_DIR = Path(__file__).resolve().parent

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

# 细菌常见可替代起始密码子；当目标 protein 以 M 开头时按 M 处理。
BACTERIAL_START_CODONS = {"ATG", "GTG", "TTG", "CTG", "ATT", "ATC", "ATA"}
VALID_DNA_CHARACTERS = set("ACGTRYSWKMBDHVN")


def input_path(name: str) -> Path:
    path = Path(name).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(f"找不到输入文件：{path}")
    return path


def clean_protein(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("-", "").rstrip("*")


def clean_dna(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("U", "T").replace("-", "")


def read_fasta(path: Path, molecule: str):
    order = []
    records = {}
    current_id = None
    current_header = None
    chunks = []

    def save_record():
        nonlocal current_id, current_header, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"{path.name} 中存在重复 FASTA ID：{current_id}")
        raw = "".join(chunks)
        sequence = clean_protein(raw) if molecule == "protein" else clean_dna(raw)
        if not sequence:
            raise ValueError(f"{path.name} 中存在空序列：{current_id}")
        records[current_id] = {"header": current_header, "sequence": sequence}
        order.append(current_id)

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, raw_line in enumerate(handle, 1):
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith(">"):
                save_record()
                current_header = line[1:].strip()
                if not current_header:
                    raise ValueError(f"{path.name} 第{line_number}行 FASTA 标题为空")
                current_id = current_header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(f"{path.name} 第{line_number}行在标题前出现序列")
                chunks.append(line)
    save_record()
    return order, records


def read_structure(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames:
            raise ValueError(f"{path.name} 没有表头")
        fields = list(reader.fieldnames)
        rows = list(reader)

    id_field = next(
        (field for field in fields
         if field.strip().lower() in {"sarg.seq.id", "id", "protein_id", "seq_id"}),
        None,
    )
    type_field = next((f for f in fields if f.strip().lower() == "type"), None)
    subtype_field = next((f for f in fields if f.strip().lower() == "subtype"), None)
    if id_field is None or type_field is None or subtype_field is None:
        raise ValueError(
            f"{path.name} 必须包含 ID、Type、Subtype 列；当前列为：{fields}"
        )

    by_id = {}
    for row in rows:
        sequence_id = row[id_field].strip()
        if not sequence_id:
            raise ValueError(f"{path.name} 存在空 ID")
        if sequence_id in by_id:
            raise ValueError(f"{path.name} 存在重复 ID：{sequence_id}")
        by_id[sequence_id] = row
    return fields, rows, by_id, id_field, type_field, subtype_field


def translate_forward_frame0(dna: str, target_starts_with_m: bool) -> str:
    amino_acids = []
    for position in range(0, len(dna) - 2, 3):
        amino_acids.append(CODON_TABLE.get(dna[position:position + 3], "X"))
    if (
        amino_acids
        and target_starts_with_m
        and dna[:3] in BACTERIAL_START_CODONS
    ):
        amino_acids[0] = "M"
    return "".join(amino_acids)


def residues_compatible(target: str, translated: str) -> bool:
    return target == translated or target in AMBIGUOUS_PROTEIN_RESIDUES


def validate_pair(protein: str, dna: str):
    """只接受正向 frame 0 的全长翻译对应。"""
    protein = clean_protein(protein)
    dna = clean_dna(dna)

    invalid_characters = sorted(set(dna) - VALID_DNA_CHARACTERS)
    if invalid_characters:
        return False, "INVALID_DNA_CHARACTERS"

    if len(dna) not in {len(protein) * 3, (len(protein) + 1) * 3}:
        return False, "DNA_LENGTH_NOT_FULL_CDS"

    translated_raw = translate_forward_frame0(dna, protein.startswith("M"))
    translated_without_terminal_stop = translated_raw[:-1] if translated_raw.endswith("*") else translated_raw

    if "*" in translated_without_terminal_stop:
        return False, "INTERNAL_STOP_CODON"
    if len(translated_without_terminal_stop) != len(protein):
        return False, "TRANSLATED_LENGTH_MISMATCH"
    if not all(
        residues_compatible(target, observed)
        for target, observed in zip(protein, translated_without_terminal_stop)
    ):
        return False, "PROTEIN_TRANSLATION_NOT_MATCHED"

    if translated_without_terminal_stop == protein:
        return True, "EXACT_FORWARD_FRAME0"
    return True, "COMPATIBLE_AMBIGUOUS_PROTEIN_RESIDUE"


def validate_dataset(label, protein_order, proteins, dna_order, dna_records):
    protein_ids = set(proteins)
    dna_ids = set(dna_records)
    only_protein = protein_ids - dna_ids
    only_dna = dna_ids - protein_ids
    if only_protein or only_dna:
        examples_protein = sorted(only_protein)[:10]
        examples_dna = sorted(only_dna)[:10]
        raise ValueError(
            f"{label} protein/DNA FASTA 的ID集合不一致：\n"
            f"  仅protein中存在：{len(only_protein)}，示例={examples_protein}\n"
            f"  仅DNA中存在：{len(only_dna)}，示例={examples_dna}"
        )

    # ID集合一致即可；后续一律按照 protein FASTA 顺序配对和写出。
    valid_ids = []
    failed = []
    status_counts = Counter()
    for index, sequence_id in enumerate(protein_order, 1):
        accepted, status = validate_pair(
            proteins[sequence_id]["sequence"],
            dna_records[sequence_id]["sequence"],
        )
        status_counts[status] += 1
        if accepted:
            valid_ids.append(sequence_id)
        else:
            failed.append((sequence_id, status))
        if index == 1 or index % 5000 == 0:
            print(f"  {label}: checked {index}/{len(protein_order)}")

    print(f"  {label} protein records       : {len(protein_order)}")
    print(f"  {label} DNA records           : {len(dna_order)}")
    print(f"  {label} translation matched   : {len(valid_ids)}")
    print(f"  {label} translation unmatched : {len(failed)}")
    for status, count in sorted(status_counts.items()):
        print(f"    {status}: {count}")
    if failed:
        print(f"  First unmatched examples: {failed[:10]}")
    return valid_ids, failed


def wrap_sequence(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def replace_header_id(header: str, new_id: str) -> str:
    parts = header.split(maxsplit=1)
    return new_id if len(parts) == 1 else f"{new_id} {parts[1]}"


def main():
    arg_protein_path = input_path(ARG_PROTEIN_FASTA)
    arg_dna_path = input_path(ARG_DNA_FASTA)
    arg_structure_path = input_path(ARG_STRUCTURE)
    nonarg_protein_path = input_path(NONARG_PROTEIN_FASTA)
    nonarg_dna_path = input_path(NONARG_DNA_FASTA)

    print("=" * 100)
    print("Check, balance and merge ARG/nonARG DNA-protein pairs")
    print("=" * 100)
    print(f"Random seed: {RANDOM_SEED}")

    arg_order, arg_proteins = read_fasta(arg_protein_path, "protein")
    arg_dna_order, arg_dna = read_fasta(arg_dna_path, "DNA")
    nonarg_order, nonarg_proteins = read_fasta(nonarg_protein_path, "protein")
    nonarg_dna_order, nonarg_dna = read_fasta(nonarg_dna_path, "DNA")

    fields, structure_rows, structure_by_id, id_field, type_field, subtype_field = read_structure(
        arg_structure_path
    )
    if set(arg_proteins) != set(structure_by_id):
        raise ValueError(
            "ARG protein FASTA 与 ARG structure 的ID集合不一致："
            f"仅FASTA={len(set(arg_proteins)-set(structure_by_id))}，"
            f"仅structure={len(set(structure_by_id)-set(arg_proteins))}"
        )

    print("\n[1/2] Validate ARG pairs")
    valid_arg_ids, failed_arg = validate_dataset(
        "ARG", arg_order, arg_proteins, arg_dna_order, arg_dna
    )
    if failed_arg:
        raise RuntimeError(
            f"ARG 一对一数据中仍有 {len(failed_arg)} 对翻译不匹配。"
            "为避免破坏既定 ARG 数量，程序已停止，请先检查这些 ARG。"
        )
    if valid_arg_ids != arg_order:
        raise RuntimeError("ARG 验证结果顺序异常")

    print("\n[2/2] Validate nonARG pairs")
    valid_nonarg_ids, failed_nonarg = validate_dataset(
        "nonARG", nonarg_order, nonarg_proteins, nonarg_dna_order, nonarg_dna
    )

    target_nonarg_count = len(valid_arg_ids)
    if len(valid_nonarg_ids) < target_nonarg_count:
        shortage = target_nonarg_count - len(valid_nonarg_ids)
        raise RuntimeError(
            f"通过翻译验证的 nonARG 只有 {len(valid_nonarg_ids)} 条，"
            f"但 ARG 有 {target_nonarg_count} 条，还缺少 {shortage} 条合格 nonARG。"
        )

    rng = random.Random(RANDOM_SEED)
    selected_set = set(rng.sample(valid_nonarg_ids, target_nonarg_count))
    # 按原始 nonARG protein FASTA 顺序输出，使结果稳定且 protein/DNA 对齐。
    selected_nonarg_ids = [x for x in nonarg_order if x in selected_set]
    if len(selected_nonarg_ids) != target_nonarg_count:
        raise RuntimeError("nonARG 随机抽样数量异常")

    # 避免合并后出现重复ID。如果与ARG重名，则只在输出中统一添加前缀。
    arg_id_set = set(valid_arg_ids)
    collisions = arg_id_set.intersection(selected_nonarg_ids)
    if collisions:
        nonarg_output_id = {x: f"nonARG__{x}" for x in selected_nonarg_ids}
        if arg_id_set.intersection(nonarg_output_id.values()):
            raise RuntimeError("添加 nonARG__ 前缀后仍然存在ID冲突")
        print(f"\nDetected {len(collisions)} ARG/nonARG ID collisions; added nonARG__ prefix in outputs.")
    else:
        nonarg_output_id = {x: x for x in selected_nonarg_ids}

    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    protein_output = output_dir / OUTPUT_PROTEIN_FASTA
    dna_output = output_dir / OUTPUT_DNA_FASTA
    structure_output = output_dir / OUTPUT_STRUCTURE

    with protein_output.open("w", encoding="utf-8", newline="\n") as handle:
        for sequence_id in valid_arg_ids:
            record = arg_proteins[sequence_id]
            handle.write(f">{record['header']}\n{wrap_sequence(record['sequence'])}\n")
        for sequence_id in selected_nonarg_ids:
            record = nonarg_proteins[sequence_id]
            header = replace_header_id(record["header"], nonarg_output_id[sequence_id])
            handle.write(f">{header}\n{wrap_sequence(record['sequence'])}\n")

    with dna_output.open("w", encoding="utf-8", newline="\n") as handle:
        for sequence_id in valid_arg_ids:
            record = arg_dna[sequence_id]
            handle.write(f">{record['header']}\n{wrap_sequence(record['sequence'])}\n")
        for sequence_id in selected_nonarg_ids:
            record = nonarg_dna[sequence_id]
            header = replace_header_id(record["header"], nonarg_output_id[sequence_id])
            handle.write(f">{header}\n{wrap_sequence(record['sequence'])}\n")

    with structure_output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fields, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        for sequence_id in valid_arg_ids:
            writer.writerow(structure_by_id[sequence_id])
        for sequence_id in selected_nonarg_ids:
            # nonARG 只填写 ID、Type=nonARG、Subtype=nonARG，其余ARG专属字段留空。
            row = {field: "" for field in fields}
            row[id_field] = nonarg_output_id[sequence_id]
            row[type_field] = "nonARG"
            row[subtype_field] = "nonARG"
            writer.writerow(row)

    final_count = len(valid_arg_ids) + len(selected_nonarg_ids)
    print("\n" + "=" * 100)
    print("COMPLETED")
    print("=" * 100)
    print(f"ARG records                         : {len(valid_arg_ids)}")
    print(f"Valid nonARG before sampling        : {len(valid_nonarg_ids)}")
    print(f"Rejected nonARG translation pairs   : {len(failed_nonarg)}")
    print(f"Randomly selected nonARG records    : {len(selected_nonarg_ids)}")
    print(f"Final protein records               : {final_count}")
    print(f"Final DNA records                   : {final_count}")
    print(f"Final structure rows                : {final_count}")
    print(f"ARG:nonARG ratio                    : 1:1")
    print(f"Random seed                         : {RANDOM_SEED}")
    print("\nOutput files:")
    print(f"  {protein_output}")
    print(f"  {dna_output}")
    print(f"  {structure_output}")


if __name__ == "__main__":
    main()
