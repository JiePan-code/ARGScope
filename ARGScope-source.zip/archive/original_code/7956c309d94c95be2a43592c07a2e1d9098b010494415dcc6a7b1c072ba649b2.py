"""Package only authored plot outputs; never traverse the dependency junction."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

root=Path(__file__).resolve().parent
folder=root/'figures_Type_ARG_only'
target=root/'Type_ARG_only_updated_figures.zip'
paths=sorted(p for p in folder.rglob('*') if p.is_file())
assert len([p for p in paths if p.suffix=='.png'])==25
inputs=[root/mod/name for mod in ['Protein','DNA'] for name in [
 '01_Type_barplot_macro_five_metrics.csv','02_Type_overall_macro_weighted_micro.csv',
 '04_Per_Type_ARGScope23_display_view.csv','06_ARG_nonARG_macro_weighted_micro.csv']]+[root/'ARGScope_23_types.csv',root/'README_结果说明.md',root/'Type_name_mapping_audit.csv']
with ZipFile(target,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths:z.write(p,p.relative_to(root))
    z.write(root/'plot_corrected_type_results.py','plot_corrected_type_results.py')
    for p in inputs:z.write(p,p.relative_to(root))
with ZipFile(target) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(paths)+1+len(inputs)
print(f'{target}: {len(paths)+1+len(inputs)} entries, {target.stat().st_size/1024**2:.1f} MiB; CRC verified.')
