const path = require('path');
const fs = require('fs');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const out = path.join(__dirname,'outputs','argscope_method_diagrams_20260926');

async function run(){
  const all=[];
  for (const [name,width,height] of [['ARGScope_overview',3508,2480],['ARGScope_AA_NT_training',2480,3508]]) {
    const svg=path.join(out,name+'.svg');
    await sharp(svg,{density:300}).resize(width,height,{fit:'fill'}).flatten({background:'#ffffff'})
      .withMetadata({density:300}).png().toFile(path.join(out,name+'.png'));
    await sharp(path.join(out,name+'.png')).withMetadata({density:300})
      .tiff({compression:'lzw',predictor:'horizontal',xres:300/25.4,yres:300/25.4,resolutionUnit:'inch'})
      .toFile(path.join(out,name+'_A4_300DPI.tif'));
    await sharp(path.join(out,name+'.png')).resize({width:name==='ARGScope_overview'?1800:1400})
      .png().toFile(path.join(out,name+'_preview.png'));
    const m=await sharp(path.join(out,name+'_A4_300DPI.tif')).metadata();
    all.push({name,width:m.width,height:m.height,density:m.density,format:m.format});
  }
  fs.writeFileSync(path.join(out,'render_validation.json'),JSON.stringify(all,null,2));
  console.log(JSON.stringify(all));
}
run().catch(e=>{console.error(e);process.exit(1)});
