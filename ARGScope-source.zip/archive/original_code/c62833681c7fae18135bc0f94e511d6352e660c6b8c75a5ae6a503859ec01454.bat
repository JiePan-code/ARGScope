@echo off
setlocal
chcp 65001 >nul
set "PYTHON_EXE=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%PYTHON_EXE%" (
  echo Python not found. Edit PYTHON_EXE in this BAT.
  pause
  exit /b 1
)
"%PYTHON_EXE%" -X utf8 -B "%~dp0calculate_full_metrics.py"
set "RUN_EXIT=%ERRORLEVEL%"
if "%RUN_EXIT%"=="0" echo DONE. New metrics folder created under full.
if not "%RUN_EXIT%"=="0" echo Calculation stopped. Read the error above.
pause
exit /b %RUN_EXIT%
