from Bio import SeqIO
import os
import csv
import json

# ===== 输入 =====
fasta_file = "mibig_prot_seqs_4.0.fasta"
gbk_dir = "mibig_gbk_4.0"
json_dir = "mibig_json_4.0"

# ===== 输出 =====
out_protein = "mibig_final_protein.fasta"
out_dna = "mibig_final_dna.fasta"
out_csv = "mibig_final_annotation.csv"


# ===== Step 1: 读取目标ID =====
target_ids = set()

with open(fasta_file) as f:
    for line in f:
        if line.startswith(">"):
            parts = line.strip()[1:].split("|")
            pid = parts[4].split(".")[0]
            target_ids.add(pid)

print("目标protein数量:", len(target_ids))


# ===== Step 2: 读取所有 JSON → 构建 BGC type 表 =====
bgc_type_map = {}

for file in os.listdir(json_dir):
    if not file.endswith(".json"):
        continue

    path = os.path.join(json_dir, file)

    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    bgc_id = data["accession"]   # BGC0000001

    try:
        classes = data["biosynthesis"]["classes"]

        # 取第一个（主类型）
        main_class = classes[0]["class"]
        subclass = classes[0].get("subclass", "NA")

    except:
        main_class = "Other"
        subclass = "NA"

    bgc_type_map[bgc_id] = (main_class, subclass)

print("JSON加载完成:", len(bgc_type_map))


# ===== Step 3: 主流程 =====
data = []
found = set()

with open(out_protein, "w") as f_prot, open(out_dna, "w") as f_dna:

    for file in os.listdir(gbk_dir):
        if not file.endswith(".gbk"):
            continue

        gbk_path = os.path.join(gbk_dir, file)

        # 提取 BGC ID
        bgc_id = file.replace(".gbk", "")

        if bgc_id not in bgc_type_map:
            continue

        bgc_type, bgc_subtype = bgc_type_map[bgc_id]

        for record in SeqIO.parse(gbk_path, "genbank"):

            for feature in record.features:

                if feature.type != "CDS":
                    continue

                if "translation" not in feature.qualifiers:
                    continue

                # ID
                if "protein_id" in feature.qualifiers:
                    pid = feature.qualifiers["protein_id"][0]
                elif "locus_tag" in feature.qualifiers:
                    pid = feature.qualifiers["locus_tag"][0]
                else:
                    continue

                pid_base = pid.split(".")[0]

                if pid_base not in target_ids:
                    continue

                protein_seq = feature.qualifiers["translation"][0]
                dna_seq = feature.location.extract(record.seq)

                # gene-level subtype
                if "product" in feature.qualifiers:
                    gene_subtype = feature.qualifiers["product"][0]
                else:
                    gene_subtype = "unknown"

                # 写 fasta
                f_prot.write(f">{pid}\n{protein_seq}\n")
                f_dna.write(f">{pid}\n{str(dna_seq)}\n")

                # annotation
                data.append([
                    pid,
                    bgc_type,
                    gene_subtype  # ⭐用gene_function替代subtype
                ])

                found.add(pid_base)


# ===== Step 4: 写 CSV =====
with open(out_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["ID", "type", "subtype"])
    writer.writerows(data)


# ===== Step 5: 检查 =====
print("\n===== 检查 =====")
print("目标ID:", len(target_ids))
print("匹配成功:", len(found))
print("未匹配:", len(target_ids - found))