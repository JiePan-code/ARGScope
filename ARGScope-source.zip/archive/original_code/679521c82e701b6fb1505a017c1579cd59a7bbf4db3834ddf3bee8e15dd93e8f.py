#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Per-Type Precision radar comparison: Protein/DNA x 60/70/80/90%.

Uses the existing reported per-Type table; does not alter metrics, predictions,
training, model thresholds or evaluation cohorts. Missing values break lines.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle
from matplotlib.text import Text
from PIL import Image

ROOT = Path(__file__).resolve().parent
INPUT = ROOT/"inputs"
SOURCE = ROOT.parent
PCTS = [60, 70, 80, 90]
MODELS = {"protein": ["ARGNet", "DeepARG", "PLM-ARG", "FunGeneTyper", "ARGScope"],
          "dna": ["ARGNet", "DeepARG", "ARGScope"]}
COLORS = {"ARGNet": "#89949E", "DeepARG": "#8472B0", "PLM-ARG": "#BDA364",
          "FunGeneTyper": "#64A598", "ARGScope": "#CF4877"}
MARKERS = {"ARGNet": "s", "DeepARG": "^", "PLM-ARG": "D", "FunGeneTyper": "v", "ARGScope": "o"}
STYLES = {"ARGNet": "--", "DeepARG": ":", "PLM-ARG": "-.", "FunGeneTyper": (0, (4, 1.3, 1.2, 1.3)), "ARGScope": "-"}
CONTEXT = ("Per-Type Precision in each model's existing reported evaluation cohort. "
           "Cohorts and label coverage are not matched; descriptive comparison only. "
           "Missing values are gaps, not measured zeros. Display filtering is not sample filtering.")
plt.rcParams.update({"font.family": "Arial", "font.size": 9, "text.color": "#24292D",
                     "figure.facecolor": "white", "savefig.facecolor": "white",
                     "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42})


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def csv(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.12g")


def load_inputs():
    INPUT.mkdir(exist_ok=True)
    sources = {"reported_per_type.csv": SOURCE/"data/reported_per_type_NOT_matched.csv",
               "type_mapping.csv": SOURCE/"data/type_display_mapping.csv",
               "ARGScope_counts.csv": SOURCE/"data/ARGScope_per_type_five_metrics.csv"}
    manifest_path = INPUT/"source_manifest.json"
    if not manifest_path.exists():
        for name, source in sources.items():
            assert source.is_file(), source
            assert not (INPUT/name).exists(), "Incomplete snapshot; inspect inputs."
        meta = {}
        for name, source in sources.items():
            shutil.copy2(source, INPUT/name)
            meta[name] = {"original_path": str(source), "sha256": sha(source)}
        dump(manifest_path, meta)
    metadata = json.loads(manifest_path.read_text(encoding="utf-8"))
    for name, info in metadata.items():
        assert sha(INPUT/name) == info["sha256"]
    data = pd.read_csv(INPUT/"reported_per_type.csv")
    data = data[data.Metric.eq("Precision") & data.Completeness.isin(PCTS)].copy()
    mapping = pd.read_csv(INPUT/"type_mapping.csv")
    own_counts = pd.read_csv(INPUT/"ARGScope_counts.csv")
    assert len(mapping) == 23 and mapping.Type.is_unique
    assert len(data) == 736
    assert not data.duplicated(["Modality", "Model", "Completeness", "Type"]).any()
    assert data.Value.dropna().between(0, 1).all()
    own = data[data.Model.eq("ARGScope")].merge(own_counts, on=["Modality", "Completeness", "Type"], validate="one_to_one")
    assert len(own) == 184 and own.Value.notna().all()
    den = (own.TP+own.FP).to_numpy(float)
    checked = np.divide(own.TP.to_numpy(float), den, out=np.zeros(len(own)), where=den > 0)
    np.testing.assert_allclose(own.Value, checked, atol=6e-12, rtol=0)
    return data, mapping, metadata


def select_types(data, mapping):
    tables, filters = {}, []
    for mod, models in MODELS.items():
        for pct in PCTS:
            part = data[data.Modality.eq(mod) & data.Completeness.eq(pct)]
            table = part.pivot(index="Type", columns="Model", values="Value").reindex(index=mapping.Type, columns=models)
            own_ok = table.ARGScope.gt(0)
            other_ok = table[models[:-1]].gt(0).any(axis=1)
            keep = own_ok & other_ok
            for typ in table.index:
                reason = "displayed" if keep[typ] else ("ARGScope_precision_zero" if not own_ok[typ]
                         else "all_baselines_zero_or_missing")
                filters.append({"Modality": mod, "Completeness": pct, "Type": typ,
                                "ARGScope_precision": table.loc[typ, "ARGScope"],
                                "Shown": bool(keep[typ]), "Reason": reason})
            tables[mod, pct] = table.loc[keep].copy()
            assert len(tables[mod, pct]) >= 3
    return tables, pd.DataFrame(filters)


def spread(y, spacing):
    order = np.argsort(y)
    values = np.array(y)[order]
    for i in range(1, len(values)):
        values[i] = max(values[i], values[i-1]+spacing)
    values -= (values[0]+values[-1])/2
    result = np.empty(len(values))
    result[order] = values
    return result


def panel(ax, table, mapping, mod, pct, name, drawn, font=8.1, single=False):
    types = table.index.tolist()
    labels = mapping.set_index("Type").Display.to_dict()
    angles = np.pi/2-(np.arange(len(types))+.5)*2*np.pi/len(types)
    ux, uy = np.cos(angles), np.sin(angles)
    texts = []
    for r in [.2, .4, .6, .8, 1.]:
        ax.add_patch(Circle((0, 0), r, facecolor="none", edgecolor="#D8DEE3" if r < 1 else "#68737E",
                            lw=.45 if r < 1 else .7, zorder=0))
    for x, y in zip(ux, uy):
        ax.plot([0, x], [0, y], lw=.4, color="#E5E8EC", zorder=0)
    for side in [-1, 1]:
        indexes = [i for i in range(len(types)) if (ux[i] < 0) == (side < 0)]
        ys = spread(uy[indexes]*1.10, spacing=.147 if not single else .12)
        for i, y in zip(indexes, ys):
            x = ux[i]*1.06+side*.025
            ax.plot([ux[i]*1.01, x-side*.015], [uy[i]*1.01, y], color="#BBC2C9", lw=.4)
            texts.append(ax.text(x, y, labels[types[i]], va="center", ha="left" if side > 0 else "right",
                                 fontsize=font, clip_on=False))
    for model in MODELS[mod]:
        values = table[model].to_numpy(float)
        xs = np.r_[ux*values, ux[0]*values[0]]
        ys = np.r_[uy*values, uy[0]*values[0]]
        # NaNs intentionally remain in the path: no interpolation over unreported Types.
        line, = ax.plot(xs, ys, color=COLORS[model], ls=STYLES[model],
                        lw=1.10 if single else .90, marker=MARKERS[model],
                        ms=3 if single else 2.5, mew=.6,
                        mfc=COLORS[model] if model == "ARGScope" else "white",
                        zorder=5 if model == "ARGScope" else 3)
        assert np.array_equal(np.isnan(line.get_xdata()[:-1]), np.isnan(values))
        for i, typ in enumerate(types):
            drawn.append({"Figure": name, "Modality": mod, "Completeness": pct, "Model": model,
                          "Type": typ, "Metric": "Precision", "Score": values[i],
                          "Angle": angles[i], "X": line.get_xdata()[i], "Y": line.get_ydata()[i],
                          "Status": "source_missing_line_gap" if np.isnan(values[i]) else "observed_score"})
    for r in [.2, .4, .6, .8, 1.]:
        a = np.deg2rad(83)
        ax.text(r*np.cos(a)+.018, r*np.sin(a)-.02, f"{r:.1f}", fontsize=6.8 if single else 6.0,
                ha="left", va="center", color="#707A83", zorder=8,
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": .78, "pad": .2})
    ax.set(xlim=(-2.03, 2.03), ylim=(-1.30, 1.30), aspect="equal")
    ax.axis("off")
    return texts


def legend_handles(models):
    return [Line2D([0], [0], color=COLORS[m], ls=STYLES[m], marker=MARKERS[m], lw=1.1, ms=3.4,
                   mfc=COLORS[m] if m == "ARGScope" else "white", label=m) for m in models]


def check_layout(fig, groups):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    outside = []
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        box = text.get_window_extent(renderer)
        if box.width and box.height and (box.x0 < bounds.x0-1 or box.y0 < bounds.y0-1 or
                                        box.x1 > bounds.x1+1 or box.y1 > bounds.y1+1):
            outside.append(text.get_text())
    labels = [text for group in groups for text in group]
    overlap = []
    for i, left in enumerate(labels):
        for right in labels[i+1:]:
            if left.get_window_extent(renderer).overlaps(right.get_window_extent(renderer)):
                overlap.append([left.get_text(), right.get_text()])
    assert not outside, f"Text out of bounds: {outside}"
    assert not overlap, f"Overlapping labels: {overlap}"
    return {"outside_canvas_text": 0, "type_label_overlap": 0}


def save(fig, name, out, manifest, groups):
    check = check_layout(fig, groups)
    for ext in ["png", "pdf", "svg"]:
        path = out/f"{name}.{ext}"
        metadata = {"Subject": CONTEXT} if ext == "pdf" else {"Description": CONTEXT}
        fig.savefig(path, dpi=450, metadata=metadata)
        manifest.append({"file": path.name, "sha256": sha(path), "width_mm": fig.get_figwidth()*25.4,
                         "height_mm": fig.get_figheight()*25.4, **check})
    fig.savefig(out/f"{name}_preview.png", dpi=140)
    plt.close(fig)


def draw_combined(tables, mapping, out, drawn, manifest):
    name = "01_Precision_2x4_all_models"
    fig = plt.figure(figsize=(420/25.4, 162/25.4))
    grid = fig.add_gridspec(2, 4, left=.052, right=.99, bottom=.035, top=.86,
                           wspace=.13, hspace=.12)
    groups = []
    for row, mod in enumerate(MODELS):
        row_axes = []
        for col, pct in enumerate(PCTS):
            ax = fig.add_subplot(grid[row, col])
            row_axes.append(ax)
            groups.append(panel(ax, tables[mod, pct], mapping, mod, pct, name, drawn))
            box = ax.get_position()
            if row == 0:
                fig.text((box.x0+box.x1)/2, box.y1+.022, f"{pct}%", ha="center", fontsize=11)
        pos = row_axes[0].get_position()
        fig.text(.018, pos.y0+pos.height/2, "Protein" if mod == "protein" else "DNA", rotation=90,
                 ha="center", va="center", fontweight="bold", fontsize=12)
    fig.legend(handles=legend_handles(MODELS["protein"]), loc="upper center", bbox_to_anchor=(.52, .978),
               ncol=5, frameon=False, fontsize=10, handlelength=3, columnspacing=2)
    save(fig, name, out, manifest, groups)


def draw_single(tables, mapping, mod, pct, out, drawn, manifest):
    name = f"{mod}_{pct}_Precision_models"
    fig = plt.figure(figsize=(180/25.4, 139/25.4))
    ax = fig.add_axes([.03, .035, .94, .81])
    labels = panel(ax, tables[mod, pct], mapping, mod, pct, name, drawn, font=9.4, single=True)
    fig.text(.5, .95, f"{'Protein' if mod == 'protein' else 'DNA'} · {pct}%", ha="center", fontsize=12)
    fig.legend(handles=legend_handles(MODELS[mod]), loc="upper center", bbox_to_anchor=(.5, .916),
               ncol=len(MODELS[mod]), frameon=False, fontsize=8, handlelength=2.3, columnspacing=1.1)
    save(fig, name, out, manifest, [labels])


def validate(data, tables, drawn, manifest, out, metadata):
    keys = ["Modality", "Completeness", "Model", "Type", "Metric"]
    merged = drawn.merge(data, on=keys, validate="many_to_one")
    assert len(merged) == len(drawn)
    np.testing.assert_allclose(merged.Score, merged.Value, equal_nan=True, atol=0, rtol=0)
    np.testing.assert_allclose(np.hypot(merged.X, merged.Y), merged.Value, equal_nan=True, atol=3e-16, rtol=0)
    assert np.array_equal(merged.Score.isna(), merged.X.isna())
    assert np.array_equal(merged.Score.isna(), merged.Y.isna())
    main = drawn[drawn.Figure.eq("01_Precision_2x4_all_models")]
    assert main.Modality.nunique() == 2 and main.Completeness.nunique() == 4
    assert set(main.Metric) == {"Precision"}
    for mod, models in MODELS.items():
        for pct in PCTS:
            group = main[main.Modality.eq(mod) & main.Completeness.eq(pct)]
            assert set(group.Model) == set(models)
            assert len(group) == len(tables[mod, pct])*len(models)
    assert len(manifest) == 27
    for info in manifest:
        path = out/info["file"]
        assert sha(path) == info["sha256"]
        if path.suffix == ".png":
            with Image.open(path) as im:
                im.verify()
        elif path.suffix == ".svg":
            ET.parse(path)
            assert "Recall" not in path.read_text(encoding="utf-8")
        else:
            content = path.read_bytes()
            assert content.startswith(b"%PDF-") and b"%%EOF" in content[-100:]
    for name, meta in metadata.items():
        assert sha(INPUT/name) == meta["sha256"]
        original = Path(meta["original_path"])
        if original.is_file():
            assert sha(original) == meta["sha256"]
    return {"status": "PASS", "main_layout": "2 rows x 4 columns", "metric": "Precision_only",
            "protein_models": MODELS["protein"], "dna_models": MODELS["dna"],
            "panel_type_counts": {f"{mod}_{pct}": len(table) for (mod, pct), table in tables.items()},
            "main_score_slots": len(main), "main_available_scores": int(main.Score.notna().sum()),
            "main_missing_gaps": int(main.Score.isna().sum()), "zero_imputation": False,
            "values_unchanged": True, "original_inputs_unchanged": True,
            "outside_canvas_text": 0, "type_label_overlap": 0, "formal_files": len(manifest),
            "same_test_cohort_across_models": False}


def package(out):
    archive = ROOT/"ARGScope_Type_Precision_2x4.zip"
    files = [Path(__file__), ROOT/"README_说明.md", ROOT/"双击绘图.bat", ROOT/"render_status.json"]
    files += list(INPUT.glob("*")) + list(out.rglob("*"))
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            if path.is_file():
                z.write(path, Path("Type_Precision_2x4")/path.relative_to(ROOT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    return archive


def main():
    data, mapping, metadata = load_inputs()
    tables, filters = select_types(data, mapping)
    out = ROOT/("v"+datetime.now().strftime("%y%m%d_%H%M%S"))
    out.mkdir()
    (out/"data").mkdir()
    status = {"status": "RUNNING", "figure_directory": str(out), "code_sha256": sha(__file__),
              "started_utc": datetime.now(timezone.utc).isoformat()}
    dump(ROOT/"render_status.json", status)
    csv(filters, out/"data/type_display_filter.csv")
    csv(data, out/"data/all_source_precision_values.csv")
    drawn, manifest = [], []
    print("Rendering the 2 x 4 all-model Type precision figure...", flush=True)
    draw_combined(tables, mapping, out, drawn, manifest)
    for mod in MODELS:
        for pct in PCTS:
            print(f"Rendering {mod} {pct}%...", flush=True)
            draw_single(tables, mapping, mod, pct, out, drawn, manifest)
    drawn = pd.DataFrame(drawn)
    csv(drawn, out/"data/drawn_points.csv")
    report = validate(data, tables, drawn, manifest, out, metadata)
    dump(out/"validation_report.json", report)
    dump(out/"figure_manifest.json", manifest)
    status.update(status="COMPLETE", finished_utc=datetime.now(timezone.utc).isoformat(), validation=report)
    dump(ROOT/"render_status.json", status)
    archive = package(out)
    print(json.dumps({"figures": str(out), "archive": str(archive), "validation": report}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
