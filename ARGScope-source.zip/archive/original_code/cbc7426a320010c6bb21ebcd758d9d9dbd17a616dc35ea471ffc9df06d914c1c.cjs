const fs=require('fs');
const path=require('path');
const sharp=require('sharp');
const out=path.join(__dirname,'outputs','ARGScope_iconkit_3color_20260929');
const manifest=JSON.parse(fs.readFileSync(path.join(out,'manifest.json'),'utf8'));

async function main(){
  const png=path.join(out,'PNG');fs.mkdirSync(png,{recursive:true});
  const results=[];
  for(let i=0;i<manifest.assets.length;i+=6){
    await Promise.all(manifest.assets.slice(i,i+6).map(async asset=>{
      const file=path.join(out,'SVG',asset.file+'.svg');
      const target=path.join(png,asset.file+'.png');
      const width=Math.round(1200*asset.width/Math.max(asset.width,asset.height));
      const height=Math.round(1200*asset.height/Math.max(asset.width,asset.height));
      await sharp(file,{density:300}).resize(width,height).png().withMetadata({density:300}).toFile(target);
      const meta=await sharp(target).metadata();
      const {data,info}=await sharp(target).ensureAlpha().raw().toBuffer({resolveWithObject:true});
      let minX=info.width,minY=info.height,maxX=-1,maxY=-1;
      for(let y=0;y<info.height;y++)for(let x=0;x<info.width;x++){
        if(data[(y*info.width+x)*4+3]>8){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
      }
      if(!meta.hasAlpha)throw Error('Missing alpha: '+asset.file);
      if(maxX<0)throw Error('Blank: '+asset.file);
      const clipped=minX<=0||minY<=0||maxX>=info.width-1||maxY>=info.height-1;
      results.push({file:asset.file,width:meta.width,height:meta.height,alpha:meta.hasAlpha,bbox:[minX,minY,maxX,maxY],clipped});
    }));
  }
  for(const f of fs.readdirSync(out).filter(f=>/^Catalog_\d+\.svg$/.test(f)||f==='00_icon_overview.svg'||f==='00_preview.svg')){
    await sharp(path.join(out,f),{density:96}).flatten({background:'#ffffff'}).png().toFile(path.join(out,f.replace('.svg','.png')));
  }
  results.sort((a,b)=>a.file.localeCompare(b.file));
  fs.writeFileSync(path.join(out,'validation.json'),JSON.stringify({assets:results.length,clipped:results.filter(x=>x.clipped),results},null,2));
  console.log(JSON.stringify({assets:results.length,clipped:results.filter(x=>x.clipped),allTransparent:results.every(x=>x.alpha)}));
}
main().catch(e=>{console.error(e);process.exit(1)});
