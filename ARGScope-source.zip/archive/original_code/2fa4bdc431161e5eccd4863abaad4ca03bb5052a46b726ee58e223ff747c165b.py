# -*- coding: utf-8 -*-
"""
3-set Venn comparison for:
    1) ARGScope (DIAMOND0.7 + Gate0.1)
    2) DeepARG
    3) Raw BLASTN (unfiltered original BLASTN results; headerless TSV)

Use case:
- Compare ARGScope / DeepARG / raw BLASTN
- BLASTN here means the ORIGINAL blast output before strict filtering by:
      E-value <= 1e-7
      Identity >= 80%
      Query coverage >= 75%
      Alignment length >= 75 nt

Recommended folder structure:
Diamon结果/
├── 2.DeepARG_Fastq结果/
├── 4.Diamon/
│   └── ARGScope_DIAMOND_gate010_realdata_predictions/
│       └── diamond0.7/
│           └── all_samples_ARG_predictions.csv
├── 5.BLASTN_all_reads_results/
│   ├── argbert_1/
│   │   └── argbert_1_blastn.tsv
│   ├── argbert_2/
│   └── ...
└── draw_ARGScope_D070_G010_DeepARG_rawBLAST_venn.py

This script can also be placed under:
    Diamon结果/4.Diamon/

Output:
    6.ARGScope_D070_G010_DeepARG_rawBLAST_3set_Venn_results/

Requires:
    pip install venn

Panel layout:
    horizontal layout, 4 plots per row
"""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from venn import venn
except ImportError as exc:
    raise ImportError(
        "Package 'venn' is required.\n"
        "Please install it first:\n"
        "    pip install venn"
    ) from exc


# =============================================================================
# 1. PATHS
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# Support two placements:
# A) script directly under Diamon结果/
# B) script inside 4.Diamon/
if (SCRIPT_DIR / "2.DeepARG_Fastq结果").is_dir():
    BASE_DIR = SCRIPT_DIR
elif (SCRIPT_DIR.parent / "2.DeepARG_Fastq结果").is_dir():
    BASE_DIR = SCRIPT_DIR.parent
else:
    BASE_DIR = SCRIPT_DIR

DEEPARG_ROOT = BASE_DIR / "2.DeepARG_Fastq结果"
RAW_BLAST_ROOT = BASE_DIR / "5.BLASTN_all_reads_results"

DIAMOND_ROOT = BASE_DIR / "4.Diamon"
ARGSCOPE_DIAMOND_FILE = (
    DIAMOND_ROOT
    / "ARGScope_DIAMOND_gate010_realdata_predictions"
    / "diamond0.7"
    / "all_samples_ARG_predictions.csv"
)

TARGET_DIAMOND_TEXT = "diamond0.7"
TARGET_GATE = 0.10

OUT_DIR = BASE_DIR / "6.ARGScope_D070_G010_DeepARG_rawBLAST_3set_Venn_results"
OUT_DIR.mkdir(parents=True, exist_ok=True)

ID_OUT_DIR = OUT_DIR / "intersection_ids"
ID_OUT_DIR.mkdir(parents=True, exist_ok=True)

DPI = 600


# =============================================================================
# 2. HELPERS
# =============================================================================

def clean_id_series(series: pd.Series) -> set[str]:
    s = series.astype(str).str.strip()
    s = s[s.ne("") & s.ne("nan") & s.ne("None")]
    return set(s.tolist())


def save_id_set(ids: set[str], output_file: Path, col_name: str = "read_id") -> None:
    pd.DataFrame({col_name: sorted(ids)}).to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig",
    )


def sample_name_from_arg_file(path: Path) -> str:
    """
    Example:
        argbert_2.clean.deeparg.mapping.ARG -> argbert_2
        argscope_1.clean.deeparg.mapping(1).ARG -> argscope_1
    """
    name = path.name
    match = re.match(
        r"(.+?)\.clean\.deeparg\.mapping(?:\(\d+\))?\.ARG$",
        name,
        flags=re.IGNORECASE,
    )
    if match:
        return match.group(1)

    lower = name.lower()
    if ".clean." in lower:
        pos = lower.index(".clean.")
        return name[:pos]

    return path.stem


# =============================================================================
# 3. ARGScope (DIAMOND0.7 + Gate0.1)
# =============================================================================

def load_argscope_diamond_sets() -> Dict[str, set[str]]:
    if not ARGSCOPE_DIAMOND_FILE.exists():
        raise FileNotFoundError(
            f"ARGScope DIAMOND file not found:\n{ARGSCOPE_DIAMOND_FILE}"
        )

    df = pd.read_csv(
        ARGSCOPE_DIAMOND_FILE,
        encoding="utf-8-sig",
        low_memory=False,
    )

    required = ["sample_name", "read_id"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"Missing columns in ARGScope DIAMOND file: {missing}\n"
            f"Available columns: {df.columns.tolist()}"
        )

    mask = pd.Series(True, index=df.index)

    if "Pred_ARG" in df.columns:
        pred = df["Pred_ARG"].astype(str).str.strip().str.upper()
        mask &= pred.eq("ARG")

    if "gate_threshold" in df.columns:
        gate_values = pd.to_numeric(df["gate_threshold"], errors="coerce")
        gate_mask = np.isclose(
            gate_values.to_numpy(dtype=float),
            TARGET_GATE,
            rtol=0.0,
            atol=1e-10,
            equal_nan=False,
        )
        if not gate_mask.any():
            observed = sorted(gate_values.dropna().unique().tolist())
            raise RuntimeError(
                f"Expected gate_threshold={TARGET_GATE}, but observed={observed}"
            )
        mask &= gate_mask

    if "diamond_threshold" in df.columns:
        diamond_text = df["diamond_threshold"].astype(str).str.strip().str.lower()
        diamond_mask = diamond_text.eq(TARGET_DIAMOND_TEXT.lower())
        if not diamond_mask.any():
            observed = sorted(diamond_text.dropna().unique().tolist())
            raise RuntimeError(
                f"Expected diamond_threshold={TARGET_DIAMOND_TEXT}, but observed={observed}"
            )
        mask &= diamond_mask

    df = df.loc[mask, ["sample_name", "read_id"]].copy()
    df["sample_name"] = df["sample_name"].astype(str).str.strip()
    df["read_id"] = df["read_id"].astype(str).str.strip()

    result = {}
    for sample in sorted(df["sample_name"].unique().tolist()):
        result[sample] = clean_id_series(
            df.loc[df["sample_name"].eq(sample), "read_id"]
        )

    if not result:
        raise RuntimeError(
            "No ARGScope DIAMOND0.7 + Gate0.1 rows remained after filtering."
        )

    return result


# =============================================================================
# 4. DeepARG
# =============================================================================

def load_deeparg_sets() -> Dict[str, set[str]]:
    if not DEEPARG_ROOT.is_dir():
        raise FileNotFoundError(f"DeepARG folder not found:\n{DEEPARG_ROOT}")

    files = sorted(DEEPARG_ROOT.glob("*.ARG"))
    if not files:
        raise RuntimeError(f"No *.ARG files found for DeepARG under:\n{DEEPARG_ROOT}")

    result = {}
    for path in files:
        sample = sample_name_from_arg_file(path)

        header = pd.read_csv(path, sep="\t", nrows=0)
        if "read_id" not in header.columns:
            raise ValueError(
                f"'read_id' column not found in DeepARG file:\n{path}\n"
                f"Available columns: {header.columns.tolist()}"
            )

        df = pd.read_csv(
            path,
            sep="\t",
            usecols=["read_id"],
            dtype={"read_id": str},
            low_memory=False,
        )

        result[sample] = clean_id_series(df["read_id"])

    return result


# =============================================================================
# 5. RAW BLASTN (unfiltered)
# =============================================================================

def find_raw_blast_file(sample: str) -> Path:
    sample_dir = RAW_BLAST_ROOT / sample
    if not sample_dir.is_dir():
        raise FileNotFoundError(
            f"Raw BLAST sample folder not found:\n{sample_dir}"
        )

    preferred = sample_dir / f"{sample}_blastn.tsv"
    if preferred.exists():
        return preferred

    candidates = sorted(sample_dir.glob("*_blastn.tsv"))
    if len(candidates) == 1:
        return candidates[0]
    if candidates:
        return candidates[0]

    raise FileNotFoundError(
        f"No raw BLASTN TSV found under:\n{sample_dir}"
    )


def load_raw_blast_sets(samples: List[str]) -> Dict[str, set[str]]:
    """
    Read RAW BLASTN output.

    IMPORTANT:
    The original BLASTN TSV files have NO header row.
    Therefore column 0 is qseqid.

    Example first row:
        SRR6468672.233#0/1    NG_047924...    99.010    101    ...

    We only need unique query/read IDs for the Venn comparison,
    so only the first BLAST column is loaded.
    """
    result = {}

    for sample in samples:
        try:
            path = find_raw_blast_file(sample)
        except FileNotFoundError:
            print(f"[WARNING] Raw BLASTN file missing for sample: {sample}")
            continue

        try:
            df = pd.read_csv(
                path,
                sep="\t",
                header=None,
                usecols=[0],
                names=["qseqid"],
                dtype={0: str},
                low_memory=False,
            )
        except pd.errors.EmptyDataError:
            df = pd.DataFrame(columns=["qseqid"])

        result[sample] = clean_id_series(df["qseqid"])

        print(
            f"[Raw BLASTN] {sample}: "
            f"{len(df):,} hit rows, "
            f"{len(result[sample]):,} unique read IDs"
        )

    return result


# =============================================================================
# 6. STATS
# =============================================================================

def calc_stats(
    argscope_ids: set[str],
    deeparg_ids: set[str],
    rawblast_ids: set[str],
) -> dict:

    all_three = argscope_ids & deeparg_ids & rawblast_ids
    union_all = argscope_ids | deeparg_ids | rawblast_ids

    pair_argscope_deeparg = argscope_ids & deeparg_ids
    pair_argscope_rawblast = argscope_ids & rawblast_ids
    pair_deeparg_rawblast = deeparg_ids & rawblast_ids

    return {
        "ARGScope_count": len(argscope_ids),
        "DeepARG_count": len(deeparg_ids),
        "Raw_BLASTN_count": len(rawblast_ids),
        "ALL_THREE_intersection": len(all_three),
        "ARGScope_DeepARG_intersection": len(pair_argscope_deeparg),
        "ARGScope_RawBLAST_intersection": len(pair_argscope_rawblast),
        "DeepARG_RawBLAST_intersection": len(pair_deeparg_rawblast),
        "Union_all_three": len(union_all),
        "ALL_THREE_over_ARGScope_pct": (
            100.0 * len(all_three) / len(argscope_ids) if argscope_ids else 0.0
        ),
        "ALL_THREE_over_DeepARG_pct": (
            100.0 * len(all_three) / len(deeparg_ids) if deeparg_ids else 0.0
        ),
        "ALL_THREE_over_RawBLAST_pct": (
            100.0 * len(all_three) / len(rawblast_ids) if rawblast_ids else 0.0
        ),
        "Jaccard_all_three_pct": (
            100.0 * len(all_three) / len(union_all) if union_all else 0.0
        ),
        "_all_three_ids": all_three,
        "_argscope_deeparg_ids": pair_argscope_deeparg,
        "_argscope_rawblast_ids": pair_argscope_rawblast,
        "_deeparg_rawblast_ids": pair_deeparg_rawblast,
    }


# =============================================================================
# 7. DRAW
# =============================================================================

def make_venn_sets(
    argscope_ids: set[str],
    deeparg_ids: set[str],
    rawblast_ids: set[str],
):
    return {
        "ARGScope\nD0.7+G0.1": argscope_ids,
        "DeepARG": deeparg_ids,
        "Raw BLASTN": rawblast_ids,
    }


def draw_single(
    sample: str,
    argscope_ids: set[str],
    deeparg_ids: set[str],
    rawblast_ids: set[str],
    output_file: Path,
) -> None:

    stats = calc_stats(argscope_ids, deeparg_ids, rawblast_ids)

    fig, ax = plt.subplots(figsize=(8.4, 7.0))
    venn(make_venn_sets(argscope_ids, deeparg_ids, rawblast_ids), ax=ax)

    ax.set_title(
        f"{sample.replace('_', '-')}\n"
        f"All-three intersection = {stats['ALL_THREE_intersection']:,}",
        fontsize=13,
        pad=14,
    )

    fig.tight_layout()
    fig.savefig(output_file, dpi=DPI, bbox_inches="tight")
    fig.savefig(output_file.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def draw_panel(panel_data) -> None:
    n = len(panel_data)
    ncols = 4
    nrows = math.ceil(n / ncols)

    fig, axes = plt.subplots(nrows, ncols, figsize=(28, 5.8 * nrows))

    if hasattr(axes, "flat"):
        flat_axes = list(axes.flat)
    else:
        flat_axes = [axes]

    for ax, item in zip(flat_axes, panel_data):
        sample, argscope_ids, deeparg_ids, rawblast_ids = item
        stats = calc_stats(argscope_ids, deeparg_ids, rawblast_ids)

        venn(make_venn_sets(argscope_ids, deeparg_ids, rawblast_ids), ax=ax)

        ax.set_title(
            f"{sample.replace('_', '-')}\n"
            f"3-set | Core = {stats['ALL_THREE_intersection']:,}",
            fontsize=10,
            pad=8,
        )

    for ax in flat_axes[len(panel_data):]:
        ax.axis("off")

    fig.suptitle(
        "ARGScope D0.7+G0.1 / DeepARG / Raw BLASTN\n"
        "Raw BLASTN = original BLAST output before strict filtering",
        fontsize=16,
        y=0.995,
    )

    fig.tight_layout(rect=[0, 0, 1, 0.975])
    fig.savefig(OUT_DIR / "ALL_COMMON_SAMPLES_3SET_Venn_panel.png", dpi=DPI, bbox_inches="tight")
    fig.savefig(OUT_DIR / "ALL_COMMON_SAMPLES_3SET_Venn_panel.pdf", bbox_inches="tight")
    plt.close(fig)


# =============================================================================
# 8. MAIN
# =============================================================================

def main():
    print("=" * 110)
    print("3-set Venn: ARGScope D0.7+G0.1 / DeepARG / Raw BLASTN")
    print("=" * 110)
    print(f"SCRIPT_DIR      : {SCRIPT_DIR}")
    print(f"BASE_DIR        : {BASE_DIR}")
    print(f"ARGScope source : {ARGSCOPE_DIAMOND_FILE}")
    print(f"DeepARG         : {DEEPARG_ROOT}")
    print(f"Raw BLASTN      : {RAW_BLAST_ROOT}")
    print(f"Output          : {OUT_DIR}")
    print("=" * 110)

    argscope_sets = load_argscope_diamond_sets()
    deeparg_sets = load_deeparg_sets()

    all_samples = sorted(set(argscope_sets) | set(deeparg_sets))
    rawblast_sets = load_raw_blast_sets(all_samples)

    common_samples = sorted(
        set(argscope_sets)
        & set(deeparg_sets)
        & set(rawblast_sets)
    )

    availability = []
    for sample in sorted(set(all_samples) | set(rawblast_sets)):
        availability.append({
            "sample": sample,
            "ARGScope_D070_G010": sample in argscope_sets,
            "DeepARG": sample in deeparg_sets,
            "Raw_BLASTN": sample in rawblast_sets,
            "common_to_all_three": sample in common_samples,
        })

    pd.DataFrame(availability).to_csv(
        OUT_DIR / "sample_availability_across_three_methods.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("Common samples:")
    print(common_samples)

    if not common_samples:
        raise RuntimeError("No sample is present in all three methods.")

    rows = []
    panel_data = []

    pooled_argscope = set()
    pooled_deeparg = set()
    pooled_rawblast = set()

    for sample in common_samples:
        argscope_ids = argscope_sets[sample]
        deeparg_ids = deeparg_sets[sample]
        rawblast_ids = rawblast_sets[sample]

        stats = calc_stats(argscope_ids, deeparg_ids, rawblast_ids)

        rows.append({
            "sample": sample,
            "ARGScope_count": stats["ARGScope_count"],
            "DeepARG_count": stats["DeepARG_count"],
            "Raw_BLASTN_count": stats["Raw_BLASTN_count"],
            "ALL_THREE_intersection": stats["ALL_THREE_intersection"],
            "ARGScope_DeepARG_intersection": stats["ARGScope_DeepARG_intersection"],
            "ARGScope_RawBLAST_intersection": stats["ARGScope_RawBLAST_intersection"],
            "DeepARG_RawBLAST_intersection": stats["DeepARG_RawBLAST_intersection"],
            "ALL_THREE_over_ARGScope_pct": stats["ALL_THREE_over_ARGScope_pct"],
            "ALL_THREE_over_DeepARG_pct": stats["ALL_THREE_over_DeepARG_pct"],
            "ALL_THREE_over_RawBLAST_pct": stats["ALL_THREE_over_RawBLAST_pct"],
            "Jaccard_all_three_pct": stats["Jaccard_all_three_pct"],
        })

        save_id_set(
            stats["_all_three_ids"],
            ID_OUT_DIR / f"{sample}_all_three_intersection_read_ids.csv",
        )
        save_id_set(
            stats["_argscope_deeparg_ids"],
            ID_OUT_DIR / f"{sample}_ARGScope_DeepARG_intersection_read_ids.csv",
        )
        save_id_set(
            stats["_argscope_rawblast_ids"],
            ID_OUT_DIR / f"{sample}_ARGScope_RawBLAST_intersection_read_ids.csv",
        )
        save_id_set(
            stats["_deeparg_rawblast_ids"],
            ID_OUT_DIR / f"{sample}_DeepARG_RawBLAST_intersection_read_ids.csv",
        )

        draw_single(
            sample,
            argscope_ids,
            deeparg_ids,
            rawblast_ids,
            OUT_DIR / f"{sample}_3set_venn.png",
        )

        panel_data.append((sample, argscope_ids, deeparg_ids, rawblast_ids))

        pooled_argscope.update(f"{sample}::{rid}" for rid in argscope_ids)
        pooled_deeparg.update(f"{sample}::{rid}" for rid in deeparg_ids)
        pooled_rawblast.update(f"{sample}::{rid}" for rid in rawblast_ids)

    per_sample_file = OUT_DIR / "per_sample_3set_overlap_summary.csv"
    pd.DataFrame(rows).to_csv(
        per_sample_file,
        index=False,
        encoding="utf-8-sig",
    )

    draw_panel(panel_data)

    pooled_stats = calc_stats(
        pooled_argscope,
        pooled_deeparg,
        pooled_rawblast,
    )

    pooled_venn_file = OUT_DIR / "ALL_COMMON_SAMPLES_POOLED_3set_venn.png"
    draw_single(
        "ALL_COMMON_SAMPLES_POOLED",
        pooled_argscope,
        pooled_deeparg,
        pooled_rawblast,
        pooled_venn_file,
    )

    pooled_summary_file = OUT_DIR / "pooled_3set_overlap_summary.csv"
    pd.DataFrame([{
        "sample": "ALL_COMMON_SAMPLES_POOLED",
        "ARGScope_count": pooled_stats["ARGScope_count"],
        "DeepARG_count": pooled_stats["DeepARG_count"],
        "Raw_BLASTN_count": pooled_stats["Raw_BLASTN_count"],
        "ALL_THREE_intersection": pooled_stats["ALL_THREE_intersection"],
        "ARGScope_DeepARG_intersection": pooled_stats["ARGScope_DeepARG_intersection"],
        "ARGScope_RawBLAST_intersection": pooled_stats["ARGScope_RawBLAST_intersection"],
        "DeepARG_RawBLAST_intersection": pooled_stats["DeepARG_RawBLAST_intersection"],
        "ALL_THREE_over_ARGScope_pct": pooled_stats["ALL_THREE_over_ARGScope_pct"],
        "ALL_THREE_over_DeepARG_pct": pooled_stats["ALL_THREE_over_DeepARG_pct"],
        "ALL_THREE_over_RawBLAST_pct": pooled_stats["ALL_THREE_over_RawBLAST_pct"],
        "Jaccard_all_three_pct": pooled_stats["Jaccard_all_three_pct"],
    }]).to_csv(
        pooled_summary_file,
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 110)
    print("DONE")
    print("=" * 110)
    print(f"Common samples : {len(common_samples)}")
    print(f"Per-sample CSV : {per_sample_file}")
    print(f"Pooled CSV     : {pooled_summary_file}")
    print(f"Pooled Venn    : {pooled_venn_file}")
    print(f"Panel          : {OUT_DIR / 'ALL_COMMON_SAMPLES_3SET_Venn_panel.png'}")
    print("=" * 110)


if __name__ == "__main__":
    main()
