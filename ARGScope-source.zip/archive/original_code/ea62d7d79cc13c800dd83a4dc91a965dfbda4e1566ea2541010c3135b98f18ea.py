# -*- coding: utf-8 -*-
import re
import csv

INPUT_FASTA = "VFDB_setB_nt.fas"
OUTPUT_CSV = "VF_DNASeq.csv"


def parse_header(header):
    """
    解析类似下面的 FASTA header:
    >VFG037176(gb|WP_001081735) (plc1) phospholipase C
    [Phospholipase C (VF0470) - Exotoxin (VFC0235)]
    [Acinetobacter baumannii ACICU]
    """

    result = {
        "VFG_ID": "",
        "Protein_ID": "",
        "Gene_Symbol": "",
        "Description": "",
        "Subtype": "",
        "Subtype_ID": "",
        "Type": "",
        "Type_ID": "",
        "Strain": ""
    }

    header = header.strip()

    # 去掉开头 >
    if header.startswith(">"):
        header = header[1:].strip()

    # -------------------------
    # 1. 提取最后两个中括号内容
    #    倒数第二个通常是 [Subtype (VFxxxx) - Type (VFCxxxx)]
    #    倒数第一个通常是 [Strain]
    # -------------------------
    bracket_contents = re.findall(r"\[([^\[\]]+)\]", header)

    vf_block = ""
    strain = ""

    if len(bracket_contents) >= 1:
        strain = bracket_contents[-1].strip()
    if len(bracket_contents) >= 2:
        vf_block = bracket_contents[-2].strip()

    result["Strain"] = strain

    # -------------------------
    # 2. 解析 vf_block:
    #    Subtype (VFxxxx) - Type (VFCxxxx)
    # -------------------------
    vf_pattern = re.match(
        r"^(.*?)\s*\((VF\d+)\)\s*-\s*(.*?)\s*\((VFC\d+)\)$",
        vf_block
    )
    if vf_pattern:
        result["Subtype"] = vf_pattern.group(1).strip()
        result["Subtype_ID"] = vf_pattern.group(2).strip()
        result["Type"] = vf_pattern.group(3).strip()
        result["Type_ID"] = vf_pattern.group(4).strip()

    # -------------------------
    # 3. 去掉后面的 [vf_block] 和 [strain]
    #    剩下前半部分:
    #    VFG037176(gb|WP_001081735) (plc1) phospholipase C
    # -------------------------
    core = re.sub(r"\s*\[[^\[\]]+\]\s*$", "", header).strip()
    core = re.sub(r"\s*\[[^\[\]]+\]\s*$", "", core).strip()

    # -------------------------
    # 4. 提取 VFG_ID 和 Protein_ID
    #    例如:
    #    VFG037176(gb|WP_001081735)
    # -------------------------
    m = re.match(r"^(\S+?)\(([^()]*)\)\s*(.*)$", core)
    if m:
        result["VFG_ID"] = m.group(1).strip()
        result["Protein_ID"] = m.group(2).strip()
        remain = m.group(3).strip()
    else:
        remain = core

    # -------------------------
    # 5. 提取 Gene_Symbol
    #    通常后面第一个括号是 gene symbol，例如 (plc1)
    # -------------------------
    m2 = re.match(r"^\(([^()]*)\)\s*(.*)$", remain)
    if m2:
        result["Gene_Symbol"] = m2.group(1).strip()
        result["Description"] = m2.group(2).strip()
    else:
        result["Description"] = remain.strip()

    return result


def read_fasta(fasta_file):
    """
    读取 FASTA，返回 [(header, sequence), ...]
    """
    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))
                header = line.strip()
                seq_lines = []
            else:
                seq_lines.append(line.strip())

        if header is not None:
            records.append((header, "".join(seq_lines)))

    return records


def main():
    records = read_fasta(INPUT_FASTA)

    fieldnames = [
        "VFG_ID",
        "Protein_ID",
        "Gene_Symbol",
        "Description",
        "Subtype",
        "Subtype_ID",
        "Type",
        "Type_ID",
        "Strain",
        "Sequence"
    ]

    parsed_rows = []

    for header, seq in records:
        info = parse_header(header)
        info["Sequence"] = seq
        parsed_rows.append(info)

    with open(OUTPUT_CSV, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(parsed_rows)

    print(f"总序列数: {len(parsed_rows)}")
    print(f"结果已保存到: {OUTPUT_CSV}")

    # 简单统计
    type_set = set()
    subtype_set = set()
    for row in parsed_rows:
        if row["Type"]:
            type_set.add(row["Type"])
        if row["Subtype"]:
            subtype_set.add(row["Subtype"])

    print(f"Type 数量: {len(type_set)}")
    print(f"Subtype 数量: {len(subtype_set)}")


if __name__ == "__main__":
    main()