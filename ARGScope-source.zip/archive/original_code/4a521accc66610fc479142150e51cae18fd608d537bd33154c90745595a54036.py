#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Four-stage, unsupervised UMAP of saved Full-student TEST-ARG features.

Run directly with the dnabert2_5060 interpreter. No training or source files are
modified. Type labels color the plots; they are NEVER passed to UMAP fitting.
"""
import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from collections import Counter
from importlib.metadata import version
from pathlib import Path

# Reproducible, bounded CPU execution; no GPU/model inference is necessary.
os.environ.setdefault("NUMBA_NUM_THREADS", "1")
import numpy as np
import pandas as pd
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors
from threadpoolctl import threadpool_limits
from umap import UMAP

HERE = Path(__file__).resolve().parent
TYPE_NAMES = [
    ("beta_lactam", "Beta-lactams", "#b29b28"),
    ("trimethoprim", "Trimethoprim", "#7765ad"),
    ("macrolide-lincosamide-streptogramin", "MLS", "#d29433"),
    ("fusidic_acid", "Fusidic acid", "#cf619e"),
    ("fosfomycin", "Fosfomycin", "#38a563"),
    ("aminoglycoside", "Aminoglycosides", "#84a834"),
    ("quinolone", "Quinolones", "#28a4b4"),
    ("multidrug", "Multidrug", "#ed6b88"),
    ("vancomycin", "Vancomycin", "#429cc3"),
    ("chloramphenicol", "Chloramphenicol", "#a472b5"),
    ("florfenicol", "Florfenicol", "#765845"),
    ("rifamycin", "Rifamycin", "#3f8466"),
    ("tetracycline", "Tetracyclines", "#27ad8b"),
    ("other_peptide_antibiotics", "Other peptides", "#ee773c"),
    ("bacitracin", "Bacitracin", "#598fce"),
    ("sulfonamide", "Sulfonamide", "#b460b4"),
    ("tetracenomycin_C", "Tetracenomycin C", "#bb6544"),
    ("novobiocin", "Novobiocin", "#81c5b5"),
    ("tunicamycin", "Tunicamycin", "#4a438d"),
    ("streptothricin", "Streptothricin", "#d6ae63"),
    ("polymyxin", "Polymyxin", "#d04945"),
    ("bleomycin", "Bleomycin", "#355b86"),
    ("puromycin", "Puromycin", "#6d7336"),
]
ORDER = [x[0] for x in TYPE_NAMES]
DISPLAY = {x[0]: x[1] for x in TYPE_NAMES}
COLORS = {x[0]: x[2] for x in TYPE_NAMES}
plt.rcParams.update({
    "font.family": "Arial", "font.size": 10, "axes.titlesize": 12,
    "axes.labelsize": 10.5, "axes.linewidth": 1.1, "svg.fonttype": "none",
    "pdf.fonttype": 42, "ps.fonttype": 42, "axes.unicode_minus": False,
    "figure.facecolor": "white",
})


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def read_ids(path):
    ids = [s.strip() for s in path.read_text(encoding="utf-8-sig").splitlines() if s.strip()]
    require(len(ids) == len(set(ids)), f"Duplicate IDs: {path}")
    return set(ids)


def inspect_modality(root, modality, epochs_override, sources):
    folder = root / modality
    best_path = folder / "current_run_best_epoch_summary.json"
    summary = json.loads(best_path.read_text(encoding="utf-8"))
    best_epoch = int(summary["current_run_best_epoch"])
    history_path = folder / ("training_loss.csv" if modality == "protein" else "student_training_history.csv")
    history = pd.read_csv(history_path)
    student = history[history.stage.eq("student")].copy()
    score_col = "validation_selection_score" if modality == "protein" else "validation_score"
    require(not student.epoch.duplicated().any(), "Duplicate student epochs in training history")
    best_score = float(summary["current_run_best_validation_score"])
    best_row = student[student.epoch.eq(best_epoch)]
    require(len(best_row) == 1, f"Best epoch absent from history: {modality}")
    require(np.isclose(float(best_row.iloc[0][score_col]), best_score, rtol=0, atol=1e-12),
            f"Best score disagrees with history: {modality}")
    require(np.isclose(float(student[score_col].max()), best_score, rtol=0, atol=1e-12),
            f"Saved best is not a validation maximum: {modality}")
    pred_path = folder / "test_sequence_predictions.csv"
    truth = pd.read_csv(pred_path, keep_default_na=False)
    require(truth.sequence_id.is_unique and set(truth.split) == {"test"}, "Invalid test prediction identities/split")
    test_path = folder / "test_ids.txt"
    test_ids = read_ids(test_path)
    require(set(truth.sequence_id) == test_ids, "Test predictions do not match authoritative test IDs")
    arg_truth = truth.loc[truth.true_ARG.eq(1)].set_index("sequence_id").sort_index()
    require(set(arg_truth.true_type) == set(ORDER), "Expected all 23 ARG Types in the feature population")
    reference_ids = arg_truth.index.tolist()
    train_path = folder / ("train_ids.txt" if modality == "protein" else "model_train_ids.txt")
    val_path = folder / "validation_ids.txt"
    train_ids, val_ids = read_ids(train_path), read_ids(val_path)
    require(not (test_ids & train_ids or test_ids & val_ids or train_ids & val_ids), "Train/validation/test ID overlap")
    for path in (best_path, history_path, pred_path, test_path, train_path, val_path):
        sources[str(path)] = sha256(path)
    feature_files = sorted((folder / "epoch_features").glob("*_test_ARG_type_features.pt"))
    require(bool(feature_files), f"No epoch feature files under {folder}")
    snapshots, audit = {}, []
    fingerprint = None
    for path in feature_files:
        sources[str(path)] = sha256(path)
        # Tensor/dictionary-only loading; no unrestricted pickle execution.
        data = torch.load(path, map_location="cpu", weights_only=True)
        epoch = int(data["epoch"])
        ids = list(data["sequence_ids"])
        require(len(ids) == len(set(ids)) == len(reference_ids), f"Duplicate/missing feature IDs: {path.name}")
        require(set(ids) == set(reference_ids), f"Feature population mismatch: {path.name}")
        require(data["split"] == "test" and data["ARG_only"] is True, "Feature population must be TEST ARG only")
        positions = pd.Index(ids).get_indexer(reference_ids)
        true_types = np.asarray(data["true_types"], dtype=str)[positions]
        true_subtypes = np.asarray(data["true_subtypes"], dtype=str)[positions]
        require(np.array_equal(true_types, arg_truth.true_type.to_numpy()), f"Type labels disagree: {path.name}")
        require(np.array_equal(true_subtypes, arg_truth.true_subtype.to_numpy()), f"Subtype labels disagree: {path.name}")
        features = data["features"].detach().cpu().numpy()[positions].astype(np.float32, copy=False)
        require(features.shape == (len(reference_ids), 512) and np.isfinite(features).all(), f"Invalid 512D features: {path}")
        norms = np.linalg.norm(features, axis=1)
        require(np.allclose(norms, 1, rtol=0, atol=1e-4), f"Expected normalized student features: {path.name}")
        provenance = data["experiment_provenance"]
        current_fingerprint = provenance.get("split_fingerprint")
        require(current_fingerprint is not None, "Missing split fingerprint")
        if fingerprint is None:
            fingerprint = current_fingerprint
        require(current_fingerprint == fingerprint, "Mixed split fingerprints across epochs")
        require(not provenance.get("smoke_test_only", False), "Smoke-test features cannot be plotted as final results")
        # Each epoch has one feature export in the current data layout.
        require(epoch not in snapshots, f"Ambiguous duplicate feature snapshots for epoch {epoch}")
        snapshots[epoch] = {
            "path": path, "features": features, "types": true_types, "subtypes": true_subtypes,
            "ids": reference_ids, "representation": data["representation"],
            "is_best": path.name.startswith("run_best_epoch_"),
        }
        audit.append({
            "modality": modality, "epoch": epoch, "file": str(path), "n_sequences": len(ids),
            "n_types": len(set(true_types)), "dimension": 512, "all_finite": True,
            "norm_min": float(norms.min()), "norm_max": float(norms.max()),
            "is_run_best": snapshots[epoch]["is_best"], "split_fingerprint": current_fingerprint,
            "validation_score": float(student.loc[student.epoch.eq(epoch), score_col].iloc[0])
                if student.epoch.eq(epoch).any() else None,
        })
        del data
    require(best_epoch in snapshots and snapshots[best_epoch]["is_best"], "Best-epoch feature export missing")
    require(snapshots[best_epoch]["path"].name == summary["best_epoch_snapshot"], "Summary identifies a different best feature file")
    earlier = sorted(e for e in snapshots if e < best_epoch)
    require(len(earlier) >= 3, "Need at least three available snapshots preceding the best epoch")
    if epochs_override:
        first_three = list(epochs_override)
        require(len(first_three) == len(set(first_three)) == 3, "--epochs requires three unique epochs")
        require(all(e in earlier for e in first_three) and first_three == sorted(first_three),
                "Requested epochs must be available, increasing, and before the validation-best epoch")
    else:
        # Temporal choice before plotting: initial, approximately 1/3 and 2/3 of the way to best.
        first_three = [earlier[0]]
        for target in (best_epoch / 3, 2 * best_epoch / 3):
            candidates = [e for e in earlier if e not in first_three]
            first_three.append(min(candidates, key=lambda e: (abs(e - target), e)))
        first_three.sort()
    selected = first_three + [best_epoch]
    for item in audit:
        item["selected_for_plot"] = item["epoch"] in selected
    return {
        "selected_epochs": selected, "best_epoch": best_epoch, "best_validation_score": best_score,
        "snapshots": snapshots, "audit": audit, "split_fingerprint": fingerprint,
        "ids": reference_ids, "types": arg_truth.true_type.to_numpy(),
    }


def projection(snapshot, modality, epoch, out, params, versions, recompute):
    prefix = out / "coordinates" / f"{modality}_epoch_{epoch:03d}"
    path = prefix.with_suffix(".csv")
    metadata_path = prefix.with_suffix(".json")
    identity = {
        "source_sha256": sha256(snapshot["path"]), "params": params,
        "umap_version": versions["umap-learn"], "numpy_version": versions["numpy"],
        "numba_version": versions["numba"],
        "sequence_ids_sha256": hashlib.sha256("\n".join(snapshot["ids"]).encode("utf-8")).hexdigest(),
    }
    if path.exists() and metadata_path.exists() and not recompute:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        require(metadata["identity"] == identity,
                f"Cached UMAP inputs/parameters changed: {path.name}; use --recompute to replace this generated cache")
        require(metadata["coordinates_sha256"] == sha256(path), "Cached coordinate file has changed")
        frame = pd.read_csv(path, keep_default_na=False, float_precision="round_trip")
        require(frame.sequence_id.tolist() == snapshot["ids"], "Cached coordinates have different IDs")
        require(np.array_equal(frame.Type.to_numpy(), snapshot["types"]), "Cached coordinate labels differ")
        coords = frame[["UMAP1", "UMAP2"]].to_numpy()
        print(f"CACHED {modality} epoch {epoch}", flush=True)
    else:
        started = time.perf_counter()
        print(f"FIT {modality} epoch {epoch}: {snapshot['features'].shape}", flush=True)
        # Intentionally omit y: no Type/subtype labels guide the 2D arrangement.
        coords = UMAP(**params).fit_transform(snapshot["features"])
        require(coords.shape == (len(snapshot["ids"]), 2) and np.isfinite(coords).all(), "Invalid UMAP coordinates")
        frame = pd.DataFrame({
            "sequence_id": snapshot["ids"], "Type": snapshot["types"], "Subtype": snapshot["subtypes"],
            "UMAP1": coords[:, 0], "UMAP2": coords[:, 1],
        })
        frame.to_csv(path, index=False, encoding="utf-8-sig")
        # Return the exported full-precision values on both fresh and cached runs.
        coords = pd.read_csv(path, float_precision="round_trip")[["UMAP1", "UMAP2"]].to_numpy()
        metadata = {
            "identity": identity, "source": str(snapshot["path"]),
            "coordinates_sha256": sha256(path), "fit_seconds": time.perf_counter()-started,
            "supervised": False, "labels_used_in_fit": False,
        }
        save_json(metadata_path, metadata)
        print(f"DONE {modality} epoch {epoch}: {metadata['fit_seconds']:.1f}s", flush=True)
    require(np.isfinite(coords).all(), "Nonfinite projected coordinates")
    return coords


def separation_statistics(snapshot, coords, modality, epoch, best_epoch):
    x, labels = snapshot["features"], snapshot["types"]
    # Exact cosine neighbors with query=None excludes each observation itself.
    neighbors = NearestNeighbors(n_neighbors=15, metric="cosine", algorithm="brute", n_jobs=1).fit(x).kneighbors(return_distance=False)
    purity = (labels[neighbors] == labels[:, None]).mean(axis=1)
    return {
        "modality": modality, "epoch": epoch, "is_validation_best": epoch == best_epoch,
        "n_sequences": len(labels), "n_types": len(set(labels)),
        "silhouette_512D_cosine": float(silhouette_score(x, labels, metric="cosine")),
        "type_neighbor_purity_512D_k15": float(purity.mean()),
        "macro_type_neighbor_purity_512D_k15": float(np.mean([purity[labels == t].mean() for t in ORDER])),
        "silhouette_UMAP2D_euclidean_visual_only": float(silhouette_score(coords, labels, metric="euclidean")),
    }


def make_figure(modality, info, projections, out, seed, marker_size):
    width, left, right, gap, bottom, top = 15.8, .55, .18, .42, 1.40, .58
    side = (width-left-right-3*gap)/4
    height = bottom+side+top
    fig = plt.figure(figsize=(width, height))
    axes, point_counts, artists = [], [], []
    order = np.random.default_rng(seed).permutation(len(info["ids"]))
    labels = info["types"]
    point_colors = np.asarray([COLORS[t] for t in labels])
    for position, epoch in enumerate(info["selected_epochs"]):
        ax = fig.add_axes([(left+position*(side+gap))/width, bottom/height, side/width, side/height])
        coords = projections[epoch]
        artist = ax.scatter(coords[order, 0], coords[order, 1], c=point_colors[order],
                            s=marker_size, alpha=.92, edgecolors="white", linewidths=.17,
                            marker="o", rasterized=False)
        lo, hi = coords.min(axis=0), coords.max(axis=0)
        center = (lo+hi)/2
        span = max(float(np.max(hi-lo)), 1e-6)*1.10
        ax.set_xlim(center[0]-span/2, center[0]+span/2)
        ax.set_ylim(center[1]-span/2, center[1]+span/2)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel("UMAP1", labelpad=5)
        ax.set_ylabel("UMAP2", labelpad=5)
        title = f"Best model (epoch {epoch})" if position == 3 else f"Epoch {epoch}"
        ax.set_title(title, pad=10, fontweight="normal")
        axes.append(ax)
        artists.append(artist)
        point_counts.append(len(artist.get_offsets()))
    handles = [Line2D([], [], color=COLORS[t], marker="o", linestyle="none", markersize=6,
                      markeredgecolor="white", markeredgewidth=.3, label=DISPLAY[t]) for t in ORDER]
    legend = fig.legend(handles=handles, ncol=6, loc="upper left", mode="expand",
                        bbox_to_anchor=(left/width, .30/height, (width-left-right)/width, .76/height),
                        bbox_transform=fig.transFigure, frameon=False, borderaxespad=0, borderpad=0,
                        handlelength=1.0, handletextpad=.50, labelspacing=.45, fontsize=9)
    # Publication layout: no figure-level title, panel letters, or footnotes.
    # Population and independent-UMAP interpretation notes remain in the README.
    require(len(fig.texts) == 0, "Unexpected top title, panel letter or bottom explanatory text")
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    lb = legend.get_window_extent(renderer)
    first, last = axes[0].get_window_extent(renderer), axes[-1].get_window_extent(renderer)
    require(abs(lb.x0-first.x0) < 1 and abs(lb.x1-last.x1) < 1, "Legend width does not align with the four-panel plot")
    label_boxes = [a.xaxis.label.get_window_extent(renderer) for a in axes]
    require(lb.y1 + 3 < min(box.y0 for box in label_boxes), "Legend overlaps UMAP1 labels")
    # Ensure each of the 23 labels fits and none is lost/overlapping.
    legend_boxes = [t.get_window_extent(renderer) for t in legend.get_texts()]
    require(len(legend_boxes) == 23, "Incomplete Type legend")
    for i, box in enumerate(legend_boxes):
        require(box.x0 >= first.x0-1 and box.x1 <= last.x1+1, "Legend text leaves plot width")
        for other in legend_boxes[i+1:]:
            require(not box.overlaps(other), "Legend labels overlap")
    require(point_counts == [len(info["ids"])]*4, "A panel dropped points")
    target = out / f"{'Protein' if modality == 'protein' else 'DNA'}_UMAP_4epochs_Type"
    for extension in ("png", "svg", "pdf"):
        fig.savefig(target.with_suffix("."+extension), dpi=600, bbox_inches="tight", pad_inches=.055,
                    facecolor="white")
    fig.savefig(out / "_preview" / (target.name+".png"), dpi=140, bbox_inches="tight", pad_inches=.055,
                facecolor="white")
    geometry = {
        "four_panels": True, "epochs": info["selected_epochs"], "best_epoch": info["best_epoch"],
        "points_per_panel": point_counts, "legend_entries": 23, "legend_columns": 6, "legend_rows": 4,
        "legend_bounds_px": [lb.x0, lb.x1], "plot_bounds_px": [first.x0, last.x1],
        "legend_width_matches_plot": True, "legend_labels_do_not_overlap": True,
        "no_panel_letter_labels": True, "no_bottom_explanatory_footnotes": True,
        "no_top_modality_title": True,
        "point_count_check": "PASS",
    }
    plt.close(fig)
    save_json(out / f"{modality}_figure_layout_validation.json", geometry)
    return geometry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE.parent, help="Full results root containing protein/ and dna/")
    parser.add_argument("--output-dir", type=Path, default=HERE)
    parser.add_argument("--epochs", nargs=3, type=int, help="Three earlier epochs; best is always appended from validation records")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--neighbors", type=int, default=15)
    parser.add_argument("--min-dist", type=float, default=.1)
    parser.add_argument("--marker-size", type=float, default=10)
    parser.add_argument("--recompute", action="store_true", help="Replace generated coordinate caches; never modifies original features")
    args = parser.parse_args()
    require(2 <= args.neighbors < 2287 and 0 <= args.min_dist <= 1 and args.marker_size > 0, "Invalid plotting/UMAP parameters")
    root, out = args.root.resolve(), args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "coordinates").mkdir(exist_ok=True)
    (out / "_preview").mkdir(exist_ok=True)
    versions = {p: version(p) for p in ("umap-learn", "numba", "numpy", "scikit-learn", "matplotlib", "pandas", "torch")}
    params = dict(n_neighbors=args.neighbors, min_dist=args.min_dist, n_components=2, metric="cosine",
                  random_state=args.seed, transform_seed=args.seed, n_jobs=1, n_epochs=500,
                  init="spectral", low_memory=True, spread=1.0)
    sources = {}
    info = {mode: inspect_modality(root, mode, args.epochs, sources) for mode in ("protein", "dna")}
    require(info["protein"]["ids"] == info["dna"]["ids"], "Protein and DNA contain different sequence populations")
    require(np.array_equal(info["protein"]["types"], info["dna"]["types"]), "Protein and DNA Type truth differs")
    require(info["protein"]["split_fingerprint"] == info["dna"]["split_fingerprint"], "Protein and DNA have different training splits")
    pd.DataFrame(info["protein"]["audit"]+info["dna"]["audit"]).to_csv(out/"epoch_feature_audit.csv", index=False, encoding="utf-8-sig")
    counts = Counter(info["protein"]["types"])
    pd.DataFrame([{"Type": t, "Display": DISPLAY[t], "color": COLORS[t], "n_test_ARG": counts[t]}
                  for t in ORDER]).to_csv(out/"type_color_and_counts.csv", index=False, encoding="utf-8-sig")
    selection = {
        mode: {"selected_epochs": d["selected_epochs"], "best_epoch": d["best_epoch"],
               "best_validation_score": d["best_validation_score"]} for mode, d in info.items()
    }
    save_json(out/"selected_epochs.json", selection)
    print(json.dumps(selection, ensure_ascii=False), flush=True)
    statistics, layouts = [], {}
    with threadpool_limits(limits=2):
        for mode, d in info.items():
            projections = {}
            for epoch in d["selected_epochs"]:
                snap = d["snapshots"][epoch]
                projections[epoch] = projection(snap, mode, epoch, out, params, versions, args.recompute)
                statistics.append(separation_statistics(snap, projections[epoch], mode, epoch, d["best_epoch"]))
            layouts[mode] = make_figure(mode, d, projections, out, args.seed, args.marker_size)
            print(f"EXPORTED {mode}: PNG / SVG / PDF", flush=True)
    pd.DataFrame(statistics).to_csv(out/"type_separation_summary.csv", index=False, encoding="utf-8-sig")
    # Verify source bytes after completing the work.
    for path, digest in sources.items():
        require(sha256(Path(path)) == digest, f"Source changed during plotting: {path}")
    manifest = {
        "status": "PASS", "n_sequences_each_panel": len(info["protein"]["ids"]), "n_types": 23,
        "selection": selection, "umap_parameters": params, "versions": versions, "sources_sha256": sources,
        "script_sha256": sha256(Path(__file__)), "layouts": layouts, "source_files_unchanged": True,
        "labels_used_in_UMAP_fit": False, "random_draw_order_shared": True,
        "image_text_policy": "Retain epoch titles, axes and Type legend only; omit top modality title, panel letters and bottom explanatory footnotes. See README for interpretation.",
        "interpretation": "Each epoch is independently embedded with fixed settings. Axes are not aligned; compare local Type mixing qualitatively, not between-panel coordinates or island distances. Best epoch is selected by validation score, not UMAP appearance. Epoch 0 is the saved pre-student-optimization representation, not raw ESM2/DNABERT2 embeddings.",
        "documentation": ["https://umap-learn.readthedocs.io/en/latest/reproducibility.html",
                          "https://umap-learn.readthedocs.io/en/latest/parameters.html"],
    }
    save_json(out/"UMAP_RUN_MANIFEST.json", manifest)
    print(f"SUCCESS: {out}", flush=True)


if __name__ == "__main__":
    main()
