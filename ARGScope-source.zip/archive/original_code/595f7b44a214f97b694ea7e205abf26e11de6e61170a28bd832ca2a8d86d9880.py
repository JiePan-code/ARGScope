from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from PIL import Image

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/ARGScope_drawio_redesign_v3_20260930'
DEST = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/ARGScope_drawio_redesign_v3_20260930')
NAME = 'Figure1_ARGScope_redesign_v3'
source = OUT / (NAME+'.drawio')
doc = ET.parse(source)
cells = {c.get('id'): c for c in doc.iter('mxCell')}
assert cells['prototypes-to-aa-head'].get('target') == 'aa-teacher-subtype'
assert cells['prototypes-to-nt-head'].get('target') == 'nt-teacher-subtype'
assert cells['fused-to-teachers'].get('target') == 'teacher-fused-input'
assert cells['subtype-to-type'].get('source') == 'reported-subtype'
assert cells['subtype-to-type'].get('target') == 'reported-type'
for cell in cells.values():
    if cell.get('edge') == '1':
        assert cell.find('mxGeometry').get('relative') == '1'
    if cell.get('value'):
        assert 'fontFamily=Arial' in cell.get('style', '')
    if 'shape=image' in cell.get('style', ''):
        assert 'image=data:image/' in cell.get('style')

svg_path = OUT / (NAME+'.svg')
svg = ET.parse(svg_path)
svg_nodes = list(svg.iter())
svg_words = ' '.join(''.join(n.itertext()) for n in svg_nodes if n.tag.endswith(('text', 'div', 'span')))
for expected in ['ARGScope', 'DNABERT-2', 'Subtype + non-ARG', 'Head weights']:
    assert expected in svg_words, f'Current label missing from SVG: {expected}'
png_path = OUT / (NAME+'.png')
with Image.open(png_path) as im:
    size = im.size
    im.verify()
assert size[0] >= 2500

lint = subprocess.run([sys.executable, 'C:/Users/Jie Pan/.codex/skills/drawio-skill/scripts/validate.py', str(source), '--json'],
                      capture_output=True, text=True, check=True)
findings = json.loads(lint.stdout)
assert findings['errors'] == 0
assert not any(f['code'] == 'W-OVERLAP' for f in findings['findings'])
report = {
    'native_source_valid': True, 'text_overlap_warnings': 0,
    'png_readable': True, 'png_size': list(size),
    'svg_current_labels_confirmed': True,
    'semantic_endpoint_checks': 'passed',
    'all_assets_embedded': True,
    'accepted_warnings': {
        'fused-aa-junction': 'Intentional branching junction on the common teacher-input wire.',
        'three_edge_crossings': 'Different forward/constraint paths; arc line jumps visible in native exports.'
    },
    'structural_lint': findings,
    'visual_qa': 'Initial render reviewed and two targeted spacing/label repair rounds completed; preview for user approval.',
    'generation_calls': 0,
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()
}
(OUT/'final_checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
if DEST.exists():
    raise SystemExit('Destination already exists; will not overwrite a potentially edited user copy.')
shutil.copytree(OUT, DEST)
for suffix in ['.drawio','.png','.svg']:
    assert hashlib.sha256((OUT/(NAME+suffix)).read_bytes()).digest() == hashlib.sha256((DEST/(NAME+suffix)).read_bytes()).digest()
print(json.dumps({'destination': str(DEST), 'files': [NAME+'.drawio',NAME+'.png',NAME+'.svg'],
                  'verification': report}, ensure_ascii=False, indent=2))
