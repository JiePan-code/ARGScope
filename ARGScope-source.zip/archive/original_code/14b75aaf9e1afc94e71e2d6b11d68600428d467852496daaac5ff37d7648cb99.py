import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import math
import re
from pathlib import Path


# ==========================================================
# 1. 严格 Cross-Attention 模块
# ==========================================================

class StrictCrossAttention(nn.Module):
    """
    严格 Cross-Attention:
        Q = AA embedding
        K = NT embedding
        V = NT embedding
    """

    def __init__(self, dim_aa, dim_nt, d_model=512, n_heads=8):
        super().__init__()

        assert d_model % n_heads == 0, "d_model 必须能被 n_heads 整除"

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.q_proj = nn.Linear(dim_aa, d_model)
        self.k_proj = nn.Linear(dim_nt, d_model)
        self.v_proj = nn.Linear(dim_nt, d_model)

        self.out_proj = nn.Linear(d_model, d_model)
        self.layernorm = nn.LayerNorm(d_model)

    def forward(self, aa_feat, nt_feat):
        B = aa_feat.size(0)

        Q = self.q_proj(aa_feat)
        K = self.k_proj(nt_feat)
        V = self.v_proj(nt_feat)

        Q = Q.view(B, self.n_heads, self.head_dim)
        K = K.view(B, self.n_heads, self.head_dim)
        V = V.view(B, self.n_heads, self.head_dim)

        scores = (Q * K).sum(-1) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(scores, dim=-1)

        context = attn_weights.unsqueeze(-1) * V
        context = context.reshape(B, self.d_model)

        fused = self.out_proj(context)
        fused = self.layernorm(fused + self.q_proj(aa_feat))

        return fused, attn_weights


# ==========================================================
# 2. 文件路径
# ==========================================================

nt_file = "VF_nonVF_dna_embedding.txt"
aa_file = "VF_nonVF_protein_embed_1280.txt"
label_file = "vf_nonvf_ID表_clean_unique_subtype_type.csv"

output_file = "1.all_fusion_embedding_512_with_label.csv"

# 如果显存足够，可以调大到 8192 或 16384
BATCH_SIZE = 4096

# 是否使用 AMP 半精度推理。加速明显，输出会有轻微数值差异。
USE_AMP = torch.cuda.is_available()


# ==========================================================
# 3. 工具函数
# ==========================================================

def clean_id(x):
    x = str(x).strip()
    x = x.lstrip(">")
    x = x.split()[0]
    return x


def detect_label_columns(label_df):
    """
    自动识别 label 文件中的 id / Type / Subtype 列。
    兼容：
        id, type, subtype
        id, Type, Subtype
        ID, Type, Subtype
    """
    col_map = {c.lower(): c for c in label_df.columns}

    if "id" not in col_map:
        raise ValueError("label 文件缺少 id 列")

    if "type" not in col_map:
        raise ValueError("label 文件缺少 Type/type 列")

    if "subtype" not in col_map:
        raise ValueError("label 文件缺少 Subtype/subtype 列")

    return col_map["id"], col_map["type"], col_map["subtype"]


def parse_embedding_line_fast(line):
    """
    快速解析一行 embedding。
    支持：
        id\t0.1\t0.2
        id 0.1 0.2
        id,0.1,0.2
        id [0.1, 0.2]
    """
    line = line.strip()

    if not line:
        return None

    # 找到第一个分隔位置，前面是 ID，后面是数值
    # 常见分隔符：tab、空格、逗号
    m = re.search(r"[\t,\s]+", line)

    if m is None:
        return None

    sample_id = clean_id(line[:m.start()])
    value_str = line[m.end():].strip()

    if not value_str:
        return None

    # 兼容 [0.1, 0.2, ...]
    value_str = value_str.replace("[", " ")
    value_str = value_str.replace("]", " ")
    value_str = value_str.replace(",", " ")

    values = np.fromstring(value_str, sep=" ", dtype=np.float32)

    if values.size == 0:
        return "BAD_LINE"

    return sample_id, values


def read_embedding_txt_fast(file_path):
    """
    高速读取 embedding txt。
    返回：
        ids: list[str]
        matrix: np.ndarray, shape = [N, D]
    """
    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError("找不到文件: {}".format(file_path))

    ids = []
    feats = []
    dim = None
    bad_lines = 0

    with open(file_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, start=1):
            parsed = parse_embedding_line_fast(line)

            if parsed is None:
                continue

            if parsed == "BAD_LINE":
                # 第一行如果是表头，跳过
                if line_num == 1:
                    print("检测到表头或非数值首行，已跳过:", file_path)
                    continue

                bad_lines += 1
                if bad_lines <= 5:
                    print("无法解析的行:", file_path, "line", line_num, line[:120])
                continue

            sample_id, values = parsed

            if dim is None:
                dim = values.size
            elif values.size != dim:
                raise ValueError(
                    "{} 第 {} 行 embedding 维度不一致。期望 {}，实际 {}。该行前 120 字符: {}".format(
                        file_path, line_num, dim, values.size, line[:120]
                    )
                )

            ids.append(sample_id)
            feats.append(values)

    if len(ids) == 0:
        raise ValueError("{} 没有读取到任何有效 embedding。".format(file_path))

    matrix = np.vstack(feats).astype(np.float32)

    # 去重，保留第一次出现
    seen = set()
    keep_idx = []
    dup_n = 0

    for i, sid in enumerate(ids):
        if sid in seen:
            dup_n += 1
            continue
        seen.add(sid)
        keep_idx.append(i)

    if dup_n > 0:
        print("警告: {} 中发现重复 ID 数量: {}，将保留第一次出现的记录。".format(file_path, dup_n))
        ids = [ids[i] for i in keep_idx]
        matrix = matrix[keep_idx]

    print("读取完成:", file_path)
    print("样本数:", len(ids))
    print("特征维度:", matrix.shape[1])
    print("-" * 60)

    return ids, matrix


def align_by_common_ids(nt_ids, nt_mat, aa_ids, aa_mat):
    """
    按共同 ID 对齐两个 embedding 矩阵。
    """
    nt_map = {sid: i for i, sid in enumerate(nt_ids)}
    aa_map = {sid: i for i, sid in enumerate(aa_ids)}

    common_ids = sorted(set(nt_map.keys()) & set(aa_map.keys()))

    if len(common_ids) == 0:
        print("NT ID 前 10 个:", nt_ids[:10])
        print("AA ID 前 10 个:", aa_ids[:10])
        raise ValueError("NT 和 AA 的 ID 交集为 0，请检查 ID 是否一致。")

    nt_index = [nt_map[sid] for sid in common_ids]
    aa_index = [aa_map[sid] for sid in common_ids]

    nt_aligned = nt_mat[nt_index]
    aa_aligned = aa_mat[aa_index]

    return common_ids, nt_aligned, aa_aligned


def fuse_in_batches(model, aa_mat, nt_mat, device, batch_size=4096):
    """
    batch 推理生成 fusion embedding。
    """
    model.eval()
    fused_list = []

    n = aa_mat.shape[0]

    with torch.no_grad():
        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)

            aa_batch = torch.from_numpy(aa_mat[start:end]).to(device, non_blocking=True)
            nt_batch = torch.from_numpy(nt_mat[start:end]).to(device, non_blocking=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                fused_batch, _ = model(aa_batch, nt_batch)

            fused_list.append(fused_batch.float().cpu().numpy())

            if start == 0 or end == n or (start // batch_size + 1) % 10 == 0:
                print("Fusion progress: {}/{}".format(end, n))

    fused_np = np.vstack(fused_list).astype(np.float32)

    return fused_np


def load_label_map(label_file):
    """
    读取 label 文件，返回 id -> Type / Subtype 映射。
    """
    label_df = pd.read_csv(label_file)

    id_col, type_col, subtype_col = detect_label_columns(label_df)

    label_df = label_df[[id_col, type_col, subtype_col]].copy()
    label_df.columns = ["id", "Type", "Subtype"]

    label_df["id"] = label_df["id"].apply(clean_id)
    label_df["Type"] = label_df["Type"].astype(str).str.strip()
    label_df["Subtype"] = label_df["Subtype"].astype(str).str.strip()

    dup_n = label_df["id"].duplicated().sum()

    if dup_n > 0:
        print("警告: label 文件中发现重复 ID 数量: {}，将保留第一次出现的记录。".format(dup_n))
        label_df = label_df.drop_duplicates(subset="id", keep="first")

    type_map = dict(zip(label_df["id"], label_df["Type"]))
    subtype_map = dict(zip(label_df["id"], label_df["Subtype"]))

    return type_map, subtype_map


# ==========================================================
# 4. 主程序
# ==========================================================

def main():
    torch.backends.cudnn.benchmark = True

    print("Loading embedding files...")

    nt_ids, nt_mat = read_embedding_txt_fast(nt_file)
    aa_ids, aa_mat = read_embedding_txt_fast(aa_file)

    print("NT 样本数:", len(nt_ids))
    print("AA 样本数:", len(aa_ids))

    common_ids, nt_aligned, aa_aligned = align_by_common_ids(
        nt_ids,
        nt_mat,
        aa_ids,
        aa_mat
    )

    print("交集样本数:", len(common_ids))
    print("NT 特征形状:", nt_aligned.shape)
    print("AA 特征形状:", aa_aligned.shape)

    if nt_aligned.shape[1] == 0:
        raise ValueError("NT 特征维度为 0，说明 NT 文件没有被正确解析。")

    if aa_aligned.shape[1] == 0:
        raise ValueError("AA 特征维度为 0，说明 AA 文件没有被正确解析。")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    dim_nt = nt_aligned.shape[1]
    dim_aa = aa_aligned.shape[1]

    model = StrictCrossAttention(
        dim_aa=dim_aa,
        dim_nt=dim_nt,
        d_model=512,
        n_heads=8
    ).to(device)

    print("Start fusion...")

    fused_np = fuse_in_batches(
        model=model,
        aa_mat=aa_aligned,
        nt_mat=nt_aligned,
        device=device,
        batch_size=BATCH_SIZE
    )

    print("融合特征形状:", fused_np.shape)

    print("Loading labels...")

    type_map, subtype_map = load_label_map(label_file)

    type_values = [type_map.get(sid, np.nan) for sid in common_ids]
    subtype_values = [subtype_map.get(sid, np.nan) for sid in common_ids]

    matched_n = sum(pd.notna(type_values))
    unmatched_n = len(common_ids) - matched_n

    print("匹配到标签的样本数:", matched_n)
    print("未匹配到标签的样本数:", unmatched_n)

    print("Saving output...")

    feature_cols = ["fusion_{}".format(i) for i in range(fused_np.shape[1])]

    fusion_df = pd.DataFrame(fused_np, columns=feature_cols)
    fusion_df.insert(0, "Subtype", subtype_values)
    fusion_df.insert(0, "Type", type_values)
    fusion_df.insert(0, "id", common_ids)

    fusion_df.to_csv(output_file, index=False, encoding="utf-8-sig")

    print("已保存融合特征到:", output_file)


if __name__ == "__main__":
    main()