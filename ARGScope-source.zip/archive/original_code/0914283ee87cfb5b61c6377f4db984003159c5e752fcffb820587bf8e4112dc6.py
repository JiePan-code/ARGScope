#!/usr/bin/env python3
"""Five-sector annular bars using the verified boxplot revision point estimates.

Bars start at a common score-zero circle; the central hole is NOT a truncated
score axis. Bootstrap percentile intervals are inherited without recalculation.
Model cohorts differ, so model comparisons remain descriptive only.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.cbook import boxplot_stats
from matplotlib.ticker import MaxNLocator, FormatStrFormatter

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
DATA=ROOT/'data'
DATA.mkdir(parents=True,exist_ok=True)
# A fresh directory per render avoids overwriting images open in desktop previews.
FIG=ROOT/('figures_'+time.strftime('%Y%m%d_%H%M%S'))
spec=importlib.util.spec_from_file_location('type_network_style',SOURCE/'type_level_revision/plot_type_network_revision.py')
net=importlib.util.module_from_spec(spec)
spec.loader.exec_module(net)
base=net.base
base.FIG=FIG
base.exports.clear();base.LAYOUT_QA.clear()
POINT_SOURCE=SOURCE/'boxplot_revision/data/all_model_points_and_intervals.csv'
points=pd.read_csv(POINT_SOURCE)
bootstrap=pd.read_csv(SOURCE/'violin_revision/data/ARGScope_parent_bootstrap_five_metrics.csv')
raw_matrix=pd.read_csv(SOURCE/'type_level_revision/data/combined_Type_profile_spearman.csv',index_col=0)
raw_arcs=pd.read_csv(SOURCE/'type_level_revision/data/combined_model_Type_arcs.csv')
order=[t for t in base.ORDER if t!='puromycin']
assert len(order)==22
net.ORDER=order
matrix=raw_matrix.loc[order,order].to_numpy()
arcs=raw_arcs[raw_arcs.Type.isin(order)].copy()
pd.DataFrame(matrix,index=order,columns=order).to_csv(DATA/'Type_matrix_without_puromycin.csv',encoding='utf-8-sig')
arcs.to_csv(DATA/'model_Type_arcs_without_puromycin.csv',index=False,encoding='utf-8-sig')
points.to_csv(DATA/'unchanged_point_estimates_and_intervals.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
METRICS=['Accuracy','Precision','Recall','F1','MCC']
METRIC_SHORT=['ACC','Precision','Recall','F1','MCC']
SHORT={'ARGNet':'AN','DeepARG':'DA','PLM-ARG':'PL','FunGeneTyper':'FG','ARGScope':'AS'}
SECTOR_BG=['#E4F0F3','#F1EEDC','#E6EAF5','#E5F0E7','#F6E4ED']
PCTS=[60,70,80,90]
R0=.44
BAR_AUDIT=[]
TEXT_QA=[]
INPUTS=[POINT_SOURCE,SOURCE/'violin_revision/data/ARGScope_parent_bootstrap_five_metrics.csv',
        SOURCE/'type_level_revision/data/combined_Type_profile_spearman.csv',
        SOURCE/'type_level_revision/data/combined_model_Type_arcs.csv',
        SOURCE/'data/type_display_mapping.csv']
HASHES={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS}


def polar_mm(fig,x,y,size):
    w,h=fig.get_size_inches()*25.4
    return fig.add_axes([x/w,1-(y+size)/h,size/w,size/h],projection='polar')


def radial_rotation(theta):
    deg=(90-np.degrees(theta)+180)%360-180
    if deg>90:deg-=180
    if deg<-90:deg+=180
    return deg


def sector_chart(ax,mod,pct,large=False):
    models=base.MODELS[mod]
    assert models[-1]=='ARGScope'
    ax.set_theta_offset(np.pi/2);ax.set_theta_direction(-1)
    ax.set_ylim(0,1.83);ax.grid(False);ax.set_xticks([]);ax.set_yticks([])
    ax.spines['polar'].set_visible(False)
    fs=7.2 if large else 4.9
    label_fs=8.2 if large else 5.6
    for k,metric in enumerate(METRICS):
        center=k*2*np.pi/5
        span=np.deg2rad(57)
        left=center-span/2
        right=center+span/2
        ax.bar(center,1.,bottom=R0,width=span,facecolor=SECTOR_BG[k],edgecolor='#5B6268',linewidth=.65,zorder=0)
        theta=np.linspace(left,right,120)
        for tick in [0,.25,.5,.75,1.]:
            ax.plot(theta,np.full_like(theta,R0+tick),color='#99A1A6',linewidth=.35,zorder=1)
        for tick in [0,.5,1.]:
            ax.text(left-.035,R0+tick,f'{tick:.1f}',ha='center',va='center',fontsize=fs-.8,
                    rotation=radial_rotation(left),rotation_mode='anchor',color='#40474C')
        step=span/len(models)
        for j,model in enumerate(models):
            t=left+(j+.5)*step
            row=points[(points.Modality==mod)&(points.Model==model)&(points.Completeness==pct)&points.Level.eq('Type')&points.Metric.eq(metric)]
            assert len(row)==1
            row=row.iloc[0]
            value=float(row.Point_estimate)
            assert 0<=value<=1 and 0<=row.CI_low<=row.CI_high<=1
            ax.bar(t,value,bottom=R0,width=.80*step,facecolor=base.COLORS[model],edgecolor='#5C6267',
                   linewidth=.50,hatch='///' if model=='DeepARG' else None,zorder=3)
            ax.plot([t,t],[R0+row.CI_low,R0+row.CI_high],color='#34393D',lw=.55,zorder=4)
            for v in [row.CI_low,row.CI_high]:
                cap=np.array([t-.045*step,t+.045*step])
                ax.plot(cap,np.full(2,R0+v),color='#34393D',lw=.55,zorder=4)
            ax.text(t,R0+value*.56,f'{value:.4f}',ha='center',va='center',fontsize=fs,
                    rotation=radial_rotation(t),rotation_mode='anchor',color='#172027',zorder=5)
            ax.text(t,1.52,SHORT[model],ha='center',va='center',fontsize=fs,
                    rotation=radial_rotation(t),rotation_mode='anchor',color='#30363B')
            BAR_AUDIT.append(dict(Modality=mod,Model=model,Completeness=pct,Metric=metric,
                                  Point_estimate=value,Label=f'{value:.4f}',Radius_bottom=R0,Radius_top=R0+value,
                                  CI_low=row.CI_low,CI_high=row.CI_high,Population=row.Population))
        ax.text(center,1.72,METRIC_SHORT[k],ha='center',va='center',fontsize=label_fs,fontweight='bold',color='#22272B')
    ax.text(0,0,f'{pct}%\n'+('Protein' if mod=='protein' else 'DNA'),ha='center',va='center',
            fontsize=10 if large else 7.2,fontweight='bold',linespacing=1.4,color='#30363B')


def legend(fig):
    handles=[Patch(facecolor=base.COLORS[m],edgecolor='#5B6268',hatch='///' if m=='DeepARG' else None,
                   label=f'{SHORT[m]}  {m}') for m in base.MODELS['protein']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.50,.998),ncol=5,frameon=False,fontsize=8,columnspacing=1.6,handlelength=1.6)


def descriptive_note(fig,y):
    w=fig.get_size_inches()[0]*25.4
    base.text_mm(fig,w/2,y,'Different model cohorts; DeepARG represents selected ARG hits only. Descriptive comparison, not a matched benchmark.',ha='center',fontsize=6.8,color='#60676C')


def subtype_panel(ax,mod,metric):
    color=base.MODCOL[mod]
    extremes=[]
    for i,pct in enumerate(PCTS):
        values=bootstrap[(bootstrap.Modality==mod)&bootstrap.Level.eq('Subtype')&(bootstrap.Completeness==pct)][metric].to_numpy()
        assert len(values)==2000
        stat=boxplot_stats(values,whis=1.5)[0]
        ax.bxp([stat],positions=[i],widths=[.40],patch_artist=True,manage_ticks=False,
               boxprops=dict(facecolor=color,edgecolor=color,alpha=.82,lw=.65),
               medianprops=dict(color='#24282B',lw=.65),whiskerprops=dict(color=color,lw=.6),
               capprops=dict(color=color,lw=.6),flierprops=dict(marker='.',markersize=.7,markerfacecolor=color,markeredgecolor='none',alpha=.3))
        point=points[(points.Modality==mod)&points.Model.eq('ARGScope')&points.Level.eq('Subtype')&(points.Completeness==pct)&points.Metric.eq(metric)].iloc[0].Point_estimate
        ax.scatter(i,point,marker='D',s=7,facecolor=color,edgecolor='white',lw=.3,zorder=5)
        extremes.extend([values.min(),values.max(),point])
    lo,hi=min(extremes),max(extremes)
    pad=max((hi-lo)*.07,.005)
    lower=max(0,np.floor((lo-pad)*20)/20);upper=min(1,np.ceil((hi+pad)*20)/20)
    if upper-lower<.06:lower=max(0,upper-.06)
    ax.set(xlim=(-.55,3.55),ylim=(lower-.003,upper+.003),xticks=range(4),xticklabels=[f'{p}%' for p in PCTS])
    ax.yaxis.set_major_locator(MaxNLocator(nbins=3,min_n_ticks=3))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_title(metric,fontsize=8.5,pad=4)
    base.clean(ax)


def type_overview():
    fig=base.canvas(320,190)
    legend(fig)
    for mod,top in [('protein',13),('dna',94)]:
        for j,pct in enumerate(PCTS):sector_chart(polar_mm(fig,3+79*j,top,77),mod,pct)
    descriptive_note(fig,183)
    base.save(fig,'Type_sector_bars_60_90_main')


def main_figure():
    fig=base.canvas(320,433)
    legend(fig)
    for mod,top in [('protein',13),('dna',94)]:
        for j,pct in enumerate(PCTS):sector_chart(polar_mm(fig,3+79*j,top,77),mod,pct)
    descriptive_note(fig,183)
    sm,_=net.network(base.ax_mm(fig,17,191,287,136),matrix,arcs,fontsize=6.8)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,307,226,2.4,56))
    cb.set_ticks([-1,-.5,0,.5,1]);cb.ax.tick_params(labelsize=6,length=2)
    cb.set_label('Profile correlation (ρ)',fontsize=7)
    for mod,top in [('protein',342),('dna',389)]:
        for j,metric in enumerate(METRICS):subtype_panel(base.ax_mm(fig,20+j*60,top,50,28),mod,metric)
        base.text_mm(fig,4,top+14,('Protein' if mod=='protein' else 'DNA')+' · Subtype',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,160,429,'Subtype: ARGScope only. Boxes: IQR; line: median; whiskers: 1.5 IQR; diamond: observed score.',ha='center',fontsize=7,color='#62686D')
    base.save(fig,'sector_bars_and_Type_network_main')


def standalone_network():
    fig=base.canvas(300,205)
    sm,_=net.network(base.ax_mm(fig,2,0,283,199),matrix,arcs,fontsize=7)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,285,57,2.4,75))
    cb.set_ticks([-1,-.5,0,.5,1]);cb.ax.tick_params(labelsize=7,length=2)
    cb.set_label('Profile correlation (ρ)',fontsize=7)
    assert all('puromycin' not in t.get_text().lower() for t in fig.findobj(matplotlib.text.Text))
    base.save(fig,'Type_network_without_Puromycin')


def single_charts():
    for mod in ['protein','dna']:
        for pct in PCTS:
            fig=base.canvas(128,139)
            sector_chart(polar_mm(fig,1,0,126),mod,pct,large=True)
            models=base.MODELS[mod]
            handles=[Patch(facecolor=base.COLORS[m],edgecolor='#5B6268',hatch='///' if m=='DeepARG' else None,label=f'{SHORT[m]} {m}') for m in models]
            fig.legend(handles=handles,loc='center',bbox_to_anchor=(.50,.067),ncol=len(models),frameon=False,fontsize=5.8,columnspacing=.9,handlelength=1.1)
            base.text_mm(fig,64,136,'Different cohorts; DeepARG: selected ARG hits only. Lines: parent-bootstrap 95% intervals.',ha='center',fontsize=5.1,color='#60676C')
            base.save(fig,f'{mod}_{pct}pct_sector_bars')


if __name__=='__main__':
    started=time.time()
    (ROOT/'render_status.json').write_text(json.dumps(dict(status='RUNNING',started=started)),encoding='utf-8')
    type_overview();main_figure();standalone_network();single_charts()
    pd.DataFrame(BAR_AUDIT).to_csv(DATA/'rendered_bar_values.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    (DATA/'input_hashes.json').write_text(json.dumps(HASHES,indent=2),encoding='utf-8')
    (ROOT/'figure_manifest.json').write_text(json.dumps(base.exports,indent=2),encoding='utf-8')
    (ROOT/'layout_validation.json').write_text(json.dumps(base.LAYOUT_QA,indent=2),encoding='utf-8')
    for p,h in HASHES.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
    (ROOT/'render_status.json').write_text(json.dumps(dict(status='COMPLETE',started=started,finished=time.time(),figure_directory=FIG.name,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())),encoding='utf-8')
    print(FIG,flush=True)
    print('PASS: 11 designs; original point estimates unchanged; Puromycin row/column/arcs removed.',flush=True)
