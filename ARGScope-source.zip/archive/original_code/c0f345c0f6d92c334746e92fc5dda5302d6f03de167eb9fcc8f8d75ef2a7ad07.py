# -*- coding: utf-8 -*-
"""
Calculate mean full length for each ARG subtype and type
from SARG nucleotide FASTA and SARG structure annotation file.

Input:
    1. Nucleotide_SARG_v3.2_Long.fasta
    2. Nucleotide_SARG_v3.2_Long_struct.txt / .csv / .tsv

Output:
    subtype_mean_full_length.csv
    type_mean_full_length.csv
    sequence_length_with_subtype.csv
"""

import os
import re
import pandas as pd


# =========================================================
# 1. CONFIG
# =========================================================

FASTA_FILE = "Nucleotide_SARG_v3.2_Long.fasta"

# 这里改成你的 struct 文件名
STRUCT_FILE = "Nucleotide_SARG_v3.2_Long_structure.txt"

OUT_SUBTYPE_LENGTH = "subtype_mean_full_length.csv"
OUT_TYPE_LENGTH = "type_mean_full_length.csv"
OUT_SEQ_LENGTH = "sequence_length_with_subtype.csv"


# =========================================================
# 2. READ FASTA AND CALCULATE SEQUENCE LENGTH
# =========================================================

def read_fasta_lengths(fasta_file):
    records = []

    current_header = None
    current_seq = []

    with open(fasta_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith(">"):
                if current_header is not None:
                    seq = "".join(current_seq).replace(" ", "").replace("\n", "")
                    records.append({
                        "Fasta_Header": current_header,
                        "Sequence_Length": len(seq)
                    })

                current_header = line[1:].strip()
                current_seq = []
            else:
                current_seq.append(line)

        if current_header is not None:
            seq = "".join(current_seq).replace(" ", "").replace("\n", "")
            records.append({
                "Fasta_Header": current_header,
                "Sequence_Length": len(seq)
            })

    df = pd.DataFrame(records)

    if df.empty:
        raise ValueError("No FASTA records found. Please check the FASTA file.")

    return df


def clean_label(x):
    if pd.isna(x):
        return ""
    s = str(x).strip()
    s = re.sub(r"\s+", " ", s)
    return s


def infer_type_from_subtype(subtype):
    """
    Infer ARG type from subtype label.

    Examples:
        multidrug__tolC -> multidrug
        beta_lactam__TEM-1 -> beta_lactam

    If no '__' exists, return Unknown.
    """
    s = clean_label(subtype)

    if "__" in s:
        return s.split("__", 1)[0].strip()

    return "Unknown"


fasta_df = read_fasta_lengths(FASTA_FILE)

print("[INFO] FASTA records:", fasta_df.shape[0])
print(fasta_df.head())


# =========================================================
# 3. EXTRACT ID FROM FASTA HEADER
# =========================================================
# FASTA header example:
# lcl|NZ_CP053218.1_cds_WP_000010637.1_1141
#
# struct file NucleotideID example:
# lcl|NZ_NIER01000015.1_cds_WP_00074171.1_22
#
# So here the whole header is used as NucleotideID.

fasta_df["NucleotideID"] = fasta_df["Fasta_Header"].astype(str).str.strip()


# =========================================================
# 4. READ STRUCT FILE
# =========================================================

def read_table_auto(file_path):
    """
    Automatically read csv/tsv/txt/xlsx-like table.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext in [".xlsx", ".xls"]:
        return pd.read_excel(file_path)

    try:
        df = pd.read_csv(file_path, sep="\t", dtype=str)
        if df.shape[1] > 1:
            return df
    except Exception:
        pass

    try:
        df = pd.read_csv(file_path, sep=",", dtype=str)
        if df.shape[1] > 1:
            return df
    except Exception:
        pass

    df = pd.read_csv(file_path, sep=r"\s+", engine="python", dtype=str)
    return df


struct_df = read_table_auto(STRUCT_FILE)

struct_df.columns = [str(c).strip() for c in struct_df.columns]

print("[INFO] Struct file shape:", struct_df.shape)
print("[INFO] Struct columns:")
print(struct_df.columns.tolist())


# =========================================================
# 5. CHECK REQUIRED COLUMNS
# =========================================================

required_cols = ["NucleotideID", "Subtype"]

missing = [c for c in required_cols if c not in struct_df.columns]
if missing:
    raise ValueError(
        f"Struct file missing columns: {missing}\n"
        f"Current columns are: {struct_df.columns.tolist()}"
    )

# 如果 struct 文件有 Type 列，直接读取；否则后面从 Subtype 推断
if "Type" in struct_df.columns:
    keep_cols = ["NucleotideID", "Type", "Subtype"]
else:
    keep_cols = ["NucleotideID", "Subtype"]

struct_df = struct_df[keep_cols].copy()

struct_df["NucleotideID"] = struct_df["NucleotideID"].astype(str).str.strip()
struct_df["Subtype"] = struct_df["Subtype"].apply(clean_label)

if "Type" in struct_df.columns:
    struct_df["Type"] = struct_df["Type"].apply(clean_label)
else:
    struct_df["Type"] = struct_df["Subtype"].apply(infer_type_from_subtype)

# 如果 Type 为空，也尝试从 Subtype 推断
empty_type_mask = (
    struct_df["Type"].isna()
    | (struct_df["Type"].astype(str).str.strip() == "")
    | (struct_df["Type"].astype(str).str.lower() == "nan")
    | (struct_df["Type"].astype(str).str.lower() == "unknown")
)

struct_df.loc[empty_type_mask, "Type"] = struct_df.loc[
    empty_type_mask, "Subtype"
].apply(infer_type_from_subtype)


# =========================================================
# 6. MERGE FASTA LENGTH WITH SUBTYPE AND TYPE
# =========================================================

merged = fasta_df.merge(
    struct_df,
    on="NucleotideID",
    how="left"
)

missing_subtype = merged["Subtype"].isna().sum()
missing_type = merged["Type"].isna().sum()

print("[INFO] Matched records:", merged.shape[0] - missing_subtype)
print("[INFO] Records without subtype:", missing_subtype)
print("[INFO] Records without type:", missing_type)

if missing_subtype > 0:
    print("[WARNING] Some FASTA records were not matched to subtype.")
    print(merged[merged["Subtype"].isna()].head(10))


# 只保留有 subtype 的序列
merged_valid = merged.dropna(subset=["Subtype"]).copy()

# 去除空 subtype
merged_valid = merged_valid[
    merged_valid["Subtype"].astype(str).str.len() > 0
].copy()

# 清理 Type
merged_valid["Type"] = merged_valid["Type"].apply(clean_label)
merged_valid["Type"] = merged_valid["Type"].replace("", "Unknown")


# =========================================================
# 7. CALCULATE MEAN FULL LENGTH PER SUBTYPE
# =========================================================

subtype_length = (
    merged_valid
    .groupby("Subtype", as_index=False)
    .agg(
        Type=("Type", lambda x: x.value_counts().index[0] if len(x.dropna()) > 0 else "Unknown"),
        Reference_sequence_count=("Sequence_Length", "count"),
        Mean_full_length=("Sequence_Length", "mean"),
        Median_full_length=("Sequence_Length", "median"),
        Min_full_length=("Sequence_Length", "min"),
        Max_full_length=("Sequence_Length", "max"),
        Sum_full_length=("Sequence_Length", "sum")
    )
)

subtype_length["Mean_full_length"] = subtype_length["Mean_full_length"].round(4)
subtype_length["Median_full_length"] = subtype_length["Median_full_length"].round(4)

subtype_length = subtype_length[
    [
        "Type",
        "Subtype",
        "Reference_sequence_count",
        "Mean_full_length",
        "Median_full_length",
        "Min_full_length",
        "Max_full_length",
        "Sum_full_length",
    ]
]

subtype_length = subtype_length.sort_values(
    ["Reference_sequence_count", "Type", "Subtype"],
    ascending=[False, True, True]
).reset_index(drop=True)


# =========================================================
# 8. CALCULATE MEAN FULL LENGTH PER TYPE
# =========================================================

type_length = (
    merged_valid
    .groupby("Type", as_index=False)
    .agg(
        Reference_sequence_count=("Sequence_Length", "count"),
        Subtype_count=("Subtype", "nunique"),
        Mean_full_length=("Sequence_Length", "mean"),
        Median_full_length=("Sequence_Length", "median"),
        Min_full_length=("Sequence_Length", "min"),
        Max_full_length=("Sequence_Length", "max"),
        Sum_full_length=("Sequence_Length", "sum")
    )
)

type_length["Mean_full_length"] = type_length["Mean_full_length"].round(4)
type_length["Median_full_length"] = type_length["Median_full_length"].round(4)

type_length = type_length.sort_values(
    ["Reference_sequence_count", "Type"],
    ascending=[False, True]
).reset_index(drop=True)


# =========================================================
# 9. SAVE OUTPUT
# =========================================================

merged_valid.to_csv(OUT_SEQ_LENGTH, index=False, encoding="utf-8-sig")
subtype_length.to_csv(OUT_SUBTYPE_LENGTH, index=False, encoding="utf-8-sig")
type_length.to_csv(OUT_TYPE_LENGTH, index=False, encoding="utf-8-sig")

print("\n[OK] Finished.")
print(f"[OK] Saved sequence-level file: {OUT_SEQ_LENGTH}")
print(f"[OK] Saved subtype-level file: {OUT_SUBTYPE_LENGTH}")
print(f"[OK] Saved type-level file: {OUT_TYPE_LENGTH}")

print("\n[Preview] subtype mean full length:")
print(subtype_length.head(20).to_string(index=False))

print("\n[Preview] type mean full length:")
print(type_length.head(20).to_string(index=False))