# -*- coding: utf-8 -*-
"""Apply the trained 150-nt DNA student to 90-nt and 120-nt embeddings.

The trained model was built with 50-aa/150-nt paired data, gated-fusion
teacher information and refined ARG subtype prototypes.  In this script,
inference uses DNA embeddings only:

    90-nt or 120-nt DNABERT-2 embedding -> DNA student -> ARG/nonARG -> Subtype

No confidence rejection or Unknown class is used.  Every record receives a
prediction and coverage is always 100%.  The ARG probability threshold saved
in the model checkpoint is reused without tuning on 90-nt or 120-nt data.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader, TensorDataset


SCRIPT_VERSION = (
    "2026-08-18-apply-ARG1-nonARG10-150nt-DNA-student-"
    "to-90nt-120nt-GPU-v1"
)
NONARG = "nonARG"
HERE = Path(__file__).resolve().parent

# =============================================================================
# ARG:nonARG = 1:10 model / embedding paths
# =============================================================================

DEFAULT_MODEL = (
    HERE
    / "DNA_student_ARG1_nonARG10_50aa_150nt_fusion_refined_precision_v2"
    / "DNA_student_fusion_refined_model.pt"
)

DEFAULT_REFERENCE_FUSION = (
    HERE
    / "Gated_fusion_ARG1_nonARG10_50aa_150nt_supervised"
    / "all_50aa_150nt_supervised_gated_fused_embeddings.pt"
)

DEFAULT_INPUT_ROOT = (
    HERE
    / "DNA_embedding"
)

DEFAULT_SIMULATION_ROOT = (
    HERE
    / "ARG1_nonARG10"
    / "paired_simulated_fragments_5parts"
)

DEFAULT_OUTPUT = (
    HERE
    / "DNA_student_ARG1_nonARG10_50aa_150nt_fusion_refined_precision_v2"
    / "apply_to_30aa_40aa_DNA"
)


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    dna_pt: Path
    structure: Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Apply the trained 150-nt DNA student to 90-nt and 120-nt PT files."
    )
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--reference-fusion", type=Path, default=DEFAULT_REFERENCE_FUSION)
    parser.add_argument(
        "--dna-90-pt",
        type=Path,
        default=(
            DEFAULT_INPUT_ROOT
            / "fixed_30aa_90nt"
            / "fixed_30aa_90nt_chunk_000001_dnabert2_CLS.pt"
        ),
    )
    parser.add_argument(
        "--dna-120-pt",
        type=Path,
        default=(
            DEFAULT_INPUT_ROOT
            / "fixed_40aa_120nt"
            / "fixed_40aa_120nt_chunk_000001_dnabert2_CLS.pt"
        ),
    )
    parser.add_argument(
        "--structure-90",
        type=Path,
        default=(
            DEFAULT_SIMULATION_ROOT
            / "fixed_30aa_90nt"
            / "structure_30aa_90nt_5parts.txt"
        ),
    )
    parser.add_argument(
        "--structure-120",
        type=Path,
        default=(
            DEFAULT_SIMULATION_ROOT
            / "fixed_40aa_120nt"
            / "structure_40aa_120nt_5parts.txt"
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def canonical_id(value: Any) -> str:
    return str(value).strip().split()[0]


def canonical_subtype(value: Any) -> str:
    text = str(value).strip()
    return NONARG if text.lower() == "nonarg" else text


def load_pt(path: Path) -> Any:
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def validate_input_files(args: argparse.Namespace) -> list[DatasetSpec]:
    datasets = [
        DatasetSpec("30aa_90nt", args.dna_90_pt, args.structure_90),
        DatasetSpec("40aa_120nt", args.dna_120_pt, args.structure_120),
    ]
    for path, description in (
        (args.model, "trained DNA student model"),
        (args.reference_fusion, "50aa reference fusion PT"),
        (args.dna_90_pt, "90nt DNA embedding PT"),
        (args.dna_120_pt, "120nt DNA embedding PT"),
        (args.structure_90, "30aa/90nt structure"),
        (args.structure_120, "40aa/120nt structure"),
    ):
        if not path.is_file():
            raise FileNotFoundError(f"{description} not found: {path}")
    if args.batch_size < 1 or args.num_workers < 0:
        raise ValueError("Batch size must be positive and num_workers cannot be negative")
    if args.output_dir.exists() and any(args.output_dir.iterdir()) and not args.overwrite:
        raise FileExistsError(
            f"Output directory is not empty: {args.output_dir}\n"
            "Use --overwrite to replace outputs made by this script."
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    return datasets


class CosineHead(nn.Module):
    def __init__(self, number_classes: int, dimension: int, scale: float):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(number_classes, dimension))
        nn.init.xavier_uniform_(self.weight)
        self.scale = float(scale)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.scale * F.linear(
            F.normalize(features, p=2, dim=1),
            F.normalize(self.weight, p=2, dim=1),
        )


class ResidualBlock(nn.Module):
    def __init__(self, dimension: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.gelu(x + self.net(x))


class DNAStudent(nn.Module):
    def __init__(
        self,
        dna_dimension: int,
        dna_mean: torch.Tensor,
        dna_std: torch.Tensor,
        number_arg_subtypes: int,
        hidden_dimension: int,
        embedding_dimension: int,
        dropout: float,
        binary_scale: float,
        subtype_scale: float,
    ):
        super().__init__()
        self.register_buffer("dna_mean", dna_mean.clone().float())
        self.register_buffer("dna_std", dna_std.clone().float())
        self.input = nn.Sequential(
            nn.Linear(dna_dimension, hidden_dimension),
            nn.LayerNorm(hidden_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(
            ResidualBlock(hidden_dimension, dropout),
            ResidualBlock(hidden_dimension, dropout),
        )
        self.output = nn.Sequential(
            nn.Linear(hidden_dimension, embedding_dimension),
            nn.LayerNorm(embedding_dimension),
        )
        self.binary_head = CosineHead(2, embedding_dimension, binary_scale)
        self.arg_head = CosineHead(number_arg_subtypes, embedding_dimension, subtype_scale)

    def encode(self, dna: torch.Tensor) -> torch.Tensor:
        dna = (dna - self.dna_mean) / self.dna_std
        hidden = self.blocks(self.input(dna))
        return F.normalize(self.output(hidden), p=2, dim=1)

    def forward(self, dna: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        features = self.encode(dna)
        return self.binary_head(features), self.arg_head(features), features


def load_model(
    checkpoint_path: Path,
    device: torch.device,
) -> tuple[DNAStudent, dict[str, Any], float]:
    checkpoint = load_pt(checkpoint_path)
    if not isinstance(checkpoint, dict):
        raise TypeError("Model checkpoint must contain a dictionary")
    required = {
        "student_state_dict",
        "dna_input_dimension",
        "embedding_dimension",
        "arg_subtype_names",
        "dna_train_mean",
        "dna_train_std",
        "configuration",
    }
    missing = sorted(required - set(checkpoint))
    if missing:
        raise KeyError(f"Model checkpoint is missing fields: {missing}")
    configuration = checkpoint["configuration"]
    arg_names = [canonical_subtype(value) for value in checkpoint["arg_subtype_names"]]
    dna_dimension = int(checkpoint["dna_input_dimension"])
    embedding_dimension = int(checkpoint["embedding_dimension"])
    model = DNAStudent(
        dna_dimension=dna_dimension,
        dna_mean=checkpoint["dna_train_mean"],
        dna_std=checkpoint["dna_train_std"],
        number_arg_subtypes=len(arg_names),
        hidden_dimension=int(configuration.get("hidden_dim", 1024)),
        embedding_dimension=embedding_dimension,
        dropout=float(configuration.get("dropout", 0.18)),
        binary_scale=float(configuration.get("logit_scale_binary", 16.0)),
        subtype_scale=float(configuration.get("logit_scale_subtype", 24.0)),
    )
    model.load_state_dict(checkpoint["student_state_dict"], strict=True)
    model.to(device).eval()
    threshold = float(checkpoint.get("selected_binary_ARG_probability_threshold", 0.50))
    if not 0.0 < threshold < 1.0:
        raise ValueError(f"Invalid saved binary threshold: {threshold}")
    return model, checkpoint, threshold


def load_embedding_pt(path: Path, expected_dimension: int) -> tuple[list[str], torch.Tensor]:
    obj = load_pt(path)
    if not isinstance(obj, dict):
        raise TypeError(f"Embedding PT must contain a dictionary: {path}")
    id_key = next((key for key in ("ids", "fragment_ids", "sequence_ids") if key in obj), None)
    embedding_key = next(
        (key for key in ("embeddings", "mean_embeddings", "features") if key in obj),
        None,
    )
    if id_key is None or embedding_key is None:
        raise KeyError(f"Embedding PT requires IDs and embeddings: keys={sorted(obj)}")
    ids = [canonical_id(value) for value in obj[id_key]]
    embeddings = obj[embedding_key]
    if not isinstance(embeddings, torch.Tensor) or embeddings.ndim != 2:
        raise ValueError(f"Embeddings must be a two-dimensional tensor: {path}")
    embeddings = embeddings.detach().cpu().float().contiguous()
    if tuple(embeddings.shape) != (len(ids), expected_dimension):
        raise ValueError(
            f"Unexpected embedding shape {tuple(embeddings.shape)} in {path}; "
            f"expected ({len(ids)}, {expected_dimension})"
        )
    if len(set(ids)) != len(ids):
        raise ValueError(f"Duplicate fragment IDs in {path}: {len(ids)-len(set(ids))}")
    if not bool(torch.isfinite(embeddings).all()):
        raise ValueError(f"NaN or Inf detected in embeddings: {path}")
    return ids, embeddings


def load_fragment_metadata(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames:
            raise ValueError(f"Structure file has no header: {path}")
        required = {"SARG.Seq.ID", "Subtype", "Type"}
        missing = sorted(required - set(reader.fieldnames))
        if missing:
            raise ValueError(f"Structure file is missing columns {missing}: {path}")
        original_column = (
            "Original.SARG.Seq.ID"
            if "Original.SARG.Seq.ID" in reader.fieldnames
            else None
        )
        rows: dict[str, dict[str, str]] = {}
        for line_number, raw in enumerate(reader, start=2):
            fragment_id = canonical_id(raw.get("SARG.Seq.ID", ""))
            original_id = canonical_id(raw.get(original_column, "")) if original_column else ""
            if not original_id and "__SIM_" in fragment_id:
                original_id = fragment_id.split("__SIM_", 1)[0]
            subtype = canonical_subtype(raw.get("Subtype", ""))
            type_name = str(raw.get("Type", "")).strip()
            if subtype.lower() == "nonarg":
                subtype = NONARG
                type_name = NONARG
            if not fragment_id or not original_id or not subtype or not type_name:
                raise ValueError(f"Incomplete metadata at line {line_number}: {path}")
            if fragment_id in rows:
                raise ValueError(f"Duplicate structure fragment ID: {fragment_id}")
            rows[fragment_id] = {
                "original_id": original_id,
                "subtype": subtype,
                "type": type_name,
            }
    if not rows:
        raise ValueError(f"No metadata rows found: {path}")
    return rows


def load_reference_splits(path: Path) -> dict[str, str]:
    obj = load_pt(path)
    if not isinstance(obj, dict) or "original_ids" not in obj or "model_splits" not in obj:
        raise KeyError("Reference fusion PT requires original_ids and model_splits")
    original_ids = [canonical_id(value) for value in obj["original_ids"]]
    splits = [str(value).strip().lower() for value in obj["model_splits"]]
    if len(original_ids) != len(splits):
        raise ValueError("Reference original_ids and model_splits have different lengths")
    result: dict[str, str] = {}
    for original_id, split in zip(original_ids, splits):
        if split not in {"train", "validation", "test"}:
            raise ValueError(f"Invalid reference split: {split}")
        if original_id in result and result[original_id] != split:
            raise ValueError(f"Conflicting reference split for {original_id}")
        result[original_id] = split
    return result


def amp_context(device: torch.device, use_amp: bool):
    return torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp)


@torch.no_grad()
def infer_fragments(
    model: DNAStudent,
    embeddings: torch.Tensor,
    batch_size: int,
    num_workers: int,
    device: torch.device,
    use_amp: bool,
) -> dict[str, torch.Tensor]:
    loader = DataLoader(
        TensorDataset(embeddings, torch.arange(embeddings.shape[0])),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=num_workers > 0,
    )
    binary_logits, subtype_logits, features, indices = [], [], [], []
    for batch, batch_indices in loader:
        batch = batch.to(device, non_blocking=True)
        with amp_context(device, use_amp):
            binary, subtype, encoded = model(batch)
        binary_logits.append(binary.float().cpu())
        subtype_logits.append(subtype.float().cpu())
        features.append(encoded.float().cpu())
        indices.append(batch_indices)
    return {
        "indices": torch.cat(indices),
        "binary_logits": torch.cat(binary_logits),
        "subtype_logits": torch.cat(subtype_logits),
        "features": torch.cat(features),
    }


@torch.no_grad()
def aggregate_originals(
    fragment_output: dict[str, torch.Tensor],
    original_ids: list[str],
    model: DNAStudent,
) -> tuple[dict[str, torch.Tensor], list[str], list[int]]:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, original_id in enumerate(original_ids):
        groups[original_id].append(index)
    ordered_originals = list(groups)
    means, representative_indices = [], []
    for original_id in ordered_originals:
        local = torch.tensor(groups[original_id], dtype=torch.long)
        feature = fragment_output["features"].index_select(0, local).mean(dim=0)
        means.append(F.normalize(feature, p=2, dim=0))
        representative_indices.append(groups[original_id][0])
    features = torch.stack(means)
    device = next(model.parameters()).device
    binary_logits = model.binary_head(features.to(device)).float().cpu()
    subtype_logits = model.arg_head(features.to(device)).float().cpu()
    return {
        "indices": torch.arange(len(ordered_originals)),
        "binary_logits": binary_logits,
        "subtype_logits": subtype_logits,
        "features": features,
    }, ordered_originals, representative_indices


def output_to_prediction_rows(
    output: dict[str, torch.Tensor],
    fragment_ids: list[str],
    original_ids: list[str],
    true_subtypes: list[str],
    true_types: list[str],
    splits: list[str],
    arg_names: list[str],
    subtype_to_type: dict[str, str],
    threshold: float,
    dataset: str,
    sequence_level: str,
) -> list[dict[str, Any]]:
    binary_probability = torch.softmax(output["binary_logits"], dim=1)[:, 1].numpy()
    subtype_probability_tensor = torch.softmax(output["subtype_logits"], dim=1)
    subtype_probability, subtype_indices = torch.max(subtype_probability_tensor, dim=1)
    subtype_probability = subtype_probability.numpy()
    subtype_indices = subtype_indices.numpy()
    predicted_binary = binary_probability >= threshold
    rows = []
    for index in range(len(original_ids)):
        arg_head_subtype = arg_names[int(subtype_indices[index])]
        predicted_subtype = arg_head_subtype if predicted_binary[index] else NONARG
        predicted_type = subtype_to_type[predicted_subtype]
        rows.append({
            "dataset": dataset,
            "sequence_level": sequence_level,
            "split": splits[index],
            "fragment_id": fragment_ids[index] if sequence_level == "fragment" else "",
            "original_id": original_ids[index],
            "true_subtype": true_subtypes[index],
            "predicted_subtype": predicted_subtype,
            "ARG_head_predicted_subtype": arg_head_subtype,
            "true_type": true_types[index],
            "predicted_type": predicted_type,
            "true_ARG": int(true_subtypes[index].lower() != "nonarg"),
            "predicted_ARG": int(predicted_binary[index]),
            "ARG_probability": float(binary_probability[index]),
            "ARG_subtype_max_probability": float(subtype_probability[index]),
            "binary_threshold": threshold,
            "coverage": 1.0,
        })
    return rows


def safe_mcc(true: np.ndarray, predicted: np.ndarray) -> float:
    if len(true) == 0 or len(np.unique(true)) < 2 or len(np.unique(predicted)) < 2:
        return 0.0
    return float(matthews_corrcoef(true, predicted))


def overall_metrics(true: list[str], predicted: list[str]) -> dict[str, Any]:
    true_array = np.asarray(true, dtype=object)
    predicted_array = np.asarray(predicted, dtype=object)
    return {
        "n": int(len(true_array)),
        "accuracy": float(accuracy_score(true_array, predicted_array)),
        "macro_precision": float(
            precision_score(true_array, predicted_array, average="macro", zero_division=0)
        ),
        "weighted_precision": float(
            precision_score(true_array, predicted_array, average="weighted", zero_division=0)
        ),
        "macro_recall": float(
            recall_score(true_array, predicted_array, average="macro", zero_division=0)
        ),
        "weighted_recall": float(
            recall_score(true_array, predicted_array, average="weighted", zero_division=0)
        ),
        "macro_f1": float(f1_score(true_array, predicted_array, average="macro", zero_division=0)),
        "weighted_f1": float(
            f1_score(true_array, predicted_array, average="weighted", zero_division=0)
        ),
        "mcc": safe_mcc(true_array, predicted_array),
        "coverage": 1.0,
    }


def one_vs_rest_metrics(
    true: list[str],
    predicted: list[str],
    class_names: list[str],
    class_column: str,
    dataset: str,
    split: str,
    sequence_level: str,
) -> list[dict[str, Any]]:
    true_array = np.asarray(true, dtype=object)
    predicted_array = np.asarray(predicted, dtype=object)
    number = len(true_array)
    rows = []
    for class_name in class_names:
        true_mask = true_array == class_name
        predicted_mask = predicted_array == class_name
        tp = int(np.sum(true_mask & predicted_mask))
        fp = int(np.sum(~true_mask & predicted_mask))
        fn = int(np.sum(true_mask & ~predicted_mask))
        tn = int(number - tp - fp - fn)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
        rows.append({
            class_column: class_name,
            "dataset": dataset,
            "split": split,
            "sequence_level": sequence_level,
            "ACC": (tp + tn) / number if number else 0.0,
            "Precision": precision,
            "Recall": recall,
            "F1": f1,
            "MCC": safe_mcc(true_mask.astype(np.int64), predicted_mask.astype(np.int64)),
            "support": tp + fn,
            "predicted_count": tp + fp,
            "correct_count": tp,
            "wrong_count": fp + fn,
            "TP": tp,
            "FP": fp,
            "FN": fn,
            "TN": tn,
            "total_samples": number,
            "coverage": 1.0,
        })
    return rows


def evaluate_prediction_rows(
    rows: list[dict[str, Any]],
    arg_names: list[str],
    type_names: list[str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    overall_rows, subtype_rows, type_rows, binary_rows = [], [], [], []
    dataset = rows[0]["dataset"]
    sequence_level = rows[0]["sequence_level"]
    for split in ("train", "validation", "test", "not_in_50aa_reference"):
        selected = [row for row in rows if row["split"] == split]
        if not selected:
            continue
        true_subtype = [row["true_subtype"] for row in selected]
        predicted_subtype = [row["predicted_subtype"] for row in selected]
        true_type = [row["true_type"] for row in selected]
        predicted_type = [row["predicted_type"] for row in selected]
        true_binary = ["ARG" if row["true_ARG"] else NONARG for row in selected]
        predicted_binary = ["ARG" if row["predicted_ARG"] else NONARG for row in selected]

        arg_selected = [row for row in selected if row["true_ARG"]]
        arg_true_subtype = [row["true_subtype"] for row in arg_selected]
        # Oracle-binary subtype prediction is the ARG head's prediction.  The
        # closed end-to-end prediction remains in prediction CSV and subtype
        # per-class metrics below.
        arg_predicted_subtype = []
        arg_oracle_predicted_subtype = []
        for row in arg_selected:
            arg_oracle_predicted_subtype.append(row["ARG_head_predicted_subtype"])
            if row["predicted_ARG"]:
                arg_predicted_subtype.append(row["predicted_subtype"])
            else:
                # A nonARG gate error remains an error in end-to-end subtype
                # evaluation; it is not silently removed.
                arg_predicted_subtype.append(NONARG)

        for task, true_values, predicted_values in (
            ("ARG_nonARG", true_binary, predicted_binary),
            ("ARG_subtype_oracle_binary", arg_true_subtype, arg_oracle_predicted_subtype),
            ("ARG_subtype_end_to_end", arg_true_subtype, arg_predicted_subtype),
            ("Type_end_to_end", true_type, predicted_type),
            ("end_to_end_ARG_nonARG_plus_subtype", true_subtype, predicted_subtype),
        ):
            values = overall_metrics(true_values, predicted_values)
            overall_rows.append({
                "dataset": dataset,
                "split": split,
                "sequence_level": sequence_level,
                "task": task,
                **values,
            })
        subtype_rows.extend(
            one_vs_rest_metrics(
                true_subtype,
                predicted_subtype,
                arg_names,
                "Subtype",
                dataset,
                split,
                sequence_level,
            )
        )
        type_rows.extend(
            one_vs_rest_metrics(
                true_type,
                predicted_type,
                type_names,
                "Type",
                dataset,
                split,
                sequence_level,
            )
        )
        binary_rows.extend(
            one_vs_rest_metrics(
                true_binary,
                predicted_binary,
                ["ARG", NONARG],
                "Class",
                dataset,
                split,
                sequence_level,
            )
        )
    return overall_rows, subtype_rows, type_rows, binary_rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fieldnames, seen = [], set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def process_dataset(
    spec: DatasetSpec,
    model: DNAStudent,
    checkpoint: dict[str, Any],
    threshold: float,
    reference_splits: dict[str, str],
    args: argparse.Namespace,
    device: torch.device,
    use_amp: bool,
) -> dict[str, Any]:
    print("\n" + "=" * 115, flush=True)
    print(f"DATASET: {spec.name}", flush=True)
    print("=" * 115, flush=True)
    print(f"DNA PT     : {spec.dna_pt}", flush=True)
    print(f"Structure  : {spec.structure}", flush=True)
    ids, embeddings = load_embedding_pt(
        spec.dna_pt,
        int(checkpoint["dna_input_dimension"]),
    )

    print(
        f"Embedding shape : {tuple(embeddings.shape)}",
        flush=True,
    )

    print(
        f"GPU memory before inference: "
        f"allocated={torch.cuda.memory_allocated(0)/(1024**3):.3f} GiB | "
        f"reserved={torch.cuda.memory_reserved(0)/(1024**3):.3f} GiB",
        flush=True,
    )

    metadata = load_fragment_metadata(spec.structure)
    missing_metadata = [fragment_id for fragment_id in ids if fragment_id not in metadata]
    if missing_metadata:
        raise ValueError(
            f"{len(missing_metadata)} embedding IDs have no structure metadata; "
            f"examples={missing_metadata[:10]}"
        )

    original_ids = [metadata[value]["original_id"] for value in ids]
    true_subtypes = [metadata[value]["subtype"] for value in ids]
    true_types = [metadata[value]["type"] for value in ids]
    splits = [reference_splits.get(value, "not_in_50aa_reference") for value in original_ids]
    arg_names = [canonical_subtype(value) for value in checkpoint["arg_subtype_names"]]
    unknown_true_subtypes = sorted(set(true_subtypes) - (set(arg_names) | {NONARG}))
    if unknown_true_subtypes:
        raise ValueError(f"True subtypes absent from model classes: {unknown_true_subtypes[:10]}")
    subtype_to_type: dict[str, str] = {NONARG: NONARG}
    for subtype, type_name in zip(true_subtypes, true_types):
        if subtype in subtype_to_type and subtype_to_type[subtype] != type_name:
            raise ValueError(f"Subtype maps to multiple Types: {subtype}")
        subtype_to_type[subtype] = type_name
    missing_prediction_types = sorted(set(arg_names) - set(subtype_to_type))
    if missing_prediction_types:
        raise ValueError(
            f"Model subtype classes missing Type mappings: {missing_prediction_types[:10]}"
        )
    type_names = sorted(
        {subtype_to_type[value] for value in arg_names}, key=lambda value: value.lower()
    )

    fragment_output = infer_fragments(
        model,
        embeddings,
        args.batch_size,
        args.num_workers,
        device,
        use_amp,
    )
    fragment_rows = output_to_prediction_rows(
        fragment_output,
        ids,
        original_ids,
        true_subtypes,
        true_types,
        splits,
        arg_names,
        subtype_to_type,
        threshold,
        spec.name,
        "fragment",
    )

    original_output, ordered_originals, representative_indices = aggregate_originals(
        fragment_output, original_ids, model
    )
    original_rows = output_to_prediction_rows(
        original_output,
        [""] * len(ordered_originals),
        ordered_originals,
        [true_subtypes[index] for index in representative_indices],
        [true_types[index] for index in representative_indices],
        [splits[index] for index in representative_indices],
        arg_names,
        subtype_to_type,
        threshold,
        spec.name,
        "original",
    )
    # Explicit consistency audit across the five fragments of every original.
    labels_by_original: dict[str, set[tuple[str, str, str]]] = defaultdict(set)
    for original_id, subtype, type_name, split in zip(
        original_ids, true_subtypes, true_types, splits
    ):
        labels_by_original[original_id].add((subtype, type_name, split))
    inconsistent = [key for key, values in labels_by_original.items() if len(values) != 1]
    if inconsistent:
        raise ValueError(f"Inconsistent labels/splits within original IDs: {inconsistent[:10]}")

    overall_fragment, subtype_fragment, type_fragment, binary_fragment = evaluate_prediction_rows(
        fragment_rows, arg_names, type_names
    )
    overall_original, subtype_original, type_original, binary_original = evaluate_prediction_rows(
        original_rows, arg_names, type_names
    )
    output_dir = args.output_dir / spec.name
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "fragment_predictions.csv", fragment_rows)
    write_csv(output_dir / "original_predictions.csv", original_rows)
    write_csv(output_dir / "overall_metrics.csv", overall_fragment + overall_original)
    write_csv(output_dir / "subtype_level_metrics.csv", subtype_fragment + subtype_original)
    write_csv(output_dir / "type_level_metrics.csv", type_fragment + type_original)
    write_csv(output_dir / "ARG_nonARG_level_metrics.csv", binary_fragment + binary_original)

    test_original = [
        row
        for row in overall_original
        if row["split"] == "test" and row["task"] == "ARG_subtype_oracle_binary"
    ]
    if test_original:
        row = test_original[0]
        print(
            f"TEST original subtype (oracle binary) | n={row['n']:,} | "
            f"ACC={row['accuracy']:.6f} | "
            f"weighted_precision={row['weighted_precision']:.6f} | "
            f"weighted_F1={row['weighted_f1']:.6f} | MCC={row['mcc']:.6f}",
            flush=True,
        )
    print(f"Fragments              : {len(ids):,}", flush=True)
    print(f"Originals              : {len(ordered_originals):,}", flush=True)
    print(
        f"Not in 50aa reference  : "
        f"{len({original_ids[i] for i, split in enumerate(splits) if split == 'not_in_50aa_reference'}):,}",
        flush=True,
    )
    print(f"Output                 : {output_dir}", flush=True)
    print(
        f"GPU memory after inference : "
        f"allocated={torch.cuda.memory_allocated(0)/(1024**3):.3f} GiB | "
        f"reserved={torch.cuda.memory_reserved(0)/(1024**3):.3f} GiB",
        flush=True,
    )

    torch.cuda.empty_cache()

    return {
        "dataset": spec.name,
        "fragment_count": len(ids),
        "original_count": len(ordered_originals),
        "overall_rows": overall_fragment + overall_original,
    }


def main() -> None:
    args = parse_args()
    datasets = validate_input_files(args)
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA GPU is unavailable. "
            "CPU fallback is disabled for this ARGScope inference script."
        )

    device = torch.device("cuda:0")
    use_amp = not args.no_amp

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    model, checkpoint, threshold = load_model(
        args.model,
        device,
    )
    reference_splits = load_reference_splits(args.reference_fusion)

    print("=" * 115, flush=True)
    print(
        "Apply ARG1:nonARG10 150-nt DNA student to "
        "90-nt and 120-nt DNABERT-2 CLS embeddings",
        flush=True,
    )
    print("=" * 115, flush=True)
    print(f"Script version    : {SCRIPT_VERSION}", flush=True)
    print(f"Model             : {args.model}", flush=True)
    print(f"Reference fusion  : {args.reference_fusion}", flush=True)
    print(f"Output directory  : {args.output_dir}", flush=True)
    print("Training ratio    : ARG:nonARG = 1:10", flush=True)
    print("DNA embedding     : DNABERT-2 first_token_CLS, 768D", flush=True)
    print(f"Device            : {device}", flush=True)
    print(f"GPU               : {torch.cuda.get_device_name(0)}", flush=True)
    print(f"CUDA version      : {torch.version.cuda}", flush=True)
    print(f"AMP               : {use_amp}", flush=True)
    print("CPU fallback      : disabled", flush=True)
    print(
        f"GPU total memory  : "
        f"{torch.cuda.get_device_properties(0).total_memory/(1024**3):.2f} GiB",
        flush=True,
    )
    print(f"DNA input dim     : {checkpoint['dna_input_dimension']}", flush=True)
    print(f"ARG subtype count : {len(checkpoint['arg_subtype_names'])}", flush=True)
    print(f"Saved ARG threshold: {threshold:.8f}", flush=True)

    summaries = []
    combined_overall = []
    for spec in datasets:
        result = process_dataset(
            spec,
            model,
            checkpoint,
            threshold,
            reference_splits,
            args,
            device,
            use_amp,
        )
        summaries.append({
            "dataset": result["dataset"],
            "fragment_count": result["fragment_count"],
            "original_count": result["original_count"],
            "binary_threshold": threshold,
            "coverage": 1.0,
        })
        combined_overall.extend(result["overall_rows"])
    write_csv(args.output_dir / "30aa_40aa_dataset_summary.csv", summaries)
    write_csv(args.output_dir / "30aa_40aa_overall_metrics.csv", combined_overall)
    with (args.output_dir / "run_configuration.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "script_version": SCRIPT_VERSION,
                "training_ARG_nonARG_ratio": "1:10",
                "DNA_embedding_definition": (
                    "DNABERT-2-117M native BPE; first_token_CLS; "
                    "768 dimensions; max_token_length=512"
                ),
                "model": str(args.model),
                "reference_fusion": str(args.reference_fusion),
                "saved_binary_threshold": threshold,
                "datasets": [
                    {"name": spec.name, "dna_pt": str(spec.dna_pt), "structure": str(spec.structure)}
                    for spec in datasets
                ],
                "coverage_policy": "all records classified; no rejection or Unknown",
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    print("\n" + "=" * 115, flush=True)
    print("INFERENCE COMPLETED", flush=True)
    print("=" * 115, flush=True)
    print(
        f"Combined metrics: "
        f"{args.output_dir / '30aa_40aa_overall_metrics.csv'}",
        flush=True,
    )
    print(
        f"Peak GPU memory : "
        f"{torch.cuda.max_memory_allocated(0)/(1024**3):.3f} GiB",
        flush=True,
    )


if __name__ == "__main__":
    main()
