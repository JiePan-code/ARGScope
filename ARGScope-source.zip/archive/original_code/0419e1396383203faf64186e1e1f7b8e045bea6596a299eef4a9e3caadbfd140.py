#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope multi-length Protein student
Clean multi-panel UMAP for Windows

Key points
----------
1. Does NOT change UMAP parameters.
2. Does NOT change existing Type colors.
3. Uses one shared UMAP fit for all epochs.
4. Uses composite sample ID = length_name + KEY.
5. Layout only:
   - row 1: 4 panels
   - row 2: 3 panels, centered
   - row 3: full-width legend
6. macrolide-lincosamide-streptogramin is displayed as MLS.
"""

from pathlib import Path
import re
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpec
from sklearn.preprocessing import LabelEncoder

try:
    import umap
except ImportError as e:
    raise ImportError(
        "Please install umap-learn first:\n"
        "pip install umap-learn"
    ) from e


# =============================================================================
# 1. Paths
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent
INPUT_DIR = ROOT_DIR / "UMAP_embeddings"

# Read the previous color mapping from this folder if it exists.
# This is the safest way to guarantee that colors do not change.
OLD_OUTPUT_DIR = ROOT_DIR / "UMAP_figures_windows"

OUTPUT_DIR = ROOT_DIR / "UMAP_figures_windows_clean"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SUBTYPE_TYPE_MAP = ROOT_DIR / "subtype_type_map.csv"


# =============================================================================
# 2. UMAP settings
#    These are intentionally kept the same as the previous plotting script.
# =============================================================================

USE_SUPERVISED_UMAP = False
TARGET_WEIGHT = 0.04
RANDOM_STATE = 42

UMAP_PARAMS = dict(
    n_neighbors=18,
    min_dist=0.90,
    spread=3.20,
    metric="cosine",
    random_state=RANDOM_STATE,
)

# Keep these identical if you want the exact same point appearance.
POINT_SIZE = 5
POINT_ALPHA = 0.62
POINT_LINEWIDTH = 0.0
EDGE_COLOR = "none"

SAVE_DPI = 600


# =============================================================================
# 3. Figure layout
# =============================================================================

FIG_WIDTH = 17.2
FIG_HEIGHT = 10.2

PANEL_TITLE_SIZE = 11.5
AXIS_LABEL_SIZE = 10.5
MAIN_TITLE_SIZE = 15.0

# Legend has its own dedicated row, so it will never overlap panels.
LEGEND_NCOL = 6
LEGEND_FONT_SIZE = 8.2
LEGEND_MARKER_SIZE = 5.6

SHOW_MAIN_TITLE = True
MAIN_TITLE = "UMAP of Protein-student representations colored by ARG type"

# Use one global x/y range for every epoch panel.
GLOBAL_AXIS_PADDING = 0.035


# =============================================================================
# 4. Original color palette
#    Do not change.
# =============================================================================

TYPE_COLOR_LIST = [
    "#E64B35", "#1F78B4", "#00A087", "#3C5488", "#F39B7F",
    "#7E6148", "#4DBBD5", "#D00000", "#B09C85", "#91D1C2",
    "#A6CEE3", "#FF7F00", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDB462", "#6A3D9A", "#CAB2D6", "#B15928",
    "#F0E442", "#8C510A", "#80CDC1", "#35978F", "#F781BF",
    "#377EB8", "#FFB000", "#66A61E", "#E7298A", "#984EA3",
    "#A6DBA0",
]


DISPLAY_NAME_MAP = {
    "macrolide-lincosamide-streptogramin": "MLS",
}


# =============================================================================
# 5. Matplotlib style
# =============================================================================

warnings.filterwarnings("ignore", category=UserWarning)

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "axes.titlesize": PANEL_TITLE_SIZE,
    "axes.labelsize": AXIS_LABEL_SIZE,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": LEGEND_FONT_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 6. Snapshot discovery
# =============================================================================

def parse_snapshot_file(path: Path):
    name = path.name

    m = re.fullmatch(r"student_embedding_epoch_(\d+)\.csv", name)
    if m:
        epoch = int(m.group(1))
        return {
            "path": path,
            "epoch": epoch,
            "is_best": False,
            "title": f"Epoch {epoch}",
            "sort_key": (epoch, 0),
        }

    m = re.fullmatch(r"student_embedding_best_epoch_(\d+)\.csv", name)
    if m:
        epoch = int(m.group(1))
        return {
            "path": path,
            "epoch": epoch,
            "is_best": True,
            "title": f"Best model (epoch {epoch})",
            # Put best model after regular epoch panels.
            "sort_key": (10**9, epoch),
        }

    return None


def discover_snapshots():
    if not INPUT_DIR.is_dir():
        raise FileNotFoundError(f"UMAP embedding folder not found: {INPUT_DIR}")

    infos = []

    for path in INPUT_DIR.glob("student_embedding_*.csv"):
        info = parse_snapshot_file(path)
        if info is not None:
            infos.append(info)

    if not infos:
        raise FileNotFoundError(
            f"No student_embedding_epoch_*.csv files found in:\n{INPUT_DIR}"
        )

    infos.sort(key=lambda x: x["sort_key"])

    print("\n[Discovered snapshots]")
    for x in infos:
        print(
            f"  {x['path'].name} | "
            f"title={x['title']} | best={x['is_best']}"
        )

    return infos


# =============================================================================
# 7. Column helpers
# =============================================================================

def find_first_column(df, candidates, required=True):
    lower_map = {str(c).strip().casefold(): c for c in df.columns}

    for candidate in candidates:
        c = lower_map.get(str(candidate).casefold())
        if c is not None:
            return c

    if required:
        raise ValueError(
            f"Cannot find one of columns {candidates}. "
            f"Existing columns={df.columns.tolist()}"
        )

    return None


def numeric_embed_columns(df):
    cols = [c for c in df.columns if str(c).startswith("embed_")]

    def num_key(c):
        try:
            return int(str(c).split("_")[-1])
        except Exception:
            return 10**9

    return sorted(cols, key=num_key)


# =============================================================================
# 8. Load snapshot
# =============================================================================

def load_one_snapshot(info):
    path = info["path"]
    df = pd.read_csv(path, low_memory=False)

    key_col = find_first_column(df, ["KEY", "key"])
    length_col = find_first_column(
        df,
        ["length_name", "Length", "length"],
        required=False,
    )
    type_col = find_first_column(
        df,
        ["True_Type", "Type", "true_Type", "true_type"],
    )
    subtype_col = find_first_column(
        df,
        ["True_Subtype", "Subtype", "true_Subtype", "true_subtype"],
        required=False,
    )

    if length_col is None:
        raise ValueError(
            f"{path.name} has no length_name column. "
            "Multi-length snapshots need length_name + KEY as the unique sample ID."
        )

    embed_cols = numeric_embed_columns(df)
    if not embed_cols:
        raise ValueError(f"No embed_* columns found in {path.name}")

    df["__KEY__"] = df[key_col].astype(str).str.strip()
    df["__LENGTH__"] = df[length_col].astype(str).str.strip()
    df["__TYPE__"] = df[type_col].astype(str).str.strip()

    if subtype_col is not None:
        df["__SUBTYPE__"] = df[subtype_col].astype(str).str.strip()
    else:
        df["__SUBTYPE__"] = ""

    # Correct unique ID for this multi-length dataset.
    df["__SAMPLE_ID__"] = (
        df["__LENGTH__"].astype(str)
        + "|||"
        + df["__KEY__"].astype(str)
    )

    dup_mask = df["__SAMPLE_ID__"].duplicated(keep=False)
    if dup_mask.any():
        dup = df.loc[dup_mask, "__SAMPLE_ID__"].head(20).tolist()
        raise ValueError(
            f"Duplicated composite sample IDs in {path.name}: {dup}"
        )

    X = (
        df[embed_cols]
        .apply(pd.to_numeric, errors="coerce")
        .to_numpy(dtype=np.float32)
    )

    if not np.isfinite(X).all():
        raise ValueError(f"{path.name}: embed_* contains NaN/Inf")

    print(
        f"[Loaded] {path.name}: "
        f"N={len(df):,}, dim={X.shape[1]}, "
        f"Types={df['__TYPE__'].nunique()}, "
        f"Lengths={df['__LENGTH__'].nunique()}"
    )

    return {
        **info,
        "df": df,
        "X": X,
        "embed_cols": embed_cols,
    }


# =============================================================================
# 9. Align all snapshots to exactly the same samples
# =============================================================================

def align_snapshots(snapshots):
    common_ids = set(snapshots[0]["df"]["__SAMPLE_ID__"])

    for s in snapshots[1:]:
        common_ids &= set(s["df"]["__SAMPLE_ID__"])

    if not common_ids:
        raise ValueError("No common samples across epoch snapshots.")

    # Preserve the first snapshot's row order.
    first_ids = snapshots[0]["df"]["__SAMPLE_ID__"].tolist()
    ordered_common = [x for x in first_ids if x in common_ids]

    print(
        f"\n[Alignment] common samples across all snapshots: "
        f"{len(ordered_common):,}"
    )

    aligned = []

    for s in snapshots:
        df = s["df"].set_index("__SAMPLE_ID__", drop=False).loc[ordered_common].copy()

        embed_cols = s["embed_cols"]
        X = df[embed_cols].to_numpy(dtype=np.float32)

        new_s = dict(s)
        new_s["df"] = df.reset_index(drop=True)
        new_s["X"] = X
        aligned.append(new_s)

    # Verify metadata are identical across all snapshots.
    ref = aligned[0]["df"][["__SAMPLE_ID__", "__TYPE__", "__LENGTH__"]].copy()

    for s in aligned[1:]:
        cur = s["df"][["__SAMPLE_ID__", "__TYPE__", "__LENGTH__"]].copy()
        if not ref.equals(cur):
            raise ValueError(
                f"Sample metadata are inconsistent across snapshots: "
                f"{s['path'].name}"
            )

    return aligned


# =============================================================================
# 10. Type order and color mapping
# =============================================================================

def read_full_type_order():
    if SUBTYPE_TYPE_MAP.is_file():
        mapping = pd.read_csv(SUBTYPE_TYPE_MAP, low_memory=False)
        type_col = find_first_column(mapping, ["Type", "type"])

        vals = (
            mapping[type_col]
            .dropna()
            .astype(str)
            .str.strip()
            .drop_duplicates()
            .tolist()
        )

        # Stable alphabetical order, matching the previous plotting behavior.
        vals = sorted(vals)

        print(f"[Type map] full Type count from subtype_type_map.csv: {len(vals)}")
        return vals

    print("[Warning] subtype_type_map.csv not found. "
          "Using Types detected from snapshots.")
    return None


def try_load_existing_color_mapping():
    candidates = [
        OLD_OUTPUT_DIR / "type_color_mapping.csv",
        ROOT_DIR / "type_color_mapping.csv",
    ]

    for path in candidates:
        if not path.is_file():
            continue

        try:
            df = pd.read_csv(path, low_memory=False)

            raw_col = None
            color_col = None

            for c in ["raw_type", "True_Type", "Type", "type"]:
                if c in df.columns:
                    raw_col = c
                    break

            for c in ["color", "Color"]:
                if c in df.columns:
                    color_col = c
                    break

            if raw_col is None or color_col is None:
                continue

            mapping = dict(
                zip(
                    df[raw_col].astype(str),
                    df[color_col].astype(str),
                )
            )

            if mapping:
                print(f"[Colors] Loaded existing color mapping: {path}")
                return mapping
        except Exception:
            pass

    return None


def build_color_mapping(snapshots):
    detected = sorted(
        pd.concat(
            [s["df"]["__TYPE__"] for s in snapshots],
            ignore_index=True,
        )
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    full_order = read_full_type_order()

    if full_order is None:
        full_order = detected

    # Include any detected label absent from subtype_type_map.csv.
    for x in detected:
        if x not in full_order:
            full_order.append(x)

    existing_map = try_load_existing_color_mapping()

    color_map = {}

    if existing_map is not None:
        # Preserve old colors exactly.
        for label in full_order:
            if label in existing_map:
                color_map[label] = existing_map[label]

    # Fill only genuinely missing color definitions.
    unused_colors = [
        c for c in TYPE_COLOR_LIST
        if c not in set(color_map.values())
    ]

    for label in full_order:
        if label not in color_map:
            if unused_colors:
                color_map[label] = unused_colors.pop(0)
            else:
                # Fallback only if >31 labels.
                cmap = plt.get_cmap("turbo")
                color_map[label] = mpl.colors.to_hex(
                    cmap(len(color_map) / max(1, len(full_order) - 1))
                )

    present = set(detected)
    missing = [x for x in full_order if x not in present]

    print(f"[Types] present in snapshots: {len(present)}")
    print(f"[Types] legend total: {len(full_order)}")

    if missing:
        print("[Types absent from current snapshots]")
        for x in missing:
            print("  -", x)

    out = pd.DataFrame({
        "raw_type": full_order,
        "display_type": [
            DISPLAY_NAME_MAP.get(x, x) for x in full_order
        ],
        "color": [color_map[x] for x in full_order],
        "present_in_snapshot": [x in present for x in full_order],
    })

    out.to_csv(
        OUTPUT_DIR / "type_color_mapping.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return full_order, color_map


# =============================================================================
# 11. Shared UMAP
# =============================================================================

def encode_labels(labels):
    le = LabelEncoder()
    return le.fit_transform(np.asarray(labels).astype(str)).astype(np.int32)


def compute_shared_umap(snapshots):
    print("\n[Shared UMAP]")
    print(f"  supervised = {USE_SUPERVISED_UMAP}")
    print(f"  params     = {UMAP_PARAMS}")

    blocks = [s["X"] for s in snapshots]
    X_all = np.vstack(blocks)

    print(f"  combined matrix = {X_all.shape}")

    reducer = umap.UMAP(
        **UMAP_PARAMS,
        target_metric="categorical" if USE_SUPERVISED_UMAP else "euclidean",
        target_weight=TARGET_WEIGHT if USE_SUPERVISED_UMAP else 0.0,
    )

    if USE_SUPERVISED_UMAP:
        labels = np.concatenate([
            s["df"]["__TYPE__"].astype(str).to_numpy()
            for s in snapshots
        ])
        Z_all = reducer.fit_transform(X_all, y=encode_labels(labels))
    else:
        Z_all = reducer.fit_transform(X_all)

    cursor = 0

    for s in snapshots:
        n = len(s["df"])
        s["Z"] = Z_all[cursor:cursor + n]
        cursor += n

    return snapshots


# =============================================================================
# 12. Axis range
# =============================================================================

def global_axis_limits(snapshots):
    Z = np.vstack([s["Z"] for s in snapshots])

    xmin, xmax = float(Z[:, 0].min()), float(Z[:, 0].max())
    ymin, ymax = float(Z[:, 1].min()), float(Z[:, 1].max())

    x_range = xmax - xmin
    y_range = ymax - ymin

    x_pad = max(x_range * GLOBAL_AXIS_PADDING, 1e-6)
    y_pad = max(y_range * GLOBAL_AXIS_PADDING, 1e-6)

    return (
        xmin - x_pad,
        xmax + x_pad,
        ymin - y_pad,
        ymax + y_pad,
    )


# =============================================================================
# 13. Plot helpers
# =============================================================================

def style_axis(ax, limits, show_ylabel=True):
    xmin, xmax, ymin, ymax = limits

    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)

    ax.set_xticks([])
    ax.set_yticks([])

    ax.set_xlabel("UMAP1", labelpad=1.5)

    if show_ylabel:
        ax.set_ylabel("UMAP2", labelpad=1.5)
    else:
        ax.set_ylabel("")

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)
        spine.set_color("black")


def plot_snapshot(ax, snapshot, color_map, limits, show_ylabel):
    df = snapshot["df"]
    Z = snapshot["Z"]
    labels = df["__TYPE__"].astype(str).to_numpy()

    # Large classes first, rare classes last.
    counts = pd.Series(labels).value_counts(ascending=False)

    for label in counts.index:
        mask = labels == label

        ax.scatter(
            Z[mask, 0],
            Z[mask, 1],
            s=POINT_SIZE,
            c=color_map[label],
            alpha=POINT_ALPHA,
            linewidths=POINT_LINEWIDTH,
            edgecolors=EDGE_COLOR,
            rasterized=True,
        )

    style_axis(ax, limits, show_ylabel=show_ylabel)

    if snapshot["is_best"]:
        ax.set_title(
            snapshot["title"],
            fontweight="bold",
            pad=5,
        )
    else:
        ax.set_title(
            snapshot["title"],
            fontweight="normal",
            pad=5,
        )


def make_legend_handles(type_order, color_map):
    handles = []

    for raw_name in type_order:
        display_name = DISPLAY_NAME_MAP.get(raw_name, raw_name)

        handles.append(
            Line2D(
                [0],
                [0],
                linestyle="none",
                marker="o",
                markerfacecolor=color_map[raw_name],
                markeredgecolor="none",
                markersize=LEGEND_MARKER_SIZE,
                label=display_name,
            )
        )

    return handles


# =============================================================================
# 14. Clean multi-panel layout
# =============================================================================

def plot_clean_multipanel(snapshots, type_order, color_map):
    n = len(snapshots)

    if n > 7:
        raise ValueError(
            f"This clean layout is designed for <=7 snapshots, found {n}. "
            "Adjust GridSpec if more epochs are needed."
        )

    limits = global_axis_limits(snapshots)

    fig = plt.figure(
        figsize=(FIG_WIDTH, FIG_HEIGHT),
        dpi=SAVE_DPI,
        constrained_layout=False,
    )

    # 8 virtual columns:
    # top row:
    # [0:2] [2:4] [4:6] [6:8]
    #
    # second row centered:
    #   [1:3] [3:5] [5:7]
    #
    # third row:
    # legend full width
    gs = GridSpec(
        nrows=3,
        ncols=8,
        figure=fig,
        height_ratios=[1.0, 1.0, 0.50],
        hspace=0.28,
        wspace=0.32,
        left=0.045,
        right=0.985,
        top=0.900,
        bottom=0.045,
    )

    panel_slots = [
        (0, slice(0, 2)),
        (0, slice(2, 4)),
        (0, slice(4, 6)),
        (0, slice(6, 8)),
        (1, slice(1, 3)),
        (1, slice(3, 5)),
        (1, slice(5, 7)),
    ]

    axes = []

    for i, snapshot in enumerate(snapshots):
        row, col_slice = panel_slots[i]
        ax = fig.add_subplot(gs[row, col_slice])
        axes.append(ax)

        # Show UMAP2 only on the first panel of each data row.
        show_ylabel = i in (0, 4)

        plot_snapshot(
            ax=ax,
            snapshot=snapshot,
            color_map=color_map,
            limits=limits,
            show_ylabel=show_ylabel,
        )

    # Dedicated legend area.
    legend_ax = fig.add_subplot(gs[2, :])
    legend_ax.axis("off")

    handles = make_legend_handles(type_order, color_map)
    labels = [DISPLAY_NAME_MAP.get(x, x) for x in type_order]

    legend_ax.legend(
        handles=handles,
        labels=labels,
        loc="center",
        ncol=LEGEND_NCOL,
        frameon=False,
        fontsize=LEGEND_FONT_SIZE,
        handlelength=0.8,
        handletextpad=0.30,
        columnspacing=1.25,
        labelspacing=0.65,
        borderaxespad=0.0,
        markerscale=1.0,
    )

    if SHOW_MAIN_TITLE:
        fig.suptitle(
            MAIN_TITLE,
            fontsize=MAIN_TITLE_SIZE,
            y=0.965,
            fontweight="normal",
        )

    out_png = OUTPUT_DIR / "umap_ARG_type_epochs_multipanel_clean.png"
    out_pdf = OUTPUT_DIR / "umap_ARG_type_epochs_multipanel_clean.pdf"
    out_svg = OUTPUT_DIR / "umap_ARG_type_epochs_multipanel_clean.svg"

    fig.savefig(
        out_png,
        dpi=SAVE_DPI,
        bbox_inches="tight",
        pad_inches=0.08,
    )
    fig.savefig(
        out_pdf,
        bbox_inches="tight",
        pad_inches=0.08,
    )
    fig.savefig(
        out_svg,
        bbox_inches="tight",
        pad_inches=0.08,
    )

    plt.close(fig)

    print(f"[Saved] {out_png}")
    print(f"[Saved] {out_pdf}")
    print(f"[Saved] {out_svg}")


# =============================================================================
# 15. Best-model figure
# =============================================================================

def plot_best_model(snapshots, type_order, color_map):
    best = [s for s in snapshots if s["is_best"]]

    if not best:
        return

    snapshot = best[-1]
    limits = global_axis_limits(snapshots)

    fig = plt.figure(
        figsize=(8.2, 7.6),
        dpi=SAVE_DPI,
        constrained_layout=False,
    )

    gs = GridSpec(
        nrows=2,
        ncols=1,
        figure=fig,
        height_ratios=[1.0, 0.48],
        left=0.11,
        right=0.97,
        top=0.92,
        bottom=0.06,
        hspace=0.16,
    )

    ax = fig.add_subplot(gs[0, 0])

    plot_snapshot(
        ax=ax,
        snapshot=snapshot,
        color_map=color_map,
        limits=limits,
        show_ylabel=True,
    )

    legend_ax = fig.add_subplot(gs[1, 0])
    legend_ax.axis("off")

    handles = make_legend_handles(type_order, color_map)
    labels = [DISPLAY_NAME_MAP.get(x, x) for x in type_order]

    legend_ax.legend(
        handles=handles,
        labels=labels,
        loc="center",
        ncol=4,
        frameon=False,
        fontsize=7.5,
        handlelength=0.8,
        handletextpad=0.30,
        columnspacing=1.10,
        labelspacing=0.55,
        borderaxespad=0.0,
    )

    out_png = OUTPUT_DIR / "umap_ARG_type_best_model_clean.png"
    out_pdf = OUTPUT_DIR / "umap_ARG_type_best_model_clean.pdf"

    fig.savefig(
        out_png,
        dpi=SAVE_DPI,
        bbox_inches="tight",
        pad_inches=0.08,
    )
    fig.savefig(
        out_pdf,
        bbox_inches="tight",
        pad_inches=0.08,
    )
    plt.close(fig)

    print(f"[Saved] {out_png}")
    print(f"[Saved] {out_pdf}")


# =============================================================================
# 16. Save coordinates
# =============================================================================

def save_coordinates(snapshots):
    all_parts = []

    for s in snapshots:
        df = s["df"].copy()

        keep_cols = [
            c for c in df.columns
            if not c.startswith("embed_")
            and not c.startswith("__")
        ]

        out = df[keep_cols].copy()

        out.insert(0, "snapshot_title", s["title"])
        out.insert(1, "snapshot_epoch", s["epoch"])
        out.insert(2, "is_best", s["is_best"])
        out["UMAP1"] = s["Z"][:, 0]
        out["UMAP2"] = s["Z"][:, 1]

        safe_name = (
            f"best_epoch_{s['epoch']:03d}"
            if s["is_best"]
            else f"epoch_{s['epoch']:03d}"
        )

        out.to_csv(
            OUTPUT_DIR / f"umap_coordinates_{safe_name}.csv",
            index=False,
            encoding="utf-8-sig",
        )

        all_parts.append(out)

    pd.concat(all_parts, ignore_index=True).to_csv(
        OUTPUT_DIR / "umap_coordinates_all_snapshots.csv",
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# 17. Main
# =============================================================================

def main():
    print("=" * 80)
    print("ARGScope multi-length Protein student: clean UMAP plotting")
    print("=" * 80)
    print(f"ROOT_DIR   = {ROOT_DIR}")
    print(f"INPUT_DIR  = {INPUT_DIR}")
    print(f"OUTPUT_DIR = {OUTPUT_DIR}")

    snapshot_infos = discover_snapshots()
    snapshots = [load_one_snapshot(info) for info in snapshot_infos]

    snapshots = align_snapshots(snapshots)

    type_order, color_map = build_color_mapping(snapshots)

    snapshots = compute_shared_umap(snapshots)

    save_coordinates(snapshots)

    plot_clean_multipanel(
        snapshots=snapshots,
        type_order=type_order,
        color_map=color_map,
    )

    plot_best_model(
        snapshots=snapshots,
        type_order=type_order,
        color_map=color_map,
    )

    print("\nDone.")
    print(f"Results saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":
    main()
