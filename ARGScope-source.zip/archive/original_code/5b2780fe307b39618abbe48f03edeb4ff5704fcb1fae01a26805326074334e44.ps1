$ErrorActionPreference='Stop'
$taskWord=$null
$taskDocument=$null
$taskDirectory=$PSScriptRoot
try {
    $taskWord=New-Object -ComObject Word.Application
    $taskWord.Visible=$false
    $taskWord.DisplayAlerts=0
    $taskDocument=$taskWord.Documents.Open((Join-Path $taskDirectory 'Supplementary_materials_recalculated.docx'),$false,$true)
    $taskDocument.ExportAsFixedFormat((Join-Path $taskDirectory 'document_qa\Supplementary_materials_recalculated.pdf'),17)
    Write-Output 'Read-only Word PDF export succeeded.'
} finally {
    if ($null -ne $taskDocument) { $taskDocument.Close(0) }
    if ($null -ne $taskWord) { $taskWord.Quit() }
}
