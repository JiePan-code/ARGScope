#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Run independent DIAMOND blastx searches at identity 0.5 and 0.8 on all original
*_all_reads.fasta files.

Console output is intentionally compact:
- one line when each DIAMOND task starts;
- one heartbeat line every N seconds;
- one line when each task finishes;
- overall completed-task percentage and approximate ETA.

DIAMOND itself is still called for every sample and every threshold.

Default work layout:
    merged_fasta/
        run_local_diamond_05_to_09_all_reads_progress.py
        diamond.exe
        3.SARG_v3.2_20220917_Long_subdatabase.fasta
        argbert_1_all_reads.fasta
        argbert_2_all_reads.fasta
        argbert_3_all_reads.fasta
        argscope_1_all_reads.fasta
        ...
        argscope_6_all_reads.fasta

Default thresholds:
    diamond0.5 = identity >= 50%
    diamond0.8 = identity >= 80%

Default filters:
    query coverage       >= 75%
    alignment length     >= 25 aa
    e-value              <= 1e-7
    max target sequences = 50
    max HSPs             = 1
    sensitivity          = very-sensitive

For 9 samples and 2 thresholds, the script performs 18 independent
diamond.exe blastx runs on the complete original FASTA files.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Iterable, Sequence


PIPELINE_VERSION = "local_diamond_all_reads_add_0.5_0.8_progress_v1"

PROTEIN_REFERENCE_NAME = "3.SARG_v3.2_20220917_Long_subdatabase.fasta"
DEFAULT_PATTERN = "*_all_reads.fasta"
DEFAULT_OUTPUT_NAME = "DIAMOND_all_reads_separate_0.2_0.6_0.7_0.9_results"

DIAMOND_FIELDS = [
    "qseqid",
    "sseqid",
    "pident",
    "length",
    "mismatch",
    "gapopen",
    "qstart",
    "qend",
    "sstart",
    "send",
    "evalue",
    "bitscore",
    "qlen",
    "slen",
    "qcovhsp",
]

BEST_HIT_HEADER = [
    "sample",
    "threshold_label",
    "identity_threshold_pct",
    *DIAMOND_FIELDS,
]


class PipelineError(RuntimeError):
    pass


def log(message: str) -> None:
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}", flush=True)


def format_command(command: Sequence[str]) -> str:
    return " ".join(shlex.quote(str(part)) for part in command)


def format_duration(seconds: float | None) -> str:
    if seconds is None or seconds < 0:
        return "NA"

    seconds = int(round(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    if hours > 0:
        return f"{hours}h {minutes:02d}m {seconds:02d}s"
    if minutes > 0:
        return f"{minutes}m {seconds:02d}s"
    return f"{seconds}s"


def format_size(num_bytes: int) -> str:
    value = float(num_bytes)
    units = ["B", "KB", "MB", "GB", "TB"]

    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            return f"{value:.1f} {unit}"
        value /= 1024.0

    return f"{num_bytes} B"


def open_text_auto(path: Path, mode: str):
    if path.name.lower().endswith(".gz"):
        return gzip.open(path, mode, encoding="utf-8", newline="")
    return path.open(mode, encoding="utf-8", newline="")


def resolve_diamond(requested: str | None, script_dir: Path) -> str:
    candidates: list[str] = []

    if requested:
        candidates.append(requested)

    env_value = os.environ.get("DIAMOND_EXE", "").strip()
    if env_value:
        candidates.append(env_value)

    candidates.extend([
        str(script_dir / "diamond.exe"),
        str(script_dir / "diamond"),
        "diamond.exe",
        "diamond",
    ])

    checked: set[str] = set()

    for item in candidates:
        if not item or item in checked:
            continue
        checked.add(item)

        resolved = shutil.which(item)
        if resolved:
            return str(Path(resolved).resolve())

        candidate = Path(item)
        if candidate.is_file():
            return str(candidate.resolve())

    raise PipelineError(
        "DIAMOND executable was not found. Put diamond.exe beside this script, "
        "set DIAMOND_EXE, or use --diamond PATH."
    )


def validate_protein_fasta(path: Path, max_letters: int = 5000) -> None:
    if not path.is_file():
        raise PipelineError(f"Protein reference FASTA not found: {path}")

    letters: list[str] = []

    with open_text_auto(path, "rt") as handle:
        for line in handle:
            if not line or line.startswith(">"):
                continue

            letters.extend(
                character
                for character in line.strip().upper()
                if character.isalpha() or character == "*"
            )

            if len(letters) >= max_letters:
                break

    if not letters:
        raise PipelineError(f"No sequence letters found in reference: {path}")

    examined = letters[:max_letters]
    nucleotide_like = sum(
        character in {"A", "C", "G", "T", "U", "N"}
        for character in examined
    )

    if nucleotide_like / len(examined) >= 0.97:
        raise PipelineError(
            "The reference appears to be nucleotide FASTA, not protein FASTA: "
            f"{path}"
        )


def strip_sequence_suffix(filename: str) -> str:
    lower = filename.lower()

    for suffix in (
        ".fasta.gz",
        ".fastq.gz",
        ".fna.gz",
        ".fa.gz",
        ".fq.gz",
        ".fasta",
        ".fastq",
        ".fna",
        ".fa",
        ".fq",
    ):
        if lower.endswith(suffix):
            filename = filename[: -len(suffix)]
            break

    if filename.endswith("_all_reads"):
        filename = filename[: -len("_all_reads")]

    return filename


def discover_samples(
    input_dir: Path,
    pattern: str,
    selected: set[str],
) -> list[Path]:
    samples = sorted(
        path
        for path in input_dir.glob(pattern)
        if path.is_file()
    )

    if selected:
        lookup: dict[str, Path] = {}

        for path in samples:
            lookup[path.name] = path
            lookup[strip_sequence_suffix(path.name)] = path

        missing = [
            name
            for name in sorted(selected)
            if name not in lookup
        ]

        if missing:
            raise PipelineError(
                "Requested sample(s) not found: " + ", ".join(missing)
            )

        samples = sorted({lookup[name] for name in selected})

    if not samples:
        raise PipelineError(f"No FASTA matched: {input_dir / pattern}")

    return samples


def parse_thresholds(text: str) -> list[tuple[str, float]]:
    percentages: list[float] = []

    for token in text.split(","):
        token = token.strip()

        if not token:
            continue

        value = float(token)
        percentage = value * 100.0 if 0 < value <= 1 else value

        if not (0 < percentage <= 100):
            raise PipelineError(f"Invalid identity threshold: {token}")

        percentages.append(percentage)

    percentages = sorted(set(percentages))

    if not percentages:
        raise PipelineError("No identity thresholds were supplied")

    return [
        (f"diamond{percentage / 100.0:.1f}", percentage)
        for percentage in percentages
    ]


def run_quiet_command(command: Sequence[str], log_file: Path) -> None:
    log_file.parent.mkdir(parents=True, exist_ok=True)

    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(
            f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] "
            f"$ {format_command(command)}\n"
        )
        handle.flush()

        completed = subprocess.run(
            [str(part) for part in command],
            stdout=handle,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )

    if completed.returncode != 0:
        raise PipelineError(
            f"Command failed with exit code {completed.returncode}. "
            f"See log: {log_file}"
        )


def run_diamond_with_heartbeat(
    command: Sequence[str],
    log_file: Path,
    output_file: Path,
    heartbeat_seconds: int,
    run_index: int,
    total_runs: int,
    completed_durations: list[float],
    sample: str,
    threshold_label: str,
) -> float:
    """
    Run DIAMOND silently, while printing only periodic coarse progress.
    DIAMOND stdout/stderr is written to a per-run log file.
    """
    log_file.parent.mkdir(parents=True, exist_ok=True)

    start = time.time()

    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(
            f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] "
            f"$ {format_command(command)}\n"
        )
        handle.flush()

        process = subprocess.Popen(
            [str(part) for part in command],
            stdout=handle,
            stderr=subprocess.STDOUT,
            text=True,
        )

        while True:
            return_code = process.poll()

            if return_code is not None:
                break

            time.sleep(heartbeat_seconds)

            elapsed = time.time() - start
            current_size = (
                output_file.stat().st_size
                if output_file.exists()
                else 0
            )

            completed_before_current = run_index - 1

            if completed_durations:
                average_completed = (
                    sum(completed_durations)
                    / len(completed_durations)
                )
                remaining_runs_after_current = total_runs - run_index
                approximate_eta = (
                    max(average_completed - elapsed, 0.0)
                    + remaining_runs_after_current * average_completed
                )
            else:
                approximate_eta = None

            overall_percent = (
                completed_before_current / total_runs * 100.0
                if total_runs > 0
                else 0.0
            )

            log(
                "[PROGRESS] "
                f"run={run_index}/{total_runs} | "
                f"overall_completed={overall_percent:.1f}% | "
                f"sample={sample} | threshold={threshold_label} | "
                f"current_elapsed={format_duration(elapsed)} | "
                f"current_output={format_size(current_size)} | "
                f"approx_remaining={format_duration(approximate_eta)}"
            )

    elapsed = time.time() - start

    if return_code != 0:
        raise PipelineError(
            f"DIAMOND failed with exit code {return_code}. "
            f"See log: {log_file}"
        )

    return elapsed


def build_database(
    diamond: str,
    protein_fasta: Path,
    output_root: Path,
    threads: int,
    overwrite: bool,
) -> Path:
    database_prefix = output_root / "db" / "SARG_v3.2_Long_protein"
    database_file = Path(str(database_prefix) + ".dmnd")
    database_prefix.parent.mkdir(parents=True, exist_ok=True)

    if (
        database_file.exists()
        and not overwrite
        and database_file.stat().st_size > 0
        and database_file.stat().st_mtime_ns
        >= protein_fasta.stat().st_mtime_ns
    ):
        log(f"Reusing DIAMOND database: {database_file}")
        return database_prefix

    temporary_prefix = Path(str(database_prefix) + ".building")
    temporary_database = Path(str(temporary_prefix) + ".dmnd")
    temporary_database.unlink(missing_ok=True)

    command = [
        diamond,
        "makedb",
        "--in",
        str(protein_fasta),
        "--db",
        str(temporary_prefix),
        "--threads",
        str(threads),
    ]

    log("Building DIAMOND database")
    run_quiet_command(
        command,
        output_root / "logs" / "makedb.log",
    )

    if (
        not temporary_database.exists()
        or temporary_database.stat().st_size == 0
    ):
        raise PipelineError(
            f"DIAMOND database was not created: {temporary_database}"
        )

    os.replace(temporary_database, database_file)
    log(f"DIAMOND database ready: {database_file}")

    return database_prefix


def wrap_sequence(sequence: str, width: int = 80) -> Iterable[str]:
    for start in range(0, len(sequence), width):
        yield sequence[start : start + width]


def read_best_hits(
    raw_hits: Path,
    threshold_pct: float,
    minimum_alignment_aa: int,
    minimum_query_cover: float,
    maximum_evalue: float,
) -> tuple[dict[str, list[str]], int, int]:
    best_hits: dict[str, list[str]] = {}
    best_scores: dict[str, tuple[float, float, float]] = {}

    raw_rows = 0
    eligible_rows = 0

    with gzip.open(
        raw_hits,
        "rt",
        encoding="utf-8",
        newline="",
    ) as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.rstrip("\r\n")

            if not line:
                continue

            fields = line.split("\t")

            if len(fields) != len(DIAMOND_FIELDS):
                raise PipelineError(
                    f"Unexpected DIAMOND column count in {raw_hits}, "
                    f"line {line_number}: "
                    f"expected {len(DIAMOND_FIELDS)}, "
                    f"observed {len(fields)}"
                )

            raw_rows += 1

            try:
                pident = float(fields[2])
                alignment_length = int(float(fields[3]))
                evalue = float(fields[10])
                bitscore = float(fields[11])
                query_coverage = float(fields[14])
            except ValueError as exc:
                raise PipelineError(
                    f"Invalid numeric field in {raw_hits}, "
                    f"line {line_number}"
                ) from exc

            if pident < threshold_pct:
                continue
            if alignment_length < minimum_alignment_aa:
                continue
            if query_coverage < minimum_query_cover:
                continue
            if evalue > maximum_evalue:
                continue

            eligible_rows += 1
            query_id = fields[0]
            score = (bitscore, pident, -evalue)

            if (
                query_id not in best_scores
                or score > best_scores[query_id]
            ):
                best_scores[query_id] = score
                best_hits[query_id] = fields

    return best_hits, raw_rows, eligible_rows


def write_best_hits_and_ids(
    best_hits: dict[str, list[str]],
    sample: str,
    threshold_label: str,
    threshold_pct: float,
    best_hits_file: Path,
    ids_file: Path,
) -> None:
    best_hits_file.parent.mkdir(parents=True, exist_ok=True)
    ids_file.parent.mkdir(parents=True, exist_ok=True)

    temporary_best = best_hits_file.with_name(
        best_hits_file.name + ".tmp.gz"
    )
    temporary_ids = ids_file.with_name(
        ids_file.name + ".tmp"
    )

    temporary_best.unlink(missing_ok=True)
    temporary_ids.unlink(missing_ok=True)

    ordered_ids = sorted(best_hits)

    with gzip.open(
        temporary_best,
        "wt",
        encoding="utf-8",
        newline="",
    ) as hit_handle, temporary_ids.open(
        "wt",
        encoding="utf-8",
        newline="",
    ) as id_handle:
        writer = csv.writer(
            hit_handle,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writerow(BEST_HIT_HEADER)

        for query_id in ordered_ids:
            writer.writerow([
                sample,
                threshold_label,
                threshold_pct,
                *best_hits[query_id],
            ])
            id_handle.write(query_id + "\n")

    os.replace(temporary_best, best_hits_file)
    os.replace(temporary_ids, ids_file)


def extract_candidate_fasta(
    input_fasta: Path,
    candidate_ids: set[str],
    output_fasta: Path,
) -> tuple[int, int]:
    output_fasta.parent.mkdir(parents=True, exist_ok=True)

    temporary = output_fasta.with_name(
        output_fasta.name + ".tmp"
    )
    temporary.unlink(missing_ok=True)

    total_records = 0
    written_records = 0

    def flush_record(
        handle,
        header: str | None,
        sequence_parts: list[str],
        keep: bool,
    ) -> None:
        nonlocal written_records

        if header is None or not keep:
            return

        handle.write(header + "\n")
        sequence = "".join(sequence_parts)

        for chunk in wrap_sequence(sequence):
            handle.write(chunk + "\n")

        written_records += 1

    with open_text_auto(
        input_fasta,
        "rt",
    ) as source, temporary.open(
        "wt",
        encoding="utf-8",
        newline="",
    ) as target:
        current_header: str | None = None
        current_sequence: list[str] = []
        keep = False

        for line in source:
            if line.startswith(">"):
                flush_record(
                    target,
                    current_header,
                    current_sequence,
                    keep,
                )

                total_records += 1
                current_header = line.rstrip("\r\n")
                read_id = current_header[1:].strip().split()[0]
                keep = read_id in candidate_ids
                current_sequence = []
            else:
                current_sequence.append(line.strip())

        flush_record(
            target,
            current_header,
            current_sequence,
            keep,
        )

    os.replace(temporary, output_fasta)

    return total_records, written_records


def write_json_atomic(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    temporary = path.with_name(path.name + ".tmp")

    with temporary.open("wt", encoding="utf-8") as handle:
        json.dump(
            payload,
            handle,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
        )
        handle.write("\n")

    os.replace(temporary, path)


def build_run_signature(
    query: Path,
    protein_fasta: Path,
    database_file: Path,
    threshold_pct: float,
    args: argparse.Namespace,
) -> dict:
    return {
        "pipeline_version": PIPELINE_VERSION,
        "query": str(query.resolve()),
        "query_size": query.stat().st_size,
        "query_mtime_ns": query.stat().st_mtime_ns,
        "protein_fasta": str(protein_fasta.resolve()),
        "protein_size": protein_fasta.stat().st_size,
        "protein_mtime_ns": protein_fasta.stat().st_mtime_ns,
        "database_file": str(database_file.resolve()),
        "database_size": database_file.stat().st_size,
        "database_mtime_ns": database_file.stat().st_mtime_ns,
        "identity_pct": threshold_pct,
        "query_cover_pct": args.query_cover,
        "minimum_alignment_aa": args.min_align_aa,
        "evalue": str(args.evalue),
        "max_target_seqs": args.max_target_seqs,
        "max_hsps": args.max_hsps,
        "min_orf": args.min_orf,
        "sensitivity": args.sensitivity,
        "block_size": args.block_size,
    }


def process_one_task(
    diamond: str,
    database_prefix: Path,
    protein_fasta: Path,
    query: Path,
    sample: str,
    threshold_label: str,
    threshold_pct: float,
    output_root: Path,
    args: argparse.Namespace,
    run_index: int,
    total_runs: int,
    completed_durations: list[float],
) -> tuple[dict, bool, float]:
    threshold_dir = output_root / threshold_label

    raw_hits = (
        threshold_dir
        / "raw_hits"
        / f"{sample}_{threshold_label}_raw.tsv.gz"
    )
    best_hits_file = (
        threshold_dir
        / "best_hits"
        / f"{sample}_{threshold_label}_best_hits.tsv.gz"
    )
    ids_file = (
        threshold_dir
        / "candidate_ids"
        / f"{sample}_{threshold_label}_candidate_ids.txt"
    )
    candidate_fasta = (
        threshold_dir
        / "candidate_reads"
        / f"{sample}_{threshold_label}_candidate_reads.fasta"
    )
    done_file = threshold_dir / "done" / f"{sample}.json"
    run_log = (
        threshold_dir
        / "logs"
        / f"{sample}_{threshold_label}.log"
    )
    temporary_dir = (
        output_root
        / "tmp"
        / threshold_label
        / sample
    )
    temporary_dir.mkdir(parents=True, exist_ok=True)

    database_file = Path(str(database_prefix) + ".dmnd")

    current_signature = build_run_signature(
        query=query,
        protein_fasta=protein_fasta,
        database_file=database_file,
        threshold_pct=threshold_pct,
        args=args,
    )

    required_outputs = [
        raw_hits,
        best_hits_file,
        ids_file,
        candidate_fasta,
        done_file,
    ]

    if (
        not args.overwrite
        and all(path.exists() for path in required_outputs)
    ):
        try:
            with done_file.open("rt", encoding="utf-8") as handle:
                previous = json.load(handle)

            if all(
                previous.get(key) == value
                for key, value in current_signature.items()
            ):
                log(
                    f"[SKIP {run_index}/{total_runs}] "
                    f"{sample} {threshold_label} already complete"
                )
                previous_duration = float(
                    previous.get("elapsed_seconds", 0.0)
                )
                return previous, True, previous_duration

        except (OSError, json.JSONDecodeError):
            pass

    if args.overwrite:
        for path in required_outputs:
            path.unlink(missing_ok=True)

    raw_hits.parent.mkdir(parents=True, exist_ok=True)

    temporary_raw_hits = raw_hits.with_name(
        raw_hits.name + ".tmp.gz"
    )
    temporary_raw_hits.unlink(missing_ok=True)

    command = [
        diamond,
        "blastx",
        "--query",
        str(query),
        "--db",
        str(database_prefix),
        "--out",
        str(temporary_raw_hits),
        "--outfmt",
        "6",
        *DIAMOND_FIELDS,
        "--evalue",
        str(args.evalue),
        "--id",
        f"{threshold_pct:g}",
        "--query-cover",
        f"{args.query_cover:g}",
        "--max-target-seqs",
        str(args.max_target_seqs),
        "--max-hsps",
        str(args.max_hsps),
        "--min-orf",
        str(args.min_orf),
        "--threads",
        str(args.threads),
        "--block-size",
        str(args.block_size),
        "--tmpdir",
        str(temporary_dir),
        "--compress",
        "1",
    ]

    if args.sensitivity != "default":
        command.append(f"--{args.sensitivity}")

    log(
        f"[START {run_index}/{total_runs}] "
        f"{sample} {threshold_label} | "
        f"DIAMOND blastx | all original reads | "
        f"identity>={threshold_pct:g}%"
    )

    elapsed = run_diamond_with_heartbeat(
        command=command,
        log_file=run_log,
        output_file=temporary_raw_hits,
        heartbeat_seconds=args.heartbeat_seconds,
        run_index=run_index,
        total_runs=total_runs,
        completed_durations=completed_durations,
        sample=sample,
        threshold_label=threshold_label,
    )

    if not temporary_raw_hits.exists():
        raise PipelineError(
            f"DIAMOND output was not created: {temporary_raw_hits}"
        )

    os.replace(temporary_raw_hits, raw_hits)

    log(
        f"[POSTPROCESS {run_index}/{total_runs}] "
        f"{sample} {threshold_label} | "
        "selecting best hits and extracting FASTA"
    )

    best_hits, raw_rows, eligible_rows = read_best_hits(
        raw_hits=raw_hits,
        threshold_pct=threshold_pct,
        minimum_alignment_aa=args.min_align_aa,
        minimum_query_cover=args.query_cover,
        maximum_evalue=float(args.evalue),
    )

    write_best_hits_and_ids(
        best_hits=best_hits,
        sample=sample,
        threshold_label=threshold_label,
        threshold_pct=threshold_pct,
        best_hits_file=best_hits_file,
        ids_file=ids_file,
    )

    total_reads, written_reads = extract_candidate_fasta(
        input_fasta=query,
        candidate_ids=set(best_hits),
        output_fasta=candidate_fasta,
    )

    if written_reads != len(best_hits):
        raise PipelineError(
            f"Candidate ID/FASTA mismatch for {sample} {threshold_label}: "
            f"IDs={len(best_hits)}, FASTA={written_reads}"
        )

    result = {
        **current_signature,
        "sample": sample,
        "threshold_label": threshold_label,
        "input_reads": total_reads,
        "raw_hit_rows": raw_rows,
        "eligible_hit_rows_after_all_filters": eligible_rows,
        "candidate_read_ids": len(best_hits),
        "written_candidate_reads": written_reads,
        "candidate_rate": (
            len(best_hits) / total_reads
            if total_reads > 0
            else 0.0
        ),
        "elapsed_seconds": round(elapsed, 3),
        "raw_hits": str(raw_hits.resolve()),
        "best_hits": str(best_hits_file.resolve()),
        "candidate_ids": str(ids_file.resolve()),
        "candidate_fasta": str(candidate_fasta.resolve()),
        "log_file": str(run_log.resolve()),
    }

    write_json_atomic(done_file, result)

    completed_after = run_index
    overall_percent = (
        completed_after / total_runs * 100.0
        if total_runs > 0
        else 100.0
    )

    duration_pool = completed_durations + [elapsed]
    average_duration = sum(duration_pool) / len(duration_pool)
    remaining_tasks = total_runs - completed_after
    approximate_remaining = remaining_tasks * average_duration

    log(
        f"[DONE {run_index}/{total_runs}] "
        f"{sample} {threshold_label} | "
        f"candidates={written_reads:,}/{total_reads:,} | "
        f"task_time={format_duration(elapsed)} | "
        f"overall={overall_percent:.1f}% | "
        f"approx_remaining={format_duration(approximate_remaining)}"
    )

    return result, False, elapsed


def load_all_done_results(output_root: Path) -> list[dict]:
    rows: list[dict] = []

    for path in sorted(
        output_root.glob("diamond*/done/*.json")
    ):
        try:
            with path.open("rt", encoding="utf-8") as handle:
                rows.append(json.load(handle))
        except (OSError, json.JSONDecodeError):
            continue

    return rows


def write_summaries(output_root: Path) -> None:
    rows = load_all_done_results(output_root)

    if not rows:
        return

    long_file = (
        output_root
        / "diamond_0.2_0.5_0.6_0.7_0.8_0.9_all_reads_long_summary.tsv"
    )
    columns = [
        "sample",
        "threshold_label",
        "identity_pct",
        "input_reads",
        "raw_hit_rows",
        "eligible_hit_rows_after_all_filters",
        "candidate_read_ids",
        "written_candidate_reads",
        "candidate_rate",
        "elapsed_seconds",
        "query_cover_pct",
        "minimum_alignment_aa",
        "evalue",
        "max_target_seqs",
        "raw_hits",
        "best_hits",
        "candidate_ids",
        "candidate_fasta",
        "log_file",
    ]

    temporary = long_file.with_name(long_file.name + ".tmp")

    with temporary.open(
        "wt",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=columns,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()

        for row in sorted(
            rows,
            key=lambda item: (
                str(item["sample"]),
                float(item["identity_pct"]),
            ),
        ):
            writer.writerow({
                column: row.get(column, "")
                for column in columns
            })

    os.replace(temporary, long_file)

    samples = sorted({
        str(row["sample"])
        for row in rows
    })
    labels = sorted(
        {
            str(row["threshold_label"])
            for row in rows
        },
        key=lambda value: float(value.replace("diamond", "")),
    )

    lookup = {
        (
            str(row["sample"]),
            str(row["threshold_label"]),
        ): row
        for row in rows
    }

    matrix_file = (
        output_root
        / "diamond_0.2_0.5_0.6_0.7_0.8_0.9_all_reads_candidate_count_matrix.tsv"
    )
    temporary = matrix_file.with_name(
        matrix_file.name + ".tmp"
    )

    with temporary.open(
        "wt",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.writer(
            handle,
            delimiter="\t",
            lineterminator="\n",
        )

        writer.writerow([
            "sample",
            *[
                f"candidate_reads_{label}"
                for label in labels
            ],
        ])

        for sample in samples:
            writer.writerow([
                sample,
                *[
                    lookup.get(
                        (sample, label),
                        {},
                    ).get("candidate_read_ids", "")
                    for label in labels
                ],
            ])

    os.replace(temporary, matrix_file)


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent

    parser = argparse.ArgumentParser(
        description=(
            "Run independent DIAMOND blastx searches at identity 0.5 and 0.8 "
            "on all original reads with compact heartbeat progress."
        )
    )

    parser.add_argument(
        "--input-dir",
        type=Path,
        default=script_dir,
    )
    parser.add_argument(
        "--protein-fasta",
        type=Path,
        default=script_dir / PROTEIN_REFERENCE_NAME,
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=script_dir / DEFAULT_OUTPUT_NAME,
    )
    parser.add_argument(
        "--pattern",
        default=DEFAULT_PATTERN,
    )
    parser.add_argument(
        "--thresholds",
        default="0.5,0.8",
    )
    parser.add_argument(
        "--sample",
        action="append",
        default=[],
        help=(
            "Run only selected sample(s). May be repeated or comma-separated."
        ),
    )
    parser.add_argument(
        "--diamond",
        default=None,
    )
    parser.add_argument(
        "--threads",
        type=int,
        default=max(
            1,
            min(16, (os.cpu_count() or 4) - 1),
        ),
    )
    parser.add_argument(
        "--query-cover",
        type=float,
        default=75.0,
    )
    parser.add_argument(
        "--min-align-aa",
        type=int,
        default=25,
    )
    parser.add_argument(
        "--evalue",
        default="1e-7",
    )
    parser.add_argument(
        "--max-target-seqs",
        type=int,
        default=10,
    )
    parser.add_argument(
        "--max-hsps",
        type=int,
        default=1,
    )
    parser.add_argument(
        "--min-orf",
        type=int,
        default=1,
    )
    parser.add_argument(
        "--sensitivity",
        choices=[
            "default",
            "fast",
            "mid-sensitive",
            "sensitive",
            "more-sensitive",
            "very-sensitive",
            "ultra-sensitive",
        ],
        default="very-sensitive",
    )
    parser.add_argument(
        "--block-size",
        type=float,
        default=0.4,
    )
    parser.add_argument(
        "--heartbeat-seconds",
        type=int,
        default=60,
        help=(
            "Print one coarse progress line every N seconds during DIAMOND."
        ),
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
    )
    parser.add_argument(
        "--overwrite-db",
        action="store_true",
    )

    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if not args.input_dir.is_dir():
        raise PipelineError(
            f"Input directory not found: {args.input_dir}"
        )

    if args.threads < 1:
        raise PipelineError("--threads must be >= 1")

    if not (0 <= args.query_cover <= 100):
        raise PipelineError("--query-cover must be in [0, 100]")

    if args.min_align_aa < 1:
        raise PipelineError("--min-align-aa must be >= 1")

    if args.max_target_seqs < 1:
        raise PipelineError("--max-target-seqs must be >= 1")

    if args.max_hsps < 1:
        raise PipelineError("--max-hsps must be >= 1")

    if args.min_orf < 1:
        raise PipelineError("--min-orf must be >= 1")

    if args.block_size <= 0:
        raise PipelineError("--block-size must be > 0")

    if args.heartbeat_seconds < 5:
        raise PipelineError(
            "--heartbeat-seconds must be at least 5"
        )

    try:
        evalue = float(args.evalue)
    except ValueError as exc:
        raise PipelineError(
            f"Invalid --evalue: {args.evalue}"
        ) from exc

    if evalue <= 0:
        raise PipelineError("--evalue must be > 0")


def main() -> int:
    args = parse_args()

    try:
        validate_args(args)

        input_dir = args.input_dir.resolve()
        protein_fasta = args.protein_fasta.resolve()
        output_root = args.output_dir.resolve()
        output_root.mkdir(parents=True, exist_ok=True)

        script_dir = Path(__file__).resolve().parent
        diamond = resolve_diamond(args.diamond, script_dir)

        validate_protein_fasta(protein_fasta)

        run_quiet_command(
            [diamond, "version"],
            output_root / "logs" / "diamond_version.log",
        )

        selected: set[str] = set()

        for item in args.sample:
            selected.update(
                part.strip()
                for part in item.split(",")
                if part.strip()
            )

        samples = discover_samples(
            input_dir=input_dir,
            pattern=args.pattern,
            selected=selected,
        )
        thresholds = parse_thresholds(args.thresholds)

        total_runs = len(samples) * len(thresholds)

        log("=" * 80)
        log("DIAMOND 0.5 and 0.8 on all original reads")
        log(f"DIAMOND executable: {diamond}")
        log(f"Input directory: {input_dir}")
        log(f"Protein reference: {protein_fasta}")
        log(f"Output directory: {output_root}")
        log(
            f"Samples ({len(samples)}): "
            + ", ".join(
                strip_sequence_suffix(path.name)
                for path in samples
            )
        )
        log(
            f"Thresholds ({len(thresholds)}): "
            + ", ".join(
                label
                for label, _ in thresholds
            )
        )
        log(f"Independent diamond.exe blastx runs: {total_runs}")
        log(
            f"threads={args.threads}, "
            f"heartbeat={args.heartbeat_seconds}s, "
            f"qcov>={args.query_cover:g}%, "
            f"align>={args.min_align_aa} aa, "
            f"evalue<={args.evalue}, "
            f"max-target-seqs={args.max_target_seqs}"
        )
        log("=" * 80)

        database_prefix = build_database(
            diamond=diamond,
            protein_fasta=protein_fasta,
            output_root=output_root,
            threads=args.threads,
            overwrite=args.overwrite_db,
        )

        tasks: list[tuple[Path, str, str, float]] = []

        for threshold_label, threshold_pct in thresholds:
            for query in samples:
                tasks.append((
                    query,
                    strip_sequence_suffix(query.name),
                    threshold_label,
                    threshold_pct,
                ))

        completed_durations: list[float] = []

        for run_index, (
            query,
            sample,
            threshold_label,
            threshold_pct,
        ) in enumerate(tasks, start=1):
            result, was_skipped, elapsed = process_one_task(
                diamond=diamond,
                database_prefix=database_prefix,
                protein_fasta=protein_fasta,
                query=query.resolve(),
                sample=sample,
                threshold_label=threshold_label,
                threshold_pct=threshold_pct,
                output_root=output_root,
                args=args,
                run_index=run_index,
                total_runs=total_runs,
                completed_durations=completed_durations,
            )

            if elapsed > 0:
                completed_durations.append(elapsed)

            write_summaries(output_root)

        write_summaries(output_root)

        run_info = {
            "pipeline_version": PIPELINE_VERSION,
            "diamond_executable": diamond,
            "input_dir": str(input_dir),
            "protein_fasta": str(protein_fasta),
            "output_root": str(output_root),
            "samples": [
                strip_sequence_suffix(path.name)
                for path in samples
            ],
            "thresholds": [
                {
                    "label": label,
                    "identity_pct": percentage,
                }
                for label, percentage in thresholds
            ],
            "total_independent_diamond_runs": total_runs,
            "query_cover_pct": args.query_cover,
            "minimum_alignment_aa": args.min_align_aa,
            "evalue": str(args.evalue),
            "max_target_seqs": args.max_target_seqs,
            "max_hsps": args.max_hsps,
            "min_orf": args.min_orf,
            "sensitivity": args.sensitivity,
            "threads": args.threads,
            "heartbeat_seconds": args.heartbeat_seconds,
        }

        write_json_atomic(
            output_root / "run_info.json",
            run_info,
        )

        log("=" * 80)
        log("All requested DIAMOND runs finished")
        log(
            "Candidate count matrix: "
            f"{output_root / 'diamond_0.2_0.5_0.6_0.7_0.8_0.9_all_reads_candidate_count_matrix.tsv'}"
        )
        log(
            "Long summary: "
            f"{output_root / 'diamond_0.2_0.5_0.6_0.7_0.8_0.9_all_reads_long_summary.tsv'}"
        )
        log("=" * 80)

        return 0

    except (
        PipelineError,
        OSError,
        subprocess.SubprocessError,
        ValueError,
        json.JSONDecodeError,
    ) as exc:
        print(f"ERROR: {exc}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
