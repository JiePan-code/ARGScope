#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope / ARG-OAP / DeepARG real-data Type-level boxplot + scatter comparison
=============================================================================

What this script does
---------------------
1. Recursively scans ARGScope real-data folders:
      ARGScope_DIAMOND_gate010_realdata_predictions/
      ARGScope_DIAMOND_gate020_realdata_predictions/
      ...
   and reads every:
      all_samples_ARG_predictions.csv

2. Reads ARG-OAP Type counts:
      ARGOAP/unnormalized_count.type.revised.txt

3. Reads DeepARG real-data results:
      DeepARG_Fast结果/*.clean.deeparg.mapping.ARG

4. Harmonizes Type names across the three tools.

5. Creates MULTIPLE PARAMETER GROUPS.  Each group can contain several
   ARGScope gate+DIAMOND configurations plus ARG-OAP and DeepARG.

6. For every shared Type, draws:
      boxplot + jittered sample-level points
   like the faceted example figure.

7. Outputs both:
      A. raw Type count
      B. within-tool relative abundance (%)

Default auto grouping
---------------------
AUTO_GROUP_MODE = "by_gate"
CONFIGS_PER_GROUP = 3

Example output groups for gate 0.10:
  group 1: g0.10/d0.2, g0.10/d0.5, g0.10/d0.6, ARG-OAP, DeepARG
  group 2: g0.10/d0.7, g0.10/d0.8, g0.10/d0.9, ARG-OAP, DeepARG

You can also use arbitrary custom groups by setting:
    AUTO_GROUP_MODE = "custom"

Python 3.8 compatible.
Dependencies:
    pandas numpy matplotlib
"""

from __future__ import print_function

import math
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =============================================================================
# 1. CONFIG
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

OUT_DIR = ROOT_DIR / "ARGScope_ARGOAP_DeepARG_Type_boxscatter_multi_groups"
FIG_DIR = OUT_DIR / "figures"
TABLE_DIR = OUT_DIR / "tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)

# Do not hard-code the comparison-tool folder names.
# The script will auto-detect the actual ARG-OAP file and DeepARG folder.
ARG_OAP_FILE = None
DEEPARG_DIR = None

ARGSCOPE_FILE_NAME = "all_samples_ARG_predictions.csv"
DEEPARG_PATTERN = "*.clean.deeparg.mapping.ARG"

# -----------------------------------------------------------------------------
# PARAMETER GROUPING
# -----------------------------------------------------------------------------
# Options:
#   "by_gate"    : fixed gate, split DIAMOND values into groups
#   "by_diamond" : fixed DIAMOND, split gate values into groups
#   "custom"     : use CUSTOM_GROUPS exactly
AUTO_GROUP_MODE = "by_gate"

# Maximum number of ARGScope parameter configurations in one figure group.
# ARG-OAP and DeepARG are then added automatically.
CONFIGS_PER_GROUP = 3

# Used only when AUTO_GROUP_MODE == "custom".
# Any number of groups can be defined.
# Format: "group name": [(gate, diamond), (gate, diamond), ...]
CUSTOM_GROUPS = {
    "Candidate_group_A": [
        (0.10, 0.20),
        (0.20, 0.20),
        (0.30, 0.20),
    ],
    "Candidate_group_B": [
        (0.10, 0.50),
        (0.20, 0.50),
        (0.30, 0.50),
    ],
}

# -----------------------------------------------------------------------------
# TYPE SELECTION
# -----------------------------------------------------------------------------
# "shared_all_three": Type must be detected at least once by ARGScope (any
#                      configuration), ARG-OAP, and DeepARG.
# "union":            union of canonical Types from the three tools.
TYPE_SELECTION_MODE = "shared_all_three"

# None = draw all selected Types.
# Example: 20 = only top 20 Types based on average relative abundance.
TOP_N_TYPES = None

# Type ordering:
#   "abundance"  : highest overall relative abundance first
#   "alphabetical"
TYPE_ORDER_MODE = "abundance"

# -----------------------------------------------------------------------------
# FIGURE LAYOUT
# -----------------------------------------------------------------------------
FACET_NCOLS = 5
FACET_NROWS = 4
PANEL_WIDTH = 3.10
PANEL_HEIGHT = 2.55

DPI = 600
SAVE_PDF = True
SAVE_SVG = True

POINT_SIZE = 22
POINT_ALPHA = 0.80
JITTER_WIDTH = 0.075
BOX_WIDTH = 0.56

# Make both raw-count and relative-abundance figures.
MAKE_RAW_COUNT = True
MAKE_RELATIVE_ABUNDANCE = True

# Optional log10(count+1) figure.
MAKE_LOG10_COUNT = False

# Show sample-level points on top of boxplots.
SHOW_SCATTER = True

# Main model colors: all ARGScope configurations use related red tones.
ARG_OAP_COLOR = "#B8B8B8"
DEEPARG_COLOR = "#6D8FB3"
ARGSCOPE_COLORS = [
    "#F4A3A3",
    "#EB7777",
    "#DF5555",
    "#CC3636",
    "#AF1F1F",
    "#8F1010",
]

# Preferred sample order.
PREFERRED_SAMPLES = [
    "argbert_1", "argbert_2", "argbert_3",
    "argscope_1", "argscope_2", "argscope_3",
    "argscope_4", "argscope_5", "argscope_6",
]

# -----------------------------------------------------------------------------
# FONT / STYLE
# -----------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9.0,
    "axes.titlesize": 9.3,
    "axes.labelsize": 9.0,
    "xtick.labelsize": 7.4,
    "ytick.labelsize": 7.4,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 2. TYPE MAPPING
# =============================================================================

def clean_token(x):
    if pd.isna(x):
        return ""
    s = str(x).strip().lower()
    s = s.replace("β", "beta")
    s = re.sub(r"[\s/_-]+", "_", s)
    s = re.sub(r"[^a-z0-9_]", "", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_")


# Canonical ARGScope-style Type names.
TYPE_ALIASES = {
    "aminoglycoside": "aminoglycoside",
    "aminoglycosides": "aminoglycoside",

    "aminocoumarin": "novobiocin",
    "aminocoumarins": "novobiocin",
    "novobiocin": "novobiocin",

    "bacitracin": "bacitracin",

    "beta_lactam": "beta_lactam",
    "betalactam": "beta_lactam",
    "betalactams": "beta_lactam",

    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",
    "phenicols": "chloramphenicol",

    "fluoroquinolone": "quinolone",
    "fluoroquinolones": "quinolone",
    "quinolone": "quinolone",
    "quinolones": "quinolone",

    "fosfomycin": "fosfomycin",
    "fusidic_acid": "fusidic_acid",

    "glycopeptide": "vancomycin",
    "glycopeptides": "vancomycin",
    "vancomycin": "vancomycin",

    "mls": "macrolide-lincosamide-streptogramin",
    "macrolide_lincosamide_streptogramin": "macrolide-lincosamide-streptogramin",

    "multidrug": "multidrug",
    "multi_drug_resistance": "multidrug",

    "mupirocin": "mupirocin",

    "pleuromutilin": "pleuromutilin_tiamulin",
    "pleuromutilin_tiamulin": "pleuromutilin_tiamulin",

    "polymyxin": "polymyxin",

    "rifamycin": "rifamycin",
    "rifampin": "rifamycin",
    "rifampicin": "rifamycin",

    "streptothricin": "streptothricin",
    "nucleoside": "streptothricin",
    "nucleosides": "streptothricin",

    "sulfonamide": "sulfonamide",
    "sulfonamides": "sulfonamide",

    "tetracenomycin_c": "tetracenomycin_C",
    "tetracycline": "tetracycline",
    "trimethoprim": "trimethoprim",

    "triclosan": "triclosan",
    "tunicamycin": "tunicamycin",
    "puromycin": "puromycin",
}

# Clearly non-Type / ambiguous ARG-OAP rows to exclude.
EXCLUDE_RAW_TYPES = {
    "pneumoniae",
    "perfringens",
    "fabrum",
    "monocytogenes",
    "cloacae",
    "class",
    "lividans",
    "23s",
    "anguillarum",
    "efflux",
    "baumannii",
    "pseudomallei",
    "coli",
    "intrinsic",
    "other_peptide_antibiotics",
}

# Ambiguous / unsupported DeepARG broad classes are excluded rather than forced
# into an ARGScope Type.
EXCLUDE_DEEPARG_CLASSES = {
    "unclassified",
    "peptide",
    "fosmidomycin",
    "nitroimidazole",
    "others",
    "other",
}


def canonical_type(raw):
    token = clean_token(raw)
    if token in EXCLUDE_RAW_TYPES:
        return None
    if token in TYPE_ALIASES:
        return TYPE_ALIASES[token]
    # Keep already-clean ARGScope labels when no explicit alias is needed.
    raw_s = str(raw).strip()
    if raw_s and token not in EXCLUDE_DEEPARG_CLASSES:
        return raw_s
    return None


# =============================================================================
# 3. ARGScope LOADING
# =============================================================================

def infer_gate_from_path(path):
    for part in path.parts:
        m = re.search(r"gate(\d+)", part.lower())
        if m:
            return int(m.group(1)) / 100.0
    return None


def infer_diamond_from_path(path):
    for part in reversed(path.parts):
        m = re.search(r"diamond\s*([01]?\.\d+)", part.lower())
        if m:
            return float(m.group(1))
    return None


def parse_diamond_value(value):
    s = str(value).strip().lower()
    m = re.search(r"([01]?\.\d+)", s)
    if m:
        return float(m.group(1))
    return None


def discover_argscope_prediction_files():
    files = []
    for p in ROOT_DIR.rglob(ARGSCOPE_FILE_NAME):
        if OUT_DIR in p.parents:
            continue
        if infer_gate_from_path(p) is None:
            continue
        files.append(p)
    return sorted(files)


def load_argscope_counts():
    files = discover_argscope_prediction_files()
    if not files:
        raise FileNotFoundError(
            "Cannot find any %s under ARGScope_DIAMOND_gate* folders." % ARGSCOPE_FILE_NAME
        )

    parts = []
    diagnostics = []

    print("=" * 90)
    print("Reading ARGScope Type predictions")
    print("=" * 90)
    print("Files found:", len(files))

    for i, path in enumerate(files, start=1):
        gate = infer_gate_from_path(path)
        path_diamond = infer_diamond_from_path(path)

        df = pd.read_csv(path)
        required = {"sample_name", "Pred_Type"}
        missing = required - set(df.columns)
        if missing:
            print("[SKIP]", path, "missing", missing)
            continue

        if "Pred_ARG" in df.columns:
            df = df[df["Pred_ARG"].astype(str).str.upper() == "ARG"].copy()

        # Deduplicate read predictions if read_id exists.
        if "read_id" in df.columns:
            dedup_cols = ["sample_name", "read_id"]
            if "diamond_threshold" in df.columns:
                dedup_cols.append("diamond_threshold")
            df = df.drop_duplicates(subset=dedup_cols, keep="first").copy()

        df["Type"] = df["Pred_Type"].map(canonical_type)
        df = df[df["Type"].notna()].copy()

        if "diamond_threshold" in df.columns:
            df["diamond"] = df["diamond_threshold"].map(parse_diamond_value)
        else:
            df["diamond"] = path_diamond

        if path_diamond is not None:
            df["diamond"] = df["diamond"].fillna(path_diamond)

        df["gate"] = float(gate)
        df = df[df["diamond"].notna()].copy()

        g = (
            df.groupby(["gate", "diamond", "sample_name", "Type"], as_index=False)
              .size()
              .rename(columns={"sample_name": "sample", "size": "Count"})
        )
        g["model"] = "ARGScope"
        parts.append(g)

        diagnostics.append({
            "file": str(path.relative_to(ROOT_DIR)),
            "gate": gate,
            "path_diamond": path_diamond,
            "rows_after_filter": len(df),
            "unique_diamonds": ",".join(str(x) for x in sorted(df["diamond"].dropna().unique())),
            "samples": df["sample_name"].nunique(),
            "types": df["Type"].nunique(),
        })

        print("[%03d/%03d] gate=%.2f | diamonds=%s | rows=%d | %s" % (
            i, len(files), gate,
            sorted(df["diamond"].dropna().unique().tolist()),
            len(df), path.relative_to(ROOT_DIR)
        ))

    if not parts:
        raise RuntimeError("No usable ARGScope prediction files were parsed.")

    out = pd.concat(parts, ignore_index=True)

    # If the same configuration was found in multiple files, combine counts.
    out = (
        out.groupby(["gate", "diamond", "sample", "Type", "model"], as_index=False)["Count"]
           .sum()
    )

    pd.DataFrame(diagnostics).to_csv(
        TABLE_DIR / "ARGScope_file_scan_diagnostics.csv",
        index=False, encoding="utf-8-sig"
    )
    out.to_csv(
        TABLE_DIR / "ARGScope_type_counts_all_parameter_settings.csv",
        index=False, encoding="utf-8-sig"
    )
    return out


# =============================================================================
# 3B. AUTO-DETECT ARG-OAP / DeepARG INPUTS
# =============================================================================

def find_argoap_file():
    """Find unnormalized_count.type.revised.txt under ROOT_DIR recursively."""
    exact = ROOT_DIR / "ARGOAP" / "unnormalized_count.type.revised.txt"
    if exact.exists():
        return exact

    candidates = [
        p for p in ROOT_DIR.rglob("unnormalized_count.type.revised.txt")
        if OUT_DIR not in p.parents
    ]
    if not candidates:
        raise FileNotFoundError(
            "Cannot find unnormalized_count.type.revised.txt anywhere under ROOT_DIR: %s"
            % ROOT_DIR
        )

    candidates = sorted(candidates, key=lambda p: (len(p.parts), str(p).lower()))
    if len(candidates) > 1:
        print("[WARN] Multiple ARG-OAP type files found; using:", candidates[0])
        for p in candidates[1:]:
            print("       other candidate:", p)
    return candidates[0]


def find_deeparg_dir():
    """
    Find the directory containing *.clean.deeparg.mapping.ARG files.
    This avoids depending on a fixed Chinese/English folder name.
    """
    exact = ROOT_DIR / "DeepARG_Fast结果"
    if exact.exists():
        exact_files = sorted(exact.glob(DEEPARG_PATTERN))
        if exact_files:
            return exact

    files = [
        p for p in ROOT_DIR.rglob(DEEPARG_PATTERN)
        if OUT_DIR not in p.parents
    ]
    if not files:
        raise FileNotFoundError(
            "Cannot find any DeepARG files matching %s under ROOT_DIR: %s"
            % (DEEPARG_PATTERN, ROOT_DIR)
        )

    # Usually all 9 files are in one folder. If more than one candidate parent
    # exists, choose the folder containing the largest number of matching files.
    parent_counts = {}
    for p in files:
        parent_counts[p.parent] = parent_counts.get(p.parent, 0) + 1

    ranked = sorted(
        parent_counts.items(),
        key=lambda kv: (-kv[1], len(kv[0].parts), str(kv[0]).lower()),
    )
    best_dir, best_count = ranked[0]

    if len(ranked) > 1:
        print("[WARN] Multiple DeepARG result directories found.")
        print("       using:", best_dir, "| files=", best_count)
        for p, n in ranked[1:]:
            print("       other:", p, "| files=", n)

    return best_dir

# =============================================================================
# 4. ARG-OAP LOADING
# =============================================================================

def load_argoap_counts():
    # Auto-detect the actual ARG-OAP type-count file every time this loader runs.
    # Do not depend on the optional global argoap_file, which may be None.
    argoap_file = find_argoap_file()
    print("[ARG-OAP] detected file:", argoap_file)

    if not argoap_file.exists():
        raise FileNotFoundError("Missing ARG-OAP Type file: %s" % argoap_file)

    df = pd.read_csv(argoap_file, sep="\t")
    if "gene" not in df.columns:
        raise ValueError("ARG-OAP file must contain a 'gene' column.")

    df["Type"] = df["gene"].map(canonical_type)

    excluded = df[df["Type"].isna()].copy()
    excluded.to_csv(
        TABLE_DIR / "ARGOAP_excluded_type_rows.csv",
        index=False, encoding="utf-8-sig"
    )

    df = df[df["Type"].notna()].copy()
    sample_cols = [c for c in df.columns if c not in {"gene", "Type"}]

    long_df = df.melt(
        id_vars=["Type"],
        value_vars=sample_cols,
        var_name="sample",
        value_name="Count",
    )
    long_df["Count"] = pd.to_numeric(long_df["Count"], errors="coerce").fillna(0.0)
    long_df = long_df.groupby(["sample", "Type"], as_index=False)["Count"].sum()
    long_df["model"] = "ARG-OAP"

    long_df.to_csv(
        TABLE_DIR / "ARGOAP_type_counts.csv",
        index=False, encoding="utf-8-sig"
    )
    return long_df


# =============================================================================
# 5. DeepARG LOADING
# =============================================================================

def infer_sample_from_deeparg_filename(path):
    suffix = ".clean.deeparg.mapping.ARG"
    name = path.name
    if name.endswith(suffix):
        return name[:-len(suffix)]
    return name.split(".clean", 1)[0]


def canonical_deeparg_type(raw):
    token = clean_token(raw)
    if token in EXCLUDE_DEEPARG_CLASSES:
        return None
    return canonical_type(raw)


def load_deeparg_counts():
    deeparg_dir = find_deeparg_dir()
    print("[DeepARG] detected folder:", deeparg_dir)

    files = sorted(deeparg_dir.glob(DEEPARG_PATTERN))
    if not files:
        raise FileNotFoundError("No DeepARG result files found in %s" % deeparg_dir)

    parts = []
    diagnostics = []

    for path in files:
        sample = infer_sample_from_deeparg_filename(path)
        df = pd.read_csv(path, sep="\t")

        if "predicted_ARG-class" not in df.columns:
            print("[SKIP DeepARG]", path.name, "no predicted_ARG-class")
            continue

        # One DeepARG result per read. If duplicates exist, keep strongest hit.
        if "read_id" in df.columns:
            sort_cols = []
            ascending = []
            if "probability" in df.columns:
                df["probability"] = pd.to_numeric(df["probability"], errors="coerce")
                sort_cols.append("probability")
                ascending.append(False)
            if "alignment-bitscore" in df.columns:
                df["alignment-bitscore"] = pd.to_numeric(df["alignment-bitscore"], errors="coerce")
                sort_cols.append("alignment-bitscore")
                ascending.append(False)
            if sort_cols:
                df = df.sort_values(sort_cols, ascending=ascending)
            df = df.drop_duplicates(subset=["read_id"], keep="first").copy()

        df["Type"] = df["predicted_ARG-class"].map(canonical_deeparg_type)
        excluded = df[df["Type"].isna()][["predicted_ARG-class"]].copy()
        excluded["sample"] = sample
        diagnostics.append(excluded)

        df = df[df["Type"].notna()].copy()

        if "counts" in df.columns:
            df["_count"] = pd.to_numeric(df["counts"], errors="coerce").fillna(1.0)
        else:
            df["_count"] = 1.0

        g = df.groupby("Type", as_index=False)["_count"].sum().rename(columns={"_count": "Count"})
        g["sample"] = sample
        g["model"] = "DeepARG"
        parts.append(g)

    if not parts:
        raise RuntimeError("No usable DeepARG results were parsed.")

    out = pd.concat(parts, ignore_index=True)
    out = out[["sample", "Type", "Count", "model"]]

    if diagnostics:
        pd.concat(diagnostics, ignore_index=True).to_csv(
            TABLE_DIR / "DeepARG_excluded_classes.csv",
            index=False, encoding="utf-8-sig"
        )

    out.to_csv(
        TABLE_DIR / "DeepARG_type_counts.csv",
        index=False, encoding="utf-8-sig"
    )
    return out


# =============================================================================
# 6. UNIFIED DATA PREPARATION
# =============================================================================

def preferred_sample_order(all_samples):
    all_samples = list(dict.fromkeys(str(x) for x in all_samples))
    ordered = [x for x in PREFERRED_SAMPLES if x in all_samples]
    ordered.extend(sorted(x for x in all_samples if x not in ordered))
    return ordered


def available_argscope_configs(argscope_df):
    configs = (
        argscope_df[["gate", "diamond"]]
        .drop_duplicates()
        .sort_values(["gate", "diamond"])
    )
    return [(float(r.gate), float(r.diamond)) for r in configs.itertuples(index=False)]


def fmt_config(gate, diamond):
    return "ARGScope\ng%.2f / d%.1f" % (float(gate), float(diamond))


def safe_name(s):
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(s))
    return s.strip("_")


def build_parameter_groups(configs):
    config_set = set((round(g, 6), round(d, 6)) for g, d in configs)
    groups = []

    if AUTO_GROUP_MODE == "custom":
        for group_name, requested in CUSTOM_GROUPS.items():
            valid = []
            for gate, diamond in requested:
                key = (round(float(gate), 6), round(float(diamond), 6))
                if key in config_set:
                    valid.append((float(gate), float(diamond)))
                else:
                    print("[WARN] custom config not found:", gate, diamond)
            if valid:
                groups.append((group_name, valid))

    elif AUTO_GROUP_MODE == "by_gate":
        gates = sorted(set(g for g, _ in configs))
        for gate in gates:
            ds = sorted(d for g, d in configs if np.isclose(g, gate))
            for chunk_i in range(0, len(ds), CONFIGS_PER_GROUP):
                chunk = ds[chunk_i:chunk_i + CONFIGS_PER_GROUP]
                valid = [(gate, d) for d in chunk]
                group_name = "gate%.2f_set%d" % (gate, chunk_i // CONFIGS_PER_GROUP + 1)
                groups.append((group_name, valid))

    elif AUTO_GROUP_MODE == "by_diamond":
        diamonds = sorted(set(d for _, d in configs))
        for diamond in diamonds:
            gs = sorted(g for g, d in configs if np.isclose(d, diamond))
            for chunk_i in range(0, len(gs), CONFIGS_PER_GROUP):
                chunk = gs[chunk_i:chunk_i + CONFIGS_PER_GROUP]
                valid = [(g, diamond) for g in chunk]
                group_name = "diamond%.1f_set%d" % (diamond, chunk_i // CONFIGS_PER_GROUP + 1)
                groups.append((group_name, valid))
    else:
        raise ValueError("Unknown AUTO_GROUP_MODE: %s" % AUTO_GROUP_MODE)

    if not groups:
        raise RuntimeError("No parameter groups were constructed.")

    manifest_rows = []
    for group_name, group_configs in groups:
        for order, (g, d) in enumerate(group_configs, start=1):
            manifest_rows.append({
                "group": group_name,
                "order": order,
                "gate": g,
                "diamond": d,
                "label": fmt_config(g, d).replace("\n", " "),
            })
    pd.DataFrame(manifest_rows).to_csv(
        TABLE_DIR / "parameter_group_manifest.csv",
        index=False, encoding="utf-8-sig"
    )
    return groups


def choose_types(argscope_df, argoap_df, deeparg_df):
    a = set(argscope_df["Type"].dropna().astype(str))
    o = set(argoap_df["Type"].dropna().astype(str))
    d = set(deeparg_df["Type"].dropna().astype(str))

    if TYPE_SELECTION_MODE == "shared_all_three":
        selected = a & o & d
    elif TYPE_SELECTION_MODE == "union":
        selected = a | o | d
    else:
        raise ValueError("Unknown TYPE_SELECTION_MODE: %s" % TYPE_SELECTION_MODE)

    if not selected:
        raise RuntimeError("No Types selected after cross-tool harmonization.")
    return sorted(selected)


def complete_model_type_table(df, samples, types, model_name):
    base_idx = pd.MultiIndex.from_product([samples, types], names=["sample", "Type"])
    x = df[["sample", "Type", "Count"]].copy()
    x["sample"] = x["sample"].astype(str)
    x["Type"] = x["Type"].astype(str)
    x = x.groupby(["sample", "Type"], as_index=True)["Count"].sum()
    x = x.reindex(base_idx, fill_value=0.0).reset_index()
    x["model"] = model_name
    return x


def make_relative_abundance(df):
    out = df.copy()
    totals = out.groupby(["category", "sample"])["Count"].transform("sum")
    out["Relative_abundance_pct"] = np.where(totals > 0, 100.0 * out["Count"] / totals, 0.0)
    return out


def build_group_long_table(argscope_df, argoap_df, deeparg_df, group_name, group_configs, types, samples):
    parts = []

    for gate, diamond in group_configs:
        sub = argscope_df[
            np.isclose(argscope_df["gate"].astype(float), float(gate)) &
            np.isclose(argscope_df["diamond"].astype(float), float(diamond))
        ].copy()
        completed = complete_model_type_table(sub, samples, types, "ARGScope")
        completed["gate"] = float(gate)
        completed["diamond"] = float(diamond)
        completed["category"] = fmt_config(gate, diamond)
        completed["category_family"] = "ARGScope"
        parts.append(completed)

    oap = complete_model_type_table(argoap_df, samples, types, "ARG-OAP")
    oap["gate"] = np.nan
    oap["diamond"] = np.nan
    oap["category"] = "ARG-OAP"
    oap["category_family"] = "ARG-OAP"
    parts.append(oap)

    deep = complete_model_type_table(deeparg_df, samples, types, "DeepARG")
    deep["gate"] = np.nan
    deep["diamond"] = np.nan
    deep["category"] = "DeepARG"
    deep["category_family"] = "DeepARG"
    parts.append(deep)

    out = pd.concat(parts, ignore_index=True)
    out["group"] = group_name
    out = make_relative_abundance(out)
    out["log10_Count_plus1"] = np.log10(out["Count"].astype(float) + 1.0)
    return out


def rank_types(all_group_df, types):
    if TYPE_ORDER_MODE == "alphabetical":
        ordered = sorted(types)
    else:
        score = (
            all_group_df.groupby("Type")["Relative_abundance_pct"]
            .mean()
            .sort_values(ascending=False)
        )
        ordered = [t for t in score.index if t in set(types)]
        ordered.extend([t for t in types if t not in ordered])

    if TOP_N_TYPES is not None:
        ordered = ordered[:int(TOP_N_TYPES)]
    return ordered


# =============================================================================
# 7. PLOTTING
# =============================================================================

def category_colors(categories):
    result = {}
    argscope_i = 0
    for cat in categories:
        if str(cat).startswith("ARGScope"):
            result[cat] = ARGSCOPE_COLORS[argscope_i % len(ARGSCOPE_COLORS)]
            argscope_i += 1
        elif cat == "ARG-OAP":
            result[cat] = ARG_OAP_COLOR
        elif cat == "DeepARG":
            result[cat] = DEEPARG_COLOR
        else:
            result[cat] = "#999999"
    return result


def metric_info(metric):
    if metric == "Count":
        return "Count", "raw_count"
    if metric == "Relative_abundance_pct":
        return "Relative abundance (%)", "relative_abundance"
    if metric == "log10_Count_plus1":
        return "log10(Count + 1)", "log10_count"
    return metric, safe_name(metric)


def plot_one_page(group_df, group_name, categories, type_page, page_i, total_pages, metric):
    ylabel, metric_tag = metric_info(metric)
    ntypes = len(type_page)
    ncols = FACET_NCOLS
    nrows = int(math.ceil(float(ntypes) / float(ncols)))

    fig, axes = plt.subplots(
        nrows=nrows,
        ncols=ncols,
        figsize=(PANEL_WIDTH * ncols, PANEL_HEIGHT * nrows + 1.25),
        squeeze=False,
        dpi=180,
    )
    axes_flat = axes.ravel()
    colors = category_colors(categories)

    rng = np.random.RandomState(42)

    for ax_i, type_name in enumerate(type_page):
        ax = axes_flat[ax_i]
        sub_type = group_df[group_df["Type"] == type_name].copy()

        values = []
        for cat in categories:
            arr = sub_type[sub_type["category"] == cat][metric].astype(float).to_numpy()
            values.append(arr)

        bp = ax.boxplot(
            values,
            positions=np.arange(len(categories)),
            widths=BOX_WIDTH,
            patch_artist=True,
            showfliers=False,
            medianprops=dict(color="#333333", linewidth=1.1),
            whiskerprops=dict(color="#666666", linewidth=0.8),
            capprops=dict(color="#666666", linewidth=0.8),
            boxprops=dict(linewidth=0.9, edgecolor="#666666"),
        )

        for box, cat in zip(bp["boxes"], categories):
            box.set_facecolor(colors[cat])
            box.set_alpha(0.50 if cat != "ARG-OAP" else 0.42)

        if SHOW_SCATTER:
            for x_i, (cat, arr) in enumerate(zip(categories, values)):
                if len(arr) == 0:
                    continue
                # deterministic but visibly separated jitter
                jitter = rng.uniform(-JITTER_WIDTH, JITTER_WIDTH, size=len(arr))
                ax.scatter(
                    np.full(len(arr), x_i, dtype=float) + jitter,
                    arr,
                    s=POINT_SIZE,
                    c=colors[cat],
                    alpha=POINT_ALPHA,
                    edgecolors="white",
                    linewidths=0.35,
                    zorder=3,
                )

        ax.set_title(type_name, fontsize=9.1, pad=4)
        ax.set_xticks(np.arange(len(categories)))
        ax.set_xticklabels(categories, rotation=48, ha="right", rotation_mode="anchor", fontsize=6.7)

        if ax_i % ncols == 0:
            ax.set_ylabel(ylabel, fontsize=8.2)
        else:
            ax.set_ylabel("")

        ax.grid(axis="y", linestyle=":", linewidth=0.45, alpha=0.30)
        ax.set_axisbelow(True)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_linewidth(0.75)
        ax.spines["bottom"].set_linewidth(0.75)

        # Add n=sample count unobtrusively.
        n_samples = sub_type["sample"].nunique()
        ax.text(
            0.98, 0.96, "n=%d" % n_samples,
            transform=ax.transAxes,
            ha="right", va="top",
            fontsize=6.4, color="#777777"
        )

    for j in range(ntypes, len(axes_flat)):
        axes_flat[j].axis("off")

    # Legend emphasizes ARGScope-family parameters while keeping baselines visible.
    handles = []
    labels = []
    for cat in categories:
        h = plt.Line2D(
            [], [], linestyle="none", marker="o", markersize=7,
            markerfacecolor=colors[cat], markeredgecolor="white", markeredgewidth=0.6
        )
        handles.append(h)
        labels.append(cat.replace("\n", " "))

    fig.legend(
        handles, labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.925),
        ncol=min(len(labels), 5),
        frameon=False,
        fontsize=8.4,
        handletextpad=0.4,
        columnspacing=1.1,
    )

    title = "%s | Type-level %s | page %d/%d" % (
        group_name,
        ylabel,
        page_i,
        total_pages,
    )
    fig.suptitle(title, fontsize=14.0, fontweight="bold", y=0.985)

    fig.subplots_adjust(
        left=0.055,
        right=0.99,
        top=0.865,
        bottom=0.11,
        wspace=0.32,
        hspace=0.62,
    )

    out_subdir = FIG_DIR / safe_name(group_name)
    out_subdir.mkdir(parents=True, exist_ok=True)

    stem = "%s_%s_page%02d" % (safe_name(group_name), metric_tag, page_i)
    png = out_subdir / (stem + ".png")
    pdf = out_subdir / (stem + ".pdf")
    svg = out_subdir / (stem + ".svg")

    fig.savefig(png, dpi=DPI, bbox_inches="tight", facecolor="white")
    if SAVE_PDF:
        fig.savefig(pdf, bbox_inches="tight", facecolor="white")
    if SAVE_SVG:
        fig.savefig(svg, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    print("[FIGURE]", png)


def plot_group(group_df, group_name, group_configs, ordered_types):
    categories = [fmt_config(g, d) for g, d in group_configs] + ["ARG-OAP", "DeepARG"]

    per_page = FACET_NCOLS * FACET_NROWS
    pages = [ordered_types[i:i + per_page] for i in range(0, len(ordered_types), per_page)]
    total_pages = len(pages)

    metrics = []
    if MAKE_RAW_COUNT:
        metrics.append("Count")
    if MAKE_RELATIVE_ABUNDANCE:
        metrics.append("Relative_abundance_pct")
    if MAKE_LOG10_COUNT:
        metrics.append("log10_Count_plus1")

    for metric in metrics:
        for page_i, type_page in enumerate(pages, start=1):
            plot_one_page(
                group_df=group_df,
                group_name=group_name,
                categories=categories,
                type_page=type_page,
                page_i=page_i,
                total_pages=total_pages,
                metric=metric,
            )


def save_group_summary(group_df, group_name):
    summary = (
        group_df.groupby(["category", "Type"], as_index=False)
        .agg(
            n_samples=("sample", "nunique"),
            mean_count=("Count", "mean"),
            median_count=("Count", "median"),
            std_count=("Count", "std"),
            mean_relative_abundance_pct=("Relative_abundance_pct", "mean"),
            median_relative_abundance_pct=("Relative_abundance_pct", "median"),
        )
    )
    summary.to_csv(
        TABLE_DIR / (safe_name(group_name) + "_type_boxplot_summary.csv"),
        index=False, encoding="utf-8-sig"
    )


# =============================================================================
# 8. MAIN
# =============================================================================

def main():
    print("=" * 90)
    print("ARGScope / ARG-OAP / DeepARG Type-level boxplot + scatter")
    print("Multiple ARGScope parameter combinations per group")
    print("=" * 90)
    print("ROOT_DIR:", ROOT_DIR)
    print("OUT_DIR :", OUT_DIR)
    print("AUTO_GROUP_MODE:", AUTO_GROUP_MODE)
    print("CONFIGS_PER_GROUP:", CONFIGS_PER_GROUP)
    print()

    argscope = load_argscope_counts()
    argoap = load_argoap_counts()
    deeparg = load_deeparg_counts()

    configs = available_argscope_configs(argscope)
    print("\nAvailable ARGScope configurations:", len(configs))
    for g, d in configs:
        print("  gate=%.2f diamond=%.1f" % (g, d))

    groups = build_parameter_groups(configs)
    print("\nParameter groups:", len(groups))
    for name, cfgs in groups:
        print(" ", name, "=>", cfgs)

    selected_types = choose_types(argscope, argoap, deeparg)
    print("\nSelected cross-tool Types:", len(selected_types))
    print(selected_types)

    # Use common sample set to keep all boxes directly comparable.
    samples = set(argscope["sample"].astype(str))
    samples &= set(argoap["sample"].astype(str))
    samples &= set(deeparg["sample"].astype(str))
    samples = preferred_sample_order(samples)

    if not samples:
        raise RuntimeError("No common sample names across ARGScope, ARG-OAP and DeepARG.")

    print("\nCommon samples (%d):" % len(samples))
    for s in samples:
        print(" ", s)

    all_group_parts = []

    # Build all groups first so Type ordering can be consistent across figures.
    group_tables = []
    for group_name, group_configs in groups:
        gdf = build_group_long_table(
            argscope_df=argscope,
            argoap_df=argoap,
            deeparg_df=deeparg,
            group_name=group_name,
            group_configs=group_configs,
            types=selected_types,
            samples=samples,
        )
        group_tables.append((group_name, group_configs, gdf))
        all_group_parts.append(gdf)

    all_groups = pd.concat(all_group_parts, ignore_index=True)
    ordered_types = rank_types(all_groups, selected_types)

    pd.DataFrame({"Type": ordered_types, "plot_order": range(1, len(ordered_types) + 1)}).to_csv(
        TABLE_DIR / "Type_plot_order.csv",
        index=False, encoding="utf-8-sig"
    )

    for group_name, group_configs, gdf in group_tables:
        print("\n[PLOT GROUP]", group_name)
        gdf.to_csv(
            TABLE_DIR / (safe_name(group_name) + "_sample_type_values_long.csv"),
            index=False, encoding="utf-8-sig"
        )
        save_group_summary(gdf, group_name)
        plot_group(gdf, group_name, group_configs, ordered_types)

    all_groups.to_csv(
        TABLE_DIR / "ALL_parameter_groups_sample_type_values_long.csv",
        index=False, encoding="utf-8-sig"
    )

    print("\n" + "=" * 90)
    print("Done.")
    print("Figures:", FIG_DIR)
    print("Tables :", TABLE_DIR)
    print("=" * 90)


if __name__ == "__main__":
    main()
