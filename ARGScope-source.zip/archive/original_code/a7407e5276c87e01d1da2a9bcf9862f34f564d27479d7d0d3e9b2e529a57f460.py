#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARGScope joint 30aa/40aa/50aa Protein Student
=============================================

Design
------
This is the short-AA analogue of the previous 60p-100p model:

    50aa = anchor/full short-read view, analogous to 100p
    40aa = 0.8-length view, analogous to an incomplete-length view
    30aa = 0.6-length view, analogous to an incomplete-length view

All three lengths participate in:
    - Protein StandardScaler fitting
    - Fusion StandardScaler fitting
    - Fusion Teacher training
    - Protein Student training
    - validation early stopping
    - best-model selection

Training-time information:
    30aa/40aa/50aa Protein embeddings, 1280D
    30aa/40aa/50aa Fusion embeddings, 512D
    50aa refined subtype prototypes, 512D
    same-fragment pairing across Protein and Fusion
    base-ID relationship across five crops
    mean 50aa Fusion embedding as the parent/anchor representation

Inference-time information:
    Protein embedding + known AA length only

Expected files
--------------
1.30aa_all_fusion_embedding_512_with_label.csv
1.40aa_all_fusion_embedding_512_with_label.csv
1.50aa_all_fusion_embedding_512_with_label.csv

2.30aa_ARG_protein_with_label.csv
2.40aa_ARG_protein_with_label.csv
2.50aa_ARG_protein_with_label.csv

Preferred refined file:
4.50aa_Refined_embeddings_512.csv

Fallback refined file:
4.150nt_all_Refined_embeddings_512.csv

Splits:
train_set_shortread.csv
test_set_shortread.csv

Evaluation
----------
val_evaluation/
test_evaluation/
coverage_evaluation/

For every length:
    fragment predictions
    five-crop parent aggregation
    subtype metrics
    Type metrics
"""

from __future__ import annotations

import argparse
import copy
import gc
import json
import math
import os
import random
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
)
from sklearn.preprocessing import LabelEncoder, StandardScaler
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler


SCRIPT_VERSION = "ARGScope_joint_30aa40aa50aa_v1_2026-08-04"

LENGTH_ORDER = ["30aa", "40aa", "50aa"]
LENGTH_RATIO = {
    "30aa": 0.60,
    "40aa": 0.80,
    "50aa": 1.00,
}

PROTEIN_FILES = {
    "30aa": "2.30aa_ARG_protein_with_label.csv",
    "40aa": "2.40aa_ARG_protein_with_label.csv",
    "50aa": "2.50aa_ARG_protein_with_label.csv",
}

FUSION_FILES = {
    "30aa": "1.30aa_all_fusion_embedding_512_with_label.csv",
    "40aa": "1.40aa_all_fusion_embedding_512_with_label.csv",
    "50aa": "1.50aa_all_fusion_embedding_512_with_label.csv",
}

REFINED_PREFERRED = "4.50aa_Refined_embeddings_512.csv"
REFINED_FALLBACK = "4.150nt_all_Refined_embeddings_512.csv"

TRAIN_SPLIT_FILE = "train_set_shortread.csv"
TEST_SPLIT_FILE = "test_set_shortread.csv"

EXPECTED_PROTEIN_DIM = 1280
EXPECTED_FUSION_DIM = 512
EXPECTED_SUBTYPE_COUNT = 2825

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id",
    "NucleotideID", "ProteinID", "protein_id", "Protein_id",
    "Original_ID", "original_id", "read_id", "Read_ID",
]
TYPE_CANDIDATES = [
    "Type", "type", "TYPE", "ARG_type", "arg_type",
    "true_type", "True_Type",
]
SUBTYPE_CANDIDATES = [
    "Subtype", "subtype", "SUBTYPE", "ARG_subtype", "arg_subtype",
    "label", "Label", "LABEL", "true_subtype", "True_Subtype",
]
BASE_ID_CANDIDATES = [
    "base_id", "Base_ID", "BASE_ID", "baseid", "BaseID",
    "Parent_ID", "parent_id", "ParentID",
    "Original_base_id", "original_base_id",
    "Source_ID", "source_id", "Long_ID", "long_id",
]


@dataclass
class Config:
    data_dir: str
    output_dir: str

    seed: int = 281
    val_ratio: float = 0.12

    batch_size: int = 512
    eval_batch_size: int = 4096
    num_workers: int = 8

    teacher_hidden_dim: int = 768
    student_hidden_dim: int = 1024
    embed_dim: int = 512
    residual_blocks: int = 2
    dropout: float = 0.18

    teacher_epochs: int = 120
    student_epochs: int = 220
    teacher_patience: int = 20
    student_patience: int = 35

    teacher_lr: float = 3e-4
    student_lr: float = 1.5e-4
    weight_decay: float = 5e-5
    min_delta: float = 1e-5

    arcface_margin: float = 0.15
    logit_scale: float = 28.0
    label_smoothing: float = 0.003
    supcon_temperature: float = 0.10
    kd_temperature: float = 3.0

    teacher_ce_weight: float = 1.00
    teacher_supcon_weight: float = 0.20
    teacher_refined_weight: float = 0.02

    student_ce_weight: float = 1.00
    student_supcon_weight: float = 0.18
    same_view_align_weight: float = 0.22
    anchor_50aa_align_weight: float = 0.14
    same_view_kd_weight: float = 0.12
    anchor_50aa_kd_weight: float = 0.06
    student_refined_weight: float = 0.02

    use_refined_anchor: bool = True
    use_ema: bool = True
    ema_decay: float = 0.995

    class_weight_power: float = 0.18
    class_weight_clip_min: float = 0.85
    class_weight_clip_max: float = 1.50

    sampler_class_power: float = 0.20
    sampler_class_clip_min: float = 0.70
    sampler_class_clip_max: float = 2.00

    eval_every_teacher: int = 2
    eval_every_student: int = 2

    device: str = "auto"
    amp: bool = True
    validate_only: bool = False


def parse_args() -> Config:
    parser = argparse.ArgumentParser(
        description=(
            "Jointly train ARGScope on 30aa, 40aa and 50aa; "
            "50aa acts as the anchor view."
        )
    )
    parser.add_argument(
        "--data-dir",
        default="/scratch/users/ntu/pan.jie/work/ARGSCOPE_newmodel/traingdata",
    )
    parser.add_argument(
        "--output-dir",
        default=(
            "/scratch/users/ntu/pan.jie/work/ARGSCOPE_newmodel/"
            "ARGScope_joint_30aa40aa50aa_outputs"
        ),
    )
    parser.add_argument("--seed", type=int, default=281)
    parser.add_argument("--val-ratio", type=float, default=0.12)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--eval-batch-size", type=int, default=4096)
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--teacher-epochs", type=int, default=120)
    parser.add_argument("--student-epochs", type=int, default=220)
    parser.add_argument("--teacher-patience", type=int, default=20)
    parser.add_argument("--student-patience", type=int, default=35)
    parser.add_argument("--teacher-lr", type=float, default=3e-4)
    parser.add_argument("--student-lr", type=float, default=1.5e-4)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--no-refined-anchor", action="store_true")
    parser.add_argument("--validate-only", action="store_true")

    args = parser.parse_args()

    return Config(
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        seed=args.seed,
        val_ratio=args.val_ratio,
        batch_size=args.batch_size,
        eval_batch_size=args.eval_batch_size,
        num_workers=args.num_workers,
        teacher_epochs=args.teacher_epochs,
        student_epochs=args.student_epochs,
        teacher_patience=args.teacher_patience,
        student_patience=args.student_patience,
        teacher_lr=args.teacher_lr,
        student_lr=args.student_lr,
        device=args.device,
        amp=not args.no_amp,
        use_refined_anchor=not args.no_refined_anchor,
        validate_only=args.validate_only,
    )


# =============================================================================
# Utilities
# =============================================================================

def seed_everything(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True

    try:
        torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def resolve_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    device = torch.device(value)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable.")
    return device


def save_json(data: object, path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)


def normalize_series(series: pd.Series) -> pd.Series:
    return (
        series.astype(str)
        .str.replace("\ufeff", "", regex=False)
        .str.strip()
    )


def find_column(
    dataframe: pd.DataFrame,
    candidates: Sequence[str],
) -> Optional[str]:
    lower_map = {
        str(column).strip().casefold(): column
        for column in dataframe.columns
    }
    for candidate in candidates:
        found = lower_map.get(candidate.casefold())
        if found is not None:
            return found
    return None


def require_file(path: Path, description: str) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"{description} not found: {path}")


def natural_key(value: object):
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", str(value))
    ]


def feature_columns(dataframe: pd.DataFrame) -> List[str]:
    excluded = {
        "key", "id", "geneid", "nucleotideid", "proteinid",
        "protein_id", "original_id", "read_id",
        "type", "subtype", "arg_type", "arg_subtype",
        "label", "count", "split", "base_id", "parent_id",
        "crop_index", "length_name", "length_ratio",
    }

    columns = []
    for column in dataframe.columns:
        text = str(column).strip()
        if text.casefold() in excluded:
            continue
        if text.casefold().startswith("unnamed:"):
            continue
        if pd.api.types.is_numeric_dtype(dataframe[column]):
            columns.append(column)

    return sorted(columns, key=natural_key)


def numeric_matrix(
    dataframe: pd.DataFrame,
    columns: Sequence[str],
    expected_dimension: int,
    description: str,
) -> np.ndarray:
    if len(columns) != expected_dimension:
        raise ValueError(
            f"{description}: expected {expected_dimension} features, "
            f"found {len(columns)}"
        )

    numeric = dataframe[list(columns)].apply(
        pd.to_numeric,
        errors="coerce",
    )
    if numeric.isna().any().any():
        positions = np.argwhere(
            numeric.isna().to_numpy()
        )[:10].tolist()
        raise ValueError(
            f"{description}: nonnumeric/missing values at {positions}"
        )

    matrix = numeric.to_numpy(dtype=np.float32, copy=True)
    if not np.isfinite(matrix).all():
        raise ValueError(f"{description}: contains NaN/Inf.")
    if np.any(np.linalg.norm(matrix, axis=1) <= 1e-12):
        raise ValueError(f"{description}: contains all-zero rows.")
    return matrix


def transform_chunks(
    scaler: StandardScaler,
    matrix: np.ndarray,
    chunk_size: int = 50000,
) -> np.ndarray:
    output = np.empty_like(matrix, dtype=np.float32)
    for start in range(0, len(matrix), chunk_size):
        end = min(start + chunk_size, len(matrix))
        output[start:end] = scaler.transform(
            matrix[start:end]
        ).astype(np.float32)
    return output


def l2_normalize_np(
    matrix: np.ndarray,
    eps: float = 1e-12,
) -> np.ndarray:
    norm = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.maximum(norm, eps)


def make_grad_scaler(enabled: bool):
    return torch.amp.GradScaler("cuda", enabled=enabled)


def autocast_cuda(enabled: bool):
    return torch.amp.autocast(
        device_type="cuda",
        enabled=enabled,
    )


def infer_base_id(keys: pd.Series) -> pd.Series:
    """
    Expanded fragments usually end in _1 ... _5.
    """
    return normalize_series(keys).str.replace(
        r"(?:_part|_crop|_fragment)?[_-]?([1-5])$",
        "",
        regex=True,
    )


# =============================================================================
# Split handling
# =============================================================================

def read_short_split(path: Path, description: str) -> pd.DataFrame:
    require_file(path, description)

    dataframe = pd.read_csv(path, low_memory=False)
    dataframe.columns = [
        str(column).replace("\ufeff", "").strip()
        for column in dataframe.columns
    ]

    key_column = find_column(dataframe, KEY_CANDIDATES)
    if key_column is None:
        raise ValueError(
            f"{description}: no ID column. "
            f"Columns={dataframe.columns.tolist()}"
        )

    base_column = find_column(dataframe, BASE_ID_CANDIDATES)

    output = pd.DataFrame(
        {"KEY": normalize_series(dataframe[key_column])}
    )

    if base_column is not None:
        output["base_id"] = normalize_series(
            dataframe[base_column]
        )
    else:
        output["base_id"] = infer_base_id(output["KEY"])

    if output["KEY"].duplicated().any():
        examples = output.loc[
            output["KEY"].duplicated(keep=False),
            "KEY",
        ].head(20).tolist()
        raise ValueError(
            f"{description}: duplicate IDs. Examples={examples}"
        )

    return output


def build_base_split(
    parent_labels: pd.DataFrame,
    train_path: Path,
    test_path: Path,
    validation_ratio: float,
    seed: int,
) -> pd.DataFrame:
    train_file = read_short_split(
        train_path,
        "train_set_shortread.csv",
    )
    test_file = read_short_split(
        test_path,
        "test_set_shortread.csv",
    )

    train_base_ids = set(train_file["base_id"])
    coverage_base_ids = set(test_file["base_id"])
    overlap_base_ids = train_base_ids & coverage_base_ids
    independent_test_ids = coverage_base_ids - train_base_ids

    print("\nShort-read base-ID relationships:")
    print(f"  train base IDs:             {len(train_base_ids):,}")
    print(f"  coverage test base IDs:     {len(coverage_base_ids):,}")
    print(f"  train/test overlap:         {len(overlap_base_ids):,}")
    print(f"  independent test base IDs:  {len(independent_test_ids):,}")

    available_ids = set(parent_labels["base_id"])
    missing_train = sorted(train_base_ids - available_ids)
    missing_test = sorted(coverage_base_ids - available_ids)

    if missing_train or missing_test:
        raise ValueError(
            "Split IDs are absent from the 50aa reference data. "
            f"missing_train={len(missing_train)}, "
            f"missing_test={len(missing_test)}, "
            f"train_examples={missing_train[:10]}, "
            f"test_examples={missing_test[:10]}"
        )

    uncovered = sorted(
        available_ids - train_base_ids - coverage_base_ids
    )
    if uncovered:
        raise ValueError(
            f"{len(uncovered)} base IDs are not assigned by the "
            f"short-read split. Examples={uncovered[:20]}"
        )

    validation_candidates = train_base_ids - overlap_base_ids
    candidate_frame = parent_labels[
        parent_labels["base_id"].isin(validation_candidates)
    ].copy()

    rng = np.random.default_rng(seed)
    validation_ids: List[str] = []

    for subtype, group in candidate_frame.groupby(
        "Subtype",
        sort=True,
    ):
        ids = group["base_id"].to_numpy(copy=True)
        rng.shuffle(ids)
        count = len(ids)

        if count < 5:
            continue

        total_train_support = int(
            (
                parent_labels["base_id"].isin(train_base_ids)
                & (parent_labels["Subtype"] == subtype)
            ).sum()
        )

        validation_count = max(
            1,
            int(round(count * validation_ratio)),
        )
        validation_count = min(
            validation_count,
            count - 1,
            total_train_support - 1,
        )

        if validation_count > 0:
            validation_ids.extend(
                ids[:validation_count].tolist()
            )

    validation_set = set(validation_ids)
    effective_train_ids = train_base_ids - validation_set

    rows = []
    for row in parent_labels.itertuples(index=False):
        base_id = row.base_id
        in_train_file = base_id in train_base_ids
        in_coverage_test = base_id in coverage_base_ids
        is_overlap = base_id in overlap_base_ids

        if base_id in validation_set:
            split = "val"
        elif base_id in effective_train_ids:
            split = "train"
        elif base_id in independent_test_ids:
            split = "test"
        else:
            raise RuntimeError(f"Unassigned base ID: {base_id}")

        rows.append(
            {
                "base_id": base_id,
                "Type": row.Type,
                "Subtype": row.Subtype,
                "split": split,
                "in_train_file": bool(in_train_file),
                "in_coverage_test": bool(in_coverage_test),
                "is_train_test_overlap": bool(is_overlap),
            }
        )

    result = pd.DataFrame(rows)

    train_subtypes = set(
        result.loc[result["split"] == "train", "Subtype"]
    )
    outside_subtypes = set(
        result.loc[result["split"] != "train", "Subtype"]
    )
    missing_subtypes = sorted(
        outside_subtypes - train_subtypes
    )
    if missing_subtypes:
        raise ValueError(
            "Validation/test include subtypes absent from training. "
            f"Examples={missing_subtypes[:20]}"
        )

    print("\nEffective base split:")
    print(
        result.groupby("split")
        .agg(
            base_ids=("base_id", "size"),
            Types=("Type", "nunique"),
            Subtypes=("Subtype", "nunique"),
        )
        .reset_index()
        .to_string(index=False)
    )
    print(
        f"Coverage base IDs: "
        f"{int(result['in_coverage_test'].sum()):,}; "
        f"overlap base IDs: "
        f"{int(result['is_train_test_overlap'].sum()):,}"
    )

    return result


# =============================================================================
# Data loading
# =============================================================================

def read_embedding(
    path: Path,
    description: str,
    expected_dimension: int,
) -> Tuple[pd.DataFrame, np.ndarray]:
    require_file(path, description)
    print(f"Reading {description}: {path}")

    dataframe = pd.read_csv(path, low_memory=False)
    dataframe.columns = [
        str(column).replace("\ufeff", "").strip()
        for column in dataframe.columns
    ]

    key_column = find_column(dataframe, KEY_CANDIDATES)
    type_column = find_column(dataframe, TYPE_CANDIDATES)
    subtype_column = find_column(
        dataframe,
        SUBTYPE_CANDIDATES,
    )

    if key_column is None:
        raise ValueError(f"{description}: no ID column.")
    if type_column is None or subtype_column is None:
        raise ValueError(
            f"{description}: Type and Subtype columns are required."
        )

    dataframe[key_column] = normalize_series(
        dataframe[key_column]
    )
    dataframe[type_column] = normalize_series(
        dataframe[type_column]
    )
    dataframe[subtype_column] = normalize_series(
        dataframe[subtype_column]
    )

    if dataframe[key_column].duplicated().any():
        examples = dataframe.loc[
            dataframe[key_column].duplicated(keep=False),
            key_column,
        ].head(20).tolist()
        raise ValueError(
            f"{description}: duplicate IDs. Examples={examples}"
        )

    columns = feature_columns(dataframe)
    matrix = numeric_matrix(
        dataframe,
        columns,
        expected_dimension,
        description,
    )

    metadata = pd.DataFrame(
        {
            "KEY": dataframe[key_column],
            "base_id": infer_base_id(dataframe[key_column]),
            "Type": dataframe[type_column],
            "Subtype": dataframe[subtype_column],
        }
    )
    metadata["crop_index"] = pd.to_numeric(
        metadata["KEY"].str.extract(
            r"([1-5])$",
            expand=False,
        ),
        errors="coerce",
    ).fillna(-1).astype(int)

    del dataframe
    gc.collect()

    print(
        f"{description}: rows={len(metadata):,}, "
        f"base_ids={metadata['base_id'].nunique():,}, "
        f"dimension={matrix.shape[1]}"
    )

    return metadata, matrix


def align_to_reference(
    reference_metadata: pd.DataFrame,
    target_metadata: pd.DataFrame,
    target_matrix: np.ndarray,
    description: str,
) -> Tuple[pd.DataFrame, np.ndarray]:
    reference_keys = reference_metadata["KEY"].tolist()
    reference_set = set(reference_keys)
    target_set = set(target_metadata["KEY"])

    if reference_set != target_set:
        raise ValueError(
            f"{description}: ID set differs from the 50aa reference. "
            f"reference_only={len(reference_set - target_set)}, "
            f"target_only={len(target_set - reference_set)}"
        )

    target_index = pd.Series(
        np.arange(len(target_metadata), dtype=np.int64),
        index=target_metadata["KEY"],
    )
    order = target_index.loc[
        reference_keys
    ].to_numpy(dtype=np.int64)

    aligned_metadata = target_metadata.iloc[
        order
    ].reset_index(drop=True)
    aligned_matrix = target_matrix[order]

    for column in [
        "base_id",
        "Type",
        "Subtype",
        "crop_index",
    ]:
        mismatch = (
            reference_metadata[column].to_numpy()
            != aligned_metadata[column].to_numpy()
        )
        if mismatch.any():
            examples = pd.DataFrame(
                {
                    "KEY": reference_metadata.loc[
                        mismatch,
                        "KEY",
                    ].head(10),
                    "reference": reference_metadata.loc[
                        mismatch,
                        column,
                    ].head(10),
                    "target": aligned_metadata.loc[
                        mismatch,
                        column,
                    ].head(10),
                }
            ).to_dict("records")
            raise ValueError(
                f"{description}: {column} mismatch. "
                f"Examples={examples}"
            )

    return aligned_metadata, aligned_matrix


def load_all_data(
    data_dir: Path,
) -> Tuple[
    Dict[str, pd.DataFrame],
    Dict[str, np.ndarray],
    Dict[str, np.ndarray],
]:
    metadata: Dict[str, pd.DataFrame] = {}
    protein_raw: Dict[str, np.ndarray] = {}
    fusion_raw: Dict[str, np.ndarray] = {}

    reference_metadata, reference_protein = read_embedding(
        data_dir / PROTEIN_FILES["50aa"],
        "50aa Protein",
        EXPECTED_PROTEIN_DIM,
    )
    metadata["50aa"] = reference_metadata
    protein_raw["50aa"] = reference_protein

    for length_name in ["30aa", "40aa"]:
        current_metadata, current_matrix = read_embedding(
            data_dir / PROTEIN_FILES[length_name],
            f"{length_name} Protein",
            EXPECTED_PROTEIN_DIM,
        )
        current_metadata, current_matrix = align_to_reference(
            reference_metadata,
            current_metadata,
            current_matrix,
            f"{length_name} Protein",
        )
        metadata[length_name] = current_metadata
        protein_raw[length_name] = current_matrix

    for length_name in LENGTH_ORDER:
        current_metadata, current_matrix = read_embedding(
            data_dir / FUSION_FILES[length_name],
            f"{length_name} Fusion",
            EXPECTED_FUSION_DIM,
        )
        current_metadata, current_matrix = align_to_reference(
            reference_metadata,
            current_metadata,
            current_matrix,
            f"{length_name} Fusion",
        )
        fusion_raw[length_name] = current_matrix

    # Validate five crops per base for every length.
    for length_name in LENGTH_ORDER:
        counts = metadata[length_name].groupby(
            "base_id"
        ).size()
        bad = counts[counts != 5]
        if len(bad) > 0:
            raise ValueError(
                f"{length_name}: expected five crops per base ID. "
                f"{len(bad)} base IDs differ. "
                f"Examples={bad.head(20).to_dict()}"
            )

    return metadata, protein_raw, fusion_raw


def build_parent_labels(
    reference_metadata: pd.DataFrame,
) -> pd.DataFrame:
    consistency = (
        reference_metadata.groupby("base_id")
        .agg(
            Type_count=("Type", "nunique"),
            Subtype_count=("Subtype", "nunique"),
        )
    )

    bad = consistency[
        (consistency["Type_count"] != 1)
        | (consistency["Subtype_count"] != 1)
    ]
    if len(bad) > 0:
        raise ValueError(
            f"{len(bad)} base IDs have inconsistent labels."
        )

    labels = (
        reference_metadata[
            ["base_id", "Type", "Subtype"]
        ]
        .drop_duplicates("base_id")
        .reset_index(drop=True)
    )

    subtype_type_count = labels.groupby(
        "Subtype"
    )["Type"].nunique()
    conflicts = subtype_type_count[
        subtype_type_count > 1
    ]
    if len(conflicts) > 0:
        raise ValueError(
            f"{len(conflicts)} subtypes map to multiple Types."
        )

    return labels


def attach_split(
    metadata: Dict[str, pd.DataFrame],
    base_split: pd.DataFrame,
) -> Dict[str, pd.DataFrame]:
    split_columns = [
        "base_id",
        "split",
        "in_train_file",
        "in_coverage_test",
        "is_train_test_overlap",
    ]

    output = {}
    for length_name in LENGTH_ORDER:
        current = metadata[length_name].merge(
            base_split[split_columns],
            on="base_id",
            how="left",
            validate="many_to_one",
        )
        if current["split"].isna().any():
            raise ValueError(
                f"{length_name}: rows without inherited split."
            )
        current["length_name"] = length_name
        current["length_ratio"] = LENGTH_RATIO[length_name]
        output[length_name] = current

    return output


def concatenate_lengths(
    metadata: Dict[str, pd.DataFrame],
    protein_raw: Dict[str, np.ndarray],
    fusion_raw: Dict[str, np.ndarray],
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    metadata_parts = []
    protein_parts = []
    fusion_parts = []

    for length_name in LENGTH_ORDER:
        metadata_parts.append(metadata[length_name])
        protein_parts.append(protein_raw[length_name])
        fusion_parts.append(fusion_raw[length_name])

    combined_metadata = pd.concat(
        metadata_parts,
        ignore_index=True,
    )
    combined_protein = np.concatenate(
        protein_parts,
        axis=0,
    ).astype(np.float32)
    combined_fusion = np.concatenate(
        fusion_parts,
        axis=0,
    ).astype(np.float32)

    print("\nCombined joint dataset:")
    print(
        combined_metadata.groupby(
            ["split", "length_name"]
        )
        .agg(
            rows=("KEY", "size"),
            base_ids=("base_id", "nunique"),
            Types=("Type", "nunique"),
            Subtypes=("Subtype", "nunique"),
        )
        .reset_index()
        .to_string(index=False)
    )

    return (
        combined_metadata,
        combined_protein,
        combined_fusion,
    )


# =============================================================================
# Labels, scalers and prototypes
# =============================================================================

def build_labels(
    combined_metadata: pd.DataFrame,
    out_dir: Path,
) -> Tuple[LabelEncoder, np.ndarray, Dict[str, str]]:
    training_subtypes = sorted(
        combined_metadata.loc[
            combined_metadata["split"] == "train",
            "Subtype",
        ].unique()
    )

    encoder = LabelEncoder()
    encoder.fit(training_subtypes)

    if len(encoder.classes_) != EXPECTED_SUBTYPE_COUNT:
        raise ValueError(
            f"Training contains {len(encoder.classes_)} subtypes; "
            f"expected {EXPECTED_SUBTYPE_COUNT}."
        )

    unseen = sorted(
        set(combined_metadata["Subtype"])
        - set(encoder.classes_)
    )
    if unseen:
        raise ValueError(
            f"Subtypes outside training: {unseen[:20]}"
        )

    labels = encoder.transform(
        combined_metadata["Subtype"]
    ).astype(np.int64)

    mapping = (
        combined_metadata[["Subtype", "Type"]]
        .drop_duplicates()
        .sort_values(["Type", "Subtype"])
        .reset_index(drop=True)
    )

    if mapping["Subtype"].duplicated().any():
        raise ValueError(
            "A subtype maps to multiple Types."
        )

    subtype_to_type = dict(
        zip(mapping["Subtype"], mapping["Type"])
    )

    joblib.dump(
        encoder,
        out_dir / "subtype_encoder.joblib",
    )
    mapping.to_csv(
        out_dir / "subtype_type_map.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return encoder, labels, subtype_to_type


def scaler_fit_indices(
    metadata: pd.DataFrame,
) -> np.ndarray:
    training = metadata[
        metadata["split"] == "train"
    ].copy()

    # Equal contribution from every base and every AA length.
    # One crop per base and length is used for fitting the scalers.
    indices = (
        training.sort_values(
            [
                "base_id",
                "length_name",
                "crop_index",
                "KEY",
            ]
        )
        .groupby(
            ["base_id", "length_name"],
            sort=False,
        )
        .head(1)
        .index
        .to_numpy(dtype=np.int64)
    )

    return indices


def fit_scalers(
    metadata: pd.DataFrame,
    protein_raw: np.ndarray,
    fusion_raw: np.ndarray,
    out_dir: Path,
) -> Tuple[
    np.ndarray,
    np.ndarray,
    StandardScaler,
    StandardScaler,
]:
    fit_indices = scaler_fit_indices(metadata)

    print(
        f"\nScaler fitting rows: {len(fit_indices):,} "
        "(30aa + 40aa + 50aa, length-balanced)"
    )

    protein_scaler = StandardScaler()
    fusion_scaler = StandardScaler()

    protein_scaler.fit(protein_raw[fit_indices])
    fusion_scaler.fit(fusion_raw[fit_indices])

    protein_scaled = transform_chunks(
        protein_scaler,
        protein_raw,
    )
    fusion_scaled = transform_chunks(
        fusion_scaler,
        fusion_raw,
    )

    joblib.dump(
        protein_scaler,
        out_dir / "protein_scaler_30aa40aa50aa.joblib",
    )
    joblib.dump(
        fusion_scaler,
        out_dir / "fusion_scaler_30aa40aa50aa.joblib",
    )

    return (
        protein_scaled,
        fusion_scaled,
        protein_scaler,
        fusion_scaler,
    )


def choose_refined_file(data_dir: Path) -> Optional[Path]:
    preferred = data_dir / REFINED_PREFERRED
    fallback = data_dir / REFINED_FALLBACK

    if preferred.is_file():
        print(f"Using refined prototype file: {preferred}")
        return preferred
    if fallback.is_file():
        print(
            f"Preferred refined file is absent; "
            f"using fallback: {fallback}"
        )
        return fallback

    print(
        "WARNING: neither 50aa nor 150nt refined prototype "
        "file was found. Training will continue without "
        "refined prototype regularization."
    )
    return None


def load_refined(
    path: Optional[Path],
    encoder: LabelEncoder,
    fusion_scaler: StandardScaler,
    enabled: bool,
) -> Optional[np.ndarray]:
    if not enabled or path is None:
        return None

    dataframe = pd.read_csv(path, low_memory=False)
    dataframe.columns = [
        str(column).replace("\ufeff", "").strip()
        for column in dataframe.columns
    ]

    subtype_column = find_column(
        dataframe,
        SUBTYPE_CANDIDATES,
    )
    if subtype_column is None:
        raise ValueError(
            f"{path.name}: no Subtype column."
        )

    dataframe[subtype_column] = normalize_series(
        dataframe[subtype_column]
    )

    columns = feature_columns(dataframe)
    if len(columns) != EXPECTED_FUSION_DIM:
        raise ValueError(
            f"{path.name}: expected {EXPECTED_FUSION_DIM} "
            f"features, found {len(columns)}."
        )

    numeric = dataframe[columns].apply(
        pd.to_numeric,
        errors="coerce",
    )
    if numeric.isna().any().any():
        raise ValueError(
            f"{path.name}: nonnumeric/missing values."
        )

    temporary = pd.concat(
        [
            dataframe[[subtype_column]].rename(
                columns={subtype_column: "Subtype"}
            ),
            numeric,
        ],
        axis=1,
    )
    grouped = temporary.groupby(
        "Subtype"
    )[columns].mean()

    missing = [
        subtype
        for subtype in encoder.classes_
        if subtype not in grouped.index
    ]
    if missing:
        raise ValueError(
            f"{path.name}: missing {len(missing)} subtypes. "
            f"Examples={missing[:20]}"
        )

    matrix = np.stack(
        [
            grouped.loc[subtype].to_numpy(
                dtype=np.float32
            )
            for subtype in encoder.classes_
        ],
        axis=0,
    )

    matrix = fusion_scaler.transform(
        matrix
    ).astype(np.float32)
    matrix = l2_normalize_np(
        matrix
    ).astype(np.float32)

    print(
        f"Loaded refined subtype prototypes: {matrix.shape}"
    )
    return matrix


def build_anchor_50aa_fusion(
    metadata: pd.DataFrame,
    fusion_scaled: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    anchor_rows = metadata[
        metadata["length_name"] == "50aa"
    ].copy()
    anchor_rows["combined_index"] = anchor_rows.index

    base_ids = sorted(
        metadata["base_id"].unique()
    )
    base_to_index = {
        base_id: index
        for index, base_id in enumerate(base_ids)
    }

    anchors = np.zeros(
        (len(base_ids), EXPECTED_FUSION_DIM),
        dtype=np.float32,
    )

    for base_id, group in anchor_rows.groupby(
        "base_id",
        sort=False,
    ):
        combined_indices = group[
            "combined_index"
        ].to_numpy(dtype=np.int64)
        mean_embedding = fusion_scaled[
            combined_indices
        ].mean(axis=0)
        anchors[
            base_to_index[base_id]
        ] = mean_embedding.astype(np.float32)

    row_to_base_index = (
        metadata["base_id"]
        .map(base_to_index)
        .to_numpy(dtype=np.int64)
    )

    return anchors, row_to_base_index, base_ids


# =============================================================================
# Dataset and sampling
# =============================================================================

class JointDataset(Dataset):
    def __init__(
        self,
        protein: np.ndarray,
        fusion: np.ndarray,
        labels: np.ndarray,
        length_ratio: np.ndarray,
        row_to_base_index: np.ndarray,
        anchor_50aa_fusion: np.ndarray,
        selected_indices: np.ndarray,
    ) -> None:
        self.protein = torch.from_numpy(protein)
        self.fusion = torch.from_numpy(fusion)
        self.labels = torch.from_numpy(
            labels.astype(np.int64)
        )
        self.length_ratio = torch.from_numpy(
            length_ratio.astype(np.float32)
        )
        self.row_to_base_index = torch.from_numpy(
            row_to_base_index.astype(np.int64)
        )
        self.anchor_50aa_fusion = torch.from_numpy(
            anchor_50aa_fusion
        )
        self.selected_indices = torch.from_numpy(
            selected_indices.astype(np.int64)
        )

    def __len__(self) -> int:
        return len(self.selected_indices)

    def __getitem__(self, index: int):
        row = self.selected_indices[index]
        base_index = self.row_to_base_index[row]

        return (
            self.protein[row],
            self.fusion[row],
            self.labels[row],
            self.length_ratio[row],
            self.anchor_50aa_fusion[base_index],
            row,
        )


def mild_class_weights(
    labels: np.ndarray,
    num_classes: int,
    power: float,
    clip_min: float,
    clip_max: float,
) -> np.ndarray:
    counts = np.bincount(
        labels,
        minlength=num_classes,
    ).astype(np.float64)

    if np.any(counts == 0):
        missing = np.where(counts == 0)[0].tolist()
        raise ValueError(
            f"Training lacks classes: {missing[:20]}"
        )

    weights = (counts.mean() / counts) ** power
    weights = weights / weights.mean()
    weights = np.clip(
        weights,
        clip_min,
        clip_max,
    )

    return weights.astype(np.float32)


def make_balanced_sampler(
    metadata: pd.DataFrame,
    labels: np.ndarray,
    selected_indices: np.ndarray,
    cfg: Config,
) -> WeightedRandomSampler:
    selected = metadata.loc[
        selected_indices
    ].copy()
    selected["class_id"] = labels[
        selected_indices
    ]

    crop_count = (
        selected.groupby(
            ["base_id", "length_name"]
        )["KEY"]
        .transform("size")
        .to_numpy(dtype=np.float64)
    )

    length_balance = 1.0 / np.maximum(
        crop_count,
        1.0,
    )

    base_label = selected[
        ["base_id", "class_id"]
    ].drop_duplicates("base_id")

    base_class_counts = (
        base_label["class_id"]
        .value_counts()
        .to_dict()
    )
    mean_count = float(
        np.mean(list(base_class_counts.values()))
    )

    class_factor_map = {
        class_id: np.clip(
            (mean_count / count)
            ** cfg.sampler_class_power,
            cfg.sampler_class_clip_min,
            cfg.sampler_class_clip_max,
        )
        for class_id, count in base_class_counts.items()
    }

    class_factor = (
        selected["class_id"]
        .map(class_factor_map)
        .to_numpy(dtype=np.float64)
    )

    weights = length_balance * class_factor

    base_count = selected["base_id"].nunique()
    length_count = selected["length_name"].nunique()
    samples_per_epoch = base_count * length_count

    print(
        f"Balanced sampler: source_rows={len(selected):,}, "
        f"base_ids={base_count:,}, lengths={length_count}, "
        f"samples_per_epoch={samples_per_epoch:,}"
    )

    return WeightedRandomSampler(
        weights=torch.tensor(
            weights,
            dtype=torch.double,
        ),
        num_samples=int(samples_per_epoch),
        replacement=True,
    )


def make_loader(
    dataset: Dataset,
    batch_size: int,
    device: torch.device,
    num_workers: int,
    sampler=None,
    shuffle: bool = False,
) -> DataLoader:
    arguments = {
        "dataset": dataset,
        "batch_size": batch_size,
        "sampler": sampler,
        "shuffle": shuffle if sampler is None else False,
        "num_workers": num_workers,
        "pin_memory": device.type == "cuda",
        "drop_last": False,
    }

    if num_workers > 0:
        arguments["persistent_workers"] = True
        arguments["prefetch_factor"] = 2

    return DataLoader(**arguments)


# =============================================================================
# Models and losses
# =============================================================================

class ResidualBlock(nn.Module):
    def __init__(
        self,
        dimension: int,
        dropout: float,
    ) -> None:
        super().__init__()

        self.network = nn.Sequential(
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dimension, dimension),
            nn.LayerNorm(dimension),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return F.gelu(x + self.network(x))


class Encoder(nn.Module):
    def __init__(
        self,
        input_dimension: int,
        hidden_dimension: int,
        embedding_dimension: int,
        dropout: float,
        residual_blocks: int,
    ) -> None:
        super().__init__()

        self.input_layer = nn.Sequential(
            nn.Linear(
                input_dimension,
                hidden_dimension,
            ),
            nn.LayerNorm(hidden_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(
            *[
                ResidualBlock(
                    hidden_dimension,
                    dropout,
                )
                for _ in range(residual_blocks)
            ]
        )

        self.output_layer = nn.Sequential(
            nn.Linear(
                hidden_dimension,
                embedding_dimension,
            ),
            nn.LayerNorm(embedding_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        hidden = self.input_layer(x)
        hidden = self.blocks(hidden)
        embedding = self.output_layer(hidden)
        return F.normalize(
            embedding,
            p=2,
            dim=1,
        )


class LengthConditionedProteinEncoder(nn.Module):
    def __init__(
        self,
        protein_dimension: int,
        hidden_dimension: int,
        embedding_dimension: int,
        dropout: float,
        residual_blocks: int,
    ) -> None:
        super().__init__()

        self.protein_layer = nn.Sequential(
            nn.Linear(
                protein_dimension,
                hidden_dimension,
            ),
            nn.LayerNorm(hidden_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.length_layer = nn.Sequential(
            nn.Linear(1, 32),
            nn.GELU(),
            nn.Linear(32, 64),
            nn.LayerNorm(64),
            nn.GELU(),
        )

        self.merge_layer = nn.Sequential(
            nn.Linear(
                hidden_dimension + 64,
                hidden_dimension,
            ),
            nn.LayerNorm(hidden_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(
            *[
                ResidualBlock(
                    hidden_dimension,
                    dropout,
                )
                for _ in range(residual_blocks)
            ]
        )

        self.output_layer = nn.Sequential(
            nn.Linear(
                hidden_dimension,
                embedding_dimension,
            ),
            nn.LayerNorm(embedding_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        protein: torch.Tensor,
        length_ratio: torch.Tensor,
    ) -> torch.Tensor:
        protein_hidden = self.protein_layer(protein)
        length_hidden = self.length_layer(
            length_ratio.view(-1, 1)
        )
        hidden = self.merge_layer(
            torch.cat(
                [protein_hidden, length_hidden],
                dim=1,
            )
        )
        hidden = self.blocks(hidden)
        embedding = self.output_layer(hidden)

        return F.normalize(
            embedding,
            p=2,
            dim=1,
        )


class ArcMarginHead(nn.Module):
    def __init__(
        self,
        embedding_dimension: int,
        num_classes: int,
        scale: float,
        margin: float,
    ) -> None:
        super().__init__()

        self.weight = nn.Parameter(
            torch.empty(
                num_classes,
                embedding_dimension,
            )
        )
        nn.init.xavier_uniform_(self.weight)

        self.scale = float(scale)
        self.margin = float(margin)
        self.cos_margin = math.cos(margin)
        self.sin_margin = math.sin(margin)
        self.threshold = math.cos(
            math.pi - margin
        )
        self.margin_correction = (
            math.sin(math.pi - margin) * margin
        )

    def forward(
        self,
        embedding: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        embedding = F.normalize(
            embedding,
            p=2,
            dim=1,
        )
        weight = F.normalize(
            self.weight,
            p=2,
            dim=1,
        )
        cosine = F.linear(
            embedding,
            weight,
        )

        if labels is None:
            return cosine * self.scale

        cosine_float = cosine.float()
        sine = torch.sqrt(
            torch.clamp(
                1.0 - cosine_float.pow(2),
                min=1e-7,
            )
        )
        phi = (
            cosine_float * self.cos_margin
            - sine * self.sin_margin
        )
        phi = torch.where(
            cosine_float > self.threshold,
            phi,
            cosine_float - self.margin_correction,
        )

        one_hot = torch.zeros_like(
            cosine_float
        )
        one_hot.scatter_(
            1,
            labels.view(-1, 1),
            1.0,
        )

        output = (
            one_hot * phi
            + (1.0 - one_hot) * cosine_float
        )
        return output * self.scale

    def normalized_weight(self) -> torch.Tensor:
        return F.normalize(
            self.weight.float(),
            p=2,
            dim=1,
        )


class FusionTeacher(nn.Module):
    def __init__(
        self,
        cfg: Config,
        num_classes: int,
    ) -> None:
        super().__init__()

        self.encoder = Encoder(
            input_dimension=EXPECTED_FUSION_DIM,
            hidden_dimension=cfg.teacher_hidden_dim,
            embedding_dimension=cfg.embed_dim,
            dropout=cfg.dropout,
            residual_blocks=cfg.residual_blocks,
        )
        self.head = ArcMarginHead(
            embedding_dimension=cfg.embed_dim,
            num_classes=num_classes,
            scale=cfg.logit_scale,
            margin=cfg.arcface_margin,
        )

    def forward(
        self,
        fusion: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ):
        embedding = self.encoder(fusion)
        margin_logits = self.head(
            embedding,
            labels,
        )
        plain_logits = self.head(
            embedding,
            None,
        )
        return margin_logits, plain_logits, embedding


class ProteinStudent(nn.Module):
    def __init__(
        self,
        cfg: Config,
        num_classes: int,
    ) -> None:
        super().__init__()

        self.encoder = LengthConditionedProteinEncoder(
            protein_dimension=EXPECTED_PROTEIN_DIM,
            hidden_dimension=cfg.student_hidden_dim,
            embedding_dimension=cfg.embed_dim,
            dropout=cfg.dropout,
            residual_blocks=cfg.residual_blocks,
        )
        self.head = ArcMarginHead(
            embedding_dimension=cfg.embed_dim,
            num_classes=num_classes,
            scale=cfg.logit_scale,
            margin=cfg.arcface_margin,
        )

    def forward(
        self,
        protein: torch.Tensor,
        length_ratio: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ):
        embedding = self.encoder(
            protein,
            length_ratio,
        )
        margin_logits = self.head(
            embedding,
            labels,
        )
        plain_logits = self.head(
            embedding,
            None,
        )
        return margin_logits, plain_logits, embedding


def supervised_contrastive_loss(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    with torch.amp.autocast(
        device_type=embeddings.device.type,
        enabled=False,
    ):
        normalized = F.normalize(
            embeddings.float(),
            p=2,
            dim=1,
        )
        labels = labels.long()

        logits = (
            normalized @ normalized.T
        ) / float(temperature)

        sample_count = logits.size(0)
        identity = torch.eye(
            sample_count,
            dtype=torch.bool,
            device=logits.device,
        )
        logits = logits.masked_fill(
            identity,
            -1e9,
        )

        positive_mask = (
            labels.unsqueeze(0)
            .eq(labels.unsqueeze(1))
            & ~identity
        )
        positive_count = positive_mask.sum(dim=1)
        valid = positive_count > 0

        if not bool(valid.any()):
            return logits.new_zeros(())

        log_probability = (
            logits
            - torch.logsumexp(
                logits,
                dim=1,
                keepdim=True,
            )
        )
        positive_log_probability = torch.where(
            positive_mask,
            log_probability,
            torch.zeros_like(log_probability),
        )
        mean_positive = (
            positive_log_probability.sum(dim=1)
            / positive_count.clamp_min(1)
        )

        return -mean_positive[valid].mean()


def cosine_pull_loss(
    student_embedding: torch.Tensor,
    teacher_embedding: torch.Tensor,
    sample_weight: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    student = F.normalize(
        student_embedding.float(),
        p=2,
        dim=1,
    )
    teacher = F.normalize(
        teacher_embedding.float(),
        p=2,
        dim=1,
    )

    row_loss = 1.0 - torch.sum(
        student * teacher,
        dim=1,
    )

    if sample_weight is None:
        return row_loss.mean()

    weights = sample_weight.float()
    return (
        torch.sum(row_loss * weights)
        / weights.sum().clamp_min(1e-8)
    )


def knowledge_distillation_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
    sample_weight: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    student_log_probability = F.log_softmax(
        student_logits.float() / temperature,
        dim=1,
    )
    teacher_probability = F.softmax(
        teacher_logits.float().detach()
        / temperature,
        dim=1,
    )

    row_loss = F.kl_div(
        student_log_probability,
        teacher_probability,
        reduction="none",
    ).sum(dim=1) * (temperature ** 2)

    if sample_weight is None:
        return row_loss.mean()

    weights = sample_weight.float()
    return (
        torch.sum(row_loss * weights)
        / weights.sum().clamp_min(1e-8)
    )


def refined_anchor_loss(
    head: ArcMarginHead,
    refined_prototypes: Optional[torch.Tensor],
) -> torch.Tensor:
    if refined_prototypes is None:
        return head.weight.new_zeros(())

    class_centers = head.normalized_weight()
    refined = F.normalize(
        refined_prototypes.float(),
        p=2,
        dim=1,
    )

    if class_centers.shape != refined.shape:
        raise ValueError(
            f"Head/refined shape mismatch: "
            f"{class_centers.shape} vs {refined.shape}"
        )

    return (
        1.0
        - torch.sum(
            class_centers * refined,
            dim=1,
        )
    ).mean()


def anchor_weight(
    length_ratio: torch.Tensor,
) -> torch.Tensor:
    """
    50aa is the anchor view.
    40aa and 30aa receive progressively weaker forced alignment.
    """
    ratio = length_ratio.float()

    weights = torch.where(
        ratio >= 0.999,
        torch.ones_like(ratio),
        torch.zeros_like(ratio),
    )
    weights = torch.where(
        (ratio >= 0.799) & (ratio < 0.999),
        0.60,
        weights,
    )
    weights = torch.where(
        ratio < 0.799,
        0.25,
        weights,
    )

    return weights


class EMA:
    def __init__(
        self,
        model: nn.Module,
        decay: float,
    ) -> None:
        self.decay = decay
        self.shadow = {
            name: parameter.detach().clone()
            for name, parameter in model.named_parameters()
            if parameter.requires_grad
        }
        self.backup: Dict[str, torch.Tensor] = {}

    def update(
        self,
        model: nn.Module,
    ) -> None:
        for name, parameter in model.named_parameters():
            if parameter.requires_grad:
                self.shadow[name] = (
                    self.decay * self.shadow[name]
                    + (1.0 - self.decay)
                    * parameter.detach()
                )

    def apply_shadow(
        self,
        model: nn.Module,
    ) -> None:
        self.backup = {}
        for name, parameter in model.named_parameters():
            if parameter.requires_grad:
                self.backup[name] = (
                    parameter.detach().clone()
                )
                parameter.data.copy_(
                    self.shadow[name].data
                )

    def restore(
        self,
        model: nn.Module,
    ) -> None:
        for name, parameter in model.named_parameters():
            if name in self.backup:
                parameter.data.copy_(
                    self.backup[name].data
                )
        self.backup = {}


# =============================================================================
# Metrics and predictions
# =============================================================================

def metric_dict(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    (
        precision_weighted,
        recall_weighted,
        f1_weighted,
        _,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="weighted",
        zero_division=0,
    )

    (
        precision_macro,
        recall_macro,
        f1_macro,
        _,
    ) = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="macro",
        zero_division=0,
    )

    return {
        "N": int(len(y_true)),
        "class_count": int(len(np.unique(y_true))),
        "ACC": float(
            accuracy_score(y_true, y_pred)
        ),
        "Precision_weighted": float(
            precision_weighted
        ),
        "Recall_weighted": float(
            recall_weighted
        ),
        "F1_weighted": float(f1_weighted),
        "Precision_macro": float(precision_macro),
        "Recall_macro": float(recall_macro),
        "F1_macro": float(f1_macro),
        "MCC": float(
            matthews_corrcoef(y_true, y_pred)
            if len(np.unique(y_true)) > 1
            else 0.0
        ),
    }


def model_selection_score(
    metrics_by_length: Dict[
        str,
        Dict[str, float],
    ],
) -> float:
    rows = [
        metrics_by_length[length_name]
        for length_name in LENGTH_ORDER
        if length_name in metrics_by_length
    ]

    mean_precision = float(
        np.mean(
            [
                row["Precision_weighted"]
                for row in rows
            ]
        )
    )
    mean_accuracy = float(
        np.mean(
            [
                row["ACC"]
                for row in rows
            ]
        )
    )
    mean_f1 = float(
        np.mean(
            [
                row["F1_weighted"]
                for row in rows
            ]
        )
    )
    worst_accuracy = float(
        np.min(
            [
                row["ACC"]
                for row in rows
            ]
        )
    )

    return (
        0.55 * mean_precision
        + 0.25 * mean_accuracy
        + 0.10 * mean_f1
        + 0.10 * worst_accuracy
    )


@torch.no_grad()
def predict_teacher(
    model: FusionTeacher,
    fusion: np.ndarray,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> np.ndarray:
    model.eval()
    predictions = []

    for start in range(
        0,
        len(selected_indices),
        batch_size,
    ):
        end = min(
            start + batch_size,
            len(selected_indices),
        )
        indices = selected_indices[start:end]
        batch = torch.from_numpy(
            fusion[indices]
        ).to(device)

        _, logits, _ = model(batch, None)
        predictions.append(
            logits.argmax(dim=1)
            .cpu()
            .numpy()
        )

    return np.concatenate(predictions)


@torch.no_grad()
def predict_student(
    model: ProteinStudent,
    protein: np.ndarray,
    length_ratio: np.ndarray,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
    return_probabilities: bool,
):
    model.eval()

    predictions = []
    confidences = []
    margins = []
    probabilities = (
        []
        if return_probabilities
        else None
    )

    for start in range(
        0,
        len(selected_indices),
        batch_size,
    ):
        end = min(
            start + batch_size,
            len(selected_indices),
        )
        indices = selected_indices[start:end]

        protein_batch = torch.from_numpy(
            protein[indices]
        ).to(device)
        length_batch = torch.from_numpy(
            length_ratio[indices]
        ).to(device)

        _, logits, _ = model(
            protein_batch,
            length_batch,
            None,
        )

        probability = torch.softmax(
            logits.float(),
            dim=1,
        )
        top2 = torch.topk(
            probability,
            k=2,
            dim=1,
        )

        predictions.append(
            top2.indices[:, 0]
            .cpu()
            .numpy()
        )
        confidences.append(
            top2.values[:, 0]
            .cpu()
            .numpy()
        )
        margins.append(
            (
                top2.values[:, 0]
                - top2.values[:, 1]
            )
            .cpu()
            .numpy()
        )

        if return_probabilities:
            probabilities.append(
                probability.cpu()
                .numpy()
                .astype(np.float32)
            )

    output = {
        "pred": np.concatenate(predictions),
        "confidence": np.concatenate(confidences),
        "margin": np.concatenate(margins),
    }

    if return_probabilities:
        output["probs"] = np.concatenate(
            probabilities
        )

    return output


def evaluate_balanced(
    model: ProteinStudent,
    protein: np.ndarray,
    length_ratio: np.ndarray,
    labels: np.ndarray,
    metadata: pd.DataFrame,
    selected_indices: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> Dict[str, Dict[str, float]]:
    output = predict_student(
        model,
        protein,
        length_ratio,
        selected_indices,
        batch_size,
        device,
        return_probabilities=False,
    )

    true_labels = labels[selected_indices]
    selected_metadata = metadata.loc[
        selected_indices
    ].reset_index(drop=True)

    result = {}
    for length_name in LENGTH_ORDER:
        mask = (
            selected_metadata["length_name"]
            .to_numpy()
            == length_name
        )
        if mask.any():
            result[length_name] = metric_dict(
                true_labels[mask],
                output["pred"][mask],
            )

    return result


def print_length_metrics(
    title: str,
    metrics: Dict[str, Dict[str, float]],
) -> None:
    print("\n" + title)
    for length_name in LENGTH_ORDER:
        if length_name not in metrics:
            continue

        row = metrics[length_name]
        print(
            f"{length_name:>4s} | "
            f"N={row['N']:>7d} | "
            f"ACC={row['ACC']:.4f} | "
            f"WP={row['Precision_weighted']:.4f} | "
            f"WF1={row['F1_weighted']:.4f} | "
            f"MCC={row['MCC']:.4f}"
        )


def one_vs_rest_table(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
    dataset: str,
    level: str,
) -> pd.DataFrame:
    rows = []

    for class_id in sorted(
        np.unique(y_true)
    ):
        true_binary = (
            y_true == class_id
        ).astype(np.int8)
        pred_binary = (
            y_pred == class_id
        ).astype(np.int8)

        (
            precision,
            recall,
            f1,
            _,
        ) = precision_recall_fscore_support(
            true_binary,
            pred_binary,
            average="binary",
            zero_division=0,
        )

        if (
            len(np.unique(true_binary)) == 1
            and len(np.unique(pred_binary)) == 1
        ):
            mcc = 0.0
        else:
            mcc = float(
                matthews_corrcoef(
                    true_binary,
                    pred_binary,
                )
            )

        support = int(
            true_binary.sum()
        )
        pred_count = int(
            pred_binary.sum()
        )
        correct_count = int(
            (
                (y_true == class_id)
                & (y_pred == class_id)
            ).sum()
        )

        rows.append(
            {
                "dataset": dataset,
                "level": level,
                "class_id": int(class_id),
                "class_name": class_names[class_id],
                "support": support,
                "pred_count": pred_count,
                "correct_count": correct_count,
                "ACC": (
                    correct_count / support
                    if support > 0
                    else 0.0
                ),
                "Precision": float(precision),
                "Recall": float(recall),
                "F1": float(f1),
                "MCC": mcc,
            }
        )

    return pd.DataFrame(rows)


# =============================================================================
# Training
# =============================================================================

def train_teacher(
    cfg: Config,
    fusion: np.ndarray,
    labels: np.ndarray,
    metadata: pd.DataFrame,
    train_indices: np.ndarray,
    validation_indices: np.ndarray,
    refined_tensor: Optional[torch.Tensor],
    device: torch.device,
    out_dir: Path,
) -> FusionTeacher:
    print("\n" + "=" * 80)
    print("Stage 1: joint 30aa/40aa/50aa Fusion Teacher")
    print("=" * 80)

    dummy_protein = np.zeros(
        (
            len(fusion),
            EXPECTED_PROTEIN_DIM,
        ),
        dtype=np.float32,
    )
    dummy_base_index = np.zeros(
        len(fusion),
        dtype=np.int64,
    )
    dummy_anchor = np.zeros(
        (
            1,
            EXPECTED_FUSION_DIM,
        ),
        dtype=np.float32,
    )

    dataset = JointDataset(
        protein=dummy_protein,
        fusion=fusion,
        labels=labels,
        length_ratio=metadata[
            "length_ratio"
        ].to_numpy(dtype=np.float32),
        row_to_base_index=dummy_base_index,
        anchor_50aa_fusion=dummy_anchor,
        selected_indices=train_indices,
    )

    sampler = make_balanced_sampler(
        metadata,
        labels,
        train_indices,
        cfg,
    )
    loader = make_loader(
        dataset,
        cfg.batch_size,
        device,
        cfg.num_workers,
        sampler=sampler,
    )

    num_classes = int(labels.max()) + 1
    model = FusionTeacher(
        cfg,
        num_classes,
    ).to(device)

    if refined_tensor is not None:
        if (
            refined_tensor.shape
            != model.head.weight.shape
        ):
            raise ValueError(
                f"Refined/head shape mismatch: "
                f"{refined_tensor.shape} vs "
                f"{model.head.weight.shape}"
            )

        with torch.no_grad():
            model.head.weight.copy_(
                refined_tensor
            )

        print(
            "Initialized Fusion Teacher class centers "
            "from the 50aa/150nt refined prototypes."
        )

    parent_rows = (
        metadata.loc[train_indices]
        .drop_duplicates("base_id")
        .index
        .to_numpy(dtype=np.int64)
    )

    class_weights_np = mild_class_weights(
        labels[parent_rows],
        num_classes,
        cfg.class_weight_power,
        cfg.class_weight_clip_min,
        cfg.class_weight_clip_max,
    )
    class_weights = torch.tensor(
        class_weights_np,
        dtype=torch.float32,
        device=device,
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.teacher_lr,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=5,
        min_lr=1e-6,
    )

    amp_enabled = (
        cfg.amp
        and device.type == "cuda"
    )
    gradient_scaler = make_grad_scaler(
        amp_enabled
    )

    best_score = -np.inf
    best_epoch = 0
    best_state = None
    no_improvement = 0
    history = []

    for epoch in range(
        1,
        cfg.teacher_epochs + 1,
    ):
        model.train()

        running_loss = 0.0
        running_ce = 0.0
        running_supcon = 0.0
        running_refined = 0.0
        seen = 0

        for (
            _,
            fusion_batch,
            label_batch,
            _,
            _,
            _,
        ) in loader:
            fusion_batch = fusion_batch.to(
                device,
                non_blocking=True,
            )
            label_batch = label_batch.to(
                device,
                non_blocking=True,
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            with autocast_cuda(amp_enabled):
                (
                    margin_logits,
                    _,
                    embedding,
                ) = model(
                    fusion_batch,
                    label_batch,
                )

                loss_ce = F.cross_entropy(
                    margin_logits,
                    label_batch,
                    weight=class_weights,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_supcon = supervised_contrastive_loss(
                    embedding,
                    label_batch,
                    cfg.supcon_temperature,
                )
                loss_refined = refined_anchor_loss(
                    model.head,
                    refined_tensor,
                )

                loss = (
                    cfg.teacher_ce_weight * loss_ce
                    + cfg.teacher_supcon_weight
                    * loss_supcon
                    + cfg.teacher_refined_weight
                    * loss_refined
                )

            gradient_scaler.scale(
                loss
            ).backward()
            gradient_scaler.unscale_(
                optimizer
            )
            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0,
            )
            gradient_scaler.step(
                optimizer
            )
            gradient_scaler.update()

            batch_size = len(label_batch)
            running_loss += (
                float(loss.item())
                * batch_size
            )
            running_ce += (
                float(loss_ce.item())
                * batch_size
            )
            running_supcon += (
                float(loss_supcon.item())
                * batch_size
            )
            running_refined += (
                float(loss_refined.item())
                * batch_size
            )
            seen += batch_size

        evaluate_now = (
            epoch == 1
            or epoch % cfg.eval_every_teacher == 0
            or epoch == cfg.teacher_epochs
        )

        if evaluate_now:
            predictions = predict_teacher(
                model,
                fusion,
                validation_indices,
                cfg.eval_batch_size,
                device,
            )

            selected_metadata = metadata.loc[
                validation_indices
            ].reset_index(drop=True)
            true_labels = labels[
                validation_indices
            ]

            validation_metrics = {}
            for length_name in LENGTH_ORDER:
                mask = (
                    selected_metadata["length_name"]
                    .to_numpy()
                    == length_name
                )
                if mask.any():
                    validation_metrics[
                        length_name
                    ] = metric_dict(
                        true_labels[mask],
                        predictions[mask],
                    )

            score = model_selection_score(
                validation_metrics
            )
            scheduler.step(score)

            if score > best_score + cfg.min_delta:
                best_score = score
                best_epoch = epoch
                best_state = copy.deepcopy(
                    model.state_dict()
                )
                no_improvement = 0
            else:
                no_improvement += 1
        else:
            validation_metrics = {}
            score = float("nan")

        row = {
            "epoch": epoch,
            "train_loss": (
                running_loss / max(seen, 1)
            ),
            "train_ce": (
                running_ce / max(seen, 1)
            ),
            "train_supcon": (
                running_supcon / max(seen, 1)
            ),
            "train_refined": (
                running_refined / max(seen, 1)
            ),
            "validation_score": score,
            "learning_rate": (
                optimizer.param_groups[0]["lr"]
            ),
        }

        for (
            length_name,
            metrics,
        ) in validation_metrics.items():
            row[
                f"{length_name}_ACC"
            ] = metrics["ACC"]
            row[
                f"{length_name}_WP"
            ] = metrics["Precision_weighted"]
            row[
                f"{length_name}_WF1"
            ] = metrics["F1_weighted"]
            row[
                f"{length_name}_MCC"
            ] = metrics["MCC"]

        history.append(row)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Teacher {epoch:03d}] "
                f"loss={row['train_loss']:.4f} | "
                f"score={score:.4f} | "
                f"lr={row['learning_rate']:.2e}"
            )
            if validation_metrics:
                print_length_metrics(
                    "Fusion Teacher validation",
                    validation_metrics,
                )

        if (
            evaluate_now
            and no_improvement
            >= cfg.teacher_patience
        ):
            print(
                f"Teacher early stopping at epoch "
                f"{epoch}; best_epoch={best_epoch}, "
                f"best_score={best_score:.4f}"
            )
            break

    if best_state is None:
        raise RuntimeError(
            "Fusion Teacher did not produce a checkpoint."
        )

    model.load_state_dict(best_state)
    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "fusion_teacher_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "best_validation_score": best_score,
            "config": asdict(cfg),
        },
        out_dir / "fusion_teacher_best.pth",
    )

    return model


def train_student(
    cfg: Config,
    teacher: FusionTeacher,
    protein: np.ndarray,
    fusion: np.ndarray,
    labels: np.ndarray,
    metadata: pd.DataFrame,
    row_to_base_index: np.ndarray,
    anchor_50aa_fusion: np.ndarray,
    train_indices: np.ndarray,
    validation_indices: np.ndarray,
    refined_tensor: Optional[torch.Tensor],
    device: torch.device,
    out_dir: Path,
) -> ProteinStudent:
    print("\n" + "=" * 80)
    print("Stage 2: joint 30aa/40aa/50aa Protein Student")
    print("=" * 80)

    length_ratio = metadata[
        "length_ratio"
    ].to_numpy(dtype=np.float32)

    dataset = JointDataset(
        protein=protein,
        fusion=fusion,
        labels=labels,
        length_ratio=length_ratio,
        row_to_base_index=row_to_base_index,
        anchor_50aa_fusion=anchor_50aa_fusion,
        selected_indices=train_indices,
    )

    sampler = make_balanced_sampler(
        metadata,
        labels,
        train_indices,
        cfg,
    )
    loader = make_loader(
        dataset,
        cfg.batch_size,
        device,
        cfg.num_workers,
        sampler=sampler,
    )

    num_classes = int(labels.max()) + 1
    model = ProteinStudent(
        cfg,
        num_classes,
    ).to(device)

    with torch.no_grad():
        model.head.weight.copy_(
            teacher.head.weight.detach()
        )

    print(
        "Initialized Protein Student subtype centers "
        "from the Fusion Teacher."
    )

    for parameter in teacher.parameters():
        parameter.requires_grad = False
    teacher.eval()

    parent_rows = (
        metadata.loc[train_indices]
        .drop_duplicates("base_id")
        .index
        .to_numpy(dtype=np.int64)
    )

    class_weights_np = mild_class_weights(
        labels[parent_rows],
        num_classes,
        cfg.class_weight_power,
        cfg.class_weight_clip_min,
        cfg.class_weight_clip_max,
    )
    class_weights = torch.tensor(
        class_weights_np,
        dtype=torch.float32,
        device=device,
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.student_lr,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=7,
        min_lr=1e-6,
    )

    amp_enabled = (
        cfg.amp
        and device.type == "cuda"
    )
    gradient_scaler = make_grad_scaler(
        amp_enabled
    )
    ema = (
        EMA(model, cfg.ema_decay)
        if cfg.use_ema
        else None
    )

    best_score = -np.inf
    best_epoch = 0
    best_state = None
    best_ema = None
    no_improvement = 0
    history = []

    for epoch in range(
        1,
        cfg.student_epochs + 1,
    ):
        model.train()

        running = {
            "loss": 0.0,
            "ce": 0.0,
            "supcon": 0.0,
            "same_align": 0.0,
            "anchor_align": 0.0,
            "same_kd": 0.0,
            "anchor_kd": 0.0,
            "refined": 0.0,
            "n": 0,
        }

        for (
            protein_batch,
            fusion_batch,
            label_batch,
            length_batch,
            anchor_batch,
            _,
        ) in loader:
            protein_batch = protein_batch.to(
                device,
                non_blocking=True,
            )
            fusion_batch = fusion_batch.to(
                device,
                non_blocking=True,
            )
            label_batch = label_batch.to(
                device,
                non_blocking=True,
            )
            length_batch = length_batch.to(
                device,
                non_blocking=True,
            )
            anchor_batch = anchor_batch.to(
                device,
                non_blocking=True,
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            with torch.no_grad():
                (
                    _,
                    same_teacher_logits,
                    same_teacher_embedding,
                ) = teacher(
                    fusion_batch,
                    None,
                )
                (
                    _,
                    anchor_teacher_logits,
                    anchor_teacher_embedding,
                ) = teacher(
                    anchor_batch,
                    None,
                )

            with autocast_cuda(amp_enabled):
                (
                    margin_logits,
                    plain_logits,
                    student_embedding,
                ) = model(
                    protein_batch,
                    length_batch,
                    label_batch,
                )

                loss_ce = F.cross_entropy(
                    margin_logits,
                    label_batch,
                    weight=class_weights,
                    label_smoothing=cfg.label_smoothing,
                )
                loss_supcon = supervised_contrastive_loss(
                    student_embedding,
                    label_batch,
                    cfg.supcon_temperature,
                )
                loss_same_align = cosine_pull_loss(
                    student_embedding,
                    same_teacher_embedding,
                )

                weights = anchor_weight(
                    length_batch
                )
                loss_anchor_align = cosine_pull_loss(
                    student_embedding,
                    anchor_teacher_embedding,
                    sample_weight=weights,
                )

                loss_same_kd = (
                    knowledge_distillation_loss(
                        plain_logits,
                        same_teacher_logits,
                        cfg.kd_temperature,
                    )
                )
                loss_anchor_kd = (
                    knowledge_distillation_loss(
                        plain_logits,
                        anchor_teacher_logits,
                        cfg.kd_temperature,
                        sample_weight=weights,
                    )
                )
                loss_refined = refined_anchor_loss(
                    model.head,
                    refined_tensor,
                )

                loss = (
                    cfg.student_ce_weight * loss_ce
                    + cfg.student_supcon_weight
                    * loss_supcon
                    + cfg.same_view_align_weight
                    * loss_same_align
                    + cfg.anchor_50aa_align_weight
                    * loss_anchor_align
                    + cfg.same_view_kd_weight
                    * loss_same_kd
                    + cfg.anchor_50aa_kd_weight
                    * loss_anchor_kd
                    + cfg.student_refined_weight
                    * loss_refined
                )

            gradient_scaler.scale(
                loss
            ).backward()
            gradient_scaler.unscale_(
                optimizer
            )
            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0,
            )
            gradient_scaler.step(
                optimizer
            )
            gradient_scaler.update()

            if ema is not None:
                ema.update(model)

            batch_size = len(label_batch)
            running["loss"] += (
                float(loss.item())
                * batch_size
            )
            running["ce"] += (
                float(loss_ce.item())
                * batch_size
            )
            running["supcon"] += (
                float(loss_supcon.item())
                * batch_size
            )
            running["same_align"] += (
                float(loss_same_align.item())
                * batch_size
            )
            running["anchor_align"] += (
                float(loss_anchor_align.item())
                * batch_size
            )
            running["same_kd"] += (
                float(loss_same_kd.item())
                * batch_size
            )
            running["anchor_kd"] += (
                float(loss_anchor_kd.item())
                * batch_size
            )
            running["refined"] += (
                float(loss_refined.item())
                * batch_size
            )
            running["n"] += batch_size

        evaluate_now = (
            epoch == 1
            or epoch % cfg.eval_every_student == 0
            or epoch == cfg.student_epochs
        )

        if evaluate_now:
            if ema is not None:
                ema.apply_shadow(model)

            validation_metrics = evaluate_balanced(
                model,
                protein,
                length_ratio,
                labels,
                metadata,
                validation_indices,
                cfg.eval_batch_size,
                device,
            )
            score = model_selection_score(
                validation_metrics
            )

            if ema is not None:
                ema.restore(model)

            scheduler.step(score)

            if score > best_score + cfg.min_delta:
                best_score = score
                best_epoch = epoch
                best_state = copy.deepcopy(
                    model.state_dict()
                )
                if ema is not None:
                    best_ema = {
                        name: value.detach()
                        .cpu()
                        .clone()
                        for (
                            name,
                            value,
                        ) in ema.shadow.items()
                    }
                no_improvement = 0
            else:
                no_improvement += 1
        else:
            validation_metrics = {}
            score = float("nan")

        sample_count = max(
            running["n"],
            1,
        )
        row = {
            "epoch": epoch,
            "train_loss": (
                running["loss"] / sample_count
            ),
            "train_ce": (
                running["ce"] / sample_count
            ),
            "train_supcon": (
                running["supcon"] / sample_count
            ),
            "train_same_align": (
                running["same_align"]
                / sample_count
            ),
            "train_anchor_align": (
                running["anchor_align"]
                / sample_count
            ),
            "train_same_kd": (
                running["same_kd"] / sample_count
            ),
            "train_anchor_kd": (
                running["anchor_kd"]
                / sample_count
            ),
            "train_refined": (
                running["refined"]
                / sample_count
            ),
            "validation_score": score,
            "learning_rate": (
                optimizer.param_groups[0]["lr"]
            ),
        }

        for (
            length_name,
            metrics,
        ) in validation_metrics.items():
            row[
                f"{length_name}_ACC"
            ] = metrics["ACC"]
            row[
                f"{length_name}_WP"
            ] = metrics["Precision_weighted"]
            row[
                f"{length_name}_WF1"
            ] = metrics["F1_weighted"]
            row[
                f"{length_name}_MCC"
            ] = metrics["MCC"]

        history.append(row)

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"[Student {epoch:03d}] "
                f"loss={row['train_loss']:.4f} | "
                f"ce={row['train_ce']:.4f} | "
                f"same_align={row['train_same_align']:.4f} | "
                f"anchor_align={row['train_anchor_align']:.4f} | "
                f"score={score:.4f} | "
                f"lr={row['learning_rate']:.2e}"
            )
            if validation_metrics:
                print_length_metrics(
                    "Protein Student validation",
                    validation_metrics,
                )

        if (
            evaluate_now
            and no_improvement
            >= cfg.student_patience
        ):
            print(
                f"Student early stopping at epoch "
                f"{epoch}; best_epoch={best_epoch}, "
                f"best_score={best_score:.4f}"
            )
            break

    if best_state is None:
        raise RuntimeError(
            "Protein Student did not produce a checkpoint."
        )

    model.load_state_dict(best_state)

    if ema is not None and best_ema is not None:
        ema.shadow = best_ema
        ema.apply_shadow(model)
        print(
            "Loaded the best EMA Protein Student."
        )

    model.eval()

    pd.DataFrame(history).to_csv(
        out_dir / "protein_student_training_history.csv",
        index=False,
        encoding="utf-8-sig",
    )
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "best_epoch": best_epoch,
            "best_validation_score": best_score,
            "config": asdict(cfg),
        },
        out_dir / "protein_student_best.pth",
    )

    return model


# =============================================================================
# Final evaluation
# =============================================================================

def evaluate_and_save(
    model: ProteinStudent,
    split_name: str,
    protein: np.ndarray,
    labels: np.ndarray,
    metadata: pd.DataFrame,
    encoder: LabelEncoder,
    subtype_to_type: Dict[str, str],
    cfg: Config,
    device: torch.device,
    out_dir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    evaluation_dir = (
        out_dir / f"{split_name}_evaluation"
    )
    evaluation_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    length_ratio = metadata[
        "length_ratio"
    ].to_numpy(dtype=np.float32)

    subtype_classes = list(
        encoder.classes_
    )
    type_classes = sorted(
        set(subtype_to_type.values())
    )
    type_encoder = LabelEncoder()
    type_encoder.fit(type_classes)

    fragment_rows = []
    parent_rows = []
    subtype_class_parts = []
    type_class_parts = []

    if split_name == "coverage":
        split_mask = metadata[
            "in_coverage_test"
        ].to_numpy(dtype=bool)
    else:
        split_mask = (
            metadata["split"].to_numpy()
            == split_name
        )

    for length_name in LENGTH_ORDER:
        indices = np.where(
            split_mask
            & (
                metadata["length_name"]
                .to_numpy()
                == length_name
            )
        )[0].astype(np.int64)

        if len(indices) == 0:
            continue

        prediction = predict_student(
            model,
            protein,
            length_ratio,
            indices,
            cfg.eval_batch_size,
            device,
            return_probabilities=True,
        )

        y_true = labels[indices]
        y_pred = prediction["pred"]
        probabilities = prediction["probs"]

        subtype_metrics = metric_dict(
            y_true,
            y_pred,
        )
        fragment_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": "Subtype_fragment",
                **subtype_metrics,
            }
        )

        true_subtypes = encoder.inverse_transform(
            y_true
        )
        pred_subtypes = encoder.inverse_transform(
            y_pred
        )

        true_types = np.asarray(
            [
                subtype_to_type[subtype]
                for subtype in true_subtypes
            ]
        )
        pred_types = np.asarray(
            [
                subtype_to_type[subtype]
                for subtype in pred_subtypes
            ]
        )

        y_true_type = type_encoder.transform(
            true_types
        )
        y_pred_type = type_encoder.transform(
            pred_types
        )

        type_metrics = metric_dict(
            y_true_type,
            y_pred_type,
        )
        fragment_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": (
                    "Type_from_Subtype_fragment"
                ),
                **type_metrics,
            }
        )

        prediction_frame = metadata.loc[
            indices,
            [
                "KEY",
                "base_id",
                "crop_index",
                "length_name",
                "length_ratio",
                "Type",
                "Subtype",
                "split",
                "in_train_file",
                "in_coverage_test",
                "is_train_test_overlap",
            ],
        ].copy()

        prediction_frame["Pred_Subtype"] = (
            pred_subtypes
        )
        prediction_frame["Pred_Type"] = (
            pred_types
        )
        prediction_frame[
            "subtype_confidence"
        ] = prediction["confidence"]
        prediction_frame[
            "subtype_margin"
        ] = prediction["margin"]
        prediction_frame[
            "Subtype_correct"
        ] = y_true == y_pred
        prediction_frame[
            "Type_correct"
        ] = true_types == pred_types

        prediction_frame.to_csv(
            evaluation_dir
            / f"{length_name}_fragment_predictions.csv",
            index=False,
            encoding="utf-8-sig",
            float_format="%.8f",
        )

        subtype_class_parts.append(
            one_vs_rest_table(
                y_true,
                y_pred,
                subtype_classes,
                dataset=length_name,
                level="Subtype_fragment",
            )
        )
        type_class_parts.append(
            one_vs_rest_table(
                y_true_type,
                y_pred_type,
                list(type_encoder.classes_),
                dataset=length_name,
                level=(
                    "Type_from_Subtype_fragment"
                ),
            )
        )

        selected_metadata = metadata.loc[
            indices
        ].reset_index(drop=True)

        positions_by_base = (
            selected_metadata.reset_index()
            .groupby("base_id")["index"]
            .apply(list)
        )

        parent_true = []
        parent_pred = []
        parent_confidence = []
        parent_margin = []
        parent_ids = []

        for (
            base_id,
            positions,
        ) in positions_by_base.items():
            position_array = np.asarray(
                positions,
                dtype=np.int64,
            )
            mean_probability = probabilities[
                position_array
            ].mean(axis=0)

            top2 = np.argpartition(
                -mean_probability,
                kth=1,
            )[:2]
            top2 = top2[
                np.argsort(
                    -mean_probability[top2]
                )
            ]

            parent_ids.append(base_id)
            parent_true.append(
                int(y_true[position_array[0]])
            )
            parent_pred.append(
                int(top2[0])
            )
            parent_confidence.append(
                float(mean_probability[top2[0]])
            )
            parent_margin.append(
                float(
                    mean_probability[top2[0]]
                    - mean_probability[top2[1]]
                )
            )

        parent_true = np.asarray(
            parent_true,
            dtype=np.int64,
        )
        parent_pred = np.asarray(
            parent_pred,
            dtype=np.int64,
        )

        parent_subtype_metrics = metric_dict(
            parent_true,
            parent_pred,
        )
        parent_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": (
                    "Subtype_parent_aggregated"
                ),
                **parent_subtype_metrics,
            }
        )

        parent_true_subtypes = (
            encoder.inverse_transform(
                parent_true
            )
        )
        parent_pred_subtypes = (
            encoder.inverse_transform(
                parent_pred
            )
        )
        parent_true_types = np.asarray(
            [
                subtype_to_type[subtype]
                for subtype
                in parent_true_subtypes
            ]
        )
        parent_pred_types = np.asarray(
            [
                subtype_to_type[subtype]
                for subtype
                in parent_pred_subtypes
            ]
        )

        parent_type_metrics = metric_dict(
            type_encoder.transform(
                parent_true_types
            ),
            type_encoder.transform(
                parent_pred_types
            ),
        )
        parent_rows.append(
            {
                "split": split_name,
                "dataset": length_name,
                "level": (
                    "Type_from_Subtype_parent_aggregated"
                ),
                **parent_type_metrics,
            }
        )

        parent_prediction_frame = pd.DataFrame(
            {
                "base_id": parent_ids,
                "length_name": length_name,
                "true_Subtype": parent_true_subtypes,
                "pred_Subtype": parent_pred_subtypes,
                "true_Type": parent_true_types,
                "pred_Type": parent_pred_types,
                "confidence": parent_confidence,
                "margin": parent_margin,
                "Subtype_correct": (
                    parent_true == parent_pred
                ),
                "Type_correct": (
                    parent_true_types
                    == parent_pred_types
                ),
            }
        )

        parent_prediction_frame.to_csv(
            evaluation_dir
            / (
                f"{length_name}_"
                "parent_aggregated_predictions.csv"
            ),
            index=False,
            encoding="utf-8-sig",
            float_format="%.8f",
        )

        del prediction, probabilities
        gc.collect()

    fragment_overall = pd.DataFrame(
        fragment_rows
    )
    parent_overall = pd.DataFrame(
        parent_rows
    )
    subtype_by_class = pd.concat(
        subtype_class_parts,
        ignore_index=True,
    )
    type_by_class = pd.concat(
        type_class_parts,
        ignore_index=True,
    )

    fragment_overall.to_csv(
        evaluation_dir
        / "fragment_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    parent_overall.to_csv(
        evaluation_dir
        / "parent_aggregated_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    subtype_by_class.to_csv(
        evaluation_dir
        / "fragment_subtype_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    type_by_class.to_csv(
        evaluation_dir
        / "fragment_type_metrics_by_class.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    return fragment_overall, parent_overall


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    cfg = parse_args()
    seed_everything(cfg.seed)
    device = resolve_device(cfg.device)

    data_dir = Path(cfg.data_dir)
    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    save_json(
        asdict(cfg),
        out_dir / "run_config.json",
    )

    print("=" * 80)
    print("ARGScope joint 30aa/40aa/50aa model")
    print(f"Script version: {SCRIPT_VERSION}")
    print("=" * 80)
    print(f"Data directory: {data_dir.resolve()}")
    print(f"Output directory: {out_dir.resolve()}")
    print(f"Device: {device}")
    print(f"PyTorch: {torch.__version__}")
    print(
        f"CUDA available: "
        f"{torch.cuda.is_available()}"
    )

    if torch.cuda.is_available():
        print(
            f"GPU: "
            f"{torch.cuda.get_device_name(0)}"
        )
        print(f"CUDA: {torch.version.cuda}")

    start_time = time.time()

    (
        metadata_by_length,
        protein_by_length,
        fusion_by_length,
    ) = load_all_data(data_dir)

    parent_labels = build_parent_labels(
        metadata_by_length["50aa"]
    )
    base_split = build_base_split(
        parent_labels,
        data_dir / TRAIN_SPLIT_FILE,
        data_dir / TEST_SPLIT_FILE,
        cfg.val_ratio,
        cfg.seed,
    )

    metadata_by_length = attach_split(
        metadata_by_length,
        base_split,
    )

    (
        metadata,
        protein_raw,
        fusion_raw,
    ) = concatenate_lengths(
        metadata_by_length,
        protein_by_length,
        fusion_by_length,
    )

    base_split.to_csv(
        out_dir / "parent_split.csv",
        index=False,
        encoding="utf-8-sig",
    )
    metadata.to_csv(
        out_dir / "all_view_metadata.csv",
        index=False,
        encoding="utf-8-sig",
    )

    (
        encoder,
        labels,
        subtype_to_type,
    ) = build_labels(
        metadata,
        out_dir,
    )

    if cfg.validate_only:
        print("\nValidation-only mode passed.")
        print(f"Rows: {len(metadata):,}")
        print(
            f"Base IDs: "
            f"{metadata['base_id'].nunique():,}"
        )
        print(
            f"Subtypes: "
            f"{len(encoder.classes_):,}"
        )
        return

    (
        protein_scaled,
        fusion_scaled,
        _,
        fusion_scaler,
    ) = fit_scalers(
        metadata,
        protein_raw,
        fusion_raw,
        out_dir,
    )

    del protein_raw, fusion_raw
    gc.collect()

    refined_path = choose_refined_file(
        data_dir
    )
    refined_np = load_refined(
        refined_path,
        encoder,
        fusion_scaler,
        cfg.use_refined_anchor,
    )
    refined_tensor = (
        torch.tensor(
            refined_np,
            dtype=torch.float32,
            device=device,
        )
        if refined_np is not None
        else None
    )

    (
        anchor_50aa_fusion,
        row_to_base_index,
        base_id_order,
    ) = build_anchor_50aa_fusion(
        metadata,
        fusion_scaled,
    )

    joblib.dump(
        base_id_order,
        out_dir / "base_id_order.joblib",
    )

    train_indices = np.where(
        metadata["split"].to_numpy()
        == "train"
    )[0].astype(np.int64)
    validation_indices = np.where(
        metadata["split"].to_numpy()
        == "val"
    )[0].astype(np.int64)
    independent_test_indices = np.where(
        metadata["split"].to_numpy()
        == "test"
    )[0].astype(np.int64)
    coverage_indices = np.where(
        metadata["in_coverage_test"]
        .to_numpy(dtype=bool)
    )[0].astype(np.int64)

    print("\nJoint row counts:")
    print(f"  train:             {len(train_indices):,}")
    print(f"  validation:        {len(validation_indices):,}")
    print(
        f"  independent test:  "
        f"{len(independent_test_indices):,}"
    )
    print(f"  coverage:          {len(coverage_indices):,}")

    if len(validation_indices) == 0:
        raise ValueError(
            "Validation split is empty."
        )

    teacher = train_teacher(
        cfg,
        fusion_scaled,
        labels,
        metadata,
        train_indices,
        validation_indices,
        refined_tensor,
        device,
        out_dir,
    )

    student = train_student(
        cfg,
        teacher,
        protein_scaled,
        fusion_scaled,
        labels,
        metadata,
        row_to_base_index,
        anchor_50aa_fusion,
        train_indices,
        validation_indices,
        refined_tensor,
        device,
        out_dir,
    )

    print("\n" + "=" * 80)
    print(
        "Final validation, independent-test "
        "and coverage evaluation"
    )
    print("=" * 80)

    val_fragment, val_parent = evaluate_and_save(
        student,
        "val",
        protein_scaled,
        labels,
        metadata,
        encoder,
        subtype_to_type,
        cfg,
        device,
        out_dir,
    )
    test_fragment, test_parent = evaluate_and_save(
        student,
        "test",
        protein_scaled,
        labels,
        metadata,
        encoder,
        subtype_to_type,
        cfg,
        device,
        out_dir,
    )
    (
        coverage_fragment,
        coverage_parent,
    ) = evaluate_and_save(
        student,
        "coverage",
        protein_scaled,
        labels,
        metadata,
        encoder,
        subtype_to_type,
        cfg,
        device,
        out_dir,
    )

    summary = pd.concat(
        [
            val_fragment,
            val_parent,
            test_fragment,
            test_parent,
            coverage_fragment,
            coverage_parent,
        ],
        ignore_index=True,
    )
    summary.to_csv(
        out_dir / "all_length_evaluation_summary.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )

    checkpoint = {
        "model_name": (
            "ARGScope_joint_30aa40aa50aa_protein_student"
        ),
        "script_version": SCRIPT_VERSION,
        "student_state_dict": student.state_dict(),
        "teacher_state_dict": teacher.state_dict(),
        "protein_dimension": EXPECTED_PROTEIN_DIM,
        "fusion_dimension": EXPECTED_FUSION_DIM,
        "embedding_dimension": cfg.embed_dim,
        "num_classes": len(encoder.classes_),
        "subtype_classes": (
            encoder.classes_.tolist()
        ),
        "subtype_to_type": subtype_to_type,
        "length_ratios": LENGTH_RATIO,
        "anchor_length": "50aa",
        "training_lengths": LENGTH_ORDER,
        "config": asdict(cfg),
        "files": {
            "protein_files": PROTEIN_FILES,
            "fusion_files": FUSION_FILES,
            "refined_preferred": REFINED_PREFERRED,
            "refined_fallback": REFINED_FALLBACK,
            "train_split": TRAIN_SPLIT_FILE,
            "test_split": TEST_SPLIT_FILE,
        },
        "inference_note": (
            "Inference uses Protein embedding plus "
            "the known length ratio only."
        ),
        "evaluation_note": {
            "test": (
                "Independent base IDs present in the test "
                "split but absent from the training split."
            ),
            "coverage": (
                "Complete short-read coverage test. "
                "It may intentionally include train/test overlap."
            ),
        },
    }

    torch.save(
        checkpoint,
        out_dir
        / "argscope_joint_30aa40aa50aa_checkpoint.pth",
    )

    elapsed = time.time() - start_time

    save_json(
        {
            "runtime_seconds": elapsed,
            "runtime_hours": elapsed / 3600.0,
            "rows": len(metadata),
            "base_ids": int(
                metadata["base_id"].nunique()
            ),
            "subtypes": len(encoder.classes_),
            "training_lengths": LENGTH_ORDER,
            "anchor_length": "50aa",
            "main_summary": (
                "all_length_evaluation_summary.csv"
            ),
            "checkpoint": (
                "argscope_joint_30aa40aa50aa_checkpoint.pth"
            ),
            "protein_scaler": (
                "protein_scaler_30aa40aa50aa.joblib"
            ),
            "subtype_encoder": (
                "subtype_encoder.joblib"
            ),
        },
        out_dir / "run_manifest.json",
    )

    print("\n" + "=" * 80)
    print("Training completed")
    print("=" * 80)
    print("\nIndependent-test fragment results:")
    print(test_fragment.to_string(index=False))
    print("\nCoverage fragment results:")
    print(coverage_fragment.to_string(index=False))
    print(f"\nOutput directory: {out_dir.resolve()}")
    print(
        "Main summary: "
        "all_length_evaluation_summary.csv"
    )
    print(
        "Checkpoint: "
        "argscope_joint_30aa40aa50aa_checkpoint.pth"
    )
    print(
        f"Runtime: {elapsed / 3600.0:.2f} hours"
    )


if __name__ == "__main__":
    main()
