"""Replace only panel B's averaging scheme using verified existing predictions."""
from pathlib import Path
import importlib.util
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('palette_figures', HERE / 'recolor_figure2_figure3_multicolor.py')
palette = importlib.util.module_from_spec(spec)
spec.loader.exec_module(palette)
base = palette.base
OUT = HERE / 'outputs/figure2_figure3_weighted_20260924'
OLD = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Figure2_Figure3_多色配色版_20260923')
base.OUT = OUT
base.PALETTE = OLD / 'plot_data/umap_reference_palette.csv'
base.SOURCE = OLD / 'plot_data'
DATA = HERE / 'outputs/argscope_including_nonARG_20260922/data'
AUDIT = []


class WeightedBuilder(palette.MulticolorBuilder):
    def bars(self):
        super().bars()
        source = DATA / self.mod / 'ARGScope_Subtype_macro_weighted_micro_60_100.csv'
        frame = pd.read_csv(source)
        selection = frame[(frame.Completeness == 100) & (frame.Average == 'weighted')]
        assert len(selection) == 1
        row = selection.iloc[0]
        labels = row.Averaged_labels.split(';')
        assert len(labels) == 821 and 'nonARG' in labels
        raw_path = DATA / self.mod / 'ARGScope_100pct_sequence_evaluation.csv'
        raw = pd.read_csv(raw_path, keep_default_na=False)
        assert len(raw) == int(row.N) == 4574
        assert raw.sequence_id.is_unique
        p, r, f, _ = precision_recall_fscore_support(
            raw.true_subtype, raw.predicted_subtype, labels=labels,
            average='weighted', zero_division=0)
        checked = np.array([accuracy_score(raw.true_subtype, raw.predicted_subtype),
                            p, r, f, matthews_corrcoef(raw.true_subtype, raw.predicted_subtype)])
        values = row[base.FIELDS].to_numpy(float)
        np.testing.assert_allclose(checked, values, atol=1e-12, rtol=0)
        old = pd.read_csv(self.base / 'B_subtype_macro_values.csv').iloc[0]
        np.testing.assert_allclose(values[[0, 4]], old[['Accuracy', 'MCC']].to_numpy(float), atol=1e-12, rtol=0)
        ax = self.groups['B'][0]
        for bar, annotation, value in zip(ax.patches, ax.texts, values):
            bar.set_height(value)
            annotation.set_y(value + .012)
            annotation.set_text(f'{value:.4f}')
        ax.set_xticks(range(5), ['ACC', 'Weighted\nprecision', 'Weighted\nrecall', 'Weighted F1', 'MCC'])
        assert len(ax.texts) == 5
        assert all('Macro' not in tick.get_text() for tick in ax.get_xticklabels())
        record = {
            'modality': self.mod, 'figure': self.number, 'N': len(raw),
            'labels': 821, 'nonARG_included': True, 'averaging': 'weighted',
            'values': dict(zip(base.FIELDS, map(float, values))),
            'metrics_source': str(source), 'metrics_sha256': base.sha(source),
            'prediction_source': str(raw_path), 'prediction_sha256': base.sha(raw_path),
            'sequence_level_verification': True, 'ACC_MCC_unchanged': True,
        }
        AUDIT.append(record)


def main():
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 19, 'text.color': base.INK,
        'axes.labelcolor': base.INK, 'xtick.color': base.INK, 'ytick.color': base.INK,
        'figure.facecolor': 'none', 'axes.facecolor': 'none', 'savefig.transparent': True,
        'svg.fonttype': 'path', 'hatch.linewidth': .65, 'axes.linewidth': .8})
    OUT.mkdir(parents=True, exist_ok=True)
    for mod in ['Protein', 'DNA']:
        base.AUDIT[mod] = {}
        builder = WeightedBuilder(mod)
        builder.radar(); builder.bars(); builder.heatmap(); builder.umap()
        builder.matrices(); builder.errors(); builder.verify()
        builder.export(f'Figure{builder.number}B_{mod}_Subtype_weighted', ['B'])
        builder.export(f'Figure{builder.number}_{mod}_combined', None, True)
        plt.close(builder.fig)
    for record in AUDIT:
        assert base.sha(record['metrics_source']) == record['metrics_sha256']
        assert base.sha(record['prediction_source']) == record['prediction_sha256']
    (OUT / 'weighted_metrics_verified.json').write_text(json.dumps(AUDIT, indent=2), encoding='utf-8')
    print(json.dumps(AUDIT, indent=2))


if __name__ == '__main__':
    main()
