"""Two-panel paper figure: precision-selected types, with P/R/F1 on a common scale."""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/novel_gene_type_heatmaps_20260923/data/Novel_gene_per_type_precision_recall_F1.csv'
RAW_ROOT = Path('E:/1. ARGmodel/1. NonARG_training/new model result8.24/5. novel gene')
OUT = ROOT / 'outputs/novel_gene_publication_bars_20260925'
NAME = 'Novel_gene_selected_types_grouped_bars'
METRICS = [('Precision', '#4D86AA', -.25), ('Recall', '#D7A35B', 0), ('F1', '#71A392', .25)]
ORDER = ['Beta-lactams', 'Trimethoprim', 'Fosfomycin', 'Quinolones', 'Tetracyclines', 'Sulfonamide']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    source_frame = pd.read_csv(SOURCE, keep_default_na=False)
    hashes = {str(SOURCE): sha(SOURCE)}
    selected = source_frame.loc[source_frame.Support.gt(0) & source_frame.Precision.ge(.95)].copy()
    assert selected.groupby('Modality').size().to_dict() == {'AA': 6, 'NT': 2}
    selected['order'] = selected.Type_display.map({v: i for i, v in enumerate(ORDER)})
    assert selected.order.notna().all()
    selected = selected.sort_values(['Modality', 'order'])
    for mod, folder in [('AA', '1.Protein_novel_gene_100pct'), ('NT', '2.DNA_novel_gene_100pct')]:
        raw_path = RAW_ROOT / folder / 'test_sequence_predictions.csv'
        hashes[str(raw_path)] = sha(raw_path)
        raw = pd.read_csv(raw_path, keep_default_na=False)
        assert raw.sequence_id.is_unique and len(raw) == 4494
        ref = raw.loc[raw.true_ARG.eq(1)]
        assert len(ref) == 2247 and ref.novel_ARG_subtype.eq(1).all() and ref.split.eq('test').all()
        for row in source_frame.loc[source_frame.Modality.eq(mod)].itertuples():
            true = ref.true_type.eq(row.Type)
            pred = ref.predicted_type.eq(row.Type)
            tp, n, called = int((true & pred).sum()), int(true.sum()), int(pred.sum())
            assert (tp, n, called) == (row.TP, row.Support, row.Predicted)
            expected = [tp / called if called else 0, tp / n if n else 0,
                        2 * tp / (n + called) if (n + called) else 0]
            assert np.allclose(expected, [row.Precision, row.Recall, row.F1], rtol=0, atol=1e-12)
    selected.drop(columns='order').to_csv(OUT / 'Selected_types_source_data.csv', index=False, encoding='utf-8-sig')
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 9, 'text.color': '#222222',
                         'axes.labelcolor': '#222222', 'xtick.color': '#333333', 'ytick.color': '#222222',
                         'svg.hashsalt': 'novel-types-publication-20260925', 'pdf.fonttype': 42})
    fig = plt.figure(figsize=(180 / 25.4, 170 / 25.4), dpi=180, facecolor='none')
    legend_handles = [Patch(facecolor=color, edgecolor='none', label=metric) for metric, color, _ in METRICS]
    fig.legend(handles=legend_handles, loc='upper center', bbox_to_anchor=(.577, .998),
               ncol=3, frameon=False, fontsize=9.5, handlelength=1.7, handleheight=.85,
               handletextpad=.55, columnspacing=1.9, borderaxespad=0)
    bars, labels, axes = [], [], []
    for mod, panel, title_y, bottom, height in [('AA', 'A', .936, .375, .527), ('NT', 'B', .316, .093, .527 / 3)]:
        data = selected.loc[selected.Modality.eq(mod)]
        rows = list(data.itertuples())
        fig.text(.025, title_y, panel, fontsize=13, weight='bold', va='center')
        fig.text(.245, title_y, f'ARGScope-{mod}', fontsize=11.3, weight='bold', va='center')
        ax = fig.add_axes([.245, bottom, .657, height], facecolor='none')
        axes.append(ax)
        ax.set_xlim(0, 1)
        ax.set_ylim(len(rows) - .48, -.48)
        ax.set_yticks(np.arange(len(rows)), [f'{r.Type_display}\n(n = {r.Support})' for r in rows],
                      fontsize=9.6, linespacing=1.4)
        ax.tick_params(axis='y', length=0, pad=9)
        ax.set_xticks([0, .25, .5, .75, 1], ['0', '0.25', '0.50', '0.75', '1.00'], fontsize=9)
        ax.tick_params(axis='x', length=3, width=.65, pad=4)
        ax.grid(axis='x', color='#E3E7E9', linewidth=.55, zorder=0)
        ax.set_axisbelow(True)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        for key in ['left', 'bottom']:
            ax.spines[key].set_color('#6C7479')
            ax.spines[key].set_linewidth(.65)
        if mod == 'NT':
            ax.set_xlabel('Score', fontsize=10, labelpad=5)
        for i, row in enumerate(rows):
            for metric, color, offset in METRICS:
                value = float(getattr(row, metric))
                bar = ax.barh(i + offset, value, height=.205, color=color, edgecolor='none', zorder=3)
                bars.append((bar.patches[0], value))
                label = ax.text(value + .012, i + offset, f'{value:.4f}', ha='left', va='center',
                                fontsize=8.5, color='#222222', clip_on=False, zorder=4)
                labels.append(label)
    fig.text(.245, .016, 'Precision ≥ 0.95; reference ARG sequences only; n = reference count.',
             fontsize=8.0, ha='left', va='bottom')
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    outside, overlaps = [], []
    text_items = [t for t in fig.findobj(match=Text) if t.get_visible() and t.get_text()]
    for t in text_items:
        bbox = t.get_window_extent(renderer)
        if bbox.width and bbox.height and (bbox.x0 < -1 or bbox.y0 < -1 or bbox.x1 > width + 1 or bbox.y1 > height + 1):
            outside.append(t.get_text())
    for i, first in enumerate(labels):
        for second in labels[i + 1:]:
            if first.get_window_extent(renderer).overlaps(second.get_window_extent(renderer)):
                overlaps.append([first.get_text(), second.get_text()])
    assert not outside, outside
    assert not overlaps, overlaps
    assert len(bars) == 24 and all(abs(bar.get_width() - v) < 1e-14 for bar, v in bars)
    for ax in axes:
        assert ax.get_xlim() == (0, 1)
    with plt.rc_context({'svg.fonttype': 'path'}):
        fig.savefig(OUT / (NAME + '.svg'), transparent=True)
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / (NAME + '_editable.svg'), transparent=True)
    fig.savefig(OUT / (NAME + '.pdf'), transparent=True)
    fig.savefig(OUT / (NAME + '_transparent_300dpi.tif'), dpi=300, transparent=True,
                pil_kwargs={'compression': 'tiff_lzw'})
    with Image.open(OUT / (NAME + '_transparent_300dpi.tif')) as im:
        assert all(float(v) == 300 for v in im.info['dpi'])
        rgba = im.convert('RGBA')
        assert rgba.getchannel('A').getextrema() == (0, 255)
        image_size = im.size
    background = Image.new('RGBA', image_size, 'white')
    background.alpha_composite(rgba)
    background.convert('RGB').save(OUT / (NAME + '_white_300dpi.tif'), compression='tiff_lzw', dpi=(300, 300))
    preview = background.convert('RGB')
    preview.thumbnail((1276, 1206), Image.Resampling.LANCZOS)
    preview.save(OUT / (NAME + '_preview.png'))
    preview.convert('L').save(OUT / 'QA_grayscale.png')
    plt.close(fig)
    assert all(sha(Path(path)) == value for path, value in hashes.items())
    audit = {'display_id': 'novel-gene-precision-selected-types-v2', 'selection': 'Precision >= 0.95 and reference support > 0',
             'selection_applied_independently_per_model': True, 'selected_types': {'AA': 6, 'NT': 2},
             'metrics_displayed': ['Precision', 'Recall', 'F1'], 'number_of_bars': len(bars),
             'scope': '2247 reference ARG sequences only; subtype-disjoint test set',
             'label_n_definition': 'Reference sequences in the type, not predicted count',
             'recall_or_F1_filter': False, 'source_files_unchanged': True, 'full_results_retained': True,
             'physical_mm': [180, 170], 'tif_pixels': list(image_size), 'tif_dpi': [300, 300],
             'out_of_canvas_text': outside, 'overlapping_numeric_labels': overlaps, 'source_sha256': hashes,
             'author_review_status': 'Pending; no journal-specific compliance claim'}
    (OUT / 'verification.json').write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    print(json.dumps({'output': str(OUT), 'tif_pixels': image_size, 'physical_mm': [180, 170]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
