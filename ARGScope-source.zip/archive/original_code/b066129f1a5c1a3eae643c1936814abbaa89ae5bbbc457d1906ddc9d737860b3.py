#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# =============================================================================
# 1) Paths
# =============================================================================
SCRIPT_DIR = Path(__file__).resolve().parent
OUTDIR = SCRIPT_DIR / 'Protein_100pct_radial_comparison_FIXED'
OUTDIR.mkdir(parents=True, exist_ok=True)

SEARCH_PATTERNS = [
    '**/*longaa.csv',
    '**/*LongAA*.csv',
    '**/*long_aa*.csv',
]

MODEL_ORDER = ['PLM-ARG', 'ARGNet', 'DeepARG', 'Fungenetyper', 'ARGScope']
MODEL_COLORS = {
    'ARGNet': '#4C84C4',
    'DeepARG': '#7DB7E8',
    'Fungenetyper': '#C9DEF1',
    'PLM-ARG': '#F4F4F4',
    'ARGScope': '#1F5AA6',
}

METRIC_ORDER = ['Accuracy', 'Precision', 'Recall', 'F1-score', 'MCC']
METRIC_COLUMN_MAP = {
    'Accuracy':  ['ACC', 'Accuracy', 'accuracy', 'acc'],
    'Precision': ['Precision', 'precision'],
    'Recall':    ['Recall', 'recall'],
    'F1-score':  ['F1', 'f1', 'F1-score', 'f1-score'],
    'MCC':       ['MCC', 'mcc'],
}

# =============================================================================
# 2) Output / style settings
# =============================================================================
FIGSIZE = (7.2, 7.2)
DPI = 600
SAVE_TRANSPARENT = True
SAVE_PNG = True
SAVE_TIF = True
SAVE_PDF = True
SAVE_SVG = True

FONT_FAMILY = 'Arial'
TITLE = ''      # keep empty to remove top title
TITLE_SIZE = 14
METRIC_LABEL_SIZE = 12
RADIAL_TICK_SIZE = 8.5
LEGEND_SIZE = 9

# Ring geometry
VISUAL_INNER_RADIUS = 0.55    # larger -> bigger hole
VISUAL_OUTER_RADIUS = 1.18    # larger -> thicker ring / longer bars
BAR_SLOT_WIDTH = 0.20         # angular slot per bar, in abstract units
GROUP_GAP = 0.55              # gap between metric groups, in abstract units
BAR_WIDTH_SCALE = 0.82        # bar width inside its slot
BAR_EDGE_COLOR = '#4A4A4A'
BAR_EDGE_WIDTH = 0.8

# Radial scale
VALUE_MAX = 1.00
AUTO_PAD = 0.02               # extra padding below min metric value
MIN_ALLOWED = 0.00            # do not go below this unless your data are lower
MAX_TICKS = 8                 # prevent too many radial tick labels

# =============================================================================
# 3) Utilities
# =============================================================================
def infer_model_name(path: Path) -> str | None:
    s = f'{path.parent.name} {path.stem}'.lower().replace('_', ' ').replace('-', ' ')
    if 'argscope' in s:
        return 'ARGScope'
    if 'plm' in s and 'arg' in s:
        return 'PLM-ARG'
    if 'fungenetyper' in s:
        return 'Fungenetyper'
    if 'deeparg' in s:
        return 'DeepARG'
    if 'argnet' in s:
        return 'ARGNet'
    return None


def collect_input_files() -> dict[str, Path]:
    hits = []
    for pattern in SEARCH_PATTERNS:
        hits.extend(SCRIPT_DIR.glob(pattern))
    hits = sorted(set([p for p in hits if p.is_file()]))

    file_map: dict[str, Path] = {}
    for p in hits:
        model = infer_model_name(p)
        if model is None:
            continue
        if model not in file_map:
            file_map[model] = p
        else:
            # prefer exact canonical file names
            old = file_map[model]
            canonical = {
                'ARGNet': 'argnet_longaa.csv',
                'DeepARG': 'deeparg_longaa.csv',
                'Fungenetyper': 'fungenetyper_longaa.csv',
                'PLM-ARG': 'plmarg_longaa.csv',
                'ARGScope': 'argscope_longaa.csv',
            }[model]
            if p.name.lower() == canonical and old.name.lower() != canonical:
                file_map[model] = p
    return file_map


def find_metric_column(df: pd.DataFrame, candidate_names: list[str]) -> str:
    lower_map = {str(c).strip().lower(): c for c in df.columns}
    for name in candidate_names:
        key = name.strip().lower()
        if key in lower_map:
            return lower_map[key]
    raise KeyError(f'Cannot find metric column among: {candidate_names}')


def find_100pct_row(df: pd.DataFrame) -> pd.Series:
    first_col = df.columns[0]
    values = df[first_col].astype(str).str.strip().str.lower()

    exact_tokens = ['long aa', 'longaa', '100%', '100', '100p', '100pct', 'long_aa']
    for token in exact_tokens:
        hit = df.loc[values == token]
        if not hit.empty:
            return hit.iloc[0]

    contains = values.str.contains(r'long\s*aa|100', regex=True, na=False)
    hit = df.loc[contains]
    if not hit.empty:
        return hit.iloc[0]

    raise ValueError('Cannot find the 100% / LongAA row.')


def load_model_summary(path: Path, model_name: str) -> dict:
    df = pd.read_csv(path)
    row = find_100pct_row(df)
    out = {'Model': model_name, 'File': str(path)}
    for metric in METRIC_ORDER:
        col = find_metric_column(df, METRIC_COLUMN_MAP[metric])
        out[metric] = float(row[col])
    return out


def choose_tick_step(vmin: float, vmax: float) -> float:
    span = vmax - vmin
    if span <= 0.06:
        return 0.01
    if span <= 0.12:
        return 0.02
    if span <= 0.25:
        return 0.05
    return 0.10


def compute_scale_bounds(values: np.ndarray) -> tuple[float, np.ndarray]:
    actual_min = float(np.min(values))
    proposed_min = actual_min - AUTO_PAD
    step = choose_tick_step(proposed_min, VALUE_MAX)
    scale_min = math.floor(proposed_min / step) * step
    scale_min = min(scale_min, actual_min)  # never above actual min
    scale_min = max(MIN_ALLOWED, scale_min) if actual_min >= MIN_ALLOWED else scale_min
    scale_min = round(scale_min, 3)

    ticks = np.arange(scale_min, VALUE_MAX + step * 0.5, step)
    if len(ticks) > MAX_TICKS:
        step = choose_tick_step(scale_min, VALUE_MAX)
        while len(np.arange(scale_min, VALUE_MAX + step * 0.5, step)) > MAX_TICKS:
            step *= 2
        ticks = np.arange(scale_min, VALUE_MAX + step * 0.5, step)
    ticks = np.round(ticks, 3)
    return scale_min, ticks


def map_value_to_radius(value: float, scale_min: float) -> float:
    frac = (value - scale_min) / (VALUE_MAX - scale_min)
    frac = max(0.0, min(1.0, frac))
    return VISUAL_INNER_RADIUS + frac * (VISUAL_OUTER_RADIUS - VISUAL_INNER_RADIUS)


# =============================================================================
# 4) Plotting
# =============================================================================
def make_plot(summary_df: pd.DataFrame, out_prefix: Path) -> None:
    values = summary_df[METRIC_ORDER].to_numpy(dtype=float)
    scale_min, tick_values = compute_scale_bounds(values)
    tick_radii = [map_value_to_radius(v, scale_min) for v in tick_values]

    n_models = len(summary_df)
    n_metrics = len(METRIC_ORDER)

    # Build angular layout using abstract units, then map to 2pi.
    total_units = n_metrics * (n_models * BAR_SLOT_WIDTH + GROUP_GAP)
    unit_angle = 2 * np.pi / total_units
    actual_bar_width = BAR_SLOT_WIDTH * unit_angle * BAR_WIDTH_SCALE

    theta_list = []
    height_list = []
    color_list = []
    metric_centers = []

    current_unit = 0.0
    for metric in METRIC_ORDER:
        group_thetas = []
        for _, row in summary_df.iterrows():
            center_unit = current_unit + BAR_SLOT_WIDTH / 2
            theta = center_unit * unit_angle
            radius_value = map_value_to_radius(float(row[metric]), scale_min)

            theta_list.append(theta)
            height_list.append(radius_value - VISUAL_INNER_RADIUS)
            color_list.append(MODEL_COLORS[row['Model']])
            group_thetas.append(theta)
            current_unit += BAR_SLOT_WIDTH
        metric_centers.append(float(np.mean(group_thetas)))
        current_unit += GROUP_GAP

    fig = plt.figure(figsize=FIGSIZE)
    fig.patch.set_alpha(0 if SAVE_TRANSPARENT else 1)
    ax = plt.subplot(111, polar=True)
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, VISUAL_OUTER_RADIUS + 0.18)

    # Bars
    ax.bar(
        theta_list,
        height_list,
        width=actual_bar_width,
        bottom=VISUAL_INNER_RADIUS,
        color=color_list,
        edgecolor=BAR_EDGE_COLOR,
        linewidth=BAR_EDGE_WIDTH,
        align='center',
        zorder=3,
    )

    # Grid and ticks
    ax.set_yticks(tick_radii)
    ax.set_yticklabels([f'{v:.3f}' for v in tick_values], fontsize=RADIAL_TICK_SIZE)
    ax.set_rlabel_position(0)
    ax.yaxis.grid(True, color='#D7D7D7', linewidth=0.85)
    ax.xaxis.grid(True, color='#E4E4E4', linewidth=0.85)
    ax.set_xticks([])

    # Draw center white/transparent hole to match reference style.
    center_circle = plt.Circle(
        (0.5, 0.5), 0.18, transform=ax.transAxes,
        facecolor=(1, 1, 1, 0 if SAVE_TRANSPARENT else 1),
        edgecolor='#D8D8D8', linewidth=0.8, zorder=4,
    )
    ax.add_artist(center_circle)

    # Metric labels
    label_radius = VISUAL_OUTER_RADIUS + 0.11
    for theta, metric in zip(metric_centers, METRIC_ORDER):
        ax.text(theta, label_radius, metric, ha='center', va='center', fontsize=METRIC_LABEL_SIZE)

    # Title
    if TITLE:
        ax.set_title(TITLE, fontsize=TITLE_SIZE, pad=20)

    # Legend
    handles = [Patch(facecolor=MODEL_COLORS[m], edgecolor=BAR_EDGE_COLOR, linewidth=0.8, label=m)
               for m in MODEL_ORDER]
    ax.legend(
        handles=handles,
        loc='center left',
        bbox_to_anchor=(1.02, 0.28),
        frameon=True,
        facecolor=(1, 1, 1, 0.92),
        edgecolor='#D0D0D0',
        fontsize=LEGEND_SIZE,
        borderpad=0.35,
        labelspacing=0.25,
        handlelength=1.3,
        handletextpad=0.45,
    )

    # Save summary text for debugging
    summary_lines = [f'Radial scale min: {scale_min:.3f}', 'Tick values: ' + ', '.join(f'{x:.3f}' for x in tick_values)]
    (out_prefix.parent / 'radial_scale_info.txt').write_text('\n'.join(summary_lines), encoding='utf-8')

    plt.tight_layout()

    if SAVE_PNG:
        fig.savefig(out_prefix.with_suffix('.png'), dpi=DPI, transparent=SAVE_TRANSPARENT)
    if SAVE_TIF:
        fig.savefig(out_prefix.with_suffix('.tif'), dpi=DPI, transparent=SAVE_TRANSPARENT)
    if SAVE_PDF:
        fig.savefig(out_prefix.with_suffix('.pdf'), transparent=SAVE_TRANSPARENT)
    if SAVE_SVG:
        fig.savefig(out_prefix.with_suffix('.svg'), transparent=SAVE_TRANSPARENT)
    plt.close(fig)


# =============================================================================
# 5) Main
# =============================================================================
def main() -> None:
    plt.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': [FONT_FAMILY, 'DejaVu Sans', 'Liberation Sans'],
        'pdf.fonttype': 42,
        'ps.fonttype': 42,
        'svg.fonttype': 'none',
        'axes.unicode_minus': False,
        'savefig.facecolor': 'none' if SAVE_TRANSPARENT else 'white',
        'savefig.edgecolor': 'none' if SAVE_TRANSPARENT else 'white',
    })

    file_map = collect_input_files()

    print('=' * 100)
    print('100% LongAA protein radial comparison (FIXED)')
    print('=' * 100)
    print('Search root:', SCRIPT_DIR)
    print('Found files:')
    for model in MODEL_ORDER:
        print(f'  {model:12s}: {file_map.get(model, "NOT FOUND")}')

    missing = [m for m in MODEL_ORDER if m not in file_map]
    if missing:
        raise FileNotFoundError('Missing required model CSV(s): ' + ', '.join(missing))

    rows = [load_model_summary(file_map[model], model) for model in MODEL_ORDER]
    summary_df = pd.DataFrame(rows)
    summary_df.to_csv(OUTDIR / 'protein_100pct_model_summary.csv', index=False, encoding='utf-8-sig')

    print('\nExtracted 100% values:')
    print(summary_df[['Model'] + METRIC_ORDER].to_string(index=False))

    make_plot(summary_df, OUTDIR / 'protein_100pct_radial_comparison_fixed')

    print('\nSaved to:', OUTDIR)
    print('Done.')


if __name__ == '__main__':
    main()
