"""Legend-only refresh of the two verified 100% subtype panels."""
from pathlib import Path
import json
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image
import plot_argscope_including_nonarg as plot

HERE = Path(__file__).resolve().parent
OLD = plot.FIGURES
OUT = HERE / 'outputs/argscope_subtype_legend_update_20260922'
plot.FIGURES = OUT
plot.font_manager.findfont('Arial', fallback_to_default=False)
plot.plt.rcParams.update({
    'font.family': 'Arial', 'font.size': 11, 'svg.fonttype': 'path',
    'pdf.fonttype': 42, 'axes.linewidth': .75, 'hatch.linewidth': .55,
    'figure.facecolor': 'none', 'axes.facecolor': 'none',
    'savefig.facecolor': 'none', 'savefig.transparent': True,
    'text.color': '#20282E',
})
frames = []
for modality in ['Protein', 'DNA']:
    source = OLD / 'plot_data' / modality / 'B_subtype_macro_values.csv'
    frames.append(pd.read_csv(source))
metrics = pd.concat(frames, ignore_index=True)

for modality, expected in [('Protein', 'ARGScope-AA (Subtype)'), ('DNA', 'ARGScope-NT (Subtype)')]:
    (OUT / 'plot_data' / modality).mkdir(parents=True, exist_ok=True)
    plot.bars(modality, metrics)
    before = pd.read_csv(OLD / 'plot_data' / modality / 'B_subtype_macro_values.csv')
    after = pd.read_csv(OUT / 'plot_data' / modality / 'B_subtype_macro_values.csv')
    pd.testing.assert_frame_equal(before, after)
    entry = plot.AUDIT[-1]
    svg = ET.parse(entry['editable_svg']).getroot()
    texts = [node.text for node in svg.findall('.//{http://www.w3.org/2000/svg}text')]
    assert expected in texts
    for value in before[plot.FIELDS].iloc[0]:
        assert f'{value:.4f}' in texts
    png = OUT / 'previews' / Path(entry['outlined_svg']).parent.name / (entry['panel'] + '.png')
    assert Image.open(png).getchannel('A').getextrema()[0] == 0
    entry.update(legend=expected, data_unchanged=True, change='legend only')

(OUT / 'plot_data/legend_verification.json').write_text(
    json.dumps(plot.AUDIT, ensure_ascii=False, indent=2), encoding='utf-8')
print('PASS: both legends updated, numerical data unchanged, transparent vector SVGs.')
