# -*- coding: utf-8 -*-
"""
Batch prediction for real-data DNABERT-2 .pt embeddings using trained ARGScope DNA model

功能：
1. 批量读取 DATA_DIR 下所有子文件夹中的 .pt embedding 文件。
2. 同一个文件夹内部的多个 .pt 文件视为同一批数据，合并统计。
3. 每个文件夹内部输出 3 个 CSV：

   1) ARGScope_ARG_summary.csv
      - 统计该文件夹总 embedding 数
      - 预测为 ARG 的数量
      - ARG 占比
      - nonARG 数量和占比

   2) ARGScope_ARG_subtype_counts.csv
      - 预测出的 ARG subtype
      - 每种 subtype 的数量
      - 占总 embedding 的比例
      - 占 ARG embedding 的比例

   3) ARGScope_ARG_ids.csv
      - 预测为 ARG 的原始 ID
      - 来源 pt 文件
      - Pred_Subtype
      - subtype_confidence
      - subtype_margin

说明：
- 判断 ARG 的规则：
      Pred_Subtype 不是 nonarg / non_arg / non-arg / non arg / NONARG
- 如果 .pt 文件中包含 ids / KEY / seq_ids 等字段，会使用原始 ID。
- 如果 .pt 文件中没有 ID，会自动生成：
      文件名__row_0
      文件名__row_1
      ...
- 适配 PyTorch 2.6+ 的 torch.load(weights_only=False)。
"""

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader


# =========================
# 1. 路径配置
# =========================

# 当前脚本所在目录：建议把本脚本放在 fusion_teacher_dna_student_outputs 文件夹内运行
SCRIPT_DIR = Path(__file__).resolve().parent

# 模型文件所在目录
MODEL_DIR = SCRIPT_DIR

# 真实数据 DNABERT-2 embedding .pt 总文件夹
# 程序会自动识别其中每个包含 .pt 文件的子文件夹，例如 argtest_1_1, argtest_2_1 等
DATA_DIR = Path(
    r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V2\all_merged_fasta_chunks\dnabert2_embeddings_pt"
)

# 优先使用兼容真实数据 pt 的 checkpoint
CHECKPOINT_FILE = MODEL_DIR / "model_checkpoint_real_pt_compatible.pth"
if not CHECKPOINT_FILE.exists():
    CHECKPOINT_FILE = MODEL_DIR / "model_checkpoint.pth"

SCALER_DNA_FILE = MODEL_DIR / "scaler_dna.joblib"
ENCODER_FILE = MODEL_DIR / "subtype_encoder.joblib"

# 每个数据文件夹内部输出的 3 个 CSV
OUT_ARG_SUMMARY_NAME = "ARGScope_ARG_summary.csv"
OUT_ARG_SUBTYPE_COUNTS_NAME = "ARGScope_ARG_subtype_counts.csv"
OUT_ARG_IDS_NAME = "ARGScope_ARG_ids.csv"

# 如果某些 .pt 文件报错，在模型目录保存总错误日志
SKIPPED_LOG_FILE = MODEL_DIR / "ARGScope_skipped_pt_files_by_folder.csv"

BATCH_SIZE = 4096
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# =========================
# 2. 模型参数
# 必须和训练代码保持一致
# =========================

DNA_HIDDEN_DIM = 1024
EMBED_DIM = 512
NUM_RES_BLOCKS = 2
DROPOUT = 0.18
LOGIT_SCALE = 28.0
ARCFACE_MARGIN = 0.15


# =========================
# 3. 模型结构
# =========================

class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.25):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )

        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, embed_dim=512, dropout=0.25, num_blocks=2):
        super().__init__()

        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout=dropout)
            for _ in range(num_blocks)
        ])

        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.input(x)
        h = self.blocks(h)
        z = self.embedding(h)
        z = nn.functional.normalize(z, p=2, dim=1)
        return z


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=30.0, margin=0.20):
        super().__init__()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embed_dim))
        nn.init.xavier_uniform_(self.weight)

        self.scale = scale
        self.margin = margin

    def forward(self, z, labels=None):
        z = nn.functional.normalize(z, p=2, dim=1)
        w = nn.functional.normalize(self.weight, p=2, dim=1)
        cosine = nn.functional.linear(z, w)
        return cosine * self.scale


class DNAStudent(nn.Module):
    def __init__(self, dna_dim, num_classes):
        super().__init__()

        self.encoder = Encoder(
            input_dim=dna_dim,
            hidden_dim=DNA_HIDDEN_DIM,
            embed_dim=EMBED_DIM,
            dropout=DROPOUT,
            num_blocks=NUM_RES_BLOCKS,
        )

        self.head = ArcMarginHead(
            embed_dim=EMBED_DIM,
            num_classes=num_classes,
            scale=LOGIT_SCALE,
            margin=ARCFACE_MARGIN,
        )

    def forward(self, x, labels=None):
        z = self.encoder(x)
        logits_margin = self.head(z, labels=labels)
        logits_plain = self.head(z, labels=None)
        return logits_margin, logits_plain, z


# =========================
# 4. 判断 ARG / nonARG
# =========================

def is_nonarg_label(x):
    s = str(x).strip().lower()
    s = s.replace("-", "_").replace(" ", "_")

    nonarg_names = {
        "nonarg",
        "non_arg",
        "non_arg_gene",
        "non_resistance",
        "non_resistance_gene",
        "nonarg_gene",
        "non_arg_sequences",
        "non_arg_sequence",
        "non_antibiotic_resistance",
    }

    return s in nonarg_names


# =========================
# 5. 搜索所有包含 .pt 的文件夹
# =========================

def find_pt_folders(data_dir):
    """
    按 .pt 文件所在的直接父文件夹分组。

    例如：
        dnabert2_embeddings_pt/argtest_1_1/chunk_001.pt
        dnabert2_embeddings_pt/argtest_1_1/chunk_002.pt

    会归为同一个 folder：
        argtest_1_1
    """

    if not data_dir.exists():
        raise FileNotFoundError(f"找不到真实数据文件夹: {data_dir}")

    all_pt_files = sorted(data_dir.rglob("*.pt"))

    if len(all_pt_files) == 0:
        raise FileNotFoundError(f"在文件夹中没有找到任何 .pt 文件: {data_dir}")

    folder_to_files = {}

    for pt_file in all_pt_files:
        parent = pt_file.parent
        folder_to_files.setdefault(parent, []).append(pt_file)

    print(f"Found {len(all_pt_files)} .pt files under:")
    print(data_dir)

    print(f"\nFound {len(folder_to_files)} folders containing .pt files:")
    for folder, files in folder_to_files.items():
        print(f" - {folder} | pt files: {len(files)}")

    return folder_to_files


# =========================
# 6. 读取 .pt embedding 和 ID
# =========================

def find_2d_tensor_from_dict(obj):
    candidate_keys = [
        "embeddings",
        "embedding",
        "features",
        "feature",
        "x",
        "X",
        "dna_embeddings",
        "dnabert2_embeddings",
    ]

    for k in candidate_keys:
        if k in obj:
            v = obj[k]
            if torch.is_tensor(v) and v.ndim == 2:
                return k, v
            if isinstance(v, np.ndarray) and v.ndim == 2:
                return k, torch.tensor(v)

    for k, v in obj.items():
        if torch.is_tensor(v) and v.ndim == 2:
            return k, v
        if isinstance(v, np.ndarray) and v.ndim == 2:
            return k, torch.tensor(v)

    return None, None


def find_ids_from_dict(obj, n, pt_file):
    candidate_keys = [
        "ids",
        "id",
        "keys",
        "KEY",
        "names",
        "seq_ids",
        "sequence_ids",
        "gene_ids",
        "Geneid",
        "geneid",
        "NucleotideID",
        "ProteinID",
        "headers",
        "fasta_ids",
    ]

    for k in candidate_keys:
        if k in obj:
            v = obj[k]

            if isinstance(v, (list, tuple, np.ndarray)) and len(v) == n:
                return [str(x) for x in v]

            if torch.is_tensor(v) and len(v) == n:
                return [str(x) for x in v.cpu().numpy().tolist()]

    # 没有 ID 时，生成可追踪的 ID：文件名 + row index
    return [f"{pt_file.stem}__row_{i}" for i in range(n)]


def load_real_pt_embedding(pt_file):
    print(f"\nLoading real embedding file: {pt_file.name}")

    obj = torch.load(
        pt_file,
        map_location="cpu",
        weights_only=False
    )

    emb = None
    ids = None

    if isinstance(obj, dict):
        emb_key, emb = find_2d_tensor_from_dict(obj)

        if emb is None:
            print("当前 .pt 文件是 dict，但没有找到二维 embedding tensor。")
            print("dict keys:", list(obj.keys()))
            raise ValueError(f"无法从 .pt dict 中识别 embedding: {pt_file}")

        print(f"Detected embedding key: {emb_key}")
        emb = emb.float()
        ids = find_ids_from_dict(obj, emb.shape[0], pt_file)

    elif isinstance(obj, (list, tuple)):
        for item in obj:
            if torch.is_tensor(item) and item.ndim == 2:
                emb = item.float()
                break
            if isinstance(item, np.ndarray) and item.ndim == 2:
                emb = torch.tensor(item, dtype=torch.float32)
                break

        if emb is None:
            raise ValueError(f"无法从 list/tuple 中找到二维 embedding tensor: {pt_file}")

        n = emb.shape[0]

        for item in obj:
            if isinstance(item, (list, tuple, np.ndarray)) and len(item) == n:
                # 避免把数值矩阵误判成 ID
                if not (isinstance(item, np.ndarray) and item.ndim == 2):
                    ids = [str(x) for x in item]
                    break

        if ids is None:
            ids = [f"{pt_file.stem}__row_{i}" for i in range(n)]

    elif torch.is_tensor(obj):
        if obj.ndim != 2:
            raise ValueError(f"tensor 维度错误，期望 [N, D]，实际: {obj.shape}, 文件: {pt_file}")

        emb = obj.float()
        ids = [f"{pt_file.stem}__row_{i}" for i in range(emb.shape[0])]

    else:
        raise ValueError(f"不支持的 .pt 文件类型: {type(obj)}, 文件: {pt_file}")

    X = emb.cpu().numpy().astype(np.float32)

    if len(ids) != X.shape[0]:
        raise ValueError(
            f"ID 数量和 embedding 数量不一致: ids={len(ids)}, embeddings={X.shape[0]}, 文件={pt_file}"
        )

    print("Loaded embeddings:")
    print("  sample count:", X.shape[0])
    print("  embedding dim:", X.shape[1])
    print("  id count:", len(ids))

    return ids, X


# =========================
# 7. 加载模型
# =========================

def load_model_and_scaler():
    if not CHECKPOINT_FILE.exists():
        raise FileNotFoundError(f"找不到模型文件: {CHECKPOINT_FILE}")

    if not SCALER_DNA_FILE.exists():
        raise FileNotFoundError(f"找不到 scaler 文件: {SCALER_DNA_FILE}")

    if not ENCODER_FILE.exists():
        raise FileNotFoundError(f"找不到 subtype encoder 文件: {ENCODER_FILE}")

    print(f"\nLoading checkpoint: {CHECKPOINT_FILE}")

    checkpoint = torch.load(
        CHECKPOINT_FILE,
        map_location=DEVICE,
        weights_only=False
    )

    scaler_dna = joblib.load(SCALER_DNA_FILE)
    subtype_encoder = joblib.load(ENCODER_FILE)

    dna_dim = int(checkpoint.get("dna_dim"))
    num_classes = int(checkpoint.get("num_classes"))

    if "student_state_dicts" in checkpoint:
        student_state_dicts = checkpoint["student_state_dicts"]
    elif "student_state_dict" in checkpoint:
        student_state_dicts = [checkpoint["student_state_dict"]]
    else:
        raise KeyError("checkpoint 中没有 student_state_dicts 或 student_state_dict。")

    models = []

    for sd in student_state_dicts:
        model = DNAStudent(
            dna_dim=dna_dim,
            num_classes=num_classes,
        ).to(DEVICE)

        model.load_state_dict(sd, strict=True)
        model.eval()
        models.append(model)

    print("Loaded model:")
    print("  student models:", len(models))
    print("  dna_dim:", dna_dim)
    print("  num_classes:", num_classes)

    return models, scaler_dna, subtype_encoder, dna_dim


# =========================
# 8. 对一个 chunk 预测，并返回统计和 ARG ID 明细
# =========================

def predict_one_chunk_and_collect_arg_ids(
    models,
    X_scaled,
    ids,
    subtype_encoder,
    source_pt_file,
    folder_name
):
    dataset = TensorDataset(torch.tensor(X_scaled, dtype=torch.float32))

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    subtype_classes = subtype_encoder.classes_
    num_classes = len(subtype_classes)

    subtype_count_array = np.zeros(num_classes, dtype=np.int64)
    nonarg_count = 0
    arg_id_rows = []

    start_idx = 0
    total_seen = 0

    for batch_idx, (xb,) in enumerate(loader, start=1):
        xb = xb.to(DEVICE)

        batch_probs_sum = None

        with torch.no_grad():
            for model in models:
                model.eval()

                _, logits_plain, _ = model(xb, labels=None)
                probs = torch.softmax(logits_plain.float(), dim=1)

                if batch_probs_sum is None:
                    batch_probs_sum = probs
                else:
                    batch_probs_sum = batch_probs_sum + probs

            batch_probs_mean = batch_probs_sum / len(models)

            pred_idx = torch.argmax(batch_probs_mean, dim=1).cpu().numpy()
            probs_np = batch_probs_mean.cpu().numpy()

        batch_size_now = len(pred_idx)
        batch_ids = ids[start_idx:start_idx + batch_size_now]

        if len(batch_ids) != batch_size_now:
            raise ValueError("batch ID 数量与预测数量不一致")

        batch_counts = np.bincount(pred_idx, minlength=num_classes)
        subtype_count_array += batch_counts.astype(np.int64)

        sorted_probs = np.sort(probs_np, axis=1)[:, ::-1]
        confidence = sorted_probs[:, 0]

        if probs_np.shape[1] >= 2:
            margin = sorted_probs[:, 0] - sorted_probs[:, 1]
        else:
            margin = np.zeros_like(confidence)

        pred_subtypes = subtype_classes[pred_idx]

        for one_id, one_subtype, one_conf, one_margin in zip(
            batch_ids,
            pred_subtypes,
            confidence,
            margin
        ):
            if is_nonarg_label(one_subtype):
                nonarg_count += 1
            else:
                arg_id_rows.append({
                    "folder_name": folder_name,
                    "source_pt_file": source_pt_file.name,
                    "Original_ID": one_id,
                    "Pred_Subtype": one_subtype,
                    "subtype_confidence": float(one_conf),
                    "subtype_margin": float(one_margin),
                })

        start_idx += batch_size_now
        total_seen += batch_size_now

    return subtype_count_array, nonarg_count, total_seen, arg_id_rows


# =========================
# 9. 处理一个文件夹
# =========================

def process_one_folder(
    folder,
    pt_files,
    models,
    scaler_dna,
    subtype_encoder,
    dna_dim
):
    print("\n" + "=" * 100)
    print("Processing folder:")
    print(folder)
    print(f"PT files in this folder: {len(pt_files)}")

    num_classes = len(subtype_encoder.classes_)

    folder_subtype_count_array = np.zeros(num_classes, dtype=np.int64)
    folder_total_embeddings = 0
    folder_nonarg_count = 0

    skipped_files = []

    # ARG ID 文件可能很大，所以采用逐 chunk 追加写入，不一次性放内存
    out_arg_ids_csv = folder / OUT_ARG_IDS_NAME
    if out_arg_ids_csv.exists():
        out_arg_ids_csv.unlink()

    arg_ids_header_written = False

    for file_idx, pt_file in enumerate(pt_files, start=1):
        print("\n" + "-" * 80)
        print(f"Processing file {file_idx}/{len(pt_files)}")
        print(pt_file)

        try:
            ids, X_raw = load_real_pt_embedding(pt_file)

            if X_raw.shape[1] != dna_dim:
                raise ValueError(
                    f"embedding 维度与模型不一致。"
                    f" 文件维度={X_raw.shape[1]}, 模型维度={dna_dim}"
                )

            print("Scaling embeddings...")
            X_scaled = scaler_dna.transform(X_raw).astype(np.float32)

            print("Predicting and collecting ARG IDs...")
            chunk_count_array, chunk_nonarg_count, chunk_n, chunk_arg_rows = (
                predict_one_chunk_and_collect_arg_ids(
                    models=models,
                    X_scaled=X_scaled,
                    ids=ids,
                    subtype_encoder=subtype_encoder,
                    source_pt_file=pt_file,
                    folder_name=folder.name
                )
            )

            folder_subtype_count_array += chunk_count_array
            folder_nonarg_count += int(chunk_nonarg_count)
            folder_total_embeddings += int(chunk_n)

            # 追加保存该 chunk 中预测为 ARG 的 ID
            if len(chunk_arg_rows) > 0:
                chunk_arg_df = pd.DataFrame(chunk_arg_rows)

                chunk_arg_df.to_csv(
                    out_arg_ids_csv,
                    mode="a",
                    header=not arg_ids_header_written,
                    index=False,
                    encoding="utf-8-sig"
                )

                arg_ids_header_written = True

            print(f"Finished file {file_idx}/{len(pt_files)}")
            print(f"Chunk samples: {chunk_n}")
            print(f"Chunk predicted ARG: {len(chunk_arg_rows)}")
            print(f"Folder accumulated samples: {folder_total_embeddings}")

            del ids
            del X_raw
            del X_scaled
            del chunk_count_array
            del chunk_arg_rows

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        except Exception as e:
            print(f"[WARNING] Skip file due to error: {pt_file}")
            print("Error:", repr(e))

            skipped_files.append({
                "folder": str(folder),
                "file": str(pt_file),
                "error": repr(e)
            })
            continue

    if folder_total_embeddings == 0:
        print(f"[WARNING] No successful embeddings in folder: {folder}")

        # 即使没有成功，也输出空文件，避免后续找不到
        empty_summary = pd.DataFrame([{
            "folder_name": folder.name,
            "folder_path": str(folder),
            "total_pt_files_found": int(len(pt_files)),
            "total_pt_files_success": 0,
            "total_pt_files_skipped": int(len(pt_files)),
            "total_embeddings": 0,
            "predicted_ARG_count": 0,
            "predicted_ARG_percentage": 0.0,
            "predicted_nonARG_count": 0,
            "predicted_nonARG_percentage": 0.0,
            "predicted_ARG_subtype_count": 0,
        }])

        empty_summary.to_csv(folder / OUT_ARG_SUMMARY_NAME, index=False, encoding="utf-8-sig")

        empty_counts = pd.DataFrame(columns=[
            "folder_name",
            "Pred_Subtype",
            "Count",
            "Percentage_of_total_embeddings",
            "Percentage_of_predicted_ARG",
        ])
        empty_counts.to_csv(folder / OUT_ARG_SUBTYPE_COUNTS_NAME, index=False, encoding="utf-8-sig")

        empty_ids = pd.DataFrame(columns=[
            "folder_name",
            "source_pt_file",
            "Original_ID",
            "Pred_Subtype",
            "subtype_confidence",
            "subtype_margin",
        ])
        empty_ids.to_csv(folder / OUT_ARG_IDS_NAME, index=False, encoding="utf-8-sig")

        return skipped_files

    subtype_classes = subtype_encoder.classes_

    all_subtype_counts = pd.DataFrame({
        "Pred_Subtype": subtype_classes,
        "Count": folder_subtype_count_array
    })

    # 只保留被预测为 ARG 的 subtype，不保留 nonARG
    arg_subtype_counts = all_subtype_counts[
        (~all_subtype_counts["Pred_Subtype"].apply(is_nonarg_label))
        & (all_subtype_counts["Count"] > 0)
    ].copy()

    predicted_arg_count = int(arg_subtype_counts["Count"].sum())
    predicted_nonarg_count = int(folder_total_embeddings - predicted_arg_count)

    if predicted_arg_count > 0:
        arg_subtype_counts["Percentage_of_total_embeddings"] = (
            arg_subtype_counts["Count"] / folder_total_embeddings * 100
        )
        arg_subtype_counts["Percentage_of_predicted_ARG"] = (
            arg_subtype_counts["Count"] / predicted_arg_count * 100
        )
    else:
        arg_subtype_counts["Percentage_of_total_embeddings"] = 0.0
        arg_subtype_counts["Percentage_of_predicted_ARG"] = 0.0

    arg_subtype_counts = arg_subtype_counts.sort_values(
        by=["Count", "Pred_Subtype"],
        ascending=[False, True]
    ).reset_index(drop=True)

    arg_subtype_counts.insert(0, "folder_name", folder.name)

    summary_df = pd.DataFrame([{
        "folder_name": folder.name,
        "folder_path": str(folder),
        "total_pt_files_found": int(len(pt_files)),
        "total_pt_files_success": int(len(pt_files) - len(skipped_files)),
        "total_pt_files_skipped": int(len(skipped_files)),
        "total_embeddings": int(folder_total_embeddings),
        "predicted_ARG_count": int(predicted_arg_count),
        "predicted_ARG_percentage": float(predicted_arg_count / folder_total_embeddings * 100),
        "predicted_nonARG_count": int(predicted_nonarg_count),
        "predicted_nonARG_percentage": float(predicted_nonarg_count / folder_total_embeddings * 100),
        "predicted_ARG_subtype_count": int(len(arg_subtype_counts)),
    }])

    summary_csv = folder / OUT_ARG_SUMMARY_NAME
    subtype_counts_csv = folder / OUT_ARG_SUBTYPE_COUNTS_NAME

    summary_df.to_csv(
        summary_csv,
        index=False,
        encoding="utf-8-sig"
    )

    arg_subtype_counts.to_csv(
        subtype_counts_csv,
        index=False,
        encoding="utf-8-sig"
    )

    # 如果整个文件夹没有任何 ARG ID，也输出空的 ARG ID 文件
    if not out_arg_ids_csv.exists():
        empty_ids = pd.DataFrame(columns=[
            "folder_name",
            "source_pt_file",
            "Original_ID",
            "Pred_Subtype",
            "subtype_confidence",
            "subtype_margin",
        ])
        empty_ids.to_csv(
            out_arg_ids_csv,
            index=False,
            encoding="utf-8-sig"
        )

    print("\nFolder prediction finished.")
    print("Saved:", summary_csv)
    print("Saved:", subtype_counts_csv)
    print("Saved:", out_arg_ids_csv)

    print("\nSummary:")
    print(summary_df.to_string(index=False))

    print("\nTop 30 ARG subtypes:")
    if len(arg_subtype_counts) > 0:
        print(arg_subtype_counts.head(30).to_string(index=False))
    else:
        print("No ARG subtype predicted in this folder.")

    return skipped_files


# =========================
# 10. 主程序
# =========================

def main():
    print("Using device:", DEVICE)

    folder_to_files = find_pt_folders(DATA_DIR)

    models, scaler_dna, subtype_encoder, dna_dim = load_model_and_scaler()

    all_skipped_files = []

    for folder_idx, (folder, pt_files) in enumerate(folder_to_files.items(), start=1):
        print("\n" + "#" * 100)
        print(f"Folder {folder_idx}/{len(folder_to_files)}")

        skipped_files = process_one_folder(
            folder=folder,
            pt_files=pt_files,
            models=models,
            scaler_dna=scaler_dna,
            subtype_encoder=subtype_encoder,
            dna_dim=dna_dim
        )

        all_skipped_files.extend(skipped_files)

    if len(all_skipped_files) > 0:
        pd.DataFrame(all_skipped_files).to_csv(
            SKIPPED_LOG_FILE,
            index=False,
            encoding="utf-8-sig"
        )
        print("\nSkipped file log saved:", SKIPPED_LOG_FILE)

    print("\n" + "=" * 100)
    print("All folder-level predictions finished.")
    print("Each folder should contain:")
    print(f" - {OUT_ARG_SUMMARY_NAME}")
    print(f" - {OUT_ARG_SUBTYPE_COUNTS_NAME}")
    print(f" - {OUT_ARG_IDS_NAME}")


if __name__ == "__main__":
    main()