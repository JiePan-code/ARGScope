"""Redraw VF/BGC from verified numeric evidence, never from screenshot pixels.

All source files are read-only. Only subtype P/R/F1 averaging changes to weighted.
UMAP coordinates, checkpoint selection, class populations and type metrics stay fixed.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import shutil
import zipfile
import math

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, to_rgb
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'outputs/vf_bgc_merged_20260922_v6'
METRIC_ROOT = ROOT / 'outputs/vf_bgc_binary_positive_20260922'
TYPE_ROOT = ROOT / 'outputs/vf_bgc_including_negative_20260922/data'
OUT = ROOT / 'outputs/vf_bgc_weighted_A4_300DPI_20260925'
DELIVERY = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/VF_BGC_weighted_A4_300DPI_20260925')
W, H = 2480 / 300, 3508 / 300
INK = '#22343F'
GRAY = '#697782'
GRID = '#DCE3E7'
COLORS = {'AA': '#3B7F8C', 'NT': '#D4964B'}
LIGHT = {'AA': '#79ACB3', 'NT': '#E8BF84'}
METRICS = ['ACC', 'Precision', 'Recall', 'F1', 'MCC']
SOURCE_HASHES = {}
AUDIT = {'source_checks': [], 'figures': [], 'umap_checks': []}
FIGTEXT = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_frame(path, **kwargs):
    path = Path(path)
    SOURCE_HASHES[str(path)] = sha(path)
    return pd.read_csv(path, encoding='utf-8-sig', keep_default_na=False, **kwargs)


def load_json(path):
    path = Path(path)
    SOURCE_HASHES[str(path)] = sha(path)
    return json.loads(path.read_text(encoding='utf-8'))


def source_data():
    metrics = read_frame(METRIC_ROOT / 'data/all_metrics_binary_positive.csv')
    verification = load_json(METRIC_ROOT / 'verification.json')
    epochs = load_json(OLD / 'epoch_manifest.json')
    dataset = {}
    for domain in ['VF', 'BGC']:
        heat = read_frame(TYPE_ROOT / f'{domain}_heatmap_values.csv', index_col=0)
        palette = read_frame(OLD / 'plot_data' / domain / 'type_palette.csv')
        dataset[domain] = {'heat': heat, 'palette': palette,
                           'metrics': metrics[metrics.Domain.eq(domain)].copy(), 'umaps': []}
        negative = 'non-VF' if domain == 'VF' else 'nonBGC'
        for mod in ['AA', 'NT']:
            model = f'{domain}Scope-{mod}'
            source = next(row for row in verification['models'] if row['Model'] == model)
            source_path = Path(source['Source'])
            assert sha(source_path) == source['SHA256'], source_path
            frame = read_frame(source_path)
            assert frame.id.is_unique and frame.split.eq('test').all()
            assert len(frame) == source['N']
            for task, key, avg in [('Binary', 'binary', 'binary'),
                                   ('Subtype', 'subtype', 'weighted')]:
                truth, predicted = frame[f'true_{key}'], frame[f'predicted_{key}']
                if task == 'Binary':
                    truth = truth.ne(negative).astype(int)
                    predicted = predicted.ne(negative).astype(int)
                p, r, f, _ = precision_recall_fscore_support(
                    truth, predicted, average=avg, zero_division=0)
                result = [accuracy_score(truth, predicted), p, r, f,
                          matthews_corrcoef(truth, predicted)]
                reported = metrics.loc[metrics.Model.eq(model) & metrics.Task.eq(task) &
                                       metrics.Average.eq(avg), METRICS].iloc[0].to_numpy(float)
                np.testing.assert_allclose(result, reported, rtol=0, atol=1e-12)
                if task == 'Subtype':
                    labels = sorted(set(truth) | set(predicted))
                    pc, rc, fc, support = precision_recall_fscore_support(
                        truth, predicted, labels=labels, average=None, zero_division=0)
                    manual = [float(np.dot(v, support) / len(frame)) for v in [pc, rc, fc]]
                    np.testing.assert_allclose(manual, result[1:4], rtol=0, atol=1e-12)
                AUDIT['source_checks'].append({'model': model, 'task': task, 'average': avg,
                    'N': len(frame), 'values': dict(zip(METRICS, map(float, result))),
                    'sequence_level_recomputed': True})
            labels = heat.index.tolist()[1:]
            assert negative in labels
            p, r, f, _ = precision_recall_fscore_support(
                frame.true_type, frame.predicted_type, labels=labels, average=None, zero_division=0)
            for metric, values in zip(['Precision', 'Recall', 'F1'], [p, r, f]):
                expected = np.r_[values.mean(), values]
                np.testing.assert_allclose(expected, heat[f'{metric}_{mod}'].to_numpy(float),
                                           rtol=0, atol=1e-12)
        for entry in [e for e in epochs if e['domain'] == domain]:
            file = OLD / 'plot_data' / domain / 'umap' / (
                entry['variant'] + '_' + Path(entry['feature_file']).stem + '_umap.csv')
            points = read_frame(file)
            assert points.id.is_unique and len(points) == entry['samples']
            assert set(points.epoch) == {entry['epoch']}
            assert set(points.Type) <= set(palette.Type)
            assert np.isfinite(points[['UMAP1', 'UMAP2']].to_numpy()).all()
            dataset[domain]['umaps'].append((entry, points, file))
    return dataset


def ax_at(fig, x, top, width, height, **kwargs):
    return fig.add_axes([x / W, 1 - (top + height) / H, width / W, height / H],
                        facecolor='none', **kwargs)


def txt(fig, x, top, text, size=10, weight='normal', ha='left', **kwargs):
    t = fig.text(x / W, 1 - top / H, text, fontsize=size, color=INK,
                 weight=weight, ha=ha, va='top', **kwargs)
    FIGTEXT.setdefault(fig, []).append(t)
    return t


def letter(fig, x, top, label):
    return txt(fig, x, top, label, size=13, weight='bold')


def make_figure():
    return plt.figure(figsize=(W, H), dpi=150, facecolor='none')


def modality_legend(fig, x, top, size=9):
    handles = [Patch(facecolor=LIGHT[m], edgecolor=COLORS[m], linewidth=.6,
                     hatch=None if m == 'AA' else '///',
                     label='AA (protein)' if m == 'AA' else 'NT (DNA)') for m in ['AA', 'NT']]
    return fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(x / W, 1 - top / H),
                      ncol=2, frameon=False, fontsize=size, handlelength=1.5,
                      columnspacing=1.4, handletextpad=.45, borderaxespad=0)


def radar(fig, domain, data, box, small=False):
    ax = ax_at(fig, *box, projection='polar')
    theta = np.linspace(0, 2 * np.pi, 5, endpoint=False)
    angles = np.r_[theta, theta[0]]
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    for mod in ['AA', 'NT']:
        row = data['metrics'].loc[data['metrics'].Model.eq(f'{domain}Scope-{mod}') &
                                   data['metrics'].Task.eq('Binary')].iloc[0]
        values = row[METRICS].to_numpy(float)
        ax.plot(angles, np.r_[values, values[0]], color=COLORS[mod], lw=1.4,
                marker='o' if mod == 'AA' else 's', ms=2.8,
                linestyle='-' if mod == 'AA' else '--', zorder=4)
        ax.fill(angles, np.r_[values, values[0]], color=COLORS[mod], alpha=.06)
    names = ['ACC', 'P', 'R', 'F1', 'MCC'] if small else ['ACC', 'Precision', 'Recall', 'F1', 'MCC']
    ax.set_xticks(theta, names, fontsize=8.5 if small else 10.5)
    ax.tick_params(axis='x', pad=4 if small else 7)
    for tick, alignment in zip(ax.get_xticklabels(), ['center', 'left', 'left', 'right', 'right']):
        tick.set_horizontalalignment(alignment)
    ax.set_ylim(0, 1)
    ax.set_yticks([.25, .5, .75, 1], ['', '0.50', '', '1.00'],
                 fontsize=8 if small else 9, color=GRAY)
    ax.set_rlabel_position(20)
    ax.grid(color=GRID, lw=.55)
    ax.spines['polar'].set_color('#A9B6BF')
    ax.spines['polar'].set_linewidth(.7)
    return ax


def bars(fig, domain, data, box, small=False):
    ax = ax_at(fig, *box)
    xx = np.arange(5)
    for j, mod in enumerate(['AA', 'NT']):
        row = data['metrics'].loc[data['metrics'].Model.eq(f'{domain}Scope-{mod}') &
            data['metrics'].Task.eq('Subtype') & data['metrics'].Average.eq('weighted')].iloc[0]
        values = row[METRICS].to_numpy(float)
        patches = ax.bar(xx + (j - .5) * .35, values, width=.32,
                        color=LIGHT[mod], edgecolor=COLORS[mod], linewidth=.6,
                        hatch=None if mod == 'AA' else '///', zorder=3)
        np.testing.assert_allclose([p.get_height() for p in patches], values, rtol=0, atol=0)
        if not small:
            for patch, value in zip(patches, values):
                ax.text(patch.get_x() + patch.get_width() / 2, value + .025, f'{value:.4f}',
                        ha='center', va='bottom', fontsize=9.2, color=INK)
    names = ['ACC', 'P', 'R', 'F1', 'MCC'] if small else [
        'ACC', 'Weighted\nprecision', 'Weighted\nrecall', 'Weighted\nF1', 'MCC']
    ax.set_xticks(xx, names, fontsize=9 if small else 10)
    ax.tick_params(axis='x', length=0, pad=5)
    ax.set_ylim(0, 1.07 if small else 1.11)
    ax.set_yticks([0, .25, .5, .75, 1], ['0', '0.25', '0.50', '0.75', '1.00'],
                 fontsize=8 if small else 9.3)
    if not small:
        ax.set_ylabel('Score', fontsize=10, labelpad=3)
    ax.set_xlim(-.6, 4.6)
    ax.grid(axis='y', color=GRID, lw=.6, zorder=0)
    for s in ['top', 'right']:
        ax.spines[s].set_visible(False)
    for s in ['left', 'bottom']:
        ax.spines[s].set_color('#84949F')
        ax.spines[s].set_linewidth(.65)
    ax.tick_params(axis='y', length=2.5, color='#84949F')
    return ax


def wrapped(label):
    return {'Antimicrobial activity/Competitive advantage':
            'Antimicrobial activity/\nCompetitive advantage',
            'Nutritional/Metabolic factor': 'Nutritional/Metabolic\nfactor',
            'Post-translational modification': 'Post-translational\nmodification',
            'non-VF': 'Non-VF', 'nonBGC': 'Non-BGC'}.get(label, label)


CMAPS = {
    'VF': LinearSegmentedColormap.from_list('vf_teal', ['#F4F8F6', '#C8E1D9', '#8ABCB6', '#497F88', '#193D56']),
    'BGC': LinearSegmentedColormap.from_list('bgc_purple', ['#FAF6F3', '#E2D8E2', '#BAA8CB', '#88759F', '#493D68'])}


def contrast_ink(rgb):
    vals = np.asarray(rgb[:3])
    linear = np.where(vals <= .04045, vals / 12.92, ((vals + .055) / 1.055) ** 2.4)
    luminance = float(linear @ np.array([.2126, .7152, .0722]))
    return 'white' if luminance < .179 else '#000000'


def heatmap(fig, domain, data, box, small=False):
    matrix = data['heat'].to_numpy(float)
    labels = data['heat'].index.tolist()
    n = len(labels)
    heights = np.array([1.55 if '\n' in wrapped(label) else 1.0 for label in labels])
    ys = []
    cursor = -.5
    for i, height in enumerate(heights):
        ys.append(cursor + height / 2)
        cursor += height + (.33 if i == 0 else 0)
    ys = np.asarray(ys)
    ax = ax_at(fig, *box)
    cmap = CMAPS[domain]
    fs = 8.2 if small else 11.5
    labfs = 8.2 if small else 10
    for i, y in enumerate(ys):
        for j in range(6):
            value = float(matrix[i, j])
            color = cmap(value)
            ax.add_patch(Rectangle((j - .5, y - heights[i] / 2 + .025), 1, heights[i] - .05, facecolor=color,
                                  edgecolor='white', linewidth=.7))
            t = ax.text(j, y, f'{value:.4f}', ha='center', va='center', fontsize=fs,
                        color=contrast_ink(color))
            t.set_gid(f'{domain}-heat-{i}-{j}')
    ax.set_xlim(-.5, 5.5)
    ax.set_ylim(cursor, -.55)
    ax.set_yticks(ys, [wrapped(v) for v in labels], fontsize=labfs)
    ax.tick_params(axis='y', length=0, pad=6 if small else 8)
    for label in ax.get_yticklabels():
        label.set_linespacing(.92)
    ax.set_xticks(range(6), ['AA', 'NT'] * 3, fontsize=8.6 if small else 10.5)
    ax.tick_params(axis='x', length=0, pad=5)
    for tick in ax.get_xticklabels():
        tick.set_color(COLORS[tick.get_text()])
        tick.set_weight('bold')
    for k, title in enumerate(['Precision', 'Recall', 'F1']):
        ax.text((2 * k + 1) / 6, 1.013, title, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=9.8 if small else 12, color=INK)
    for x in [1.5, 3.5]:
        ax.axvline(x, color='white', lw=3)
    for s in ax.spines.values():
        s.set_visible(False)
    x, top, width, height = box
    cax = ax_at(fig, x + width + .055, top + .16, .052 if small else .075, height - .32)
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0, 1), cmap=cmap), cax=cax)
    cb.set_ticks([0, .25, .5, .75, 1], labels=['0', '0.25', '0.50', '0.75', '1.00'])
    cb.ax.tick_params(labelsize=8 if small else 9, length=0, pad=2)
    cb.outline.set_visible(False)
    return ax


def umap_row(fig, domain, data, top, side, gap, left, small=False):
    palette = dict(zip(data['palette'].Type, data['palette'].Color))
    for col, (entry, frame, file) in enumerate(data['umaps']):
        x = left + col * (side + gap)
        ax = ax_at(fig, x, top, side, side)
        order = np.random.default_rng(20260921).permutation(len(frame))
        points = frame.iloc[order]
        offsets = points[['UMAP1', 'UMAP2']].to_numpy()
        sc = ax.scatter(points.UMAP1, points.UMAP2, c=[palette[v] for v in points.Type],
                        s=1.3 if small else 1.65, alpha=.8, linewidths=0, rasterized=False)
        assert np.array_equal(np.asarray(sc.get_offsets()), offsets)
        low = frame[['UMAP1', 'UMAP2']].min().to_numpy()
        high = frame[['UMAP1', 'UMAP2']].max().to_numpy()
        center, half = (low + high) / 2, max(high - low) * .55
        ax.set_xlim(center[0] - half, center[0] + half)
        ax.set_ylim(center[1] - half, center[1] + half)
        ax.set_aspect('equal')
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel('UMAP1', fontsize=8.5 if small else 10, labelpad=2)
        if col == 0:
            ax.set_ylabel('UMAP2', fontsize=8.5 if small else 10, labelpad=3)
        for spine in ax.spines.values():
            spine.set_color('#89969E')
            spine.set_linewidth(.65)
        mod = 'Protein' if entry['variant'] == 'AA' else 'DNA'
        best = col % 2 == 1
        title = f'{mod} · ' + ('Best epoch' if best else 'Epoch 0')
        # Entire selected-checkpoint title is bold to keep it unmistakable at print size.
        ax.set_title(title, fontsize=9 if small else 10.5,
                     fontweight='bold' if best else 'normal', pad=5, color=INK)
        AUDIT['umap_checks'].append({'figure': fig.get_label(), 'domain': domain,
            'modality': entry['variant'], 'epoch': entry['epoch'], 'points': len(points),
            'source': str(file), 'source_sha256': SOURCE_HASHES[str(file)],
            'coordinates_unchanged': True, 'point_order_unchanged': True})


def type_legend(fig, domain, data, top, small=False):
    palette = data['palette']
    if domain == 'VF':
        groups = [list(range(0, 4)), list(range(4, 8)), list(range(8, 11)), list(range(11, 14))]
    else:
        groups = [[0, 1], [2, 3], [4, 5], [6]]
    starts = [.34, 2.27, 4.17, 6.19]
    fontsize = 8.1 if small else 9.4
    lineheight = fontsize / 72 * 1.12
    for x, indices in zip(starts, groups):
        pos = top
        for idx in indices:
            row = palette.iloc[idx]
            label = wrapped(row.Type)
            dot = Line2D([x / W], [1 - (pos + fontsize / 144) / H], transform=fig.transFigure,
                          marker='o', color=row.Color, ms=4 if small else 4.8,
                          linestyle='none', markeredgewidth=0)
            fig.add_artist(dot)
            txt(fig, x + .08, pos, label, size=fontsize, linespacing=1.02)
            pos += lineheight * (label.count('\n') + 1) + (.024 if small else .06)


def combined(data):
    fig = make_figure()
    fig.set_label('VF_BGC_combined_weighted_A4_300DPI')
    modality_legend(fig, W / 2, .07, 9.4)
    configs = [('VF', .04, .50, 2.24, 'A', 'B'), ('BGC', 4.19, 4.65, 6.39, 'C', 'D')]
    for domain, lx, rx, bx, a, b in configs:
        letter(fig, lx, .37, a)
        txt(fig, rx + .65, .40, f'{domain}/non-{domain}', size=10, ha='center')
        radar(fig, domain, data[domain], [rx, .94, 1.22, 1.22], small=True)
        letter(fig, bx - .14, .37, b)
        txt(fig, bx + .82, .38, f'{domain} · Subtype\n(weighted)', size=9.8, ha='center', linespacing=1.05)
        bars(fig, domain, data[domain], [bx + .10, .79, 1.61, 1.49], small=True)
    txt(fig, W / 2, 2.55, 'P = precision, R = recall. Radars: positive-class metrics. Subtype bars: weighted P/R/F1.',
        size=8.3, ha='center')
    letter(fig, .05, 2.81, 'E')
    letter(fig, 4.47, 2.81, 'F')
    heatmap(fig, 'VF', data['VF'], [1.51, 3.06, 2.62, 3.19], small=True)
    heatmap(fig, 'BGC', data['BGC'], [5.20, 3.06, 2.63, 2.60], small=True)
    txt(fig, 6.45, 5.96, 'Average: macro across all types\nand the non-target class',
        size=8.6, ha='center', linespacing=1.3)
    letter(fig, .05, 6.48, 'G')
    txt(fig, .29, 6.50, 'VF', size=10.5, weight='bold')
    umap_row(fig, 'VF', data['VF'], 6.85, 1.52, .43, .39, small=True)
    type_legend(fig, 'VF', data['VF'], 8.64, small=True)
    letter(fig, .05, 9.38, 'H')
    txt(fig, .29, 9.40, 'BGC', size=10.5, weight='bold')
    umap_row(fig, 'BGC', data['BGC'], 9.68, 1.52, .43, .39, small=True)
    type_legend(fig, 'BGC', data['BGC'], 11.39, small=True)
    return fig


def individual(domain, data):
    fig = make_figure()
    fig.set_label(f'{domain}_weighted_A4_300DPI')
    txt(fig, .24, .14, f'{domain} | Full-length sequence annotation', size=14, weight='bold')
    modality_legend(fig, 6.55, .45, 10)
    letter(fig, .16, .68, 'A')
    txt(fig, 1.47, .69, f'{domain}/non-{domain} classification', size=11, ha='center')
    radar(fig, domain, data, [.61, 1.34, 1.52, 1.52])
    letter(fig, 3.02, .68, 'B')
    txt(fig, 5.76, .74, 'Subtype prediction (weighted)', size=11.5, ha='center')
    bars(fig, domain, data, [3.43, 1.13, 4.47, 1.80])
    letter(fig, .16, 3.48, 'C')
    txt(fig, .45, 3.52, 'Biosynthetic types' if domain == 'BGC' else 'Virulence-factor types',
        size=11.5, weight='bold')
    heatmap(fig, domain, data, [2.10 if domain == 'VF' else 1.35, 3.94,
                               5.30 if domain == 'VF' else 6.05, 3.73])
    txt(fig, 4.8, 7.94, f'Average: macro across {len(data["heat"])-2} {domain} types and Non-{domain}',
        size=9.6, ha='center')
    letter(fig, .16, 8.20, 'D')
    txt(fig, .45, 8.24, 'Representations during training', size=11.5, weight='bold')
    umap_row(fig, domain, data, 8.63, 1.63, .35, .37, small=False)
    type_legend(fig, domain, data, 10.54, small=False)
    return fig


def validate_text_bounds(fig):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    issues = []
    for t in fig.findobj(match=Text):
        if not t.get_visible() or not t.get_text().strip():
            continue
        # Axis objects contain duplicate invisible-by-axis labels. Count only rendered labels.
        if t.axes is not None and not t.axes.get_visible():
            continue
        box = t.get_window_extent(renderer)
        if box.width == 0 or box.height == 0:
            continue
        if box.x0 < -1 or box.y0 < -1 or box.x1 > width + 1 or box.y1 > height + 1:
            issues.append({'text': t.get_text(), 'bounds': list(map(float, box.extents))})
    return issues


def save(fig):
    name = fig.get_label()
    bounds = validate_text_bounds(fig)
    # Exports preserve an exact A4 raster canvas, not bbox_inches='tight'.
    p = OUT / f'{name}_transparent.tif'
    fig.savefig(p, dpi=300, transparent=True, pil_kwargs={'compression': 'tiff_lzw'})
    rgba = Image.open(p).convert('RGBA')
    assert rgba.size == (2480, 3508)
    white = Image.new('RGBA', rgba.size, 'white')
    white.alpha_composite(rgba)
    white.convert('RGB').save(OUT / f'{name}_white.tif', dpi=(300, 300), compression='tiff_lzw')
    preview = white.convert('RGB')
    preview.thumbnail((1240, 1754), Image.Resampling.LANCZOS)
    preview.save(OUT / 'previews' / f'{name}.png')
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / 'editable_svg' / f'{name}.svg', transparent=True)
    checks = []
    for suffix in ['transparent', 'white']:
        image_path = OUT / f'{name}_{suffix}.tif'
        with Image.open(image_path) as im:
            assert im.size == (2480, 3508)
            assert all(abs(float(v) - 300) < .001 for v in im.info['dpi'])
            assert im.info.get('compression') == 'tiff_lzw'
            if suffix == 'transparent':
                alpha = np.asarray(im.getchannel('A'))
                assert np.count_nonzero(alpha == 0) > alpha.size * .1
            checks.append({'file': str(image_path), 'size': list(im.size), 'DPI': [float(v) for v in im.info['dpi']],
                           'mode': im.mode, 'compression': im.info['compression']})
    AUDIT['figures'].append({'name': name, 'outside_canvas': bounds, 'formats': checks})
    print(json.dumps({'figure': name, 'outside_canvas': bounds}, ensure_ascii=False), flush=True)
    plt.close(fig)


def main():
    for folder in [OUT, OUT / 'previews', OUT / 'editable_svg', OUT / 'data']:
        folder.mkdir(parents=True, exist_ok=True)
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10, 'text.color': INK,
                         'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK,
                         'hatch.linewidth': .45, 'savefig.pad_inches': 0,
                         'svg.hashsalt': 'vf-bgc-weighted-a4-20260925', 'pdf.fonttype': 42})
    data = source_data()
    print('Verified sequence-level weighted metrics, binary positive-class metrics, and type heatmaps.', flush=True)
    save(combined(data))
    for domain in ['VF', 'BGC']:
        save(individual(domain, data[domain]))
        data[domain]['heat'].to_csv(OUT / 'data' / f'{domain}_heatmap_values_unchanged.csv')
        data[domain]['metrics'].to_csv(OUT / 'data' / f'{domain}_metrics.csv', index=False)
    assert all(sha(Path(p)) == digest for p, digest in SOURCE_HASHES.items())
    AUDIT.update({'input_files_unmodified': True, 'source_hashes': SOURCE_HASHES,
                  'binary_average': 'positive class', 'subtype_average': 'weighted',
                  'type_average': 'macro', 'UMAP_refitted': False,
                  'source_numeric_tolerance': 1e-12,
                  'AA_NT_colors': COLORS, 'dimensions_mm': [W * 25.4, H * 25.4]})
    (OUT / 'verification.json').write_text(json.dumps(AUDIT, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    # Delivery is performed separately only after visual review.
    print(str(OUT), flush=True)


if __name__ == '__main__':
    main()
