# -*- coding: utf-8 -*-
"""
对 3 个外部方法分别单独比较：

1. DeepARG_ss
2. DeepARG_short
3. ARG-OAP 3

每个外部方法都会单独输出：
1) 9个数据集的 5×6 相对差异热图
   - 行：Gate 0.10–0.50
   - 列：DIAMOND 0.2, 0.5, 0.6, 0.7, 0.8, 0.9
   - 颜色：相对差异百分比
       (ARGScope - external) / external × 100%
   - 格子文字：
       ARGScope count
       相对差异百分比

2) 每个数据集最接近该外部方法的前5个配置图（颜色表示DIAMOND阈值）

3) CSV结果：
   - all_comparisons_*.csv
   - best_configuration_per_dataset_*.csv
   - top5_configurations_per_dataset_*.csv

输入目录：
E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed
"""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import Patch


# =============================================================================
# 1. 路径与参数
# =============================================================================

BASE_DIR = Path(
    r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed"
)

EXTERNAL_FILE = BASE_DIR / "DeepARG_ARGOAP.csv"

GATE_FOLDERS: Dict[float, str] = {
    0.10: "ARGScope_DIAMOND_gate010_realdata_predictions",
    0.20: "ARGScope_DIAMOND_gate020_realdata_predictions",
    0.30: "ARGScope_DIAMOND_gate030_realdata_predictions",
    0.40: "ARGScope_DIAMOND_gate040_realdata_predictions",
    0.50: "ARGScope_DIAMOND_gate050_realdata_predictions",
}

DIAMOND_THRESHOLDS = ["0.2", "0.5", "0.6", "0.7", "0.8", "0.9"]

MATRIX_FILE_NAME = "all_thresholds_final_ARG_count_matrix.csv"
SUMMARY_FILE_NAME = "sample_summary.csv"

OUTPUT_DIR = BASE_DIR / "ARGScope_vs_3_external_methods_heatmap_comparison"

METHOD_CONFIGS = [
    {
        "source_column": "DeepARG_Count",
        "method_name": "DeepARG_ss",
        "safe_name": "DeepARG_ss",
    },
    {
        "source_column": "DeepARG_short",
        "method_name": "DeepARG_short",
        "safe_name": "DeepARG_short",
    },
    {
        "source_column": "ARG-OAP 3",
        "method_name": "ARG-OAP 3",
        "safe_name": "ARG_OAP_3",
    },
]

DPI = 300
TOP_N = 5

# None 表示按当前方法绝对相对差异的98%分位数自动确定对称颜色范围
COLOR_LIMIT_PERCENT: Optional[float] = None


# =============================================================================
# 2. 通用工具
# =============================================================================

def natural_key(text: str) -> Tuple:
    parts = re.split(r"(\d+)", str(text))
    return tuple(int(part) if part.isdigit() else part.lower() for part in parts)


def normalize_sample_name(value: object) -> str:
    text = str(value).strip()
    replacements = {
        "ARGbert": "argbert",
        "Argbert": "argbert",
        "argBERT": "argbert",
        "ARGscope": "argscope",
        "Argscope": "argscope",
        "ARGScope": "argscope",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.lower()


def normalize_diamond(value: object) -> str:
    text = str(value).strip().lower().replace("diamond", "")
    return f"{float(text):.1f}"


def normalize_sample_column(df: pd.DataFrame, source_file: Path) -> pd.DataFrame:
    candidates = ["sample_name", "Sample", "sample", "dataset", "Dataset", "Type"]
    sample_column = next((column for column in candidates if column in df.columns), None)

    if sample_column is None:
        first_column = df.columns[0]
        if not str(first_column).startswith("final_ARG_count_diamond"):
            sample_column = first_column

    if sample_column is None:
        raise ValueError(
            f"无法识别样品列：{source_file}\n现有列：{list(df.columns)}"
        )

    return df.rename(columns={sample_column: "sample_name"})


def extract_diamond_from_column(column_name: str) -> Optional[str]:
    match = re.search(
        r"(?:final_ARG_count_)?diamond(\d+(?:\.\d+)?)$",
        str(column_name),
    )
    if not match:
        return None
    return normalize_diamond(match.group(1))


def configuration_label(gate_threshold: float, diamond_threshold: str) -> str:
    return f"Gate {gate_threshold:.2f} + DIAMOND {diamond_threshold}"


def make_method_output_paths(safe_name: str) -> Dict[str, Path]:
    return {
        "method_dir": OUTPUT_DIR / safe_name,
        "heatmap_file": OUTPUT_DIR / safe_name / f"{safe_name}_relative_difference_heatmaps.png",
        "top5_file": OUTPUT_DIR / safe_name / f"top5_closest_configurations_to_{safe_name}.png",
        "all_csv": OUTPUT_DIR / safe_name / f"all_comparisons_{safe_name}.csv",
        "best_csv": OUTPUT_DIR / safe_name / f"best_configuration_per_dataset_{safe_name}.csv",
        "top5_csv": OUTPUT_DIR / safe_name / f"top5_configurations_per_dataset_{safe_name}.csv",
    }


# =============================================================================
# 3. 读取 ARGScope 结果
# =============================================================================

def read_one_sample_summary(
    gate_threshold: float,
    diamond_threshold: str,
    summary_file: Path,
) -> pd.DataFrame:
    df = pd.read_csv(summary_file, encoding="utf-8-sig")
    df = normalize_sample_column(df, summary_file)

    if "final_ARG_count" not in df.columns:
        raise ValueError(f"{summary_file} 中没有 final_ARG_count 列。")

    output = pd.DataFrame({
        "sample_name": df["sample_name"].map(normalize_sample_name),
        "ARGScope_count": pd.to_numeric(df["final_ARG_count"], errors="coerce"),
    })
    output["gate_threshold"] = float(gate_threshold)
    output["diamond_threshold"] = normalize_diamond(diamond_threshold)

    output = output.dropna(subset=["sample_name", "ARGScope_count"]).copy()
    output["ARGScope_count"] = output["ARGScope_count"].astype(int)

    return output[
        ["gate_threshold", "diamond_threshold", "sample_name", "ARGScope_count"]
    ]


def read_matrix_fallback(gate_threshold: float, matrix_file: Path) -> pd.DataFrame:
    df = pd.read_csv(matrix_file, encoding="utf-8-sig")
    df = normalize_sample_column(df, matrix_file)
    df = df[df["sample_name"].notna()].copy()
    df["sample_name"] = df["sample_name"].map(normalize_sample_name)

    count_columns: List[str] = []
    column_to_diamond: Dict[str, str] = {}

    for column in df.columns:
        diamond_threshold = extract_diamond_from_column(str(column))
        if diamond_threshold is not None:
            count_columns.append(column)
            column_to_diamond[column] = diamond_threshold

    if not count_columns:
        return pd.DataFrame(
            columns=[
                "gate_threshold",
                "diamond_threshold",
                "sample_name",
                "ARGScope_count",
            ]
        )

    long_df = df.melt(
        id_vars=["sample_name"],
        value_vars=count_columns,
        var_name="source_column",
        value_name="ARGScope_count",
    )
    long_df["diamond_threshold"] = long_df["source_column"].map(column_to_diamond)
    long_df["gate_threshold"] = float(gate_threshold)
    long_df["ARGScope_count"] = pd.to_numeric(long_df["ARGScope_count"], errors="coerce")

    long_df = long_df.dropna(
        subset=["sample_name", "diamond_threshold", "ARGScope_count"]
    ).copy()
    long_df["ARGScope_count"] = long_df["ARGScope_count"].astype(int)

    return long_df[
        ["gate_threshold", "diamond_threshold", "sample_name", "ARGScope_count"]
    ]


def collect_argscope_results() -> pd.DataFrame:
    all_gate_frames: List[pd.DataFrame] = []

    for gate_threshold, folder_name in sorted(GATE_FOLDERS.items()):
        gate_dir = BASE_DIR / folder_name

        if not gate_dir.is_dir():
            print(f"[WARNING] Gate目录不存在：{gate_dir}", flush=True)
            continue

        summary_frames: List[pd.DataFrame] = []

        for diamond_threshold in DIAMOND_THRESHOLDS:
            summary_file = gate_dir / f"diamond{diamond_threshold}" / SUMMARY_FILE_NAME

            if not summary_file.is_file():
                continue

            print(
                f"[READ SUMMARY] gate={gate_threshold:.2f}, "
                f"diamond={diamond_threshold} | {summary_file}",
                flush=True,
            )

            summary_frames.append(
                read_one_sample_summary(
                    gate_threshold=gate_threshold,
                    diamond_threshold=diamond_threshold,
                    summary_file=summary_file,
                )
            )

        if summary_frames:
            gate_df = pd.concat(summary_frames, ignore_index=True)
        else:
            gate_df = pd.DataFrame(
                columns=[
                    "gate_threshold",
                    "diamond_threshold",
                    "sample_name",
                    "ARGScope_count",
                ]
            )

        matrix_file = gate_dir / MATRIX_FILE_NAME
        if matrix_file.is_file():
            matrix_df = read_matrix_fallback(
                gate_threshold=gate_threshold,
                matrix_file=matrix_file,
            )
            if not matrix_df.empty:
                gate_df = pd.concat([gate_df, matrix_df], ignore_index=True)
                gate_df = gate_df.drop_duplicates(
                    subset=[
                        "gate_threshold",
                        "diamond_threshold",
                        "sample_name",
                    ],
                    keep="first",
                )

        all_gate_frames.append(gate_df)

    if not all_gate_frames:
        raise FileNotFoundError("没有读取到任何 ARGScope 结果。")

    combined = pd.concat(all_gate_frames, ignore_index=True)
    combined["gate_threshold"] = pd.to_numeric(combined["gate_threshold"], errors="coerce")
    combined["diamond_threshold"] = combined["diamond_threshold"].map(normalize_diamond)
    combined["sample_name"] = combined["sample_name"].map(normalize_sample_name)
    combined["ARGScope_count"] = pd.to_numeric(combined["ARGScope_count"], errors="coerce")

    combined = combined.dropna(
        subset=[
            "gate_threshold",
            "diamond_threshold",
            "sample_name",
            "ARGScope_count",
        ]
    ).copy()

    combined["ARGScope_count"] = combined["ARGScope_count"].astype(int)

    combined = combined.drop_duplicates(
        subset=["gate_threshold", "diamond_threshold", "sample_name"],
        keep="first",
    )

    return combined


# =============================================================================
# 4. 读取外部结果
# =============================================================================

def read_external_results_for_method(source_column: str, method_name: str) -> pd.DataFrame:
    if not EXTERNAL_FILE.is_file():
        raise FileNotFoundError(f"找不到外部结果文件：{EXTERNAL_FILE}")

    df = pd.read_csv(EXTERNAL_FILE, encoding="utf-8-sig")
    df = normalize_sample_column(df, EXTERNAL_FILE)

    if source_column not in df.columns:
        raise ValueError(f"{EXTERNAL_FILE} 中没有 '{source_column}' 列。")

    output = df[["sample_name", source_column]].copy()
    output = output.rename(columns={source_column: "external_count"})
    output["sample_name"] = output["sample_name"].map(normalize_sample_name)
    output["external_count"] = pd.to_numeric(output["external_count"], errors="coerce")

    output = output.dropna(subset=["sample_name", "external_count"]).copy()
    output["external_count"] = output["external_count"].astype(int)
    output["method_name"] = method_name

    return output


# =============================================================================
# 5. 构建比较表
# =============================================================================

def build_comparison_table(
    argscope_df: pd.DataFrame,
    external_df: pd.DataFrame,
    safe_name: str,
) -> pd.DataFrame:
    samples = sorted(external_df["sample_name"].unique(), key=natural_key)

    expected = pd.MultiIndex.from_product(
        [sorted(GATE_FOLDERS), DIAMOND_THRESHOLDS, samples],
        names=["gate_threshold", "diamond_threshold", "sample_name"],
    ).to_frame(index=False)

    complete = expected.merge(
        argscope_df,
        on=["gate_threshold", "diamond_threshold", "sample_name"],
        how="left",
    )

    missing = complete[complete["ARGScope_count"].isna()].copy()
    if not missing.empty:
        missing_file = OUTPUT_DIR / safe_name / f"missing_combinations_{safe_name}.csv"
        missing.to_csv(missing_file, index=False, encoding="utf-8-sig")
        print(
            f"[WARNING] {safe_name}: 有 {len(missing)} 个配置结果缺失，已输出：{missing_file}",
            flush=True,
        )

    comparison = complete.merge(external_df, on="sample_name", how="left")
    comparison["count_difference"] = comparison["ARGScope_count"] - comparison["external_count"]
    comparison["absolute_count_difference"] = comparison["count_difference"].abs()

    denominator = comparison["external_count"].replace(0, np.nan)
    comparison["relative_difference_percent"] = (
        comparison["count_difference"] / denominator * 100.0
    )
    comparison["absolute_relative_difference_percent"] = (
        comparison["relative_difference_percent"].abs()
    )
    comparison["configuration"] = comparison.apply(
        lambda row: configuration_label(
            float(row["gate_threshold"]),
            str(row["diamond_threshold"]),
        ),
        axis=1,
    )

    comparison = comparison.sort_values(
        ["sample_name", "diamond_threshold", "gate_threshold"],
        key=lambda series: series.map(natural_key) if series.name == "sample_name" else series,
    ).reset_index(drop=True)

    return comparison


# =============================================================================
# 6. 主热图
# =============================================================================

def determine_color_limit(comparison_df: pd.DataFrame) -> float:
    if COLOR_LIMIT_PERCENT is not None:
        return float(COLOR_LIMIT_PERCENT)

    finite_values = comparison_df["relative_difference_percent"].replace(
        [np.inf, -np.inf], np.nan
    ).dropna()

    if finite_values.empty:
        return 1.0

    absolute_values = np.abs(
        finite_values.to_numpy(dtype=float)
    )

    # 极端百分比会把其余格子的颜色压得很淡。
    # 使用98%分位数确定色阶，并通过色柱两端箭头表示超出范围的值。
    maximum = float(
        np.nanpercentile(
            absolute_values,
            98.0,
        )
    )

    if maximum == 0:
        return 1.0

    return maximum


def annotate_relative_heatmap(axis, count_matrix: np.ndarray, relative_matrix: np.ndarray) -> None:
    for row_index in range(count_matrix.shape[0]):
        for column_index in range(count_matrix.shape[1]):
            count_value = count_matrix[row_index, column_index]
            relative_value = relative_matrix[row_index, column_index]

            if (not np.isfinite(count_value)) or (not np.isfinite(relative_value)):
                text = "NA"
            else:
                sign = "+" if relative_value > 0 else ""
                text = f"{int(round(count_value)):,}\n{sign}{relative_value:.1f}%"

            axis.text(
                column_index,
                row_index,
                text,
                ha="center",
                va="center",
                fontsize=6.5,
            )


def plot_relative_difference_heatmaps(
    comparison_df: pd.DataFrame,
    method_name: str,
    safe_name: str,
    heatmap_file: Path,
) -> None:
    samples = sorted(comparison_df["sample_name"].unique(), key=natural_key)
    gates = sorted(GATE_FOLDERS)
    diamonds = DIAMOND_THRESHOLDS

    color_limit = determine_color_limit(comparison_df)
    norm = TwoSlopeNorm(vmin=-color_limit, vcenter=0.0, vmax=color_limit)

    n_columns = 3
    n_rows = math.ceil(len(samples) / n_columns)

    fig, axes = plt.subplots(
        n_rows,
        n_columns,
        figsize=(17, 15),
        squeeze=False,
    )

    image = None

    for sample_index, sample_name in enumerate(samples):
        axis = axes[sample_index // n_columns][sample_index % n_columns]
        sample_df = comparison_df[comparison_df["sample_name"] == sample_name].copy()

        relative_pivot = sample_df.pivot(
            index="gate_threshold",
            columns="diamond_threshold",
            values="relative_difference_percent",
        ).reindex(index=gates, columns=diamonds)

        count_pivot = sample_df.pivot(
            index="gate_threshold",
            columns="diamond_threshold",
            values="ARGScope_count",
        ).reindex(index=gates, columns=diamonds)

        relative_matrix = relative_pivot.to_numpy(dtype=float)
        count_matrix = count_pivot.to_numpy(dtype=float)

        image = axis.imshow(
            relative_matrix,
            aspect="auto",
            cmap="coolwarm",
            norm=norm,
        )

        axis.set_xticks(np.arange(len(diamonds)))
        axis.set_xticklabels([f"D{value}" for value in diamonds])

        axis.set_yticks(np.arange(len(gates)))
        axis.set_yticklabels([f"G{value:.1f}" for value in gates])

        external_values = sample_df["external_count"].dropna()
        external_count = int(external_values.iloc[0]) if not external_values.empty else 0

        axis.set_title(f"{sample_name}\n{method_name} = {external_count:,}")
        axis.set_xlabel("DIAMOND threshold")
        axis.set_ylabel("Gate threshold")

        annotate_relative_heatmap(
            axis=axis,
            count_matrix=count_matrix,
            relative_matrix=relative_matrix,
        )

    total_axes = n_rows * n_columns
    for axis_index in range(len(samples), total_axes):
        fig.delaxes(axes[axis_index // n_columns][axis_index % n_columns])

    # 使用独立的横向色柱，放在整张图下方。
    # 不再把色柱放在右侧，避免遮挡第三列子图。
    if image is not None:
        colorbar_axis = fig.add_axes(
            [0.22, 0.035, 0.56, 0.018]
        )
        colorbar = fig.colorbar(
            image,
            cax=colorbar_axis,
            orientation="horizontal",
            extend="both",
        )
        colorbar.set_label(
            f"Relative difference (%) = "
            f"(ARGScope - {method_name}) / {method_name} × 100",
            fontsize=10,
            labelpad=7,
        )
        colorbar.ax.tick_params(
            labelsize=9,
        )

    fig.suptitle(
        f"ARGScope versus {method_name} across all 30 configurations\n"
        f"Cell text: ARGScope count and relative difference",
        fontsize=15,
        y=0.985,
    )

    fig.subplots_adjust(
        left=0.06,
        right=0.97,
        bottom=0.105,
        top=0.91,
        wspace=0.25,
        hspace=0.38,
    )

    fig.savefig(heatmap_file, dpi=DPI, bbox_inches="tight")
    plt.close(fig)


# =============================================================================
# 7. Top-N 配置图
# =============================================================================

def prepare_top_configurations(comparison_df: pd.DataFrame) -> pd.DataFrame:
    valid = comparison_df.dropna(
        subset=[
            "ARGScope_count",
            "external_count",
            "absolute_relative_difference_percent",
        ]
    ).copy()

    top_df = (
        valid.sort_values(
            [
                "sample_name",
                "absolute_relative_difference_percent",
                "absolute_count_difference",
            ]
        )
        .groupby("sample_name", as_index=False, group_keys=False)
        .head(TOP_N)
        .copy()
    )

    return top_df


def plot_top5_configurations(
    top_df: pd.DataFrame,
    method_name: str,
    top5_file: Path,
) -> None:
    samples = sorted(top_df["sample_name"].unique(), key=natural_key)

    n_columns = 3
    n_rows = math.ceil(len(samples) / n_columns)

    fig, axes = plt.subplots(
        n_rows,
        n_columns,
        figsize=(18, 15),
        squeeze=False,
    )

    for sample_index, sample_name in enumerate(samples):
        axis = axes[sample_index // n_columns][sample_index % n_columns]
        sample_df = top_df[top_df["sample_name"] == sample_name].copy()

        sample_df = sample_df.sort_values(
            "absolute_relative_difference_percent",
            ascending=True,
        ).reset_index(drop=True)

        y = np.arange(len(sample_df))
        # 按 DIAMOND 阈值使用固定颜色。
        # 同一个 DIAMOND 阈值在全部9个数据集和3个外部方法中保持同一种颜色。
        diamond_color_map = {
            "0.2": "#4C78A8",
            "0.5": "#F58518",
            "0.6": "#54A24B",
            "0.7": "#E45756",
            "0.8": "#B279A2",
            "0.9": "#72B7B2",
        }

        bar_colors = [
            diamond_color_map.get(
                str(value),
                "#9E9E9E",
            )
            for value in sample_df["diamond_threshold"]
        ]

        axis.barh(
            y,
            sample_df["absolute_relative_difference_percent"],
            color=bar_colors,
            edgecolor="black",
            linewidth=0.55,
        )

        labels = [
            f"D{diamond} / G{gate:.1f}"
            for gate, diamond in zip(
                sample_df["gate_threshold"],
                sample_df["diamond_threshold"],
            )
        ]

        axis.set_yticks(y)
        axis.set_yticklabels(labels)
        axis.invert_yaxis()

        axis.set_xlabel("Absolute relative difference (%)")
        axis.set_title(sample_name)
        axis.grid(True, axis="x", alpha=0.25)

        for row_index, row in sample_df.iterrows():
            axis.text(
                row["absolute_relative_difference_percent"],
                row_index,
                f"  {row['absolute_relative_difference_percent']:.1f}%"
                f" | {int(row['ARGScope_count']):,} vs {int(row['external_count']):,}",
                va="center",
                fontsize=7.5,
            )

    total_axes = n_rows * n_columns
    for axis_index in range(len(samples), total_axes):
        fig.delaxes(axes[axis_index // n_columns][axis_index % n_columns])

    # 全图统一图例：颜色表示 DIAMOND 阈值。
    diamond_color_map = {
        "0.2": "#4C78A8",
        "0.5": "#F58518",
        "0.6": "#54A24B",
        "0.7": "#E45756",
        "0.8": "#B279A2",
        "0.9": "#72B7B2",
    }

    legend_handles = [
        Patch(
            facecolor=diamond_color_map[diamond],
            edgecolor="black",
            label=f"DIAMOND {diamond}",
        )
        for diamond in DIAMOND_THRESHOLDS
    ]

    fig.legend(
        handles=legend_handles,
        loc="upper center",
        ncol=6,
        bbox_to_anchor=(0.5, 0.965),
        frameon=False,
        fontsize=9,
    )

    fig.suptitle(
        f"Top {TOP_N} ARGScope configurations closest to {method_name} for each dataset",
        fontsize=15,
        y=0.995,
    )

    fig.tight_layout(rect=[0, 0, 1, 0.925])
    fig.savefig(top5_file, dpi=DPI, bbox_inches="tight")
    plt.close(fig)


# =============================================================================
# 8. 保存结果表
# =============================================================================

def save_result_tables(
    comparison_df: pd.DataFrame,
    top_df: pd.DataFrame,
    all_csv: Path,
    best_csv: Path,
    top5_csv: Path,
) -> None:
    output_columns = [
        "sample_name",
        "gate_threshold",
        "diamond_threshold",
        "configuration",
        "ARGScope_count",
        "external_count",
        "count_difference",
        "absolute_count_difference",
        "relative_difference_percent",
        "absolute_relative_difference_percent",
        "method_name",
    ]

    comparison_df[output_columns].to_csv(
        all_csv,
        index=False,
        encoding="utf-8-sig",
        float_format="%.4f",
    )

    top_df[output_columns].to_csv(
        top5_csv,
        index=False,
        encoding="utf-8-sig",
        float_format="%.4f",
    )

    best_df = (
        top_df.sort_values(
            [
                "sample_name",
                "absolute_relative_difference_percent",
                "absolute_count_difference",
            ]
        )
        .groupby("sample_name", as_index=False)
        .head(1)
        .copy()
    )

    best_df[output_columns].to_csv(
        best_csv,
        index=False,
        encoding="utf-8-sig",
        float_format="%.4f",
    )


# =============================================================================
# 9. 主程序
# =============================================================================

def main() -> None:
    print("=" * 96)
    print("ARGScope vs 3 external methods: 9 datasets × 30 configurations")
    print(f"Base directory: {BASE_DIR}")
    print(f"External file : {EXTERNAL_FILE}")
    print("=" * 96, flush=True)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[STEP] 读取 ARGScope 结果", flush=True)
    argscope_df = collect_argscope_results()

    for config in METHOD_CONFIGS:
        source_column = config["source_column"]
        method_name = config["method_name"]
        safe_name = config["safe_name"]
        paths = make_method_output_paths(safe_name)
        paths["method_dir"].mkdir(parents=True, exist_ok=True)

        print("-" * 96, flush=True)
        print(f"[METHOD] {method_name}", flush=True)

        external_df = read_external_results_for_method(
            source_column=source_column,
            method_name=method_name,
        )

        comparison_df = build_comparison_table(
            argscope_df=argscope_df,
            external_df=external_df,
            safe_name=safe_name,
        )

        top_df = prepare_top_configurations(comparison_df)

        print(f"[PLOT] 9-panel heatmaps for {method_name}", flush=True)
        plot_relative_difference_heatmaps(
            comparison_df=comparison_df,
            method_name=method_name,
            safe_name=safe_name,
            heatmap_file=paths["heatmap_file"],
        )

        print(f"[PLOT] Top {TOP_N} configurations for {method_name}", flush=True)
        plot_top5_configurations(
            top_df=top_df,
            method_name=method_name,
            top5_file=paths["top5_file"],
        )

        save_result_tables(
            comparison_df=comparison_df,
            top_df=top_df,
            all_csv=paths["all_csv"],
            best_csv=paths["best_csv"],
            top5_csv=paths["top5_csv"],
        )

        print(f"[DONE] {method_name}", flush=True)
        print(f"输出目录：{paths['method_dir']}", flush=True)

    print("=" * 96)
    print("全部完成。")
    print(f"总输出目录：{OUTPUT_DIR}")
    print("=" * 96)


if __name__ == "__main__":
    main()
