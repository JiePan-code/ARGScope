# -*- coding: utf-8 -*-
import re
import pandas as pd

# =========================
# 1. 输入输出文件
# =========================
DNA_FASTA = "VFDB_setB_nt.fas"
PROTEIN_FASTA = "VFDB_setB_pro.fas"

OUT_PRO_FASTA = "VFDB_matched_protein.fasta"
OUT_DNA_FASTA = "VFDB_matched_dna.fasta"
OUT_CSV = "VFDB_matched_summary.csv"
OUT_ERROR_CSV = "VFDB_pairing_errors.csv"

# =========================
# 2. 读取 FASTA
# =========================
def read_fasta(fasta_file):
    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))
                header = line
                seq_lines = []
            else:
                seq_lines.append(line)

        if header is not None:
            records.append((header, "".join(seq_lines)))

    return records


# =========================
# 3. 解析 header
#    现在按“原始 type/subtype”：
#    subtype = 方括号前半段
#    type    = 方括号后半段
# =========================
def parse_header(header):
    """
    示例:
    >VFG037170(gb|WP_001081754) (plc1) phospholipase C
    [Phospholipase C (VF0470) - Exotoxin (VFC0235)]
    [Acinetobacter baumannii 1656-2]

    输出:
    ID = VFG037170
    subtype = Phospholipase C
    type = Exotoxin
    """

    result = {
        "ID": "",
        "type": "",
        "subtype": "",
        "Subtype_ID": "",
        "Type_ID": "",
        "header": header
    }

    h = header.strip()
    if h.startswith(">"):
        h = h[1:].strip()

    # 1) 提取 ID（最前面的 VFGxxxx）
    m_id = re.match(r"^(\S+?)\(", h)
    if m_id:
        result["ID"] = m_id.group(1).strip()
    else:
        result["ID"] = h.split()[0]

    # 2) 提取中括号内容
    bracket_contents = re.findall(r"\[([^\[\]]+)\]", h)

    # 正常情况下：
    # 倒数第二个是 [Subtype (VFxxxx) - Type (VFCxxxx)]
    vf_block = ""
    if len(bracket_contents) >= 2:
        vf_block = bracket_contents[-2].strip()
    elif len(bracket_contents) == 1:
        vf_block = bracket_contents[0].strip()

    # 3) 解析 vf_block
    #    Subtype (VFxxxx) - Type (VFCxxxx)
    m_vf = re.match(
        r"^(.*?)\s*\((VF\d+)\)\s*-\s*(.*?)\s*\((VFC\d+)\)$",
        vf_block
    )
    if m_vf:
        result["subtype"] = m_vf.group(1).strip()
        result["Subtype_ID"] = m_vf.group(2).strip()
        result["type"] = m_vf.group(3).strip()
        result["Type_ID"] = m_vf.group(4).strip()

    return result


# =========================
# 4. FASTA 转 DataFrame
# =========================
def fasta_to_df(fasta_file, seq_col_name):
    records = read_fasta(fasta_file)
    rows = []

    for header, seq in records:
        info = parse_header(header)
        info[seq_col_name] = seq
        rows.append(info)

    return pd.DataFrame(rows)


# =========================
# 5. 序列换行
# =========================
def wrap_sequence(seq, width=80):
    return "\n".join(seq[i:i+width] for i in range(0, len(seq), width))


# =========================
# 6. 写 FASTA
# =========================
def write_fasta(df, seq_col, out_file):
    with open(out_file, "w", encoding="utf-8") as f:
        for _, row in df.iterrows():
            header = (
                f">{row['ID']} | subtype={row['subtype']} | type={row['type']}"
            )
            f.write(header + "\n")
            f.write(wrap_sequence(str(row[seq_col]).strip()) + "\n")


# =========================
# 7. 主流程
# =========================
dna_df = fasta_to_df(DNA_FASTA, "DNA_SEQUENCE")
pro_df = fasta_to_df(PROTEIN_FASTA, "PROTEIN_SEQUENCE")

print("DNA记录数:", len(dna_df))
print("Protein记录数:", len(pro_df))

# 去掉空格
for col in ["ID", "type", "subtype", "Subtype_ID", "Type_ID", "DNA_SEQUENCE"]:
    dna_df[col] = dna_df[col].astype(str).str.strip()

for col in ["ID", "type", "subtype", "Subtype_ID", "Type_ID", "PROTEIN_SEQUENCE"]:
    pro_df[col] = pro_df[col].astype(str).str.strip()

# 只保留所需列
dna_df = dna_df[["ID", "type", "subtype", "Subtype_ID", "Type_ID", "DNA_SEQUENCE"]].copy()
dna_df.columns = ["ID", "DNA_type", "DNA_subtype", "DNA_Subtype_ID", "DNA_Type_ID", "DNA_SEQUENCE"]

pro_df = pro_df[["ID", "type", "subtype", "Subtype_ID", "Type_ID", "PROTEIN_SEQUENCE"]].copy()
pro_df.columns = ["ID", "PRO_type", "PRO_subtype", "PRO_Subtype_ID", "PRO_Type_ID", "PROTEIN_SEQUENCE"]

# 按 ID 对齐
merged = pd.merge(
    pro_df,
    dna_df,
    on="ID",
    how="outer",
    indicator=True
)

# =========================
# 8. 错误记录定义
#    1) 只在一边出现
#    2) type 不一致
#    3) subtype 不一致
# =========================
error_mask = (
    (merged["_merge"] != "both") |
    (merged["PRO_type"] != merged["DNA_type"]) |
    (merged["PRO_subtype"] != merged["DNA_subtype"])
)

error_df = merged[error_mask].copy()
clean_df = merged[~error_mask].copy()

# =========================
# 9. 最终结果
# =========================
final_df = clean_df[[
    "ID",
    "PRO_type",
    "PRO_subtype",
    "PRO_Subtype_ID",
    "PRO_Type_ID",
    "PROTEIN_SEQUENCE",
    "DNA_SEQUENCE"
]].copy()

final_df.columns = [
    "ID",
    "type",
    "subtype",
    "Subtype_ID",
    "Type_ID",
    "PROTEIN_SEQUENCE",
    "DNA_SEQUENCE"
]

# 保存 CSV
final_df.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")
error_df.to_csv(OUT_ERROR_CSV, index=False, encoding="utf-8-sig")

# 输出 FASTA
write_fasta(final_df, "PROTEIN_SEQUENCE", OUT_PRO_FASTA)
write_fasta(final_df, "DNA_SEQUENCE", OUT_DNA_FASTA)

# =========================
# 10. 统计输出
# =========================
print("\n===== 完成 =====")
print("正确匹配数:", len(final_df))
print("错误记录数:", len(error_df))
print("Type 数量:", final_df["type"].nunique())
print("Subtype 数量:", final_df["subtype"].nunique())
print("Protein FASTA:", OUT_PRO_FASTA)
print("DNA FASTA:", OUT_DNA_FASTA)
print("汇总CSV:", OUT_CSV)
print("错误CSV:", OUT_ERROR_CSV)