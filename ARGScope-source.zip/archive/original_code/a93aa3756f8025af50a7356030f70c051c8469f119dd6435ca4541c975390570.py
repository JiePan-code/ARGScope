import random
import pandas as pd
from pathlib import Path


# ==========================================================
# 1. 输入文件
# ==========================================================

# BGC 的 id/type/Subtype 表
BGC_ID_TABLE = "protein_ID_列表.csv"

# BGC 对应的 protein 和 DNA FASTA
BGC_PROTEIN_FASTA = "BGC_protein.fasta"
BGC_DNA_FASTA = "BGC_dna.fasta"

# 旧版 protein embedding 文件
# BGC 和 nonBGC 都必须能在这个文件中找到
OLD_PROTEIN_EMBED_FILE = "BGC_protein_embed_1280(前一个版本).txt"

# nonBGC 总数据
NONBGC_CSV = "merged_shared_mapping_excludeMIBIG.csv"


# ==========================================================
# 2. 输出文件
# ==========================================================

FINAL_PROTEIN_FASTA = "final_equal_BGC_nonBGC_protein.fasta"
FINAL_DNA_FASTA = "final_equal_BGC_nonBGC_dna.fasta"
FINAL_ID_TABLE = "final_equal_BGC_nonBGC_id_type_subtype.csv"

FILTERED_BGC_TABLE = "filtered_BGC_used_in_final_dataset.csv"
REMOVED_BGC_NOT_IN_OLD_EMBED = "removed_BGC_not_in_old_protein_embedding.csv"

MISSING_BGC_PROTEIN = "missing_BGC_protein_ids.csv"
MISSING_BGC_DNA = "missing_BGC_dna_ids.csv"

NONBGC_SAMPLED_TABLE = "sampled_nonBGC_mapping.csv"
SUMMARY_FILE = "final_equal_BGC_nonBGC_summary.csv"


# ==========================================================
# 3. 列名设置
# ==========================================================

BGC_ID_COL = "id"
BGC_TYPE_COL = "type"
BGC_SUBTYPE_COL = "Subtype"

NONBGC_PROTEIN_ID_COL = "protein_id"
NONBGC_PROTEIN_SEQ_COL = "protein_sequence"
NONBGC_DNA_ID_COL = "dna_id"
NONBGC_DNA_SEQ_COL = "dna_sequence"


# ==========================================================
# 4. 参数
# ==========================================================

RANDOM_SEED = 42
CHUNKSIZE = 3000
LINE_WIDTH = 80

# 如果 BGC_DNA_FASTA 的 header 不能和 BGC id 对上，
# 但 DNA FASTA 顺序和 BGC_ID_TABLE 顺序一致，可以设为 True。
ALLOW_BGC_DNA_ORDER_FALLBACK = True


# ==========================================================
# 5. 工具函数
# ==========================================================

def clean_id(x):
    if pd.isna(x):
        return ""

    x = str(x).strip()
    x = x.lstrip(">")

    if x == "" or x.lower() in ["nan", "none", "null"]:
        return ""

    parts = x.split()
    if len(parts) == 0:
        return ""

    return parts[0]


def clean_text(x):
    if pd.isna(x):
        return ""

    x = str(x).strip()
    x = x.replace("\n", " ")
    x = x.replace("\r", " ")
    x = " ".join(x.split())

    return x


def clean_sequence(seq):
    if pd.isna(seq):
        return ""

    seq = str(seq).strip()
    seq = seq.replace("\n", "")
    seq = seq.replace("\r", "")
    seq = seq.replace(" ", "")
    seq = seq.replace("\t", "")
    seq = seq.upper()

    return seq


def remove_version(x):
    x = clean_id(x)

    if x == "":
        return ""

    if "." in x:
        return x.rsplit(".", 1)[0]

    return x


def ids_match(query_id, id_set_full, id_set_nover):
    q = clean_id(query_id)
    q_nover = remove_version(q)

    if q in id_set_full:
        return True

    if q_nover in id_set_nover:
        return True

    return False


def check_required_columns(df, required_cols, file_name):
    for col in required_cols:
        if col not in df.columns:
            raise ValueError("{} 缺少列: {}".format(file_name, col))


def write_fasta_record(handle, seq_id, seq, line_width=80):
    seq_id = clean_id(seq_id)
    seq = clean_sequence(seq)

    handle.write(">{}\n".format(seq_id))

    for i in range(0, len(seq), line_width):
        handle.write(seq[i:i + line_width] + "\n")


# ==========================================================
# 6. 读取旧版 protein embedding ID
# ==========================================================

def read_embedding_ids(embed_file):
    """
    从旧版 embedding txt 中读取第一列 ID。
    支持空格、tab、逗号分隔。
    只读取 ID，不读取 1280 维特征。
    """
    embed_path = Path(embed_file)

    if not embed_path.exists():
        raise FileNotFoundError("找不到旧版 protein embedding 文件: {}".format(embed_file))

    id_full = set()
    id_nover = set()

    total_lines = 0
    valid_lines = 0

    with open(embed_path, "r", encoding="utf-8") as f:
        for line in f:
            total_lines += 1

            line = line.strip()
            if not line:
                continue

            first = line.replace(",", " ").split()[0]
            sid = clean_id(first)

            if sid == "":
                continue

            # 跳过可能的表头
            if sid.lower() in ["id", "protein_id", "geneid"]:
                continue

            id_full.add(sid)
            id_nover.add(remove_version(sid))
            valid_lines += 1

    print("读取旧版 protein embedding:", embed_file)
    print("总行数:", total_lines)
    print("有效 ID 数:", len(id_full))
    print("-" * 60)

    return id_full, id_nover


# ==========================================================
# 7. 读取 BGC id/type/Subtype 表，并按旧 embedding 过滤
# ==========================================================

def load_bgc_table(old_embed_ids_full, old_embed_ids_nover):
    bgc_path = Path(BGC_ID_TABLE)

    if not bgc_path.exists():
        raise FileNotFoundError("找不到 BGC ID 表: {}".format(BGC_ID_TABLE))

    df = pd.read_csv(BGC_ID_TABLE, dtype=str, low_memory=False)

    required_cols = [BGC_ID_COL, BGC_TYPE_COL, BGC_SUBTYPE_COL]
    check_required_columns(df, required_cols, BGC_ID_TABLE)

    df = df[[BGC_ID_COL, BGC_TYPE_COL, BGC_SUBTYPE_COL]].copy()
    df.columns = ["id", "type", "Subtype"]

    df["id"] = df["id"].apply(clean_id)
    df["type"] = df["type"].apply(clean_text)
    df["Subtype"] = df["Subtype"].apply(clean_text)

    df = df[df["id"] != ""].copy()
    df = df.drop_duplicates(subset=["id"], keep="first").reset_index(drop=True)

    print("BGC ID 表原始唯一样本数:", len(df))
    print("BGC type 分布:")
    print(df["type"].value_counts())

    in_old_embed_mask = df["id"].apply(
        lambda x: ids_match(x, old_embed_ids_full, old_embed_ids_nover)
    )

    removed_df = df[~in_old_embed_mask].copy()
    kept_df = df[in_old_embed_mask].copy().reset_index(drop=True)

    removed_df.to_csv(
        REMOVED_BGC_NOT_IN_OLD_EMBED,
        index=False,
        encoding="utf-8-sig"
    )

    print("=" * 60)
    print("按旧版 protein embedding 过滤 BGC")
    print("=" * 60)
    print("旧 embedding 中存在的 BGC 数:", len(kept_df))
    print("旧 embedding 中不存在、被移除的 BGC 数:", len(removed_df))
    print("被移除文件:", REMOVED_BGC_NOT_IN_OLD_EMBED)

    if len(kept_df) == 0:
        raise ValueError("按旧版 protein embedding 过滤后 BGC 数量为 0，请检查 ID 格式是否一致。")

    return kept_df


# ==========================================================
# 8. 读取 FASTA 并建立索引
# ==========================================================

def parse_fasta(fasta_file):
    fasta_file = Path(fasta_file)

    if not fasta_file.exists():
        raise FileNotFoundError("找不到 FASTA 文件: {}".format(fasta_file))

    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n").rstrip("\r")

            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))

                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line.strip())

        if header is not None:
            records.append((header, "".join(seq_lines)))

    print("读取 FASTA:", fasta_file)
    print("序列数:", len(records))

    return records


def build_fasta_index(records):
    exact_index = {}
    nover_index = {}

    for header, seq in records:
        rid = clean_id(header)
        rid_nover = remove_version(rid)

        seq = clean_sequence(seq)

        if rid and rid not in exact_index:
            exact_index[rid] = seq

        if rid_nover and rid_nover not in nover_index:
            nover_index[rid_nover] = seq

    return exact_index, nover_index


def get_seq_by_id(seq_index_exact, seq_index_nover, seq_id):
    sid = clean_id(seq_id)
    sid_nover = remove_version(sid)

    if sid in seq_index_exact:
        return seq_index_exact[sid], "exact"

    if sid_nover in seq_index_nover:
        return seq_index_nover[sid_nover], "without_version"

    return "", "not_found"


# ==========================================================
# 9. 从 BGC FASTA 中提取 BGC protein 和 DNA
# ==========================================================

def build_bgc_records(bgc_df):
    print("=" * 60)
    print("读取 BGC protein FASTA")
    print("=" * 60)

    protein_records = parse_fasta(BGC_PROTEIN_FASTA)
    protein_exact, protein_nover = build_fasta_index(protein_records)

    print("=" * 60)
    print("读取 BGC DNA FASTA")
    print("=" * 60)

    dna_records = parse_fasta(BGC_DNA_FASTA)
    dna_exact, dna_nover = build_fasta_index(dna_records)

    bgc_protein_out = []
    bgc_dna_out = []
    bgc_table_out_rows = []

    missing_protein = []
    missing_dna = []

    dna_seq_by_order = [clean_sequence(seq) for _, seq in dna_records]

    for i, row in bgc_df.iterrows():
        sid = clean_id(row["id"])

        protein_seq, protein_match = get_seq_by_id(
            protein_exact,
            protein_nover,
            sid
        )

        if protein_seq == "":
            missing_protein.append(sid)
            continue

        dna_seq, dna_match = get_seq_by_id(
            dna_exact,
            dna_nover,
            sid
        )

        if dna_seq == "" and ALLOW_BGC_DNA_ORDER_FALLBACK:
            if i < len(dna_seq_by_order):
                dna_seq = dna_seq_by_order[i]
                dna_match = "order_fallback"

        if dna_seq == "":
            missing_dna.append(sid)
            continue

        # 关键：protein 和 DNA FASTA 都用 protein id 作为 header，
        # 这样后续 AA/NT embedding 可以直接按 id 对齐。
        bgc_protein_out.append((sid, protein_seq))
        bgc_dna_out.append((sid, dna_seq))

        bgc_table_out_rows.append({
            "id": sid,
            "type": row["type"],
            "Subtype": row["Subtype"]
        })

    bgc_table_out = pd.DataFrame(bgc_table_out_rows)

    print("=" * 60)
    print("BGC FASTA 匹配结果")
    print("=" * 60)
    print("过滤后 BGC 表中 ID 数:", len(bgc_df))
    print("BGC protein/DNA 均匹配数量:", len(bgc_table_out))
    print("缺失 protein 数:", len(missing_protein))
    print("缺失 DNA 数:", len(missing_dna))

    if len(missing_protein) > 0:
        pd.DataFrame({"id": missing_protein}).to_csv(
            MISSING_BGC_PROTEIN,
            index=False,
            encoding="utf-8-sig"
        )
        print("缺失 protein ID 已保存:", MISSING_BGC_PROTEIN)

    if len(missing_dna) > 0:
        pd.DataFrame({"id": missing_dna}).to_csv(
            MISSING_BGC_DNA,
            index=False,
            encoding="utf-8-sig"
        )
        print("缺失 DNA ID 已保存:", MISSING_BGC_DNA)

    if len(bgc_table_out) == 0:
        raise ValueError(
            "BGC protein 和 DNA 均匹配数量为 0，请检查 BGC FASTA 的 header 是否和 protein_ID_列表.csv 的 id 一致。"
        )

    bgc_table_out.to_csv(
        FILTERED_BGC_TABLE,
        index=False,
        encoding="utf-8-sig"
    )
    print("最终使用的 BGC 表已保存:", FILTERED_BGC_TABLE)

    return bgc_protein_out, bgc_dna_out, bgc_table_out


# ==========================================================
# 10. 从 nonBGC 总表中随机抽取与 BGC 相同数量
#     限制：nonBGC protein_id 也必须在旧版 protein embedding 中存在
# ==========================================================

def sample_nonbgc_records(sample_n, old_embed_ids_full, old_embed_ids_nover):
    nonbgc_path = Path(NONBGC_CSV)

    if not nonbgc_path.exists():
        raise FileNotFoundError("找不到 nonBGC 文件: {}".format(NONBGC_CSV))

    required_cols = [
        NONBGC_PROTEIN_ID_COL,
        NONBGC_PROTEIN_SEQ_COL,
        NONBGC_DNA_ID_COL,
        NONBGC_DNA_SEQ_COL
    ]

    random.seed(RANDOM_SEED)

    reservoir = []
    seen_protein_ids = set()

    total_rows = 0
    bad_rows = 0
    duplicate_rows = 0
    not_in_old_embed_rows = 0
    valid_unique_count = 0

    print("=" * 60)
    print("开始 reservoir sampling 抽取 nonBGC")
    print("限制条件：nonBGC protein_id 必须存在于旧版 protein embedding 文件中")
    print("=" * 60)

    reader = pd.read_csv(
        NONBGC_CSV,
        dtype=str,
        chunksize=CHUNKSIZE,
        low_memory=False
    )

    for chunk_idx, chunk in enumerate(reader, start=1):
        check_required_columns(chunk, required_cols, NONBGC_CSV)

        for _, row in chunk.iterrows():
            total_rows += 1

            protein_id = clean_id(row[NONBGC_PROTEIN_ID_COL])
            protein_seq = clean_sequence(row[NONBGC_PROTEIN_SEQ_COL])
            dna_id = clean_id(row[NONBGC_DNA_ID_COL])
            dna_seq = clean_sequence(row[NONBGC_DNA_SEQ_COL])

            if protein_id == "" or protein_seq == "" or dna_id == "" or dna_seq == "":
                bad_rows += 1
                continue

            if protein_id in seen_protein_ids:
                duplicate_rows += 1
                continue

            # 新增规则：nonBGC 也必须在旧版 protein embedding 中找得到
            if not ids_match(protein_id, old_embed_ids_full, old_embed_ids_nover):
                not_in_old_embed_rows += 1
                continue

            seen_protein_ids.add(protein_id)
            valid_unique_count += 1

            item = {
                "id": protein_id,
                "type": "nonBGC",
                "Subtype": "nonBGC",
                "protein_id": protein_id,
                "protein_sequence": protein_seq,
                "dna_id": dna_id,
                "dna_sequence": dna_seq
            }

            if len(reservoir) < sample_n:
                reservoir.append(item)
            else:
                j = random.randint(0, valid_unique_count - 1)
                if j < sample_n:
                    reservoir[j] = item

        if chunk_idx % 10 == 0:
            print(
                "已处理 chunk: {}, 总行数: {}, 旧 embedding 中有效唯一 nonBGC: {}, 当前抽样池: {}".format(
                    chunk_idx,
                    total_rows,
                    valid_unique_count,
                    len(reservoir)
                )
            )

    if valid_unique_count < sample_n:
        raise ValueError(
            "旧版 protein embedding 中可用 nonBGC 数量 {} 小于需要抽样数量 {}，无法抽取等量数据。".format(
                valid_unique_count,
                sample_n
            )
        )

    nonbgc_df = pd.DataFrame(reservoir)

    print("=" * 60)
    print("nonBGC 抽样完成")
    print("=" * 60)
    print("nonBGC 总行数:", total_rows)
    print("空 ID/空序列无效行数:", bad_rows)
    print("重复 protein_id 行数:", duplicate_rows)
    print("不在旧版 protein embedding 中的 nonBGC 行数:", not_in_old_embed_rows)
    print("旧 embedding 中有效唯一 nonBGC 数:", valid_unique_count)
    print("最终抽样 nonBGC 数:", len(nonbgc_df))

    nonbgc_df.to_csv(
        NONBGC_SAMPLED_TABLE,
        index=False,
        encoding="utf-8-sig"
    )

    print("抽样 nonBGC mapping 已保存:", NONBGC_SAMPLED_TABLE)

    nonbgc_protein_out = []
    nonbgc_dna_out = []
    nonbgc_table_rows = []

    for _, row in nonbgc_df.iterrows():
        sid = clean_id(row["id"])

        # 关键：DNA FASTA 也使用 protein_id 作为 header，方便后续 AA/NT 对齐。
        nonbgc_protein_out.append((sid, clean_sequence(row["protein_sequence"])))
        nonbgc_dna_out.append((sid, clean_sequence(row["dna_sequence"])))

        nonbgc_table_rows.append({
            "id": sid,
            "type": "nonBGC",
            "Subtype": "nonBGC"
        })

    nonbgc_table_out = pd.DataFrame(nonbgc_table_rows)

    return nonbgc_protein_out, nonbgc_dna_out, nonbgc_table_out


# ==========================================================
# 11. 写出最终 FASTA 和 ID 表
# ==========================================================

def write_final_outputs(
    bgc_protein_records,
    bgc_dna_records,
    bgc_table,
    nonbgc_protein_records,
    nonbgc_dna_records,
    nonbgc_table
):
    final_protein_records = bgc_protein_records + nonbgc_protein_records
    final_dna_records = bgc_dna_records + nonbgc_dna_records

    final_table = pd.concat(
        [
            bgc_table[["id", "type", "Subtype"]],
            nonbgc_table[["id", "type", "Subtype"]]
        ],
        axis=0,
        ignore_index=True
    )

    dup_n = final_table["id"].duplicated().sum()

    if dup_n > 0:
        print("警告: final ID 表中存在重复 ID 数:", dup_n)
        final_table = final_table.drop_duplicates(subset=["id"], keep="first").reset_index(drop=True)

        keep_ids = set(final_table["id"].tolist())
        final_protein_records = [(sid, seq) for sid, seq in final_protein_records if sid in keep_ids]
        final_dna_records = [(sid, seq) for sid, seq in final_dna_records if sid in keep_ids]

    print("=" * 60)
    print("写出最终 protein FASTA")
    print("=" * 60)

    with open(FINAL_PROTEIN_FASTA, "w", encoding="utf-8") as f:
        for sid, seq in final_protein_records:
            write_fasta_record(f, sid, seq, LINE_WIDTH)

    print("Saved:", FINAL_PROTEIN_FASTA)
    print("protein 序列数:", len(final_protein_records))

    print("=" * 60)
    print("写出最终 DNA FASTA")
    print("=" * 60)

    with open(FINAL_DNA_FASTA, "w", encoding="utf-8") as f:
        for sid, seq in final_dna_records:
            write_fasta_record(f, sid, seq, LINE_WIDTH)

    print("Saved:", FINAL_DNA_FASTA)
    print("DNA 序列数:", len(final_dna_records))

    final_table.to_csv(
        FINAL_ID_TABLE,
        index=False,
        encoding="utf-8-sig"
    )

    print("Saved:", FINAL_ID_TABLE)
    print("ID 表样本数:", len(final_table))

    summary_df = pd.DataFrame([
        {
            "category": "BGC",
            "count": len(bgc_table)
        },
        {
            "category": "nonBGC",
            "count": len(nonbgc_table)
        },
        {
            "category": "final_total",
            "count": len(final_table)
        }
    ])

    summary_df.to_csv(
        SUMMARY_FILE,
        index=False,
        encoding="utf-8-sig"
    )

    print("Saved:", SUMMARY_FILE)

    print("=" * 60)
    print("最终 type 分布")
    print("=" * 60)
    print(final_table["type"].value_counts())

    print("=" * 60)
    print("最终 Subtype 分布前 30")
    print("=" * 60)
    print(final_table["Subtype"].value_counts().head(30))


# ==========================================================
# 12. 主函数
# ==========================================================

def main():
    print("=" * 60)
    print("Step 1. 读取旧版 protein embedding ID")
    print("=" * 60)

    old_embed_ids_full, old_embed_ids_nover = read_embedding_ids(OLD_PROTEIN_EMBED_FILE)

    print("=" * 60)
    print("Step 2. 读取并过滤 BGC id/type/Subtype 表")
    print("=" * 60)

    bgc_df = load_bgc_table(
        old_embed_ids_full=old_embed_ids_full,
        old_embed_ids_nover=old_embed_ids_nover
    )

    print("=" * 60)
    print("Step 3. 构建 BGC protein/DNA 记录")
    print("=" * 60)

    bgc_protein_records, bgc_dna_records, bgc_table = build_bgc_records(bgc_df)

    bgc_count = len(bgc_table)

    print("=" * 60)
    print("Step 4. 抽取同等数量 nonBGC")
    print("=" * 60)

    nonbgc_protein_records, nonbgc_dna_records, nonbgc_table = sample_nonbgc_records(
        sample_n=bgc_count,
        old_embed_ids_full=old_embed_ids_full,
        old_embed_ids_nover=old_embed_ids_nover
    )

    print("=" * 60)
    print("Step 5. 写出最终 BGC + nonBGC 数据")
    print("=" * 60)

    write_final_outputs(
        bgc_protein_records=bgc_protein_records,
        bgc_dna_records=bgc_dna_records,
        bgc_table=bgc_table,
        nonbgc_protein_records=nonbgc_protein_records,
        nonbgc_dna_records=nonbgc_dna_records,
        nonbgc_table=nonbgc_table
    )

    print("=" * 60)
    print("完成")
    print("=" * 60)

    print("最终 protein FASTA:", FINAL_PROTEIN_FASTA)
    print("最终 DNA FASTA:", FINAL_DNA_FASTA)
    print("最终 ID 表:", FINAL_ID_TABLE)


if __name__ == "__main__":
    main()