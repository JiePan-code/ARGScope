"""Verified, standalone replacements for Figure 2B and Figure 3B.

Run with D:/Anaconda/envs/dnabert2_5060/python.exe.
No prediction files, existing figures, or manuscript documents are changed.
"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
from matplotlib.text import Text
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support


HERE = Path(__file__).resolve().parent
RESULTS = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW")
SUPPLEMENT = HERE / "outputs" / "argscope_subtype_argonly_20260922" / "Supplementary_materials_ARGonly_subtype_20260922.docx"
OUT = HERE / "outputs" / "argscope_subtype_argonly_20260922" / "figures"
DELIVERIES = [
    Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\ARG_100pct_subtype_ARGonly_20260922"),
    RESULTS / "Subtype_ARGonly_20260922" / "figures",
]
COLORS = {"Protein": "#8FC4BC", "DNA": "#BDD8EB"}
HATCHES = {"Protein": "--", "DNA": "//"}
NAMES = {"Protein": "ARGScope-AA", "DNA": "ARGScope-NT"}
FIELDS = ["Accuracy", "Precision", "Recall", "F1", "MCC"]
XLABELS = ["ACC", "Macro\nprecision", "Macro\nrecall", "Macro F1", "MCC"]
EDGE = "#6B858A"
AUDITS = []


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def supplement_row(modality):
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with zipfile.ZipFile(SUPPLEMENT) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    tables = root.findall("./w:body/w:tbl", ns)
    index = 2 if modality == "Protein" else 5
    rows = []
    for row in tables[index].findall("./w:tr", ns):
        cells = ["".join(t.text or "" for t in cell.findall(".//w:t", ns)).strip()
                 for cell in row.findall("./w:tc", ns)]
        if len(cells) >= 8 and cells[0] == "100%" and cells[2] == "macro":
            rows.append([float(cells[j]) for j in range(3, 8)])
    assert len(rows) == 1, (modality, rows)
    return rows[0]


def reviewed_rows():
    columns = ["Modality", "Model", "Completeness", "Level", "Scope", "Average", "N",
               "N_labels_averaged", "Source"] + FIELDS
    cache = pd.read_csv(RESULTS / "calculation_cache" / "all_metrics.csv", usecols=columns)
    rows = cache[(cache.Model == "ARGScope") & (cache.Completeness == 100)
                 & (cache.Level == "Subtype") & (cache.Scope == "ARG_only")
                 & (cache.Average == "macro")].copy()
    assert len(rows) == 2 and set(rows.Modality) == {"Protein", "DNA"}
    manifest = pd.read_csv(RESULTS / "input_file_manifest.csv")
    cohort = {}
    for _, row in rows.iterrows():
        path = Path(row.Source)
        declared = manifest[manifest.Path == str(path)]
        assert len(declared) == 1
        actual_hash = digest(path)
        assert actual_hash == declared.iloc[0].SHA256, f"Source changed: {path}"
        df = pd.read_csv(path, keep_default_na=False)
        assert df.split.eq("test").all()
        assert df.completeness_percent.eq(100).all()
        assert df.sequence_level.eq("full_length").all()
        assert df.sequence_id.is_unique
        df = df.loc[df.true_subtype.ne("nonARG")].copy()
        assert len(df) == int(row.N)
        assert df.true_subtype.ne("").all() and df.predicted_subtype.ne("").all()
        y, p = df.true_subtype.astype(str), df.predicted_subtype.astype(str)
        assert "nonARG" not in set(y), "Exclude reference negatives, retain missed ARGs"
        labels = np.union1d(y, p)
        labels = labels[labels != "nonARG"]
        assert len(labels) == int(row.N_labels_averaged)
        precision, recall, f1, _ = precision_recall_fscore_support(
            y, p, labels=labels, average="macro", zero_division=0)
        values = np.array([accuracy_score(y, p), precision, recall, f1, matthews_corrcoef(y, p)])
        np.testing.assert_allclose(values, row[FIELDS].to_numpy(dtype=float), atol=1e-12, rtol=0)
        np.testing.assert_allclose(np.round(values, 4), supplement_row(row.Modality), atol=1e-12, rtol=0)
        assert ((values >= 0) & (values <= 1)).all()
        cohort[row.Modality] = df.set_index("sequence_id").true_subtype.sort_index()
        AUDITS.append({"modality": row.Modality, "source": str(path), "sha256": actual_hash,
                       "n_sequences": len(df), "n_labels": len(labels),
                       "values": dict(zip(FIELDS, values.tolist())),
                       "cache_matches_raw_recomputation": True,
                       "supplementary_table": 3 if row.Modality == "Protein" else 6,
                       "supplementary_values_match_four_decimals": True,
                       "scope": "Reference ARG sequences at 100% only. Missed ARGs and zero-scoring subtypes retained. NonARG excluded from averaged labels."})
    pd.testing.assert_series_equal(cohort["Protein"], cohort["DNA"])
    return rows


def make_chart(row):
    values = row[FIELDS].to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(4.6, 3.8))
    fig.patch.set_alpha(0)
    ax.set_facecolor("none")
    fig.subplots_adjust(left=.145, right=.980, bottom=.190, top=.900)
    x = np.arange(5)
    bars = ax.bar(x, values, width=.44, color=COLORS[row.Modality], edgecolor=EDGE,
                  linewidth=.65, hatch=HATCHES[row.Modality], zorder=3)
    ax.set_xlim(-.58, 4.58)
    ax.set_ylim(0, 1.055)
    ax.set_xticks(x, XLABELS, fontsize=11)
    ax.set_yticks(np.linspace(0, 1, 6), [f"{v:.1f}" for v in np.linspace(0, 1, 6)])
    ax.set_ylabel("Score", fontsize=12, labelpad=6)
    ax.tick_params(axis="x", length=0, pad=7)
    ax.tick_params(axis="y", length=3.2, width=.7, labelsize=10.5)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#E9EDF0", linewidth=.65)
    ax.spines[["top", "right"]].set_visible(False)
    for side in ["left", "bottom"]:
        ax.spines[side].set_linewidth(.75)
        ax.spines[side].set_color("#626B70")
    value_texts = []
    for patch, value in zip(bars, values):
        assert abs(patch.get_height() - value) < 1e-12
        value_texts.append(ax.text(patch.get_x() + patch.get_width() / 2, value + .018,
                                  f"{value:.4f}", ha="center", va="bottom", fontsize=10,
                                  color="#30383D"))
    ax.legend(handles=[Patch(facecolor=COLORS[row.Modality], edgecolor=EDGE, linewidth=.65,
                             hatch=HATCHES[row.Modality], label=NAMES[row.Modality])],
              loc="lower center", bbox_to_anchor=(.5, 1.005), frameon=False,
              fontsize=11.5, handlelength=1.7, handletextpad=.6, borderaxespad=0)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    text_bounds = []
    for artist in fig.findobj(match=Text):
        if not artist.get_visible() or not artist.get_text():
            continue
        assert artist.get_fontfamily() == ["Arial"]
        box = artist.get_window_extent(renderer)
        assert box.x0 >= -1 and box.y0 >= -1
        assert box.x1 <= fig.bbox.width + 1 and box.y1 <= fig.bbox.height + 1
        text_bounds.append({"text": artist.get_text(), "bounds": list(box.bounds)})
    for i, text in enumerate(value_texts):
        for other in value_texts[i + 1:]:
            assert not text.get_window_extent(renderer).overlaps(other.get_window_extent(renderer))
    stem = "Figure2B_Protein_100pct_Subtype_ARGonly_macro" if row.Modality == "Protein" else "Figure3B_DNA_100pct_Subtype_ARGonly_macro"
    for extension in ["svg", "png", "pdf"]:
        fig.savefig(OUT / f"{stem}.{extension}", dpi=600, facecolor="none", edgecolor="none",
                    transparent=True, bbox_inches="tight", pad_inches=0)
    svg = ET.parse(OUT / f"{stem}.svg").getroot()
    assert not svg.findall(".//{http://www.w3.org/2000/svg}image"), "Must be a true vector export"
    svg_texts = svg.findall(".//{http://www.w3.org/2000/svg}text")
    assert len(svg_texts) > 10 and all("Arial" in t.attrib.get("style", "") for t in svg_texts)
    for value in values:
        assert any(t.text == f"{value:.4f}" for t in svg_texts)
    AUDITS.append({"file_stem": stem, "formats": ["svg", "png", "pdf"],
                   "figure_inches": [4.6, 3.8], "font": "Arial", "editable_svg_text": True,
                   "svg_contains_no_raster_image": True, "bars_match_source": True,
                   "text_within_canvas": True, "transparent_background": True, "outer_padding_inches": 0,
                   "bar_width": .44, "hatch": HATCHES[row.Modality],
                   "color": COLORS[row.Modality], "text_bounds": text_bounds})
    plt.close(fig)
    return stem


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    font_path = font_manager.findfont("Arial", fallback_to_default=False)
    plt.rcParams.update({"font.family": "Arial", "font.size": 11,
                         "text.color": "#30383D", "axes.labelcolor": "#30383D",
                         "xtick.color": "#30383D", "ytick.color": "#30383D",
                         "hatch.linewidth": .40, "svg.fonttype": "none", "pdf.fonttype": 42,
                         "savefig.bbox": None})
    rows = reviewed_rows()
    stems = [make_chart(rows[rows.Modality == modality].iloc[0]) for modality in ["Protein", "DNA"]]
    support = OUT / "plot_data"
    support.mkdir(exist_ok=True)
    rows.to_csv(support / "subtype_macro_five_metrics.csv", index=False)
    (support / "verification.json").write_text(json.dumps({"font_path": font_path,
        "shared_test_ids_and_truth": True, "supplement_sha256": digest(SUPPLEMENT),
        "checks": AUDITS}, ensure_ascii=False, indent=2), encoding="utf-8")
    shutil.copy2(__file__, support / Path(__file__).name)
    shutil.copy2(HERE / "argscope_subtype_replacement_README.md", OUT / "README.md")
    with zipfile.ZipFile(OUT / "ARGScope_Protein_DNA_100pct_Subtype_bars.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for stem in stems:
            for extension in ["svg", "png", "pdf"]:
                path = OUT / f"{stem}.{extension}"
                archive.write(path, path.name)
    for destination in DELIVERIES:
        shutil.copytree(OUT, destination, dirs_exist_ok=True)
        for stem in stems:
            for extension in ["svg", "png", "pdf"]:
                name = f"{stem}.{extension}"
                assert digest(OUT / name) == digest(destination / name)
    print(rows[["Modality", "Average"] + FIELDS].to_string(index=False))
    print("OUTPUT", OUT)
    for destination in DELIVERIES:
        print("DELIVERY", destination)


if __name__ == "__main__":
    main()
