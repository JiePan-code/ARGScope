import pandas as pd


# ==========================================================
# 1. 输入输出文件
# ==========================================================

INPUT_FILE = "merged_annotation.csv"

OUTPUT_CLEAN_FILE = "BGC_ID表_clean_unique_subtype_type.csv"
OUTPUT_REMOVED_FILE = "BGC_ID表_removed_conflict_rows.csv"
OUTPUT_MAPPING_FILE = "BGC_subtype_to_type_final_mapping.csv"
OUTPUT_CONFLICT_SUMMARY = "BGC_subtype_type_conflict_summary.csv"


# ==========================================================
# 2. 列名设置
# ==========================================================

ID_COL = "ID"
TYPE_COL = "type"
SUBTYPE_COL = "subtype"


# ==========================================================
# 3. 读取数据
# ==========================================================

df = pd.read_csv(INPUT_FILE)

required_cols = [ID_COL, TYPE_COL, SUBTYPE_COL]
for col in required_cols:
    if col not in df.columns:
        raise ValueError("输入文件缺少列: {}".format(col))

df[ID_COL] = df[ID_COL].astype(str).str.strip()
df[TYPE_COL] = df[TYPE_COL].astype(str).str.strip()
df[SUBTYPE_COL] = df[SUBTYPE_COL].astype(str).str.strip()

print("原始样本数:", len(df))
print("原始 Type 数:", df[TYPE_COL].nunique())
print("原始 Subtype 数:", df[SUBTYPE_COL].nunique())


# ==========================================================
# 4. 统计每个 Subtype 对应的 Type 数量
# ==========================================================

type_count_per_subtype = (
    df.groupby(SUBTYPE_COL)[TYPE_COL]
    .nunique()
    .reset_index(name="type_count")
)

conflict_subtypes = type_count_per_subtype[
    type_count_per_subtype["type_count"] > 1
][SUBTYPE_COL].tolist()

print("存在多个 Type 的 Subtype 数:", len(conflict_subtypes))


# ==========================================================
# 5. 生成冲突汇总表
# ==========================================================

conflict_summary = (
    df[df[SUBTYPE_COL].isin(conflict_subtypes)]
    .groupby([SUBTYPE_COL, TYPE_COL])
    .size()
    .reset_index(name="sample_count")
    .sort_values(
        by=[SUBTYPE_COL, "sample_count", TYPE_COL],
        ascending=[True, False, True]
    )
)

conflict_summary.to_csv(
    OUTPUT_CONFLICT_SUMMARY,
    index=False,
    encoding="utf-8-sig"
)

print("冲突汇总已保存:", OUTPUT_CONFLICT_SUMMARY)


# ==========================================================
# 6. 为每个 Subtype 选择唯一 Type
#    规则：保留样本数最多的 Type
#    如果样本数相同，按 Type 字母顺序保留第一个，保证结果可复现
# ==========================================================

subtype_type_count = (
    df.groupby([SUBTYPE_COL, TYPE_COL])
    .size()
    .reset_index(name="sample_count")
)

subtype_type_count = subtype_type_count.sort_values(
    by=[SUBTYPE_COL, "sample_count", TYPE_COL],
    ascending=[True, False, True]
)

best_mapping = subtype_type_count.drop_duplicates(
    subset=[SUBTYPE_COL],
    keep="first"
).copy()

best_mapping = best_mapping.rename(
    columns={
        TYPE_COL: "Selected_Type",
        "sample_count": "Selected_Type_Sample_Count"
    }
)

best_mapping.to_csv(
    OUTPUT_MAPPING_FILE,
    index=False,
    encoding="utf-8-sig"
)

print("最终 Subtype-Type 映射表已保存:", OUTPUT_MAPPING_FILE)


# ==========================================================
# 7. 合并最终映射，标记保留 / 删除
# ==========================================================

df2 = df.merge(
    best_mapping[[SUBTYPE_COL, "Selected_Type", "Selected_Type_Sample_Count"]],
    on=SUBTYPE_COL,
    how="left"
)

df2["Keep"] = df2[TYPE_COL] == df2["Selected_Type"]

clean_df = df2[df2["Keep"]].copy()
removed_df = df2[~df2["Keep"]].copy()


# ==========================================================
# 8. 输出清洗后的 label 文件和被删除的数据
# ==========================================================

clean_df = clean_df[[ID_COL, TYPE_COL, SUBTYPE_COL]].copy()
removed_df = removed_df[
    [
        ID_COL,
        TYPE_COL,
        SUBTYPE_COL,
        "Selected_Type",
        "Selected_Type_Sample_Count"
    ]
].copy()

clean_df.to_csv(
    OUTPUT_CLEAN_FILE,
    index=False,
    encoding="utf-8-sig"
)

removed_df.to_csv(
    OUTPUT_REMOVED_FILE,
    index=False,
    encoding="utf-8-sig"
)

print("清洗后文件已保存:", OUTPUT_CLEAN_FILE)
print("被删除冲突数据已保存:", OUTPUT_REMOVED_FILE)


# ==========================================================
# 9. 清洗后检查
# ==========================================================

check = (
    clean_df.groupby(SUBTYPE_COL)[TYPE_COL]
    .nunique()
    .reset_index(name="type_count")
)

remain_conflict = check[check["type_count"] > 1]

print("-" * 60)
print("清洗后样本数:", len(clean_df))
print("删除样本数:", len(removed_df))
print("清洗后 Type 数:", clean_df[TYPE_COL].nunique())
print("清洗后 Subtype 数:", clean_df[SUBTYPE_COL].nunique())
print("清洗后仍存在多个 Type 的 Subtype 数:", len(remain_conflict))

if len(remain_conflict) > 0:
    print("仍存在冲突的 Subtype:")
    print(remain_conflict)
else:
    print("检查通过：每个 Subtype 已唯一对应一个 Type。")


# ==========================================================
# 10. 打印被修正的冲突 Subtype
# ==========================================================

print("-" * 60)
print("冲突 Subtype 的最终保留 Type:")

conflict_best = best_mapping[
    best_mapping[SUBTYPE_COL].isin(conflict_subtypes)
].copy()

conflict_best = conflict_best.sort_values(SUBTYPE_COL)

for _, row in conflict_best.iterrows():
    subtype = row[SUBTYPE_COL]
    selected_type = row["Selected_Type"]
    selected_count = row["Selected_Type_Sample_Count"]

    print("{} -> {}，保留样本数: {}".format(
        subtype,
        selected_type,
        selected_count
    ))