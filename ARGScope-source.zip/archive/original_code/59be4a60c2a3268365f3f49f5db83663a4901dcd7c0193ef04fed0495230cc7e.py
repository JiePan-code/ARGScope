import pandas as pd
import numpy as np

# =========================
# 1. 读取数据
# =========================
input_file = "1.90p_all_fusion_embedding_512_with_label.csv"
df = pd.read_csv(input_file)

# 去掉列名前后空格，并统一转成小写
df.columns = df.columns.str.strip().str.lower()

print("总样本数:", len(df))
print("当前列名示例:", df.columns[:10].tolist())

# 检查必要列
required_cols = ["subtype", "type"]
missing_cols = [c for c in required_cols if c not in df.columns]
if missing_cols:
    raise ValueError(f"源文件缺少必要列: {missing_cols}，请检查 CSV 表头。当前列名为: {df.columns.tolist()}")

print("Subtype 总数(原始):", df["subtype"].astype(str).nunique())

# =========================
# 2. 选择特征列（512 维融合特征）
# =========================
exclude_cols = ["id", "geneid", "type", "subtype"]
feature_cols = [c for c in df.columns if c not in exclude_cols]

print("特征维度(原始列数):", len(feature_cols))

# 保证特征列是数值
df[feature_cols] = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

# 可选：把特征列统一改名为 g0..g511
if len(feature_cols) == 512:
    new_feature_cols = [f"g{i}" for i in range(512)]
    rename_map = {old: new for old, new in zip(feature_cols, new_feature_cols)}
    df = df.rename(columns=rename_map)
    feature_cols = new_feature_cols
    print("已将特征列重命名为 g0..g511")
else:
    print("警告：特征列不是 512 维，请检查 feature_cols 选择逻辑。")
    print("当前识别到的特征列前20个:", feature_cols[:20])

# =========================
# 3. 不过滤 subtype（全保留）
# =========================
min_count = 1
sub_counts = df["subtype"].astype(str).value_counts()
valid_subtypes = sub_counts[sub_counts >= min_count].index

df_sub = df[df["subtype"].astype(str).isin(valid_subtypes)].copy()

print("过滤后 Subtype 数:", df_sub["subtype"].astype(str).nunique())
print("过滤后样本数:", len(df_sub))

# =========================
# 4. 按 subtype 计算 prototype（特征均值）和 count
# =========================
df_sub["subtype"] = df_sub["subtype"].astype(str)
df_sub["type"] = df_sub["type"].astype(str)

grouped = df_sub.groupby("subtype", sort=False)

proto_matrix = grouped[feature_cols].mean()
counts = grouped.size()
types = grouped["type"].agg(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else x.iloc[0])

# =========================
# 5. 整合成一个 DataFrame
# =========================
proto_df = proto_matrix.copy()
proto_df.insert(0, "Type", types)
proto_df.insert(1, "Count", counts)

proto_df = proto_df.reset_index()
proto_df = proto_df.rename(columns={"subtype": "Subtype"})

print("\n示例前几行:")
print(proto_df.head())

print("\nSubtype 原型数量:", len(proto_df))
print("Count=1 的 subtype 数量:", int((proto_df["Count"] == 1).sum()))

# =========================
# 6. 保存为 CSV
# =========================
output_file = "4.subtype_prototypes_512.csv"
proto_df.to_csv(output_file, index=False, encoding="utf-8-sig")

print(f"\n已保存 subtype prototype 到: {output_file}")