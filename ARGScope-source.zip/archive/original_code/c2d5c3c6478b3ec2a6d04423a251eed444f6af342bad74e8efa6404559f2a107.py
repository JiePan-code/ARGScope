#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent post-run checks; recompute all published metrics with scikit-learn."""
import csv
import hashlib
import json
import math
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

import sklearn
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support


ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent.parent
METRICS = ("Accuracy", "Precision", "Recall", "F1", "MCC")


def read(path, delimiter=","):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def metric_check(row, truth, predicted, average):
    precision, recall, f1, _ = precision_recall_fscore_support(
        truth, predicted, average=average, zero_division=0)
    values = [accuracy_score(truth, predicted), precision, recall, f1,
              matthews_corrcoef(truth, predicted)]
    differences = [abs(float(row[key]) - float(value)) for key, value in zip(METRICS, values)]
    require(max(differences) <= 1e-12, f"Metric mismatch: {row}; expected={values}")
    if average == "binary":
        counts = Counter(zip(truth, predicted))
        for key, value in (("TP", counts[1, 1]), ("FP", counts[0, 1]),
                           ("FN", counts[1, 0]), ("TN", counts[0, 0])):
            require(int(row[key]) == value, f"Confusion count mismatch: {key}")
    return max(differences)


def main():
    receipt = json.loads((ROOT / "COMPLETE.json").read_text(encoding="utf-8"))
    require(receipt["status"] == "complete", "Incomplete application")
    for relative, expected_hash in receipt["CSV_files"].items():
        require(digest(ROOT / relative) == expected_hash, f"Changed CSV: {relative}")
    for source in receipt["sources"]:
        require(digest(Path(source["path"])) == source["sha256"], "Changed original input or checkpoint")
    for name, expected_hash in receipt["code_sha256"].items():
        require(digest(ROOT / name) == expected_hash, f"Application code changed: {name}")
    original_rows = read(DATA / "all_ARG_nonARG_1to1_structure.txt", "\t")
    original = {row["SARG.Seq.ID"]: row for row in original_rows}
    require(len(original) == len(original_rows) == 26878, "Original population mismatch")
    subtype_counts = Counter(row["Subtype"] for row in original_rows if row["ARG.or.nonARG"] == "ARG")
    singleton = {sid for sid, row in original.items()
                 if row["ARG.or.nonARG"] == "ARG" and subtype_counts[row["Subtype"]] == 1}
    require(len(singleton) == 2004, "Original singleton count mismatch")
    manifest = read(DATA / "ARGScope_80_20_results/full/protein/split_manifest.csv")
    groups = {split: {row["sequence_id"] for row in manifest if row["model_split"] == split}
              for split in ("train", "validation", "test")}
    require(not groups["train"] & groups["validation"] and not groups["test"] & (groups["train"] | groups["validation"]),
            "Saved split overlap")
    require(len(groups["test"]) == 4574 and not groups["test"] & singleton, "Wrong evaluation parents")
    tables = {name: read(ROOT / "metrics" / name) for name in (
        "01_ARG_nonARG_ARG_positive_five_metrics.csv", "02_Type_overall_macro_weighted_micro.csv",
        "03_Subtype_overall_macro_weighted_micro.csv", "04_Per_type_five_metrics.csv",
        "05_ARG_nonARG_macro_weighted_micro_optional.csv", "06_ARG_nonARG_each_class_five_metrics.csv")}
    # Independently obtain the repaired IDs from DNA's explicit original_ids and header part fields.
    import torch
    repaired = torch.load(DATA / "DNABERT2_embedding/percent_90/percent_90_chunk_000001_dnabert2_OFFICIAL_MEAN.pt",
                          map_location="cpu", weights_only=True, mmap=True)
    repair_lookup = {}
    for sid, parent, header in zip(repaired["ids"], repaired["original_ids"], repaired["headers"]):
        if "__SIM_" in sid:
            tokens = dict(token.split("=", 1) for token in header.split()[1:] if "=" in token)
            require(tokens["original_id"] == parent, "Repaired header parent mismatch")
            repair_lookup[sid] = (parent, int(tokens["part"]))
    require(len(repair_lookup) == 165, "Repair metadata coverage mismatch")
    del repaired
    summaries, checked_rows, max_error = [], 0, 0.0
    paired = {}
    for modality in ("protein", "dna"):
        display = "Protein" if modality == "protein" else "DNA"
        for pct in (60, 70, 80, 90, 100):
            file = ROOT / modality / ("100%_test_sequence_predictions.csv" if pct == 100
                                      else f"{pct}%_fragment_predictions_test.csv")
            rows = read(file)
            require(len(rows) == (4574 if pct == 100 else 22870), "Prediction count mismatch")
            require(len({r["sequence_id"] for r in rows}) == len(rows), "Duplicate prediction IDs")
            by_parent = Counter(r["parent_sequence_id"] for r in rows)
            require(set(by_parent) == groups["test"], "Evaluation includes or omits parents")
            require(set(by_parent.values()) == {1 if pct == 100 else 5}, "Wrong number of copies per parent")
            seen_pairs = set()
            for row in rows:
                sid, parent, part = row["sequence_id"], row["parent_sequence_id"], int(row["replicate"])
                require(row["split"] == "test" and int(row["completeness_percent"]) == pct, "Wrong output condition")
                require(parent not in singleton and parent not in groups["train"] | groups["validation"], "Ineligible parent")
                require((parent, part) not in seen_pairs, "Duplicate parent/replicate")
                seen_pairs.add((parent, part))
                if pct == 100:
                    require(sid == parent and part == 0, "Wrong full-length identity")
                elif "__SIM_" in sid:
                    require(pct == 90 and repair_lookup.get(sid) == (parent, part), "Repair ID mapping mismatch")
                else:
                    require(sid == f"{parent}_{part}" and part in range(1, 6), "Fragment identity mismatch")
                truth = original[parent]
                require(row["true_subtype"] == truth["Subtype"] and row["true_type"] == truth["Type"] and
                        int(row["true_ARG"]) == int(truth["ARG.or.nonARG"] == "ARG"), "Wrong ground truth")
                probability = float(row["ARG_probability"])
                require(math.isfinite(probability) and 0 <= probability <= 1 and float(row["binary_threshold"]) == .8,
                        "Invalid probability or changed threshold")
                require(int(row["predicted_ARG"]) == int(probability >= .8), "Binary gate mismatch")
                require(row["predicted_subtype"] == (row["ARG_subtype_before_binary_gate"]
                        if probability >= .8 else "nonARG"), "Subtype gate mismatch")
            paired[modality, pct] = {(r["sequence_id"], r["parent_sequence_id"], r["true_type"], r["true_subtype"]) for r in rows}
            by_condition = lambda table: [r for r in tables[table] if r["Modality"] == display and int(r["Completeness_percent"]) == pct]
            yb, pb = [int(r["true_ARG"]) for r in rows], [int(r["predicted_ARG"]) for r in rows]
            for name, selected in tables.items():
                for report in by_condition(name):
                    if name.startswith("01_"):
                        yt, yp, average = yb, pb, "binary"
                    elif name.startswith(("02_", "03_")):
                        level = "type" if name.startswith("02_") else "subtype"
                        yt, yp = [r[f"true_{level}"] for r in rows], [r[f"predicted_{level}"] for r in rows]
                        average = report["Average"]
                    elif name.startswith("04_"):
                        yt = [int(r["true_type"] == report["Type"]) for r in rows]
                        yp = [int(r["predicted_type"] == report["Type"]) for r in rows]
                        average = "binary"
                    elif name.startswith("05_"):
                        yt, yp, average = yb, pb, report["Average"]
                    else:
                        label = int(report["Positive_class"] == "ARG")
                        yt, yp, average = [int(y == label) for y in yb], [int(y == label) for y in pb], "binary"
                    max_error = max(max_error, metric_check(report, yt, yp, average))
                    checked_rows += 1
            summaries.append({"modality": modality, "completeness_percent": pct, "sequences": len(rows),
                              "parents": len(by_parent), "ARG_sequences": sum(yb), "nonARG_sequences": len(yb) - sum(yb),
                              "ARG_subtypes": len({r["true_subtype"] for r in rows} - {"nonARG"}),
                              "train_validation_parent_overlap": 0, "singleton_parent_overlap": 0})
            print(f"VERIFIED {modality} {pct}%: {len(rows)} rows", flush=True)
    for pct in (60, 70, 80, 90, 100):
        require(paired["protein", pct] == paired["dna", pct], "Cross-modality IDs or truth disagree")
    for file in (ROOT / "audit").glob("*_inputs.json"):
        record = json.loads(file.read_text(encoding="utf-8"))
        for source in record["sources"]:
            require(digest(Path(source["path"])) == source["sha256"], "Embedding changed since prediction")
    report = {"status": "PASS", "created_at": datetime.now().astimezone().isoformat(),
              "sklearn_version": sklearn.__version__, "metric_rows_checked": checked_rows,
              "maximum_metric_absolute_error": max_error, "metric_tolerance": 1e-12,
              "train_validation_parent_overlap": 0, "singleton_parent_overlap": 0,
              "two_modalities_have_identical_IDs_and_truth": True, "conditions": summaries}
    with (ROOT / "INDEPENDENT_VALIDATION.json").open("x", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
