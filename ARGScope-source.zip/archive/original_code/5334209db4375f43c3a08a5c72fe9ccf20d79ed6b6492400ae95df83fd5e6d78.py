#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Filter strict BLASTN results to the CURRENT ARGScope subtype label space.

Designed for this directory layout:

BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt/
├── argbert_1/
│   ├── argbert_1_strict_all_hits.tsv
│   ├── argbert_1_strict_besthit.tsv
│   └── argbert_1_strict_subject_counts.csv
├── argbert_2/
├── argbert_3/
├── argscope_1/
├── argscope_2/
├── argscope_3/
├── argscope_4/
├── argscope_5/
├── argscope_6/
├── 3.SARG_v3.2_20220917_Long_subdatabase_structure.txt
├── Nucleotide_SARG_v3.2_Long_structure.txt
└── structure_50aa_150nt_5parts.txt

Core logic
----------
1. Read Nucleotide_SARG_v3.2_Long_structure.txt.
   Map BLAST subject ID (sseqid) -> original Type/Subtype.

2. Read structure_50aa_150nt_5parts.txt.
   Its ARG Subtype set defines the CURRENT ARGScope label space.
   nonARG is excluded.

3. For every dataset:
      *_strict_all_hits.tsv
          ↓
      map sseqid -> Type/Subtype
          ↓
      keep only hits whose Subtype exists in current ARGScope
          ↓
      RESELECT the best hit per qseqid
          ↓
      final current-label-space BLAST ground truth

Why reselect from all hits?
---------------------------
Suppose a read has:
    best old hit  -> subtype that was later removed
    second hit    -> subtype still present in current ARGScope

Filtering only the old *_strict_besthit.tsv would incorrectly discard
that read. Filtering *_strict_all_hits.tsv first and THEN selecting the
best remaining hit reproduces the result expected from a reduced label space.

Main final output
-----------------
BLASTN_current_ARGScope_labelspace/
├── BLASTN_current_scope_dataset_summary.csv       <-- MAIN count summary
├── BLASTN_current_scope_subtype_count_matrix.csv
├── BLASTN_current_scope_type_count_matrix.csv
├── BLASTN_current_scope_removed_subtype_summary.csv
├── BLASTN_current_scope_mapping_audit.csv
│
├── argbert_1/
│   ├── argbert_1_current_scope_besthit.tsv        <-- FINAL per-read BLAST truth
│   ├── argbert_1_current_scope_all_hits.tsv
│   ├── argbert_1_current_scope_subtype_counts.csv
│   ├── argbert_1_current_scope_type_counts.csv
│   ├── argbert_1_out_of_scope_hits.tsv
│   ├── argbert_1_unmapped_hits.tsv
│   └── argbert_1_current_scope_summary.json
└── ...

The count used for comparison with ARGScope is:
    current_scope_BLAST_ARG_count

This equals the number of rows / unique qseqid in:
    <dataset>_current_scope_besthit.tsv

This task is I/O/dataframe filtering and grouping; GPU acceleration is not
appropriate and would add unnecessary dependencies.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import pandas as pd


SCRIPT_VERSION = "2026-08-18-BLASTN-current-ARGScope-labelspace-v1"

DATASETS = [
    "argbert_1",
    "argbert_2",
    "argbert_3",
    "argscope_1",
    "argscope_2",
    "argscope_3",
    "argscope_4",
    "argscope_5",
    "argscope_6",
]

SCRIPT_DIR = Path(__file__).resolve().parent

DEFAULT_ROOT = SCRIPT_DIR

DEFAULT_NUCLEOTIDE_STRUCTURE = (
    DEFAULT_ROOT
    / "Nucleotide_SARG_v3.2_Long_structure.txt"
)

DEFAULT_CURRENT_STRUCTURE = (
    DEFAULT_ROOT
    / "structure_50aa_150nt_5parts.txt"
)

DEFAULT_OUTPUT_ROOT = (
    DEFAULT_ROOT
    / "BLASTN_current_ARGScope_labelspace"
)

NONARG_CANONICAL = "nonARG"


# Standard 14-column format used by the strict BLASTN pipeline.
DEFAULT_BLAST_COLUMNS_14 = [
    "qseqid",
    "sseqid",
    "pident",
    "length",
    "mismatch",
    "gapopen",
    "qstart",
    "qend",
    "sstart",
    "send",
    "evalue",
    "bitscore",
    "qlen",
    "qcov",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Filter all 9 strict BLASTN datasets to the current "
            "ARGScope subtype label space and reselect best hits."
        )
    )

    parser.add_argument(
        "--root",
        type=Path,
        default=DEFAULT_ROOT,
        help=(
            "BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt root. "
            "Default: script directory."
        ),
    )

    parser.add_argument(
        "--nucleotide-structure",
        type=Path,
        default=None,
        help=(
            "Nucleotide_SARG_v3.2_Long_structure.txt. "
            "Default: <root>/Nucleotide_SARG_v3.2_Long_structure.txt"
        ),
    )

    parser.add_argument(
        "--current-structure",
        type=Path,
        default=None,
        help=(
            "Current structure_50aa_150nt_5parts.txt. "
            "Default: <root>/structure_50aa_150nt_5parts.txt"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=None,
        help=(
            "Output directory. "
            "Default: <root>/BLASTN_current_ARGScope_labelspace"
        ),
    )

    parser.add_argument(
        "--datasets",
        nargs="+",
        default=DATASETS,
        help="Datasets to process.",
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow overwriting output files.",
    )

    return parser.parse_args()


def normalize_label(value: Any) -> str:
    text = str(value).strip()

    if not text or text.lower() == "nan":
        return ""

    if text.lower() == "nonarg":
        return NONARG_CANONICAL

    return text


def normalize_subject_id(value: Any) -> str:
    """
    Normalize BLAST subject IDs and SARG NucleotideID.

    Examples:
        lcl|NZ_NIER01000015.1_cds_WP_000074171.1_22
        -> NZ_NIER01000015.1_cds_WP_000074171.1_22

        NZ_NIER01000015.1_cds_WP_000074171.1_22
        -> unchanged
    """
    text = str(value).strip()

    if not text or text.lower() == "nan":
        return ""

    # BLAST database headers can carry an lcl| prefix.
    while text.startswith("lcl|"):
        text = text[4:]

    # Defensive normalization if a pipe-surrounded identifier is present.
    text = text.strip()

    return text


def read_tabular_auto(
    path: Path,
    expected_first_columns: tuple[str, ...] = (),
) -> pd.DataFrame:
    """
    Read TSV with automatic header detection.

    For BLAST files:
      - if qseqid/sseqid header exists, use it
      - otherwise assign standard 14 BLAST columns
    """
    if not path.is_file():
        raise FileNotFoundError(
            f"File not found: {path}"
        )

    # Read first non-empty line.
    first_line = ""

    with path.open(
        "r",
        encoding="utf-8-sig",
        errors="replace",
    ) as handle:
        for line in handle:
            if line.strip():
                first_line = line.rstrip("\r\n")
                break

    if not first_line:
        return pd.DataFrame()

    tokens = first_line.split("\t")
    lowered = {
        token.strip().lower()
        for token
        in tokens
    }

    has_header = False

    if expected_first_columns:
        has_header = all(
            column.lower() in lowered
            for column
            in expected_first_columns
        )
    elif (
        "qseqid" in lowered
        and "sseqid" in lowered
    ):
        has_header = True

    if has_header:
        return pd.read_csv(
            path,
            sep="\t",
            dtype=str,
            low_memory=False,
        )

    # Headerless BLAST table.
    if len(tokens) == 14:
        return pd.read_csv(
            path,
            sep="\t",
            names=DEFAULT_BLAST_COLUMNS_14,
            header=None,
            dtype=str,
            low_memory=False,
        )

    # Fallback for arbitrary structure tables should normally not be used.
    return pd.read_csv(
        path,
        sep="\t",
        dtype=str,
        low_memory=False,
    )


def read_structure_table(
    path: Path,
) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(
            f"Structure file not found: {path}"
        )

    df = pd.read_csv(
        path,
        sep="\t",
        dtype=str,
        low_memory=False,
    )

    if df.empty:
        raise ValueError(
            f"Structure file is empty: {path}"
        )

    return df


def find_column_case_insensitive(
    df: pd.DataFrame,
    candidates: Iterable[str],
) -> str | None:
    lookup = {
        str(column).strip().lower():
            str(column)
        for column
        in df.columns
    }

    for candidate in candidates:
        found = lookup.get(
            candidate.lower()
        )

        if found is not None:
            return found

    return None


def build_nucleotide_mapping(
    nucleotide_structure: Path,
):
    """
    Build exact normalized NucleotideID -> (Type, Subtype).

    Ambiguous IDs mapping to >1 Type/Subtype are NOT silently accepted.
    They are excluded from the mapping and reported separately.
    """
    df = read_structure_table(
        nucleotide_structure
    )

    nucleotide_col = find_column_case_insensitive(
        df,
        [
            "NucleotideID",
            "Nucleotide.ID",
            "Nucleotide_ID",
            "sseqid",
        ],
    )

    type_col = find_column_case_insensitive(
        df,
        ["Type"],
    )

    subtype_col = find_column_case_insensitive(
        df,
        ["Subtype"],
    )

    if nucleotide_col is None:
        raise ValueError(
            "Could not find NucleotideID column in "
            f"{nucleotide_structure}. "
            f"Columns={list(df.columns)}"
        )

    if type_col is None or subtype_col is None:
        raise ValueError(
            "Could not find Type/Subtype columns in "
            f"{nucleotide_structure}"
        )

    work = pd.DataFrame(
        {
            "subject_norm":
                df[
                    nucleotide_col
                ].map(
                    normalize_subject_id
                ),

            "mapped_type":
                df[
                    type_col
                ].map(
                    normalize_label
                ),

            "mapped_subtype":
                df[
                    subtype_col
                ].map(
                    normalize_label
                ),
        }
    )

    work = work[
        (
            work[
                "subject_norm"
            ]
            != ""
        )
        & (
            work[
                "mapped_subtype"
            ]
            != ""
        )
    ].copy()

    # Unique pairs per subject.
    pair_counts = (
        work[
            [
                "subject_norm",
                "mapped_type",
                "mapped_subtype",
            ]
        ]
        .drop_duplicates()
        .groupby(
            "subject_norm",
            sort=False,
        )
        .size()
    )

    ambiguous_ids = set(
        pair_counts[
            pair_counts > 1
        ].index
    )

    mapping_df = (
        work[
            ~work[
                "subject_norm"
            ].isin(
                ambiguous_ids
            )
        ]
        [
            [
                "subject_norm",
                "mapped_type",
                "mapped_subtype",
            ]
        ]
        .drop_duplicates(
            subset=[
                "subject_norm"
            ],
            keep="first",
        )
        .copy()
    )

    mapping = {
        row.subject_norm: (
            row.mapped_type,
            row.mapped_subtype,
        )
        for row
        in mapping_df.itertuples(
            index=False
        )
    }

    return {
        "mapping": mapping,
        "mapping_df": mapping_df,
        "ambiguous_ids": ambiguous_ids,
        "raw_rows": int(
            len(df)
        ),
        "unique_normalized_ids": int(
            work[
                "subject_norm"
            ].nunique()
        ),
        "mapped_unambiguous_ids": int(
            len(mapping)
        ),
    }


def build_current_label_space(
    current_structure: Path,
):
    """
    Current ARGScope subtype universe.

    Only ARG subtypes are retained. nonARG is not part of BLAST ARG truth.
    """
    df = read_structure_table(
        current_structure
    )

    type_col = find_column_case_insensitive(
        df,
        ["Type"],
    )

    subtype_col = find_column_case_insensitive(
        df,
        ["Subtype"],
    )

    if type_col is None or subtype_col is None:
        raise ValueError(
            "Current structure must contain Type and Subtype columns: "
            f"{current_structure}"
        )

    work = pd.DataFrame(
        {
            "Type":
                df[
                    type_col
                ].map(
                    normalize_label
                ),

            "Subtype":
                df[
                    subtype_col
                ].map(
                    normalize_label
                ),
        }
    )

    work = work[
        (
            work[
                "Subtype"
            ]
            != ""
        )
        & (
            work[
                "Subtype"
            ]
            != NONARG_CANONICAL
        )
    ].drop_duplicates()

    subtype_to_types = (
        work
        .groupby(
            "Subtype"
        )[
            "Type"
        ]
        .nunique()
    )

    conflicts = subtype_to_types[
        subtype_to_types > 1
    ]

    if not conflicts.empty:
        raise ValueError(
            "Current structure has Subtype -> multiple Type conflicts. "
            f"Examples: {conflicts.head(20).to_dict()}"
        )

    subtype_to_type = (
        work
        .drop_duplicates(
            subset=[
                "Subtype"
            ]
        )
        .set_index(
            "Subtype"
        )[
            "Type"
        ]
        .to_dict()
    )

    current_subtypes = set(
        subtype_to_type
    )

    current_types = set(
        subtype_to_type.values()
    )

    return {
        "current_subtypes":
            current_subtypes,

        "current_types":
            current_types,

        "subtype_to_type":
            subtype_to_type,

        "number_current_ARG_subtypes":
            len(
                current_subtypes
            ),

        "number_current_ARG_types":
            len(
                current_types
            ),
    }


def load_blast_hits(
    path: Path,
) -> pd.DataFrame:
    df = read_tabular_auto(
        path,
        expected_first_columns=(
            "qseqid",
            "sseqid",
        ),
    )

    if df.empty:
        return df

    qseqid_col = find_column_case_insensitive(
        df,
        ["qseqid"],
    )

    sseqid_col = find_column_case_insensitive(
        df,
        ["sseqid"],
    )

    if qseqid_col is None or sseqid_col is None:
        raise ValueError(
            f"BLAST file lacks qseqid/sseqid: {path}\n"
            f"Columns={list(df.columns)}"
        )

    if qseqid_col != "qseqid":
        df = df.rename(
            columns={
                qseqid_col:
                    "qseqid",
            }
        )

    if sseqid_col != "sseqid":
        df = df.rename(
            columns={
                sseqid_col:
                    "sseqid",
            }
        )

    df[
        "qseqid"
    ] = (
        df[
            "qseqid"
        ]
        .astype(str)
        .str.strip()
    )

    df[
        "sseqid"
    ] = (
        df[
            "sseqid"
        ]
        .astype(str)
        .str.strip()
    )

    df[
        "_row_order"
    ] = range(
        len(df)
    )

    return df


def numeric_series(
    df: pd.DataFrame,
    candidates: Iterable[str],
    default: float,
) -> pd.Series:
    column = find_column_case_insensitive(
        df,
        candidates,
    )

    if column is None:
        return pd.Series(
            default,
            index=df.index,
            dtype=float,
        )

    return pd.to_numeric(
        df[
            column
        ],
        errors="coerce",
    ).fillna(
        default
    )


def select_best_hits(
    in_scope_hits: pd.DataFrame,
) -> pd.DataFrame:
    """
    Select one best remaining hit per qseqid.

    Priority:
      1. bitscore descending
      2. evalue ascending
      3. pident descending
      4. qcov descending
      5. alignment length descending
      6. original row order ascending

    Count is one row per qseqid regardless of ties.
    """
    if in_scope_hits.empty:
        return in_scope_hits.copy()

    work = in_scope_hits.copy()

    work[
        "_rank_bitscore"
    ] = numeric_series(
        work,
        [
            "bitscore",
            "bit_score",
        ],
        default=-math.inf,
    )

    work[
        "_rank_evalue"
    ] = numeric_series(
        work,
        [
            "evalue",
            "e-value",
        ],
        default=math.inf,
    )

    work[
        "_rank_pident"
    ] = numeric_series(
        work,
        [
            "pident",
            "identity",
        ],
        default=-math.inf,
    )

    work[
        "_rank_qcov"
    ] = numeric_series(
        work,
        [
            "qcov",
            "qcovs",
            "qcovhsp",
            "query_coverage",
        ],
        default=-math.inf,
    )

    work[
        "_rank_length"
    ] = numeric_series(
        work,
        [
            "length",
            "alnlen",
            "alignment_length",
        ],
        default=-math.inf,
    )

    work = work.sort_values(
        by=[
            "qseqid",
            "_rank_bitscore",
            "_rank_evalue",
            "_rank_pident",
            "_rank_qcov",
            "_rank_length",
            "_row_order",
        ],
        ascending=[
            True,
            False,
            True,
            False,
            False,
            False,
            True,
        ],
        kind="mergesort",
    )

    best = (
        work
        .drop_duplicates(
            subset=[
                "qseqid"
            ],
            keep="first",
        )
        .sort_values(
            "_row_order",
            kind="mergesort",
        )
        .copy()
    )

    rank_columns = [
        "_rank_bitscore",
        "_rank_evalue",
        "_rank_pident",
        "_rank_qcov",
        "_rank_length",
    ]

    best = best.drop(
        columns=[
            column
            for column
            in rank_columns
            if column
            in best.columns
        ]
    )

    return best


def map_hits(
    hits: pd.DataFrame,
    nucleotide_mapping: dict[str, tuple[str, str]],
    current_subtypes: set[str],
) -> pd.DataFrame:

    if hits.empty:
        return hits.copy()

    work = hits.copy()

    work[
        "subject_norm"
    ] = work[
        "sseqid"
    ].map(
        normalize_subject_id
    )

    mapped_pairs = work[
        "subject_norm"
    ].map(
        nucleotide_mapping
    )

    work[
        "mapped_type"
    ] = mapped_pairs.map(
        lambda value:
            value[0]
            if isinstance(
                value,
                tuple,
            )
            else ""
    )

    work[
        "mapped_subtype"
    ] = mapped_pairs.map(
        lambda value:
            value[1]
            if isinstance(
                value,
                tuple,
            )
            else ""
    )

    work[
        "mapping_status"
    ] = work[
        "mapped_subtype"
    ].map(
        lambda subtype:
            "mapped"
            if subtype
            else "unmapped"
    )

    work[
        "current_scope_status"
    ] = work[
        "mapped_subtype"
    ].map(
        lambda subtype:
            (
                "in_scope"
                if subtype
                in current_subtypes
                else (
                    "out_of_scope"
                    if subtype
                    else "unmapped"
                )
            )
    )

    return work


def read_old_besthit_optional(
    path: Path,
    nucleotide_mapping: dict[str, tuple[str, str]],
    current_subtypes: set[str],
):
    if not path.is_file():
        return None

    old = load_blast_hits(
        path
    )

    old = map_hits(
        old,
        nucleotide_mapping,
        current_subtypes,
    )

    return old


def safe_write_tsv(
    df: pd.DataFrame,
    path: Path,
    overwrite: bool,
) -> None:
    if (
        path.exists()
        and not overwrite
    ):
        raise FileExistsError(
            f"Output already exists: {path}\n"
            "Use --overwrite to replace it."
        )

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    df.to_csv(
        temp,
        sep="\t",
        index=False,
        encoding="utf-8",
    )

    os.replace(
        temp,
        path,
    )


def safe_write_csv(
    df: pd.DataFrame,
    path: Path,
    overwrite: bool,
) -> None:
    if (
        path.exists()
        and not overwrite
    ):
        raise FileExistsError(
            f"Output already exists: {path}\n"
            "Use --overwrite to replace it."
        )

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    df.to_csv(
        temp,
        index=False,
        encoding="utf-8-sig",
    )

    os.replace(
        temp,
        path,
    )


def safe_write_json(
    payload: dict[str, Any],
    path: Path,
    overwrite: bool,
) -> None:
    if (
        path.exists()
        and not overwrite
    ):
        raise FileExistsError(
            f"Output already exists: {path}\n"
            "Use --overwrite to replace it."
        )

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(
        temp,
        path,
    )


def count_table(
    best_hits: pd.DataFrame,
    column: str,
    output_name: str,
) -> pd.DataFrame:

    if best_hits.empty:
        return pd.DataFrame(
            columns=[
                output_name,
                "count",
            ]
        )

    result = (
        best_hits[
            column
        ]
        .value_counts(
            dropna=False
        )
        .rename_axis(
            output_name
        )
        .reset_index(
            name="count"
        )
    )

    result[
        output_name
    ] = result[
        output_name
    ].fillna(
        ""
    )

    return result


def process_dataset(
    dataset: str,
    root: Path,
    output_root: Path,
    nucleotide_mapping: dict[str, tuple[str, str]],
    current_subtypes: set[str],
    overwrite: bool,
):
    dataset_dir = (
        root
        / dataset
    )

    all_hits_path = (
        dataset_dir
        / f"{dataset}_strict_all_hits.tsv"
    )

    old_besthit_path = (
        dataset_dir
        / f"{dataset}_strict_besthit.tsv"
    )

    if not all_hits_path.is_file():
        raise FileNotFoundError(
            f"Missing strict all-hits file: {all_hits_path}"
        )

    dataset_output = (
        output_root
        / dataset
    )

    dataset_output.mkdir(
        parents=True,
        exist_ok=True,
    )

    print()
    print(
        "=" * 118,
        flush=True,
    )
    print(
        f"DATASET: {dataset}",
        flush=True,
    )
    print(
        "=" * 118,
        flush=True,
    )
    print(
        f"All hits    : {all_hits_path}",
        flush=True,
    )
    print(
        f"Old besthit : {old_besthit_path}",
        flush=True,
    )

    hits = load_blast_hits(
        all_hits_path
    )

    total_hit_rows = int(
        len(hits)
    )

    total_reads_with_strict_hit = int(
        hits[
            "qseqid"
        ].nunique()
    )

    mapped = map_hits(
        hits,
        nucleotide_mapping,
        current_subtypes,
    )

    mapped_hits = mapped[
        mapped[
            "mapping_status"
        ]
        == "mapped"
    ].copy()

    unmapped_hits = mapped[
        mapped[
            "mapping_status"
        ]
        == "unmapped"
    ].copy()

    in_scope_hits = mapped[
        mapped[
            "current_scope_status"
        ]
        == "in_scope"
    ].copy()

    out_scope_hits = mapped[
        mapped[
            "current_scope_status"
        ]
        == "out_of_scope"
    ].copy()

    best = select_best_hits(
        in_scope_hits
    )

    if best[
        "qseqid"
    ].duplicated().any():
        raise RuntimeError(
            f"{dataset}: duplicate qseqid remained after best-hit selection"
        )

    old_best = read_old_besthit_optional(
        old_besthit_path,
        nucleotide_mapping,
        current_subtypes,
    )

    if old_best is not None:
        original_besthit_rows = int(
            len(old_best)
        )

        original_besthit_unique_reads = int(
            old_best[
                "qseqid"
            ].nunique()
        )

        old_best_direct_in_scope = old_best[
            old_best[
                "current_scope_status"
            ]
            == "in_scope"
        ].copy()

        direct_filtered_old_besthit_count = int(
            old_best_direct_in_scope[
                "qseqid"
            ].nunique()
        )

        rescued_ids = (
            set(
                best[
                    "qseqid"
                ]
            )
            - set(
                old_best_direct_in_scope[
                    "qseqid"
                ]
            )
        )

        rescued_by_reselection = len(
            rescued_ids
        )

    else:
        original_besthit_rows = None
        original_besthit_unique_reads = None
        direct_filtered_old_besthit_count = None
        rescued_by_reselection = None
        rescued_ids = set()

    current_scope_count = int(
        len(best)
    )

    current_scope_unique_reads = int(
        best[
            "qseqid"
        ].nunique()
    )

    if (
        current_scope_count
        != current_scope_unique_reads
    ):
        raise RuntimeError(
            f"{dataset}: final besthit row count != unique qseqid count"
        )

    mapped_unique_subjects = int(
        mapped_hits[
            "subject_norm"
        ].nunique()
    )

    unmapped_unique_subjects = int(
        unmapped_hits[
            "subject_norm"
        ].nunique()
    )

    in_scope_unique_subtypes = int(
        best[
            "mapped_subtype"
        ].nunique()
    ) if not best.empty else 0

    in_scope_unique_types = int(
        best[
            "mapped_type"
        ].nunique()
    ) if not best.empty else 0

    subtype_counts = count_table(
        best,
        "mapped_subtype",
        "Subtype",
    )

    type_counts = count_table(
        best,
        "mapped_type",
        "Type",
    )

    removed_subtype_counts = count_table(
        out_scope_hits,
        "mapped_subtype",
        "Subtype",
    )

    # Count removed reads by their best out-of-scope hit only for descriptive audit.
    # This is NOT used as the current-scope ground truth.
    out_scope_best = select_best_hits(
        out_scope_hits
    )

    removed_besthit_subtype_counts = count_table(
        out_scope_best,
        "mapped_subtype",
        "Subtype",
    ).rename(
        columns={
            "count":
                "besthit_read_count",
        }
    )

    removed_subtype_summary = (
        removed_subtype_counts
        .rename(
            columns={
                "count":
                    "all_hit_row_count",
            }
        )
        .merge(
            removed_besthit_subtype_counts,
            on="Subtype",
            how="outer",
        )
        .fillna(0)
    )

    if not removed_subtype_summary.empty:
        removed_subtype_summary[
            "all_hit_row_count"
        ] = (
            removed_subtype_summary[
                "all_hit_row_count"
            ]
            .astype(int)
        )

        removed_subtype_summary[
            "besthit_read_count"
        ] = (
            removed_subtype_summary[
                "besthit_read_count"
            ]
            .astype(int)
        )

    # ------------------------------------------------------------------
    # Write per-dataset final outputs
    # ------------------------------------------------------------------

    best_output = (
        dataset_output
        / f"{dataset}_current_scope_besthit.tsv"
    )

    all_scope_output = (
        dataset_output
        / f"{dataset}_current_scope_all_hits.tsv"
    )

    out_scope_output = (
        dataset_output
        / f"{dataset}_out_of_scope_hits.tsv"
    )

    unmapped_output = (
        dataset_output
        / f"{dataset}_unmapped_hits.tsv"
    )

    subtype_output = (
        dataset_output
        / f"{dataset}_current_scope_subtype_counts.csv"
    )

    type_output = (
        dataset_output
        / f"{dataset}_current_scope_type_counts.csv"
    )

    removed_subtype_output = (
        dataset_output
        / f"{dataset}_out_of_scope_subtype_counts.csv"
    )

    summary_output = (
        dataset_output
        / f"{dataset}_current_scope_summary.json"
    )

    # Keep original BLAST columns + mapping columns, remove internal rank/order.
    internal_columns = {
        "_row_order",
    }

    def clean_for_write(
        frame: pd.DataFrame,
    ) -> pd.DataFrame:
        return frame.drop(
            columns=[
                column
                for column
                in internal_columns
                if column
                in frame.columns
            ]
        )

    safe_write_tsv(
        clean_for_write(
            best
        ),
        best_output,
        overwrite,
    )

    safe_write_tsv(
        clean_for_write(
            in_scope_hits
        ),
        all_scope_output,
        overwrite,
    )

    safe_write_tsv(
        clean_for_write(
            out_scope_hits
        ),
        out_scope_output,
        overwrite,
    )

    safe_write_tsv(
        clean_for_write(
            unmapped_hits
        ),
        unmapped_output,
        overwrite,
    )

    safe_write_csv(
        subtype_counts,
        subtype_output,
        overwrite,
    )

    safe_write_csv(
        type_counts,
        type_output,
        overwrite,
    )

    safe_write_csv(
        removed_subtype_summary,
        removed_subtype_output,
        overwrite,
    )

    summary = {
        "dataset":
            dataset,

        "script_version":
            SCRIPT_VERSION,

        "strict_all_hit_rows":
            total_hit_rows,

        "strict_all_unique_reads":
            total_reads_with_strict_hit,

        "mapped_hit_rows":
            int(
                len(
                    mapped_hits
                )
            ),

        "unmapped_hit_rows":
            int(
                len(
                    unmapped_hits
                )
            ),

        "mapped_unique_subjects":
            mapped_unique_subjects,

        "unmapped_unique_subjects":
            unmapped_unique_subjects,

        "in_scope_hit_rows":
            int(
                len(
                    in_scope_hits
                )
            ),

        "out_of_scope_hit_rows":
            int(
                len(
                    out_scope_hits
                )
            ),

        "current_scope_BLAST_ARG_count":
            current_scope_count,

        "current_scope_unique_reads":
            current_scope_unique_reads,

        "current_scope_unique_subtypes_detected":
            in_scope_unique_subtypes,

        "current_scope_unique_types_detected":
            in_scope_unique_types,

        "original_strict_besthit_rows":
            original_besthit_rows,

        "original_strict_besthit_unique_reads":
            original_besthit_unique_reads,

        "old_besthit_direct_filter_count":
            direct_filtered_old_besthit_count,

        "rescued_by_reselection_from_all_hits":
            rescued_by_reselection,

        "final_besthit_file":
            str(
                best_output
            ),

        "final_subtype_count_file":
            str(
                subtype_output
            ),

        "final_type_count_file":
            str(
                type_output
            ),
    }

    safe_write_json(
        summary,
        summary_output,
        overwrite,
    )

    print(
        f"strict all-hit rows                : {total_hit_rows:,}",
        flush=True,
    )

    print(
        f"strict unique reads                : {total_reads_with_strict_hit:,}",
        flush=True,
    )

    print(
        f"mapped hit rows                    : {len(mapped_hits):,}",
        flush=True,
    )

    print(
        f"unmapped hit rows                  : {len(unmapped_hits):,}",
        flush=True,
    )

    print(
        f"in-scope hit rows                  : {len(in_scope_hits):,}",
        flush=True,
    )

    print(
        f"out-of-scope hit rows              : {len(out_scope_hits):,}",
        flush=True,
    )

    if original_besthit_unique_reads is not None:
        print(
            f"original strict besthit count      : {original_besthit_unique_reads:,}",
            flush=True,
        )

        print(
            f"old besthit direct-filter count    : {direct_filtered_old_besthit_count:,}",
            flush=True,
        )

        print(
            f"rescued by all-hit reselection     : {rescued_by_reselection:,}",
            flush=True,
        )

    print(
        f"FINAL current-scope BLAST ARG count: {current_scope_count:,}",
        flush=True,
    )

    print(
        f"FINAL detected Subtypes            : {in_scope_unique_subtypes:,}",
        flush=True,
    )

    print(
        f"FINAL detected Types               : {in_scope_unique_types:,}",
        flush=True,
    )

    print(
        f"Final besthit                      : {best_output}",
        flush=True,
    )

    # Per-dataset removed subtype table for global merge.
    removed_global = removed_subtype_summary.copy()

    if not removed_global.empty:
        removed_global.insert(
            0,
            "dataset",
            dataset,
        )

    return {
        "summary":
            summary,

        "subtype_counts":
            subtype_counts,

        "type_counts":
            type_counts,

        "removed_subtype_summary":
            removed_global,

        "unmapped_subjects":
            sorted(
                set(
                    unmapped_hits[
                        "subject_norm"
                    ]
                )
                - {""}
            ),
    }


def make_count_matrix(
    per_dataset_counts: dict[
        str,
        pd.DataFrame,
    ],
    label_column: str,
) -> pd.DataFrame:

    labels = sorted(
        {
            label
            for frame
            in per_dataset_counts.values()
            for label
            in frame[
                label_column
            ].tolist()
        }
    )

    output = pd.DataFrame(
        {
            label_column:
                labels,
        }
    )

    for dataset in DATASETS:
        frame = per_dataset_counts.get(
            dataset
        )

        if frame is None:
            output[
                dataset
            ] = 0
            continue

        mapping = dict(
            zip(
                frame[
                    label_column
                ],
                frame[
                    "count"
                ],
            )
        )

        output[
            dataset
        ] = output[
            label_column
        ].map(
            lambda label:
                int(
                    mapping.get(
                        label,
                        0,
                    )
                )
        )

    return output


def main() -> None:

    args = parse_args()

    root = (
        args.root
        .expanduser()
        .resolve()
    )

    if not root.is_dir():
        raise NotADirectoryError(
            f"Root directory not found: {root}"
        )

    nucleotide_structure = (
        args.nucleotide_structure
        if args.nucleotide_structure
        is not None
        else (
            root
            / "Nucleotide_SARG_v3.2_Long_structure.txt"
        )
    )

    current_structure = (
        args.current_structure
        if args.current_structure
        is not None
        else (
            root
            / "structure_50aa_150nt_5parts.txt"
        )
    )

    output_root = (
        args.output_root
        if args.output_root
        is not None
        else (
            root
            / "BLASTN_current_ARGScope_labelspace"
        )
    )

    nucleotide_structure = (
        nucleotide_structure
        .expanduser()
        .resolve()
    )

    current_structure = (
        current_structure
        .expanduser()
        .resolve()
    )

    output_root = (
        output_root
        .expanduser()
        .resolve()
    )

    requested_datasets = list(
        dict.fromkeys(
            args.datasets
        )
    )

    unexpected = [
        dataset
        for dataset
        in requested_datasets
        if dataset
        not in DATASETS
    ]

    if unexpected:
        raise ValueError(
            f"Unexpected dataset(s): {unexpected}"
        )

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "=" * 118,
        flush=True,
    )

    print(
        "STRICT BLASTN -> CURRENT ARGScope SUBTYPE LABEL SPACE",
        flush=True,
    )

    print(
        "=" * 118,
        flush=True,
    )

    print(
        f"Script version        : {SCRIPT_VERSION}",
        flush=True,
    )

    print(
        f"Root                  : {root}",
        flush=True,
    )

    print(
        f"Nucleotide structure  : {nucleotide_structure}",
        flush=True,
    )

    print(
        f"Current structure     : {current_structure}",
        flush=True,
    )

    print(
        f"Output root           : {output_root}",
        flush=True,
    )

    print(
        f"Datasets              : {requested_datasets}",
        flush=True,
    )

    print(
        "GPU                   : not used (I/O + dataframe filtering task)",
        flush=True,
    )

    print(
        "\nLoading SARG nucleotide subject mapping...",
        flush=True,
    )

    nucleotide_info = build_nucleotide_mapping(
        nucleotide_structure
    )

    print(
        f"Nucleotide structure rows          : "
        f"{nucleotide_info['raw_rows']:,}",
        flush=True,
    )

    print(
        f"Unique normalized Nucleotide IDs   : "
        f"{nucleotide_info['unique_normalized_ids']:,}",
        flush=True,
    )

    print(
        f"Unambiguous subject mappings       : "
        f"{nucleotide_info['mapped_unambiguous_ids']:,}",
        flush=True,
    )

    print(
        f"Ambiguous subject IDs excluded     : "
        f"{len(nucleotide_info['ambiguous_ids']):,}",
        flush=True,
    )

    print(
        "\nLoading CURRENT ARGScope subtype universe...",
        flush=True,
    )

    label_info = build_current_label_space(
        current_structure
    )

    print(
        f"Current ARG Subtypes               : "
        f"{label_info['number_current_ARG_subtypes']:,}",
        flush=True,
    )

    print(
        f"Current ARG Types                  : "
        f"{label_info['number_current_ARG_types']:,}",
        flush=True,
    )

    all_summaries = []

    subtype_counts_by_dataset = {}
    type_counts_by_dataset = {}
    removed_frames = []
    mapping_audit_rows = []

    for index, dataset in enumerate(
        requested_datasets,
        start=1,
    ):

        print(
            f"\n######## DATASET {index}/{len(requested_datasets)} ########",
            flush=True,
        )

        result = process_dataset(
            dataset=dataset,
            root=root,
            output_root=output_root,
            nucleotide_mapping=nucleotide_info[
                "mapping"
            ],
            current_subtypes=label_info[
                "current_subtypes"
            ],
            overwrite=args.overwrite,
        )

        all_summaries.append(
            result[
                "summary"
            ]
        )

        subtype_counts_by_dataset[
            dataset
        ] = result[
            "subtype_counts"
        ]

        type_counts_by_dataset[
            dataset
        ] = result[
            "type_counts"
        ]

        if not result[
            "removed_subtype_summary"
        ].empty:
            removed_frames.append(
                result[
                    "removed_subtype_summary"
                ]
            )

        mapping_audit_rows.append(
            {
                "dataset":
                    dataset,

                "unmapped_unique_subjects":
                    len(
                        result[
                            "unmapped_subjects"
                        ]
                    ),

                "unmapped_subject_examples":
                    ";".join(
                        result[
                            "unmapped_subjects"
                        ][:20]
                    ),
            }
        )

    # ------------------------------------------------------------------
    # Combined final outputs
    # ------------------------------------------------------------------

    summary_df = pd.DataFrame(
        all_summaries
    )

    summary_columns = [
        "dataset",
        "original_strict_besthit_unique_reads",
        "old_besthit_direct_filter_count",
        "rescued_by_reselection_from_all_hits",
        "current_scope_BLAST_ARG_count",
        "current_scope_unique_subtypes_detected",
        "current_scope_unique_types_detected",
        "strict_all_hit_rows",
        "strict_all_unique_reads",
        "mapped_hit_rows",
        "unmapped_hit_rows",
        "in_scope_hit_rows",
        "out_of_scope_hit_rows",
    ]

    summary_df = summary_df[
        [
            column
            for column
            in summary_columns
            if column
            in summary_df.columns
        ]
    ]

    summary_path = (
        output_root
        / "BLASTN_current_scope_dataset_summary.csv"
    )

    safe_write_csv(
        summary_df,
        summary_path,
        args.overwrite,
    )

    # Count matrices.
    subtype_matrix = make_count_matrix(
        subtype_counts_by_dataset,
        "Subtype",
    )

    type_matrix = make_count_matrix(
        type_counts_by_dataset,
        "Type",
    )

    subtype_matrix_path = (
        output_root
        / "BLASTN_current_scope_subtype_count_matrix.csv"
    )

    type_matrix_path = (
        output_root
        / "BLASTN_current_scope_type_count_matrix.csv"
    )

    safe_write_csv(
        subtype_matrix,
        subtype_matrix_path,
        args.overwrite,
    )

    safe_write_csv(
        type_matrix,
        type_matrix_path,
        args.overwrite,
    )

    # Removed subtype summary.
    if removed_frames:
        removed_all = pd.concat(
            removed_frames,
            ignore_index=True,
        )

        removed_global = (
            removed_all
            .groupby(
                "Subtype",
                as_index=False,
            )[
                [
                    "all_hit_row_count",
                    "besthit_read_count",
                ]
            ]
            .sum()
            .sort_values(
                [
                    "besthit_read_count",
                    "all_hit_row_count",
                    "Subtype",
                ],
                ascending=[
                    False,
                    False,
                    True,
                ],
            )
        )
    else:
        removed_global = pd.DataFrame(
            columns=[
                "Subtype",
                "all_hit_row_count",
                "besthit_read_count",
            ]
        )

    removed_path = (
        output_root
        / "BLASTN_current_scope_removed_subtype_summary.csv"
    )

    safe_write_csv(
        removed_global,
        removed_path,
        args.overwrite,
    )

    mapping_audit_df = pd.DataFrame(
        mapping_audit_rows
    )

    mapping_audit_path = (
        output_root
        / "BLASTN_current_scope_mapping_audit.csv"
    )

    safe_write_csv(
        mapping_audit_df,
        mapping_audit_path,
        args.overwrite,
    )

    # Label-space audit.
    label_space_df = pd.DataFrame(
        sorted(
            label_info[
                "subtype_to_type"
            ].items()
        ),
        columns=[
            "Subtype",
            "Type",
        ],
    )

    label_space_path = (
        output_root
        / "CURRENT_ARGScope_ARG_subtype_label_space.csv"
    )

    safe_write_csv(
        label_space_df,
        label_space_path,
        args.overwrite,
    )

    print()
    print(
        "#" * 118,
        flush=True,
    )

    print(
        "ALL 9 DATASETS COMPLETED",
        flush=True,
    )

    print(
        "#" * 118,
        flush=True,
    )

    print(
        f"Current ARG subtype universe : "
        f"{label_info['number_current_ARG_subtypes']:,}",
        flush=True,
    )

    print(
        f"Main dataset summary         : {summary_path}",
        flush=True,
    )

    print(
        f"Subtype count matrix         : {subtype_matrix_path}",
        flush=True,
    )

    print(
        f"Type count matrix            : {type_matrix_path}",
        flush=True,
    )

    print(
        f"Removed subtype summary      : {removed_path}",
        flush=True,
    )

    print(
        f"Mapping audit                : {mapping_audit_path}",
        flush=True,
    )

    print()
    print(
        "For comparison with ARGScope, use column:",
        flush=True,
    )

    print(
        "    current_scope_BLAST_ARG_count",
        flush=True,
    )

    print()
    print(
        "For per-read ground-truth comparison, use:",
        flush=True,
    )

    print(
        "    <dataset>/<dataset>_current_scope_besthit.tsv",
        flush=True,
    )


if __name__ == "__main__":
    main()
