// Render the actual vector deliverables for visual QA, without changing them.
const fs=require('fs');
const path=require('path');
const sharp=require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve('outputs/argscope_subtype_argonly_20260922/Figure2_Figure3_transparent_SVG');
const qa=path.resolve('outputs/argscope_subtype_argonly_20260922/qa_svg');
fs.mkdirSync(qa,{recursive:true});
(async()=>{
 const report=[];
 for(const folder of ['Figure2_Protein','Figure3_DNA']){
  const files=fs.readdirSync(path.join(root,folder)).filter(x=>x.endsWith('.svg')).sort();
  if(files.length!==7) throw Error('Expected 7 SVGs');
  for(const file of files){
   const svg=fs.readFileSync(path.join(root,folder,file));
   const s=svg.toString();
   if(s.includes('<image ')) throw Error('Raster element in '+file);
   const result=await sharp(svg,{density:170}).resize({width:1800,height:1500,fit:'inside'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
   const {width,height,channels}=result.info;
   let x0=width,y0=height,x1=-1,y1=-1,transparent=0;
   for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const a=result.data[(y*width+x)*channels+channels-1];
    if(a===0)transparent++;
    if(a>4){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
   }
   if(!transparent) throw Error('No transparency: '+file);
   await sharp(result.data,{raw:result.info}).flatten({background:'#ffffff'}).png().toFile(path.join(qa,file.replace('.svg','.png')));
   report.push({file,width,height,alpha_zero_pixels:transparent,exterior_blank_pixels:[x0,y0,width-1-x1,height-1-y1],has_raster_image:false});
  }
 }
 fs.writeFileSync(path.join(qa,'svg_render_verification.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
