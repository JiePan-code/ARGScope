from pathlib import Path
import base64
import json
import re
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
import zlib

root=Path(__file__).resolve().parent
source=root/'outputs/ARGScope_drawio_20260930'
dest=Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/ARGScope_drawio_20260930')

def pages(path):
    result=[]
    for p in ET.parse(path).getroot().findall('diagram'):
        model=p.find('mxGraphModel')
        if model is None:
            model=ET.fromstring(urllib.parse.unquote(zlib.decompress(base64.b64decode(p.text),-15).decode()))
        cells=model.findall('./root/mxCell')
        result.append((p.get('name'),cells))
    return result

app_file=dest/'ARGScope_Figure1_Figure2_editable.drawio'
original=pages(source/app_file.name)
saved=pages(app_file)
assert len(saved)==2
report=[]
for (oname,oc),(sname,sc) in zip(original,saved):
    assert oname==sname
    assert len(oc)==len(sc)
    omap={c.get('id'):c for c in oc}
    for c in sc:
        prior=omap[c.get('id')]
        assert c.get('value','')==prior.get('value',''), c.get('id')
        assert c.get('source')==prior.get('source') and c.get('target')==prior.get('target')
        g,pg=c.find('mxGeometry'),prior.find('mxGeometry')
        if g is not None:
            for k in ['x','y','width','height']:
                assert float(g.get(k,0))==float(pg.get(k,0)), (c.get('id'),k)
        style=c.get('style','')
        for hexcolor in re.findall(r'#[A-Fa-f0-9]{6}',style):
            assert hexcolor.upper() in {'#3478AE','#259B91','#283743','#FFFFFF'}
        if c.get('value'):
            assert 'fontFamily=Arial;' in style
    report.append({'page':sname,'cells':len(sc),'app_saved_geometry_and_labels_match':True,
                   'native_text_cells':sum(bool(c.get('value')) for c in sc),
                   'embedded_svg_icons':sum('shape=image;' in c.get('style','') for c in sc)})

report_path=dest/'drawio_app_verification.json'
report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
archive=dest.with_suffix('.zip')
assert not archive.exists(), 'Do not overwrite an existing delivery archive'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in dest.iterdir():
        if f.is_file(): z.write(f,arcname=dest.name+'/'+f.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    print(json.dumps({'validation':report,'archive':str(archive),'archive_files':len(z.namelist())},ensure_ascii=False,indent=2))
