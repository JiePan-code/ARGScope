#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Apply saved Full models to 60/70/80/90% fivefold fragment embeddings.

Singleton status is computed from ORIGINAL full-length structure records.
Use the NEW model's saved parent test IDs, never historical fragment split tags.
All original inputs are read-only. No training, calibration or resplitting.
"""
from __future__ import annotations

import argparse
import csv
import gc
import json
import re
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import torch

from metrics_core import binary_metrics, multiclass_metrics, read_csv, write_csv, sha256, METRICS
from student_models import ProteinStudent, DNAStudent

HERE = Path(__file__).resolve().parent
PCTS = (60, 70, 80, 90)
NONARG = "nonARG"
PINNED_SPLIT = "6d2d3cf7ad252f255dedf4e4bbeae693f5ea0c5112f39daec331aaa975d93991"
CHECKPOINTS = {"protein": "protein_100pct_epoch_features_run_best_model.pt", "dna": "DNA_student_long_model.pt"}
FULL_EMBEDDINGS = {"protein": "ESM2_EMBEDDING/percent_100/full_1to1_esm2_mean.pt",
                   "dna": "DNABERT2_embedding/percent_100/full_1to1_dnabert2_mean.pt"}


def save_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)


def source_record(path):
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha256(path)}


def read_structure(data_root):
    path = data_root / "all_ARG_nonARG_1to1_structure.txt"
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    by_id = {r["SARG.Seq.ID"]: r for r in rows}
    if not rows or len(rows) != len(by_id) or any(not sid or sid != sid.strip() for sid in by_id):
        raise ValueError("Original full-length structure has empty or duplicate IDs")
    subtype_types = {}
    for row in rows:
        if not row["Subtype"] or not row["Type"] or subtype_types.setdefault(row["Subtype"], row["Type"]) != row["Type"]:
            raise ValueError("Missing label or ambiguous original subtype-to-type mapping")
        if row["ARG.or.nonARG"] != ("nonARG" if row["Subtype"] == NONARG else "ARG"):
            raise ValueError("Original binary/subtype labels disagree")
    counts = Counter(r["Subtype"] for r in rows if r["ARG.or.nonARG"] == "ARG")
    singleton_ids = {sid for sid, r in by_id.items() if r["ARG.or.nonARG"] == "ARG" and counts[r["Subtype"]] == 1}
    return by_id, singleton_ids, path


def read_model_manifest(full, modality, original):
    path = full / modality / "split_manifest.csv"
    rows = read_csv(path)
    subtype_key = "Subtype" if "Subtype" in rows[0] else "subtype"
    type_key = "Type" if "Type" in rows[0] else "type"
    manifest = {r["sequence_id"]: {"Subtype": r[subtype_key], "Type": r[type_key],
                                  "model_split": r["model_split"], "external_split": r["external_split"]} for r in rows}
    if len(rows) != len(manifest):
        raise ValueError("Duplicate parent ID in model split manifest")
    for sid, row in manifest.items():
        if sid not in original or (row["Subtype"], row["Type"]) != (original[sid]["Subtype"], original[sid]["Type"]):
            raise ValueError("Saved model labels differ from original structure")
        if row["model_split"] not in {"train", "validation", "test"}:
            raise ValueError("Unknown saved model split")
        if row["external_split"] != ("test" if row["model_split"] == "test" else "train"):
            raise ValueError("Inconsistent model/external split")
    return manifest, path


def read_checkpoint(full, modality, manifest, singleton_ids, original):
    folder = full / modality
    receipt_path = folder / "COMPLETE.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8-sig"))
    ident = receipt["identity"]
    if (receipt["status"] != "complete" or ident["variant"] != "full" or ident["stage"] != modality or
            ident["smoke_test_only"] is not False or ident["split_fingerprint"] != PINNED_SPLIT):
        raise ValueError("Wrong Full model, split, incomplete run, or smoke model")
    for name in (CHECKPOINTS[modality], "split_manifest.csv", "test_sequence_predictions.csv"):
        if sha256(folder / name) != receipt["outputs"][name]:
            raise ValueError(f"Saved completed output changed: {folder / name}")
    checkpoint = torch.load(folder / CHECKPOINTS[modality], map_location="cpu", weights_only=True)
    if checkpoint["experiment_provenance"] != ident:
        raise ValueError("Checkpoint and completion provenance disagree")
    arg_names = checkpoint["arg_subtype_names"]
    population_names = {r["Subtype"] for r in manifest.values()} - {NONARG}
    if len(arg_names) != len(set(arg_names)) or set(arg_names) != population_names:
        raise ValueError("Checkpoint label set differs from saved population")
    if singleton_ids & manifest.keys():
        raise ValueError("Saved model population unexpectedly contains singleton ARGs")
    # The checkpoint stores the complete structure lookup (including unused
    # singleton labels), while the actual subtype head contains only 820 labels.
    complete_mapping = {r["Subtype"]: r["Type"] for r in original.values()}
    if checkpoint["subtype_to_type"] != complete_mapping:
        raise ValueError("Checkpoint subtype-to-type lookup differs from original structure")
    dim = 1280 if modality == "protein" else 768
    key = modality + "_train_"
    mean, std = checkpoint[key + "mean"], checkpoint[key + "std"]
    state = checkpoint["student_state_dict"]
    if (mean.shape != (dim,) or std.shape != (dim,) or not torch.isfinite(mean).all()
            or not torch.isfinite(std).all() or not torch.all(std > 0)):
        raise ValueError("Invalid saved normalization parameters")
    torch.testing.assert_close(mean, state[modality + "_mean"], rtol=0, atol=0)
    torch.testing.assert_close(std, state[modality + "_std"], rtol=0, atol=0)
    config = SimpleNamespace(**checkpoint["configuration"])
    cls = ProteinStudent if modality == "protein" else DNAStudent
    model = cls(dim, mean, std, len(arg_names), config)
    model.load_state_dict(state, strict=True)
    model.eval().requires_grad_(False).cuda()
    threshold = float(checkpoint["selected_binary_ARG_probability_threshold"])
    if threshold != .8:
        raise ValueError("Unexpected saved binary threshold; no silent recalibration")
    return model, checkpoint, int(config.eval_batch_size), threshold, receipt_path


@torch.inference_mode()
def predict(model, embedding, checkpoint, batch_size, threshold):
    # Standardization happens ONCE inside the model, using saved train statistics.
    model.eval()
    binary_logits, subtype_logits = [], []
    for begin in range(0, len(embedding), batch_size):
        xb = embedding[begin:begin + batch_size].cuda()
        with torch.autocast("cuda", dtype=torch.float16):
            binary, subtype, _ = model(xb)
        binary_logits.append(binary.float().cpu())
        subtype_logits.append(subtype.float().cpu())
    # Match training-time reporting: CPU float32 softmax after AMP logits.
    prob_arg = torch.softmax(torch.cat(binary_logits), dim=1)[:, 1]
    subtype_prob = torch.softmax(torch.cat(subtype_logits), dim=1)
    best_prob, best_index = subtype_prob.max(dim=1)
    if not torch.isfinite(prob_arg).all() or not torch.isfinite(best_prob).all():
        raise ValueError("Non-finite model probabilities")
    return prob_arg.tolist(), best_prob.tolist(), best_index.tolist()


def make_predictions(ids, parents, replicates, pct, vectors, model, checkpoint, batch_size, threshold, original):
    prob_arg, best_prob, best_index = predict(model, vectors, checkpoint, batch_size, threshold)
    rows = []
    for i, sid in enumerate(ids):
        parent = parents[i]
        truth = original[parent]
        raw_subtype = checkpoint["arg_subtype_names"][best_index[i]]
        pred_arg = int(prob_arg[i] >= threshold)
        pred_subtype = raw_subtype if pred_arg else NONARG
        pred_type = checkpoint["subtype_to_type"][pred_subtype] if pred_arg else NONARG
        rows.append({"split": "test", "sequence_level": "full_length" if pct == 100 else "fragment",
                     "sequence_id": sid, "parent_sequence_id": parent, "replicate": replicates[i],
                     "completeness_percent": pct, "true_subtype": truth["Subtype"],
                     "predicted_subtype": pred_subtype, "true_type": truth["Type"], "predicted_type": pred_type,
                     "true_ARG": int(truth["ARG.or.nonARG"] == "ARG"), "predicted_ARG": pred_arg,
                     "ARG_probability": prob_arg[i], "ARG_subtype_max_probability": best_prob[i],
                     "ARG_subtype_before_binary_gate": raw_subtype, "binary_threshold": threshold,
                     "coverage": pct / 100})
    return rows


def reproduce_full(data_root, full, modality, original, test_ids, model, checkpoint, batch_size, threshold, output):
    reference_path = full / modality / "test_sequence_predictions.csv"
    reference = read_csv(reference_path)
    ids = [r["sequence_id"] for r in reference]
    if len(set(ids)) != len(ids) or set(ids) != test_ids:
        raise ValueError("Saved 100% prediction IDs differ from model test IDs")
    path = data_root / FULL_EMBEDDINGS[modality]
    obj = torch.load(path, map_location="cpu", weights_only=True)
    indices = {sid: i for i, sid in enumerate(obj["ids"])}
    if len(indices) != len(obj["ids"]) or not test_ids <= indices.keys():
        raise ValueError("Full embedding IDs missing or duplicated")
    vectors = obj["embeddings"][[indices[sid] for sid in ids]].float().contiguous()
    if not torch.isfinite(vectors).all():
        raise ValueError("Invalid 100% embeddings")
    rows = make_predictions(ids, ids, [0] * len(ids), 100, vectors, model, checkpoint, batch_size, threshold, original)
    label_errors = []
    differences = []
    for a, b in zip(rows, reference):
        for key in ("true_subtype", "true_type", "predicted_subtype", "predicted_type", "true_ARG", "predicted_ARG"):
            if str(a[key]) != b[key]:
                label_errors.append((a["sequence_id"], key, a[key], b[key]))
        differences.extend(abs(a[k] - float(b[k])) for k in ("ARG_probability", "ARG_subtype_max_probability"))
    report = {"modality": modality, "N_test": len(ids), "label_mismatch_count": len(label_errors),
              "max_probability_difference": max(differences), "saved_best_epoch": checkpoint["student_best_epoch"],
              "threshold": threshold, "eval_batch_size": batch_size, "full_embedding": source_record(path),
              "reference_predictions": source_record(reference_path)}
    # A strong regression gate, not a test-set hyperparameter search.
    if label_errors or max(differences) > 1e-5:
        raise ValueError(f"100% reproduction failed: {report}; first mismatches: {label_errors[:3]}")
    report["status"] = "PASS"
    save_json(output / f"{modality}_100pct_reproduction.json", report)
    write_csv(output / modality / "100%_test_sequence_predictions.csv", rows)
    print(f"PASS {modality} 100% reproduction: all {len(ids)} labels match; max probability error={max(differences):.3g}", flush=True)
    del obj, vectors
    gc.collect()
    return rows, report


def fragment_files(data_root, modality, pct):
    base = data_root / ("ESM2_EMBEDDING" if modality == "protein" else "DNABERT2_embedding") / f"percent_{pct}"
    # Top-level only. Backup folders and stale completion JSONs are never inputs.
    pattern = f"percent_{pct}_protein_esm2_t33_650M_OFFICIAL_MEAN.pt" if modality == "protein" else f"percent_{pct}_chunk_*_dnabert2_OFFICIAL_MEAN.pt"
    paths = sorted(base.glob(pattern))
    if not paths:
        raise FileNotFoundError(f"No active embedding files: {base}")
    if modality == "protein" and len(paths) != 1:
        raise ValueError("Expected one active Protein embedding file")
    return paths


def select_fragments(data_root, modality, pct, original, manifest, singleton_ids, test_order, output):
    expected = {f"{sid}_{part}": (sid, part) for sid in original for part in range(1, 6)}
    if len(expected) != len(original) * 5:
        raise ValueError("Ambiguous parent/replicate ID naming")
    desired = [f"{sid}_{part}" for sid in test_order for part in range(1, 6)]
    desired_pos = {sid: i for i, sid in enumerate(desired)}
    dim = 1280 if modality == "protein" else 768
    selected = torch.empty((len(desired), dim), dtype=torch.float32)
    selected_source_ids = [None] * len(desired)
    repair_aliases = []
    seen, filled = set(), set()
    counts, records = Counter(), []
    old_tag_disagreement = 0
    files = fragment_files(data_root, modality, pct)
    for path in files:
        print(f"READ {modality} {pct}%: {path.name}", flush=True)
        obj = torch.load(path, map_location="cpu", weights_only=True)
        ids, embedding = obj["ids"], obj["embeddings"]
        if obj.get("condition") != f"percent_{pct}" or tuple(embedding.shape) != (len(ids), dim):
            raise ValueError(f"Wrong completeness or dimensions: {path}")
        if not torch.isfinite(embedding).all():
            raise ValueError(f"Non-finite embeddings: {path}")
        if modality == "protein" and (obj.get("model_name") != "esm2_t33_650M_UR50D" or obj.get("representation_layer") != 33):
            raise ValueError("Protein embedding definition differs from trained model")
        if modality == "dna":
            ordinary = obj.get("model_name") == "zhihan1996/DNABERT-2-117M"
            # The verified repaired 90% artifact retained model_path rather than model_name.
            repaired_merged = (pct == 90 and obj.get("merged_single_pt") is True and
                               obj.get("model_path") == "/scratch/users/ntu/pan.jie/work/DNABERT/model/DNABERT-2-117M" and
                               obj.get("script_version") == "2026-08-22-percent90-dnabert2-repair-merge-one-pt-v1" and
                               obj.get("pooling") == ["attention_masked_mean_all_nonpadding_tokens", "official_mean_pooling"])
            if not (ordinary or repaired_merged) or obj.get("truncation") is not False:
                raise ValueError("DNA embedding definition differs from trained model")
        source_indices, destination_indices = [], []
        headers = obj.get("headers")
        if headers is not None and len(headers) != len(ids):
            raise ValueError("Header / embedding ID count mismatch")
        for key in ("original_ids", "types", "subtypes"):
            if key in obj and len(obj[key]) != len(ids):
                raise ValueError(f"Per-row metadata length mismatch: {key}")
        for i, fid in enumerate(ids):
            canonical_id = fid
            if fid not in expected:
                repaired = re.fullmatch(r"(.+)__SIM_percent_90__P0([1-5])__A[0-9]{6}", fid) if pct == 90 else None
                if (not repaired or repaired.group(1) not in original or obj.get("repair_records") != 165 or
                        (modality == "protein" and obj.get("repair_applied") is not True)):
                    raise ValueError(f"Unrecognized fragment ID: {fid}")
                canonical_id = f"{repaired.group(1)}_{int(repaired.group(2))}"
                repair_aliases.append({"source_fragment_id": fid, "canonical_fragment_id": canonical_id,
                                       "parent_sequence_id": repaired.group(1), "replicate": int(repaired.group(2)),
                                       "retained_in_test": canonical_id in desired_pos})
            if canonical_id not in expected or canonical_id in seen:
                raise ValueError(f"Unknown or duplicate fragment ID: {fid}")
            seen.add(canonical_id)
            parent, replicate = expected[canonical_id]
            for key, truth in (("original_ids", parent), ("types", original[parent]["Type"]),
                               ("subtypes", original[parent]["Subtype"])):
                if key in obj and obj[key][i] != truth:
                    raise ValueError(f"Fragment metadata disagrees with original: {fid} / {key}")
            if headers is not None:
                tokens = dict(token.split("=", 1) for token in headers[i].split()[1:] if "=" in token)
                parent_tokens = [tokens[k] for k in ("Original.ID", "original_id") if k in tokens]
                if (not parent_tokens or any(value != parent for value in parent_tokens) or tokens.get("part") != str(replicate) or
                        tokens.get("condition") != f"percent_{pct}" or headers[i].split()[0] != fid):
                    raise ValueError(f"Fragment parent/header disagreement: {fid}")
                if parent in manifest and tokens.get("split") != manifest[parent]["external_split"]:
                    old_tag_disagreement += 1
            if parent in singleton_ids:
                counts["excluded_original_singleton_ARG_fragments"] += 1
            elif parent not in manifest:
                counts["excluded_parents_outside_saved_population"] += 1
            elif manifest[parent]["model_split"] != "test":
                counts[f"excluded_{manifest[parent]['model_split']}_fragments"] += 1
            else:
                if parent in singleton_ids or canonical_id not in desired_pos:
                    raise ValueError("Invalid fragment passed the filtering gate")
                source_indices.append(i)
                destination_indices.append(desired_pos[canonical_id])
                selected_source_ids[desired_pos[canonical_id]] = fid
                filled.add(canonical_id)
                counts["retained_test_fragments"] += 1
        if source_indices:
            selected[torch.tensor(destination_indices)] = embedding[torch.tensor(source_indices)].float()
        records.append(source_record(path))
        del obj, embedding
        gc.collect()
    if seen != expected.keys() or filled != set(desired):
        raise ValueError(f"Fragment coverage incomplete: missing_source={len(expected.keys()-seen)}, missing_test={len(set(desired)-filled)}")
    if pct == 90 and len(repair_aliases) != 165:
        raise ValueError("The repaired 90% embedding must contain exactly 165 documented replacement IDs")
    report = {"Modality": modality, "Completeness_percent": pct, "input_fragments": len(seen),
              "original_parent_sequences": len(original), **dict(counts),
              "retained_test_parents": len(test_order), "replicates_per_parent": 5,
              "repaired_ID_aliases": len(repair_aliases),
              "ARG_test_fragments": sum(original[s]["ARG.or.nonARG"] == "ARG" for s in test_order) * 5,
              "nonARG_test_fragments": sum(original[s]["ARG.or.nonARG"] == "nonARG" for s in test_order) * 5,
              "ignored_historical_header_split_disagreements": old_tag_disagreement}
    save_json(output / "audit" / f"{modality}_{pct}pct_inputs.json", {"summary": report, "sources": records})
    if repair_aliases:
        write_csv(output / "audit" / f"{modality}_{pct}pct_repaired_ID_mapping.csv", repair_aliases)
    parents, replicates = zip(*(expected[fid] for fid in desired))
    return selected_source_ids, list(parents), list(replicates), selected, report


def summarize(all_predictions, output):
    binary, types, subtypes, per_type = [], [], [], []
    binary_averages, binary_per_class, comparison = [], [], []
    for modality, pct, rows in all_predictions:
        info = {"Model": "Full", "Modality": modality.title() if modality == "protein" else "DNA",
                "Completeness_percent": pct, "N_test": len(rows),
                "N_parent_sequences": len({r["parent_sequence_id"] for r in rows}),
                "Population": "saved_test_parents_only_including_nonARG"}
        y, p = [r["true_ARG"] for r in rows], [r["predicted_ARG"] for r in rows]
        b = binary_metrics(y, p)
        binary.append({**info, "Average": "binary_ARG_positive", **b})
        binary_averages.extend({**info, **r} for r in multiclass_metrics(y, p))
        for name, value in (("ARG", 1), ("nonARG", 0)):
            binary_per_class.append({**info, "Positive_class": name,
                                     **binary_metrics([int(t == value) for t in y], [int(t == value) for t in p])})
        type_rows = multiclass_metrics([r["true_type"] for r in rows], [r["predicted_type"] for r in rows])
        subtype_rows = multiclass_metrics([r["true_subtype"] for r in rows], [r["predicted_subtype"] for r in rows])
        types.extend({**info, **r} for r in type_rows)
        subtypes.extend({**info, **r} for r in subtype_rows)
        for typ in sorted({r["true_type"] for r in rows} | {r["predicted_type"] for r in rows}):
            per_type.append({**info, "Type": typ, "Average": "one_vs_rest",
                             **binary_metrics([int(r["true_type"] == typ) for r in rows],
                                              [int(r["predicted_type"] == typ) for r in rows])})
        comparison.append({**info, "ARG_positive_Precision": b["Precision"],
                           "Type_macro_Precision": type_rows[0]["Precision"],
                           "Subtype_weighted_Precision": subtype_rows[1]["Precision"]})
    combined = [{"Level": level, **{k: v for k, v in r.items() if k not in
                {"TP", "TN", "FP", "FN", "Support", "Predicted_positive"}}}
                for level, selected in (("ARG_nonARG", binary), ("Type", types), ("Subtype", subtypes)) for r in selected]
    folder = output / "metrics"
    folder.mkdir()
    tables = {"00_all_metrics_summary.csv": combined, "01_ARG_nonARG_ARG_positive_five_metrics.csv": binary,
              "02_Type_overall_macro_weighted_micro.csv": types, "03_Subtype_overall_macro_weighted_micro.csv": subtypes,
              "04_Per_type_five_metrics.csv": per_type, "05_ARG_nonARG_macro_weighted_micro_optional.csv": binary_averages,
              "06_ARG_nonARG_each_class_five_metrics.csv": binary_per_class, "07_Precision_comparison.csv": comparison}
    for name, rows in tables.items():
        write_csv(folder / name, rows)
    per_type_dir = folder / "per_type"
    per_type_dir.mkdir()
    for typ in sorted({r["Type"] for r in per_type}):
        safe = re.sub(r"[^\w.-]+", "_", typ)[:70].strip(" .") or "type"
        write_csv(per_type_dir / f"{safe}.csv", [r for r in per_type if r["Type"] == typ])
    return tables


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=HERE.parent.parent)
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args()
    data_root, output = args.data_root.resolve(), args.output.resolve()
    full = data_root / "ARGScope_80_20_results/full"
    output.mkdir(parents=True, exist_ok=True)
    if any((output / name).exists() for name in ("audit", "protein", "dna", "metrics", "COMPLETE.json")):
        raise FileExistsError("Existing inference outputs are never overwritten; supply --output with a new directory.")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA not available; use the dnabert2_5060 Python environment")
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.set_float32_matmul_precision("high")
    original, singleton_ids, structure_path = read_structure(data_root)
    protein_manifest, protein_path = read_model_manifest(full, "protein", original)
    dna_manifest, dna_path = read_model_manifest(full, "dna", original)
    if protein_manifest != dna_manifest:
        raise ValueError("Protein and DNA saved parent splits differ")
    manifest = protein_manifest
    test_order = [r["sequence_id"] for r in read_csv(full / "protein/test_sequence_predictions.csv")]
    test_ids = {sid for sid, r in manifest.items() if r["model_split"] == "test"}
    if set(test_order) != test_ids or len(test_order) != len(test_ids) or test_ids & singleton_ids:
        raise ValueError("Test ID order/coverage or singleton check failed")
    for folder in ("audit", "protein", "dna"):
        (output / folder).mkdir()
    write_csv(output / "audit/removed_original_singleton_ARGs.csv",
              [{"parent_sequence_id": sid, "Subtype": original[sid]["Subtype"], "Type": original[sid]["Type"],
                "original_subtype_count": 1, "excluded_replicates_per_completeness": 5} for sid in sorted(singleton_ids)])
    write_csv(output / "audit/parent_selection_manifest.csv",
              [{"parent_sequence_id": sid, "Subtype": r["Subtype"], "Type": r["Type"],
                "ARG_or_nonARG": r["ARG.or.nonARG"],
                "selection": "exclude_original_singleton_ARG" if sid in singleton_ids else
                    "exclude_outside_saved_population" if sid not in manifest else manifest[sid]["model_split"]}
               for sid, r in original.items()])
    original_sources = [source_record(structure_path), source_record(protein_path), source_record(dna_path)]
    all_predictions, filtering_reports, checkpoint_records, reproduction = [], [], [], []
    started = time.monotonic()
    for modality in ("protein", "dna"):
        model, checkpoint, batch_size, threshold, receipt = read_checkpoint(full, modality, manifest, singleton_ids, original)
        checkpoint_records.extend([source_record(full / modality / CHECKPOINTS[modality]), source_record(receipt)])
        baseline, baseline_report = reproduce_full(data_root, full, modality, original, test_ids,
                                                   model, checkpoint, batch_size, threshold, output)
        all_predictions.append((modality, 100, baseline))
        reproduction.append(baseline_report)
        for pct in PCTS:
            ids, parents, parts, embedding, report = select_fragments(data_root, modality, pct, original,
                                                                     manifest, singleton_ids, test_order, output)
            rows = make_predictions(ids, parents, parts, pct, embedding, model, checkpoint, batch_size, threshold, original)
            write_csv(output / modality / f"{pct}%_fragment_predictions_test.csv", rows)
            all_predictions.append((modality, pct, rows))
            filtering_reports.append(report)
            print(f"DONE {modality} {pct}%: {len(rows)} test fragments from {len(test_ids)} parents; "
                  f"excluded singleton fragments={report['excluded_original_singleton_ARG_fragments']}", flush=True)
            del embedding
            gc.collect()
        del model, checkpoint
        torch.cuda.empty_cache()
    for pct in (60, 70, 80, 90, 100):
        paired = [{r["sequence_id"]: (r["parent_sequence_id"], r["true_subtype"], r["true_type"], r["true_ARG"])
                   for r in rows} for modality, value, rows in all_predictions if value == pct]
        if len(paired) != 2 or paired[0] != paired[1]:
            raise ValueError("Cross-modality fragment IDs or truth mismatch")
    tables = summarize(all_predictions, output)
    write_csv(output / "preprocessing_summary.csv", filtering_reports)
    for source in original_sources + checkpoint_records:
        if sha256(source["path"]) != source["sha256"]:
            raise RuntimeError("Original input/checkpoint changed during inference")
    report = {"status": "complete", "created_at": datetime.now().astimezone().isoformat(),
              "elapsed_seconds": time.monotonic() - started, "torch_version": torch.__version__,
              "GPU": torch.cuda.get_device_name(), "source_structure_parents": len(original),
              "original_singleton_ARG_parents_excluded": len(singleton_ids),
              "saved_test_parents": len(test_ids), "test_fragments_per_modality_per_completeness": len(test_ids) * 5,
              "fragment_conditions": list(PCTS), "100pct_added_as_reproduced_reference": True,
              "split_fingerprint": PINNED_SPLIT, "sources": original_sources + checkpoint_records,
              "reproduction_100pct": reproduction, "model_training_performed": False,
              "normalization": "checkpoint model-train mean/std, applied once inside Student",
              "threshold": .8, "original_embedding_files_modified": False,
              "type_subtype_metrics_include_nonARG": True, "binary_positive": "ARG",
              "averages": ["macro", "weighted", "micro"], "per_type": "one-versus-rest over all test fragments",
              "five_fragments_are_correlated": True, "independent_parent_N": len(test_ids),
              "original_header_splits_used_for_selection": False,
              "historical_header_split_warning": "Old fragment split tags are audited but ignored; saved new model parent split controls selection",
              "CSV_files": {p.relative_to(output).as_posix(): sha256(p) for p in sorted(output.rglob("*.csv"))},
              "code_sha256": {p.name: sha256(p) for p in sorted(HERE.glob("*.py"))},
              "metric_table_rows": {k: len(v) for k, v in tables.items()}}
    save_json(output / "COMPLETE.json", report)
    print(f"ALL EIGHT FRAGMENT APPLICATIONS COMPLETE: {output}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
