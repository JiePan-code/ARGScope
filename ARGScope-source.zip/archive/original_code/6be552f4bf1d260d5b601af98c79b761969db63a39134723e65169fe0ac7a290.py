#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Read-only audit for the paired BGC DNA/protein FASTA files and label CSV."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(r"E:\1. ARGmodel\BGC数据处理\BGC数据\BGC最终数据")
DNA_PATH = ROOT / "final_equal_BGC_nonBGC_dna.fasta"
PROTEIN_PATH = ROOT / "final_equal_BGC_nonBGC_protein.fasta"
LABEL_PATH = ROOT / "final_equal_BGC_nonBGC_id_type_subtype.csv"
REPORT_PATH = Path(__file__).with_name("bgc_data_quality_report.json")

DNA_ALLOWED = set("ACGTUNRYKMSWBDHV-")
PROTEIN_ALLOWED = set("ABCDEFGHIKLMNPQRSTVWXYZJUO*-")

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L","TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*","TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L","CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q","CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M","ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K","AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V","GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E","GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}


def percentile(values: list[int], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[lower])
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def length_summary(lengths: list[int]) -> dict[str, float | int | None]:
    return {
        "min": min(lengths) if lengths else None,
        "median": statistics.median(lengths) if lengths else None,
        "p95": percentile(lengths, 0.95),
        "max": max(lengths) if lengths else None,
    }


def read_fasta(path: Path, allowed: set[str]) -> tuple[dict[str, str], dict]:
    records: dict[str, str] = {}
    duplicate_ids: list[str] = []
    empty_ids: list[str] = []
    illegal_examples: list[dict[str, object]] = []
    header = None
    chunks: list[str] = []

    def commit() -> None:
        nonlocal header, chunks
        if header is None:
            return
        sequence = "".join(chunks).replace(" ", "").upper()
        seq_id = header.split()[0]
        if seq_id in records:
            duplicate_ids.append(seq_id)
            return
        records[seq_id] = sequence
        if not sequence:
            empty_ids.append(seq_id)
        illegal = sorted(set(sequence) - allowed)
        if illegal and len(illegal_examples) < 20:
            illegal_examples.append({"id": seq_id, "characters": illegal})

    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith(">"):
                commit()
                header = line[1:].strip()
                chunks = []
            else:
                if header is None:
                    raise ValueError(f"Sequence data before first FASTA header in {path}")
                chunks.append(line)
        commit()

    lengths = [len(seq) for seq in records.values()]
    hash_to_ids: dict[str, list[str]] = defaultdict(list)
    for seq_id, sequence in records.items():
        digest = hashlib.sha256(sequence.encode("ascii", errors="replace")).hexdigest()
        hash_to_ids[digest].append(seq_id)
    duplicate_groups = [ids for ids in hash_to_ids.values() if len(ids) > 1]

    stats = {
        "path": str(path),
        "record_count": len(records),
        "duplicate_id_count": len(duplicate_ids),
        "duplicate_id_examples": duplicate_ids[:20],
        "empty_sequence_count": len(empty_ids),
        "empty_sequence_examples": empty_ids[:20],
        "illegal_sequence_count": len(illegal_examples),
        "illegal_examples": illegal_examples,
        "length": length_summary(lengths),
        "exact_duplicate_sequence_group_count": len(duplicate_groups),
        "records_in_exact_duplicate_groups": sum(len(ids) for ids in duplicate_groups),
        "largest_exact_duplicate_group": max((len(ids) for ids in duplicate_groups), default=1),
        "duplicate_group_examples": duplicate_groups[:10],
    }
    return records, stats


def translate(sequence: str) -> str:
    sequence = sequence.upper().replace("U", "T").replace("-", "")
    return "".join(CODON_TABLE.get(sequence[i:i+3], "X") for i in range(0, len(sequence) - 2, 3))


def translation_identity(dna: str, protein: str) -> tuple[float, int, int]:
    predicted = translate(dna).rstrip("*")
    observed = protein.upper().replace("-", "").rstrip("*")
    comparable = min(len(predicted), len(observed))
    if comparable == 0:
        return 0.0, len(predicted), len(observed)
    matches = 0
    for index in range(comparable):
        a = predicted[index]
        b = observed[index]
        if index == 0 and b == "M" and a in {"M", "V", "L", "I"}:
            matches += 1
        elif a == b or a == "X" or b == "X":
            matches += 1
    denominator = max(len(predicted), len(observed))
    return matches / denominator if denominator else 0.0, len(predicted), len(observed)


def main() -> None:
    with LABEL_PATH.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = []
        for row_number, raw in enumerate(reader, start=2):
            row = {str(key).strip().lower(): (value or "").strip() for key, value in raw.items()}
            row["_row_number"] = row_number
            rows.append(row)
        columns = [str(name).strip().lower() for name in (reader.fieldnames or [])]

    required = {"id", "type", "subtype", "source"}
    if not required.issubset(columns):
        raise ValueError(f"Missing required CSV columns: {sorted(required - set(columns))}")

    id_to_rows: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        id_to_rows[row["id"]].append(row)
    duplicate_csv_ids = {seq_id: values for seq_id, values in id_to_rows.items() if len(values) > 1}
    conflicting_csv_ids = {
        seq_id: values
        for seq_id, values in duplicate_csv_ids.items()
        if len({(v["type"], v["subtype"], v["source"]) for v in values}) > 1
    }

    labels = {
        seq_id: (values[0]["type"], values[0]["subtype"], values[0]["source"])
        for seq_id, values in id_to_rows.items()
    }
    missing_by_column = {
        column: sum(not row[column] for row in rows)
        for column in ("id", "type", "subtype", "source")
    }
    type_counts = Counter(row["type"] for row in rows)
    subtype_counts = Counter(row["subtype"] for row in rows)
    source_counts = Counter(row["source"] for row in rows)
    source_type_counts = Counter((row["source"], row["type"]) for row in rows)
    source_subtype_counts = Counter((row["source"], row["subtype"]) for row in rows)
    subtype_to_types: dict[str, set[str]] = defaultdict(set)
    type_to_subtypes: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        subtype_to_types[row["subtype"]].add(row["type"])
        type_to_subtypes[row["type"]].add(row["subtype"])
    cross_type_subtypes = {
        subtype: sorted(types)
        for subtype, types in subtype_to_types.items()
        if len(types) > 1
    }

    dna, dna_stats = read_fasta(DNA_PATH, DNA_ALLOWED)
    protein, protein_stats = read_fasta(PROTEIN_PATH, PROTEIN_ALLOWED)
    csv_ids = set(labels)
    dna_ids = set(dna)
    protein_ids = set(protein)
    common_ids = csv_ids & dna_ids & protein_ids

    translation_bins = Counter()
    dna_mod3 = Counter()
    length_ratio_outliers = []
    identities = []
    for seq_id in common_ids:
        dna_mod3[len(dna[seq_id]) % 3] += 1
        identity, translated_len, protein_len = translation_identity(dna[seq_id], protein[seq_id])
        identities.append(identity)
        if identity >= 0.99:
            translation_bins[">=0.99"] += 1
        elif identity >= 0.95:
            translation_bins["0.95-0.99"] += 1
        elif identity >= 0.80:
            translation_bins["0.80-0.95"] += 1
        else:
            translation_bins["<0.80"] += 1
        if identity < 0.80 and len(length_ratio_outliers) < 25:
            length_ratio_outliers.append({
                "id": seq_id,
                "identity": round(identity, 6),
                "dna_nt": len(dna[seq_id]),
                "translated_aa": translated_len,
                "protein_aa": protein_len,
                "label": labels[seq_id],
            })

    dna_hash_labels: dict[str, dict[str, object]] = {}
    protein_hash_labels: dict[str, dict[str, object]] = {}
    for seq_id in common_ids:
        label = labels[seq_id]
        for sequence, target in ((dna[seq_id], dna_hash_labels), (protein[seq_id], protein_hash_labels)):
            digest = hashlib.sha256(sequence.encode("ascii", errors="replace")).hexdigest()
            entry = target.setdefault(digest, {"ids": [], "labels": set()})
            entry["ids"].append(seq_id)
            entry["labels"].add(label)

    def conflict_summary(groups: dict[str, dict[str, object]]) -> dict:
        conflicts = [entry for entry in groups.values() if len(entry["labels"]) > 1]
        return {
            "conflicting_duplicate_group_count": len(conflicts),
            "records_in_conflicting_groups": sum(len(entry["ids"]) for entry in conflicts),
            "examples": [
                {"ids": entry["ids"][:20], "labels": sorted(entry["labels"])}
                for entry in conflicts[:10]
            ],
        }

    report = {
        "intended_grain": "one label row per paired DNA/protein sequence ID",
        "csv": {
            "path": str(LABEL_PATH),
            "columns": columns,
            "row_count": len(rows),
            "unique_id_count": len(id_to_rows),
            "missing_by_column": missing_by_column,
            "duplicate_id_count": len(duplicate_csv_ids),
            "conflicting_duplicate_id_count": len(conflicting_csv_ids),
            "duplicate_id_examples": list(duplicate_csv_ids)[:20],
            "conflicting_duplicate_examples": {
                key: value for key, value in list(conflicting_csv_ids.items())[:10]
            },
            "source_counts": dict(source_counts.most_common()),
            "type_count": len(type_counts),
            "type_counts": dict(type_counts.most_common()),
            "subtype_count": len(subtype_counts),
            "subtype_counts": dict(subtype_counts.most_common()),
            "singletons": sorted([name for name, count in subtype_counts.items() if count == 1]),
            "subtypes_with_fewer_than_5": sorted([name for name, count in subtype_counts.items() if count < 5]),
            "subtype_to_multiple_types_count": len(cross_type_subtypes),
            "subtype_to_multiple_types": cross_type_subtypes,
            "type_to_subtype_count": {key: len(value) for key, value in sorted(type_to_subtypes.items())},
            "type_to_subtypes": {key: sorted(value) for key, value in sorted(type_to_subtypes.items())},
            "source_type_counts": {f"{a} | {b}": n for (a, b), n in source_type_counts.most_common()},
            "source_subtype_counts_top100": {f"{a} | {b}": n for (a, b), n in source_subtype_counts.most_common(100)},
        },
        "dna": dna_stats,
        "protein": protein_stats,
        "id_integrity": {
            "common_all_three": len(common_ids),
            "csv_not_dna": sorted(csv_ids - dna_ids)[:100],
            "csv_not_protein": sorted(csv_ids - protein_ids)[:100],
            "dna_not_csv": sorted(dna_ids - csv_ids)[:100],
            "protein_not_csv": sorted(protein_ids - csv_ids)[:100],
            "dna_not_protein": sorted(dna_ids - protein_ids)[:100],
            "protein_not_dna": sorted(protein_ids - dna_ids)[:100],
            "set_equality": csv_ids == dna_ids == protein_ids,
        },
        "paired_sequence_consistency": {
            "dna_length_modulo_3": dict(sorted(dna_mod3.items())),
            "translation_identity_bins": dict(translation_bins),
            "translation_identity_median": statistics.median(identities) if identities else None,
            "translation_identity_p05": percentile([round(value * 1_000_000) for value in identities], 0.05) / 1_000_000 if identities else None,
            "translation_outlier_examples": length_ratio_outliers,
            "dna_exact_duplicates_with_conflicting_labels": conflict_summary(dna_hash_labels),
            "protein_exact_duplicates_with_conflicting_labels": conflict_summary(protein_hash_labels),
        },
    }

    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "csv_rows": report["csv"]["row_count"],
        "unique_ids": report["csv"]["unique_id_count"],
        "types": report["csv"]["type_count"],
        "subtypes": report["csv"]["subtype_count"],
        "sources": report["csv"]["source_counts"],
        "subtype_to_multiple_types": report["csv"]["subtype_to_multiple_types_count"],
        "singletons": len(report["csv"]["singletons"]),
        "subtypes_lt5": len(report["csv"]["subtypes_with_fewer_than_5"]),
        "ids_equal": report["id_integrity"]["set_equality"],
        "translation_bins": report["paired_sequence_consistency"]["translation_identity_bins"],
        "report": str(REPORT_PATH),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
