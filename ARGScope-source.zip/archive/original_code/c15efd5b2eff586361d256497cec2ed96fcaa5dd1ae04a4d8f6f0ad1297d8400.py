"""Reproducible, narrowly scoped edits of the five supplied reference scripts."""
import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def replace_function(text, name, replacement):
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = text.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = [replacement.rstrip() + '\n']
    return ''.join(lines)

for source in sorted((ROOT / 'reference').glob('*.py')):
    text = source.read_text(encoding='utf-8-sig')
    text = text.replace('Long_fusion', 'Long_fusion_subtype2_newsplit').replace('long_fusion.pt', 'long_fusion_subtype2_newsplit.pt')
    text = text.replace('Raw_subtype_prototypes_long', 'Raw_subtype_prototypes_subtype2_newsplit')
    text = text.replace('Refined_subtype_prototypes_long', 'Refined_subtype_prototypes_subtype2_newsplit')
    text = text.replace('3.Protein_student_subtype2_newsplit', 'Protein_student_subtype2_newsplit_unified')
    text = text.replace('from __future__ import annotations', 'from __future__ import annotations\n\nimport newsplit_contract as contract')
    # Print all CLI paths/settings without introducing Python-side log redirection.
    text = re.sub(r'(    args = parse_args\(\)\n)', r'\1    print("Resolved arguments:", vars(args), flush=True)\n', text)
    if source.name.startswith('01'):
        text = text.replace('"train_ids.txt"', '"train_ids_subtype2.txt"').replace('"test_ids.txt"', '"test_ids_subtype2.txt"').replace('default=0.15,', 'default=0.20,')
        text = replace_function(text, 'align_inputs', '''def align_inputs(args, structure_path):
    protein_ids, protein_all = load_embedding_pt(args.protein_pt, expected_dim=1280)
    dna_ids, dna_all = load_embedding_pt(args.dna_pt, expected_dim=768)
    train = contract.read_ids(args.train_ids)
    test = contract.read_ids(args.test_ids)
    requested = train | test
    if train & test:
        raise ValueError('Authoritative train/test overlap')
    for name, source_ids in [('Protein', protein_ids), ('DNA', dna_ids)]:
        if len(source_ids) != len(set(source_ids)) or requested - set(source_ids):
            raise ValueError(f'{name}: duplicate IDs or missing authoritative IDs')
    ids = [x for x in protein_ids if x in requested]
    pindex = {x:i for i,x in enumerate(protein_ids)}
    dindex = {x:i for i,x in enumerate(dna_ids)}
    protein = protein_all[[pindex[x] for x in ids]].contiguous()
    dna = dna_all[[dindex[x] for x in ids]].contiguous()
    labels = read_labels(structure_path)
    # Preserve supplied ARG-only structure convention: unlisted IDs are nonARG.
    subtypes = [labels.get(x, NONARG) for x in ids]
    mapping = contract.type_mapping(structure_path, subtypes)
    print(f'Selected IDs: {len(ids)}; external train={len(train)}, test={len(test)}; ARG subtype count={len(mapping)}; Type count={len(set(mapping.values()))}', flush=True)
    print(f'IDs absent from structure, treated as nonARG: {sum(x not in labels for x in ids)}', flush=True)
    return ids, subtypes, ['train' if x in train else 'test' for x in ids], protein, dna
''')
        text = replace_function(text, 'derive_validation', '''def derive_validation(ids, subtypes, external_splits, validation_fraction, seed):
    train = {x for x,s in zip(ids, external_splits) if s == 'train'}
    test = {x for x,s in zip(ids, external_splits) if s == 'test'}
    model, _ = contract.build_model_splits_from_new_ids(ids, subtypes, train, test, validation_fraction, seed)
    print('Exact model split counts:', dict(Counter(model)), flush=True)
    return model
''')
        # Preserve the per-sequence means and additionally export full vector gates.
        text = text.replace('fused_embeddings, protein_gate_mean = (', 'fused_embeddings, protein_gate_mean, protein_gate_weights = (')
        start = text.index('def generate_fused(')
        end = text.index('\ndef main(', start)
        chunk = text[start:end]
        chunk = chunk.replace('    total_batches =', '    full_gate_cpu = torch.empty((number, fusion_dim), dtype=torch.float32)\n\n    total_batches =', 1)
        chunk = chunk.replace('        fused_cpu[', '        full_gate_cpu[start:end] = gate.float().cpu()\n\n        fused_cpu[', 1)
        chunk = chunk.replace('        gate_cpu\n        .contiguous(),', '        gate_cpu\n        .contiguous(),\n        full_gate_cpu.contiguous(),')
        text = text[:start] + chunk + text[end:]
        needle = '        safe_save(\n            output,'
        text = text.replace(needle, '''        output['gate_weights_protein'] = protein_gate_weights
        output['gate_weights_DNA'] = 1.0 - protein_gate_weights
        contract.stamp_fusion(output, structure_path, args.train_ids, args.test_ids, args.output)

''' + needle)
        text = re.sub(r'Rare subtype handling:.*?Performance\n', 'Rare subtype handling: retain at least one model-train ARG per subtype;\nvalidation fraction 0.20 with matched nonARG validation.\n\nPerformance\n', text, flags=re.S)
    elif source.name.startswith('02'):
        # Validate at the loader entry, before prototype computation.
        needle = re.search(r'    obj = torch_load_cpu\(\s*path\s*\)', text)
        assert needle
        text = text[:needle.end()] + '\n    contract.validate_fusion(obj)\n' + text[needle.end():]
        text = text.replace('        safe_save(\n            output,', "        contract.stamp_derived(output, input_obj, args.input_pt, 'raw')\n\n        safe_save(\n            output,")
    elif source.name.startswith('03'):
        needle = re.search(r'    fused = torch_load_cpu\(\s*fused_path\s*\)', text)
        assert needle
        text = text[:needle.end()] + "\n    contract.validate_derived(raw, fused, fused_path, 'raw')\n" + text[needle.end():]
        text = text.replace('        safe_save(\n            output,', "        contract.stamp_derived(output, torch_load_cpu(args.fused_pt), args.fused_pt, 'refined')\n        output['source_raw_sha256'] = contract.sha256(args.raw_pt)\n\n        safe_save(\n            output,")
    else:
        # Permit full embedding PTs to contain excluded rows; fusion must be exact.
        if source.name.startswith('04'):
            text, count = re.subn(r'if set\(\s*protein_ids\s*\) != set\(\s*fusion_ids\s*\):', 'if not set(fusion_ids).issubset(set(protein_ids)):', text)
        else:
            text, count = re.subn(r'if set\(dna_ids\) != set\(fusion_ids\):', 'if not set(fusion_ids).issubset(set(dna_ids)):', text)
            text = text.replace('4.DNA_student_subtype2_newsplit', 'DNA_student_subtype2_newsplit_unified')
        assert count == 1
        # Require an exact fusion universe BEFORE the legacy subset block.
        text = text.replace('    available_ids = set(fusion_ids)', "    contract.validate_fusion(fusion_obj, train_ids_path, test_ids_path)\n    available_ids = set(fusion_ids)")
        text = text.replace('model_splits, external_splits = build_model_splits_from_new_ids(', 'model_splits, external_splits = contract.use_saved_splits(\n        obj=fusion_obj,')
        needle = re.search(r'    refined_obj = load_pt\(\s*refined_path\s*\)', text)
        assert needle
        text = text[:needle.end()] + "\n    contract.validate_derived(refined_obj, fusion_obj, fusion_path, 'refined')\n" + text[needle.end():]
        text = text.replace('old split/model_splits metadata', 'validated exact split/model_splits metadata')
        text = text.replace('is ignored.', 'is consumed from the new fusion artifact.')
        text = text.replace('Ignore any old split/model_splits metadata stored inside', 'Consume validated exact split/model_splits metadata stored inside')
        text = text.replace('from the ORIGINAL dataset', 'from the unified new-split pipeline')
    # Enforce the same authoritative Type mapping at all downstream consumers.
    if source.name.startswith(('04', '05')):
        needle = re.search(r'    subtype_to_type = load_subtype_to_type\(\s*structure_path\s*\)', text)
        assert needle
        text = text[:needle.end()] + "\n    if any(subtype_to_type.get(s) != t for s, t in fusion_obj['subtype_to_type'].items()):\n        raise ValueError('Student structure Type mapping differs from fusion')\n" + text[needle.end():]
    if source.name.startswith('03'):
        text = text.replace('        type_to_index = {', "        if contract.type_mapping(args.structure, subtype_names) != data['fusion_type_mapping']:\n            raise ValueError('GAT structure Type mapping differs from fusion')\n\n        type_to_index = {", 1)
        # Extend the loader result only, leaving graph/model/training code intact.
        start = text.index('def load_inputs(')
        end = text.index('def select_arg_split(', start)
        chunk = text[start:end].replace('    return {', "    return {\n        'fusion_type_mapping': fused['subtype_to_type'],", 1)
        text = text[:start] + chunk + text[end:]
    text = text.replace('    args = parse_args()\n', '    args = parse_args()\n    print("Device:", "cuda" if torch.cuda.is_available() else "CPU (CUDA required)", flush=True)\n', 1)
    text = text.replace('Based on the Protein GRID-best training pipeline. The selected FusionTeacher\nis loaded from best_fusion_teacher.pt;', 'Based on the Protein GRID-best training pipeline. A new FusionTeacher\nis trained on the saved exact model-train split;')
    # Keep historical version traceable, but identify the new implementation.
    marker = 'def parse_args():'
    text = text.replace(marker, 'SCRIPT_VERSION = SCRIPT_VERSION + "-unified-newsplit-v1"\n\n\n' + marker, 1)
    ast.parse(text)
    (ROOT / source.name).write_text(text, encoding='utf-8', newline='\n')
    print('Generated', source.name)
