"""Draw new, editable ARGScope method diagrams from the current manuscript.

No source image is edited and no experimental data are generated.
"""
from pathlib import Path
from html import escape
import hashlib
import json
import math
import xml.etree.ElementTree as ET
from PIL import ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs' / 'argscope_method_diagrams_20260926'
SOURCE = Path('C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/1. ARGScope_manuscript_923.docx')
BLACK = '#111111'
GREY = '#65717c'
LINE = '#44515c'
LIGHT = '#dce2e7'
AA = '#377fac'
AA_BG = '#edf5fb'
NT = '#258c83'
NT_BG = '#eaf7f3'
VIOLET = '#8171aa'
VIOLET_BG = '#f3eff8'
GOLD = '#b98538'
GOLD_BG = '#fff6e8'


class Drawing:
    def __init__(self, width, height, mmw, mmh, title, desc):
        self.width, self.height = width, height
        self.mmw, self.mmh = mmw, mmh
        self.parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{mmw}mm" height="{mmh}mm" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">',
                      f'<title id="title">{escape(title)}</title>',
                      f'<desc id="desc">{escape(desc)}</desc>',
                      '<defs>']
        for name, color in [('dark', LINE), ('aa', AA), ('nt', NT), ('violet', VIOLET), ('gold', GOLD)]:
            self.parts.append(f'<marker id="{name}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" orient="auto-start-reverse" markerUnits="userSpaceOnUse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{color}"/></marker>')
        self.parts.extend(['</defs>', '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#111111}path,line,polyline{stroke-linejoin:round;stroke-linecap:round}</style>'])
        self.audit = []

    def rect(self, x, y, w, h, fill='white', stroke=LIGHT, radius=14, sw=1.7, dash=False):
        d = ' stroke-dasharray="8 7"' if dash else ''
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{d}/>')

    def text(self, x, y, value, size=24, bold=False, anchor='start', maxw=None, fill=BLACK):
        font = ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf', int(size))
        width = font.getlength(value)
        self.audit.append({'text': value, 'font_size': size, 'width': round(width, 2), 'available_width': maxw})
        if maxw is not None and width > maxw:
            print(f'TEXT_OVERFLOW {width:.1f}>{maxw}: {value}')
        left = x - (width/2 if anchor == 'middle' else width if anchor == 'end' else 0)
        if left < -1 or left+width > self.width+1 or y-size < -1 or y+size*.3 > self.height+1:
            raise ValueError(f'Out-of-canvas text: {value}')
        self.parts.append(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{700 if bold else 400}" text-anchor="{anchor}" style="fill:{fill}">{escape(value)}</text>')

    def lines(self, x, y, values, size=23, gap=31, bold=False, anchor='start', maxw=None):
        for j, value in enumerate(values):
            self.text(x, y+j*gap, value, size, bold, anchor, maxw)

    def box(self, x, y, w, h, title, body=(), color=LINE, fill='white', title_size=25, body_size=22, gap=29, align='center'):
        self.rect(x, y, w, h, fill, color, sw=1.8)
        ax, anchor = (x+w/2, 'middle') if align == 'center' else (x+22, 'start')
        self.text(ax, y+36, title, title_size, True, anchor, w-36)
        self.lines(ax, y+71, body, body_size, gap, False, anchor, w-36)

    def path(self, points, color=LINE, dash=False, arrow=True, width=2.6, halo=False):
        d = 'M ' + ' L '.join(f'{x} {y}' for x,y in points)
        if halo:
            self.parts.append(f'<path d="{d}" fill="none" stroke="white" stroke-width="{width+6}"/>')
        marker = {LINE:'dark', AA:'aa', NT:'nt', VIOLET:'violet', GOLD:'gold'}.get(color, 'dark')
        extra = f' marker-end="url(#{marker})"' if arrow else ''
        ds = ' stroke-dasharray="9 7"' if dash else ''
        self.parts.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{ds}{extra}/>')

    def dot(self, x, y, color=LINE, r=4):
        self.parts.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}"/>')

    def tag(self, x, y, w, text, color=VIOLET, fill=VIOLET_BG, size=20):
        self.rect(x, y, w, 36, fill, color, 18, 1.1)
        self.text(x+w/2, y+25, text, size, True, 'middle', w-18)

    def network(self, x, y, scale=1, color=VIOLET):
        pts = [(0,26), (30,0), (64,13), (72,50), (34,67), (32,30)]
        edges = [(0,1),(0,4),(0,5),(1,2),(1,5),(2,3),(2,5),(3,4),(3,5),(4,5)]
        for a,b in edges:
            self.path([(x+pts[a][0]*scale, y+pts[a][1]*scale),(x+pts[b][0]*scale,y+pts[b][1]*scale)], color, arrow=False, width=1.7)
        for px,py in pts:
            self.parts.append(f'<circle cx="{x+px*scale}" cy="{y+py*scale}" r="{6.5*scale}" fill="white" stroke="{color}" stroke-width="2"/>')

    def legend(self, x, y, compact=False):
        self.path([(x,y-7),(x+48,y-7)])
        self.text(x+60,y,'Forward flow',20)
        x2 = x+(245 if compact else 260)
        self.path([(x2,y-7),(x2+48,y-7)],VIOLET,True)
        self.text(x2+60,y,'Supervision / parameter targets',20)

    def save(self, name):
        OUT.mkdir(parents=True, exist_ok=True)
        svg = '\n'.join(self.parts+['</svg>'])
        ET.fromstring(svg)
        (OUT/f'{name}.svg').write_text(svg, encoding='utf-8')
        overflows=[r for r in self.audit if r['available_width'] is not None and r['width']>r['available_width']]
        return {'name':name,'view_box':[self.width,self.height],'physical_size_mm':[self.mmw,self.mmh],
                'min_font_size':min(row['font_size'] for row in self.audit),'text_elements':len(self.audit),'text_overflows':len(overflows)}


def overview():
    d=Drawing(1800,1273,297,210,'ARGScope framework overview',
              'Multimodal training uses paired ARG and non-ARG sequences, gated fusion, subtype prototypes, a graph-refined teacher and single-modality students. At inference either protein or nucleotide input is used, with separate binary and subtype heads and a fixed subtype-to-type mapping.')
    d.text(40,57,'ARGScope',40,True)
    d.text(278,56,'Multimodal training and single-modality annotation',29)
    d.legend(1080,94)
    d.rect(35,125,1730,735,'#fcfdff',LIGHT,20)
    d.text(62,165,'TRAINING',27,True)
    d.text(244,165,'Paired inputs; supervised teacher–student learning',24)

    # Real modality-specific inputs bypass fusion on their way to the students.
    d.box(65,267,210,260,'Paired inputs',(),LINE,'white',24)
    d.text(170,341,'ARG + non-ARG',22,False,'middle',185)
    d.rect(87,369,166,53,AA_BG,AA,9)
    d.text(170,403,'Protein',23,True,'middle')
    d.rect(87,445,166,53,NT_BG,NT,9)
    d.text(170,479,'Nucleotide',23,True,'middle')
    d.path([(275,395),(306,395),(306,314),(340,314)],AA)
    d.path([(275,472),(340,472)],NT)
    d.box(340,265,245,98,'ESM-2',['Protein vector · 1280-D'],AA,AA_BG,26,20)
    d.box(340,423,245,98,'DNABERT-2',['768-D DNA features'],NT,NT_BG,26,21)

    d.path([(585,314),(627,314),(627,217),(1620,217),(1620,265)],AA)
    d.text(965,205,'Protein features → training-fitted standardization',21,False,'middle')
    d.path([(585,472),(627,472),(627,576),(1620,576),(1620,521)],NT)
    d.text(1490,560,'Standardized DNA input',20,False,'middle')
    d.dot(604,314,AA); d.path([(585,314),(646,314),(646,360),(684,360)],AA)
    d.dot(604,472,NT); d.path([(585,472),(646,472),(646,429),(684,429)],NT)
    d.box(684,320,244,160,'Adaptive fusion',['Project each to 512-D','Sample-wise and','feature-wise gating'],GOLD,GOLD_BG,26,21,27)
    d.path([(928,397),(1060,397)])
    d.text(994,373,'Fused',20,False,'middle')
    d.text(1012,425,'512-D',20,False,'middle')
    d.box(1060,320,275,160,'Fusion teacher',['Binary + subtype','cosine classifiers','Fixed during student fit'],VIOLET,VIOLET_BG,27,22,29)
    d.box(1505,265,230,98,'ARGScope-AA',['Protein student'],AA,AA_BG,26,23)
    d.box(1505,423,230,98,'ARGScope-NT',['Nucleotide student'],NT,NT_BG,26,23)
    d.path([(1335,365),(1412,365),(1412,313),(1505,313)],VIOLET,True)
    d.path([(1335,432),(1412,432),(1412,472),(1505,472)],VIOLET,True)
    d.lines(1418,389,['Training','targets'],19,24,False,'middle')

    # Prototype means are built from fused training ARG representations.
    d.path([(973,397),(973,622),(824,622),(824,663)])
    d.dot(973,397)
    d.text(899,648,'ARG only',20,False,'middle')
    d.box(685,663,279,125,'Subtype prototypes',['Fused class means','L2 normalization'],VIOLET,VIOLET_BG,25,22,29)
    d.path([(964,724),(1001,724)],VIOLET)
    d.box(1001,663,285,125,'Subtype graph',['Mutual kNN','Residual multi-head GAT'],VIOLET,VIOLET_BG,25,21,29)
    d.path([(1286,724),(1323,724)],VIOLET)
    d.box(1323,663,390,125,'Refined prototypes',['Initialize and anchor','teacher subtype classifiers'],VIOLET,VIOLET_BG,26,23,29)
    d.path([(1519,663),(1519,633),(1370,633),(1370,537),(1200,537),(1200,480)],VIOLET,True,halo=True)
    d.text(1390,514,'Subtype-head targets',19,False,'middle')
    d.box(65,656,500,131,'Label supervision',['Binary labels: all training sequences','Subtype labels: ARG training sequences'],GOLD,GOLD_BG,26,22,30)
    d.text(72,831,'Student objectives: supervised labels + prediction distillation + feature/prototype alignment + head anchoring.',21,maxw=1680)

    # Single modality inference; the alternatives are never fused at deployment.
    d.rect(35,898,1730,333,'#ffffff',LIGHT,20)
    d.text(62,940,'INFERENCE',27,True)
    d.text(258,940,'Choose one modality; no fusion teacher or subtype graph',24)
    yy=[985,1100]
    for y,label,enc,student,color,bg in [(yy[0],'Protein only','ESM-2','ARGScope-AA',AA,AA_BG),(yy[1],'DNA only','DNABERT-2','ARGScope-NT',NT,NT_BG)]:
        d.rect(65,y,190,67,bg,color,12)
        d.text(160,y+42,label,24,True,'middle',174)
        d.path([(255,y+33),(287,y+33)],color)
        d.rect(287,y,210,67,bg,color,12)
        d.text(392,y+42,enc,25,True,'middle',190)
        d.path([(497,y+33),(534,y+33)],color)
        d.rect(534,y,215,67,'white',color,12)
        d.text(641,y+41,'Standardization',22,False,'middle',202)
        d.path([(749,y+33),(786,y+33)],color)
        d.rect(786,y,245,67,bg,color,12)
        d.text(908,y+42,student,26,True,'middle',225)
        d.path([(1031,y+33),(1070,y+33),(1070,1074)],color,arrow=False)
    d.rect(1047,1052,68,45,'white',LIGHT,22)
    d.text(1081,1083,'OR',23,True,'middle')
    d.path([(1115,1075),(1150,1075)],LINE,arrow=False)
    d.path([(1150,1075),(1150,1018),(1181,1018)])
    d.path([(1150,1075),(1150,1133),(1181,1133)])
    d.rect(1181,985,240,67,GOLD_BG,GOLD,12)
    d.text(1301,1011,'Binary head',23,True,'middle')
    d.text(1301,1038,'ARG / non-ARG',21,False,'middle')
    d.rect(1181,1100,240,67,VIOLET_BG,VIOLET,12)
    d.text(1301,1142,'Subtype head',24,True,'middle')
    d.path([(1421,1133),(1480,1133)])
    d.rect(1480,1090,253,87,'#f0f5f0','#709674',12)
    d.text(1606,1125,'Resistance type',24,True,'middle')
    d.text(1606,1155,'Fixed subtype mapping',20,False,'middle')
    d.lines(1605,1008,['Report subtype/type','for predicted ARGs only'],20,29,False,'middle',262)
    d.text(62,1206,'Each student has separate binary and subtype heads; the non-ARG outcome is retained.',21,maxw=1690)
    d.text(42,1261,'Teacher architecture is shared; AA and NT teacher configurations are selected separately.',20,maxw=1690)
    return d.save('ARGScope_overview')


def teacher(d, x, y, w, branch):
    d.rect(x,y,w,285,VIOLET_BG,VIOLET,15)
    d.text(x+24,y+37,f'{branch} branch fusion teacher',28,True,maxw=w-45)
    d.text(x+24,y+78,'Input: normalized fused features (512-D)',24,maxw=w-45)
    d.lines(x+24,y+119,['Binary head ← ARG and non-ARG centers',
                        'Subtype head ← refined ARG prototypes'],23,32,maxw=w-45)
    d.text(x+24,y+190,'Binary CE (all) + weighted subtype CE (ARGs)',23,True,maxw=w-45)
    d.text(x+24,y+224,'+ anchoring to refined prototypes',24,maxw=w-45)
    d.tag(x+22,y+240,w-44,'Fixed after validation-based selection',VIOLET,'white',22)


def student_branch(d, x, y, branch, color, bg, nt=False):
    w=735
    d.rect(x,y,w,1224,'#fcfdfd',color,19,2)
    d.rect(x,y,w,69,bg,color,19,2)
    d.text(x+27,y+45,f'ARGScope-{branch}  |  {"Nucleotide" if nt else "Protein"} student',30,True,maxw=w-54)
    ty=y+93
    teacher(d,x+28,ty,w-56,branch)
    d.text(x+118,ty+323,'Single-modality student input',25,True,maxw=w-160)

    # Student path uses exactly the raw modality embedding specified in Methods 2.6.
    iy=ty+347
    ix=x+118
    iw=520
    d.box(ix,iy,iw,110,'DNABERT-2 features · 768-D' if nt else 'ESM-2 features · 1280-D',
          ['Training-fitted feature standardization'],color,bg,26,23)
    d.path([(ix+iw/2,iy+110),(ix+iw/2,iy+143)],color)
    my=iy+143
    d.box(ix,my,iw,188,'Residual MLP',
          ['768 → 1024' if nt else '1280 → 1536 → 1024',
           '2 × 1024-dimensional residual blocks',
           'LayerNorm · GELU · dropout',
           '512-D projection + L2 normalization'],color,bg,29,23,30)
    d.path([(ix+iw/2,my+188),(ix+iw/2,my+219)],color)
    hy=my+219
    d.rect(ix,hy,iw,112,'white',color,13)
    d.text(ix+iw/2,hy+34,'Two cosine classification heads',25,True,'middle',iw-28)
    d.rect(ix+16,hy+51,224,44,GOLD_BG,GOLD,8)
    d.text(ix+128,hy+81,'Binary',24,True,'middle')
    d.rect(ix+279,hy+51,224,44,VIOLET_BG,VIOLET,8)
    d.text(ix+391,hy+81,'Subtype',24,True,'middle')
    # Fixed teacher initializes the heads, rather than supplying student inputs.
    d.path([(x+63,ty+285),(x+63,hy+55),(ix,hy+55)],VIOLET,True)
    d.text(ix+4,hy-10,'Teacher head initialization',20,maxw=iw-30)
    ly=hy+137
    d.path([(ix+iw/2,hy+112),(ix+iw/2,ly)],color)
    d.rect(x+28,ly,w-56,239,GOLD_BG,GOLD,14)
    d.text(x+49,ly+37,'Supervised classification',27,True,maxw=w-98)
    d.text(x+49,ly+70,'Binary CE: all samples; subtype CE: ARGs',23,maxw=w-98)
    d.text(x+49,ly+100,'Label smoothing; no subtype class reweighting',22,maxw=w-98)
    d.path([(x+49,ly+119),(x+w-49,ly+119)],GOLD,arrow=False,width=1.1)
    d.text(x+49,ly+154,'Prediction distillation',27,True,maxw=w-98)
    d.text(x+49,ly+191,'Subtype KD: ARG samples only',24,maxw=w-98)
    d.text(x+49,ly+225,'Binary KD: all samples' if nt else 'Binary KD: OFF (selected weight = 0)',24,True,maxw=w-98)
    # Another routed dashed line carries teacher prediction targets to loss.
    d.path([(x+w-33,ty+179),(x+w-14,ty+179),(x+w-14,ly+206),(x+w-28,ly+206)],VIOLET,True)
    d.text(x+w/2,y+1206,'+ the three alignment objectives below',24,True,'middle',w-40)


def detailed():
    d=Drawing(1600,2263,210,297,'ARGScope-AA and ARGScope-NT detailed training',
              'The two branches use shared fusion and graph preparation procedures but separately trained and selected teachers. Protein and nucleotide students have different MLP architectures. Protein training uses subtype distillation only; nucleotide training uses binary and subtype distillation. Both use supervised classification, feature alignment, prototype alignment and classifier-head anchoring.')
    d.text(40,62,'ARGScope-AA and ARGScope-NT',42,True)
    d.text(42,104,'Detailed teacher–student training',29)
    d.legend(840,104,True)
    d.rect(40,139,1520,379,'#fcfdff',LIGHT,18)
    d.text(65,181,'1  Shared fusion and prototype preparation',30,True)
    d.box(65,210,350,171,'Paired training sequences',
          ['ARG + non-ARG','ESM-2: 1280-D','DNABERT-2: 768-D'],LINE,'white',25,24,31)
    d.path([(415,294),(459,294)])
    d.box(459,210,386,171,'Adaptive gated fusion',
          ['Separate projections → 512-D','Sample- and feature-wise gating','Subtype supervision on ARGs'],GOLD,GOLD_BG,27,22,32)
    d.path([(845,294),(890,294)])
    d.box(890,210,645,171,'Subtype prototype graph',
          ['Fused ARG means → L2-normalized prototypes','Cosine similarity → mutual kNN graph',
           'Residual multi-head GAT → refined prototypes'],VIOLET,VIOLET_BG,28,24,32)
    d.text(65,424,'Graph objective: subtype CE + auxiliary type CE + prototype preservation',25,True,maxw=1450)
    d.text(65,465,'Non-ARG alignment target: a separate center of non-ARG training fusion representations.',24,maxw=1450)
    d.text(65,500,'Prototypes, graph and normalization statistics use the model-training subset only.',22,maxw=1450)

    d.text(43,567,'2  Branch-specific teachers and single-modality students',30,True,maxw=1490)
    student_branch(d,40,591,'AA',AA,AA_BG,False)
    student_branch(d,825,591,'NT',NT,NT_BG,True)
    d.text(41,1870,'3  Additional objectives in both students',30,True,maxw=1490)
    # Explicit source-target pairs are used instead of long crossed arrows.
    cy=1901
    d.box(40,cy,477,201,'Feature alignment',
          ['Student 512-D representation','↕','Normalized fused representation'],VIOLET,VIOLET_BG,29,25,38)
    d.box(561,cy,478,201,'Prototype alignment',
          ['ARG → true-subtype prototype','Non-ARG → separate center',
           'Match student representations'],VIOLET,VIOLET_BG,29,24,37)
    d.box(1083,cy,477,201,'Classifier-head anchoring',
          ['Student binary / subtype weights','↕','Fixed teacher classifier weights'],VIOLET,VIOLET_BG,27,23,38)
    d.text(41,2145,'Cosine-based alignment. CE: cross-entropy. KD: temperature-softened prediction distillation.',23,maxw=1490)
    d.text(41,2183,'Teacher architecture is shared; teacher configurations and student models are selected per branch.',23,maxw=1490)
    d.text(41,2221,'Validation selects configurations. Independent test sequences are excluded from all training stages.',23,maxw=1490)
    return d.save('ARGScope_AA_NT_training')


def main():
    reports=[overview(),detailed()]
    manifest={
        'artifact_state':'Draft figures for author review; no submission approval implied',
        'created':'2026-09-26',
        'evidence_id':'E001',
        'source':str(SOURCE),
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'source_locators':['Methods 2.1–2.7'],
        'source_processing':'Local read-only text inspection; no source modification',
        'method_evidence':{
            'C001':'2.1: paired ARG/non-ARG inputs; separate binary/subtype targets; fixed subtype-to-type mapping',
            'C002':'2.3–2.4: 1280-D protein / 768-D DNA representations; separate 512-D projections; adaptive fusion',
            'C003':'2.4–2.5: normalized training ARG means; mutual kNN by cosine similarity; residual GAT',
            'C004':'2.5: subtype/type supervision and prototype preservation',
            'C005':'2.6.1: branch-specific teachers; initialized cosine heads; classification and prototype anchoring; fixed for student training',
            'C006':'2.6.2: AA MLP 1536→1024; two residual blocks; no binary KD; subtype KD active',
            'C007':'2.6.3: NT MLP 1024; two residual blocks; binary and subtype KD active',
            'C008':'2.6.2–2.6.3: feature/prototype alignment, separate non-ARG center, head anchoring',
            'C009':'2.6.2–2.7: single-modality inference; model-training-only statistics; validation selection'
        },
        'human_verification':'pending author review',
        'authoritative_code_verification':'Not claimed: diagrams describe manuscript methods, not a new code audit',
        'presentation':{'SVG':'Editable text; transparent outer canvas; opaque cards','TIFF':'White background; A4; 300 DPI',
                        'primary_font':'Arial','text_color':'black','color_roles':{'AA':AA,'NT':NT,'teacher_prototypes':VIOLET,'objectives':GOLD}},
        'checks':reports,
        'writing_assistance_reference':'Kassis T, Agarwal V, He Y, Patel D, Brueckner AM. Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents. 2026. https://doi.org/10.48550/arXiv.2609.00065'
    }
    (OUT/'figure_provenance.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    for r in reports:
        print(json.dumps(r))


if __name__=='__main__':
    main()
