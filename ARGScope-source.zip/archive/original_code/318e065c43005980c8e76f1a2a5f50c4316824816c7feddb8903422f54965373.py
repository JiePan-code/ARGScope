#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Protein GRID-best Subtype + Type evaluation for 60%, 70%, 80%, 90%, 100%.

FINAL RULE
==========
The 100% TEST set defines the evaluation class universe.

SUBTYPE:
    only ARG Subtypes truly present in the 100% TEST set
    + nonARG for end-to-end evaluation.

TYPE:
    only ARG Types truly present in the 100% TEST set
    + nonARG for end-to-end evaluation.

Training-only classes absent from the 100% TEST true labels are NOT added
to macro/weighted/micro evaluation classes.

If a 60-90% prediction falls into a trained class that is absent from the
100% TEST true-label class set:
    - the prediction is NOT discarded;
    - it remains a wrong prediction;
    - it affects Accuracy / Recall / F1 / MCC;
    - it is not added as an extra evaluation class.

AVERAGE ORDER
=============
weighted
macro
micro

All floating-point metrics are saved to 4 decimal places.

PER-CLASS DISPLAY RULE
======================
predicted_count = TP + FP = 0
    -> Precision undefined
    -> do not export that per-class row.

TP = 0 and FP > 0
    -> Precision = 0 is a valid result
    -> keep the row.

PLACEMENT
=========
Put this script directly inside:

    2.Protein_student_long_gridsearch/
    └── protein_percent60_90_results/
        ├── PROTEIN_SUBTYPE_TYPE_60_100_100TEST_CLASSES.py
        ├── percent_60/
        ├── percent_70/
        ├── percent_80/
        └── percent_90/

60-90% prediction files:
    percent_XX/protein_fragment_test_predictions.csv
    percent_XX/protein_original_test_predictions.csv

100% prediction file:
    ../test_sequence_predictions.csv

OUTPUT
======
PROTEIN_SUBTYPE_TYPE_60_100_100TEST_CLASSES_RESULTS/
├── fragment_results/
│   ├── SUBTYPE_fragment_end_to_end_60_100.csv
│   ├── SUBTYPE_fragment_true_ARG_only_60_100.csv
│   ├── SUBTYPE_fragment_per_class_60_100.csv
│   ├── TYPE_fragment_end_to_end_60_100.csv
│   ├── TYPE_fragment_true_ARG_only_60_100.csv
│   └── TYPE_fragment_per_class_60_100.csv
│
├── original_results/
│   ├── SUBTYPE_original_end_to_end_60_100.csv
│   ├── SUBTYPE_original_true_ARG_only_60_100.csv
│   ├── SUBTYPE_original_per_class_60_100.csv
│   ├── TYPE_original_end_to_end_60_100.csv
│   ├── TYPE_original_true_ARG_only_60_100.csv
│   └── TYPE_original_per_class_60_100.csv
│
├── EVALUATION_CLASS_SET.csv
└── PROTEIN_SUBTYPE_TYPE_60_100_QC.csv

100% full-length is included in BOTH fragment_results and original_results
as the common reference.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    matthews_corrcoef,
)


VERSION = "2026-08-24-PROTEIN-60-100-100TEST-observed-classes-v1"

MODALITY = "protein"
MODEL_NAME = "Protein_GRID_best"
NONARG = "nonARG"
ROUND_DIGITS = 4

PERCENT_CONDITIONS = (
    "percent_60",
    "percent_70",
    "percent_80",
    "percent_90",
)

GROUP_FILES = {
    "fragment":
        "protein_fragment_test_predictions.csv",

    "original":
        "protein_original_test_predictions.csv",
}

GROUP_LEVEL = {
    "fragment":
        "fragment",

    "original":
        "original_mean_5parts",
}

FULL_CONDITION = "percent_100"
FULL_LEVEL = "full_length"
FULL_FILE = "test_sequence_predictions.csv"

AVERAGES = (
    "weighted",
    "macro",
    "micro",
)


# =============================================================================
# General helpers
# =============================================================================

def normalize_label(value) -> str:

    if pd.isna(value):
        return ""

    text = str(value).strip()

    compact = "".join(
        character
        for character in text.lower()
        if character.isalnum()
    )

    if compact in {
        "nonarg",
        "negative",
        "nonresistance",
        "nonresistant",
    }:
        return NONARG

    return text


def save_csv(
    dataframe: pd.DataFrame,
    path: Path,
):

    result = dataframe.copy()

    float_columns = result.select_dtypes(
        include=[
            "float16",
            "float32",
            "float64",
        ]
    ).columns

    result[
        float_columns
    ] = result[
        float_columns
    ].round(
        ROUND_DIGITS
    )

    result.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )


def binary_mcc_from_counts(
    tp: int,
    fp: int,
    fn: int,
    tn: int,
) -> float:

    numerator = (
        tp * tn
        - fp * fn
    )

    denominator = math.sqrt(
        float(
            (tp + fp)
            * (tp + fn)
            * (tn + fp)
            * (tn + fn)
        )
    )

    if denominator == 0.0:
        return 0.0

    return float(
        numerator
        / denominator
    )


def multiclass_mcc(
    y_true,
    y_pred,
) -> float:

    y_true = np.asarray(
        [
            str(value)
            for value in y_true
        ],
        dtype=str,
    )

    y_pred = np.asarray(
        [
            str(value)
            for value in y_pred
        ],
        dtype=str,
    )

    if (
        len(y_true) == 0
        or len(np.unique(y_true)) < 2
        or len(np.unique(y_pred)) < 2
    ):
        return 0.0

    return float(
        matthews_corrcoef(
            y_true,
            y_pred,
        )
    )


# =============================================================================
# Prediction loading
# =============================================================================

def load_prediction_file(
    path: Path,
    filter_test=False,
) -> pd.DataFrame:

    if not path.is_file():

        raise FileNotFoundError(
            f"Prediction file not found:\n{path}"
        )

    df = pd.read_csv(
        path,
        encoding="utf-8-sig",
    )

    if (
        filter_test
        and "split" in df.columns
    ):

        split = (
            df[
                "split"
            ]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        test_mask = (
            split == "test"
        )

        if test_mask.any():

            df = (
                df.loc[
                    test_mask
                ]
                .copy()
                .reset_index(
                    drop=True
                )
            )

    required = {
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
        "true_ARG",
        "predicted_ARG",
    }

    missing = sorted(
        required
        - set(
            df.columns
        )
    )

    if missing:

        raise ValueError(
            f"{path.name} missing columns: {missing}\n"
            f"Available columns: {list(df.columns)}"
        )

    if df.empty:

        raise ValueError(
            f"No rows in prediction file: {path}"
        )

    df = df.copy()

    for column in (
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
    ):

        df[
            column
        ] = df[
            column
        ].map(
            normalize_label
        )

        if df[
            column
        ].eq("").any():

            raise ValueError(
                f"Empty {column} found in {path}"
            )

    df[
        "true_ARG"
    ] = pd.to_numeric(
        df[
            "true_ARG"
        ],
        errors="raise",
    ).astype(int)

    df[
        "predicted_ARG"
    ] = pd.to_numeric(
        df[
            "predicted_ARG"
        ],
        errors="raise",
    ).astype(int)

    # Ensure nonARG / ARG consistency.
    bad_true = (
        (
            df[
                "true_ARG"
            ].eq(0)
            &
            (
                df[
                    "true_subtype"
                ].ne(NONARG)
                |
                df[
                    "true_type"
                ].ne(NONARG)
            )
        )
        |
        (
            df[
                "true_ARG"
            ].eq(1)
            &
            (
                df[
                    "true_subtype"
                ].eq(NONARG)
                |
                df[
                    "true_type"
                ].eq(NONARG)
            )
        )
    )

    bad_prediction = (
        (
            df[
                "predicted_ARG"
            ].eq(0)
            &
            (
                df[
                    "predicted_subtype"
                ].ne(NONARG)
                |
                df[
                    "predicted_type"
                ].ne(NONARG)
            )
        )
        |
        (
            df[
                "predicted_ARG"
            ].eq(1)
            &
            (
                df[
                    "predicted_subtype"
                ].eq(NONARG)
                |
                df[
                    "predicted_type"
                ].eq(NONARG)
            )
        )
    )

    if bad_true.any():

        raise ValueError(
            f"true_ARG inconsistent with true labels: {path}"
        )

    if bad_prediction.any():

        raise ValueError(
            f"predicted_ARG inconsistent with predicted labels: {path}"
        )

    return df


# =============================================================================
# 100% TEST class universe
# =============================================================================

def build_100_test_class_sets(
    full_df: pd.DataFrame,
):

    true_arg = full_df[
        full_df[
            "true_ARG"
        ]
        == 1
    ].copy()

    arg_subtypes = sorted(
        set(
            true_arg[
                "true_subtype"
            ].tolist()
        )
    )

    arg_types = sorted(
        set(
            true_arg[
                "true_type"
            ].tolist()
        )
    )

    if NONARG in arg_subtypes:
        raise ValueError(
            "nonARG unexpectedly present among true ARG Subtypes."
        )

    if NONARG in arg_types:
        raise ValueError(
            "nonARG unexpectedly present among true ARG Types."
        )

    return {
        "ARG_subtypes":
            arg_subtypes,

        "ARG_types":
            arg_types,

        "Subtype_end_to_end_labels":
            arg_subtypes
            + [
                NONARG
            ],

        "Type_end_to_end_labels":
            arg_types
            + [
                NONARG
            ],
    }


def validate_true_labels_against_100_test(
    df: pd.DataFrame,
    allowed_subtypes: set[str],
    allowed_types: set[str],
    condition: str,
    group_name: str,
):

    true_arg = df[
        df[
            "true_ARG"
        ]
        == 1
    ]

    extra_true_subtypes = sorted(
        set(
            true_arg[
                "true_subtype"
            ].tolist()
        )
        - allowed_subtypes
    )

    extra_true_types = sorted(
        set(
            true_arg[
                "true_type"
            ].tolist()
        )
        - allowed_types
    )

    if extra_true_subtypes:

        raise ValueError(
            f"{condition}/{group_name}: true ARG Subtypes exist "
            f"outside the 100% TEST class set: "
            f"{extra_true_subtypes[:20]}"
        )

    if extra_true_types:

        raise ValueError(
            f"{condition}/{group_name}: true ARG Types exist "
            f"outside the 100% TEST class set: "
            f"{extra_true_types[:20]}"
        )


# =============================================================================
# Per-label counts / PRF
# =============================================================================

def class_counts(
    y_true,
    y_pred,
    label: str,
):

    y_true = np.asarray(
        y_true,
        dtype=str,
    )

    y_pred = np.asarray(
        y_pred,
        dtype=str,
    )

    true_positive = (
        y_true
        == label
    )

    predicted_positive = (
        y_pred
        == label
    )

    tp = int(
        np.sum(
            true_positive
            & predicted_positive
        )
    )

    fp = int(
        np.sum(
            ~true_positive
            & predicted_positive
        )
    )

    fn = int(
        np.sum(
            true_positive
            & ~predicted_positive
        )
    )

    tn = int(
        len(
            y_true
        )
        - tp
        - fp
        - fn
    )

    return (
        tp,
        fp,
        fn,
        tn,
    )


def per_label_prf(
    y_true,
    y_pred,
    labels,
):

    rows = []

    for label in labels:

        (
            tp,
            fp,
            fn,
            tn,
        ) = class_counts(
            y_true,
            y_pred,
            label,
        )

        predicted_count = (
            tp
            + fp
        )

        support = (
            tp
            + fn
        )

        precision = (
            float(
                tp
                / predicted_count
            )
            if predicted_count
            else 0.0
        )

        recall = (
            float(
                tp
                / support
            )
            if support
            else 0.0
        )

        f1 = (
            float(
                2.0
                * precision
                * recall
                / (
                    precision
                    + recall
                )
            )
            if (
                precision
                + recall
            )
            else 0.0
        )

        rows.append(
            {
                "label":
                    label,

                "tp":
                    tp,

                "fp":
                    fp,

                "fn":
                    fn,

                "tn":
                    tn,

                "support":
                    support,

                "predicted_count":
                    predicted_count,

                "precision":
                    precision,

                "recall":
                    recall,

                "f1":
                    f1,
            }
        )

    return rows


def averaged_prf(
    y_true,
    y_pred,
    labels,
    average: str,
):

    rows = per_label_prf(
        y_true,
        y_pred,
        labels,
    )

    if average == "macro":

        return (
            float(
                np.mean(
                    [
                        row[
                            "precision"
                        ]
                        for row
                        in rows
                    ]
                )
            ),
            float(
                np.mean(
                    [
                        row[
                            "recall"
                        ]
                        for row
                        in rows
                    ]
                )
            ),
            float(
                np.mean(
                    [
                        row[
                            "f1"
                        ]
                        for row
                        in rows
                    ]
                )
            ),
        )

    if average == "weighted":

        total_support = int(
            sum(
                row[
                    "support"
                ]
                for row
                in rows
            )
        )

        if total_support == 0:

            return (
                0.0,
                0.0,
                0.0,
            )

        return (
            float(
                sum(
                    row[
                        "precision"
                    ]
                    * row[
                        "support"
                    ]
                    for row
                    in rows
                )
                / total_support
            ),
            float(
                sum(
                    row[
                        "recall"
                    ]
                    * row[
                        "support"
                    ]
                    for row
                    in rows
                )
                / total_support
            ),
            float(
                sum(
                    row[
                        "f1"
                    ]
                    * row[
                        "support"
                    ]
                    for row
                    in rows
                )
                / total_support
            ),
        )

    if average == "micro":

        tp = int(
            sum(
                row[
                    "tp"
                ]
                for row
                in rows
            )
        )

        fp = int(
            sum(
                row[
                    "fp"
                ]
                for row
                in rows
            )
        )

        fn = int(
            sum(
                row[
                    "fn"
                ]
                for row
                in rows
            )
        )

        precision = (
            float(
                tp
                / (
                    tp
                    + fp
                )
            )
            if (
                tp
                + fp
            )
            else 0.0
        )

        recall = (
            float(
                tp
                / (
                    tp
                    + fn
                )
            )
            if (
                tp
                + fn
            )
            else 0.0
        )

        f1 = (
            float(
                2.0
                * precision
                * recall
                / (
                    precision
                    + recall
                )
            )
            if (
                precision
                + recall
            )
            else 0.0
        )

        return (
            precision,
            recall,
            f1,
        )

    raise ValueError(
        f"Unknown average: {average}"
    )


# =============================================================================
# Overall metrics
# =============================================================================

def calculate_overall_rows(
    level_name: str,
    comparison_group: str,
    condition: str,
    length_percent: int,
    source_level: str,
    task: str,
    y_true,
    y_pred,
    evaluation_labels,
):

    y_true = np.asarray(
        [
            str(value)
            for value in y_true
        ],
        dtype=str,
    )

    y_pred = np.asarray(
        [
            str(value)
            for value in y_pred
        ],
        dtype=str,
    )

    if len(
        y_true
    ) == 0:

        raise ValueError(
            f"No samples for "
            f"{level_name}/{condition}/{comparison_group}/{task}"
        )

    true_outside = sorted(
        set(
            y_true.tolist()
        )
        - set(
            evaluation_labels
        )
    )

    if true_outside:

        raise ValueError(
            f"True labels outside evaluation universe in "
            f"{level_name}/{condition}/{comparison_group}/{task}: "
            f"{true_outside[:20]}"
        )

    # Accuracy uses actual predictions, including predictions to
    # training-only classes outside the 100% TEST class set.
    accuracy = float(
        accuracy_score(
            y_true,
            y_pred,
        )
    )

    # MCC also uses actual labels/predictions so out-of-set predictions
    # remain penalized.
    mcc = multiclass_mcc(
        y_true,
        y_pred,
    )

    out_of_scope_predictions = int(
        np.sum(
            ~np.isin(
                y_pred,
                np.asarray(
                    evaluation_labels,
                    dtype=str,
                ),
            )
        )
    )

    rows = []

    for average in AVERAGES:

        (
            precision,
            recall,
            f1,
        ) = averaged_prf(
            y_true,
            y_pred,
            evaluation_labels,
            average,
        )

        rows.append(
            {
                "modality":
                    MODALITY,

                "model":
                    MODEL_NAME,

                "level":
                    level_name,

                "comparison_group":
                    comparison_group,

                "condition":
                    condition,

                "length_percent":
                    length_percent,

                "source_level":
                    source_level,

                "task":
                    task,

                "average":
                    average,

                "accuracy":
                    accuracy,

                "precision":
                    precision,

                "recall":
                    recall,

                "f1":
                    f1,

                "mcc":
                    mcc,

                "support":
                    int(
                        len(
                            y_true
                        )
                    ),

                "evaluation_class_count":
                    int(
                        len(
                            evaluation_labels
                        )
                    ),

                "out_of_100test_class_predictions":
                    out_of_scope_predictions,
            }
        )

    return rows


# =============================================================================
# Per-class metrics
# =============================================================================

def calculate_per_class_rows(
    level_name: str,
    comparison_group: str,
    condition: str,
    length_percent: int,
    source_level: str,
    class_column: str,
    y_true,
    y_pred,
    evaluation_labels,
):

    y_true = np.asarray(
        [
            str(value)
            for value in y_true
        ],
        dtype=str,
    )

    y_pred = np.asarray(
        [
            str(value)
            for value in y_pred
        ],
        dtype=str,
    )

    total = int(
        len(
            y_true
        )
    )

    rows = []

    for label in evaluation_labels:

        (
            tp,
            fp,
            fn,
            tn,
        ) = class_counts(
            y_true,
            y_pred,
            label,
        )

        predicted_count = (
            tp
            + fp
        )

        # User-requested display rule:
        # if precision cannot be calculated, do not export this class.
        if predicted_count == 0:
            continue

        support = (
            tp
            + fn
        )

        precision = float(
            tp
            / predicted_count
        )

        recall = (
            float(
                tp
                / support
            )
            if support
            else 0.0
        )

        f1 = (
            float(
                2.0
                * precision
                * recall
                / (
                    precision
                    + recall
                )
            )
            if (
                precision
                + recall
            )
            else 0.0
        )

        rows.append(
            {
                "modality":
                    MODALITY,

                "model":
                    MODEL_NAME,

                "level":
                    level_name,

                "comparison_group":
                    comparison_group,

                "condition":
                    condition,

                "length_percent":
                    length_percent,

                "source_level":
                    source_level,

                class_column:
                    label,

                "ACC":
                    (
                        float(
                            (
                                tp
                                + tn
                            )
                            / total
                        )
                        if total
                        else 0.0
                    ),

                "Precision":
                    precision,

                "Recall":
                    recall,

                "F1":
                    f1,

                "MCC":
                    binary_mcc_from_counts(
                        tp,
                        fp,
                        fn,
                        tn,
                    ),

                "support":
                    support,

                "predicted_count":
                    predicted_count,

                "correct_count":
                    tp,

                "wrong_count":
                    int(
                        fp
                        + fn
                    ),

                "TP":
                    tp,

                "FP":
                    fp,

                "FN":
                    fn,

                "TN":
                    tn,

                "total_samples":
                    total,

                "is_nonARG":
                    (
                        label
                        == NONARG
                    ),
            }
        )

    return rows


# =============================================================================
# Sort
# =============================================================================

def sort_overall(
    df: pd.DataFrame,
):

    task_rank = {
        "end_to_end_all_samples":
            0,

        "true_ARG_only":
            1,
    }

    average_rank = {
        "weighted":
            0,

        "macro":
            1,

        "micro":
            2,
    }

    result = df.copy()

    result[
        "_task_rank"
    ] = result[
        "task"
    ].map(
        task_rank
    )

    result[
        "_average_rank"
    ] = result[
        "average"
    ].map(
        average_rank
    )

    result = (
        result.sort_values(
            [
                "length_percent",
                "_task_rank",
                "_average_rank",
            ]
        )
        .drop(
            columns=[
                "_task_rank",
                "_average_rank",
            ]
        )
        .reset_index(
            drop=True
        )
    )

    return result


# =============================================================================
# Build fragment/original result group
# =============================================================================

def build_group(
    group_name: str,
    loaded: dict,
    full_df: pd.DataFrame,
    class_sets: dict,
):

    source_level = GROUP_LEVEL[
        group_name
    ]

    subtype_e2e_labels = class_sets[
        "Subtype_end_to_end_labels"
    ]

    subtype_arg_labels = class_sets[
        "ARG_subtypes"
    ]

    type_e2e_labels = class_sets[
        "Type_end_to_end_labels"
    ]

    type_arg_labels = class_sets[
        "ARG_types"
    ]

    subtype_overall = []
    type_overall = []

    subtype_per_class = []
    type_per_class = []

    # ------------------------------------------------------------------
    # 60-90
    # ------------------------------------------------------------------

    for condition in PERCENT_CONDITIONS:

        length_percent = int(
            condition.split(
                "_"
            )[
                1
            ]
        )

        df = loaded[
            (
                condition,
                group_name,
            )
        ]

        arg_df = df[
            df[
                "true_ARG"
            ]
            == 1
        ].copy()

        # SUBTYPE end-to-end, including nonARG.
        subtype_overall.extend(
            calculate_overall_rows(
                level_name="SUBTYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                task="end_to_end_all_samples",
                y_true=df[
                    "true_subtype"
                ],
                y_pred=df[
                    "predicted_subtype"
                ],
                evaluation_labels=subtype_e2e_labels,
            )
        )

        # SUBTYPE true ARG only.
        # nonARG prediction remains wrong, but nonARG is not a true class here.
        subtype_overall.extend(
            calculate_overall_rows(
                level_name="SUBTYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                task="true_ARG_only",
                y_true=arg_df[
                    "true_subtype"
                ],
                y_pred=arg_df[
                    "predicted_subtype"
                ],
                evaluation_labels=subtype_arg_labels,
            )
        )

        subtype_per_class.extend(
            calculate_per_class_rows(
                level_name="SUBTYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                class_column="Subtype",
                y_true=df[
                    "true_subtype"
                ],
                y_pred=df[
                    "predicted_subtype"
                ],
                evaluation_labels=subtype_e2e_labels,
            )
        )

        # TYPE end-to-end, including nonARG.
        type_overall.extend(
            calculate_overall_rows(
                level_name="TYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                task="end_to_end_all_samples",
                y_true=df[
                    "true_type"
                ],
                y_pred=df[
                    "predicted_type"
                ],
                evaluation_labels=type_e2e_labels,
            )
        )

        # TYPE true ARG only.
        type_overall.extend(
            calculate_overall_rows(
                level_name="TYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                task="true_ARG_only",
                y_true=arg_df[
                    "true_type"
                ],
                y_pred=arg_df[
                    "predicted_type"
                ],
                evaluation_labels=type_arg_labels,
            )
        )

        type_per_class.extend(
            calculate_per_class_rows(
                level_name="TYPE",
                comparison_group=group_name,
                condition=condition,
                length_percent=length_percent,
                source_level=source_level,
                class_column="Type",
                y_true=df[
                    "true_type"
                ],
                y_pred=df[
                    "predicted_type"
                ],
                evaluation_labels=type_e2e_labels,
            )
        )

    # ------------------------------------------------------------------
    # 100% full-length shared reference
    # ------------------------------------------------------------------

    full_arg_df = full_df[
        full_df[
            "true_ARG"
        ]
        == 1
    ].copy()

    # SUBTYPE
    subtype_overall.extend(
        calculate_overall_rows(
            level_name="SUBTYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            task="end_to_end_all_samples",
            y_true=full_df[
                "true_subtype"
            ],
            y_pred=full_df[
                "predicted_subtype"
            ],
            evaluation_labels=subtype_e2e_labels,
        )
    )

    subtype_overall.extend(
        calculate_overall_rows(
            level_name="SUBTYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            task="true_ARG_only",
            y_true=full_arg_df[
                "true_subtype"
            ],
            y_pred=full_arg_df[
                "predicted_subtype"
            ],
            evaluation_labels=subtype_arg_labels,
        )
    )

    subtype_per_class.extend(
        calculate_per_class_rows(
            level_name="SUBTYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            class_column="Subtype",
            y_true=full_df[
                "true_subtype"
            ],
            y_pred=full_df[
                "predicted_subtype"
            ],
            evaluation_labels=subtype_e2e_labels,
        )
    )

    # TYPE
    type_overall.extend(
        calculate_overall_rows(
            level_name="TYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            task="end_to_end_all_samples",
            y_true=full_df[
                "true_type"
            ],
            y_pred=full_df[
                "predicted_type"
            ],
            evaluation_labels=type_e2e_labels,
        )
    )

    type_overall.extend(
        calculate_overall_rows(
            level_name="TYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            task="true_ARG_only",
            y_true=full_arg_df[
                "true_type"
            ],
            y_pred=full_arg_df[
                "predicted_type"
            ],
            evaluation_labels=type_arg_labels,
        )
    )

    type_per_class.extend(
        calculate_per_class_rows(
            level_name="TYPE",
            comparison_group=group_name,
            condition=FULL_CONDITION,
            length_percent=100,
            source_level=FULL_LEVEL,
            class_column="Type",
            y_true=full_df[
                "true_type"
            ],
            y_pred=full_df[
                "predicted_type"
            ],
            evaluation_labels=type_e2e_labels,
        )
    )

    return {
        "subtype_overall":
            sort_overall(
                pd.DataFrame(
                    subtype_overall
                )
            ),

        "type_overall":
            sort_overall(
                pd.DataFrame(
                    type_overall
                )
            ),

        "subtype_per_class":
            (
                pd.DataFrame(
                    subtype_per_class
                )
                .sort_values(
                    [
                        "length_percent",
                        "Subtype",
                    ]
                )
                .reset_index(
                    drop=True
                )
            ),

        "type_per_class":
            (
                pd.DataFrame(
                    type_per_class
                )
                .sort_values(
                    [
                        "length_percent",
                        "Type",
                    ]
                )
                .reset_index(
                    drop=True
                )
            ),
    }


# =============================================================================
# Save group
# =============================================================================

def save_group(
    group_name: str,
    output_dir: Path,
    results: dict,
):

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    prefix = (
        "fragment"
        if group_name
        == "fragment"
        else "original"
    )

    subtype_overall = results[
        "subtype_overall"
    ]

    type_overall = results[
        "type_overall"
    ]

    # SUBTYPE
    save_csv(
        subtype_overall[
            subtype_overall[
                "task"
            ]
            == "end_to_end_all_samples"
        ],
        output_dir
        / f"SUBTYPE_{prefix}_end_to_end_60_100.csv",
    )

    save_csv(
        subtype_overall[
            subtype_overall[
                "task"
            ]
            == "true_ARG_only"
        ],
        output_dir
        / f"SUBTYPE_{prefix}_true_ARG_only_60_100.csv",
    )

    save_csv(
        results[
            "subtype_per_class"
        ],
        output_dir
        / f"SUBTYPE_{prefix}_per_class_60_100.csv",
    )

    # TYPE
    save_csv(
        type_overall[
            type_overall[
                "task"
            ]
            == "end_to_end_all_samples"
        ],
        output_dir
        / f"TYPE_{prefix}_end_to_end_60_100.csv",
    )

    save_csv(
        type_overall[
            type_overall[
                "task"
            ]
            == "true_ARG_only"
        ],
        output_dir
        / f"TYPE_{prefix}_true_ARG_only_60_100.csv",
    )

    save_csv(
        results[
            "type_per_class"
        ],
        output_dir
        / f"TYPE_{prefix}_per_class_60_100.csv",
    )


# =============================================================================
# Evaluation-class table
# =============================================================================

def build_class_set_table(
    class_sets: dict,
):

    rows = []

    for subtype in class_sets[
        "ARG_subtypes"
    ]:

        rows.append(
            {
                "level":
                    "SUBTYPE",

                "class_name":
                    subtype,

                "is_nonARG":
                    False,

                "source":
                    "true label observed in 100% Protein TEST",
            }
        )

    rows.append(
        {
            "level":
                "SUBTYPE",

            "class_name":
                NONARG,

            "is_nonARG":
                True,

            "source":
                "explicit end-to-end class",
        }
    )

    for type_name in class_sets[
        "ARG_types"
    ]:

        rows.append(
            {
                "level":
                    "TYPE",

                "class_name":
                    type_name,

                "is_nonARG":
                    False,

                "source":
                    "true label observed in 100% Protein TEST",
            }
        )

    rows.append(
        {
            "level":
                "TYPE",

            "class_name":
                NONARG,

            "is_nonARG":
                True,

            "source":
                "explicit end-to-end class",
        }
    )

    return pd.DataFrame(
        rows
    )


# =============================================================================
# Main
# =============================================================================

def main():

    base_dir = Path(
        __file__
    ).resolve().parent

    # Script is expected inside:
    # 2.Protein_student_long_gridsearch/protein_percent60_90_results/
    grid_dir = (
        base_dir.parent
    )

    output_root = (
        base_dir
        / "PROTEIN_SUBTYPE_TYPE_60_100_100TEST_CLASSES_RESULTS"
    )

    fragment_dir = (
        output_root
        / "fragment_results"
    )

    original_dir = (
        output_root
        / "original_results"
    )

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "=" * 130
    )

    print(
        "PROTEIN SUBTYPE + TYPE 60-100 | CLASSES DEFINED BY 100% TEST"
    )

    print(
        "=" * 130
    )

    print(
        f"VERSION          : {VERSION}"
    )

    print(
        f"Percent base dir : {base_dir}"
    )

    print(
        f"Protein grid dir : {grid_dir}"
    )

    print(
        f"Output root      : {output_root}"
    )

    print(
        "Average order    : weighted -> macro -> micro"
    )

    print(
        f"Decimal places   : {ROUND_DIGITS}"
    )

    loaded = {}
    qc_rows = []

    # ------------------------------------------------------------------
    # Load 60-90.
    # ------------------------------------------------------------------

    for condition in PERCENT_CONDITIONS:

        condition_dir = (
            base_dir
            / condition
        )

        if not condition_dir.is_dir():

            raise FileNotFoundError(
                f"Missing condition folder:\n"
                f"{condition_dir}"
            )

        for group_name, filename in GROUP_FILES.items():

            path = (
                condition_dir
                / filename
            )

            print(
                f"[LOAD] {condition} | "
                f"{group_name} | "
                f"{filename}"
            )

            df = load_prediction_file(
                path,
                filter_test=False,
            )

            loaded[
                (
                    condition,
                    group_name,
                )
            ] = df

    # ------------------------------------------------------------------
    # Load 100% full-length TEST result.
    # ------------------------------------------------------------------

    full_path = (
        grid_dir
        / FULL_FILE
    )

    print(
        f"[LOAD] percent_100 | "
        f"full_length | "
        f"{full_path}"
    )

    full_df = load_prediction_file(
        full_path,
        filter_test=True,
    )

    # ------------------------------------------------------------------
    # Define evaluation classes ONLY from 100% TEST true labels.
    # ------------------------------------------------------------------

    class_sets = build_100_test_class_sets(
        full_df
    )

    allowed_subtypes = set(
        class_sets[
            "ARG_subtypes"
        ]
    )

    allowed_types = set(
        class_sets[
            "ARG_types"
        ]
    )

    print()
    print(
        "100% PROTEIN TEST EVALUATION CLASS SET"
    )

    print(
        f"100% true ARG Subtypes : "
        f"{len(class_sets['ARG_subtypes'])}"
    )

    print(
        f"Subtype E2E classes    : "
        f"{len(class_sets['Subtype_end_to_end_labels'])} "
        f"(ARG Subtypes + nonARG)"
    )

    print(
        f"100% true ARG Types    : "
        f"{len(class_sets['ARG_types'])}"
    )

    print(
        f"Type E2E classes       : "
        f"{len(class_sets['Type_end_to_end_labels'])} "
        f"(ARG Types + nonARG)"
    )

    print()

    # ------------------------------------------------------------------
    # Validate 60-90 true label universe and create QC.
    # ------------------------------------------------------------------

    for (
        condition,
        group_name,
    ), df in loaded.items():

        validate_true_labels_against_100_test(
            df=df,
            allowed_subtypes=allowed_subtypes,
            allowed_types=allowed_types,
            condition=condition,
            group_name=group_name,
        )

        true_arg = df[
            df[
                "true_ARG"
            ]
            == 1
        ]

        outside_subtype_predictions = int(
            (
                df[
                    "predicted_ARG"
                ].eq(1)
                &
                ~df[
                    "predicted_subtype"
                ].isin(
                    allowed_subtypes
                )
            ).sum()
        )

        outside_type_predictions = int(
            (
                df[
                    "predicted_ARG"
                ].eq(1)
                &
                ~df[
                    "predicted_type"
                ].isin(
                    allowed_types
                )
            ).sum()
        )

        qc_rows.append(
            {
                "condition":
                    condition,

                "length_percent":
                    int(
                        condition.split(
                            "_"
                        )[
                            1
                        ]
                    ),

                "comparison_group":
                    group_name,

                "rows":
                    int(
                        len(
                            df
                        )
                    ),

                "true_ARG":
                    int(
                        len(
                            true_arg
                        )
                    ),

                "true_nonARG":
                    int(
                        (
                            df[
                                "true_ARG"
                            ]
                            == 0
                        ).sum()
                    ),

                "predicted_ARG":
                    int(
                        df[
                            "predicted_ARG"
                        ].sum()
                    ),

                "predicted_to_ARG_subtype_outside_100test":
                    outside_subtype_predictions,

                "predicted_to_ARG_type_outside_100test":
                    outside_type_predictions,

                "prediction_file":
                    str(
                        base_dir
                        / condition
                        / GROUP_FILES[
                            group_name
                        ]
                    ),
            }
        )

    # ------------------------------------------------------------------
    # Calculate fragment / original.
    # ------------------------------------------------------------------

    fragment_results = build_group(
        group_name="fragment",
        loaded=loaded,
        full_df=full_df,
        class_sets=class_sets,
    )

    original_results = build_group(
        group_name="original",
        loaded=loaded,
        full_df=full_df,
        class_sets=class_sets,
    )

    save_group(
        group_name="fragment",
        output_dir=fragment_dir,
        results=fragment_results,
    )

    save_group(
        group_name="original",
        output_dir=original_dir,
        results=original_results,
    )

    # ------------------------------------------------------------------
    # Evaluation class set.
    # ------------------------------------------------------------------

    class_set_path = (
        output_root
        / "EVALUATION_CLASS_SET.csv"
    )

    build_class_set_table(
        class_sets
    ).to_csv(
        class_set_path,
        index=False,
        encoding="utf-8-sig",
    )

    # ------------------------------------------------------------------
    # Add 100% QC twice because it is the shared reference.
    # ------------------------------------------------------------------

    for group_name in (
        "fragment",
        "original",
    ):

        qc_rows.append(
            {
                "condition":
                    FULL_CONDITION,

                "length_percent":
                    100,

                "comparison_group":
                    group_name,

                "rows":
                    int(
                        len(
                            full_df
                        )
                    ),

                "true_ARG":
                    int(
                        full_df[
                            "true_ARG"
                        ].sum()
                    ),

                "true_nonARG":
                    int(
                        (
                            full_df[
                                "true_ARG"
                            ]
                            == 0
                        ).sum()
                    ),

                "predicted_ARG":
                    int(
                        full_df[
                            "predicted_ARG"
                        ].sum()
                    ),

                "predicted_to_ARG_subtype_outside_100test":
                    int(
                        (
                            full_df[
                                "predicted_ARG"
                            ].eq(1)
                            &
                            ~full_df[
                                "predicted_subtype"
                            ].isin(
                                allowed_subtypes
                            )
                        ).sum()
                    ),

                "predicted_to_ARG_type_outside_100test":
                    int(
                        (
                            full_df[
                                "predicted_ARG"
                            ].eq(1)
                            &
                            ~full_df[
                                "predicted_type"
                            ].isin(
                                allowed_types
                            )
                        ).sum()
                    ),

                "prediction_file":
                    str(
                        full_path
                    ),
            }
        )

    qc = pd.DataFrame(
        qc_rows
    )

    qc[
        "100test_ARG_subtype_count"
    ] = len(
        class_sets[
            "ARG_subtypes"
        ]
    )

    qc[
        "Subtype_E2E_class_count_with_nonARG"
    ] = len(
        class_sets[
            "Subtype_end_to_end_labels"
        ]
    )

    qc[
        "100test_ARG_Type_count"
    ] = len(
        class_sets[
            "ARG_types"
        ]
    )

    qc[
        "Type_E2E_class_count_with_nonARG"
    ] = len(
        class_sets[
            "Type_end_to_end_labels"
        ]
    )

    qc_path = (
        output_root
        / "PROTEIN_SUBTYPE_TYPE_60_100_QC.csv"
    )

    qc.to_csv(
        qc_path,
        index=False,
        encoding="utf-8-sig",
    )

    # ------------------------------------------------------------------
    # Final console output.
    # ------------------------------------------------------------------

    print(
        "=" * 130
    )

    print(
        "COMPLETED"
    )

    print(
        "=" * 130
    )

    print(
        f"100% TEST ARG Type count    : "
        f"{len(class_sets['ARG_types'])}"
    )

    print(
        f"Type classes incl. nonARG   : "
        f"{len(class_sets['Type_end_to_end_labels'])}"
    )

    print(
        f"100% TEST ARG Subtype count : "
        f"{len(class_sets['ARG_subtypes'])}"
    )

    print(
        f"Subtype classes incl. nonARG: "
        f"{len(class_sets['Subtype_end_to_end_labels'])}"
    )

    print()

    print(
        f"Fragment results : {fragment_dir}"
    )

    print(
        f"Original results : {original_dir}"
    )

    print(
        f"Evaluation set   : {class_set_path}"
    )

    print(
        f"QC               : {qc_path}"
    )

    print()

    print(
        "Average order: weighted -> macro -> micro"
    )

    print(
        "All floating-point metrics: 4 decimal places"
    )

    print(
        "End-to-end includes nonARG."
    )

    print(
        "Per-class rows with predicted_count=0 are excluded."
    )


if __name__ == "__main__":
    main()
