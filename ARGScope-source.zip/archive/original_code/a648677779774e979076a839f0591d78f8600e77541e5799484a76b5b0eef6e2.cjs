// Render the actual delivered SVGs and check transparency and safe tight margins.
const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = path.resolve('outputs/vf_bgc_including_negative_20260922');
const qa = path.join(root, 'qa_svg');
fs.mkdirSync(qa, {recursive:true});
(async () => {
  const rows = [];
  for (const sub of ['', 'editable_text']) {
    for (const name of fs.readdirSync(path.join(root, sub)).filter(f => f.endsWith('.svg')).sort()) {
      const data = fs.readFileSync(path.join(root, sub, name));
      if (data.toString().includes('<image ')) throw new Error('Embedded bitmap: '+name);
      const result = await sharp(data, {density:180}).resize({width:1800, height:1700, fit:'inside'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
      const {width:w, height:h, channels:c} = result.info;
      let x0=w, y0=h, x1=-1, y1=-1, transparent=0;
      for (let y=0;y<h;y++) for (let x=0;x<w;x++) {
        const alpha=result.data[(y*w+x)*c+c-1];
        if (alpha===0) transparent++;
        if (alpha>4) { x0=Math.min(x0,x); y0=Math.min(y0,y); x1=Math.max(x1,x); y1=Math.max(y1,y); }
      }
      const margins=[x0,y0,w-1-x1,h-1-y1];
      if (!transparent || margins.some(m=>m<1 || m>15)) throw new Error('Unsafe crop: '+name+' '+margins);
      const output=path.join(qa,(sub ? 'editable_' : '')+name.replace('.svg','.png'));
      await sharp(result.data,{raw:result.info}).flatten({background:'#ffffff'}).png().toFile(output);
      rows.push({File:path.join(sub,name),Width:w,Height:h,Exterior_pixels:margins,
                 Transparent_pixels:transparent,Has_embedded_bitmap:false});
    }
  }
  if (rows.length!==4) throw new Error('Expected two outlined and two editable SVGs');
  fs.writeFileSync(path.join(qa,'verification.json'),JSON.stringify(rows,null,2));
  console.log(JSON.stringify(rows,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
