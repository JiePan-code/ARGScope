"""Local right-click launcher for the Full DNA Student."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ablation_runtime import (
    add_default_structure,
    data_root_from_launcher,
    guard_student_recursive_delete,
    load_base,
    reject_overwrite_argument,
    set_common_student_defaults,
)

DATA = data_root_from_launcher(__file__)
m = load_base("05_dna_student.py", "dna_full_local_base")
set_common_student_defaults(
    m,
    DATA,
    "dna",
    "DNA_student_subtype2_newsplit_unified",
)
guard_student_recursive_delete(m, DATA, "DNA_student_subtype2_newsplit_unified")
reject_overwrite_argument()
add_default_structure(DATA)
m.main()
