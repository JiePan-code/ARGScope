#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Plot two type-level confusion-matrix style figures from a DNA prediction CSV.

This is the DNA-adapted version of the previous confusion-matrix script.
Main changes:
1. same plotting logic as before
2. auto-detect DNA prediction CSV in the same folder
3. no numbers inside heatmap cells
4. pale-orange color palette
5. PNG exported at 600 dpi
6. PDF/SVG also exported

Expected input CSV columns
--------------------------
true_type
predicted_type

Typical input example
---------------------
test_sequence_predictions.csv
"""

from __future__ import annotations

from pathlib import Path
import re

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.colors import LinearSegmentedColormap


# =============================================================================
# User settings
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# Leave as None for auto-detection.
# Or set explicitly, e.g.:
# INPUT_CSV = SCRIPT_DIR / "test_sequence_predictions.csv"
INPUT_CSV = None

OUTDIR = SCRIPT_DIR / "DNA_confusion_matrix_plots"
OUTDIR.mkdir(parents=True, exist_ok=True)

TRUE_COL = "true_type"
PRED_COL = "predicted_type"

DPI = 600
SAVE_PDF = True
SAVE_SVG = True
TRANSPARENT_BG = False

USE_ARIAL = True
BASE_FONT = "Arial"


# =============================================================================
# Font sizes / figure sizes
# =============================================================================

FIGSIZE = (6.15, 4.75)

TITLE_SIZE = 12.0
AXIS_LABEL_SIZE = 10.5
TICK_SIZE = 7.8
COLORBAR_TICK_SIZE = 7.8
COLORBAR_LABEL_SIZE = 9.0

SPINE_WIDTH = 0.9
CELL_GRID_WIDTH = 0.40
TICK_ROTATION = 43


# =============================================================================
# Pale-orange colormap
# =============================================================================
# If you want the whole figure more orange, just modify these colors.
LIGHT_ORANGE_COLORS = [
    "#FFF9F4",
    "#FDEDDC",
    "#F9DAB8",
    "#F5C28E",
    "#EFA869",
    "#E48948",
    "#CD6F2F",
    "#A8551F",
]

LIGHT_ORANGE_CMAP = LinearSegmentedColormap.from_list(
    "light_orange",
    LIGHT_ORANGE_COLORS,
    N=256,
)


# =============================================================================
# Display names / class order
# =============================================================================

DISPLAY_NAME_MAP = {
    "aminoglycoside": "Aminoglycosides",
    "bacitracin": "Bacitracin",
    "beta_lactam": "Beta-lactams",
    "bleomycin": "Bleomycin",
    "chloramphenicol": "Chloramphenicol",
    "florfenicol": "Florfenicol",
    "fosfomycin": "Fosfomycin",
    "fusidic_acid": "Fusidic acid",
    "macrolide-lincosamide-streptogramin": "MLS",
    "MLS": "MLS",
    "multidrug": "Multidrug",
    "nonARG": "Non-ARGs",
    "nonARGs": "Non-ARGs",
    "novobiocin": "Novobiocin",
    "other_peptide_antibiotics": "Peptide antibiotics",
    "polymyxin": "Polymyxin",
    "puromycin": "Puromycin",
    "quinolone": "Fluoroquinolones",
    "rifamycin": "Rifamycin",
    "streptothricin": "Streptothricin",
    "sulfonamide": "Sulfonamide",
    "tetracenomycin_C": "Tetracenomycin C",
    "tetracycline": "Tetracyclines",
    "trimethoprim": "Trimethoprim",
    "tunicamycin": "Tunicamycin",
    "vancomycin": "Vancomycin",
}

PREFERRED_ORDER = [
    "beta_lactam",
    "trimethoprim",
    "macrolide-lincosamide-streptogramin",
    "MLS",
    "fusidic_acid",
    "fosfomycin",
    "aminoglycoside",
    "quinolone",
    "multidrug",
    "vancomycin",
    "chloramphenicol",
    "florfenicol",
    "rifamycin",
    "tetracycline",
    "other_peptide_antibiotics",
    "bacitracin",
    "sulfonamide",
    "tetracenomycin_C",
    "novobiocin",
    "tunicamycin",
    "streptothricin",
    "polymyxin",
    "bleomycin",
    "puromycin",
    "nonARG",
    "nonARGs",
]


# =============================================================================
# Font / style
# =============================================================================

def configure_fonts():
    if USE_ARIAL:
        plt.rcParams.update({
            "font.family": "sans-serif",
            "font.sans-serif": [BASE_FONT, "DejaVu Sans", "Liberation Sans"],
        })
    else:
        plt.rcParams.update({
            "font.family": "sans-serif",
        })

    plt.rcParams.update({
        "font.size": TICK_SIZE,
        "axes.titlesize": TITLE_SIZE,
        "axes.labelsize": AXIS_LABEL_SIZE,
        "xtick.labelsize": TICK_SIZE,
        "ytick.labelsize": TICK_SIZE,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
        "savefig.facecolor": "none" if TRANSPARENT_BG else "white",
        "savefig.edgecolor": "none" if TRANSPARENT_BG else "white",
    })


def report_font_status():
    if not USE_ARIAL:
        print("[FONT] Using Matplotlib default sans-serif.")
        return

    try:
        path = fm.findfont(BASE_FONT, fallback_to_default=False)
        print(f"[FONT] Arial detected: {path}")
    except Exception:
        print(
            "[FONT WARNING] Arial not found on this machine. "
            "Matplotlib will fall back to another sans-serif font."
        )


# =============================================================================
# Helpers
# =============================================================================

def clean_label(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).strip()


def canonical_nonarg(x: str) -> str:
    s = re.sub(r"[\s_\-]+", "", str(x).strip().lower())
    if s in {"nonarg", "nonargs"}:
        return "nonARG"
    return str(x).strip()


def get_class_order(df: pd.DataFrame) -> list[str]:
    observed = []
    for col in (TRUE_COL, PRED_COL):
        observed.extend(df[col].map(clean_label).tolist())

    observed = [canonical_nonarg(x) for x in observed if x]
    observed_set = set(observed)

    order = []
    for x in PREFERRED_ORDER:
        x2 = canonical_nonarg(x)
        if x2 in observed_set and x2 not in order:
            order.append(x2)

    remaining = sorted(observed_set - set(order), key=str.lower)

    nonarg_like = []
    normal = []
    for name in remaining:
        if re.sub(r"[\s_\-]+", "", name.lower()) in {"nonarg", "nonargs"}:
            nonarg_like.append(name)
        else:
            normal.append(name)

    order.extend(normal)
    order.extend(nonarg_like)
    return order


def display_name(label: str) -> str:
    label = canonical_nonarg(label)
    if label in DISPLAY_NAME_MAP:
        return DISPLAY_NAME_MAP[label]

    text = str(label).replace("_", " ").replace("-", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text.title()


# =============================================================================
# Matrix building
# =============================================================================

def build_matrices(df: pd.DataFrame, order: list[str]):
    counts = pd.crosstab(
        df[TRUE_COL].map(canonical_nonarg),
        df[PRED_COL].map(canonical_nonarg),
        dropna=False,
    )

    counts = counts.reindex(index=order, columns=order, fill_value=0)

    counts_values = counts.to_numpy(dtype=float)
    row_sums = counts_values.sum(axis=1, keepdims=True)

    with np.errstate(divide="ignore", invalid="ignore"):
        normalized = np.divide(
            counts_values,
            row_sums,
            out=np.zeros_like(counts_values, dtype=float),
            where=row_sums > 0,
        )

    normalized_df = pd.DataFrame(
        normalized,
        index=counts.index,
        columns=counts.columns,
    )

    error_counts = counts.copy()
    np.fill_diagonal(error_counts.values, 0)

    return counts, normalized_df, error_counts


def style_axes(ax):
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(SPINE_WIDTH)
        spine.set_color("#333333")

    ax.tick_params(axis="both", which="major", width=1.0, length=4)


def save_figure(fig, stem: str):
    png = OUTDIR / f"{stem}.png"
    fig.savefig(
        png,
        dpi=DPI,
        bbox_inches="tight",
        pad_inches=0.03,
        transparent=TRANSPARENT_BG,
    )
    print(f"[SAVE] {png}")

    if SAVE_PDF:
        pdf = OUTDIR / f"{stem}.pdf"
        fig.savefig(
            pdf,
            bbox_inches="tight",
            pad_inches=0.03,
            transparent=TRANSPARENT_BG,
        )
        print(f"[SAVE] {pdf}")

    if SAVE_SVG:
        svg = OUTDIR / f"{stem}.svg"
        fig.savefig(
            svg,
            bbox_inches="tight",
            pad_inches=0.03,
            transparent=TRANSPARENT_BG,
        )
        print(f"[SAVE] {svg}")


# =============================================================================
# Plotting
# =============================================================================

def plot_matrix(
    matrix: pd.DataFrame,
    title: str,
    colorbar_label: str,
    stem: str,
    cmap=LIGHT_ORANGE_CMAP,
    mode: str = "normalized",
    show_real_label: bool = True,
):
    values = matrix.to_numpy(dtype=float)

    fig, ax = plt.subplots(figsize=FIGSIZE)

    im = ax.imshow(
        values,
        cmap=cmap,
        aspect="equal",
        interpolation="nearest",
        vmin=0.0,
        vmax=1.0 if mode == "normalized" else max(1.0, float(np.nanmax(values))),
    )

    tick_labels = [display_name(x) for x in matrix.columns.tolist()]
    tick_labels_y = [display_name(x) for x in matrix.index.tolist()]

    ax.set_xticks(np.arange(len(tick_labels)))
    ax.set_yticks(np.arange(len(tick_labels_y)))

    ax.set_xticklabels(
        tick_labels,
        rotation=TICK_ROTATION,
        ha="right",
        rotation_mode="anchor",
    )
    ax.set_yticklabels(tick_labels_y)

    ax.set_title(title, fontsize=TITLE_SIZE, pad=6)
    ax.set_xlabel("Prediction label", fontsize=AXIS_LABEL_SIZE, labelpad=5)
    if show_real_label:
        ax.set_ylabel("Real label", fontsize=AXIS_LABEL_SIZE, labelpad=5)

    ax.set_xticks(np.arange(-0.5, values.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, values.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linestyle="-", linewidth=CELL_GRID_WIDTH)
    ax.tick_params(which="minor", bottom=False, left=False)

    style_axes(ax)

    cbar = fig.colorbar(im, ax=ax, fraction=0.042, pad=0.045)
    cbar.set_label(colorbar_label, fontsize=COLORBAR_LABEL_SIZE)
    cbar.ax.tick_params(labelsize=COLORBAR_TICK_SIZE)

    fig.subplots_adjust(left=0.23, right=0.92, bottom=0.26, top=0.88)

    save_figure(fig, stem)
    plt.close(fig)


# =============================================================================
# Input-file discovery
# =============================================================================

def resolve_input_csv() -> Path:
    if INPUT_CSV is not None:
        path = Path(INPUT_CSV)
        if not path.is_absolute():
            path = SCRIPT_DIR / path
        if not path.is_file():
            raise FileNotFoundError(f"Cannot find explicitly configured input CSV: {path}")
        return path

    preferred_names = [
        "test_sequence_predictions.csv",
        "sequence_predictions.csv",
        "test_predictions.csv",
        "test_sequence_predictions(5).csv",
    ]

    for name in preferred_names:
        path = SCRIPT_DIR / name
        if path.is_file():
            try:
                header = pd.read_csv(path, nrows=0)
                if {TRUE_COL, PRED_COL}.issubset(header.columns):
                    return path
            except Exception:
                pass

    candidate_files = sorted([p for p in SCRIPT_DIR.glob("*.csv") if p.is_file()])
    valid_candidates = []

    for path in candidate_files:
        try:
            header = pd.read_csv(path, nrows=0)
        except Exception:
            continue
        if {TRUE_COL, PRED_COL}.issubset(header.columns):
            valid_candidates.append(path)

    if len(valid_candidates) == 1:
        return valid_candidates[0]

    if len(valid_candidates) == 0:
        raise FileNotFoundError(
            "No suitable prediction CSV was found in:\n"
            f"  {SCRIPT_DIR}\n\n"
            "A valid file must contain both columns:\n"
            f"  {TRUE_COL}\n"
            f"  {PRED_COL}\n\n"
            "Either place the prediction CSV in this folder, or set INPUT_CSV explicitly."
        )

    priority = [
        p for p in valid_candidates
        if ("test" in p.name.lower() and "prediction" in p.name.lower())
    ]

    if len(priority) == 1:
        return priority[0]

    candidates_to_show = priority if priority else valid_candidates
    raise RuntimeError(
        "Multiple suitable prediction CSV files were found, so the script cannot safely choose one automatically:\n\n  - "
        + "\n  - ".join(str(p.name) for p in candidates_to_show)
        + "\n\nSet INPUT_CSV explicitly near the top of the script."
    )


# =============================================================================
# Main
# =============================================================================

def main():
    configure_fonts()
    report_font_status()

    input_csv = resolve_input_csv()
    print(f"[INPUT] {input_csv}")

    df = pd.read_csv(input_csv)

    required = {TRUE_COL, PRED_COL}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    df = df[[TRUE_COL, PRED_COL]].copy()
    df[TRUE_COL] = df[TRUE_COL].map(clean_label)
    df[PRED_COL] = df[PRED_COL].map(clean_label)
    df = df[(df[TRUE_COL] != "") & (df[PRED_COL] != "")].copy()

    order = get_class_order(df)
    counts, normalized, error_counts = build_matrices(df, order)

    counts.to_csv(OUTDIR / "DNA_type_confusion_matrix_counts.csv", encoding="utf-8-sig")
    normalized.to_csv(OUTDIR / "DNA_type_confusion_matrix_row_normalized.csv", encoding="utf-8-sig")
    error_counts.to_csv(OUTDIR / "DNA_type_confusion_matrix_error_counts.csv", encoding="utf-8-sig")

    print(f"[INFO] n_samples = {len(df):,}")
    print(f"[INFO] n_classes = {len(order)}")
    print(f"[INFO] output_dir = {OUTDIR}")

    plot_matrix(
        matrix=normalized,
        title="Confusion matrix",
        colorbar_label="Proportion",
        stem="DNA_type_confusion_matrix_normalized_lightOrange",
        cmap=LIGHT_ORANGE_CMAP,
        mode="normalized",
        show_real_label=True,
    )

    plot_matrix(
        matrix=error_counts,
        title="Error detection counts",
        colorbar_label="Counts",
        stem="DNA_type_confusion_matrix_error_counts_lightOrange",
        cmap=LIGHT_ORANGE_CMAP,
        mode="counts",
        show_real_label=False,
    )

    print("[DONE]")


if __name__ == "__main__":
    main()
