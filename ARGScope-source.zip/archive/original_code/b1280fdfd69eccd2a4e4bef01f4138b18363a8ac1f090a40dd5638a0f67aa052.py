"""Create the two standalone supplementary tables from the verified metrics."""
from pathlib import Path
import csv
import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
DATA = ROOT/'outputs/vf_bgc_binary_positive_20260922/data/all_metrics_binary_positive.csv'
COUNTS = ROOT/'outputs/vf_bgc_binary_positive_20260922/data/binary_confusion_counts.csv'
OUT = ROOT/'outputs/vf_bgc_supplement_tables_20260922'
NAME = 'Supplementary_Tables_19_20_VF_BGC_20260922.docx'
WIDTHS = [1.28,1.27,.77,.75,.80,.75,.73,.75]
METRICS = ['ACC','Precision','Recall','F1','MCC']


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as handle:
        return list(csv.DictReader(handle))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value):
    return str(Decimal(str(value)).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP))


def font(run, size=11, bold=False):
    run.font.name = 'Times New Roman'
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0,0,0)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.find(qn('w:rFonts'))
    if fonts is None:
        fonts = OxmlElement('w:rFonts')
        rpr.insert(0,fonts)
    for key in ['ascii','hAnsi','eastAsia','cs']:
        fonts.set(qn('w:'+key),'Times New Roman')


def cell_text(cell, text, bold=False):
    cell.text = ''
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_before = Pt(3.5)
    paragraph.paragraph_format.space_after = Pt(3.5)
    paragraph.paragraph_format.line_spacing = 1.05
    font(paragraph.add_run(text),bold=bold)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def border(cell, edge, size=5):
    properties = cell._tc.get_or_add_tcPr()
    borders = properties.find(qn('w:tcBorders'))
    if borders is None:
        borders = OxmlElement('w:tcBorders')
        properties.append(borders)
    node = OxmlElement('w:'+edge)
    node.set(qn('w:val'),'single')
    node.set(qn('w:sz'),str(size))
    node.set(qn('w:color'),'000000')
    borders.append(node)


def add_table(doc, domain, rows, table_number):
    full_name = 'virulence factor' if domain=='VF' else 'biosynthetic gene cluster'
    caption = doc.add_paragraph(style='Caption')
    caption.paragraph_format.keep_with_next = True
    caption.paragraph_format.space_after = Pt(10)
    caption.paragraph_format.space_before = Pt(0)
    caption.paragraph_format.line_spacing = 1.1
    font(caption.add_run(f'Table {table_number}. Performance of {domain}Scope on {full_name} ({domain}) datasets.'),12,True)
    table = doc.add_table(rows=15,cols=8)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    properties = table._tbl.tblPr
    table_borders = OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        tag = OxmlElement('w:'+edge)
        tag.set(qn('w:val'),'single' if edge=='bottom' else 'nil')
        if edge=='bottom':
            tag.set(qn('w:sz'),'10')
            tag.set(qn('w:color'),'000000')
        table_borders.append(tag)
    properties.append(table_borders)
    margins = OxmlElement('w:tblCellMar')
    for side,value in [('top',30),('bottom',30),('left',45),('right',45)]:
        tag = OxmlElement('w:'+side)
        tag.set(qn('w:w'),str(value))
        tag.set(qn('w:type'),'dxa')
        margins.append(tag)
    properties.append(margins)
    for col,width in zip(table.columns,WIDTHS):
        col.width = Inches(width)
    for row in table.rows:
        trpr = row._tr.get_or_add_trPr()
        trpr.append(OxmlElement('w:cantSplit'))
        for cell,width in zip(row.cells,WIDTHS):
            cell.width = Inches(width)
    for cell,label in zip(table.rows[0].cells,
                          ['Model','Prediction task','Average',*METRICS]):
        cell_text(cell,label,True)
        border(cell,'top',10)
        border(cell,'bottom',6)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    expected = []
    for offset,mod in enumerate(['AA','NT']):
        model = f'{domain}Scope-{mod}'
        selected = [row for row in rows if row['Model']==model]
        assert len(selected)==7
        assert [(r['Task'],r['Average']) for r in selected] == [
            ('Binary','binary'),('Type','macro'),('Type','weighted'),('Type','micro'),
            ('Subtype','macro'),('Subtype','weighted'),('Subtype','micro')]
        start = 1+offset*7
        for i,row in enumerate(selected,start):
            task = f'{domain}/non-{domain}' if row['Task']=='Binary' else row['Task']
            average = '-' if row['Task']=='Binary' else row['Average']
            values = [model,task,average]+[number(row[key]) for key in METRICS]
            for cell,value in zip(table.rows[i].cells,values):
                cell_text(cell,value)
            expected.append(values)
        merged = table.cell(start,0).merge(table.cell(start+6,0))
        cell_text(merged,model)
        for group_start,label in [(start+1,'Type'),(start+4,'Subtype')]:
            merged = table.cell(group_start,1).merge(table.cell(group_start+2,1))
            cell_text(merged,label)
            for column,key in [(3,'ACC'),(7,'MCC')]:
                group = selected[1:4] if label=='Type' else selected[4:7]
                assert len({r[key] for r in group})==1
                merged = table.cell(group_start,column).merge(table.cell(group_start+2,column))
                cell_text(merged,number(group[0][key]))
        if offset==1:
            for cell in table.rows[start].cells:
                border(cell,'top',5)
    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(9)
    note.paragraph_format.space_after = Pt(0)
    note.paragraph_format.line_spacing = 1.08
    positive_types,positive_subtypes = (14,866) if domain=='VF' else (7,49)
    text = (
        f'AA and NT denote protein- and nucleotide-based models. {domain} is the positive class '
        f'and non-{domain} is the negative class for binary classification. Binary precision, recall '
        f'and F1 refer to the positive class, and "-" indicates that averaging is not applicable. '
        f'Type evaluation includes {positive_types} {domain} types plus non-{domain}, and subtype '
        f'evaluation includes {positive_subtypes} {domain} subtypes plus non-{domain}. Both use all '
        'test sequences, including false positives and missed detections. Macro averages weight '
        'labels equally, weighted averages use label support, and micro averages pool class counts. '
        'ACC and MCC do not depend on averaging. Values are rounded to four decimal places.')
    font(note.add_run('Note. '),10.5,True)
    font(note.add_run(text),10.5)
    return expected


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    sources = {str(path):sha(path) for path in [DATA,COUNTS]}
    rows = read_csv(DATA)
    assert len(rows)==28
    for count in read_csv(COUNTS):
        binary = next(row for row in rows if row['Model']==count['Model'] and row['Task']=='Binary')
        tp,fp,fn = [int(count[key]) for key in ['TP','FP','FN']]
        for key,value in [('Precision',tp/(tp+fp)),('Recall',tp/(tp+fn)),('F1',2*tp/(2*tp+fp+fn))]:
            assert abs(float(binary[key])-value)<1e-12
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.left_margin = section.right_margin = Inches(.70)
    section.top_margin = section.bottom_margin = Inches(.75)
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(11)
    style.font.color.rgb = RGBColor(0,0,0)
    style.paragraph_format.space_after = Pt(0)
    doc.core_properties.title = 'Supplementary performance metrics for VF and BGC annotation'
    doc.core_properties.subject = 'Tables 19 and 20 with positive-class binary metrics'
    doc.core_properties.author = ''
    doc.core_properties.last_modified_by = ''
    expected = []
    for i,domain in enumerate(['VF','BGC']):
        if i:
            doc.add_page_break()
        expected.append(add_table(doc,domain,rows,19+i))
    output = OUT/NAME
    doc.save(output)
    restored = Document(output)
    assert len(restored.tables)==2
    for table,wanted in zip(restored.tables,expected):
        assert len(table.rows)==15 and len(table.columns)==8
        for row,values in zip(table.rows[1:],wanted):
            assert [cell.text for cell in row.cells]==values,([cell.text for cell in row.cells],values)
    assert all(sha(Path(path))==value for path,value in sources.items())
    (OUT/'verification.json').write_text(json.dumps({'Source_files':sources,'Tables':2,
        'Metric_rows':28,'Binary_rows':4,'Numeric_values_checked':140,
        'All_values_match_verified_CSV':True,'Binary_positive_class_verified_from_counts':True,
        'Type_subtype_include_negative_class':True,'Source_files_unmodified':True},indent=2),encoding='utf-8')
    print(str(output))


if __name__=='__main__':
    main()
