"""Select types by precision only; display P/R/F1 without changing source results."""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'outputs/novel_gene_type_heatmaps_20260923/data/Novel_gene_per_type_precision_recall_F1.csv'
PREDICTIONS = Path('E:/1. ARGmodel/1. NonARG_training/new model result8.24/5. novel gene')
OUT = ROOT / 'outputs/novel_gene_selected_precision_PRF1_20260925'
NAME = 'Novel_gene_selected_precision_PRF1'
METRICS = [('Precision', '#317E91', 'o', -.20),
           ('Recall', '#C68D2D', '^', 0),
           ('F1', '#8870A4', 'D', .20)]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(SOURCE, keep_default_na=False)
    hashes = {str(SOURCE): digest(SOURCE)}
    selected = frame.loc[frame.Support.gt(0) & frame.Precision.ge(.95)].copy()
    assert selected.groupby('Modality').size().to_dict() == {'AA': 6, 'NT': 2}
    audits = []
    for mod, folder in [('AA', '1.Protein_novel_gene_100pct'), ('NT', '2.DNA_novel_gene_100pct')]:
        source = PREDICTIONS / folder / 'test_sequence_predictions.csv'
        hashes[str(source)] = digest(source)
        raw = pd.read_csv(source, keep_default_na=False)
        assert raw.sequence_id.is_unique and len(raw) == 4494
        actual = raw.loc[raw.true_ARG.eq(1)].copy()
        assert len(actual) == 2247 and actual.novel_ARG_subtype.eq(1).all()
        assert actual.split.eq('test').all()
        for record in frame.loc[frame.Modality.eq(mod)].to_dict('records'):
            pred_mask = actual.predicted_type.eq(record['Type'])
            true_mask = actual.true_type.eq(record['Type'])
            tp, predicted, support = int((pred_mask & true_mask).sum()), int(pred_mask.sum()), int(true_mask.sum())
            precision = tp / predicted if predicted else 0.
            recall = tp / support if support else 0.
            f1 = 2 * tp / (predicted + support) if predicted + support else 0.
            assert (tp, predicted, support) == (record['TP'], record['Predicted'], record['Support'])
            for metric, value in [('Precision', precision), ('Recall', recall), ('F1', f1)]:
                assert abs(value - record[metric]) < 1e-12, (mod, record['Type'], metric)
        audits.append({'modality': mod, 'reference_ARG_n': 2247, 'supported_types': 16,
                       'selected_types': int(selected.Modality.eq(mod).sum()), 'source': str(source)})
    selected = selected.sort_values(['Modality', 'Precision', 'Predicted'], ascending=[True, False, False])
    columns = ['Model', 'Type_display', 'Precision', 'Recall', 'F1', 'TP', 'Predicted', 'Support', 'Scope']
    selected[columns].to_csv(OUT / 'Selected_precision_ge_095_with_recall_F1.csv', index=False, encoding='utf-8-sig')
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'text.color': '#203746',
                         'axes.labelcolor': '#203746', 'xtick.color': '#506473',
                         'ytick.color': '#203746', 'svg.hashsalt': 'novel-selected-prf1-20260925'})
    fig = plt.figure(figsize=(10.80, 6.60), dpi=160, facecolor='none')
    fig.text(.025, .978, 'Resistance-type assignments to unseen ARG subtypes',
             ha='left', va='top', fontsize=16, weight='bold')
    fig.text(.025, .926, 'Categories selected by precision ≥ 0.95; recall and F1 shown for the selected categories',
             fontsize=11.2, va='top')
    handles = [Line2D([], [], color=color, marker=marker, ls='none', markersize=6.3, label=metric)
               for metric, color, marker, _ in METRICS]
    fig.legend(handles=handles, loc='center right', bbox_to_anchor=(.983, .865), frameon=False,
               ncol=3, handletextpad=.5, columnspacing=1.6, fontsize=11.3)
    for mod, title_y, bottom, height in [('AA', .855, .440, .350), ('NT', .362, .185, .350 / 3)]:
        subset = selected.loc[selected.Modality.eq(mod)]
        n = len(subset)
        fig.text(.025, title_y, f'ARGScope-{mod} ({"protein" if mod == "AA" else "DNA"})',
                 fontsize=13.2, weight='bold', va='top')
        ax = fig.add_axes([.205, bottom, .400, height], facecolor='none')
        ax.set_xlim(-.01, 1.035)
        ax.set_ylim(n - .5, -.5)
        ax.set_yticks(np.arange(n), subset.Type_display.tolist(), fontsize=11.6)
        ax.tick_params(axis='y', length=0, pad=9)
        ax.set_xticks([0, .25, .5, .75, 1], ['0', '0.25', '0.50', '0.75', '1.00'], fontsize=10)
        ax.tick_params(axis='x', length=3, pad=4, color='#AAB8C1')
        if mod == 'NT':
            ax.set_xlabel('Score', fontsize=11, labelpad=6)
        ax.grid(axis='x', color='#E5EAED', lw=.7, zorder=0)
        for spine in ['top', 'left', 'right']:
            ax.spines[spine].set_visible(False)
        ax.spines['bottom'].set_color('#9BA9B3')
        ax.spines['bottom'].set_linewidth(.7)
        for i, row in enumerate(subset.itertuples()):
            y = bottom + height * (1 - (i + .5) / n)
            for (metric, color, marker, offset), x in zip(METRICS, [.676, .762, .840]):
                val = getattr(row, metric)
                ax.hlines(i + offset, 0, val, color=color, alpha=.20, lw=.75, zorder=2)
                ax.scatter(val, i + offset, s=40, marker=marker, color=color,
                           edgecolor='white', linewidth=.5, zorder=4)
                fig.text(x, y, f'{val:.4f}', fontsize=11.8, ha='center', va='center',
                         weight='bold' if metric == 'Precision' else 'normal', color=color)
            fig.text(.944, y, f'{row.TP} / {row.Predicted}', fontsize=11.1, ha='center', va='center')
        label_y = bottom + height + .014
        for (metric, color, _, _), x in zip(METRICS, [.676, .762, .840]):
            fig.text(x, label_y, metric, color=color, fontsize=10.5, ha='center')
        fig.text(.944, label_y, 'Correct / predicted', fontsize=9.6, ha='center')
    fig.text(.025, .078, 'Evaluated on reference ARG sequences only (n = 2,247). Selection is applied separately to each model.',
             fontsize=10, va='top')
    fig.text(.025, .043, 'Counts: correct assignments / all predictions of that type within the evaluated set.',
             fontsize=10, va='top')
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    clipped = []
    for text in fig.findobj(match=Text):
        if text.get_visible() and text.get_text():
            b = text.get_window_extent(renderer)
            if b.width and b.height and (b.x0 < -1 or b.y0 < -1 or b.x1 > width + 1 or b.y1 > height + 1):
                clipped.append(text.get_text())
    assert not clipped, clipped
    with plt.rc_context({'svg.fonttype': 'path'}):
        fig.savefig(OUT / (NAME + '.svg'), transparent=True)
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / (NAME + '_editable.svg'), transparent=True)
    fig.savefig(OUT / (NAME + '_transparent.tif'), dpi=300, transparent=True,
                pil_kwargs={'compression': 'tiff_lzw'})
    with Image.open(OUT / (NAME + '_transparent.tif')) as im:
        assert im.size == (3240, 1980)
        assert all(float(v) == 300 for v in im.info['dpi'])
        rgba = im.convert('RGBA')
        assert rgba.getchannel('A').getextrema() == (0, 255)
    bg = Image.new('RGBA', rgba.size, 'white')
    bg.alpha_composite(rgba)
    bg.convert('RGB').save(OUT / (NAME + '_white.tif'), compression='tiff_lzw', dpi=(300, 300))
    preview = bg.convert('RGB')
    preview.thumbnail((1728, 1056), Image.Resampling.LANCZOS)
    preview.save(OUT / (NAME + '_preview.png'))
    plt.close(fig)
    assert all(digest(Path(path)) == value for path, value in hashes.items())
    report = {'selection': 'Support > 0 and per-type Precision >= 0.95, independently for AA and NT',
              'scope': '2,247 reference ARG sequences, subtype-disjoint test set',
              'metrics_displayed': ['Precision', 'Recall', 'F1'],
              'recall_and_F1_used_for_selection': False, 'source_files_unchanged': True,
              'all_original_results_retained': True, 'test_populations_changed': False,
              'outside_canvas': clipped, 'source_sha256': hashes, 'sequence_level_checks': audits,
              'tif_dimensions': [3240, 1980], 'tif_dpi': [300, 300]}
    (OUT / 'verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / Path(__file__).name)
    print(json.dumps({'output': str(OUT), 'selected': selected[columns].to_dict('records')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
