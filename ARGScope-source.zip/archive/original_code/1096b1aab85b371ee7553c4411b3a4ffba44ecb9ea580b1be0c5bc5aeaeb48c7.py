#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SARG protein subtype 筛选，并同步提取对应 DNA（PyCharm 直接运行版）。

步骤：
1. 统计 protein structure 中每个 Subtype 的 protein 数量。
2. 保留数量 >= MIN_SUBTYPE_COUNT 的 Subtype 及其 protein。
3. 根据 protein SARG.Seq.ID == nucleotide structure AminoAcidID 建立映射。
4. 提取所有对应的 NucleotideID、DNA structure 行和 DNA FASTA 序列。
5. 输出没有 DNA 映射的已保留 protein 清单，并明确报告缺少多少条。

只使用 Python 标准库，不需要安装 pandas 或 Biopython。
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


# =============================================================================
# 只需修改这里
# 把本脚本和四个输入文件放在同一文件夹，通常无需再改路径。
# =============================================================================
PROTEIN_FASTA = "3.SARG_v3.2_20220917_Long_subdatabase.fasta"
PROTEIN_STRUCTURE = "3.SARG_v3.2_20220917_Long_subdatabase_structure.txt"

DNA_FASTA = "Nucleotide_SARG_v3.2_Long.fasta"
DNA_STRUCTURE = "Nucleotide_SARG_v3.2_Long_structure.txt"

# 仅保留 protein 数量大于等于该值的 subtype。
MIN_SUBTYPE_COUNT = 3

# 输出文件夹；相对路径以本脚本所在目录为基准。
OUTPUT_DIR = "SARG_subtype_ge3_with_DNA"


SCRIPT_DIR = Path(__file__).resolve().parent


def resolve_path(value: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(f"找不到输入文件：{path}")
    return path


def read_fasta(path: Path, description: str):
    """读取 FASTA；ID 使用标题中第一个空白前的完整字段。"""
    order = []
    records = {}
    current_id = None
    current_header = ""
    chunks = []

    def save_record():
        nonlocal current_id, current_header, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"{description} FASTA 存在重复 ID：{current_id}")
        records[current_id] = (current_header, "".join(chunks).replace(" ", ""))
        order.append(current_id)

    with path.open("r", encoding="utf-8-sig") as handle:
        for line_no, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                save_record()
                current_header = line[1:].strip()
                if not current_header:
                    raise ValueError(f"{path.name} 第 {line_no} 行 FASTA 标题为空")
                current_id = current_header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(
                        f"{path.name} 第 {line_no} 行在第一个 FASTA 标题前出现序列"
                    )
                chunks.append(line)
        save_record()

    return order, records


def read_tsv(path: Path, required_columns: set[str], description: str):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None:
            raise ValueError(f"{description} structure 文件没有表头")
        fieldnames = list(reader.fieldnames)
        missing = required_columns - set(fieldnames)
        if missing:
            raise ValueError(f"{description} structure 缺少列：{sorted(missing)}")
        rows = list(reader)
    return fieldnames, rows


def ensure_unique_nonempty(values, description: str):
    if any(not value for value in values):
        raise ValueError(f"{description} 中存在空 ID")
    duplicates = [value for value, count in Counter(values).items() if count > 1]
    if duplicates:
        raise ValueError(f"{description} 中存在重复 ID，例如：{duplicates[:5]}")


def verify_same_ids(fasta_ids: set[str], structure_ids: set[str], description: str):
    fasta_only = sorted(fasta_ids - structure_ids)
    structure_only = sorted(structure_ids - fasta_ids)
    if fasta_only or structure_only:
        raise ValueError(
            f"{description} FASTA 与 structure ID 不能完全对应：\n"
            f"  仅 FASTA 中存在：{len(fasta_only)}，例如 {fasta_only[:5]}\n"
            f"  仅 structure 中存在：{len(structure_only)}，例如 {structure_only[:5]}"
        )


def write_tsv(path: Path, fieldnames, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def wrap_sequence(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def write_fasta(path: Path, original_order, records, retained_ids: set[str]):
    written_ids = set()
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record_id in original_order:
            if record_id not in retained_ids:
                continue
            header, sequence = records[record_id]
            handle.write(f">{header}\n{wrap_sequence(sequence)}\n")
            written_ids.add(record_id)
    if written_ids != retained_ids:
        missing = sorted(retained_ids - written_ids)
        raise RuntimeError(f"写出 FASTA 时缺少 {len(missing)} 个 ID，例如：{missing[:5]}")


def main():
    if MIN_SUBTYPE_COUNT < 1:
        raise ValueError("MIN_SUBTYPE_COUNT 必须大于等于 1")

    protein_fasta_path = resolve_path(PROTEIN_FASTA)
    protein_structure_path = resolve_path(PROTEIN_STRUCTURE)
    dna_fasta_path = resolve_path(DNA_FASTA)
    dna_structure_path = resolve_path(DNA_STRUCTURE)

    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    prefix = f"subtype_ge{MIN_SUBTYPE_COUNT}"
    output_protein_fasta = output_dir / f"SARG_protein_{prefix}.fasta"
    output_protein_structure = output_dir / f"SARG_protein_{prefix}_structure.txt"
    output_dna_fasta = output_dir / f"SARG_DNA_for_protein_{prefix}.fasta"
    output_dna_structure = output_dir / f"SARG_DNA_for_protein_{prefix}_structure.txt"
    output_subtype_counts = output_dir / f"SARG_subtype_counts_min{MIN_SUBTYPE_COUNT}.csv"
    output_mapping = output_dir / f"SARG_protein_DNA_mapping_{prefix}.csv"
    output_missing = output_dir / f"SARG_proteins_without_DNA_{prefix}.csv"
    output_missing_fasta = output_dir / f"SARG_proteins_without_DNA_{prefix}.fasta"
    output_summary = output_dir / f"SARG_filter_summary_min{MIN_SUBTYPE_COUNT}.txt"

    print("=" * 100)
    print(f"SARG protein/DNA filtering: retain protein subtype count >= {MIN_SUBTYPE_COUNT}")
    print("=" * 100)
    print(f"Protein FASTA     : {protein_fasta_path}")
    print(f"Protein structure : {protein_structure_path}")
    print(f"DNA FASTA         : {dna_fasta_path}")
    print(f"DNA structure     : {dna_structure_path}")
    print(f"Output directory  : {output_dir}")

    protein_order, protein_records = read_fasta(protein_fasta_path, "protein")
    dna_order, dna_records = read_fasta(dna_fasta_path, "DNA")

    protein_fields, protein_rows = read_tsv(
        protein_structure_path, {"SARG.Seq.ID", "Type", "Subtype"}, "protein"
    )
    dna_fields, dna_rows = read_tsv(
        dna_structure_path, {"AminoAcidID", "NucleotideID", "Type", "Subtype"}, "DNA"
    )

    protein_structure_ids = [row["SARG.Seq.ID"].strip() for row in protein_rows]
    nucleotide_structure_ids = [row["NucleotideID"].strip() for row in dna_rows]
    ensure_unique_nonempty(protein_structure_ids, "protein structure 的 SARG.Seq.ID")
    ensure_unique_nonempty(nucleotide_structure_ids, "DNA structure 的 NucleotideID")

    verify_same_ids(set(protein_records), set(protein_structure_ids), "protein")
    verify_same_ids(set(dna_records), set(nucleotide_structure_ids), "DNA")

    # 1. 按原始 protein 数量筛选 subtype。
    subtype_counts = Counter(row["Subtype"].strip() for row in protein_rows)
    if "" in subtype_counts:
        raise ValueError(f"protein structure 中存在 {subtype_counts['']} 条空 Subtype")
    retained_subtypes = {
        subtype for subtype, count in subtype_counts.items()
        if count >= MIN_SUBTYPE_COUNT
    }
    retained_protein_rows = [
        row for row in protein_rows if row["Subtype"].strip() in retained_subtypes
    ]
    retained_protein_ids = {
        row["SARG.Seq.ID"].strip() for row in retained_protein_rows
    }

    # 用于核对 protein 和 DNA structure 中的 Type/Subtype。
    protein_labels = {
        row["SARG.Seq.ID"].strip(): (row["Type"].strip(), row["Subtype"].strip())
        for row in protein_rows
    }

    # 2. 通过 AminoAcidID 筛选 DNA structure；一个 protein 可对应多条 DNA。
    retained_dna_rows = []
    protein_to_dna_ids = defaultdict(list)
    type_mismatches = []
    subtype_mismatches = []

    for row in dna_rows:
        protein_id = row["AminoAcidID"].strip()
        dna_id = row["NucleotideID"].strip()
        if protein_id not in retained_protein_ids:
            continue

        retained_dna_rows.append(row)
        protein_to_dna_ids[protein_id].append(dna_id)

        expected_type, expected_subtype = protein_labels[protein_id]
        if row["Type"].strip() != expected_type:
            type_mismatches.append((protein_id, dna_id))
        if row["Subtype"].strip() != expected_subtype:
            subtype_mismatches.append((protein_id, dna_id))

    retained_dna_ids = {row["NucleotideID"].strip() for row in retained_dna_rows}
    proteins_with_dna = set(protein_to_dna_ids)
    proteins_without_dna = retained_protein_ids - proteins_with_dna

    # 3. 写出四个主体文件，并再次核验输出 ID。
    write_tsv(output_protein_structure, protein_fields, retained_protein_rows)
    write_fasta(output_protein_fasta, protein_order, protein_records, retained_protein_ids)
    write_tsv(output_dna_structure, dna_fields, retained_dna_rows)
    write_fasta(output_dna_fasta, dna_order, dna_records, retained_dna_ids)

    # 4. Subtype 数量统计。
    with output_subtype_counts.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Subtype", "original_protein_count", "retained"])
        for subtype, count in sorted(subtype_counts.items(), key=lambda x: (-x[1], x[0])):
            writer.writerow([subtype, count, "Yes" if subtype in retained_subtypes else "No"])

    # 5. 每条已保留 protein 的 DNA 覆盖与候选 ID。
    protein_rows_by_id = {row["SARG.Seq.ID"].strip(): row for row in protein_rows}
    with output_mapping.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "protein_id", "Type", "Subtype", "DNA_available",
            "DNA_candidate_count", "NucleotideIDs"
        ])
        for protein_id in protein_order:
            if protein_id not in retained_protein_ids:
                continue
            row = protein_rows_by_id[protein_id]
            dna_ids = protein_to_dna_ids.get(protein_id, [])
            writer.writerow([
                protein_id,
                row["Type"].strip(),
                row["Subtype"].strip(),
                "Yes" if dna_ids else "No",
                len(dna_ids),
                ";".join(dna_ids),
            ])

    # 6. 缺少 DNA 的 protein 清单。
    with output_missing.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["protein_id", "Type", "Subtype", "reason"])
        for protein_id in protein_order:
            if protein_id not in proteins_without_dna:
                continue
            row = protein_rows_by_id[protein_id]
            writer.writerow([
                protein_id,
                row["Type"].strip(),
                row["Subtype"].strip(),
                "No AminoAcidID mapping in nucleotide structure",
            ])

    # 同步输出缺少 DNA 的 protein FASTA，保持原始完整标题、序列和记录顺序。
    write_fasta(
        output_missing_fasta,
        protein_order,
        protein_records,
        proteins_without_dna,
    )

    retained_subtype_count = len(retained_subtypes)
    removed_subtype_count = len(subtype_counts) - retained_subtype_count
    missing_count = len(proteins_without_dna)
    coverage_pct = (
        100.0 * len(proteins_with_dna) / len(retained_protein_ids)
        if retained_protein_ids else 0.0
    )

    summary_lines = [
        f"minimum_subtype_count\t{MIN_SUBTYPE_COUNT}",
        f"input_protein_records\t{len(protein_rows)}",
        f"input_unique_subtypes\t{len(subtype_counts)}",
        f"retained_protein_records\t{len(retained_protein_ids)}",
        f"retained_unique_subtypes\t{retained_subtype_count}",
        f"removed_protein_records\t{len(protein_rows) - len(retained_protein_ids)}",
        f"removed_unique_subtypes\t{removed_subtype_count}",
        f"retained_proteins_with_DNA\t{len(proteins_with_dna)}",
        f"retained_proteins_without_DNA\t{missing_count}",
        f"proteins_without_DNA_FASTA_records\t{missing_count}",
        f"protein_DNA_coverage_percent\t{coverage_pct:.4f}",
        f"retained_DNA_records\t{len(retained_dna_ids)}",
        f"retained_DNA_structure_rows\t{len(retained_dna_rows)}",
        f"type_label_mismatches\t{len(type_mismatches)}",
        f"subtype_label_mismatches\t{len(subtype_mismatches)}",
        "protein_FASTA_structure_IDs_identical\tTrue",
        "DNA_FASTA_structure_IDs_identical\tTrue",
    ]
    output_summary.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n" + "=" * 100)
    print("FILTER COMPLETED")
    print("=" * 100)
    print(f"Original proteins               : {len(protein_rows)}")
    print(f"Original unique subtypes        : {len(subtype_counts)}")
    print(f"Retained proteins               : {len(retained_protein_ids)}")
    print(f"Retained unique subtypes        : {retained_subtype_count}")
    print(f"Proteins with >=1 DNA           : {len(proteins_with_dna)}")
    print(f"Proteins without DNA (shortage) : {missing_count}")
    print(f"Protein DNA coverage            : {coverage_pct:.4f}%")
    print(f"Retained DNA records            : {len(retained_dna_ids)}")
    print(f"Type label mismatches           : {len(type_mismatches)}")
    print(f"Subtype label mismatches        : {len(subtype_mismatches)}")
    print("Protein FASTA/structure IDs     : identical")
    print("DNA FASTA/structure IDs         : identical")
    print("\nOutput files:")
    for path in [
        output_protein_fasta,
        output_protein_structure,
        output_dna_fasta,
        output_dna_structure,
        output_mapping,
        output_missing,
        output_missing_fasta,
        output_subtype_counts,
        output_summary,
    ]:
        print(f"  {path}")


if __name__ == "__main__":
    main()
