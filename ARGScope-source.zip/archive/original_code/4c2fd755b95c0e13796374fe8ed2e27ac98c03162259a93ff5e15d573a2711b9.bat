@echo off
setlocal
chcp 65001 >nul
set "PY=D:\Anaconda\envs\dnabert2_5060\python.exe"
for %%I in ("%~dp0..") do set "DATA=%%~fI"
pushd "%~dp0"
if not exist "%PY%" goto missing_python
if not exist "%DATA%\Long_fusion_subtype2_newsplit\long_fusion_subtype2_newsplit.pt" goto missing_full
if not exist "%DATA%\Refined_subtype_prototypes_subtype2_newsplit\refined_ARG_subtype_prototypes_residual_GAT.pt" goto missing_full

"%PY%" -u "ablations\wo_transfer\04_protein_student_wo_transfer.py"
if errorlevel 1 goto failed
"%PY%" -u "ablations\wo_transfer\05_dna_student_wo_transfer.py"
if errorlevel 1 goto failed

echo.
echo W/O KNOWLEDGE TRANSFER COMPLETED.
pause
exit /b 0

:missing_python
echo Python not found: %PY%
pause
exit /b 2

:missing_full
echo Missing Full fusion/refined prototype outputs. Run 01_run_full_all.bat first.
pause
exit /b 3

:failed
echo.
echo W/O KNOWLEDGE TRANSFER STOPPED AFTER AN ERROR.
pause
exit /b 1
