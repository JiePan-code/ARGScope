"""Protein Student using the full no-gate upstream chain."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, load_base, mark_saved_ablation, set_common_student_defaults

DATA = Path(__file__).resolve().parents[3]
m = load_base("04_protein_student.py", "protein_wo_gate_base")
set_common_student_defaults(m, DATA, "protein", "Protein_student_subtype2_newsplit_wo_gate")
m.DEFAULT_FUSION_PT = DATA / "Long_fusion_subtype2_nogate" / "long_fusion_subtype2_nogate.pt"
m.DEFAULT_REFINED_PT = DATA / "Refined_subtype_prototypes_subtype2_nogate" / "refined_ARG_subtype_prototypes_residual_GAT.pt"
mark_saved_ablation(m, "w/o Adaptive Gating", "learned gate MLP; fixed 0.5/0.5 fusion upstream")
add_default_structure(DATA)
m.main()
