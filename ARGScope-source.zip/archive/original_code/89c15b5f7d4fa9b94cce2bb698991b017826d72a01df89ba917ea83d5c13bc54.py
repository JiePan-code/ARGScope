"""Create a new three-ink, editable schematic icon library.

The two supplied screenshots are visual references only. No screenshot is edited,
and none of the icons represents measured structural or experimental data.
"""
from pathlib import Path
from html import escape
import json
import math
import hashlib
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs' / 'ARGScope_iconkit_3color_20260929'
SVG = OUT / 'SVG'
BLUE, TEAL, INK = '#3478AE', '#259B91', '#283743'
PALETTE = {'AA / protein': BLUE, 'NT / nucleotide': TEAL, 'Shared / text / training': INK}
ICONS = []


def path(d, color=INK, sw=4, fill='none', opacity=1, dash=None):
    extra = f' stroke-dasharray="{dash}"' if dash else ''
    return f'<path d="{d}" fill="{fill}" stroke="{color}" stroke-width="{sw}" opacity="{opacity}" stroke-linecap="round" stroke-linejoin="round"{extra}/>'


def line(x1, y1, x2, y2, color=INK, sw=4, opacity=1, dash=None):
    return path(f'M{x1},{y1} L{x2},{y2}', color, sw, opacity=opacity, dash=dash)


def rect(x, y, w, h, color=INK, radius=8, opacity=.10, sw=3):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{color}" fill-opacity="{opacity}"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="none" stroke="{color}" stroke-width="{sw}"/>')


def circle(x, y, r, color=INK, opacity=.14, sw=3):
    return (f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" fill-opacity="{opacity}"/>'
            f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="{color}" stroke-width="{sw}"/>')


def text(x, y, s, size=24, color=INK, weight=400, anchor='middle'):
    return f'<text x="{x}" y="{y}" fill="{color}" font-family="Arial,Helvetica,sans-serif" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}">{escape(s)}</text>'


def arrow(x1, y1, x2, y2, color=INK, dash=None, sw=4, both=False):
    a = math.atan2(y2-y1, x2-x1)
    def tip(x, y, ang):
        q = []
        for v in [-.48, .48]:
            q.append((x-13*math.cos(ang+v), y-13*math.sin(ang+v)))
        return path(f'M{q[0][0]},{q[0][1]} L{x},{y} L{q[1][0]},{q[1][1]}', color, sw)
    return line(x1,y1,x2,y2,color,sw,dash=dash) + tip(x2,y2,a) + (tip(x1,y1,a+math.pi) if both else '')


def star(cx, cy, r=24, color=INK, open_fill=False):
    pts = []
    for k in range(10):
        rr = r if k % 2 == 0 else r*.45
        a = -math.pi/2 + k*math.pi/5
        pts.append((cx+rr*math.cos(a), cy+rr*math.sin(a)))
    d = 'M' + ' L'.join(f'{x:.3f},{y:.3f}' for x,y in pts) + ' Z'
    return path(d,color,2.6,fill='none' if open_fill else color)


def group(body, x=0, y=0, scale=1, rotate=0):
    return f'<g transform="translate({x} {y}) rotate({rotate}) scale({scale})">{body}</g>'


def dots(x, y, vertical=False, color=INK):
    return ''.join(f'<circle cx="{x+(0 if vertical else j*10)}" cy="{y+(j*10 if vertical else 0)}" r="2.3" fill="{color}"/>' for j in range(3))


def svg_doc(w, h, body, title, description='Editable schematic icon; not experimental data.'):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}px" height="{h}px" viewBox="0 0 {w} {h}" role="img">'
            f'<title>{escape(title)}</title><desc>{escape(description)}</desc>{body}</svg>')


def add(slug, en, cn, body, w=256, h=224, category='icons', reference='Figure 1 / Figure 2', note=''):
    n = len(ICONS)+1
    filename = f'{n:02d}_{slug}'
    doc = svg_doc(w,h,body,en)
    ET.fromstring(doc)
    colors = set(re.findall(r'#[0-9A-Fa-f]{6}',doc))
    assert colors <= {BLUE,TEAL,INK}, (slug,colors)
    SVG.mkdir(parents=True, exist_ok=True)
    (SVG/f'{filename}.svg').write_text(doc,encoding='utf-8')
    ICONS.append(dict(number=n,file=filename,title=en,chinese=cn,category=category,width=w,height=h,
                      reference=reference,note=note,body=body))


def protein():
    # Original abstract ribbon drawing, with four alpha-helical segments and coils.
    b = path('M68,42 C35,9 10,58 36,76 C57,91 19,107 35,136 C48,162 25,184 53,199 C79,214 87,179 111,183 C139,188 144,221 174,201 C204,181 181,164 202,150 C228,129 225,92 198,86 C174,82 206,54 181,33 C155,11 139,40 119,33 C102,25 87,14 68,42',BLUE,3.5)
    b += path('M44,112 C77,114 69,72 101,74 C127,77 131,128 161,120 C186,115 183,82 205,93',BLUE,3,opacity=.5)
    def helix(x,y,length,rotation):
        body=''
        for j in range(5):
            yy=j*length/5
            hh=length/5
            body+=path(f'M-14,{yy} C-14,{yy+hh*.28} 14,{yy+hh*.72} 14,{yy+hh} L14,{yy+hh+7} C14,{yy+hh*.72+7} -14,{yy+hh*.28+7} -14,{yy+7} Z',BLUE,1.4,BLUE,.90)
            body+=path(f'M14,{yy+hh} C14,{yy+hh*.78} -14,{yy+hh*.35} -14,{yy}',BLUE,3,opacity=.38)
        return group(body,x,y,1,rotation)
    b += helix(69,48,81,-22)
    b += helix(117,35,99,14)
    b += helix(171,93,86,22)
    b += helix(102,127,62,-39)
    return b


def dna():
    b=''
    cx, amp, y0, length=128,41,23,178
    def xx(y,phase=0):
        return cx+amp*math.sin((y-y0)/length*math.pi*4.8+phase)
    for y in range(y0+8,y0+int(length),10):
        x1,x2=xx(y),xx(y,math.pi)
        b+=line(x1,y,x2,y,TEAL,3,opacity=.5)
    for phase in [0,math.pi]:
        pts=[(xx(y0+j*length/200,phase),y0+j*length/200) for j in range(201)]
        d='M'+' L'.join(f'{x:.2f},{y:.2f}' for x,y in pts)
        b+=path(d,TEAL,7)
    return b


def tensor(color=BLUE, vertical=True, mixed=False, norm=False):
    b=''
    if vertical:
        for j in range(7):
            cc=(BLUE if j<3 else TEAL if j>3 else INK) if mixed else color
            b+=rect(29+j*29,55,19,114,cc,2,.22+(j%3)*.19,2.2)
        if norm:
            b+=path('M22,42 L15,42 L15,182 L22,182 M234,42 L241,42 L241,182 L234,182',INK,3)
    else:
        for j in range(4):
            y=37+j*38
            b+=path(f'M49,{y+12} L183,{y+12} L204,{y} L70,{y} Z',color,2.0,color,.3)
            b+=path(f'M49,{y+12} L183,{y+12} L183,{y+29} L49,{y+29} Z',color,2.0,color,.65)
            b+=path(f'M183,{y+12} L204,{y} L204,{y+17} L183,{y+29} Z',color,2,color,.95)
    return b


def network(color=INK, attention=False, mlp=False):
    b=''
    if mlp:
        pts=[(45,67),(45,151),(127,38),(127,112),(127,187),(211,73),(211,151)]
        edges=[(a,c) for a in range(2) for c in range(2,5)]+[(a,c) for a in range(2,5) for c in range(5,7)]
    else:
        pts=[(52,57),(132,28),(211,72),(211,163),(126,195),(42,152),(126,107)]
        edges=[(0,1),(1,2),(2,3),(3,4),(4,5),(5,0),(0,6),(1,6),(2,6),(3,6),(4,6),(5,6),(0,2),(2,4)]
    for j,(a,c) in enumerate(edges):
        sw=5.3 if attention and j%3==0 else 2.8
        b+=line(*pts[a],*pts[c],color,sw,.85 if attention and j%3==0 else .40)
    for j,(x,y) in enumerate(pts):
        cc=([BLUE,TEAL,INK][j%3] if color==INK and not mlp else color)
        b+=circle(x,y,13,cc,.18 if j%2 else .55,3)
    if attention:
        b+=path('M21,72 C-5,155 43,212 109,210',INK,3.2,dash='7 7')
        b+=path('M98,203 L111,210 L101,218',INK,3.2)
    return b


def cluster(with_prototype=False):
    b=''
    for k,(x,y,col) in enumerate([(68,65,BLUE),(181,74,TEAL),(129,172,INK)]):
        for j in range(8):
            ang=j*math.pi*.765+k
            rad=17+(j%3)*10
            xx,yy=x+rad*math.cos(ang),y+rad*math.sin(ang)
            b+=circle(xx,yy,4.5,col,.85,1)
        if with_prototype:b+=star(x,y,17,col)
    return b


def prototypes():
    return ''.join(star(x,y,25,c,op) for x,y,c,op in [(54,63,BLUE,False),(130,63,TEAL,False),(205,63,INK,False),(54,145,BLUE,True),(130,145,TEAL,True),(205,145,INK,True)])


def layer(color):
    b=rect(40,47,176,132,color,15,.055,3)
    for x in [75,128,181]:
        for y in [81,144]:b+=circle(x,y,12,color,.28,2.7)
    return b


def residual(color):
    b=group(layer(color),42,51,.62)
    b+=arrow(10,116,62,116,color,sw=3.3)
    b+=arrow(160,116,188,116,color,sw=3.3)
    b+=circle(207,116,19,color,0,3)
    b+=line(198,116,216,116,color,3)+line(207,107,207,125,color,3)
    b+=arrow(226,116,247,116,color,sw=3.3)
    b+=path('M28,115 L28,47 Q28,31 46,31 L188,31 Q207,31 207,49 L207,95',color,3.3)
    b+=path('M200,85 L207,96 L214,85',color,3.3)
    return b


def probability(color, binary=True):
    if binary:
        b=rect(58,91,53,94,color,3,.25,2.5)+rect(147,43,53,142,color,3,.73,2.5)
        b+=line(38,187,223,187,INK,2.5)
    else:
        b=''
        for y,w,op in [(38,171,.72),(86,127,.45),(134,89,.22)]:
            b+=rect(37,y,w,29,color,3,op,2.4)
        b+=dots(118,193,color=INK)
    return b


def lock(opened=False):
    b=path('M85,100 L85,75 C85,21 171,21 171,75 L171,100' if not opened else 'M85,100 L85,73 C85,20 171,20 171,70',INK,10)
    b+=rect(65,95,127,109,INK,15,.13,5)
    b+=circle(128,140,9,INK,1,0)
    b+=path('M128,146 L121,172 L135,172 Z',INK,0,INK)
    return b


def target():
    b=''.join(circle(112,126,r,INK,0,5) for r in [62,41,20])
    b+=arrow(213,22,114,123,INK,sw=6)
    b+=path('M183,52 L182,28 L201,10 M183,52 L207,53 L225,33',INK,4)
    return b


def projection(color):
    b=path('M46,46 L195,78 L195,151 L46,184 Z',color,4,color,.12)
    b+=path('M46,46 L195,78 L195,151 L46,184 Z',color,3)
    b+=arrow(69,113,171,113,color,sw=4)
    return b


def standardize():
    b=line(30,181,225,181,INK,3)
    b+=path('M36,178 C75,178 74,167 86,130 C97,95 106,41 129,41 C153,41 159,100 170,136 C180,169 192,178 221,178',INK,5)
    b+=line(129,44,129,180,INK,2,.45,dash='6 7')
    return b


def fusion():
    b=arrow(20,52,99,104,BLUE,sw=5)+arrow(20,172,99,121,TEAL,sw=5)
    b+=circle(130,112,30,INK,.07,3)
    b+=line(115,112,145,112,INK,4)+line(130,97,130,127,INK,4)
    b+=arrow(160,112,239,112,INK,sw=5)
    return b


def alignment():
    b=group(tensor(BLUE),-3,57,.40)+group(tensor(INK,mixed=True),157,57,.40)
    b+=arrow(105,111,158,111,INK,'5 6',3,both=True)
    return b


def proto_alignment(nonarg=False):
    b=circle(38,112,18,INK if nonarg else BLUE,.30,3)
    b+=arrow(67,112,117,112,INK,'6 6',3.5)
    b+=circle(184,111,51,INK,.035,2)
    if nonarg:b+=star(184,111,27,INK)
    else:
        for j,c in enumerate([BLUE,TEAL,INK,BLUE,TEAL,INK]):
            a=j*math.pi/3
            b+=star(184+34*math.cos(a),111+34*math.sin(a),12,c, j>2)
    return b


def heads_anchor(subtype=False):
    b=''
    for x,col in [(24,BLUE),(155,INK)]:
        for j in range(4 if subtype else 2):
            b+=rect(x+j*(21 if subtype else 41),70,15 if subtype else 29,80,col,2,.25+j*.12,2)
    b+=arrow(147,111,116,111,INK,'5 5',3.5)
    return b


def classifier_fork():
    b=path('M128,26 L128,90 L58,90 L58,148 M128,90 L198,90 L198,148',INK,4)
    b+=path('M50,137 L58,149 L66,137 M190,137 L198,149 L206,137',INK,4)
    b+=rect(20,158,77,36,INK,7,.10,2.5)+rect(159,158,77,36,INK,7,.10,2.5)
    return b


def block(label, color=INK):
    return rect(15,29,226,77,color,12,.08,3)+text(128,77,label,24,color,700)


def build():
    add('protein_ribbon','Protein ribbon','蛋白质折叠示意',protein(),note='Symbolic ribbon, not an atomic structure or a PDB-derived model.')
    add('dna_helix','DNA helix','DNA双螺旋',dna())
    add('aa_stacked_features','AA feature stack','蛋白质堆叠特征',tensor(BLUE,False))
    add('nt_stacked_features','NT feature stack','核苷酸堆叠特征',tensor(TEAL,False))
    add('aa_embedding','AA embedding','蛋白质向量条',tensor(BLUE))
    add('nt_embedding','NT embedding','核苷酸向量条',tensor(TEAL))
    add('fused_embedding','Fused embedding','融合向量条',tensor(mixed=True))
    add('normalized_embedding','Normalized embedding','归一化融合向量',tensor(mixed=True,norm=True))
    add('aa_projection','AA projection','蛋白质线性投影',projection(BLUE))
    add('nt_projection','NT projection','核苷酸线性投影',projection(TEAL))
    add('weighted_fusion','Weighted fusion','双路加权融合',fusion())
    add('sigmoid_gate','Adaptive gate','门控符号',circle(128,112,69,INK,.055,4)+text(128,138,'σ',91,INK))
    add('sum_operator','Summation','加权求和节点',circle(128,112,52,INK,0,4)+line(100,112,156,112,INK,6)+line(128,84,128,140,INK,6))
    add('standardization','Standardization','标准化分布曲线',standardize())
    add('sample_clusters','Sample clusters','亚型样本点簇',cluster())
    add('cluster_centroids','Cluster centroids','样本簇与原型中心',cluster(True))
    add('prototype_set','Subtype prototypes','亚型原型星标集合',prototypes())
    add('prototype_blue','Blue prototype','蓝色原型星标',star(128,112,72,BLUE))
    add('prototype_teal','Teal prototype','青绿原型星标',star(128,112,72,TEAL))
    add('prototype_shared','Shared prototype','深灰原型星标',star(128,112,72,INK))
    add('nonarg_center','Non-ARG center','非ARG类别中心',circle(128,112,78,INK,.05,3)+star(128,112,49,INK))
    add('mutual_knn_graph','Mutual kNN graph','互近邻原型图',network())
    add('residual_gat_graph','Residual GAT','残差图注意力网络',network(attention=True))
    add('aa_neural_network','AA neural network','蛋白质神经网络',network(BLUE,mlp=True))
    add('nt_neural_network','NT neural network','核苷酸神经网络',network(TEAL,mlp=True))
    teacher=group(tensor(mixed=True,norm=True),56,-15,.56)+group(classifier_fork(),24,62,.81)+group(lock(),187,139,.19)
    add('fusion_teacher_heads','Fusion teacher heads','融合教师并行余弦头',teacher,note='Normalized fused representation feeds two parallel heads; no hidden MLP is implied.')
    add('aa_dense_layer','AA dense layer','蛋白质隐藏层',layer(BLUE))
    add('nt_dense_layer','NT dense layer','核苷酸隐藏层',layer(TEAL))
    add('aa_residual_block','AA residual block','蛋白质残差块',residual(BLUE))
    add('nt_residual_block','NT residual block','核苷酸残差块',residual(TEAL))
    add('binary_probabilities_aa','AA binary probabilities','蛋白质二分类概率',probability(BLUE,True))
    add('binary_probabilities_nt','NT binary probabilities','核苷酸二分类概率',probability(TEAL,True))
    add('subtype_probabilities_aa','AA subtype probabilities','蛋白质亚型概率',probability(BLUE,False))
    add('subtype_probabilities_nt','NT subtype probabilities','核苷酸亚型概率',probability(TEAL,False))
    add('teacher_binary_probabilities','Teacher binary probabilities','教师二分类概率',probability(INK,True))
    add('teacher_subtype_probabilities','Teacher subtype probabilities','教师亚型概率',probability(INK,False))
    add('frozen_lock','Frozen parameters','冻结参数锁',lock())
    add('supervision_target','Supervision target','监督损失靶标',target())
    add('feature_alignment','Feature alignment','特征对齐',alignment())
    add('arg_prototype_alignment','ARG prototype alignment','ARG原型对齐',proto_alignment())
    add('nonarg_prototype_alignment','Non-ARG alignment','非ARG中心对齐',proto_alignment(True))
    add('binary_head_anchoring','Binary-head anchoring','二分类头初始化与锚定',heads_anchor())
    add('subtype_head_anchoring','Subtype-head anchoring','亚型头初始化与锚定',heads_anchor(True))
    add('parallel_heads','Parallel classifier heads','并行分类头分支',classifier_fork())
    add('decision_diamond','Decision diamond','ARG判定菱形',path('M128,28 L229,112 L128,196 L27,112 Z',INK,4,INK,.07)+path('M128,28 L229,112 L128,196 L27,112 Z',INK,3.5))
    add('normalized_sphere','Normalized feature','归一化特征球',circle(128,112,57,BLUE,.24,4)+path('M94,73 C113,48 151,65 162,80',BLUE,7,opacity=.28))
    for col,name,cn in [(BLUE,'aa','AA'),(TEAL,'nt','NT'),(INK,'shared','共享')]:
        add(f'arrow_{name}',f'{"Shared" if name=="shared" else cn} forward arrow',f'{cn}实线箭头',arrow(21,40,235,40,col,sw=4),256,80,'connectors')
    add('arrow_training_dashed','Training target arrow','训练监督虚线箭头',arrow(21,40,235,40,INK,'10 9',4),256,80,'connectors')
    add('arrow_alignment_double','Alignment arrow','双向虚线对齐箭头',arrow(21,40,235,40,INK,'9 9',4,True),256,80,'connectors')
    add('arrow_curved_dashed','Curved training arrow','弧形虚线监督箭头',path('M234,20 C238,142 162,187 24,187',INK,4,dash='10 9')+path('M36,180 L23,187 L36,194',INK,4),256,224,'connectors')
    add('arrow_right_angle','Right-angle connector','直角连接箭头',path('M28,40 L148,40 L148,171 L229,171',INK,4)+path('M217,163 L230,171 L217,179',INK,4),256,224,'connectors')
    add('ellipsis_horizontal','Horizontal ellipsis','横向省略号',dots(63,40),148,80,'connectors')
    add('ellipsis_vertical','Vertical ellipsis','纵向省略号',dots(40,64,True),80,148,'connectors')
    for label,col,slug,cn in [
        ('ESM-2',BLUE,'esm2','蛋白编码器'),('DNABERT-2',TEAL,'dnabert2','核苷酸编码器'),
        ('Linear',INK,'linear','线性层'),('LayerNorm',INK,'layernorm','层归一化'),
        ('L2 normalization',INK,'l2_normalization','L2归一化'),('Binary',INK,'binary_head','二分类头'),
        ('Subtype',INK,'subtype_head','亚型分类头'),('Resistance type',INK,'type_output','耐药类型输出'),
        ('ARGScope-AA',BLUE,'aa_student','AA学生模块'),('ARGScope-NT',TEAL,'nt_student','NT学生模块'),
        ('AA teacher',INK,'aa_teacher','AA教师模块'),('NT teacher',INK,'nt_teacher','NT教师模块')]:
        add(f'module_{slug}',label,cn,block(label,col),256,135,'modules')
    for j,col in enumerate([BLUE,TEAL,INK,INK],1):
        add(f'stage_badge_{j}',f'Stage {j}',f'第{j}阶段编号',circle(64,64,44,col,.10,3)+text(64,79,str(j),44,col,700),128,128,'modules')


def overview():
    # Exactly the same vector bodies are reused here and in independent files.
    W=1600
    body=text(48,64,'ARGScope | Three-colour icon library',38,INK,700,'start')
    body+=text(48,101,'Editable SVG + transparent PNG  /  individual assets for manual assembly',21,INK,400,'start')
    for j,(lab,col) in enumerate(PALETTE.items()):
        x=48+j*500
        body+=f'<rect x="{x}" y="130" width="34" height="18" rx="4" fill="{col}"/>'
        body+=text(x+48,146,f'{lab}  {col}',19,INK,400,'start')
    y=190
    categories=[('icons','CORE ICONS',4,316),('connectors','CONNECTORS',4,230),('modules','OPTIONAL LABELLED MODULES',4,190)]
    for category,heading,cols,ch in categories:
        body+=text(48,y+25,heading,23,INK,700,'start')
        body+=line(48,y+42,W-48,y+42,INK,1,.25)
        y+=64
        items=[i for i in ICONS if i['category']==category]
        for j,item in enumerate(items):
            x=48+(j%cols)*380
            yy=y+(j//cols)*ch
            available_h=ch-73
            scale=min(260/item['width'],available_h/item['height'])
            gx=x+177-item['width']*scale/2
            gy=yy+(available_h-item['height']*scale)/2
            body+=group(item['body'],gx,gy,scale)
            body+=text(x+177,yy+ch-43,f'{item["number"]:02d}  {item["title"]}',18,INK,700)
        y+=math.ceil(len(items)/cols)*ch+24
    body+=text(48,y+12,'Three base inks only; lighter areas use opacity. Illustrations are schematic, not measured structures or results.',20,INK,400,'start')
    return svg_doc(W,y+48,body,'ARGScope three-colour asset index'),W,y+48


def write_docs():
    public=[{k:v for k,v in i.items() if k!='body'} for i in ICONS]
    source_paths=[Path(r'C:\Users\Jie Pan\AppData\Local\Temp\codex-clipboard-86245fae-f2d6-4e7c-9d77-4c9a0fa57b37.png'),Path(r'C:\Users\Jie Pan\AppData\Local\Temp\codex-clipboard-098ee30a-56c1-42e9-bab6-5505e0160231.png')]
    sources=[{'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in source_paths]
    manifest={'palette':PALETTE,'asset_count':len(ICONS),'sources':sources,'assets':public,
              'method':'Original editable SVG schematics based on user-provided reference images. No screenshot pixels are used.',
              'background':'Transparent. Opacity is used for shades; no additional base inks.',
              'boundary':'No experimental data, model results, or training code changed.'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# ARGScope 三色图标素材包','',f'共 {len(ICONS)} 个独立素材，每个均提供 SVG 和透明 PNG。','',
           '## 配色','',f'- 蓝色 {BLUE}：蛋白质、AA 分支。',f'- 青绿 {TEAL}：核苷酸、NT 分支。',f'- 深灰 {INK}：共享教师、融合后公共模块、原型、文字与训练监督。',
           '- 仅使用以上三种基础颜色；浅色区域以同色透明度实现。背景透明，不加入紫色、橙色或红色。',
           '- 实线表示前向流；虚线表示监督/对齐。不要再用新颜色区分损失。','',
           '## 使用方法','',
           '- 优先将 SVG 插入 PowerPoint、Illustrator 或 Inkscape。SVG 保留矢量路径，可放大和编辑；兼容性不足时使用 PNG。',
           '- 核心图标不附说明文字。图标总览中的编号和名称仅供检索，不会出现在独立图标中。',
           '- 另提供 ESM-2、DNABERT-2、Linear 等可编辑文字模块。文字使用 Arial。',
           '- 总览 SVG 与单独 SVG 复用完全相同的图形，不是另画一套。',
           '- 各素材画布尺寸按形状保留合适比例；请等比例缩放。',
           '- 所有 PNG 均透明、长边 1200 像素，SVG 不受分辨率限制。','',
           '## 科学含义边界','',
           '- 蛋白质和 DNA 是符号化插画，不对应实验测定的原子结构。',
           '- 概率柱、特征条和样本点簇是流程示意，不是实验结果或实测概率。',
           '- 星标的填充/空心和位置可用于区分示意亚型，不需要为每个亚型增加颜色。',
           '- 26 号为融合教师示意：融合向量、归一化、并行余弦分类头与冻结锁标；不表示教师包含隐藏 MLP。',
           '- 没有改动原图、稿件、实验结果或训练代码。','',
           '## 文件索引','', '|编号|文件名|内容|','|---|---|---|']
    for item in ICONS:lines.append(f'|{item["number"]:02d}|{item["file"]}|{item["chinese"]}|')
    (OUT/'使用说明_图标索引.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    import csv
    with (OUT/'图标索引.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['编号','文件名','中文内容','类别'])
        writer.writerows((i['number'],i['file'],i['chinese'],i['category']) for i in ICONS)


if __name__=='__main__':
    build()
    overview_svg,w,h=overview()
    (OUT/'00_icon_overview.svg').write_text(overview_svg,encoding='utf-8')
    sample=text(42,53,'ARGScope | Three-colour icon kit',32,INK,700,'start')
    sample+=text(42,87,'Blue: protein / AA     Teal: nucleotide / NT     Charcoal: shared modules',18,INK,400,'start')
    for j,n in enumerate([1,2,7,11,16,22,23,29,37,38,40,44]):
        item=ICONS[n-1]; x=35+(j%4)*314; y=124+(j//4)*269
        sc=min(219/item['width'],205/item['height'])
        sample+=group(item['body'],x+140-item['width']*sc/2,y+(205-item['height']*sc)/2,sc)
        sample+=text(x+140,y+236,item['title'],18,INK,700)
    (OUT/'00_preview.svg').write_text(svg_doc(1280,954,sample,'ARGScope three-colour icon preview'),encoding='utf-8')
    for page_no,start in enumerate(range(0,len(ICONS),16),1):
        subset=ICONS[start:start+16]
        body=text(48,54,f'ARGScope  |  Three-colour icons  |  {page_no:02d}',32,INK,700,'start')
        for j,item in enumerate(subset):
            x=48+(j%4)*380; y=103+(j//4)*275
            scale=min(246/item['width'],208/item['height'])
            body+=group(item['body'],x+177-item['width']*scale/2,y+(208-item['height']*scale)/2,scale)
            body+=text(x+177,y+240,f'{item["number"]:02d}  {item["title"]}',18,INK,700)
        (OUT/f'Catalog_{page_no:02d}.svg').write_text(svg_doc(1600,140+275*math.ceil(len(subset)/4),body,'ARGScope icon catalogue'),encoding='utf-8')
    write_docs()
    print(json.dumps({'count':len(ICONS),'folder':str(OUT),'overview':[w,h],'palette':PALETTE},ensure_ascii=False))
