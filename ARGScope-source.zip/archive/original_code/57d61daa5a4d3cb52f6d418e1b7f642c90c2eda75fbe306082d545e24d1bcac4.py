#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARG + nonARG paired fragment simulation
7 conditions x 5 fragments per original
STRICT paired protein/DNA coordinates + inherited original train/test split

Put this script in the SAME folder as:

    all_ARG_nonARG_1to1_protein.fasta
    all_ARG_nonARG_1to1_DNA.fasta
    all_ARG_nonARG_1to1_structure.txt

and the canonical split generated previously:

    06_original_level_split_ONLY/
        original_train_test_split.csv

Generated conditions
--------------------
    fixed_30aa_90nt
    fixed_40aa_120nt
    fixed_50aa_150nt
    percent_60
    percent_70
    percent_80
    percent_90

Five fragments per original
---------------------------
For every original sequence, every condition produces 5 fragments:

    OriginalID_1
    OriginalID_2
    OriginalID_3
    OriginalID_4
    OriginalID_5

The five windows are deterministic and distributed across the legal start
coordinate range. They are NOT independently randomized for protein and DNA.

Pairing rule
------------
If the protein fragment is:

    protein[start_aa : end_aa]

then DNA is always:

    coding_DNA[3*start_aa : 3*end_aa]

Therefore protein and DNA correspond to exactly the same coding region.

Train/test inheritance
----------------------
The original-level split is NEVER changed.

If:
    OriginalID -> train

then:
    OriginalID_1 -> train
    OriginalID_2 -> train
    ...
    OriginalID_5 -> train

Likewise for test.

Thus the simulated dataset is exactly a 5x expansion of eligible original IDs,
not a new train/test split.

Output
------
07_paired_simulated_fragments_5parts/
    fixed_30aa_90nt/
    fixed_40aa_120nt/
    fixed_50aa_150nt/
    percent_60/
    percent_70/
    percent_80/
    percent_90/

Each condition contains:
    <condition>_protein.fasta
    <condition>_DNA.fasta
    <condition>_structure.txt
    <condition>_fragment_manifest.csv
    <condition>_QC_summary.txt

Root also contains:
    all_conditions_summary.csv
    all_conditions_excluded_originals.csv
    global_simulation_QC_summary.txt

Scientific safeguards
---------------------
1. Full protein/DNA IDs must match exactly.
2. Full structure IDs must match exactly.
3. Split table must cover every original exactly once.
4. Every full DNA must translate to its paired full protein before simulation.
5. Every fragment DNA must translate to its paired fragment protein.
6. Fragment protein/DNA FASTA IDs and order must match exactly.
7. Every fragment inherits the original split.
8. No original can appear in both train and test.
9. No duplicate fragment IDs are permitted.
10. If an original cannot provide 5 UNIQUE legal windows for a condition,
    it is excluded from that condition and reported; fragments are never
    duplicated merely to force 5x.
"""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


# =============================================================================
# Configuration
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

PROTEIN_FASTA = (
    SCRIPT_DIR
    / "all_ARG_nonARG_1to1_protein.fasta"
)

DNA_FASTA = (
    SCRIPT_DIR
    / "all_ARG_nonARG_1to1_DNA.fasta"
)

STRUCTURE_FILE = (
    SCRIPT_DIR
    / "all_ARG_nonARG_1to1_structure.txt"
)

SPLIT_FILE = (
    SCRIPT_DIR
    / "06_original_level_split_ONLY"
    / "original_train_test_split.csv"
)

OUTPUT_ROOT = (
    SCRIPT_DIR
    / "07_paired_simulated_fragments_5parts"
)

N_PARTS = 5

FIXED_CONDITIONS = {
    "fixed_30aa_90nt": 30,
    "fixed_40aa_120nt": 40,
    "fixed_50aa_150nt": 50,
}

PERCENT_CONDITIONS = {
    "percent_60": 60,
    "percent_70": 70,
    "percent_80": 80,
    "percent_90": 90,
}

CONDITION_ORDER = [
    "fixed_30aa_90nt",
    "fixed_40aa_120nt",
    "fixed_50aa_150nt",
    "percent_60",
    "percent_70",
    "percent_80",
    "percent_90",
]


# =============================================================================
# Standard genetic code
# =============================================================================

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",

    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",

    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",

    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

BACTERIAL_START_CODONS = {
    "ATG",
    "GTG",
    "TTG",
    "CTG",
    "ATT",
    "ATC",
    "ATA",
}

AMBIGUOUS_TARGET_AA = set(
    "XBZJUO?"
)

VALID_IUPAC_DNA = set(
    "ACGTNRYKMSWBDHV"
)


# =============================================================================
# Basic helpers
# =============================================================================

def canonical_id(value):
    text = str(value).strip()
    return text.split()[0] if text else ""


def clean_protein(sequence):
    return (
        "".join(sequence.split())
        .upper()
        .replace("-", "")
        .rstrip("*")
    )


def clean_dna(sequence):
    return (
        "".join(sequence.split())
        .upper()
        .replace("U", "T")
        .replace("-", "")
    )


def require_file(path, label):
    if not path.is_file():
        raise FileNotFoundError(
            f"{label} not found:\n{path}"
        )


def read_fasta(path, molecule):
    order = []
    records = {}

    current_id = None
    current_header = ""
    chunks = []

    def save_current():
        nonlocal current_id
        nonlocal current_header
        nonlocal chunks

        if current_id is None:
            return

        if current_id in records:
            raise ValueError(
                f"Duplicate FASTA ID in {path.name}: {current_id}"
            )

        raw_sequence = "".join(chunks)

        if molecule == "protein":
            sequence = clean_protein(raw_sequence)

        elif molecule == "DNA":
            sequence = clean_dna(raw_sequence)

        else:
            raise ValueError(
                f"Unknown molecule: {molecule}"
            )

        records[current_id] = {
            "header": current_header,
            "sequence": sequence,
        }

        order.append(current_id)

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line_number, raw in enumerate(
            handle,
            start=1,
        ):
            line = raw.strip()

            if not line:
                continue

            if line.startswith(">"):
                save_current()

                current_header = line[1:].strip()

                if not current_header:
                    raise ValueError(
                        f"Empty FASTA header: "
                        f"{path}:{line_number}"
                    )

                current_id = canonical_id(
                    current_header
                )

                chunks = []

            else:
                if current_id is None:
                    raise ValueError(
                        "Sequence before first FASTA header: "
                        f"{path}:{line_number}"
                    )

                chunks.append(line)

        save_current()

    return order, records


def detect_delimiter(path):
    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        first = handle.readline()

    return "\t" if "\t" in first else ","


def read_table(path):
    delimiter = detect_delimiter(path)

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter=delimiter,
        )

        if reader.fieldnames is None:
            raise ValueError(
                f"No table header: {path}"
            )

        return (
            list(reader.fieldnames),
            list(reader),
        )


def write_csv(path, fields, rows):
    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            extrasaction="ignore",
        )

        writer.writeheader()
        writer.writerows(rows)


def write_tsv(path, fields, rows):
    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            extrasaction="ignore",
            lineterminator="\n",
        )

        writer.writeheader()
        writer.writerows(rows)


def wrap_sequence(sequence, width=80):
    return "\n".join(
        sequence[i:i + width]
        for i in range(
            0,
            len(sequence),
            width,
        )
    )


# =============================================================================
# Translation
# =============================================================================

def translate_frame0(
    dna,
    normalize_bacterial_start=False,
):
    dna = clean_dna(dna)

    amino_acids = []

    for index in range(
        0,
        len(dna) - 2,
        3,
    ):
        codon = dna[
            index:
            index + 3
        ]

        amino_acids.append(
            CODON_TABLE.get(
                codon,
                "X",
            )
        )

    if (
        amino_acids
        and normalize_bacterial_start
        and dna[:3] in BACTERIAL_START_CODONS
    ):
        amino_acids[0] = "M"

    return "".join(amino_acids)


def residues_compatible(
    target,
    translated,
):
    if len(target) != len(translated):
        return False

    for target_aa, translated_aa in zip(
        target,
        translated,
    ):
        if target_aa in AMBIGUOUS_TARGET_AA:
            if translated_aa == "*":
                return False
            continue

        if target_aa != translated_aa:
            return False

    return True


def validate_full_pair(
    protein,
    dna,
):
    protein = clean_protein(protein)
    dna = clean_dna(dna)

    if set(dna) - VALID_IUPAC_DNA:
        return False, "invalid_DNA_alphabet", ""

    allowed_lengths = {
        3 * len(protein),
        3 * (len(protein) + 1),
    }

    if len(dna) not in allowed_lengths:
        return False, "unexpected_DNA_length", ""

    coding_dna = dna[
        :3 * len(protein)
    ]

    translated = translate_frame0(
        coding_dna,
        normalize_bacterial_start=protein.startswith(
            "M"
        ),
    )

    if "*" in translated:
        return False, "internal_stop", coding_dna

    if not residues_compatible(
        protein,
        translated,
    ):
        return False, "translation_mismatch", coding_dna

    if len(dna) == 3 * (len(protein) + 1):
        terminal_codon = dna[
            3 * len(protein):
        ]

        if CODON_TABLE.get(
            terminal_codon,
            "X",
        ) != "*":
            return (
                False,
                "extra_terminal_codon_not_stop",
                coding_dna,
            )

    return True, "", coding_dna


def validate_fragment_pair(
    fragment_protein,
    fragment_dna,
    start_aa0,
    original_protein,
):
    fragment_protein = clean_protein(
        fragment_protein
    )

    fragment_dna = clean_dna(
        fragment_dna
    )

    if len(fragment_dna) != 3 * len(fragment_protein):
        return False, "DNA_length_not_3x_protein"

    if set(fragment_dna) - VALID_IUPAC_DNA:
        return False, "invalid_DNA_alphabet"

    normalize_start = (
        start_aa0 == 0
        and original_protein.startswith(
            "M"
        )
    )

    translated = translate_frame0(
        fragment_dna,
        normalize_bacterial_start=normalize_start,
    )

    if "*" in translated:
        return False, "fragment_internal_stop"

    if not residues_compatible(
        fragment_protein,
        translated,
    ):
        return False, "fragment_translation_mismatch"

    return True, ""


# =============================================================================
# Input validation
# =============================================================================

def load_full_dataset():
    protein_order, proteins = read_fasta(
        PROTEIN_FASTA,
        "protein",
    )

    dna_order, dna = read_fasta(
        DNA_FASTA,
        "DNA",
    )

    structure_fields, structure_rows = read_table(
        STRUCTURE_FILE
    )

    required_structure = {
        "SARG.Seq.ID",
        "Type",
        "Subtype",
        "ARG.or.nonARG",
    }

    missing = (
        required_structure
        - set(structure_fields)
    )

    if missing:
        raise ValueError(
            "Structure missing columns: "
            f"{sorted(missing)}"
        )

    structure_by_id = {}
    structure_order = []

    for row in structure_rows:
        original_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        if not original_id:
            raise ValueError(
                "Structure contains empty SARG.Seq.ID"
            )

        if original_id in structure_by_id:
            raise ValueError(
                f"Duplicate structure ID: {original_id}"
            )

        structure_by_id[
            original_id
        ] = row

        structure_order.append(
            original_id
        )

    if not (
        set(protein_order)
        == set(dna_order)
        == set(structure_order)
    ):
        raise ValueError(
            "Protein/DNA/structure ID sets are not identical."
        )

    if protein_order != dna_order:
        raise ValueError(
            "Protein/DNA FASTA order is not identical."
        )

    if protein_order != structure_order:
        raise ValueError(
            "Protein/structure order is not identical."
        )

    coding_dna_by_id = {}

    failed = []

    for index, original_id in enumerate(
        protein_order,
        start=1,
    ):
        valid, reason, coding_dna = validate_full_pair(
            proteins[
                original_id
            ][
                "sequence"
            ],
            dna[
                original_id
            ][
                "sequence"
            ],
        )

        if not valid:
            failed.append(
                {
                    "SARG.Seq.ID":
                        original_id,

                    "reason":
                        reason,
                }
            )

        else:
            coding_dna_by_id[
                original_id
            ] = coding_dna

        if (
            index == 1
            or index % 5000 == 0
            or index == len(protein_order)
        ):
            print(
                f"  full pair QC "
                f"[{index:,}/{len(protein_order):,}]",
                flush=True,
            )

    if failed:
        OUTPUT_ROOT.mkdir(
            parents=True,
            exist_ok=True,
        )

        failure_path = (
            OUTPUT_ROOT
            / "PRE_SIMULATION_FULL_PAIR_FAILURES.csv"
        )

        write_csv(
            failure_path,
            [
                "SARG.Seq.ID",
                "reason",
            ],
            failed,
        )

        raise RuntimeError(
            f"{len(failed)} full protein/DNA pairs failed QC.\n"
            f"Inspect:\n{failure_path}"
        )

    return (
        protein_order,
        proteins,
        coding_dna_by_id,
        structure_fields,
        structure_by_id,
    )


def load_split(
    expected_ids,
):
    fields, rows = read_table(
        SPLIT_FILE
    )

    required = {
        "SARG.Seq.ID",
        "split",
    }

    missing = required - set(fields)

    if missing:
        raise ValueError(
            "Split file missing columns: "
            f"{sorted(missing)}"
        )

    split_by_id = {}

    for row in rows:
        original_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        split = str(
            row.get(
                "split",
                "",
            )
        ).strip().lower()

        if not original_id:
            raise ValueError(
                "Split table contains empty SARG.Seq.ID"
            )

        if original_id in split_by_id:
            raise ValueError(
                f"Duplicate ID in split table: {original_id}"
            )

        if split not in {
            "train",
            "test",
        }:
            raise ValueError(
                f"Invalid split for {original_id}: {split}"
            )

        split_by_id[
            original_id
        ] = split

    expected_ids = set(
        expected_ids
    )

    split_ids = set(
        split_by_id
    )

    if expected_ids != split_ids:
        raise ValueError(
            "Split table does not exactly cover the full dataset:\n"
            f"  dataset only = "
            f"{len(expected_ids-split_ids)}\n"
            f"  split only   = "
            f"{len(split_ids-expected_ids)}"
        )

    return split_by_id


# =============================================================================
# Fragment-window logic
# =============================================================================

def get_fragment_length(
    condition,
    full_length_aa,
):
    if condition in FIXED_CONDITIONS:
        return FIXED_CONDITIONS[
            condition
        ]

    if condition in PERCENT_CONDITIONS:
        percent = PERCENT_CONDITIONS[
            condition
        ]

        # Integer half-up rounding:
        # floor(L*p/100 + 0.5)
        fragment_length = (
            full_length_aa
            * percent
            + 50
        ) // 100

        return max(
            1,
            fragment_length,
        )

    raise ValueError(
        f"Unknown condition: {condition}"
    )


def five_unique_even_starts(
    full_length_aa,
    fragment_length_aa,
):
    """
    Five unique, deterministic windows spanning the complete legal start range.

    Legal 0-based start coordinates:
        0 ... full_length_aa - fragment_length_aa

    Returns None if 5 distinct windows are mathematically impossible.
    """

    if fragment_length_aa > full_length_aa:
        return None

    max_start = (
        full_length_aa
        - fragment_length_aa
    )

    legal_start_count = (
        max_start
        + 1
    )

    if legal_start_count < N_PARTS:
        return None

    starts = []

    for part_index in range(
        N_PARTS
    ):
        # Half-up integer interpolation over [0, max_start].
        numerator = (
            part_index
            * max_start
        )

        denominator = (
            N_PARTS
            - 1
        )

        start = (
            numerator
            + denominator // 2
        ) // denominator

        starts.append(
            start
        )

    # Defensive uniqueness correction. Normally the legal_start_count >= 5
    # condition is already sufficient, but explicitly enforce it.
    if len(set(starts)) != N_PARTS:
        starts = []

        for part_index in range(
            N_PARTS
        ):
            start = round(
                part_index
                * max_start
                / (
                    N_PARTS
                    - 1
                )
            )

            starts.append(
                int(start)
            )

    if len(set(starts)) != N_PARTS:
        return None

    return starts


# =============================================================================
# Structure construction
# =============================================================================

def build_fragment_structure_fields(
    original_fields,
):
    preferred_fields = [
        "SARG.Seq.ID",
        "Original.SARG.Seq.ID",
        "Original.ID",
        "ARG.or.nonARG",
        "Type",
        "Subtype",
        "split",
        "condition",
        "part_index",
        "Fragment.Start.AA.0based",
        "Fragment.End.AA.exclusive",
        "Fragment.Start.NT.0based",
        "Fragment.End.NT.exclusive",
        "Protein.Length.aa",
        "DNA.Length.nt",
        "Original.Protein.Length.aa",
        "Original.DNA.Coding.Length.nt",
    ]

    output_fields = list(
        preferred_fields
    )

    for field in original_fields:
        if field in {
            "SARG.Seq.ID",
            "Original.ID",
            "ARG.or.nonARG",
            "Type",
            "Subtype",
            "Protein.Length.aa",
            "DNA.Length.nt",
        }:
            continue

        if field not in output_fields:
            output_fields.append(
                field
            )

    return output_fields


# =============================================================================
# Simulate one condition
# =============================================================================

def simulate_condition(
    condition,
    original_order,
    proteins,
    coding_dna_by_id,
    structure_fields,
    structure_by_id,
    split_by_id,
):
    condition_dir = (
        OUTPUT_ROOT
        / condition
    )

    condition_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    protein_out = (
        condition_dir
        / f"{condition}_protein.fasta"
    )

    dna_out = (
        condition_dir
        / f"{condition}_DNA.fasta"
    )

    structure_out = (
        condition_dir
        / f"{condition}_structure.txt"
    )

    manifest_out = (
        condition_dir
        / f"{condition}_fragment_manifest.csv"
    )

    qc_out = (
        condition_dir
        / f"{condition}_QC_summary.txt"
    )

    fragment_structure_fields = (
        build_fragment_structure_fields(
            structure_fields
        )
    )

    structure_rows = []

    manifest_rows = []

    excluded_rows = []

    fragment_ids = []

    train_fragment_count = 0
    test_fragment_count = 0

    train_original_count = 0
    test_original_count = 0

    class_fragment_counts = Counter()

    fragment_translation_failures = []

    with protein_out.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as protein_handle, dna_out.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as dna_handle:

        for original_index, original_id in enumerate(
            original_order,
            start=1,
        ):
            full_protein = proteins[
                original_id
            ][
                "sequence"
            ]

            coding_dna = coding_dna_by_id[
                original_id
            ]

            full_length_aa = len(
                full_protein
            )

            fragment_length_aa = (
                get_fragment_length(
                    condition,
                    full_length_aa,
                )
            )

            starts = five_unique_even_starts(
                full_length_aa,
                fragment_length_aa,
            )

            if starts is None:
                excluded_rows.append(
                    {
                        "condition":
                            condition,

                        "Original.SARG.Seq.ID":
                            original_id,

                        "split":
                            split_by_id[
                                original_id
                            ],

                        "ARG.or.nonARG":
                            str(
                                structure_by_id[
                                    original_id
                                ].get(
                                    "ARG.or.nonARG",
                                    "",
                                )
                            ).strip(),

                        "full_protein_length_aa":
                            full_length_aa,

                        "requested_fragment_length_aa":
                            fragment_length_aa,

                        "legal_start_count":
                            max(
                                0,
                                full_length_aa
                                - fragment_length_aa
                                + 1,
                            ),

                        "reason":
                            (
                                "cannot_generate_5_unique_windows"
                            ),
                    }
                )

                continue

            original_split = split_by_id[
                original_id
            ]

            if original_split == "train":
                train_original_count += 1

            elif original_split == "test":
                test_original_count += 1

            else:
                raise RuntimeError(
                    f"Invalid split: {original_split}"
                )

            original_structure = (
                structure_by_id[
                    original_id
                ]
            )

            group = str(
                original_structure.get(
                    "ARG.or.nonARG",
                    "",
                )
            ).strip()

            for part_index, start_aa0 in enumerate(
                starts,
                start=1,
            ):
                end_aa = (
                    start_aa0
                    + fragment_length_aa
                )

                start_nt0 = (
                    3
                    * start_aa0
                )

                end_nt = (
                    3
                    * end_aa
                )

                fragment_protein = (
                    full_protein[
                        start_aa0:
                        end_aa
                    ]
                )

                fragment_dna = (
                    coding_dna[
                        start_nt0:
                        end_nt
                    ]
                )

                fragment_id = (
                    f"{original_id}_{part_index}"
                )

                valid, reason = validate_fragment_pair(
                    fragment_protein,
                    fragment_dna,
                    start_aa0,
                    full_protein,
                )

                if not valid:
                    fragment_translation_failures.append(
                        {
                            "condition":
                                condition,

                            "fragment_id":
                                fragment_id,

                            "Original.SARG.Seq.ID":
                                original_id,

                            "reason":
                                reason,
                        }
                    )

                    continue

                fragment_ids.append(
                    fragment_id
                )

                if original_split == "train":
                    train_fragment_count += 1

                else:
                    test_fragment_count += 1

                class_fragment_counts[
                    group
                ] += 1

                protein_handle.write(
                    f">{fragment_id} "
                    f"Original.ID={original_id} "
                    f"condition={condition} "
                    f"part={part_index} "
                    f"split={original_split}\n"
                    f"{wrap_sequence(fragment_protein)}\n"
                )

                dna_handle.write(
                    f">{fragment_id} "
                    f"Original.ID={original_id} "
                    f"condition={condition} "
                    f"part={part_index} "
                    f"split={original_split}\n"
                    f"{wrap_sequence(fragment_dna)}\n"
                )

                fragment_row = {
                    "SARG.Seq.ID":
                        fragment_id,

                    "Original.SARG.Seq.ID":
                        original_id,

                    "Original.ID":
                        original_id,

                    "ARG.or.nonARG":
                        group,

                    "Type":
                        str(
                            original_structure.get(
                                "Type",
                                "",
                            )
                        ).strip(),

                    "Subtype":
                        str(
                            original_structure.get(
                                "Subtype",
                                "",
                            )
                        ).strip(),

                    "split":
                        original_split,

                    "condition":
                        condition,

                    "part_index":
                        part_index,

                    "Fragment.Start.AA.0based":
                        start_aa0,

                    "Fragment.End.AA.exclusive":
                        end_aa,

                    "Fragment.Start.NT.0based":
                        start_nt0,

                    "Fragment.End.NT.exclusive":
                        end_nt,

                    "Protein.Length.aa":
                        len(
                            fragment_protein
                        ),

                    "DNA.Length.nt":
                        len(
                            fragment_dna
                        ),

                    "Original.Protein.Length.aa":
                        full_length_aa,

                    "Original.DNA.Coding.Length.nt":
                        len(
                            coding_dna
                        ),
                }

                for field in structure_fields:
                    if field in {
                        "SARG.Seq.ID",
                        "Original.ID",
                        "ARG.or.nonARG",
                        "Type",
                        "Subtype",
                        "Protein.Length.aa",
                        "DNA.Length.nt",
                    }:
                        continue

                    if field not in fragment_row:
                        fragment_row[
                            field
                        ] = original_structure.get(
                            field,
                            "",
                        )

                structure_rows.append(
                    fragment_row
                )

                manifest_rows.append(
                    {
                        "fragment_id":
                            fragment_id,

                        "Original.SARG.Seq.ID":
                            original_id,

                        "ARG.or.nonARG":
                            group,

                        "Type":
                            str(
                                original_structure.get(
                                    "Type",
                                    "",
                                )
                            ).strip(),

                        "Subtype":
                            str(
                                original_structure.get(
                                    "Subtype",
                                    "",
                                )
                            ).strip(),

                        "split":
                            original_split,

                        "condition":
                            condition,

                        "part_index":
                            part_index,

                        "full_protein_length_aa":
                            full_length_aa,

                        "fragment_protein_length_aa":
                            len(
                                fragment_protein
                            ),

                        "fragment_DNA_length_nt":
                            len(
                                fragment_dna
                            ),

                        "start_aa_0based":
                            start_aa0,

                        "end_aa_exclusive":
                            end_aa,

                        "start_nt_0based":
                            start_nt0,

                        "end_nt_exclusive":
                            end_nt,
                    }
                )

            if (
                original_index == 1
                or original_index % 5000 == 0
                or original_index
                == len(original_order)
            ):
                print(
                    f"  {condition}: "
                    f"[{original_index:,}/{len(original_order):,}]",
                    flush=True,
                )

    # If even one fragment failed after a supposedly valid original pair,
    # do not silently continue.
    if fragment_translation_failures:
        failure_file = (
            condition_dir
            / f"{condition}_fragment_translation_FAILURES.csv"
        )

        write_csv(
            failure_file,
            [
                "condition",
                "fragment_id",
                "Original.SARG.Seq.ID",
                "reason",
            ],
            fragment_translation_failures,
        )

        raise RuntimeError(
            f"{condition}: "
            f"{len(fragment_translation_failures)} fragment pairs "
            f"failed DNA->protein QC.\n"
            f"Inspect:\n{failure_file}"
        )

    # ------------------------------------------------------------------
    # Write structure / manifest.
    # ------------------------------------------------------------------

    write_tsv(
        structure_out,
        fragment_structure_fields,
        structure_rows,
    )

    write_csv(
        manifest_out,
        [
            "fragment_id",
            "Original.SARG.Seq.ID",
            "ARG.or.nonARG",
            "Type",
            "Subtype",
            "split",
            "condition",
            "part_index",
            "full_protein_length_aa",
            "fragment_protein_length_aa",
            "fragment_DNA_length_nt",
            "start_aa_0based",
            "end_aa_exclusive",
            "start_nt_0based",
            "end_nt_exclusive",
        ],
        manifest_rows,
    )

    # ------------------------------------------------------------------
    # Re-read condition outputs and strict QC.
    # ------------------------------------------------------------------

    protein_order_out, protein_records_out = (
        read_fasta(
            protein_out,
            "protein",
        )
    )

    dna_order_out, dna_records_out = (
        read_fasta(
            dna_out,
            "DNA",
        )
    )

    _, structure_rows_out = read_table(
        structure_out
    )

    structure_order_out = [
        canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )
        for row
        in structure_rows_out
    ]

    qc_checks = {}

    qc_checks[
        "eligible_original_count"
    ] = (
        train_original_count
        + test_original_count
    )

    qc_checks[
        "excluded_original_count"
    ] = len(
        excluded_rows
    )

    qc_checks[
        "expected_fragment_count"
    ] = (
        qc_checks[
            "eligible_original_count"
        ]
        * N_PARTS
    )

    qc_checks[
        "actual_fragment_count"
    ] = len(
        protein_order_out
    )

    qc_checks[
        "fragment_count_exact_5x"
    ] = (
        qc_checks[
            "actual_fragment_count"
        ]
        == qc_checks[
            "expected_fragment_count"
        ]
    )

    qc_checks[
        "fragment_IDs_unique"
    ] = (
        len(
            protein_order_out
        )
        == len(
            set(
                protein_order_out
            )
        )
    )

    qc_checks[
        "protein_DNA_ID_order_identical"
    ] = (
        protein_order_out
        == dna_order_out
    )

    qc_checks[
        "protein_structure_ID_order_identical"
    ] = (
        protein_order_out
        == structure_order_out
    )

    # Verify every fragment again after disk round trip.
    postwrite_translation_failures = 0

    inheritance_failures = 0

    part_counts_per_original = Counter()

    train_fragments_post = 0
    test_fragments_post = 0

    for row in structure_rows_out:
        fragment_id = canonical_id(
            row.get(
                "SARG.Seq.ID",
                "",
            )
        )

        original_id = canonical_id(
            row.get(
                "Original.SARG.Seq.ID",
                "",
            )
        )

        split = str(
            row.get(
                "split",
                "",
            )
        ).strip().lower()

        if original_id not in split_by_id:
            inheritance_failures += 1

        elif split != split_by_id[
            original_id
        ]:
            inheritance_failures += 1

        if split == "train":
            train_fragments_post += 1

        elif split == "test":
            test_fragments_post += 1

        else:
            inheritance_failures += 1

        part_counts_per_original[
            original_id
        ] += 1

        start_aa0 = int(
            row[
                "Fragment.Start.AA.0based"
            ]
        )

        valid, _ = validate_fragment_pair(
            protein_records_out[
                fragment_id
            ][
                "sequence"
            ],
            dna_records_out[
                fragment_id
            ][
                "sequence"
            ],
            start_aa0,
            proteins[
                original_id
            ][
                "sequence"
            ],
        )

        if not valid:
            postwrite_translation_failures += 1

    qc_checks[
        "all_eligible_originals_have_exactly_5_fragments"
    ] = all(
        count == N_PARTS
        for count
        in part_counts_per_original.values()
    ) and (
        len(
            part_counts_per_original
        )
        == qc_checks[
            "eligible_original_count"
        ]
    )

    qc_checks[
        "split_inheritance_failure_count"
    ] = inheritance_failures

    qc_checks[
        "all_fragments_inherit_original_split"
    ] = (
        inheritance_failures
        == 0
    )

    qc_checks[
        "postwrite_translation_failure_count"
    ] = (
        postwrite_translation_failures
    )

    qc_checks[
        "all_fragments_translate_correctly"
    ] = (
        postwrite_translation_failures
        == 0
    )

    qc_checks[
        "train_original_count"
    ] = train_original_count

    qc_checks[
        "test_original_count"
    ] = test_original_count

    qc_checks[
        "train_fragment_count"
    ] = train_fragments_post

    qc_checks[
        "test_fragment_count"
    ] = test_fragments_post

    qc_checks[
        "train_count_exact_5x"
    ] = (
        train_fragments_post
        == train_original_count
        * N_PARTS
    )

    qc_checks[
        "test_count_exact_5x"
    ] = (
        test_fragments_post
        == test_original_count
        * N_PARTS
    )

    qc_checks[
        "ARG_fragment_count"
    ] = class_fragment_counts.get(
        "ARG",
        0,
    )

    qc_checks[
        "nonARG_fragment_count"
    ] = class_fragment_counts.get(
        "nonARG",
        0,
    )

    boolean_checks = [
        "fragment_count_exact_5x",
        "fragment_IDs_unique",
        "protein_DNA_ID_order_identical",
        "protein_structure_ID_order_identical",
        "all_eligible_originals_have_exactly_5_fragments",
        "all_fragments_inherit_original_split",
        "all_fragments_translate_correctly",
        "train_count_exact_5x",
        "test_count_exact_5x",
    ]

    qc_checks[
        "FINAL_QC_PASS"
    ] = all(
        qc_checks[
            key
        ]
        for key
        in boolean_checks
    )

    qc_lines = [
        f"condition\t{condition}",
        f"N_PARTS\t{N_PARTS}",
    ]

    for key, value in qc_checks.items():
        qc_lines.append(
            f"{key}\t{value}"
        )

    qc_out.write_text(
        "\n".join(
            qc_lines
        )
        + "\n",
        encoding="utf-8",
    )

    if not qc_checks[
        "FINAL_QC_PASS"
    ]:
        raise RuntimeError(
            f"{condition}: final condition QC failed.\n"
            f"Inspect:\n{qc_out}"
        )

    return (
        qc_checks,
        excluded_rows,
    )


# =============================================================================
# Main
# =============================================================================

def main():
    for path, label in [
        (
            PROTEIN_FASTA,
            "Full paired protein FASTA",
        ),
        (
            DNA_FASTA,
            "Full paired DNA FASTA",
        ),
        (
            STRUCTURE_FILE,
            "Full paired structure",
        ),
        (
            SPLIT_FILE,
            "Canonical original-level split",
        ),
    ]:
        require_file(
            path,
            label,
        )

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("=" * 120)
    print("ARG + nonARG PAIRED SIMULATION: 7 CONDITIONS x 5 FRAGMENTS")
    print("=" * 120)

    print("Conditions:")
    for condition in CONDITION_ORDER:
        print(f"  {condition}")

    print()
    print(
        "Fragment IDs: OriginalID_1 ... OriginalID_5"
    )
    print(
        "Protein and DNA use identical coding coordinates."
    )
    print(
        "Train/test is inherited from the original ID and is NEVER re-split."
    )

    print()
    print("[1/3] Loading and verifying full paired dataset...")

    (
        original_order,
        proteins,
        coding_dna_by_id,
        structure_fields,
        structure_by_id,
    ) = load_full_dataset()

    print(
        f"Full originals verified : {len(original_order):,}"
    )

    print()
    print("[2/3] Loading canonical original-level split...")

    split_by_id = load_split(
        original_order
    )

    original_split_counts = Counter(
        split_by_id.values()
    )

    original_class_counts = Counter(
        str(
            structure_by_id[
                original_id
            ].get(
                "ARG.or.nonARG",
                "",
            )
        ).strip()
        for original_id
        in original_order
    )

    print(
        f"Original train : "
        f"{original_split_counts.get('train', 0):,}"
    )

    print(
        f"Original test  : "
        f"{original_split_counts.get('test', 0):,}"
    )

    print(
        f"Original ARG   : "
        f"{original_class_counts.get('ARG', 0):,}"
    )

    print(
        f"Original nonARG: "
        f"{original_class_counts.get('nonARG', 0):,}"
    )

    print()
    print("[3/3] Generating 7 paired fragment datasets...")

    all_summary_rows = []

    all_excluded_rows = []

    for condition_index, condition in enumerate(
        CONDITION_ORDER,
        start=1,
    ):
        print()
        print(
            "-" * 120
        )
        print(
            f"[{condition_index}/{len(CONDITION_ORDER)}] "
            f"{condition}"
        )
        print(
            "-" * 120
        )

        (
            qc_checks,
            excluded_rows,
        ) = simulate_condition(
            condition,
            original_order,
            proteins,
            coding_dna_by_id,
            structure_fields,
            structure_by_id,
            split_by_id,
        )

        all_excluded_rows.extend(
            excluded_rows
        )

        all_summary_rows.append(
            {
                "condition":
                    condition,

                "full_original_count":
                    len(
                        original_order
                    ),

                "eligible_original_count":
                    qc_checks[
                        "eligible_original_count"
                    ],

                "excluded_original_count":
                    qc_checks[
                        "excluded_original_count"
                    ],

                "train_original_count":
                    qc_checks[
                        "train_original_count"
                    ],

                "test_original_count":
                    qc_checks[
                        "test_original_count"
                    ],

                "total_fragment_count":
                    qc_checks[
                        "actual_fragment_count"
                    ],

                "train_fragment_count":
                    qc_checks[
                        "train_fragment_count"
                    ],

                "test_fragment_count":
                    qc_checks[
                        "test_fragment_count"
                    ],

                "ARG_fragment_count":
                    qc_checks[
                        "ARG_fragment_count"
                    ],

                "nonARG_fragment_count":
                    qc_checks[
                        "nonARG_fragment_count"
                    ],

                "FINAL_QC_PASS":
                    qc_checks[
                        "FINAL_QC_PASS"
                    ],
            }
        )

        print(
            f"Eligible originals : "
            f"{qc_checks['eligible_original_count']:,}"
        )

        print(
            f"Excluded originals : "
            f"{qc_checks['excluded_original_count']:,}"
        )

        print(
            f"Fragments total    : "
            f"{qc_checks['actual_fragment_count']:,}"
        )

        print(
            f"  train            : "
            f"{qc_checks['train_fragment_count']:,}"
        )

        print(
            f"  test             : "
            f"{qc_checks['test_fragment_count']:,}"
        )

        print(
            f"  ARG              : "
            f"{qc_checks['ARG_fragment_count']:,}"
        )

        print(
            f"  nonARG           : "
            f"{qc_checks['nonARG_fragment_count']:,}"
        )

        print(
            f"FINAL_QC_PASS      : "
            f"{qc_checks['FINAL_QC_PASS']}"
        )

    # ------------------------------------------------------------------
    # Global summary.
    # ------------------------------------------------------------------

    write_csv(
        OUTPUT_ROOT
        / "all_conditions_summary.csv",
        [
            "condition",
            "full_original_count",
            "eligible_original_count",
            "excluded_original_count",
            "train_original_count",
            "test_original_count",
            "total_fragment_count",
            "train_fragment_count",
            "test_fragment_count",
            "ARG_fragment_count",
            "nonARG_fragment_count",
            "FINAL_QC_PASS",
        ],
        all_summary_rows,
    )

    write_csv(
        OUTPUT_ROOT
        / "all_conditions_excluded_originals.csv",
        [
            "condition",
            "Original.SARG.Seq.ID",
            "split",
            "ARG.or.nonARG",
            "full_protein_length_aa",
            "requested_fragment_length_aa",
            "legal_start_count",
            "reason",
        ],
        all_excluded_rows,
    )

    all_conditions_pass = all(
        row[
            "FINAL_QC_PASS"
        ]
        for row
        in all_summary_rows
    )

    global_lines = [
        f"full_original_count\t{len(original_order)}",
        f"N_PARTS\t{N_PARTS}",
        f"number_of_conditions\t{len(CONDITION_ORDER)}",
        f"original_train_count\t{original_split_counts.get('train', 0)}",
        f"original_test_count\t{original_split_counts.get('test', 0)}",
        f"original_ARG_count\t{original_class_counts.get('ARG', 0)}",
        f"original_nonARG_count\t{original_class_counts.get('nonARG', 0)}",
        f"total_exclusion_records_across_conditions\t{len(all_excluded_rows)}",
        f"ALL_CONDITIONS_QC_PASS\t{all_conditions_pass}",
    ]

    (
        OUTPUT_ROOT
        / "global_simulation_QC_summary.txt"
    ).write_text(
        "\n".join(
            global_lines
        )
        + "\n",
        encoding="utf-8",
    )

    print()
    print("=" * 120)
    print("ALL CONDITIONS COMPLETED")
    print("=" * 120)

    for row in all_summary_rows:
        print(
            f"{row['condition']:<22} "
            f"originals={row['eligible_original_count']:,} | "
            f"fragments={row['total_fragment_count']:,} | "
            f"train={row['train_fragment_count']:,} | "
            f"test={row['test_fragment_count']:,} | "
            f"QC={row['FINAL_QC_PASS']}"
        )

    print()
    print(
        f"ALL_CONDITIONS_QC_PASS = "
        f"{all_conditions_pass}"
    )

    print()
    print(
        "Canonical rule confirmed:"
    )

    print(
        "  original train -> all 5 fragments train"
    )

    print(
        "  original test  -> all 5 fragments test"
    )

    print(
        "No fragment-level re-splitting was performed."
    )

    if not all_conditions_pass:
        raise RuntimeError(
            "At least one simulated condition failed QC."
        )


if __name__ == "__main__":
    main()
