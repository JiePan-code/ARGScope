// Rasterize the verified vector masters directly onto an A4 page.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const sourceRoot = process.argv[2] || 'C:/Users/Jie Pan/Desktop/ARG模型结果/论文撰写/result图片/Figure2_Figure3_多色配色版_20260923';
const outputRoot = path.resolve(process.argv[3] || 'outputs/figure2_figure3_a4_tif_20260924');
const width = 2480;
const height = 3508;
const pad = 12;

(async () => {
  fs.mkdirSync(outputRoot, {recursive: true});
  const records = [];
  for (const name of ['Figure2_Protein', 'Figure3_DNA']) {
    const sourcePath = path.join(sourceRoot, name, `${name}_combined.svg`);
    const source = fs.readFileSync(sourcePath);
    const original = source.toString('utf8');
    if (original.includes('<image ')) throw new Error('Expected pure vector source');
    const viewBox = original.match(/viewBox="([^"]+)"/)[1].split(/\s+/).map(Number);
    const scale = Math.min((width - pad * 2) / viewBox[2], (height - pad * 2) / viewBox[3]);
    const contentWidth = Math.round(viewBox[2] * scale);
    const contentHeight = Math.round(viewBox[3] * scale);
    const resized = original.replace(/<svg\b[^>]*>/, tag => tag
      .replace(/\bwidth="[^"]*"/, `width="${contentWidth}px"`)
      .replace(/\bheight="[^"]*"/, `height="${contentHeight}px"`));
    // Supersample vector strokes and text, then reduce to final raster size.
    const content = await sharp(Buffer.from(resized), {density: 144})
      .resize(contentWidth, contentHeight).ensureAlpha().png().toBuffer();
    const left = Math.floor((width - contentWidth) / 2);
    const top = Math.floor((height - contentHeight) / 2);
    const rasterPath = path.join(outputRoot, `${name}_a4_rgba.png`);
    await sharp({create: {width, height, channels: 4, background: {r: 255, g: 255, b: 255, alpha: 0}}})
      .composite([{input: content, left, top}]).png().toFile(rasterPath);
    const hash = crypto.createHash('sha256').update(source).digest('hex');
    if (crypto.createHash('sha256').update(fs.readFileSync(sourcePath)).digest('hex') !== hash) {
      throw new Error('Source was changed');
    }
    records.push({name, sourcePath, source_sha256: hash, rasterPath, width, height,
      contentWidth, contentHeight, left, top, dpi: 300});
  }
  fs.writeFileSync(path.join(outputRoot, 'render_manifest.json'), JSON.stringify(records, null, 2));
  console.log(JSON.stringify(records, null, 2));
})().catch(error => {console.error(error); process.exit(1);});
