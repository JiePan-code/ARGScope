#!/usr/bin/env python3
"""Overall-metric parent-bootstrap violins plus the approved Type network.

Type: ARGScope empirical bootstrap density, baseline reported points only.
Subtype: ARGScope only. No invented baseline uncertainty or training repeats.
"""
from pathlib import Path
import importlib.util
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator, FormatStrFormatter

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
OUT=ROOT/'figures'
DATA=ROOT/'data'
spec=importlib.util.spec_from_file_location('type_network',SOURCE/'type_level_revision/plot_type_network_revision.py')
net=importlib.util.module_from_spec(spec)
spec.loader.exec_module(net)
base=net.base
base.FIG=OUT
base.exports.clear();base.LAYOUT_QA.clear()
boot=pd.read_csv(DATA/'ARGScope_parent_bootstrap_five_metrics.csv')
summary=pd.read_csv(DATA/'ARGScope_point_and_95CI.csv')
reported=pd.read_csv(SOURCE/'data/reported_overall_NOT_matched.csv')
matrix_source=pd.read_csv(SOURCE/'type_level_revision/data/combined_Type_profile_spearman.csv',index_col=0)
arcs_source=pd.read_csv(SOURCE/'type_level_revision/data/combined_model_Type_arcs.csv')
# The merged network hides a Type only when ARGScope is zero in ALL eight
# modality/completeness conditions. This NEVER filters the bootstrap cohort.
type_precision=pd.read_csv(SOURCE/'data/reported_per_type_NOT_matched.csv')
type_precision=type_precision[type_precision.Model.eq('ARGScope')&type_precision.Metric.eq('Precision')]
filter_rows=[]
for typ in net.ORDER:
    vals=type_precision[type_precision.Type.eq(typ)].Value
    assert len(vals)==8 and vals.notna().all()
    keep=bool(vals.gt(0).any())
    filter_rows.append(dict(Type=typ,Keep=keep,ARGScope_min=float(vals.min()),ARGScope_max=float(vals.max()),
                            N_positive_conditions=int(vals.gt(0).sum()),N_conditions=8,
                            Rule='hide_only_if_ARGScope_zero_in_all_8_conditions',Bootstrap_sample_filter=False))
filter_audit=pd.DataFrame(filter_rows)
net.ORDER=filter_audit.loc[filter_audit.Keep,'Type'].tolist()
corr=matrix_source.loc[net.ORDER,net.ORDER].to_numpy()
arcs=arcs_source[arcs_source.Type.isin(net.ORDER)].copy()
filter_audit.to_csv(DATA/'network_Type_display_filter.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(corr,index=net.ORDER,columns=net.ORDER).to_csv(DATA/'displayed_Type_profile_spearman.csv',encoding='utf-8-sig')
arcs.to_csv(DATA/'displayed_model_Type_arcs.csv',index=False,encoding='utf-8-sig')
PCTS=[60,70,80,90]
METRICS=['Accuracy','Precision','Recall','F1','MCC']
DRAW_AUDIT=[]


def violin(ax,values,x,color,width=.57):
    values=np.asarray(values,float)
    assert len(values)==2000 and np.isfinite(values).all()
    if np.ptp(values)<1e-12:
        ax.hlines(values[0],x-width/2,x+width/2,color=color,lw=1.3)
        return
    parts=ax.violinplot([values],positions=[x],widths=[width],showextrema=False,
                        showmeans=False,showmedians=False,points=160,bw_method='scott')
    for body in parts['bodies']:
        body.set_facecolor(color);body.set_edgecolor(color);body.set_alpha(.50);body.set_linewidth(.7)


def metric_panel(ax,mod,level,metric,references=False,model_color=True):
    color=base.COLORS['ARGScope'] if model_color else base.MODCOL[mod]
    extrema=[]
    for x,pct in enumerate(PCTS):
        values=boot[(boot.Modality==mod)&(boot.Level==level)&(boot.Completeness==pct)][metric].to_numpy()
        row=summary[(summary.Modality==mod)&(summary.Level==level)&(summary.Completeness==pct)&(summary.Metric==metric)].iloc[0]
        violin(ax,values,x,color)
        ax.vlines(x,row.CI_low,row.CI_high,color=color,lw=1.0,zorder=5)
        ax.hlines([row.CI_low,row.CI_high],x-.06,x+.06,color=color,lw=.8,zorder=5)
        ax.scatter(x,row.Point_estimate,s=10,marker='D',facecolor=color,edgecolor='white',lw=.35,zorder=7)
        extrema.extend([values.min(),values.max(),row.Point_estimate])
        DRAW_AUDIT.append(dict(Modality=mod,Completeness=pct,Level=level,Metric=metric,
                              Bootstrap_n=len(values),Bootstrap_min=values.min(),Bootstrap_max=values.max(),
                              Point_estimate=row.Point_estimate,References=references))
        if references:
            others=[m for m in base.MODELS[mod] if m!='ARGScope']
            offsets=np.linspace(-.24,.24,len(others))
            for model,offset in zip(others,offsets):
                val=reported[(reported.modality==mod)&(reported.Model==model)&(reported.pct==pct)].iloc[0][metric]
                assert np.isfinite(val)
                ax.scatter(x+offset,val,s=13,marker='o',facecolor=base.COLORS[model],edgecolor='white',lw=.35,zorder=6)
                extrema.append(val)
    # Distribution plots use explicit, metric-specific scales; every point is retained.
    lo,hi=min(extrema),max(extrema)
    margin=max((hi-lo)*.08,.008)
    lower=max(-1 if metric=='MCC' else 0,np.floor((lo-margin)*20)/20)
    upper=min(1,np.ceil((hi+margin)*20)/20)
    if upper-lower<.06:lower=max(0,upper-.06)
    ax.set_xlim(-.5,3.5);ax.set_ylim(lower-.002,upper+.002)
    ax.set_xticks(range(4),[f'{p}%' for p in PCTS])
    ax.yaxis.set_major_locator(MaxNLocator(nbins=3,min_n_ticks=3))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_title(metric,fontsize=8,pad=4)
    base.clean(ax)


def model_legend(fig,y=.997):
    handles=[Line2D([0],[0],color='none',marker='o',markerfacecolor=base.COLORS[m],markeredgecolor='white',markersize=4,label=m)
             for m in base.MODELS['protein'] if m!='ARGScope']
    handles.append(Patch(facecolor=base.COLORS['ARGScope'],edgecolor=base.COLORS['ARGScope'],alpha=.5,label='ARGScope bootstrap'))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,y),ncol=5,frameon=False,fontsize=8,columnspacing=1.8)


def combined():
    fig=base.canvas(280,360)
    model_legend(fig)
    for mod,top in [('protein',20),('dna',61)]:
        for j,metric in enumerate(METRICS):
            metric_panel(base.ax_mm(fig,18+52*j,top,44,26),mod,'Type',metric,references=True)
        base.text_mm(fig,4,top+13,('Protein' if mod=='protein' else 'DNA')+' · Type',rotation=90,ha='center',va='center',fontsize=8.8,fontweight='bold')
    base.text_mm(fig,142,101,'Type: baseline points are reported references; cohorts / aggregation not harmonized',ha='center',fontsize=6.6,color='#62686D')
    sm,_=net.network(base.ax_mm(fig,1,106,269,150),corr,arcs,fontsize=6.2)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,267,147,2.2,60));cb.set_ticks([-1,-.5,0,.5,1])
    cb.ax.tick_params(labelsize=6,length=2);cb.set_label('Profile correlation (ρ)',fontsize=6.8)
    for mod,top in [('protein',278),('dna',320)]:
        for j,metric in enumerate(METRICS):metric_panel(base.ax_mm(fig,18+52*j,top,44,26),mod,'Subtype',metric)
        base.text_mm(fig,4,top+13,('Protein' if mod=='protein' else 'DNA')+' · Subtype',rotation=90,ha='center',va='center',fontsize=8.8,fontweight='bold')
    base.text_mm(fig,142,359,'ARGScope only at subtype level · 2,000 parent bootstraps · diamond: observed score · bars: 95% interval',ha='center',fontsize=6.3,color='#62686D')
    base.save(fig,'ARGScope_violin_and_Type_network_main')


def separate(level):
    fig=base.canvas(280,133)
    if level=='Type':model_legend(fig,.995)
    else:
        fig.legend(handles=[Patch(facecolor=base.MODCOL[m],alpha=.5,label='Protein' if m=='protein' else 'DNA') for m in ['protein','dna']],
                   loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.995),fontsize=8)
    for mod,top in [('protein',24),('dna',79)]:
        for j,metric in enumerate(METRICS):
            metric_panel(base.ax_mm(fig,18+52*j,top,44,33),mod,level,metric,references=level=='Type',model_color=level=='Type')
        base.text_mm(fig,4,top+16,'Protein' if mod=='protein' else 'DNA',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    note='Baseline points: unmatched reported cohorts; ARGScope: parent-bootstrap violins.' if level=='Type' else 'ARGScope only. Each violin is 2,000 parent-bootstrap overall scores, not a distribution across classes.'
    base.text_mm(fig,144,126,note,ha='center',fontsize=7,color='#62686D')
    base.save(fig,f'{level.lower()}_overall_five_metrics_bootstrap_violin')


def centered_uncertainty():
    """An optional legible uncertainty-only view with explicit difference axes."""
    fig=base.canvas(280,131)
    fig.legend(handles=[Patch(facecolor=base.MODCOL[m],alpha=.5,label='Protein' if m=='protein' else 'DNA') for m in ['protein','dna']],
               loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.995),fontsize=8)
    for level,top in [('Type',23),('Subtype',79)]:
        for j,metric in enumerate(METRICS):
            ax=base.ax_mm(fig,18+52*j,top,44,33)
            limit=0
            for mod,offset in [('protein',-.17),('dna',.17)]:
                for x,pct in enumerate(PCTS):
                    values=boot[(boot.Modality==mod)&(boot.Level==level)&(boot.Completeness==pct)][metric].to_numpy()
                    row=summary[(summary.Modality==mod)&(summary.Level==level)&(summary.Completeness==pct)&(summary.Metric==metric)].iloc[0]
                    centered=values-row.Point_estimate
                    violin(ax,centered,x+offset,base.MODCOL[mod],width=.30)
                    ax.vlines(x+offset,row.CI_low-row.Point_estimate,row.CI_high-row.Point_estimate,color=base.MODCOL[mod],lw=.75)
                    limit=max(limit,float(np.max(np.abs(centered))))
            limit=np.ceil((limit+.001)/.01)*.01
            ax.set(ylim=(-limit,limit),xlim=(-.5,3.5),xticks=range(4),xticklabels=[f'{p}%' for p in PCTS])
            ax.axhline(0,color='#777D83',ls='--',lw=.6)
            ax.set_title(metric,pad=4);ax.yaxis.set_major_locator(MaxNLocator(3));ax.yaxis.set_major_formatter(FormatStrFormatter('%+.2f'))
            base.clean(ax)
        base.text_mm(fig,4,top+16,level+' · Δ score',rotation=90,ha='center',va='center',fontsize=9,fontweight='bold')
    base.text_mm(fig,144,126,'Δ score = bootstrap score − observed score. This view compares uncertainty, not model accuracy.',ha='center',fontsize=7,color='#62686D')
    base.save(fig,'ARGScope_uncertainty_only_centered_violin')


if __name__=='__main__':
    combined()
    separate('Type');separate('Subtype')
    centered_uncertainty()
    pd.DataFrame(DRAW_AUDIT).to_csv(DATA/'plotted_violin_audit.csv',index=False,encoding='utf-8-sig')
    (ROOT/'figure_manifest.json').write_text(json.dumps(base.exports,indent=2),encoding='utf-8')
    (ROOT/'layout_validation.json').write_text(json.dumps(base.LAYOUT_QA,indent=2),encoding='utf-8')
    print('Saved 4 designs in PNG / PDF / SVG; Type network retained without data changes.')
