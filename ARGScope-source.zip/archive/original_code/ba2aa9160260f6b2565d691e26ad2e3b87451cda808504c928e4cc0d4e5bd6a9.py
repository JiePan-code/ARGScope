"""Truth-independent, name-only Type harmonisation. No ontology inference.

Missing model vocabulary is not a missing measurement: its Type predictions
remain unresolved errors; all 23 reference labels still enter each macro score.
Original category text is retained in the mapping audit.
"""
import re
import numpy as np
import pandas as pd

POLICY = 'strict_name_equivalence_v1'
AUDIT = []
RAW_CHECKS = []

def key(value):
    return re.sub(r'[\s_\-]+', '', str(value).strip().casefold())

# Explicit spelling/inflection aliases only, never a drug-family relationship.
ALIASES = {
    'mls': 'macrolide-lincosamide-streptogramin',
    'betalactams': 'beta_lactam',
    'aminoglycosides': 'aminoglycoside',
    'quinolones': 'quinolone',
    'tetracyclines': 'tetracycline',
    'multidrugresistance': 'multidrug',
}

def map_name(binary, raw, labels):
    if binary == 'nonARG':
        return 'nonARG', 'binary_nonARG'
    assert binary == 'ARG'
    exact = {key(label): label for label in labels}
    assert len(exact) == len(labels)
    k = key(raw)
    if k in exact:
        return exact[k], 'exact_or_format_only'
    if k in ALIASES and ALIASES[k] in labels:
        return ALIASES[k], 'explicit_abbreviation_or_spelling'
    # Multilabel outputs are not relabelled as multidrug or as a chosen target.
    return '__STRICT_NAME_UNMAPPED__', ('unresolved_multi_category' if ';' in str(raw) or ':' in str(raw)
                                         else 'no_same_name_in_ARGScope23')

def remap(df, mod, model, pct, labels, rawcol, rawpath):
    binary = df['_binary_pred'] if '_binary_pred' in df else pd.Series('ARG', index=df.index)
    pairs = list(zip(binary, df[rawcol].astype(str)))
    lookup = {pair: map_name(*pair, labels) for pair in set(pairs)}
    df['_legacy_p'] = df['_p']
    df['_p'] = [lookup[pair][0] for pair in pairs]
    frame = pd.DataFrame({'Binary_prediction':binary.to_numpy(), 'Raw_name':df[rawcol].to_numpy(),
        'Previous_mapped_Type':df['_legacy_p'].to_numpy(), 'Strict_mapped_Type':df['_p'].to_numpy(),
        'Rule':[lookup[pair][1] for pair in pairs], 'N':1,
        'N_fixed23_truth':df['_y'].isin(labels).astype(int).to_numpy(),
        'Changed_prediction':df['_p'].ne(df['_legacy_p']).astype(int).to_numpy()})
    groupcols=['Binary_prediction','Raw_name','Previous_mapped_Type','Strict_mapped_Type','Rule']
    agg=frame.groupby(groupcols,dropna=False,sort=True)[['N','N_fixed23_truth','Changed_prediction']].sum().reset_index()
    agg.insert(0,'Completeness',pct); agg.insert(0,'Model',model); agg.insert(0,'Modality',mod)
    agg['Raw_source']=str(rawpath); agg['Mapping_policy']=POLICY
    AUDIT.extend(agg.to_dict('records'))
    return df

def verify_raw(df, mod, model, pct, rawroot, read):
    if model=='ARGNet':
        folder=rawroot/'ARGnet'/('protein' if mod=='Protein' else 'DNA')
        names=df.source_file.unique(); assert len(names)==1
        path=folder/names[0]
        raw=read(path,sep='\t'); idcol='test_id'; rawcol='resistance_category'; savedcol='raw_resistance_category'
    elif model=='FunGeneTyper':
        path=rawroot/f'FunGenetyper/Protein/{pct}p_result.csv'
        raw=read(path); idcol='id'; rawcol='class_category'; savedcol='raw_class_category'
    else:
        raise ValueError(model)
    assert raw[idcol].is_unique and set(raw[idcol])==set(df._id)
    indexed=raw.set_index(idcol).loc[df._id]
    np.testing.assert_array_equal(indexed[rawcol].astype(str),df[savedcol].astype(str))
    binary=(indexed.ARG_prediction.map(lambda x: {'arg':'ARG','nonarg':'nonARG'}[key(x)]) if model=='ARGNet' else
            np.where(indexed[rawcol].map(key).eq('others'),'nonARG','ARG'))
    np.testing.assert_array_equal(binary,df._binary_pred)
    RAW_CHECKS.append(dict(Modality=mod,Model=model,Completeness=pct,N=len(df),
        Unique_IDs_and_raw_names_match=True,Binary_calls_match=True,Source=str(path)))
    return path,savedcol

def self_test():
    labels=['beta_lactam','aminoglycoside','quinolone','tetracycline','multidrug','novobiocin','vancomycin',
        'tetracenomycin_C','other_peptide_antibiotics','rifamycin','trimethoprim','macrolide-lincosamide-streptogramin']
    for raw,target in {'beta-lactam':'beta_lactam','Betalactams':'beta_lactam','MLS':labels[-1],
        'Aminoglycosides':'aminoglycoside','TETRACENOMYCIN C':'tetracenomycin_C',
        'Multi-drug resistance':'multidrug','novobiocin':'novobiocin','vancomycin':'vancomycin'}.items():
        assert map_name('ARG',raw,labels)[0]==target
    for raw in ['aminocoumarin','glycopeptide','tetracenomycin','kasugamycin','thiostrepton','rifampin',
        'diaminopyrimidine','fluoroquinolone','macrolide','lincosamide','streptogramin','phenicol',
        'beta-lactam;aminoglycoside','lincosamide;macrolide;streptogramin']:
        assert map_name('ARG',raw,labels)[0]=='__STRICT_NAME_UNMAPPED__',raw
    assert map_name('nonARG','vancomycin',labels)[0]=='nonARG'

if __name__=='__main__':
    self_test(); print('PASS: name-only mappings, forbidden ontology conversions and binary independence.')
