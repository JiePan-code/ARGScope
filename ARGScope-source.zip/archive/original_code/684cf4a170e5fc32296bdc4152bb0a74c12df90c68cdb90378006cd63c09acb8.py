#!/usr/bin/env python3
"""Read-only validation for the local ARGScope Full/ablation suite."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path

import torch


SUITE_ROOT = Path(__file__).resolve().parent


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=None)
    return parser.parse_args()


def resolve_data_root(value: Path | None) -> Path:
    candidates: list[Path] = []
    if value is not None:
        candidates.append(value)
    configured = os.environ.get("ARGSCOPE_DATA_ROOT", "").strip()
    if configured:
        candidates.append(Path(configured))
    candidates.append(SUITE_ROOT.parent)
    for candidate in candidates:
        candidate = candidate.expanduser().resolve()
        if (candidate / "train_ids_subtype2.txt").is_file() and (
            candidate / "test_ids_subtype2.txt"
        ).is_file():
            return candidate
    checked = "\n  ".join(str(path.expanduser().resolve()) for path in candidates)
    raise FileNotFoundError(f"Could not locate the data root. Checked:\n  {checked}")


def read_ids(path: Path) -> list[str]:
    values = [line.strip() for line in path.read_text(encoding="utf-8-sig").splitlines()]
    values = [value for value in values if value]
    if len(values) != len(set(values)):
        raise ValueError(f"Duplicate IDs in {path}")
    return values


def load_embedding(path: Path, expected_dim: int):
    obj = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(obj, dict) or "ids" not in obj or "embeddings" not in obj:
        raise ValueError(f"Unexpected embedding PT structure: {path}")
    ids = [str(value) for value in obj["ids"]]
    embeddings = obj["embeddings"]
    if embeddings.ndim != 2 or embeddings.shape != (len(ids), expected_dim):
        raise ValueError(
            f"Unexpected embedding shape in {path}: {tuple(embeddings.shape)}; "
            f"expected ({len(ids)}, {expected_dim})"
        )
    if len(ids) != len(set(ids)):
        raise ValueError(f"Duplicate IDs in embedding PT: {path}")
    return ids, tuple(embeddings.shape)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def read_structure(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        required = {"SARG.Seq.ID", "Type", "Subtype", "ARG.or.nonARG"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError(
                f"Structure table must contain {sorted(required)}; "
                f"found {reader.fieldnames}"
            )
        rows = list(reader)
    mapping = {}
    for row in rows:
        seq_id = row["SARG.Seq.ID"].strip()
        if not seq_id:
            raise ValueError("Empty sequence ID in structure table")
        if seq_id in mapping:
            raise ValueError(f"Duplicate structure ID: {seq_id}")
        mapping[seq_id] = {
            "type": row["Type"].strip(),
            "subtype": row["Subtype"].strip(),
            "binary": row["ARG.or.nonARG"].strip(),
        }
    return mapping


def main():
    args = parse_args()
    data = resolve_data_root(args.data_root)
    protein_pt = (
        data / "ESM2_EMBEDDING" / "percent_100" / "full_1to1_esm2_mean.pt"
    )
    dna_pt = (
        data / "DNABERT2_embedding" / "percent_100" / "full_1to1_dnabert2_mean.pt"
    )
    structure_path = data / "all_ARG_nonARG_1to1_structure.txt"
    train_path = data / "train_ids_subtype2.txt"
    test_path = data / "test_ids_subtype2.txt"
    protein_best = (
        data.parent
        / "2.Protein_student_long_gridsearch"
        / "best_parameters_and_test_results.csv"
    )

    required_files = [
        protein_pt,
        dna_pt,
        structure_path,
        train_path,
        test_path,
        protein_best,
    ]
    missing = [str(path) for path in required_files if not path.is_file()]
    empty = [str(path) for path in required_files if path.is_file() and path.stat().st_size == 0]
    if missing or empty:
        raise FileNotFoundError(
            "Input validation failed.\n"
            f"Missing: {missing}\n"
            f"Empty: {empty}"
        )

    train_ids = read_ids(train_path)
    test_ids = read_ids(test_path)
    if set(train_ids) & set(test_ids):
        raise ValueError("Authoritative train/test ID files overlap")

    protein_ids, protein_shape = load_embedding(protein_pt, 1280)
    dna_ids, dna_shape = load_embedding(dna_pt, 768)
    if protein_ids != dna_ids:
        raise ValueError("Protein and DNA embedding IDs/order are not identical")

    embedding_ids = set(protein_ids)
    selected_ids = set(train_ids) | set(test_ids)
    if not selected_ids.issubset(embedding_ids):
        raise ValueError(
            f"Split IDs missing from embeddings: {len(selected_ids - embedding_ids)}"
        )

    structure = read_structure(structure_path)
    if not selected_ids.issubset(structure):
        raise ValueError(
            f"Split IDs missing from structure table: {len(selected_ids - set(structure))}"
        )

    def split_summary(ids: list[str]):
        labels = [structure[seq_id] for seq_id in ids]
        binary = Counter(label["binary"] for label in labels)
        arg_labels = [label for label in labels if label["binary"].upper() == "ARG"]
        return {
            "records": len(ids),
            "binary_counts": dict(sorted(binary.items())),
            "arg_subtypes": len({label["subtype"] for label in arg_labels}),
            "arg_types": len({label["type"] for label in arg_labels}),
        }

    all_arg = [
        structure[seq_id]
        for seq_id in selected_ids
        if structure[seq_id]["binary"].upper() == "ARG"
    ]
    report = {
        "status": "PASS",
        "suite_root": str(SUITE_ROOT),
        "data_root": str(data),
        "python": sys.executable,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "protein_embedding": {"path": str(protein_pt), "shape": protein_shape},
        "dna_embedding": {"path": str(dna_pt), "shape": dna_shape},
        "embedding_ids_same_order": True,
        "embedding_records": len(protein_ids),
        "external_train": split_summary(train_ids),
        "external_test": split_summary(test_ids),
        "train_test_overlap": 0,
        "selected_records": len(selected_ids),
        "excluded_embedding_records": len(embedding_ids - selected_ids),
        "retained_arg_subtypes": len({label["subtype"] for label in all_arg}),
        "retained_arg_types": len({label["type"] for label in all_arg}),
        "train_ids_sha256": file_sha256(train_path),
        "test_ids_sha256": file_sha256(test_path),
        "structure_sha256": file_sha256(structure_path),
        "old_unsuffixed_artifacts_are_not_inputs": True,
    }
    report_path = SUITE_ROOT / "preflight_report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"\nPASS: input/split checks completed. Report: {report_path}")


if __name__ == "__main__":
    main()
