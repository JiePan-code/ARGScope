# -*- coding: utf-8 -*-

import random
import pandas as pd

# =========================
# 配置区
# =========================

PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
DNA_FASTA = "all_arg_nonarg_dna.fasta"

# 原始标签表，必须包含三列：id,type,subtype
ID_LABEL_CSV = "all_arg_nonarg_id_label.csv"

NUM_PARTS = 5
SEED = 42

# 加入 90%
PERCENTAGES = [30, 40, 50, 60, 70, 80, 90]

random.seed(SEED)


# =========================
# FASTA 读取函数
# =========================

def read_fasta(fasta_file):
    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))

                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line)

        if header is not None:
            records.append((header, "".join(seq_lines)))

    return records


# =========================
# FASTA 写出函数
# =========================

def write_fasta(records, out_file, line_width=60):
    with open(out_file, "w", encoding="utf-8") as f:
        for header, seq in records:
            f.write(f">{header}\n")

            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")


# =========================
# 提取主 ID
# 默认取 header 空格前第一段
# =========================

def get_main_id(header):
    return str(header).split()[0].strip()


# =========================
# 构建 ID 字典
# =========================

def build_record_dict(records, source_name="fasta"):
    record_dict = {}
    duplicate_ids = []

    for header, seq in records:
        seq_id = get_main_id(header)

        if seq_id in record_dict:
            duplicate_ids.append(seq_id)
        else:
            record_dict[seq_id] = (header, seq)

    if duplicate_ids:
        show_ids = ", ".join(duplicate_ids[:10])
        raise ValueError(
            f"{source_name} 中发现重复 ID，无法唯一自动配对。示例重复 ID: {show_ids}"
        )

    return record_dict


# =========================
# protein-DNA 自动配对
# =========================

def build_paired_records(protein_records, dna_records):
    protein_dict = build_record_dict(protein_records, source_name="protein fasta")
    dna_dict = build_record_dict(dna_records, source_name="dna fasta")

    protein_ids = set(protein_dict.keys())
    dna_ids = set(dna_dict.keys())

    common_ids = sorted(protein_ids & dna_ids)
    protein_only_ids = sorted(protein_ids - dna_ids)
    dna_only_ids = sorted(dna_ids - protein_ids)

    paired_records = []

    for seq_id in common_ids:
        p_header, p_seq = protein_dict[seq_id]
        d_header, d_seq = dna_dict[seq_id]

        paired_records.append((seq_id, p_header, p_seq, d_header, d_seq))

    print(f"Protein 总 ID 数: {len(protein_ids)}")
    print(f"DNA 总 ID 数: {len(dna_ids)}")
    print(f"成功配对 ID 数: {len(common_ids)}")
    print(f"仅在 Protein 中存在的 ID 数: {len(protein_only_ids)}")
    print(f"仅在 DNA 中存在的 ID 数: {len(dna_only_ids)}")

    if protein_only_ids:
        print("示例 Protein-only IDs:", protein_only_ids[:10])

    if dna_only_ids:
        print("示例 DNA-only IDs:", dna_only_ids[:10])

    if len(common_ids) == 0:
        raise ValueError("Protein 和 DNA 没有可配对的共同 ID。")

    return paired_records


# =========================
# 读取标签表
# =========================

def read_id_label_table(csv_file):
    df = pd.read_csv(csv_file)

    required_cols = {"id", "type", "subtype"}
    if not required_cols.issubset(df.columns):
        raise ValueError(
            f"{csv_file} 必须包含列: id,type,subtype；当前列为: {list(df.columns)}"
        )

    df = df[["id", "type", "subtype"]].copy()

    df["id"] = df["id"].astype(str).str.strip()
    df["type"] = df["type"].astype(str).str.strip()
    df["subtype"] = df["subtype"].astype(str).str.strip()

    if df["id"].duplicated().any():
        dup_ids = df.loc[df["id"].duplicated(), "id"].tolist()[:10]
        raise ValueError(f"标签表中存在重复 id，例如: {dup_ids}")

    return df


# =========================
# 生成 expanded id 表
# 格式：id,type,subtype
# =========================

def write_expanded_id_table(id_df, out_file, num_parts=5):
    rows = []

    for _, row in id_df.iterrows():
        original_id = row["id"]
        type_ = row["type"]
        subtype = row["subtype"]

        for i in range(1, num_parts + 1):
            rows.append({
                "id": f"{original_id}_{i}",
                "type": type_,
                "subtype": subtype,
            })

    out_df = pd.DataFrame(rows, columns=["id", "type", "subtype"])
    out_df.to_csv(out_file, index=False, encoding="utf-8-sig")

    return out_df


# =========================
# 联动按比例切割
# 不翻译
#
# 规则：
# 1. aa_len = protein长度 × percent
# 2. nt_len = aa_len × 3
# 3. protein 和 DNA 使用同一个相对起点
# 4. p_start 选定后，d_start = p_start × 3
# 5. 直接截取原 protein 和原 DNA
# =========================

def make_paired_percent_reads_by_id(paired_records, percent, num_parts=5):
    protein_out = []
    dna_out = []
    mapping_rows = []

    full_length_count = 0

    for seq_id, p_header, p_seq, d_header, d_seq in paired_records:
        p_seq = str(p_seq).strip()
        d_seq = str(d_seq).strip().upper().replace("U", "T")

        p_len = len(p_seq)
        d_len = len(d_seq)

        if p_len < 1 or d_len < 3:
            continue

        aa_len = round(p_len * percent / 100.0)

        if aa_len < 1:
            aa_len = 1

        if aa_len > p_len:
            aa_len = p_len

        nt_len = aa_len * 3

        for part in range(1, num_parts + 1):
            new_id = f"{seq_id}_{part}"

            if p_len <= aa_len or d_len <= nt_len:
                p_start = 0
                d_start = 0

                p_sub = p_seq
                d_sub = d_seq

                full_length_count += 1
            else:
                max_p_start_by_protein = p_len - aa_len
                max_p_start_by_dna = (d_len - nt_len) // 3
                max_p_start = min(max_p_start_by_protein, max_p_start_by_dna)

                if max_p_start < 0:
                    p_start = 0
                    d_start = 0

                    p_sub = p_seq
                    d_sub = d_seq

                    full_length_count += 1
                else:
                    p_start = random.randint(0, max_p_start)
                    d_start = p_start * 3

                    p_sub = p_seq[p_start:p_start + aa_len]
                    d_sub = d_seq[d_start:d_start + nt_len]

            protein_out.append((new_id, p_sub))
            dna_out.append((new_id, d_sub))

            mapping_rows.append({
                "id": new_id,
                "original_id": seq_id,
                "part": part,
                "percent": percent,
                "protein_start_0based": p_start,
                "protein_end_0based_exclusive": p_start + len(p_sub),
                "protein_length": len(p_sub),
                "dna_start_0based": d_start,
                "dna_end_0based_exclusive": d_start + len(d_sub),
                "dna_length": len(d_sub),
                "original_protein_length": p_len,
                "original_dna_length": d_len,
            })

    return protein_out, dna_out, mapping_rows, full_length_count


# =========================
# 主程序
# =========================

def main():
    protein_records = read_fasta(PROTEIN_FASTA)
    dna_records = read_fasta(DNA_FASTA)
    id_df = read_id_label_table(ID_LABEL_CSV)

    print(f"Protein 原始记录数: {len(protein_records)}")
    print(f"DNA 原始记录数: {len(dna_records)}")
    print(f"标签表记录数: {len(id_df)}")

    paired_records = build_paired_records(protein_records, dna_records)

    expanded_id_out = "expanded_id_table_5x2.csv"
    expanded_df = write_expanded_id_table(
        id_df=id_df,
        out_file=expanded_id_out,
        num_parts=NUM_PARTS,
    )

    print("=" * 80)
    print(f"已输出 expanded ID 表: {expanded_id_out}")
    print(f"expanded ID 表记录数: {len(expanded_df)}")

    for pct in PERCENTAGES:
        protein_outfile = f"protein_{pct}pct_5parts.fasta"
        dna_outfile = f"dna_{pct}pct_5parts.fasta"
        mapping_outfile = f"fragment_coordinate_mapping_{pct}pct_5parts.csv"

        protein_short, dna_short, mapping_rows, full_length_count = make_paired_percent_reads_by_id(
            paired_records=paired_records,
            percent=pct,
            num_parts=NUM_PARTS,
        )

        write_fasta(protein_short, protein_outfile)
        write_fasta(dna_short, dna_outfile)

        mapping_df = pd.DataFrame(mapping_rows)
        mapping_df.to_csv(mapping_outfile, index=False, encoding="utf-8-sig")

        print("=" * 80)
        print(f"[{pct}%] 已输出:")
        print(f"  - {protein_outfile}  共 {len(protein_short)} 条")
        print(f"  - {dna_outfile}      共 {len(dna_short)} 条")
        print(f"  - {mapping_outfile}  共 {len(mapping_df)} 行")
        print(f"  - 使用全长片段数: {full_length_count}")

        if len(protein_short) != len(dna_short):
            raise ValueError(f"{pct}% 输出错误: protein 和 DNA 数量不一致。")

    print("=" * 80)
    print("Done.")


if __name__ == "__main__":
    main()