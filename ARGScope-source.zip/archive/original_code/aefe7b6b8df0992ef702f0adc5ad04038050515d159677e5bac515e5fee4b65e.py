import sys
import math
import time
import shutil
import subprocess
from pathlib import Path


# ============================================================
# 1. 项目目录
# ============================================================

WORKDIR = Path(__file__).resolve().parent

# SARG nucleotide database FASTA
DB_FASTA = WORKDIR / "Nucleotide_SARG_v3.2_Long.fasta"

# 最终结果目录
OUT_DIR = WORKDIR / "BLASTN_all_reads_results"
OUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. BLAST数据库放在纯英文、无空格路径
# ============================================================

SAFE_DB_DIR = Path(r"E:\BLAST_DB")
SAFE_DB_DIR.mkdir(parents=True, exist_ok=True)

DB_PREFIX = SAFE_DB_DIR / "Nucleotide_SARG_v3.2_Long"


# ============================================================
# 3. 临时chunk目录
# ============================================================

CHUNK_ROOT = WORKDIR / "_blastn_chunks"
CHUNK_ROOT.mkdir(parents=True, exist_ok=True)


# ============================================================
# 4. BLAST参数
# ============================================================

NUM_THREADS = 16

EVALUE = "1e-5"

MAX_TARGET_SEQS = 10

# ============================================================
# 每多少条 reads 算一个 epoch
# ============================================================

CHUNK_SIZE = 1_000_000


# ============================================================
# 5. 找BLAST程序
# ============================================================

def find_executable(name):

    system_path = shutil.which(name)

    if system_path:
        return system_path

    system_path = shutil.which(f"{name}.exe")

    if system_path:
        return system_path

    manual_path = Path(
        rf"E:\BLAST_1\blast-2.17.0+\bin\{name}.exe"
    )

    if manual_path.exists():
        return str(manual_path)

    return None


BLASTN = find_executable("blastn")
MAKEBLASTDB = find_executable("makeblastdb")


# ============================================================
# 6. 时间格式
# ============================================================

def format_time(seconds):

    if seconds < 60:
        return f"{seconds:.1f} sec"

    if seconds < 3600:
        return f"{seconds / 60:.2f} min"

    return f"{seconds / 3600:.2f} h"


# ============================================================
# 7. FASTA读取器
#
# 支持：
# >ID
# ACTG...
#
# 也支持多行sequence
# ============================================================

def fasta_reader(path):

    header = None
    seq_lines = []

    with open(
        path,
        "r",
        encoding="utf-8",
        errors="ignore"
    ) as f:

        for line in f:

            if line.startswith(">"):

                if header is not None:

                    yield (
                        header,
                        "".join(seq_lines)
                    )

                header = line.rstrip("\n\r")
                seq_lines = []

            else:

                seq_lines.append(
                    line.strip()
                )

        if header is not None:

            yield (
                header,
                "".join(seq_lines)
            )


# ============================================================
# 8. 统计FASTA reads数
# ============================================================

def count_fasta_reads(path):

    print()
    print(f"Counting reads: {path.name}")

    count = 0

    with open(
        path,
        "r",
        encoding="utf-8",
        errors="ignore"
    ) as f:

        for line in f:

            if line.startswith(">"):
                count += 1

    print(f"Total reads: {count:,}")

    return count


# ============================================================
# 9. 写一个chunk
# ============================================================

def write_chunk(records, output_path):

    with open(
        output_path,
        "w",
        encoding="utf-8"
    ) as fout:

        for header, seq in records:

            fout.write(header + "\n")
            fout.write(seq + "\n")


# ============================================================
# 10. 判断数据库是否存在
# ============================================================

def database_exists(prefix):

    known_extensions = {
        ".nhr",
        ".nin",
        ".nsq",
        ".nog",
        ".nsd",
        ".nsi",
        ".ndb",
        ".not",
        ".ntf",
        ".nto",
    }

    files = list(
        prefix.parent.glob(
            prefix.name + ".*"
        )
    )

    for f in files:

        if f.suffix.lower() in known_extensions:
            return True

    return False


# ============================================================
# 11. 检查环境
# ============================================================

print("=" * 80)
print("Local BLASTN pipeline - 1,000,000 reads per epoch")
print("=" * 80)

print(f"Project directory : {WORKDIR}")
print(f"Database FASTA    : {DB_FASTA}")
print(f"BLAST database    : {DB_PREFIX}")
print(f"Output directory  : {OUT_DIR}")
print(f"Chunk size        : {CHUNK_SIZE:,}")
print(f"Threads           : {NUM_THREADS}")
print()

if BLASTN is None:

    print("[ERROR] 找不到 blastn.exe")
    sys.exit(1)

if MAKEBLASTDB is None:

    print("[ERROR] 找不到 makeblastdb.exe")
    sys.exit(1)

if not DB_FASTA.exists():

    print("[ERROR] 找不到 nucleotide database FASTA:")
    print(DB_FASTA)

    sys.exit(1)

print(f"blastn      : {BLASTN}")
print(f"makeblastdb : {MAKEBLASTDB}")


# ============================================================
# 12. 找9个样本
# ============================================================

query_files = []

query_files.extend(
    sorted(
        WORKDIR.glob(
            "argbert_*_all_reads.fasta"
        )
    )
)

query_files.extend(
    sorted(
        WORKDIR.glob(
            "argscope_*_all_reads.fasta"
        )
    )
)

query_files = list(
    dict.fromkeys(query_files)
)

if not query_files:

    print("[ERROR] 没找到 *_all_reads.fasta")
    sys.exit(1)


print()
print("=" * 80)
print(
    f"Found {len(query_files)} query FASTA files"
)
print("=" * 80)

for f in query_files:
    print(f.name)


# ============================================================
# 13. 建立BLAST nucleotide database
# ============================================================

if database_exists(DB_PREFIX):

    print()
    print("=" * 80)
    print("BLAST database already exists")
    print("=" * 80)
    print(DB_PREFIX)

else:

    print()
    print("=" * 80)
    print("Building nucleotide BLAST database")
    print("=" * 80)

    cmd = [
        MAKEBLASTDB,

        "-in",
        "Nucleotide_SARG_v3.2_Long.fasta",

        "-dbtype",
        "nucl",

        "-parse_seqids",

        "-blastdb_version",
        "4",

        "-out",
        str(DB_PREFIX),
    ]

    print("Command:")
    print(" ".join(cmd))

    try:

        subprocess.run(
            cmd,
            cwd=str(WORKDIR),
            check=True
        )

    except subprocess.CalledProcessError as e:

        print()
        print("[ERROR] makeblastdb failed")
        print(e)

        sys.exit(1)

    print()
    print("[OK] BLAST database created.")


# ============================================================
# 14. BLAST输出格式
# ============================================================

OUTFMT = (
    "6 "
    "qseqid "
    "sseqid "
    "pident "
    "length "
    "mismatch "
    "gapopen "
    "qstart "
    "qend "
    "sstart "
    "send "
    "evalue "
    "bitscore "
    "qlen "
    "slen"
)


# ============================================================
# 15. 开始处理全部样本
# ============================================================

global_start = time.time()


for sample_index, query in enumerate(
    query_files,
    start=1
):

    sample_start_time = time.time()

    sample_name = query.stem.replace(
        "_all_reads",
        ""
    )

    # --------------------------------------------------------
    # 输出目录
    # --------------------------------------------------------

    sample_dir = OUT_DIR / sample_name
    sample_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    # 每个epoch单独保存
    epoch_dir = sample_dir / "epochs"
    epoch_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    # 临时FASTA目录
    chunk_dir = CHUNK_ROOT / sample_name
    chunk_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    final_output = (
        sample_dir
        / f"{sample_name}_blastn.tsv"
    )


    # ========================================================
    # 统计read数
    # ========================================================

    total_reads = count_fasta_reads(query)

    total_epochs = math.ceil(
        total_reads / CHUNK_SIZE
    )


    print()
    print("=" * 80)
    print(
        f"Sample "
        f"[{sample_index}/{len(query_files)}]: "
        f"{sample_name}"
    )
    print("=" * 80)

    print(f"FASTA        : {query.name}")
    print(f"Total reads  : {total_reads:,}")
    print(f"Chunk size   : {CHUNK_SIZE:,}")
    print(f"Total epochs : {total_epochs:,}")
    print()


    # ========================================================
    # FASTA逐条读取
    # ========================================================

    reader = fasta_reader(query)

    processed_reads = 0

    completed_epoch_times = []


    for epoch in range(
        1,
        total_epochs + 1
    ):

        epoch_start_read = (
            (epoch - 1) * CHUNK_SIZE + 1
        )

        epoch_end_read = min(
            epoch * CHUNK_SIZE,
            total_reads
        )

        epoch_n_reads = (
            epoch_end_read
            - epoch_start_read
            + 1
        )


        # ----------------------------------------------------
        # Epoch输出TSV
        # ----------------------------------------------------

        epoch_output = (
            epoch_dir
            / (
                f"{sample_name}_"
                f"epoch_{epoch:04d}.tsv"
            )
        )


        print()
        print("-" * 80)

        print(
            f"[Epoch {epoch}/{total_epochs}]"
        )

        print(
            f"Reads: "
            f"{epoch_start_read:,} "
            f"- "
            f"{epoch_end_read:,}"
        )


        # ====================================================
        # 即使epoch已经完成，也需要把reader推进过去
        # ====================================================

        records = []

        for _ in range(epoch_n_reads):

            try:

                record = next(reader)

            except StopIteration:
                break

            records.append(record)


        actual_reads = len(records)

        if actual_reads == 0:
            break


        # ====================================================
        # 如果结果已经存在，跳过BLAST
        # ====================================================

        if (
            epoch_output.exists()
            and epoch_output.stat().st_size > 0
        ):

            processed_reads += actual_reads

            progress = (
                processed_reads
                / total_reads
                * 100
            )

            print(
                f"[SKIP] Epoch result exists."
            )

            print(
                f"Processed: "
                f"{processed_reads:,} / "
                f"{total_reads:,}"
            )

            print(
                f"Progress : "
                f"{progress:.2f}%"
            )

            continue


        # ====================================================
        # 写临时FASTA
        # ====================================================

        chunk_fasta = (
            chunk_dir
            / (
                f"{sample_name}_"
                f"epoch_{epoch:04d}.fasta"
            )
        )

        print(
            f"Writing temporary FASTA "
            f"({actual_reads:,} reads)..."
        )

        write_chunk(
            records,
            chunk_fasta
        )


        # ====================================================
        # 运行BLASTN
        # ====================================================

        print("Running BLASTN...")

        epoch_start_time = time.time()


        # ----------------------------------------------------
        # 使用相对query路径
        # ----------------------------------------------------

        relative_chunk = (
            chunk_fasta.relative_to(
                WORKDIR
            )
        )

        relative_output = (
            epoch_output.relative_to(
                WORKDIR
            )
        )


        cmd = [
            BLASTN,

            "-task",
            "blastn",

            "-query",
            str(relative_chunk),

            "-db",
            str(DB_PREFIX),

            "-out",
            str(relative_output),

            "-outfmt",
            OUTFMT,

            "-evalue",
            EVALUE,

            "-max_target_seqs",
            str(MAX_TARGET_SEQS),

            "-num_threads",
            str(NUM_THREADS),
        ]


        try:

            subprocess.run(
                cmd,
                cwd=str(WORKDIR),
                check=True
            )

        except subprocess.CalledProcessError as e:

            print()
            print("=" * 80)
            print("[ERROR] BLASTN failed")
            print("=" * 80)

            print(f"Sample: {sample_name}")
            print(f"Epoch : {epoch}")
            print(e)

            sys.exit(1)


        epoch_seconds = (
            time.time()
            - epoch_start_time
        )

        completed_epoch_times.append(
            epoch_seconds
        )

        processed_reads += actual_reads


        # ====================================================
        # 删除临时FASTA
        # ====================================================

        try:

            chunk_fasta.unlink()

        except Exception:

            pass


        # ====================================================
        # 计算进度
        # ====================================================

        progress = (
            processed_reads
            / total_reads
            * 100
        )


        # ----------------------------------------------------
        # 当前处理速度
        # ----------------------------------------------------

        reads_per_sec = (
            actual_reads
            / epoch_seconds
            if epoch_seconds > 0
            else 0
        )


        # ----------------------------------------------------
        # 使用所有已完成epoch的平均速度预测ETA
        # ----------------------------------------------------

        total_completed_time = sum(
            completed_epoch_times
        )

        total_completed_reads = (
            len(completed_epoch_times)
            * CHUNK_SIZE
        )

        # 最后一个epoch可能不足100万
        if processed_reads < total_completed_reads:
            total_completed_reads = processed_reads


        if total_completed_time > 0:

            avg_reads_per_sec = (
                total_completed_reads
                / total_completed_time
            )

        else:

            avg_reads_per_sec = 0


        remaining_reads = (
            total_reads
            - processed_reads
        )


        if avg_reads_per_sec > 0:

            eta_seconds = (
                remaining_reads
                / avg_reads_per_sec
            )

        else:

            eta_seconds = 0


        print()
        print(
            f"[Epoch "
            f"{epoch}/{total_epochs} "
            f"FINISHED]"
        )

        print(
            f"Processed : "
            f"{processed_reads:,} / "
            f"{total_reads:,}"
        )

        print(
            f"Progress  : "
            f"{progress:.2f}%"
        )

        print(
            f"Epoch time: "
            f"{format_time(epoch_seconds)}"
        )

        print(
            f"Speed     : "
            f"{reads_per_sec:,.1f} "
            f"reads/sec"
        )

        print(
            f"ETA       : "
            f"{format_time(eta_seconds)}"
        )


        # ----------------------------------------------------
        # epoch结果大小
        # ----------------------------------------------------

        if epoch_output.exists():

            size_mb = (
                epoch_output.stat().st_size
                / 1024
                / 1024
            )

            print(
                f"Output    : "
                f"{size_mb:.2f} MB"
            )


    # ========================================================
    # 16. 合并所有epoch结果
    # ========================================================

    print()
    print("=" * 80)
    print(
        f"Merging epoch results: "
        f"{sample_name}"
    )
    print("=" * 80)


    epoch_files = []

    all_epochs_complete = True


    for epoch in range(
        1,
        total_epochs + 1
    ):

        epoch_file = (
            epoch_dir
            / (
                f"{sample_name}_"
                f"epoch_{epoch:04d}.tsv"
            )
        )

        if not epoch_file.exists():

            print(
                f"[WARNING] Missing epoch: "
                f"{epoch}"
            )

            all_epochs_complete = False
            break

        epoch_files.append(
            epoch_file
        )


    if all_epochs_complete:

        print(
            f"Merging "
            f"{len(epoch_files)} "
            f"epoch files..."
        )

        with open(
            final_output,
            "wb"
        ) as fout:

            for epoch_file in epoch_files:

                with open(
                    epoch_file,
                    "rb"
                ) as fin:

                    shutil.copyfileobj(
                        fin,
                        fout,
                        length=1024 * 1024 * 16
                    )


        final_size_gb = (
            final_output.stat().st_size
            / 1024**3
        )

        sample_seconds = (
            time.time()
            - sample_start_time
        )


        print()
        print(
            f"[SAMPLE FINISHED] "
            f"{sample_name}"
        )

        print(
            f"Total reads : "
            f"{total_reads:,}"
        )

        print(
            f"Total time  : "
            f"{format_time(sample_seconds)}"
        )

        print(
            f"Final file  : "
            f"{final_output}"
        )

        print(
            f"Final size  : "
            f"{final_size_gb:.3f} GB"
        )

    else:

        print()
        print(
            "[WARNING] Not all epochs "
            "were completed."
        )

        print(
            "Final TSV was NOT merged."
        )


# ============================================================
# 17. 全部完成
# ============================================================

global_seconds = (
    time.time()
    - global_start
)

print()
print("=" * 80)
print("ALL BLASTN JOBS FINISHED")
print("=" * 80)

print(
    f"Total time: "
    f"{format_time(global_seconds)}"
)

print()
print("Results:")
print(OUT_DIR)