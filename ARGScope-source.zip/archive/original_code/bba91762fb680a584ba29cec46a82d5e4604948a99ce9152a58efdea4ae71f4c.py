"""Reproduce the three requested BGC panels from verified three-seed results.

No panel letters. SVG text stays editable and all data geometry is vector.
Prediction CSVs, training artifacts, and older figures are read-only inputs.
"""
from pathlib import Path
import csv
import json
import hashlib
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
from matplotlib.text import Text
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, matthews_corrcoef, precision_recall_fscore_support,
)

ROOT = Path(r"E:\1. ARGmodel\BGC数据处理\BGC_standardized_20261006")
OUT = Path(__file__).resolve().parent
SEEDS = (20260915, 20261006, 20261007)
BRANCHES = ("AA", "NT")
TYPES = (
    "Hybrid", "NRPS", "Other", "PKS", "Ribosomal peptide",
    "Saccharide", "Terpene", "nonBGC",
)
BLUE = "#0072B2"
ORANGE = "#E69F00"
INK = "#202020"
GRAY = "#B9C3CC"
GRID = "#E4E9EE"
FONT = 15

plt.rcParams.update({
    "font.family": "Arial", "font.size": FONT,
    "axes.titlesize": 17, "axes.titleweight": "bold",
    "axes.labelsize": FONT, "xtick.labelsize": FONT,
    "ytick.labelsize": FONT, "legend.fontsize": FONT,
    "legend.frameon": False, "axes.linewidth": 0.9,
    "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK,
    "svg.fonttype": "none", "svg.hashsalt": "bgc-normalized-20261006",
    "pdf.fonttype": 42, "figure.facecolor": "white",
    "savefig.facecolor": "white", "hatch.linewidth": 0.45,
    "figure.dpi": 150, "savefig.dpi": 300,
})


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def check_summary(table, branch, task, metric, values):
    record = table[
        (table.method == "ARGScope") & (table.branch == branch)
        & (table.task == task) & (table.metric == metric)
    ]
    assert len(record) == 1, (branch, task, metric)
    record = record.iloc[0]
    assert int(record.seeds_completed) == 3
    np.testing.assert_allclose(np.mean(values), record["mean"], atol=1e-10, rtol=0)
    np.testing.assert_allclose(np.std(values, ddof=1), record.sample_std, atol=1e-10, rtol=0)


def extract_data():
    assert checked_json(ROOT / "Results/finalization_status.json")["complete"]
    assert checked_json(ROOT / "Results/verification_status.json")["all_requested_runs_verified"]
    manifest = checked_json(ROOT / "Dataset/dataset_manifest.json")
    fine_labels = ["nonBGC"] + manifest["fine_classes"]
    reference = pd.read_csv(
        ROOT / "Dataset/normalized_BGC_nonBGC_labels_and_fixed_splits.csv",
        keep_default_na=False,
    )
    reference = reference[reference.model_split == "test"].set_index("id")
    summary = pd.read_csv(ROOT / "Results/mean_std_metrics.csv")
    sources = [ROOT / "Results/mean_std_metrics.csv", ROOT / "Dataset/dataset_manifest.json"]
    all_metrics = []
    class_rows = []
    matrices = []
    for branch in BRANCHES:
        seed_matrices = []
        for seed in SEEDS:
            folder = ROOT / f"seed_{seed}" / branch
            pred_path = folder / "student_test_predictions.csv"
            class_path = folder / "student_type_per_class.csv"
            sources.extend([pred_path, class_path])
            df = pd.read_csv(pred_path, keep_default_na=False)
            assert len(df) == len(reference) == 13026
            assert df.id.is_unique and set(df.id) == set(reference.index)
            assert np.array_equal(df.true_type, reference.loc[df.id, "type"].to_numpy())
            assert np.array_equal(df.fine_evaluable, reference.loc[df.id, "subtype_evaluable"].to_numpy())
            for task in ("binary", "subtype"):
                sub = df if task == "binary" else df[df.fine_evaluable == 1]
                true = sub.true_binary if task == "binary" else sub.true_subtype
                pred = sub.pred_binary if task == "binary" else sub.pred_subtype
                average = "binary" if task == "binary" else "weighted"
                labels = [0, 1] if task == "binary" else fine_labels
                p, r, f, _ = precision_recall_fscore_support(
                    true, pred, labels=labels, average=average, zero_division=0,
                )
                prefix = "positive" if task == "binary" else "weighted"
                assert len(sub) == (13026 if task == "binary" else 10453)
                metrics = {
                    "accuracy": accuracy_score(true, pred),
                    prefix + "_precision": p, prefix + "_recall": r,
                    prefix + "_f1": f, "mcc": matthews_corrcoef(true, pred),
                }
                for metric, value in metrics.items():
                    all_metrics.append(dict(branch=branch, task=task, seed=seed,
                                            metric=metric, value=value, N=len(sub)))
            p, r, f, support = precision_recall_fscore_support(
                df.true_type, df.pred_type, labels=list(TYPES), zero_division=0,
            )
            per_class = pd.read_csv(class_path).set_index("label")
            matrix = np.column_stack((p, r, f))
            np.testing.assert_allclose(
                matrix, per_class.loc[list(TYPES), ["precision", "recall", "f1"]],
                atol=1e-10, rtol=0,
            )
            seed_matrices.append(np.vstack((matrix.mean(axis=0), matrix)))
            for metric_i, metric in enumerate(("precision", "recall", "f1")):
                for row_i, label in enumerate(("Average",) + TYPES):
                    class_rows.append(dict(
                        branch=branch, seed=seed, label=label, metric=metric,
                        value=seed_matrices[-1][row_i, metric_i],
                        support="" if label == "Average" else int(support[row_i - 1]),
                    ))
        seed_matrices = np.asarray(seed_matrices)
        matrices.append({"mean": seed_matrices.mean(axis=0),
                         "std": seed_matrices.std(axis=0, ddof=1)})
        for col, metric in enumerate(("macro_precision", "macro_recall", "macro_f1")):
            check_summary(summary, branch, "type", metric, seed_matrices[:, 0, col])
    all_metrics = pd.DataFrame(all_metrics)
    aggregates = {}
    for branch in BRANCHES:
        for task in ("binary", "subtype"):
            for metric, records in all_metrics[
                (all_metrics.branch == branch) & (all_metrics.task == task)
            ].groupby("metric"):
                values = records.value.to_numpy()
                check_summary(summary, branch, task, metric, values)
                aggregates[(branch, task, metric)] = (float(values.mean()), float(values.std(ddof=1)))
    all_metrics.to_csv(OUT / "binary_subtype_values_by_seed.csv", index=False, encoding="utf-8-sig")
    classes = pd.DataFrame(class_rows)
    classes.to_csv(OUT / "type_values_by_seed.csv", index=False, encoding="utf-8-sig")
    class_summary = classes.groupby(["branch", "label", "metric"], sort=False).value.agg(
        mean="mean", sample_std="std",
    ).reset_index()
    class_summary.to_csv(OUT / "type_heatmap_values.csv", index=False, encoding="utf-8-sig")
    return aggregates, matrices, sources


def text_bounds(fig):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    outside = []
    for obj in fig.findobj(match=Text):
        if not obj.get_visible() or not obj.get_text():
            continue
        bounds = obj.get_window_extent(renderer)
        if bounds.x0 < -1 or bounds.y0 < -1 or bounds.x1 > width + 1 or bounds.y1 > height + 1:
            outside.append(obj.get_text())
    assert not outside, f"Text outside canvas: {outside}"
    return {"canvas_px": [width, height], "all_visible_text_inside_canvas": True}


def save_figure(fig, name, statistics_note):
    bounds = text_bounds(fig)
    metadata = {"Title": name, "Description": statistics_note, "Creator": "ARGScope plotting"}
    fig.savefig(OUT / f"{name}.svg", metadata=metadata)
    fig.savefig(OUT / f"{name}.pdf", metadata={"Title": name, "Subject": statistics_note})
    fig.savefig(OUT / f"{name}.png", dpi=300)
    root = ET.parse(OUT / f"{name}.svg").getroot()
    ns = "{http://www.w3.org/2000/svg}"
    texts = [node.text or "" for node in root.iter(ns + "text")]
    assert len(list(root.iter(ns + "image"))) == 0, "SVG must contain vector data, not a raster heatmap"
    assert texts, "SVG text must remain editable"
    assert not set(texts).intersection({"A", "B", "C", "D", "E", "F", "G"})
    qa = {"file": name + ".svg", "editable_text": True, "raster_images": 0,
          "panel_letters": False, "svg_sha256": sha256(OUT / f"{name}.svg"), **bounds}
    plt.close(fig)
    return qa


def plot_binary(data):
    fig = plt.figure(figsize=(4.6, 4.25))
    fig.text(0.5, 0.97, "BGC/non-BGC classification", ha="center", va="top", weight="bold", size=17)
    ax = fig.add_axes([0.25, 0.15, 0.50, 0.541], projection="polar")
    theta = np.linspace(0, 2 * np.pi, 5, endpoint=False)
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, 1.05)
    ax.set_xticks(theta)
    ax.set_xticklabels(["ACC", "P", "R", "F1", "MCC"], weight="bold", size=FONT)
    ax.tick_params(axis="x", pad=9)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["", "0.5", "", "1.0"], size=FONT - 1)
    ax.set_rlabel_position(12)
    ax.grid(color=GRID, linewidth=0.9)
    ax.spines["polar"].set_edgecolor(GRAY)
    keys = ["accuracy", "positive_precision", "positive_recall", "positive_f1", "mcc"]
    closed = np.r_[theta, theta[0]]
    for branch, color, style, marker in (
        ("AA", BLUE, "-", "o"), ("NT", ORANGE, "--", "s"),
    ):
        values = np.array([data[(branch, "binary", key)][0] for key in keys])
        ax.plot(closed, np.r_[values, values[0]], color=color, linestyle=style,
                marker=marker, markersize=4.5, linewidth=2)
        ax.fill(closed, np.r_[values, values[0]], color=color, alpha=0.065)
    legend_handles = [
        Line2D([], [], color=BLUE, marker="o", lw=2, label="AA (protein)"),
        Line2D([], [], color=ORANGE, marker="s", linestyle="--", lw=2, label="NT (DNA)"),
    ]
    legend = fig.legend(handles=legend_handles, loc="upper center", bbox_to_anchor=(0.5, 0.90),
               ncol=2, columnspacing=1.0, handlelength=1.4, handletextpad=0.45)
    fig.text(0.5, 0.045, "P/R/F1: BGC-positive class", ha="center", size=FONT)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    legend_box = legend.get_window_extent(renderer)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        if label.get_text():
            assert not legend_box.overlaps(label.get_window_extent(renderer)), label.get_text()
    return save_figure(fig, "BGC_binary_radar", "Three-seed means. BGC is positive and non-BGC is negative. No panel letters.")


def plot_subtype(data):
    fig = plt.figure(figsize=(5.65, 4.25))
    fig.text(0.5, 0.97, "BGC subtype annotation", ha="center", va="top", weight="bold", size=17)
    ax = fig.add_axes([0.13, 0.24, 0.83, 0.53])
    keys = ["accuracy", "weighted_precision", "weighted_recall", "weighted_f1", "mcc"]
    x = np.arange(5)
    width = 0.31
    for branch, offset, color, hatch in (
        ("AA", -width / 2, BLUE, ""), ("NT", width / 2, ORANGE, "////"),
    ):
        means, stds = np.array([data[(branch, "subtype", key)] for key in keys]).T
        ax.bar(x + offset, means, width=width * 0.9, yerr=stds,
               color=matplotlib.colors.to_rgba(color, 0.68), edgecolor=color,
               hatch=hatch, linewidth=0.8, capsize=3,
               error_kw={"ecolor": INK, "elinewidth": 1, "capthick": 1}, zorder=3)
    ax.set_xticks(x, ["ACC", "P", "R", "F1", "MCC"], weight="bold")
    ax.set_ylim(0, 1.02)
    ax.set_xlim(-0.6, 4.6)
    ax.set_yticks([0, 0.5, 1.0], ["0.0", "0.5", "1.0"])
    ax.set_ylabel("Score")
    ax.grid(axis="y", color=GRID, lw=0.9, zorder=0)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRAY)
    ax.tick_params(length=0, pad=6)
    handles = [
        Patch(facecolor=matplotlib.colors.to_rgba(BLUE, 0.68), edgecolor=BLUE, label="AA (protein)"),
        Patch(facecolor=matplotlib.colors.to_rgba(ORANGE, 0.68), edgecolor=ORANGE,
              hatch="////", label="NT (DNA)"),
    ]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 0.885),
               ncol=2, columnspacing=1.4, handlelength=1.5)
    fig.text(0.5, 0.105, "P/R/F1: support-weighted", ha="center", size=FONT)
    fig.text(0.5, 0.045, "Mean ± SD across 3 seeds", ha="center", size=FONT)
    return save_figure(fig, "BGC_subtype_bars", "Three-seed means with sample standard deviation. Weighted evaluation on 10453 records: 3960 annotated positives and 6493 negatives.")


def plot_heatmap(matrices):
    fig = plt.figure(figsize=(11.6, 4.75))
    fig.text(0.5, 0.96, "BGC type-level performance", ha="center", va="top", size=17, weight="bold")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    cmap = LinearSegmentedColormap.from_list("BGC_orange", ["#FFF7EE", "#FFD7AF", "#F57C00"])
    norm = Normalize(0, 1)
    group_starts = [0.278, 0.503, 0.728]
    cell_width, cell_height = 0.091, 0.061
    column_gap = 0.004
    ys = [0.744] + [0.641 - i * 0.073 for i in range(8)]
    displayed_labels = ("Average", "Hybrid", "NRPS", "Other", "PKS",
                        "Ribosomal peptide", "Saccharide", "Terpene", "Non-BGC")
    for row, (label, y) in enumerate(zip(displayed_labels, ys)):
        ax.text(0.259, y, label, ha="right", va="center", size=FONT,
                weight="bold" if row == 0 else "normal")
    cell_texts = []
    for metric_i, (heading, start) in enumerate(zip(("Precision", "Recall", "F1"), group_starts)):
        ax.text(start + cell_width + column_gap / 2, 0.855, heading,
                ha="center", va="center", size=FONT, weight="bold")
        for branch_i, branch in enumerate(BRANCHES):
            x = start + branch_i * (cell_width + column_gap)
            ax.text(x + cell_width / 2, 0.808, branch, ha="center", va="center",
                    size=FONT, weight="bold")
            for row, y in enumerate(ys):
                value = matrices[branch_i]["mean"][row, metric_i]
                rect = Rectangle((x, y - cell_height / 2), cell_width, cell_height,
                                 facecolor=cmap(norm(value)), edgecolor="white", linewidth=0.6)
                ax.add_patch(rect)
                text = ax.text(x + cell_width / 2, y, f"{value:.4f}",
                               ha="center", va="center", size=FONT,
                               weight="bold" if row == 0 else "normal")
                cell_texts.append((text, rect))
    cax = fig.add_axes([0.945, ys[-1] - cell_height / 2, 0.012,
                        ys[0] - ys[-1] + cell_height])
    cbar = fig.colorbar(matplotlib.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax)
    cbar.set_ticks([0, 0.25, 0.5, 0.75, 1.0], labels=["0.00", "0.25", "0.50", "0.75", "1.00"])
    cbar.ax.tick_params(length=0, labelsize=FONT - 1, pad=5)
    cbar.outline.set_visible(False)
    cbar.solids.set_rasterized(False)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for text, rect in cell_texts:
        tb, rb = text.get_window_extent(renderer), rect.get_window_extent(renderer)
        assert tb.x0 >= rb.x0 + 2 and tb.x1 <= rb.x1 - 2, text.get_text()
        assert tb.y0 >= rb.y0 + 1 and tb.y1 <= rb.y1 - 1, text.get_text()
    return save_figure(fig, "BGC_type_heatmap", "Mean class-wise precision, recall, and F1 over three seeds. Average is an equally weighted mean of the seven positive types and non-BGC. Fixed scale 0 to 1.")


def main():
    OUT.mkdir(exist_ok=True, parents=True)
    font_path = Path(font_manager.findfont("Arial", fallback_to_default=False))
    data, matrices, sources = extract_data()
    qa = [plot_binary(data), plot_subtype(data), plot_heatmap(matrices)]
    provenance = {
        "seed_policy": "Arithmetic mean across three prespecified seeds, not pooled predictions or best-seed selection.",
        "seeds": list(SEEDS), "font": "Arial", "resolved_font": str(font_path),
        "base_font_points": FONT, "type_label_change": "RiPP -> Ribosomal peptide",
        "source_sha256": {str(path): sha256(path) for path in sources},
        "source_summary_numerical_checks_passed": True,
        "per_class_predictions_match_saved_reports": True,
        "subtype_N": 10453, "binary_and_type_N": 13026,
        "outputs": qa,
    }
    (OUT / "plot_provenance_and_qa.json").write_text(
        json.dumps(provenance, indent=2, ensure_ascii=False), encoding="utf-8",
    )
    print(json.dumps({"complete": True, "svg_files": [q["file"] for q in qa]}, indent=2))


if __name__ == "__main__":
    main()
