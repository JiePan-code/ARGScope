// Inspect actual delivered SVGs, including import-safe canvas and label extents.
const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = path.resolve('outputs/argscope_including_nonARG_20260922');
const qa = path.join(root, 'qa_svg');
fs.mkdirSync(qa, {recursive:true});
(async()=>{
  const reports=[];
  for (const variant of ['', 'editable_text']) {
    for (const folder of ['Figure2_Protein','Figure3_DNA']) {
      const dir=path.join(root,'Figure2_Figure3_SVG',variant,folder);
      const files=fs.readdirSync(dir).filter(n=>n.endsWith('.svg')).sort();
      if(files.length!==7)throw Error('Expected seven subpanels: '+dir);
      for(const file of files){
        const svg=fs.readFileSync(path.join(dir,file));
        const text=svg.toString();
        if (/<image\b/.test(text))throw Error('Rasterized SVG: '+file);
        const viewBox=text.match(/viewBox="([^"]+)"/)[1].split(/\s+/).map(Number);
        if(viewBox[0]!==0||viewBox[1]!==0)throw Error('Nonzero origin: '+file);
        if(!variant&&/<text\b/.test(text))throw Error('Unoutlined type in primary SVG');
        const result=await sharp(svg,{density:160}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
        const {width,height,channels}=result.info;
        let minX=width,minY=height,maxX=-1,maxY=-1,transparent=0;
        for(let y=0;y<height;y++)for(let x=0;x<width;x++){
          const alpha=result.data[(y*width+x)*channels+channels-1];
          if(alpha===0)transparent++;
          if(alpha>4){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
        }
        if(!transparent)throw Error('Opaque SVG '+file);
        const margin=[minX,minY,width-1-maxX,height-1-maxY];
        if(Math.min(...margin)<1)throw Error('Visible mark touches canvas edge: '+variant+' '+file+' '+margin);
        if(!variant){
          await sharp(result.data,{raw:result.info}).flatten({background:'#ffffff'}).resize({width:1900,height:1700,fit:'inside',withoutEnlargement:true}).png().toFile(path.join(qa,file.replace('.svg','.png')));
        }
        reports.push({file,variant:variant||'outlined',width,height,transparent_pixels:transparent,edge_clearance_px:margin,origin_zero:true,pure_vector:true});
      }
    }
  }
  fs.writeFileSync(path.join(qa,'svg_render_verification.json'),JSON.stringify(reports,null,2));
  console.log('PASS: 28 vector SVGs rendered, transparent with all four edges clear.');
})().catch(e=>{console.error(e);process.exit(1)});
