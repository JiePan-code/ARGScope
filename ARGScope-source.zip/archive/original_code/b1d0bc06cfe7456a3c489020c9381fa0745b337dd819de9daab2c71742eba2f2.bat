@echo off
setlocal
chcp 65001 >nul
set "PYTHON_EXE=D:\Anaconda\envs\dnabert2_5060\python.exe"
if not exist "%PYTHON_EXE%" (
  echo Python not found. Edit PYTHON_EXE in this file.
  pause
  exit /b 1
)
"%PYTHON_EXE%" -X utf8 -B -u "%~dp0apply_saved_models.py" %*
set "RUN_EXIT=%ERRORLEVEL%"
pause
exit /b %RUN_EXIT%
