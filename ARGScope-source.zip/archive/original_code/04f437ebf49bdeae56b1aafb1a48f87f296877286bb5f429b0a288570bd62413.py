"""VF/BGC figure: source-backed dataset panels first, unchanged results below, no UMAP."""
from pathlib import Path
import importlib.util
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib import font_manager
from PIL import Image
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/vf_bgc_datasets_first_no_umap_20260925'
spec = importlib.util.spec_from_file_location('vf_bgc_existing', ROOT / 'redraw_vf_bgc_weighted_a4_20260925.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
SPLITS = ['train', 'validation', 'test']
SPLIT_COLORS = {'train': '#718BA8', 'validation': '#B5ADC7', 'test': '#C88196'}
SPLIT_NAMES = {'train': 'Training', 'validation': 'Validation', 'test': 'Test'}
HASHES, AUDIT = {}, {'datasets': [], 'metrics': [], 'figures': []}
INK = '#24353F'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path, **kwargs):
    HASHES[str(path)] = sha(path)
    return pd.read_csv(path, encoding='utf-8-sig', keep_default_na=False, **kwargs)


def axes(fig, x, top, w, h, **kwargs):
    fw, fh = fig.get_size_inches()
    return fig.add_axes([x / fw, 1 - (top + h) / fh, w / fw, h / fh], facecolor='none', **kwargs)


def text(fig, x, top, s, size=10, ha='left', weight='normal', color=INK, **kwargs):
    fw, fh = fig.get_size_inches()
    return fig.text(x / fw, 1 - top / fh, s, fontsize=size, ha=ha, va='top',
                    weight=weight, color=color, **kwargs)


def letter(fig, x, top, label):
    return text(fig, x, top, label, size=14, weight='bold')


def base_canvas(fig):
    old.W, old.H = map(float, fig.get_size_inches())


def load_data():
    metrics = read(ROOT / 'outputs/vf_bgc_binary_positive_20260922/data/all_metrics_binary_positive.csv')
    verify_path = ROOT / 'outputs/vf_bgc_binary_positive_20260922/verification.json'
    HASHES[str(verify_path)] = sha(verify_path)
    records = json.loads(verify_path.read_text(encoding='utf-8'))['models']
    result = {}
    for domain in ['VF', 'BGC']:
        heat = read(ROOT / f'outputs/vf_bgc_including_negative_20260922/data/{domain}_heatmap_values.csv', index_col=0)
        negative = 'non-VF' if domain == 'VF' else 'nonBGC'
        manifests = []
        for mod in ['AA', 'NT']:
            model = f'{domain}Scope-{mod}'
            record = next(r for r in records if r['Model'] == model)
            test_path = Path(record['Source'])
            assert sha(test_path) == record['SHA256']
            directory = test_path.parent
            manifest = read(directory / 'split_manifest.csv')
            assert manifest.id.is_unique and set(manifest.model_split) == set(SPLITS)
            manifests.append(manifest.sort_values('id').reset_index(drop=True))
            for split in SPLITS:
                pred = read(directory / f'{split}_sequence_predictions.csv')
                members = manifest.loc[manifest.model_split.eq(split)]
                assert pred.id.is_unique and set(pred.id) == set(members.id)
                joined = pred.merge(members[['id', 'type', 'subtype']], on='id', validate='one_to_one')
                assert joined.true_type.eq(joined.type).all()
                assert joined.true_subtype.eq(joined.subtype).all()
                if split != 'test':
                    continue
                assert len(pred) == record['N']
                for task, key, averaging in [('Binary', 'binary', 'binary'), ('Subtype', 'subtype', 'weighted')]:
                    truth, estimate = pred[f'true_{key}'], pred[f'predicted_{key}']
                    if task == 'Binary':
                        truth, estimate = truth.ne(negative).astype(int), estimate.ne(negative).astype(int)
                    p, r, f, _ = precision_recall_fscore_support(truth, estimate, average=averaging, zero_division=0)
                    values = [accuracy_score(truth, estimate), p, r, f, matthews_corrcoef(truth, estimate)]
                    stored = metrics.loc[metrics.Model.eq(model) & metrics.Task.eq(task) & metrics.Average.eq(averaging), old.METRICS].iloc[0].to_numpy(float)
                    np.testing.assert_allclose(values, stored, rtol=0, atol=1e-12)
                    AUDIT['metrics'].append({'model': model, 'task': task, 'average': averaging,
                                             'values': dict(zip(old.METRICS, map(float, values)))})
                p, r, f, _ = precision_recall_fscore_support(pred.true_type, pred.predicted_type,
                                                            labels=heat.index.tolist()[1:], average=None, zero_division=0)
                for metric, numbers in [('Precision', p), ('Recall', r), ('F1', f)]:
                    np.testing.assert_allclose(np.r_[numbers.mean(), numbers], heat[f'{metric}_{mod}'], rtol=0, atol=1e-12)
        assert manifests[0].equals(manifests[1]), 'AA and NT split manifests differ'
        manifest = manifests[0]
        positive = manifest.loc[manifest.type.ne(negative)]
        type_order = [c for c in heat.index if c not in ['Average', negative]]
        counts = manifest.groupby(['type', 'model_split']).size().unstack(fill_value=0).reindex(columns=SPLITS)
        split_counts = manifest.model_split.value_counts().reindex(SPLITS)
        positives = manifest.loc[manifest.type.ne(negative)].model_split.value_counts().reindex(SPLITS)
        negatives = manifest.loc[manifest.type.eq(negative)].model_split.value_counts().reindex(SPLITS)
        assert counts.sum().to_dict() == split_counts.to_dict()
        assert (positives + negatives).equals(split_counts)
        domain_data = {'heat': heat, 'metrics': metrics.loc[metrics.Domain.eq(domain)].copy(), 'manifest': manifest,
                       'counts': counts, 'type_order': type_order, 'negative': negative, 'N': len(manifest),
                       'positive_N': len(positive), 'negative_N': int(manifest.type.eq(negative).sum()),
                       'types': int(positive.type.nunique()), 'subtypes': int(positive.subtype.nunique()),
                       'split_counts': split_counts, 'positives': positives, 'negatives': negatives}
        result[domain] = domain_data
        counts.to_csv(OUT / 'data' / f'{domain}_type_counts_by_split.csv')
        pd.DataFrame({'Total': split_counts, domain: positives, f'Non-{domain}': negatives}).to_csv(OUT / 'data' / f'{domain}_split_counts.csv')
        heat.to_csv(OUT / 'data' / f'{domain}_heatmap_values_unchanged.csv')
        domain_data['metrics'].to_csv(OUT / 'data' / f'{domain}_metrics_unchanged.csv', index=False)
        AUDIT['datasets'].append({'domain': domain, 'total_sequences': len(manifest),
                                  'positive_sequences': len(positive), 'negative_sequences': domain_data['negative_N'],
                                  'target_types': domain_data['types'], 'target_subtypes': domain_data['subtypes'],
                                  'split_counts': {k: int(v) for k, v in split_counts.items()},
                                  'same_AA_NT_split': True, 'model_manifest_matches_all_prediction_splits': True,
                                  'counts_are_sequences_not_clusters_or_isolates': True})
    return result


def split_legend(fig, top, size=10):
    fw, fh = fig.get_size_inches()
    handles = [Patch(facecolor=SPLIT_COLORS[s], label=SPLIT_NAMES[s]) for s in SPLITS]
    return fig.legend(handles=handles, ncol=3, frameon=False, fontsize=size, loc='upper center',
                      bbox_to_anchor=(.51, 1 - top / fh), handlelength=1.5, columnspacing=1.6,
                      borderaxespad=0, handletextpad=.5)


def dataset_panel(fig, domain, d, offset, panel_label, standalone=False):
    if standalone:
        title_top, donut_top, donut_size = .18, .83, 1.43
        legend_top = .51
        donut_x, stats_x = .70, 2.65
        counts_top, summary_top, bar_title_top, bar_top, bar_height = .84, 2.38, 2.82, 3.18, 3.78
        bar_x, bar_width = (2.50, 4.18) if domain == 'VF' else (1.65, 5.03)
        label_size, number_size, info_size = 11.1, 10.5, 11.0
        split_legend(fig, legend_top, 11)
        letter(fig, .19, title_top, panel_label)
        text(fig, .53, title_top + .015, f'{domain} dataset', size=14, weight='bold')
    else:
        title_top, donut_top, donut_size = .12, .62, 1.04
        donut_x, stats_x = offset + .15, offset + 1.44
        counts_top, summary_top, bar_title_top, bar_top, bar_height = .60, 1.70, 1.95, 2.21, 2.35
        bar_x, bar_width = (offset + 1.61, 2.32) if domain == 'VF' else (offset + .91, 3.01)
        label_size, number_size, info_size = 9.3, 9.0, 9.4
        letter(fig, offset + .03, title_top, panel_label)
        text(fig, offset + .34, title_top + .018, f'{domain} dataset', size=12, weight='bold')
    ax = axes(fig, donut_x, donut_top, donut_size, donut_size)
    values = d['split_counts'].to_numpy(int)
    wedges, _ = ax.pie(values, colors=[SPLIT_COLORS[s] for s in SPLITS], startangle=90, counterclock=False,
                       wedgeprops={'width': .24, 'edgecolor': 'white', 'linewidth': 1})
    fractions = np.array([w.theta2 - w.theta1 for w in wedges]) / 360
    np.testing.assert_allclose(fractions, values / values.sum(), rtol=0, atol=2e-7)
    ax.text(0, .045, f'{d["N"]:,}', ha='center', va='center', fontsize=13 if standalone else 11,
            weight='bold', color=INK)
    ax.text(0, -.23, 'sequences', ha='center', va='center', fontsize=9.6 if standalone else 8.8, color='#60717A')
    ax.set_aspect('equal')
    for i, split in enumerate(SPLITS):
        y = counts_top + i * (.32 if standalone else .23)
        text(fig, stats_x, y, SPLIT_NAMES[split], size=info_size, color=SPLIT_COLORS[split], weight='bold')
        text(fig, stats_x + (2.38 if standalone else 2.37), y, f'{int(d["split_counts"][split]):,}',
             size=info_size, ha='right', weight='bold')
    text(fig, stats_x, counts_top + (.99 if standalone else .73),
         f'{d["types"]} types · {d["subtypes"]} subtypes', size=info_size, weight='bold')
    center = (fig.get_size_inches()[0] / 2) if standalone else offset + 2.02
    text(fig, center, summary_top,
         f'{d["positive_N"]:,} {domain}  |  {d["negative_N"]:,} non-{domain}', size=info_size, ha='center')
    text(fig, bar_x, bar_title_top, f'{domain} sequences by functional type', size=11 if standalone else 9.8, weight='bold')
    ax = axes(fig, bar_x, bar_top, bar_width, bar_height)
    labels = d['type_order']
    ys, heights, cursor = [], [], -.5
    for value in labels:
        lines = old.wrapped(value).count('\n') + 1
        height = 1.60 if lines > 1 else 1.0
        ys.append(cursor + height / 2)
        heights.append(height)
        cursor += height + .12
    vals = d['counts'].reindex(labels)[SPLITS].to_numpy(int)
    sums = vals.sum(axis=1)
    left = np.zeros(len(labels))
    # Fixed physical thickness keeps the two datasets comparable despite different type counts.
    bar_h = (.115 if standalone else .079) / bar_height * (cursor + .5)
    for j, split in enumerate(SPLITS):
        bars = ax.barh(ys, vals[:, j], left=left, height=bar_h, color=SPLIT_COLORS[split],
                       edgecolor='none', zorder=3)
        assert np.array_equal(np.array([p.get_width() for p in bars]), vals[:, j])
        left += vals[:, j]
    assert int(sums.sum()) == d['positive_N']
    max_count = float(sums.max())
    ax.set_xlim(0, max_count * 1.25)
    ax.set_ylim(cursor, -.65)
    ax.set_yticks(ys, [old.wrapped(l) for l in labels], fontsize=label_size)
    for label in ax.get_yticklabels():
        label.set_linespacing(.98)
    ax.tick_params(axis='y', length=0, pad=6)
    ticks = [0, 4000, 8000]
    ax.set_xticks(ticks, ['0', '4,000', '8,000'], fontsize=10 if standalone else 9.2)
    ax.tick_params(axis='x', length=3, pad=3, width=.6)
    ax.set_xlabel('Number of sequences', fontsize=11 if standalone else 9.5, labelpad=4)
    ax.grid(axis='x', color='#E2E7EA', lw=.6, zorder=0)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#84949F')
    ax.spines['bottom'].set_linewidth(.65)
    for y, total in zip(ys, sums):
        ax.text(total + max_count * .018, y, f'{total:,}', fontsize=number_size, ha='left', va='center')


def adjusted_heatmap(fig, domain, d, box, large=False):
    base_canvas(fig)
    ax = old.heatmap(fig, domain, d, box, small=not large)
    if not large:
        for item in ax.texts:
            item.set_fontsize(9.25 if item.get_gid() else 10.5)
        for label in ax.get_yticklabels():
            label.set_fontsize(9.2)
        for label in ax.get_xticklabels():
            label.set_fontsize(9.7)
        for candidate in fig.axes:
            if candidate is not ax and hasattr(candidate, '_colorbar'):
                candidate.tick_params(labelsize=8.7)
    return ax


def combined(data):
    fig = plt.figure(figsize=(2480 / 300, 3508 / 300), dpi=160, facecolor='none')
    fig.set_label('VF_BGC_datasets_first_no_UMAP_A4_300DPI')
    split_legend(fig, .39, 9.8)
    dataset_panel(fig, 'VF', data['VF'], .04, 'A')
    dataset_panel(fig, 'BGC', data['BGC'], 4.20, 'B')
    base_canvas(fig)
    old.modality_legend(fig, old.W / 2, 4.94, 10.2)
    for domain, lx, rx, bx, a, b in [('VF', .04, .52, 2.24, 'C', 'D'), ('BGC', 4.19, 4.67, 6.39, 'E', 'F')]:
        letter(fig, lx, 5.25, a)
        text(fig, rx + .64, 5.30, f'{domain}/non-{domain}', size=10.5, ha='center')
        ax = old.radar(fig, domain, data[domain], [rx, 5.92, 1.23, 1.23], small=True)
        for tick in ax.get_xticklabels():
            tick.set_fontsize(9.4)
        letter(fig, bx - .14, 5.25, b)
        text(fig, bx + .82, 5.28, f'{domain} · Subtype\n(weighted)', size=10.1, ha='center', linespacing=1.03)
        ax = old.bars(fig, domain, data[domain], [bx + .10, 5.69, 1.61, 1.51], small=True)
        ax.tick_params(axis='both', labelsize=9.2)
    text(fig, old.W / 2, 7.42, 'P = precision; R = recall. Binary: positive class. Subtype: weighted P/R/F1.',
         size=9, ha='center')
    letter(fig, .06, 7.75, 'G')
    letter(fig, 4.46, 7.75, 'H')
    text(fig, 2.80, 7.78, 'VF type-level performance', size=11, weight='bold', ha='center')
    text(fig, 6.60, 7.78, 'BGC type-level performance', size=11, weight='bold', ha='center')
    adjusted_heatmap(fig, 'VF', data['VF'], [1.51, 8.21, 2.62, 3.05])
    adjusted_heatmap(fig, 'BGC', data['BGC'], [5.20, 8.21, 2.63, 2.51])
    text(fig, 6.49, 11.01, 'Average: macro across all types\nand the non-target class',
         size=9.3, ha='center', linespacing=1.28)
    text(fig, old.W / 2, 11.49, 'Dataset counts refer to the sequences used by both AA and NT models.',
         size=9, ha='center')
    return fig


def individual_dataset(domain, data):
    fig = plt.figure(figsize=(7.2, 7.82), dpi=160, facecolor='none')
    fig.set_label(f'{domain}_dataset_composition')
    dataset_panel(fig, domain, data[domain], 0, 'A' if domain == 'VF' else 'B', standalone=True)
    text(fig, 3.6, 7.59, 'Split counts include target and non-target sequences; type bars show target sequences only.',
         size=9.6, ha='center')
    return fig


def individual_result(domain, data, kind, panel):
    if kind == 'binary':
        fig = plt.figure(figsize=(5.0, 4.6), dpi=160, facecolor='none')
        base_canvas(fig)
        letter(fig, .13, .12, panel)
        text(fig, 2.55, .20, f'{domain}/non-{domain} classification', size=13, weight='bold', ha='center')
        old.radar(fig, domain, data[domain], [1.06, 1.15, 2.64, 2.64], small=False)
        old.modality_legend(fig, 2.5, 4.19, 11)
    elif kind == 'subtype':
        fig = plt.figure(figsize=(6.7, 4.3), dpi=160, facecolor='none')
        base_canvas(fig)
        letter(fig, .13, .12, panel)
        text(fig, 3.45, .20, f'{domain} subtype prediction (weighted)', size=13, weight='bold', ha='center')
        old.modality_legend(fig, 3.5, .56, 10.8)
        old.bars(fig, domain, data[domain], [.65, 1.03, 5.78, 2.57], small=False)
    else:
        fig = plt.figure(figsize=(8.0, 5.4 if domain == 'VF' else 4.2), dpi=160, facecolor='none')
        base_canvas(fig)
        letter(fig, .13, .12, panel)
        text(fig, 4.8, .20, f'{domain} type-level performance', size=13, weight='bold', ha='center')
        adjusted_heatmap(fig, domain, data[domain], [2.09 if domain == 'VF' else 1.10, .75,
                                                   5.39 if domain == 'VF' else 6.38,
                                                   3.93 if domain == 'VF' else 2.75], large=True)
        text(fig, 4.5, fig.get_size_inches()[1] - .26,
             'Average: macro across all types and the non-target class', size=10, ha='center')
    fig.set_label(f'{panel}_{domain}_{kind}_unchanged')
    return fig


def export(fig):
    name = fig.get_label()
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    fw, fh = fig.canvas.get_width_height()
    outside = []
    text_artists = []
    for item in fig.findobj(match=Text):
        if not item.get_visible() or not item.get_text().strip():
            continue
        b = item.get_window_extent(renderer)
        if not b.width or not b.height:
            continue
        if b.x0 < -1 or b.y0 < -1 or b.x1 > fw + 1 or b.y1 > fh + 1:
            outside.append(item.get_text())
        text_artists.append((item, b))
    assert not outside, (name, outside)
    for figure_text in fig.texts:
        box = figure_text.get_window_extent(renderer)
        for ax in fig.axes:
            if ax.get_xlabel():
                assert not box.overlaps(ax.xaxis.label.get_window_extent(renderer)), (name, figure_text.get_text(), ax.get_xlabel())
    assert not any(word in ' '.join(t.get_text() for t, _ in text_artists).lower() for word in ['epoch', 'umap'])
    p = OUT / f'{name}_transparent.tif'
    fig.savefig(p, dpi=300, transparent=True, pil_kwargs={'compression': 'tiff_lzw'})
    with Image.open(p) as im:
        assert all(float(x) == 300 for x in im.info['dpi'])
        rgba = im.convert('RGBA')
        assert rgba.getchannel('A').getextrema() == (0, 255)
        pixels = im.size
    if name.startswith('VF_BGC_'):
        assert pixels == (2480, 3508)
    bg = Image.new('RGBA', pixels, 'white')
    bg.alpha_composite(rgba)
    bg.convert('RGB').save(OUT / f'{name}_white.tif', dpi=(300, 300), compression='tiff_lzw')
    preview = bg.convert('RGB')
    preview.thumbnail((1488, 2105), Image.Resampling.LANCZOS)
    preview.save(OUT / 'previews' / f'{name}.png')
    if name.startswith('VF_BGC_'):
        preview.convert('L').save(OUT / 'previews' / 'QA_grayscale.png')
    with plt.rc_context({'svg.fonttype': 'path'}):
        fig.savefig(OUT / 'svg' / f'{name}.svg', transparent=True)
    with plt.rc_context({'svg.fonttype': 'none'}):
        fig.savefig(OUT / 'editable_svg' / f'{name}.svg', transparent=True)
    fig.savefig(OUT / 'pdf' / f'{name}.pdf', transparent=True)
    AUDIT['figures'].append({'name': name, 'tif_pixels': list(pixels), 'dpi': [300, 300],
                             'outside_canvas': outside, 'epoch_UMAP_panels_absent': True})
    plt.close(fig)
    print(json.dumps({'saved': name, 'pixels': pixels}), flush=True)


def main():
    for subdir in ['', 'data', 'previews', 'svg', 'editable_svg', 'pdf', 'code']:
        (OUT / subdir).mkdir(parents=True, exist_ok=True)
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10, 'text.color': INK,
                         'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK,
                         'hatch.linewidth': .4, 'svg.hashsalt': 'vf-bgc-dataset-first-20260925', 'pdf.fonttype': 42})
    data = load_data()
    export(combined(data))
    for domain in ['VF', 'BGC']:
        export(individual_dataset(domain, data))
    for domain, kind, panel in [('VF', 'binary', 'C'), ('VF', 'subtype', 'D'), ('BGC', 'binary', 'E'),
                                 ('BGC', 'subtype', 'F'), ('VF', 'type', 'G'), ('BGC', 'type', 'H')]:
        export(individual_result(domain, data, kind, panel))
    assert all(sha(Path(p)) == digest for p, digest in HASHES.items())
    AUDIT.update({'source_files_unmodified': True, 'source_sha256': HASHES,
                  'binary_average': 'positive class', 'subtype_average': 'weighted', 'type_heatmap_average': 'macro',
                  'all_original_results_preserved': True, 'old_epoch_files_not_deleted': True,
                  'new_layout': 'A-B datasets; C-F binary/subtype results; G-H type heatmaps',
                  'source_numeric_tolerance': 1e-12})
    (OUT / 'verification.json').write_text(json.dumps(AUDIT, indent=2, ensure_ascii=False), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / 'code' / Path(__file__).name)
    shutil.copy2(ROOT / 'redraw_vf_bgc_weighted_a4_20260925.py', OUT / 'code' / 'redraw_vf_bgc_weighted_a4_20260925.py')


if __name__ == '__main__':
    main()
