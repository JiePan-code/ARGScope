import pandas as pd
from pathlib import Path
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


# ==========================================================
# 1. 路径设置
# ==========================================================

BASE_DIR = Path(r"E:\1. ARG模型对比\BGC数据处理")
BGC_DATA_DIR = BASE_DIR / "BGC数据"

AA_FASTA = BGC_DATA_DIR / "mibig_prot_seqs_4.0.fasta"
DNA_FASTA = BGC_DATA_DIR / "mibig_prot_corresponding_dna.fasta"
BGC_LABEL_CSV = BGC_DATA_DIR / "mibig_bgc_id_type_subtype_fixed.csv"

OUT_AA_FASTA = BGC_DATA_DIR / "mibig_prot_seqs_4.0.proteinid_only.matched.fasta"
OUT_DNA_FASTA = BGC_DATA_DIR / "mibig_prot_corresponding_dna.proteinid_only.matched.fasta"
OUT_LABEL_CSV = BGC_DATA_DIR / "mibig_protein_id_type_subtype_matched.csv"

OUT_MISSING_CSV = BGC_DATA_DIR / "mibig_protein_dna_label_missing_records.csv"
OUT_SUMMARY_CSV = BGC_DATA_DIR / "mibig_protein_dna_label_match_summary.csv"


# ==========================================================
# 2. FASTA header 解析
# ==========================================================

def parse_mibig_header(header):
    """
    解析 MIBiG protein / DNA FASTA header。

    原始 AA header 示例:
    BGC0000001.5|c1|1-1083|+|AEK75490.1|protein_methyltransferase|AEK75490.1

    DNA header 之前生成时也是类似格式:
    BGC0000001.5|c1|1-1083|+|AEK75490.1|protein_methyltransferase

    返回:
        bgc_id      = BGC0000001.5
        bgc_base    = BGC0000001
        protein_id  = AEK75490.1
    """

    header = str(header).strip()
    parts = header.split("|")

    if len(parts) >= 5:
        bgc_id = parts[0].strip()
        bgc_base = bgc_id.split(".")[0]
        contig = parts[1].strip()
        coord = parts[2].strip()
        strand = parts[3].strip()
        protein_id = parts[4].strip()
        product = parts[5].strip() if len(parts) > 5 else ""

        if protein_id == "":
            return None

        return {
            "bgc_id": bgc_id,
            "bgc_base": bgc_base,
            "contig": contig,
            "coord": coord,
            "strand": strand,
            "protein_id": protein_id,
            "product": product,
            "header": header,
        }

    # 如果已经是 protein_id-only FASTA，例如 >AEK75490.1
    if "|" not in header and header != "":
        return {
            "bgc_id": "",
            "bgc_base": "",
            "contig": "",
            "coord": "",
            "strand": "",
            "protein_id": header.split()[0].strip(),
            "product": "",
            "header": header,
        }

    return None


# ==========================================================
# 3. 读取 FASTA，按 protein_id 去重
# ==========================================================

def read_fasta_by_protein_id(fasta_file, source_name):
    """
    读取 FASTA，并以 protein_id 为 key。
    如果 protein_id 重复，只保留第一次出现的记录。
    """

    record_dict = {}
    info_dict = {}
    removed_rows = []

    total = 0
    bad_header = 0
    duplicate = 0

    for rec in SeqIO.parse(str(fasta_file), "fasta"):
        total += 1

        info = parse_mibig_header(rec.description)

        if info is None:
            bad_header += 1
            removed_rows.append({
                "source": source_name,
                "protein_id": "",
                "header": rec.description,
                "reason": "bad_header"
            })
            continue

        protein_id = info["protein_id"]

        if protein_id in record_dict:
            duplicate += 1
            removed_rows.append({
                "source": source_name,
                "protein_id": protein_id,
                "header": rec.description,
                "reason": "duplicated_protein_id_removed"
            })
            continue

        record_dict[protein_id] = rec
        info_dict[protein_id] = info

    summary = {
        "source": source_name,
        "total_records": total,
        "unique_protein_ids": len(record_dict),
        "bad_header": bad_header,
        "duplicated_removed": duplicate
    }

    return record_dict, info_dict, pd.DataFrame(removed_rows), summary


# ==========================================================
# 4. 读取 BGC 标签表
# ==========================================================

def read_bgc_label_table(label_csv):
    df = pd.read_csv(label_csv)

    df.columns = [c.strip().lower() for c in df.columns]

    required_cols = {"id", "type", "subtype"}
    missing_cols = required_cols - set(df.columns)

    if missing_cols:
        raise ValueError(f"BGC 标签表缺少列: {missing_cols}")

    df["id"] = df["id"].astype(str).str.strip()
    df["type"] = df["type"].astype(str).str.strip()
    df["subtype"] = df["subtype"].astype(str).str.strip()

    before_n = len(df)

    df = df[
        (df["id"] != "")
        & (df["type"] != "")
        & (df["subtype"] != "")
        & (df["id"].str.lower() != "nan")
        & (df["type"].str.lower() != "nan")
        & (df["subtype"].str.lower() != "nan")
    ].copy()

    bad_n = before_n - len(df)

    dup_n = df["id"].duplicated().sum()

    if dup_n > 0:
        df = df.drop_duplicates(subset=["id"], keep="first").copy()

    label_map = df.set_index("id")[["type", "subtype"]].to_dict("index")

    summary = {
        "source": "bgc_label_csv",
        "total_records": before_n,
        "unique_protein_ids": "",
        "bad_header": bad_n,
        "duplicated_removed": int(dup_n),
        "bgc_label_count": len(label_map)
    }

    return label_map, df, summary


# ==========================================================
# 5. 创建 protein_id-only SeqRecord
# ==========================================================

def make_proteinid_only_record(original_record, protein_id):
    return SeqRecord(
        original_record.seq,
        id=protein_id,
        description=""
    )


# ==========================================================
# 6. 主程序
# ==========================================================

def main():
    print("Checking input files...")

    for fp in [AA_FASTA, DNA_FASTA, BGC_LABEL_CSV]:
        print(fp, "exists:", fp.exists())
        if not fp.exists():
            raise FileNotFoundError(f"找不到文件: {fp}")

    print("\nReading BGC label table...")
    bgc_label_map, bgc_label_df, label_summary = read_bgc_label_table(BGC_LABEL_CSV)

    print("BGC label count:", len(bgc_label_map))

    print("\nReading AA FASTA...")
    aa_records, aa_infos, aa_removed_df, aa_summary = read_fasta_by_protein_id(
        AA_FASTA,
        "aa_fasta"
    )

    print("AA unique protein IDs:", len(aa_records))

    print("\nReading DNA FASTA...")
    dna_records, dna_infos, dna_removed_df, dna_summary = read_fasta_by_protein_id(
        DNA_FASTA,
        "dna_fasta"
    )

    print("DNA unique protein IDs:", len(dna_records))

    # ======================================================
    # 根据 AA FASTA 的 bgc_base 匹配 BGC type/subtype
    # ======================================================

    label_rows = []
    missing_rows = []

    aa_with_bgc_label_ids = set()

    for protein_id, info in aa_infos.items():
        bgc_base = info["bgc_base"]

        if bgc_base in bgc_label_map:
            bgc_type = bgc_label_map[bgc_base]["type"]
            bgc_subtype = bgc_label_map[bgc_base]["subtype"]

            label_rows.append({
                "protein_id": protein_id,
                "bgc_id": info["bgc_id"],
                "bgc_base": bgc_base,
                "contig": info["contig"],
                "coord": info["coord"],
                "strand": info["strand"],
                "product": info["product"],
                "type": bgc_type,
                "subtype": bgc_subtype,
                "aa_header": info["header"],
            })

            aa_with_bgc_label_ids.add(protein_id)

        else:
            missing_rows.append({
                "source": "aa_to_bgc_label",
                "protein_id": protein_id,
                "bgc_id": info["bgc_id"],
                "bgc_base": bgc_base,
                "header": info["header"],
                "reason": "bgc_id_not_found_in_bgc_label_csv"
            })

    label_df = pd.DataFrame(label_rows)

    print("\nProtein IDs with BGC labels:", len(aa_with_bgc_label_ids))

    # ======================================================
    # 三者求交集：AA FASTA、DNA FASTA、protein label table
    # ======================================================

    aa_ids = set(aa_records.keys())
    dna_ids = set(dna_records.keys())
    label_ids = set(label_df["protein_id"]) if len(label_df) > 0 else set()

    common_ids = aa_ids & dna_ids & label_ids

    print("\nMatch statistics:")
    print("AA unique IDs:", len(aa_ids))
    print("DNA unique IDs:", len(dna_ids))
    print("Label protein IDs:", len(label_ids))
    print("Common IDs in AA + DNA + Label:", len(common_ids))

    aa_only = aa_ids - common_ids
    dna_only = dna_ids - common_ids
    label_only = label_ids - common_ids

    print("AA removed:", len(aa_only))
    print("DNA removed:", len(dna_only))
    print("Label removed:", len(label_only))

    for pid in sorted(aa_only):
        missing_rows.append({
            "source": "aa_fasta",
            "protein_id": pid,
            "bgc_id": aa_infos.get(pid, {}).get("bgc_id", ""),
            "bgc_base": aa_infos.get(pid, {}).get("bgc_base", ""),
            "header": aa_infos.get(pid, {}).get("header", ""),
            "reason": "not_in_dna_or_label"
        })

    for pid in sorted(dna_only):
        missing_rows.append({
            "source": "dna_fasta",
            "protein_id": pid,
            "bgc_id": dna_infos.get(pid, {}).get("bgc_id", ""),
            "bgc_base": dna_infos.get(pid, {}).get("bgc_base", ""),
            "header": dna_infos.get(pid, {}).get("header", ""),
            "reason": "not_in_aa_or_label"
        })

    for pid in sorted(label_only):
        row = label_df[label_df["protein_id"] == pid].iloc[0].to_dict()
        missing_rows.append({
            "source": "protein_label_table",
            "protein_id": pid,
            "bgc_id": row.get("bgc_id", ""),
            "bgc_base": row.get("bgc_base", ""),
            "header": row.get("aa_header", ""),
            "reason": "not_in_aa_or_dna"
        })

    # ======================================================
    # 按 AA FASTA 原始顺序生成最终 AA / DNA / label
    # ======================================================

    final_ids = []

    for protein_id in aa_records.keys():
        if protein_id in common_ids:
            final_ids.append(protein_id)

    final_aa_records = []
    final_dna_records = []

    for protein_id in final_ids:
        final_aa_records.append(
            make_proteinid_only_record(
                aa_records[protein_id],
                protein_id
            )
        )

        final_dna_records.append(
            make_proteinid_only_record(
                dna_records[protein_id],
                protein_id
            )
        )

    label_order_df = pd.DataFrame({
        "protein_id": final_ids,
        "_order": range(len(final_ids))
    })

    final_label_df = label_df[label_df["protein_id"].isin(common_ids)].copy()
    final_label_df = final_label_df.merge(label_order_df, on="protein_id", how="inner")
    final_label_df = final_label_df.sort_values("_order").drop(columns=["_order"])

    final_label_df = final_label_df[
        [
            "protein_id",
            "bgc_id",
            "bgc_base",
            "type",
            "subtype",
            "contig",
            "coord",
            "strand",
            "product",
        ]
    ].copy()

    # ======================================================
    # 最终一一对应检查
    # ======================================================

    aa_final_ids = [rec.id for rec in final_aa_records]
    dna_final_ids = [rec.id for rec in final_dna_records]
    label_final_ids = final_label_df["protein_id"].tolist()

    check_aa_dna = aa_final_ids == dna_final_ids
    check_aa_label = aa_final_ids == label_final_ids
    check_dna_label = dna_final_ids == label_final_ids

    print("\nFinal one-to-one check:")
    print("AA == DNA:", check_aa_dna)
    print("AA == Label:", check_aa_label)
    print("DNA == Label:", check_dna_label)

    if not (check_aa_dna and check_aa_label and check_dna_label):
        raise ValueError("最终 AA / DNA / Label 仍未一一对应，停止保存。")

    # ======================================================
    # 保存结果
    # ======================================================

    SeqIO.write(final_aa_records, str(OUT_AA_FASTA), "fasta")
    SeqIO.write(final_dna_records, str(OUT_DNA_FASTA), "fasta")
    final_label_df.to_csv(OUT_LABEL_CSV, index=False, encoding="utf-8-sig")

    removed_parts = []

    if len(aa_removed_df) > 0:
        removed_parts.append(aa_removed_df)

    if len(dna_removed_df) > 0:
        removed_parts.append(dna_removed_df)

    if len(missing_rows) > 0:
        removed_parts.append(pd.DataFrame(missing_rows))

    if len(removed_parts) > 0:
        removed_df = pd.concat(removed_parts, axis=0, ignore_index=True)
    else:
        removed_df = pd.DataFrame(columns=["source", "protein_id", "header", "reason"])

    removed_df.to_csv(OUT_MISSING_CSV, index=False, encoding="utf-8-sig")

    summary_df = pd.DataFrame([
        aa_summary,
        dna_summary,
        label_summary,
        {
            "source": "final_matched",
            "total_records": len(final_ids),
            "unique_protein_ids": len(final_ids),
            "bad_header": "",
            "duplicated_removed": "",
            "bgc_label_count": "",
            "aa_equals_dna": check_aa_dna,
            "aa_equals_label": check_aa_label,
            "dna_equals_label": check_dna_label,
        }
    ])

    summary_df.to_csv(OUT_SUMMARY_CSV, index=False, encoding="utf-8-sig")

    print("\nSaved files:")
    print("AA FASTA protein_id only:", OUT_AA_FASTA)
    print("DNA FASTA protein_id only:", OUT_DNA_FASTA)
    print("Matched label CSV:", OUT_LABEL_CSV)
    print("Missing/removed records:", OUT_MISSING_CSV)
    print("Summary:", OUT_SUMMARY_CSV)

    print("\nFinal records:", len(final_ids))
    print("Unique type:", final_label_df["type"].nunique())
    print("Unique subtype:", final_label_df["subtype"].nunique())

    subtype_check = (
        final_label_df.groupby("subtype")["type"]
        .nunique()
        .reset_index(name="type_count")
    )

    conflict = subtype_check[subtype_check["type_count"] > 1]

    if len(conflict) == 0:
        print("Subtype check passed: each subtype corresponds to only one type.")
    else:
        print("Warning: subtype maps to multiple types:")
        print(conflict)


if __name__ == "__main__":
    main()