#!/usr/bin/env python3
"""Type-by-Type descriptive profile correlations + model-to-Type precision arcs.

Correlation is between reported performance profiles, not biological Type
relationships or gene co-occurrence. Arcs encode mean precision, not correlation.
No P values, Mantel tests, matched-cohort claims or zero imputation are used.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import zipfile
import warnings
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, PathPatch, Patch
from matplotlib.path import Path as MPath
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
DATA=ROOT/'data'
FIGURES=ROOT/'figures'
DATA.mkdir(parents=True,exist_ok=True)
FIGURES.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('original_fragment_plots',SOURCE/'plot_fragment_figure.py')
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.FIG=FIGURES
base.exports.clear()
base.LAYOUT_QA.clear()
ORDER=base.ORDER
DISPLAY=base.DISPLAY
MODELS=base.MODELS
PCTS=[60,70,80,90]
RAW=pd.read_csv(SOURCE/'data/reported_per_type_NOT_matched.csv')
PRECISION=RAW[RAW.Metric.eq('Precision')].copy()
SOURCE_FILES=[SOURCE/'plot_fragment_figure.py']+list((SOURCE/'data').glob('*.csv'))
HASHES={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE_FILES}
INPUT_GRANULARITY='one model/modality/completeness/Type reported precision'


def write(df,name,index=False):
    df.to_csv(DATA/name,index=index,encoding='utf-8-sig',float_format='%.12g')


def prepare(modality=None):
    part=PRECISION if modality is None else PRECISION[PRECISION.Modality.eq(modality)]
    assert not part.duplicated(['Modality','Model','Completeness','Type']).any()
    assert part.Value.dropna().between(0,1).all()
    modalities=['protein','dna'] if modality is None else [modality]
    configurations=[(mod,m,pct) for mod in modalities for m in MODELS[mod] for pct in PCTS]
    table=part.pivot(index='Type',columns=['Modality','Model','Completeness'],values='Value')
    table=table.reindex(index=ORDER,columns=pd.MultiIndex.from_tuples(configurations))
    flat=table.copy()
    flat.columns=['|'.join(map(str,c)) for c in configurations]
    n=len(ORDER)
    corr=np.full((n,n),np.nan)
    pair_n=np.zeros((n,n),int)
    statuses=[]
    for i in range(n):
        for j in range(i,n):
            a,b=table.iloc[i].to_numpy(float),table.iloc[j].to_numpy(float)
            ok=np.isfinite(a)&np.isfinite(b)
            count=int(ok.sum())
            pair_n[i,j]=pair_n[j,i]=count
            reason='available'
            if count<8:
                reason='fewer_than_8_paired_reported_configurations'
            elif np.ptp(a[ok])==0 or np.ptp(b[ok])==0:
                reason='constant_performance_profile'
            else:
                rho=float(spearmanr(a[ok],b[ok]).statistic)
                corr[i,j]=corr[j,i]=rho
            statuses.append(dict(Type_1=ORDER[i],Type_2=ORDER[j],N_configurations=count,
                                 Spearman_rho=corr[i,j],Status=reason))
    # A mean is reported only when ALL FOUR completeness conditions are present.
    arcs=[]
    for mod in modalities:
        for model in MODELS[mod]:
            for typ in ORDER:
                vec=part[(part.Modality==mod)&(part.Model==model)&(part.Type==typ)].set_index('Completeness').reindex(PCTS).Value
                num=int(vec.notna().sum())
                arcs.append(dict(Modality=mod,Model=model,Type=typ,N_conditions=num,
                                 Mean_precision=float(vec.mean()) if num==4 else np.nan,
                                 Minimum_precision=float(vec.min()) if num==4 else np.nan,
                                 Maximum_precision=float(vec.max()) if num==4 else np.nan,
                                 Definition='arithmetic_mean_of_4_completeness_precisions_NOT_pooled_precision',
                                 Comparability='previously_reported_unmatched_cohorts'))
    name='combined' if modality is None else modality
    write(flat.reset_index(),f'{name}_Type_precision_profiles.csv')
    write(pd.DataFrame(corr,index=ORDER,columns=ORDER),f'{name}_Type_profile_spearman.csv',True)
    write(pd.DataFrame(pair_n,index=ORDER,columns=ORDER),f'{name}_pairwise_configuration_counts.csv',True)
    write(pd.DataFrame(statuses),f'{name}_pair_status.csv')
    arc_df=pd.DataFrame(arcs)
    write(arc_df,f'{name}_model_Type_arcs.csv')
    return corr,arc_df,configurations


def network(ax,corr,arcs,modality=None,fontsize=6.4):
    n=len(ORDER)
    cmap=plt.get_cmap('PRGn')
    norm=Normalize(-1,1)
    for i in range(n):
        for j in range(i,n):
            rho=corr[i,j]
            ax.add_patch(Rectangle((j-.47,i-.47),.94,.94,facecolor='#EDEEEF' if np.isnan(rho) else 'white',edgecolor='#C2C8CD',lw=.3))
            if np.isfinite(rho):
                size=.84*np.sqrt(abs(rho))
                ax.add_patch(Rectangle((j-size/2,i-size/2),size,size,facecolor=cmap(norm(rho)),edgecolor='none'))
            else:
                ax.text(j,i,'×',ha='center',va='center',fontsize=fontsize-1,color='#9A9FA3')
    for j,typ in enumerate(ORDER):
        ax.text(j,-.77,DISPLAY[typ],ha='left',va='bottom',rotation=57,rotation_mode='anchor',fontsize=fontsize)
        ax.text(n-.10,j,DISPLAY[typ],ha='left',va='center',fontsize=fontsize)
    mods=['protein','dna'] if modality is None else [modality]
    nodes=[(mod,m) for mod in mods for m in MODELS[mod]]
    ys=np.linspace(3,20.8,len(nodes))
    zero_edges=0
    positive_edges=0
    missing_edges=0
    for (mod,model),sy in zip(nodes,ys):
        sx=-9.6
        color=base.COLORS[model]
        for j,typ in enumerate(ORDER):
            row=arcs[(arcs.Modality==mod)&(arcs.Model==model)&(arcs.Type==typ)].iloc[0]
            value=row.Mean_precision
            if not np.isfinite(value):
                missing_edges+=1
                continue
            zero=bool(value==0)
            zero_edges+=zero
            positive_edges+=not zero
            verts=[(sx,sy),(sx+2.5,sy+3.0),(j-3.0,j+3.0),(j-.10,j+.12)]
            ax.add_patch(PathPatch(MPath(verts,[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4]),
                                   facecolor='none',edgecolor='#A7ACB1' if zero else color,
                                   lw=.20+1.35*value,ls=':' if zero else '-',alpha=.33 if not zero else .25,
                                   zorder=2))
        ax.scatter(sx,sy,s=42,marker='o' if mod=='protein' else 'D',color=color,edgecolor='white',lw=.6,zorder=8)
        prefix='Protein' if mod=='protein' else 'DNA'
        ax.text(sx-.65,sy,f'{prefix} · {model}',ha='right',va='center',fontsize=fontsize+1,
                color=color,fontweight='bold' if model=='ARGScope' else 'normal')
    for j in range(n):
        ax.scatter(j,j,s=4.5,facecolor='white',edgecolor='#61696E',lw=.35,zorder=8)
    # Matrix correlation and arc precision have separate, explicit legends.
    for k,p in enumerate([.25,.50,1.00]):
        y=25+k*.80
        ax.plot([-16,-13.5],[y,y],lw=.20+1.35*p,color='#4C5359')
        ax.text(-12.8,y,f'Mean precision {p:.2f}',ha='left',va='center',fontsize=fontsize)
    ax.plot([-16,-13.5],[27.4,27.4],color='#929AA1',lw=.3,ls=':')
    ax.text(-12.8,27.4,'0: dotted line; missing: no line',va='center',fontsize=fontsize)
    ax.text(.1,25.1,'Matrix: Type performance-profile Spearman ρ',fontsize=fontsize)
    ax.text(.1,26.0,'Arcs: mean Type precision across 60–90%',fontsize=fontsize)
    ax.text(.1,26.9,'Grey ×: constant or insufficient profile',fontsize=fontsize)
    ax.text(.1,27.8,'Descriptive only · no significance / biological association',fontsize=fontsize,color='#60676C')
    ax.set(xlim=(-22,32.5),ylim=(29.0,-8.0))
    ax.set_aspect('equal');ax.axis('off')
    return ScalarMappable(norm=norm,cmap=cmap),dict(positive_arcs=positive_edges,zero_arcs=zero_edges,missing_arcs=missing_edges)


def standalone(corr,arcs,modality=None):
    name='combined' if modality is None else modality
    fig=base.canvas(300,213)
    ax=base.ax_mm(fig,2,2,283,199)
    sm,counts=network(ax,corr,arcs,modality,fontsize=7)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,285,58,2.4,81))
    cb.set_ticks([-1,-.5,0,.5,1]);cb.ax.tick_params(labelsize=7,length=2)
    cb.set_label('Profile correlation (ρ)',fontsize=7)
    base.save(fig,f'Type_network_{name}')
    return counts


def combined_main(corr,arcs):
    fig=base.canvas(280,342)
    handles=[Line2D([0],[0],color=base.COLORS[m],lw=1.6 if m=='ARGScope' else 1,
                    ls='-' if m=='ARGScope' else '--',marker='o',ms=3,label=m) for m in MODELS['protein']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.55,.997),ncol=5,frameon=False,fontsize=8,columnspacing=2.5)
    for mod,top in [('protein',20),('dna',60)]:
        for j,metric in enumerate(base.METRICS):base.performance(base.ax_mm(fig,18+j*52,top,44,27),mod,metric,j==0)
        base.text_mm(fig,4,top+13,'Protein' if mod=='protein' else 'DNA',rotation=90,ha='center',va='center',fontsize=10,fontweight='bold')
    base.text_mm(fig,144,96,'Reported Type-level summaries · test cohorts / aggregation not harmonized',ha='center',fontsize=7,color='#5C6168')
    # The former Type heatmaps are replaced by this full-width Type network.
    sm,_=network(base.ax_mm(fig,1,104,269,174),corr,arcs,fontsize=6.2)
    cb=fig.colorbar(sm,cax=base.ax_mm(fig,267,152,2.2,66));cb.set_ticks([-1,-.5,0,.5,1])
    cb.ax.tick_params(labelsize=6,length=2);cb.set_label('Profile correlation (ρ)',fontsize=6.8)
    base.boxes(base.ax_mm(fig,20,290,104,39))
    base.stable(base.ax_mm(fig,166,290,101,39))
    fig.legend(handles=[Patch(facecolor=base.MODCOL[m],label='Protein' if m=='protein' else 'DNA',alpha=.6) for m in ['protein','dna']],
               loc='center',bbox_to_anchor=(.50,.182),ncol=2,frameon=False,fontsize=7)
    base.save(fig,'fragment_robustness_main_Type_network')


def main():
    summary={}
    for mod in [None,'protein','dna']:
        corr,arcs,config=prepare(mod)
        name='combined' if mod is None else mod
        summary[name]=standalone(corr,arcs,mod)
        summary[name].update(N_types=len(ORDER),N_configurations=len(config),
                             undefined_upper_triangle=int(np.isnan(corr[np.triu_indices(len(ORDER))]).sum()))
        if mod is None:combined_main(corr,arcs)
    write(PRECISION,'source_Type_precision_long.csv')
    (DATA/'source_hashes.json').write_text(json.dumps(HASHES,indent=2),encoding='utf-8')
    (ROOT/'figure_manifest.json').write_text(json.dumps(base.exports,indent=2),encoding='utf-8')
    (ROOT/'layout_validation.json').write_text(json.dumps(base.LAYOUT_QA,indent=2),encoding='utf-8')
    for p,h in HASHES.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
    (ROOT/'validation.json').write_text(json.dumps(dict(status='PASS',summaries=summary,
        preserved_inputs=len(HASHES),arcs='mean_precision_not_correlation',matrix='descriptive_profile_correlation',
        P_values='not_computed',matched_baseline_cohort=False),indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print(FIGURES)


if __name__=='__main__':
    main()
