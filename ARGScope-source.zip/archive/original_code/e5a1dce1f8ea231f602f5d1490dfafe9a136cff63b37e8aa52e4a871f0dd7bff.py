import pandas as pd
from pathlib import Path


# ==========================================================
# 1. 输入输出文件
# ==========================================================

# 你生成的 BGC protein_id 列表
ID_FILE = "protein_ID_列表.csv"

# 原始 protein FASTA
PROTEIN_FASTA = "merged_protein.fasta"

# 原始 DNA FASTA
DNA_FASTA = "merged_dna.fasta"

# 输出筛选后的 FASTA
OUTPUT_PROTEIN_FASTA = "BGC_protein.fasta"
OUTPUT_DNA_FASTA = "BGC_dna.fasta"

# 未匹配 ID 输出
OUTPUT_UNMATCHED_PROTEIN = "unmatched_protein_ids.csv"
OUTPUT_UNMATCHED_DNA = "unmatched_dna_ids.csv"


# ==========================================================
# 2. ID 列名
# ==========================================================

ID_COL = "id"


# ==========================================================
# 3. 工具函数
# ==========================================================

def clean_id(x):
    """
    清理 FASTA header 或表格中的 ID。
    >AEK75490.1 description -> AEK75490.1
    """
    if x is None:
        return ""

    x = str(x).strip()

    if x == "" or x.lower() in ["nan", "none", "null"]:
        return ""

    x = x.lstrip(">")
    parts = x.split()

    if len(parts) == 0:
        return ""

    return parts[0]


def remove_version(x):
    """
    AEK75490.1 -> AEK75490
    """
    x = clean_id(x)

    if "." in x:
        return x.rsplit(".", 1)[0]

    return x


def read_id_list(id_file, id_col="id"):
    """
    从 CSV 中读取目标 protein_id 列表。
    """
    df = pd.read_csv(id_file)

    if id_col not in df.columns:
        raise ValueError("ID 文件缺少列: {}".format(id_col))

    ids = df[id_col].apply(clean_id).tolist()
    ids = [x for x in ids if x != ""]

    # 去重，保持原顺序
    ids = list(dict.fromkeys(ids))

    print("目标 ID 数:", len(ids))
    print("前 10 个 ID:", ids[:10])

    return ids


def parse_fasta(fasta_file):
    """
    读取 FASTA，返回:
        records: list of (header, sequence)
    """
    fasta_file = Path(fasta_file)

    if not fasta_file.exists():
        raise FileNotFoundError("找不到 FASTA 文件: {}".format(fasta_file))

    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n").rstrip("\r")

            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))

                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line.strip())

        if header is not None:
            records.append((header, "".join(seq_lines)))

    print("读取 FASTA:", fasta_file)
    print("序列数:", len(records))

    return records


def build_fasta_index(records):
    """
    构建 ID -> FASTA record 映射。
    同时支持完整 ID 和去版本号 ID。
    """
    index = {}

    for header, seq in records:
        rid = clean_id(header)
        rid_nover = remove_version(rid)

        if rid and rid not in index:
            index[rid] = (header, seq)

        if rid_nover and rid_nover not in index:
            index[rid_nover] = (header, seq)

    return index


def write_fasta(records, output_file, line_width=80):
    """
    写出 FASTA。
    """
    with open(output_file, "w", encoding="utf-8") as f:
        for header, seq in records:
            f.write(">{}\n".format(header))

            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")

    print("Saved:", output_file)
    print("输出序列数:", len(records))


def filter_fasta_by_ids(target_ids, fasta_file, output_fasta, unmatched_file):
    """
    根据目标 ID 筛选 FASTA。
    """
    records = parse_fasta(fasta_file)
    index = build_fasta_index(records)

    selected_records = []
    unmatched = []

    seen = set()

    for tid in target_ids:
        tid_clean = clean_id(tid)
        tid_nover = remove_version(tid_clean)

        record = None

        if tid_clean in index:
            record = index[tid_clean]
        elif tid_nover in index:
            record = index[tid_nover]

        if record is None:
            unmatched.append(tid_clean)
            continue

        header, seq = record
        real_id = clean_id(header)

        if real_id in seen:
            continue

        seen.add(real_id)
        selected_records.append((header, seq))

    write_fasta(selected_records, output_fasta)

    unmatched_df = pd.DataFrame({"id": unmatched})
    unmatched_df.to_csv(unmatched_file, index=False, encoding="utf-8-sig")

    print("未匹配 ID 数:", len(unmatched))
    print("未匹配文件:", unmatched_file)
    print("-" * 60)

    return selected_records, unmatched


# ==========================================================
# 4. 主函数
# ==========================================================

def main():
    target_ids = read_id_list(ID_FILE, ID_COL)

    print("=" * 60)
    print("筛选 protein FASTA")
    print("=" * 60)

    filter_fasta_by_ids(
        target_ids=target_ids,
        fasta_file=PROTEIN_FASTA,
        output_fasta=OUTPUT_PROTEIN_FASTA,
        unmatched_file=OUTPUT_UNMATCHED_PROTEIN
    )

    print("=" * 60)
    print("筛选 DNA FASTA")
    print("=" * 60)

    filter_fasta_by_ids(
        target_ids=target_ids,
        fasta_file=DNA_FASTA,
        output_fasta=OUTPUT_DNA_FASTA,
        unmatched_file=OUTPUT_UNMATCHED_DNA
    )

    print("Done.")


if __name__ == "__main__":
    main()