from pathlib import Path
import hashlib
import json
import zipfile
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from PIL import Image
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
SOURCE=ROOT.parent


def main():
    hashes=json.loads((DATA/'source_hashes.json').read_text(encoding='utf-8'))
    for file,expected in hashes.items():
        assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==expected
    source=pd.read_csv(DATA/'source_Type_precision_long.csv')
    tested=0
    for name in ['combined','protein','dna']:
        profiles=pd.read_csv(DATA/f'{name}_Type_precision_profiles.csv').set_index('Type')
        matrix=pd.read_csv(DATA/f'{name}_Type_profile_spearman.csv',index_col=0)
        pair_n=pd.read_csv(DATA/f'{name}_pairwise_configuration_counts.csv',index_col=0)
        assert matrix.shape==(23,23)
        assert np.allclose(matrix,matrix.T,equal_nan=True)
        for i in range(23):
            for j in range(i,23):
                x,y=profiles.iloc[i].to_numpy(float),profiles.iloc[j].to_numpy(float)
                ok=np.isfinite(x)&np.isfinite(y)
                assert ok.sum()==pair_n.iloc[i,j]
                valid=ok.sum()>=8 and np.ptp(x[ok])>0 and np.ptp(y[ok])>0
                if valid:
                    # Independent arithmetic: Pearson correlation of average ranks.
                    expected=np.corrcoef(rankdata(x[ok]),rankdata(y[ok]))[0,1]
                    assert np.isclose(expected,matrix.iloc[i,j],atol=1e-10)
                else:
                    assert np.isnan(matrix.iloc[i,j])
                tested+=1
        arcs=pd.read_csv(DATA/f'{name}_model_Type_arcs.csv')
        for row in arcs.itertuples():
            vals=source[(source.Modality==row.Modality)&(source.Model==row.Model)&(source.Type==row.Type)].Value
            assert vals.notna().sum()==row.N_conditions
            if row.N_conditions==4:
                assert np.isclose(vals.sum()/4,row.Mean_precision,atol=1e-10)
            else:
                assert np.isnan(row.Mean_precision)
    layout=json.loads((ROOT/'layout_validation.json').read_text(encoding='utf-8'))
    assert len(layout)==4 and all(not x['visible_text_outside_canvas'] for x in layout)
    manifest=json.loads((ROOT/'figure_manifest.json').read_text(encoding='utf-8'))
    assert len(manifest)==12
    for item in manifest:
        p=ROOT/'figures'/item['file']
        assert p.stat().st_size>1000
        if p.suffix=='.png':
            with Image.open(p) as im:im.verify()
        elif p.suffix=='.svg':ET.parse(p)
        else:assert p.read_bytes().startswith(b'%PDF')
    report=dict(status='PASS',independent_pairwise_checks=tested,figure_formats=12,
                source_files_preserved=len(hashes),matrix_statistic='Spearman profile correlation',
                arc_statistic='arithmetic mean precision across 4 completeness conditions',
                no_significance_tests=True,matched_cohort_claim=False)
    filtered_manifest=ROOT/'filtered_heatmap_manifest.json'
    if filtered_manifest.exists():
        fm=json.loads(filtered_manifest.read_text(encoding='utf-8'))
        assert len(fm)==18
        for item in fm:
            p=ROOT/'filtered_heatmaps'/item['file']
            assert p.stat().st_size>1000
            if p.suffix=='.png':
                with Image.open(p) as im:im.verify()
            elif p.suffix=='.svg':ET.parse(p)
            else:assert p.read_bytes().startswith(b'%PDF')
        fl=json.loads((ROOT/'filtered_heatmap_layout.json').read_text(encoding='utf-8'))
        assert len(fl)==6 and all(not x['visible_text_outside_canvas'] for x in fl)
        fa=pd.read_csv(ROOT/'filtered_heatmap_data/display_filter_audit.csv')
        assert fa.loc[fa.Shown,'ARGScope_value'].gt(0).all()
        assert fa.loc[~fa.Shown,'ARGScope_value'].eq(0).all()
        assert len(fa)==2*4*3*23
        report['filtered_heatmap_formats']=18
        report['filter']='ARGScope > 0 per modality, completeness and metric; display only'
    (ROOT/'independent_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    target=SOURCE.parent/'ARGScope_Type_network_revision.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        # Keep the original helper and required CSVs, so the revision reruns after extraction.
        z.write(SOURCE/'plot_fragment_figure.py',f'{SOURCE.name}/plot_fragment_figure.py')
        for p in sorted((SOURCE/'data').glob('*.csv')):
            z.write(p,f'{SOURCE.name}/data/{p.name}')
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                z.write(p,Path(SOURCE.name)/ROOT.name/p.relative_to(ROOT))
    with zipfile.ZipFile(target) as z:assert z.testzip() is None
    print(json.dumps(report,indent=2))
    print(target)
    print(f'{target.stat().st_size/1024**2:.2f} MiB')


if __name__=='__main__':main()
