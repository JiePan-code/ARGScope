#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Create three publication-ready Protein Student grid-search figures.

Input
-----
Place this script in the same directory as ``ALL_PARAMETER_RESULTS.csv``.

Output
------
``protein_grid_figures/Figure1_Protein_tradeoff.{png,pdf,svg}``
``protein_grid_figures/Figure2_Protein_interaction_3x3.{png,pdf,svg}``
``protein_grid_figures/Figure3_Protein_sensitivity_2x5.{png,pdf,svg}``

The three figures follow the supplied reference:
    Figure 1 : validation accuracy versus weighted precision;
    Figure 2 : 3 x 3 Stage-1 hyperparameter-interaction panels;
    Figure 3 : 2 x 5 hyperparameter-sensitivity panels.

No overall or section title is added. Parameter names and facet labels are
retained because they are required to interpret the panels.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


# =============================================================================
# Paths and output settings
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
CSV_PATH = SCRIPT_DIR / "ALL_PARAMETER_RESULTS.csv"
OUTPUT_DIR = SCRIPT_DIR / "protein_grid_figures"

ACC_COL = "val_end_accuracy"
PREC_COL = "val_end_weighted_precision"
BALANCE_COL = "balance_score"

# Publication sizes. Figure 1 can be placed at one-column or intermediate
# width; Figures 2 and 3 are designed for full double-column placement.
FIGURE1_SIZE_IN = (4.20, 3.35)
FIGURE2_SIZE_IN = (5.40, 4.55)
FIGURE3_SIZE_IN = (7.20, 3.15)
PNG_DPI = 600

STAGE1 = "student_grid_81"
STAGE2 = "student_grid_27"

BLUE = "#4C92C3"
ORANGE = "#F28E42"
GREEN = "#78AA68"
PALE_BLUE = "#C7DCE9"
PALE_ORANGE = "#F2D6B3"
PALE_GREEN = "#CCDDBF"
INK = "#252525"
MID_GREY = "#666666"
LIGHT_GREY = "#D8D8D8"

BOX_COLORS = (PALE_BLUE, PALE_ORANGE, PALE_GREEN, "#D8C9E7", "#E8C5C5")
POINT_COLORS = (BLUE, ORANGE, GREEN, "#9575B5", "#C96B67")


def set_publication_style() -> None:
    """Apply restrained, journal-compatible Matplotlib defaults."""

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [
                "Arial",
                "Helvetica",
                "Liberation Sans",
                "DejaVu Sans",
            ],
            "font.size": 6.2,
            "axes.labelsize": 6.5,
            "axes.titlesize": 6.7,
            "axes.linewidth": 0.65,
            "axes.edgecolor": INK,
            "xtick.labelsize": 5.7,
            "ytick.labelsize": 5.7,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "xtick.major.size": 2.4,
            "ytick.major.size": 2.4,
            "xtick.major.width": 0.60,
            "ytick.major.width": 0.60,
            "legend.fontsize": 5.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.facecolor": "white",
            "savefig.edgecolor": "white",
        }
    )


# =============================================================================
# Data preparation
# =============================================================================


def require_columns(df: pd.DataFrame, columns: Iterable[str]) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise ValueError(
            "ALL_PARAMETER_RESULTS.csv is missing the following columns:\n  - "
            + "\n  - ".join(missing)
        )


def prepare_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    require_columns(df, ("stage", "combo_id", ACC_COL, PREC_COL))
    out = df.copy()

    for column in (ACC_COL, PREC_COL):
        out[column] = pd.to_numeric(out[column], errors="coerce")

    out[BALANCE_COL] = 0.5 * out[ACC_COL] + 0.5 * out[PREC_COL]
    out["ACC_percent"] = 100.0 * out[ACC_COL]
    out["Weighted_precision_percent"] = 100.0 * out[PREC_COL]
    out["Balance_percent"] = 100.0 * out[BALANCE_COL]
    return out


def load_data() -> pd.DataFrame:
    if not CSV_PATH.is_file():
        raise FileNotFoundError(
            f"Cannot find {CSV_PATH}\n"
            "Put this script in the same folder as ALL_PARAMETER_RESULTS.csv."
        )

    df = pd.read_csv(CSV_PATH, encoding="utf-8-sig")
    df = prepare_dataframe(df)

    print("=" * 88)
    print("Protein Student grid-search visualization")
    print("=" * 88)
    print(f"Input : {CSV_PATH}")
    print(f"Rows  : {len(df):,}")
    print("Stages:")
    print(df["stage"].value_counts(dropna=False).to_string())
    return df


def format_value(value) -> str:
    if pd.isna(value):
        return "NA"
    if isinstance(value, str):
        return value.replace("_", " ")
    number = float(value)
    if number != 0 and abs(number) < 0.001:
        return f"{number:.0e}"
    return f"{number:g}"


def sorted_levels(series: pd.Series) -> list:
    levels = series.dropna().drop_duplicates().tolist()
    try:
        return sorted(levels, key=float)
    except (TypeError, ValueError):
        return sorted(levels, key=str)


def level_mask(series: pd.Series, level) -> np.ndarray:
    if isinstance(level, (int, float, np.integer, np.floating)):
        values = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
        return np.isclose(values, float(level), equal_nan=False)
    return series.astype(str).to_numpy() == str(level)


def pareto_front(df: pd.DataFrame, x_col: str, y_col: str) -> pd.DataFrame:
    """Return the non-dominated frontier when both metrics are maximized."""

    work = (
        df.dropna(subset=[x_col, y_col])
        .sort_values([x_col, y_col], ascending=[False, False])
        .copy()
    )
    keep = []
    best_y = -np.inf
    for index, row in work.iterrows():
        current_y = float(row[y_col])
        if current_y > best_y:
            keep.append(index)
            best_y = current_y
    return work.loc[keep].sort_values(x_col).copy()


def style_axis(ax, grid_axis: str | None = None) -> None:
    ax.set_facecolor("white")
    for spine in ax.spines.values():
        spine.set_color(INK)
        spine.set_linewidth(0.65)
    ax.tick_params(axis="both", pad=1.6)
    if grid_axis is not None:
        ax.grid(
            axis=grid_axis,
            color=LIGHT_GREY,
            linewidth=0.42,
            alpha=0.45,
            zorder=0,
        )


# =============================================================================
# Upper-left performance panel
# =============================================================================


def draw_tradeoff_panel(ax, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    stage1 = df[df["stage"] == STAGE1].copy()
    stage2 = df[df["stage"] == STAGE2].copy()
    search = pd.concat([stage1, stage2], ignore_index=False)
    search = search.dropna(
        subset=["ACC_percent", "Weighted_precision_percent", BALANCE_COL]
    ).copy()

    if search.empty:
        raise ValueError(f"No rows were found for {STAGE1!r} or {STAGE2!r}.")

    if not stage1.empty:
        ax.scatter(
            stage1["ACC_percent"],
            stage1["Weighted_precision_percent"],
            s=10.5,
            marker="o",
            c=BLUE,
            alpha=0.92,
            edgecolors="none",
            label=f"Stage 1 ({len(stage1)})",
            zorder=3,
        )

    if not stage2.empty:
        ax.scatter(
            stage2["ACC_percent"],
            stage2["Weighted_precision_percent"],
            s=13.0,
            marker="^",
            c=ORANGE,
            alpha=0.95,
            edgecolors="none",
            label=f"Stage 2 ({len(stage2)})",
            zorder=4,
        )

    top5 = search.nlargest(5, BALANCE_COL).copy()
    frontier = pareto_front(search, "ACC_percent", "Weighted_precision_percent")

    if len(frontier) >= 2:
        ax.plot(
            frontier["ACC_percent"],
            frontier["Weighted_precision_percent"],
            color=INK,
            linestyle="--",
            linewidth=0.80,
            marker="o",
            markersize=1.8,
            markerfacecolor="white",
            markeredgewidth=0.55,
            zorder=5,
            label="Pareto front",
        )

    ax.scatter(
        top5["ACC_percent"],
        top5["Weighted_precision_percent"],
        s=29,
        marker="o",
        facecolors="none",
        edgecolors=INK,
        linewidths=0.85,
        zorder=7,
        label="Top 5",
    )

    best = top5.iloc[0]
    ax.scatter(
        [best["ACC_percent"]],
        [best["Weighted_precision_percent"]],
        s=37,
        marker="*",
        c=INK,
        edgecolors="white",
        linewidths=0.35,
        zorder=9,
        label="Best",
    )

    offsets = ((4, 5), (4, -8), (-15, 5), (4, 5), (-15, -8))
    for rank, ((_, row), offset) in enumerate(zip(top5.iterrows(), offsets), start=1):
        ax.annotate(
            f"T{rank}",
            xy=(row["ACC_percent"], row["Weighted_precision_percent"]),
            xytext=offset,
            textcoords="offset points",
            fontsize=5.0,
            color=INK,
            zorder=10,
        )

    x = search["ACC_percent"].to_numpy(dtype=float)
    y = search["Weighted_precision_percent"].to_numpy(dtype=float)
    x_span = max(float(np.nanmax(x) - np.nanmin(x)), 0.10)
    y_span = max(float(np.nanmax(y) - np.nanmin(y)), 0.10)
    ax.set_xlim(np.nanmin(x) - 0.05 * x_span, np.nanmax(x) + 0.06 * x_span)
    ax.set_ylim(np.nanmin(y) - 0.06 * y_span, np.nanmax(y) + 0.08 * y_span)
    ax.set_xlabel("Validation accuracy (%)", labelpad=2.0)
    ax.set_ylabel("Validation weighted precision (%)", labelpad=2.0)
    style_axis(ax, grid_axis="both")

    legend = ax.legend(
        loc="upper left",
        frameon=False,
        borderaxespad=0.20,
        handletextpad=0.35,
        labelspacing=0.25,
        markerscale=0.86,
    )
    legend.set_zorder(20)
    return top5, frontier


# =============================================================================
# Upper-right 3 x 3 interaction panel
# =============================================================================


def draw_interaction_panels(
    fig,
    parent_spec,
    df: pd.DataFrame,
) -> None:
    stage = df[df["stage"] == STAGE1].copy()
    required = (
        "student_lr",
        "dropout",
        "class_weight_power",
        "student_prototype_align",
        "Balance_percent",
    )
    require_columns(stage, required)
    stage = stage.dropna(subset=list(required)).copy()

    lr_values = sorted_levels(stage["student_lr"])
    dropout_values = sorted_levels(stage["dropout"])
    class_values = sorted_levels(stage["class_weight_power"])
    prototype_values = sorted_levels(stage["student_prototype_align"])

    counts = (
        len(lr_values),
        len(dropout_values),
        len(class_values),
        len(prototype_values),
    )
    if counts != (3, 3, 3, 3) or len(stage) != 81:
        raise ValueError(
            f"{STAGE1} must be a complete 3x3x3x3 grid; "
            f"found levels={counts}, rows={len(stage)}."
        )

    inner = GridSpecFromSubplotSpec(
        3,
        4,
        subplot_spec=parent_spec,
        width_ratios=(1, 1, 1, 0.075),
        wspace=0.26,
        hspace=0.38,
    )

    norm = Normalize(
        vmin=float(stage["Balance_percent"].min()),
        vmax=float(stage["Balance_percent"].max()),
    )
    cmap = plt.get_cmap("viridis")
    top5_indices = set(stage.nlargest(5, BALANCE_COL).index.tolist())
    mappable = None

    for row_index, lr in enumerate(lr_values):
        for col_index, dropout in enumerate(dropout_values):
            ax = fig.add_subplot(inner[row_index, col_index])
            panel = stage[
                level_mask(stage["student_lr"], lr)
                & level_mask(stage["dropout"], dropout)
            ].copy()

            mappable = ax.scatter(
                panel["class_weight_power"],
                panel["student_prototype_align"],
                c=panel["Balance_percent"],
                cmap=cmap,
                norm=norm,
                s=13.5,
                edgecolors="none",
                zorder=3,
            )

            selected = panel.loc[panel.index.intersection(top5_indices)]
            if not selected.empty:
                ax.scatter(
                    selected["class_weight_power"],
                    selected["student_prototype_align"],
                    marker="*",
                    s=30,
                    facecolors="#F4D03F",
                    edgecolors=INK,
                    linewidths=0.55,
                    zorder=6,
                )

            ax.set_xticks([float(value) for value in class_values])
            ax.set_yticks([float(value) for value in prototype_values])
            ax.set_xticklabels([format_value(value) for value in class_values])
            ax.set_yticklabels([format_value(value) for value in prototype_values])

            # Facet conditions are annotations, not figure titles.
            ax.text(
                0.5,
                1.055,
                f"LR {format_value(lr)}\nDropout {format_value(dropout)}",
                transform=ax.transAxes,
                ha="center",
                va="bottom",
                fontsize=4.35,
                linespacing=0.92,
                color=INK,
            )

            if row_index == 2:
                ax.set_xlabel("Class-weight power", fontsize=4.7, labelpad=1.1)
            else:
                ax.tick_params(labelbottom=False)

            if col_index == 0:
                ax.set_ylabel("Prototype-align", fontsize=4.7, labelpad=1.0)
            else:
                ax.tick_params(labelleft=False)

            ax.tick_params(axis="both", labelsize=4.25, length=1.7, pad=0.8)
            style_axis(ax, grid_axis="both")

    colorbar_axis = fig.add_subplot(inner[:, 3])
    if mappable is not None:
        colorbar = fig.colorbar(mappable, cax=colorbar_axis)
        colorbar.set_label("Balance score (%)", fontsize=5.0, labelpad=2.0)
        colorbar.ax.tick_params(labelsize=4.4, length=1.8, width=0.55, pad=1.0)
        colorbar.outline.set_linewidth(0.55)


# =============================================================================
# Lower 2 x 5 sensitivity panel
# =============================================================================


SENSITIVITY_SPECS: Sequence[tuple[str, str, str]] = (
    ("teacher_grid", "teacher_lr", "Teacher LR"),
    ("teacher_grid", "teacher_refined_anchor", "Teacher refined anchor"),
    (STAGE1, "student_lr", "Student LR"),
    (STAGE1, "dropout", "Dropout"),
    (STAGE1, "class_weight_power", "Class-weight power"),
    (STAGE1, "student_prototype_align", "Prototype-align weight"),
    (STAGE2, "student_subtype_ce", "Subtype CE weight"),
    (STAGE2, "student_binary_kd", "Binary KD weight"),
    (STAGE2, "student_feature_align", "Feature-align weight"),
    ("robustness", "candidate_rank", "Top-3 candidate rank"),
)


def collect_sensitivity_values(
    df: pd.DataFrame,
    stage_name: str,
    parameter: str,
) -> tuple[pd.DataFrame, list, list[np.ndarray]]:
    if parameter not in df.columns:
        return pd.DataFrame(), [], []
    source = df[df["stage"] == stage_name].dropna(
        subset=[parameter, "Balance_percent"]
    ).copy()
    levels = sorted_levels(source[parameter]) if not source.empty else []
    arrays = [
        source.loc[level_mask(source[parameter], level), "Balance_percent"].to_numpy(
            dtype=float
        )
        for level in levels
    ]
    return source, levels, arrays


def sensitivity_limits(df: pd.DataFrame) -> tuple[float, float]:
    arrays = []
    for stage_name, parameter, _ in SENSITIVITY_SPECS:
        _, _, values = collect_sensitivity_values(df, stage_name, parameter)
        arrays.extend(array for array in values if len(array))
    if not arrays:
        raise ValueError("No hyperparameter-sensitivity data were available.")

    values = np.concatenate(arrays)
    value_min = float(np.nanmin(values))
    value_max = float(np.nanmax(values))
    span = max(value_max - value_min, 0.35)
    return value_min - 0.07 * span, value_max + 0.09 * span


def draw_sensitivity_panel(
    ax,
    source: pd.DataFrame,
    levels: list,
    arrays: list[np.ndarray],
    parameter: str,
    label: str,
    y_limits: tuple[float, float],
    rng: np.random.Generator,
) -> list[dict]:
    if not levels:
        ax.axis("off")
        return []

    positions = np.arange(1, len(levels) + 1, dtype=float)
    boxplot = ax.boxplot(
        arrays,
        positions=positions,
        widths=0.56,
        showfliers=False,
        patch_artist=True,
        boxprops={"linewidth": 0.60, "edgecolor": MID_GREY},
        medianprops={"linewidth": 0.85, "color": INK},
        whiskerprops={"linewidth": 0.60, "color": MID_GREY},
        capprops={"linewidth": 0.60, "color": MID_GREY},
    )

    for index, patch in enumerate(boxplot["boxes"]):
        patch.set_facecolor(BOX_COLORS[index % len(BOX_COLORS)])
        patch.set_alpha(0.78)

    summary_rows = []
    for index, (position, level, values) in enumerate(zip(positions, levels, arrays)):
        if len(values) == 0:
            continue
        jitter = rng.uniform(-0.095, 0.095, size=len(values))
        ax.scatter(
            position + jitter,
            values,
            s=5.3,
            c=POINT_COLORS[index % len(POINT_COLORS)],
            alpha=0.75,
            edgecolors="none",
            zorder=3,
        )

        summary_rows.append(
            {
                "stage": source["stage"].iloc[0],
                "parameter": parameter,
                "display_name": label,
                "level": level,
                "n": int(len(values)),
                "median_balance_percent": float(np.median(values)),
                "mean_balance_percent": float(np.mean(values)),
                "min_balance_percent": float(np.min(values)),
                "max_balance_percent": float(np.max(values)),
                "best_balance_percent": float(np.max(values)),
            }
        )

    ax.set_xticks(positions)
    ax.set_xticklabels([format_value(level) for level in levels], fontsize=5.1)
    ax.set_ylim(*y_limits)
    ax.set_title(label, fontsize=6.1, pad=2.5, fontweight="normal")
    style_axis(ax, grid_axis="y")
    return summary_rows


def draw_sensitivity_panels(fig, parent_spec, df: pd.DataFrame) -> list[dict]:
    inner = GridSpecFromSubplotSpec(
        2,
        5,
        subplot_spec=parent_spec,
        wspace=0.25,
        hspace=0.30,
    )
    y_limits = sensitivity_limits(df)
    rng = np.random.default_rng(20260904)
    summary_rows = []

    for index, (stage_name, parameter, label) in enumerate(SENSITIVITY_SPECS):
        row_index, col_index = divmod(index, 5)
        ax = fig.add_subplot(inner[row_index, col_index])
        source, levels, arrays = collect_sensitivity_values(df, stage_name, parameter)
        rows = draw_sensitivity_panel(
            ax,
            source,
            levels,
            arrays,
            parameter,
            label,
            y_limits,
            rng,
        )
        summary_rows.extend(rows)

        if levels and col_index == 0:
            ax.set_ylabel("Balance score (%)", labelpad=1.8)
        elif levels:
            ax.tick_params(labelleft=False)

    return summary_rows


# =============================================================================
# Figure assembly and exports
# =============================================================================


def save_figure(fig, stem: str) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    targets = (
        (OUTPUT_DIR / f"{stem}.png", {"dpi": PNG_DPI}),
        (OUTPUT_DIR / f"{stem}.pdf", {}),
        (OUTPUT_DIR / f"{stem}.svg", {}),
    )
    for path, extra in targets:
        fig.savefig(
            path,
            bbox_inches="tight",
            pad_inches=0.025,
            facecolor="white",
            **extra,
        )
        print(f"Saved: {path}")


def draw_tradeoff_figure(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    set_publication_style()
    fig, ax = plt.subplots(
        figsize=FIGURE1_SIZE_IN,
        facecolor="white",
    )
    top5, frontier = draw_tradeoff_panel(ax, df)
    fig.subplots_adjust(left=0.145, right=0.975, bottom=0.155, top=0.975)
    save_figure(fig, "Figure1_Protein_tradeoff")
    plt.close(fig)
    return top5, frontier


def draw_interaction_figure(df: pd.DataFrame) -> None:
    set_publication_style()
    fig = plt.figure(figsize=FIGURE2_SIZE_IN, facecolor="white")
    outer = GridSpec(
        1,
        1,
        figure=fig,
        left=0.105,
        right=0.965,
        bottom=0.105,
        top=0.955,
    )
    draw_interaction_panels(fig, outer[0], df)
    save_figure(fig, "Figure2_Protein_interaction_3x3")
    plt.close(fig)


def draw_sensitivity_figure(df: pd.DataFrame) -> list[dict]:
    set_publication_style()
    fig = plt.figure(figsize=FIGURE3_SIZE_IN, facecolor="white")
    outer = GridSpec(
        1,
        1,
        figure=fig,
        left=0.070,
        right=0.990,
        bottom=0.125,
        top=0.950,
    )
    sensitivity_rows = draw_sensitivity_panels(fig, outer[0], df)
    save_figure(fig, "Figure3_Protein_sensitivity_2x5")
    plt.close(fig)
    return sensitivity_rows


def export_summary_tables(
    top5: pd.DataFrame,
    frontier: pd.DataFrame,
    sensitivity_rows: list[dict],
) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    top5.to_csv(
        OUTPUT_DIR / "top5_student_search.csv",
        index=False,
        encoding="utf-8-sig",
    )
    frontier.to_csv(
        OUTPUT_DIR / "pareto_front_student_search.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(sensitivity_rows).round(6).to_csv(
        OUTPUT_DIR / "hyperparameter_sensitivity_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )


def main() -> None:
    df = load_data()
    top5, frontier = draw_tradeoff_figure(df)
    draw_interaction_figure(df)
    sensitivity_rows = draw_sensitivity_figure(df)
    export_summary_tables(top5, frontier, sensitivity_rows)

    student_search = df[df["stage"].isin((STAGE1, STAGE2))].dropna(
        subset=[BALANCE_COL]
    )
    best = student_search.nlargest(1, BALANCE_COL).iloc[0]

    print("=" * 88)
    print("Completed")
    print("=" * 88)
    print(f"Best stage        : {best['stage']}")
    print(f"Best combo ID     : {int(best['combo_id'])}")
    print(f"Validation ACC    : {best['ACC_percent']:.4f}%")
    print(f"Weighted precision: {best['Weighted_precision_percent']:.4f}%")
    print(f"Balance score     : {best['Balance_percent']:.4f}%")
    print(f"Output directory  : {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
