#!/usr/bin/env python3
"""Show only Types with ARGScope > 0 in each modality/completeness/metric.

Display filter only. Original scores, network inputs and overall metrics stay
unchanged. Average is conditional on retained Types, not an all-Type macro mean.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
DATA=ROOT/'filtered_heatmap_data'
FIG=ROOT/'filtered_heatmaps'
DATA.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('original_plot_helpers',SOURCE/'plot_fragment_figure.py')
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.FIG=FIG
source=SOURCE/'data/reported_per_type_NOT_matched.csv'
raw=pd.read_csv(source)
before=hashlib.sha256(source.read_bytes()).hexdigest()
audits=[]
means=[]


def panel(fig,mod,pct,metric,left,top):
    selected=raw[(raw.Modality==mod)&(raw.Completeness==pct)&(raw.Metric==metric)]
    table=selected.pivot(index='Type',columns='Model',values='Value').reindex(index=base.ORDER,columns=base.MODELS[mod])
    assert table.ARGScope.notna().all()
    assert table.ARGScope.between(0,1).all()
    keep=table.ARGScope.gt(0)
    shown=table.loc[keep]
    assert len(shown)>0 and shown.ARGScope.gt(0).all()
    assert table.loc[~keep,'ARGScope'].eq(0).all()
    for typ in table.index:
        audits.append(dict(Modality=mod,Completeness=pct,Metric=metric,Type=typ,
                           ARGScope_value=float(table.loc[typ,'ARGScope']),Shown=bool(keep.loc[typ]),
                           Reason='ARGScope_strictly_positive' if keep.loc[typ] else 'ARGScope_exact_zero'))
    shown.to_csv(DATA/f'{mod}_{pct}_{metric}_displayed_values.csv',encoding='utf-8-sig',index_label='Type',float_format='%.12g')
    values=shown.to_numpy(float)
    models=shown.columns.tolist()
    n=len(shown)
    ch=3.65
    x=left+39
    w=77
    h=n*ch
    ax=base.ax_mm(fig,x,top,w,h)
    cmap=plt.get_cmap('Blues').copy();cmap.set_bad('#ECEDEF')
    im=ax.imshow(np.ma.masked_invalid(values),vmin=0,vmax=1,cmap=cmap,aspect='auto',interpolation='none')
    ax.set_yticks(range(n),[base.DISPLAY[t] for t in shown.index],fontsize=7)
    ax.set_xticks(range(len(models)),models,rotation=53,ha='right',rotation_mode='anchor',fontsize=7)
    ax.tick_params(length=0,pad=3)
    for tick in ax.get_xticklabels():
        if tick.get_text()=='ARGScope':tick.set_color(base.COLORS['ARGScope']);tick.set_fontweight('bold')
    for spine in ax.spines.values():spine.set_visible(False)
    ax.set_xticks(np.arange(-.5,len(models),1),minor=True)
    ax.set_yticks(np.arange(-.5,n,1),minor=True)
    ax.grid(which='minor',color='white',lw=.55);ax.tick_params(which='minor',length=0)
    for i in range(n):
        for j in range(len(models)):
            val=values[i,j]
            ax.text(j,i,'—' if np.isnan(val) else f'{val:.4f}',ha='center',va='center',fontsize=7,
                    color='white' if val>.60 else '#29333B')
    avg_ax=base.ax_mm(fig,x,top-ch-2.8,w,ch)
    average=shown.mean(axis=0,skipna=True)
    avg_ax.imshow(average.to_numpy()[None,:],vmin=0,vmax=1,cmap=cmap,aspect='auto')
    avg_ax.set_yticks([0],['Average'],fontsize=7);avg_ax.set_xticks([]);avg_ax.tick_params(length=0,pad=3)
    for spine in avg_ax.spines.values():spine.set_visible(False)
    for j,model in enumerate(models):
        val=average[model]
        avg_ax.text(j,0,'—' if pd.isna(val) else f'{val:.4f}',ha='center',va='center',fontsize=7,
                    color='white' if val>.60 else '#29333B')
        means.append(dict(Modality=mod,Completeness=pct,Metric=metric,Model=model,
                          Displayed_Type_mean=val,N_displayed_Types=n,
                          N_available_Types=int(shown[model].notna().sum()),
                          Definition='conditional_mean_over_displayed_Types_with_available_values_NOT_overall_macro'))
    avg_ax.set_title(f'{pct}% · {metric}',fontsize=9,pad=7)
    # One full-height scale per panel; decimal values match the cell annotations.
    cb=fig.colorbar(im,cax=base.ax_mm(fig,left+120,top-ch-2.8,2.1,h+ch+2.8))
    cb.set_ticks([0,.5,1]);cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=6,length=2,pad=2)
    return n


def main():
    counts=[]
    for mod in ['protein','dna']:
        for metric in ['Precision','Recall','F1']:
            fig=base.canvas(288,278)
            for pct,left,top in [(60,5,26),(70,149,26),(80,5,160),(90,149,160)]:
                n=panel(fig,mod,pct,metric,left,top)
                counts.append(dict(Modality=mod,Metric=metric,Completeness=pct,N_displayed=n,N_removed=23-n))
            base.save(fig,f'{mod}_{metric.lower()}_ARGScope_positive_Types')
    pd.DataFrame(audits).to_csv(DATA/'display_filter_audit.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(means).to_csv(DATA/'Average_displayed_Types_NOT_overall.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    pd.DataFrame(counts).to_csv(DATA/'Type_display_counts.csv',index=False,encoding='utf-8-sig')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    (ROOT/'filtered_heatmap_manifest.json').write_text(json.dumps(base.exports,indent=2),encoding='utf-8')
    (ROOT/'filtered_heatmap_layout.json').write_text(json.dumps(base.LAYOUT_QA,indent=2),encoding='utf-8')
    print(pd.DataFrame(counts).query("Metric == 'Precision'").to_string(index=False))
    print('PASS: original source unchanged; exact zero ARGScope Types omitted per condition and metric.')


if __name__=='__main__':main()
