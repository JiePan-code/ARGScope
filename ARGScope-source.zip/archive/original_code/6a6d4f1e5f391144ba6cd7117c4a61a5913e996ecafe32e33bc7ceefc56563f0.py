"""VF/BGC metrics with a 2x4 epoch-zero versus best-checkpoint UMAP grid."""
from pathlib import Path
import argparse
import json
import shutil
import zipfile
import compose_vf_bgc_merged as plots

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'/'vf_bgc_merged_20260922_v5'
DEST=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\VF_BGC_合并组图_20260922_v5')
plots.OUT=OUT
plt=plots.plt


def epoch_group(fig,data,top):
    """One domain per row: Protein zero/best, then DNA zero/best."""
    height=fig.get_figheight()
    panel_top=top-.25
    panel_bottom=panel_top-2.65
    grid=fig.add_gridspec(1,4,left=.068,right=.985,
        top=panel_top/height,bottom=panel_bottom/height,wspace=.16)
    fig.text(.025,(panel_top+panel_bottom)/(2*height),data['domain'],rotation=90,
             ha='center',va='center',fontsize=15,weight='bold')
    groups=[]
    for pair,mod in enumerate(['AA','NT']):
        v=data['models'][mod]
        files=[v['initial'],v['best']]
        for stage,path in enumerate(files):
            col=pair*2+stage
            frame=plots.cached_embedding(data,mod,path)
            input_name='Protein' if mod=='AA' else 'DNA'
            epoch_title='Best epoch' if stage else 'Epoch 0'
            title=f'{input_name} · {epoch_title}'
            if stage==0: assert int(frame.epoch.iloc[0])==0
            plots.embedding_panel(fig.add_subplot(grid[col]),frame,data,title)
            groups.append({'domain':data['domain'],'variant':mod,'epoch':int(frame.epoch.iloc[0]),
                           'title':title,'row':0 if data['domain']=='VF' else 1,'column':col,
                           'samples':len(frame),'feature_file':str(path)})
    legend_height=1.10 if data['domain']=='VF' else .64
    legend_gap=.40 if data['domain']=='VF' else .24
    legend_bottom=panel_bottom-legend_gap-legend_height
    assert legend_bottom>0,(data['domain'],legend_bottom)
    plots.type_legend(fig.add_axes([.068,legend_bottom/height,.917,legend_height/height]),data,4)
    return groups


def metric_block(fig,data_all,offset):
    """Preserve prior metric-panel sizes and replace type bars with subtype bars."""
    height=fig.get_figheight()
    def rect(x,y,w,h):
        return [x,(y*15.2+offset)/height,w,h*15.2/height]
    fig.legend(handles=plots.model_handles(),loc='upper center',bbox_to_anchor=(.53,.999),
        ncol=2,frameon=False,fontsize=14,handlelength=2.2,columnspacing=2.1)
    for col,domain in enumerate(['VF','BGC']):
        data=data_all[domain]; x=.078+col*.505; w=.392
        plots.radar(fig.add_axes(rect(x+.035,.757,w-.07,.174),projection='polar'),data)
        plots.functional_bars(fig.add_axes(rect(x,.566,w,.134)),data,'Subtype','macro')
        plots.heatmap(fig.add_axes(rect(.193+col*.505,.214,.282,.283)),data)
    cax=fig.add_axes(rect(.510,.227,.009,.247))
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,1),cmap='Blues'),cax=cax)
    cb.set_ticks([0,.25,.5,.75,1]); cb.ax.yaxis.set_major_formatter(plots.FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=10,length=2,pad=2); cb.outline.set_linewidth(.6)


def composites(data_all):
    fig=plt.figure(figsize=(14,21.15))
    metric_block(fig,data_all,5.95)
    manifest=[]
    manifest.extend(epoch_group(fig,data_all['VF'],8.6))
    manifest.extend(epoch_group(fig,data_all['BGC'],3.9))
    plots.save(fig,'VF_BGC_main_combined')

    # Also offer the six metric panels together for flexible journal-page assembly.
    fig=plt.figure(figsize=(14,12.4))
    metric_block(fig,data_all,-2.8)
    plots.save(fig,'VF_BGC_metrics_overview')

    fig=plt.figure(figsize=(14,8.8))
    epoch_group(fig,data_all['VF'],8.6)
    epoch_group(fig,data_all['BGC'],3.9)
    plots.save(fig,'VF_BGC_epochs_2x4','epoch_groups')
    return manifest


def standalone_metrics(data_all):
    index=[]
    for domain,data in data_all.items():
        for kind in ['binary_radar','subtype_macro','type_heatmap']:
            if kind=='binary_radar':
                fig=plt.figure(figsize=(6,6.1))
                plots.radar(fig.add_axes([.16,.18,.68,.66],projection='polar'),data)
                fig.legend(handles=plots.model_handles(),loc='lower center',bbox_to_anchor=(.5,.015),
                    ncol=2,frameon=False,fontsize=12)
            elif kind=='subtype_macro':
                fig=plt.figure(figsize=(6.8,4.8))
                ax=fig.add_axes([.12,.16,.85,.61])
                plots.functional_bars(ax,data,'Subtype','macro')
                for t in ax.texts:
                    if t.get_text()=='Subtype (macro)': t.set_text(f'{domain} · Subtype (macro)')
                fig.legend(handles=plots.model_handles(),loc='upper center',bbox_to_anchor=(.53,.985),
                    ncol=2,frameon=False,fontsize=12)
            else:
                fig=plt.figure(figsize=(8.8,7.7 if domain=='VF' else 5.3))
                plots.heatmap(fig.add_axes([.34,.105,.54,.81]),data)
                cax=fig.add_axes([.905,.16,.018,.68])
                cb=fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,1),cmap='Blues'),cax=cax)
                cb.set_ticks([0,.25,.5,.75,1]); cb.ax.yaxis.set_major_formatter(plots.FormatStrFormatter('%.4f'))
                cb.ax.tick_params(labelsize=10,length=2,pad=2); cb.outline.set_linewidth(.6)
            name=f'{domain}_{kind}'
            plots.save(fig,name,'individual_panels')
            index.append({'Domain':domain,'Content':kind,'File':f'individual_panels/{name}',
                          'Formats':'PNG | PDF | SVG'})
    plots.pd.DataFrame(index).to_csv(OUT/'individual_panels'/'子图索引.csv',index=False,encoding='utf-8-sig')


def documents(manifest):
    notes='''# VF/BGC 组图：二分类、Subtype、Type 与 2×4 Epoch 对照

## 图件

- VF_BGC_main_combined：上部依次是二分类雷达图、Subtype 五指标柱状图、Type 热图，左 VF 右 BGC。下部是 2×4 Epoch 组图，第一行 VF，第二行 BGC。
- VF_BGC_metrics_overview：单独的六张指标图组合，便于后续拼版。
- individual_panels：上述六张指标子图，每张均为 PNG/PDF/SVG。
- epoch_groups/VF_BGC_epochs_2x4：两行四列的独立 UMAP 组图，每行从左到右是 Protein · Epoch 0、Protein · Best epoch、DNA · Epoch 0、DNA · Best epoch。每行下方保留各自完整类别图例，不再拆开导出单个 epoch。

所有图使用 Arial，无 A/B/C/D 字母编号。Epoch 只展示初始和最佳模型，不展示中间 epoch。最佳模型不显示具体数字。PNG 为 300 dpi，PDF/SVG 保留矢量文字。另提供六张指标图和独立 2×4 Epoch 组图，方便论文排版。主图为 14×21.15 英寸设计画布，其他指标图的实际尺寸和字号不变。

## 统计定义不变

柱状图是 Subtype 的 ACC、macro Precision、macro Recall、macro F1、MCC，包含全部测试样本及负类。二分类 Precision、Recall、F1 也为 macro。Type 热图在真实阳性测试样本上计算，不加入真实负类。漏检仍保留为错误，Average 是 Type 的算术平均值，所有数值显示四位小数。未改阈值、预测或类别映射。

UMAP 使用已经核对的原始坐标，完整保留每个输入版本的真实阳性样本，不重新拟合、不重新挑种子、不移动簇、不删点。各面板采用等比例坐标，但不同投影间的绝对位置、距离不可定量比较。实际最佳 epoch 为 VF-AA 69、VF-NT 48、BGC-AA 10、BGC-NT 2，保存在 epoch_manifest.json 与原始坐标表中。

## 简短图注

Performance of VFScope and BGCScope on full-length test sequences. The upper panels show binary classification, subtype-level ACC, macro precision, macro recall, macro F1 and MCC, and type-resolved precision, recall and F1. VF and BGC results are shown on the left and right, respectively. The lower UMAP grid shows VF in the first row and BGC in the second. Columns show protein epoch 0, protein best epoch, DNA epoch 0 and DNA best epoch. Type evaluation excludes reference-negative sequences while retaining missed positives as errors. Subtype evaluation includes all test sequences.
'''
    (OUT/'图注与排版说明.md').write_text(notes,encoding='utf-8')
    (OUT/'epoch_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    for domain in ['VF','BGC']:
        shutil.copytree(plots.OLD/domain/'plot_data',OUT/'plot_data'/domain,dirs_exist_ok=True)
    code=OUT/'code'; code.mkdir(exist_ok=True)
    for filename in ['compose_vf_bgc_requested.py','compose_vf_bgc_merged.py','plot_vf_bgc_full_length.py']:
        shutil.copy2(HERE/filename,code/filename)
    audit={'font':'Arial','all_metrics_revalidated_from_sequence_predictions':True,
        'umap_coordinates_reused_unchanged':True,'panel_letters':False,
        'main_bar_task':'Subtype','main_bar_average':'macro','individual_metric_panels':6,
        'individual_epoch_panels_exported':False,'epoch_snapshots':len(manifest),
        'epoch_layout':'2 rows x 4 columns: VF/BGC; Protein 0/best, DNA 0/best',
        'figures':plots.FIGURE_AUDITS,'visual_review':'pending'}
    (OUT/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')


def publish():
    shutil.copytree(OUT,DEST,dirs_exist_ok=True)
    archive=DEST/'VF_BGC_figures_epoch_2x4.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file() and p.suffix.lower()!='.zip':
                z.write(p,p.relative_to(DEST))
    with zipfile.ZipFile(archive) as z: assert z.testzip() is None
    print(f'DELIVERED {DEST}',flush=True)


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    data={domain:plots.base.read_domain(domain) for domain in ['VF','BGC']}
    print('SOURCE METRICS VERIFIED',flush=True)
    manifest=composites(data)
    standalone_metrics(data)
    documents(manifest)


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--publish',action='store_true')
    if parser.parse_args().publish: publish()
    else: run()
