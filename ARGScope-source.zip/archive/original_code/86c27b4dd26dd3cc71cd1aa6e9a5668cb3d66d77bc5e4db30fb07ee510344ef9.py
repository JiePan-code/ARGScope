#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Official ESM-2 mean embedding for the corrected BGC/nonBGC protein FASTA.

Input:
  /scratch/users/ntu/pan.jie/work/BGCdataset/
  dataset/corrected_BGC_nonBGC_protein.fasta

Official ESM-2 definition:
  model      : esm2_t33_650M_UR50D
  layer      : 33
  dimension  : 1280
  truncation : first 1022 aa
  pooling    : mean residue representations
  BOS/EOS    : excluded

Unsupported residue symbols such as J are mapped to official X
for MODEL INPUT ONLY. The source FASTA is never modified.

A100:
  CUDA only
  TF32 on by default
  dynamic token-budget batching
  OOM -> halve token budget and retry
  DataLoader prefetch / pinned memory
  live heartbeat every 30 s
"""

from __future__ import annotations

import os

ORIGINAL_CUDA_VISIBLE_DEVICES = os.environ.get("CUDA_VISIBLE_DEVICES", "")
if ORIGINAL_CUDA_VISIBLE_DEVICES.startswith("GPU-"):
    os.environ["ORIGINAL_CUDA_VISIBLE_DEVICES"] = ORIGINAL_CUDA_VISIBLE_DEVICES
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import argparse
import csv
import gc
import hashlib
import json
import threading
import time
from collections import Counter
from pathlib import Path

import esm
import torch
from esm import FastaBatchedDataset
from torch.utils.data import DataLoader


ROOT = Path("/scratch/users/ntu/pan.jie/work/BGCdataset")

DEFAULT_FASTA = ROOT / "dataset/corrected_BGC_nonBGC_protein.fasta"

DEFAULT_OUT = ROOT / "ESM2_BGC"

MODEL_NAME = "esm2_t33_650M_UR50D"
LAYER = 33
DIM = 1280
MAX_AA = 1022
POOLING = "official_mean_residue_representations"
OFFICIAL_BATCH_TOKENS = 4096

SCRIPT_VERSION = "2026-09-15-esm2-bgc-v1"


def parse_args():
    p = argparse.ArgumentParser()

    p.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_FASTA,
    )

    p.add_argument(
        "--out",
        type=Path,
        default=DEFAULT_OUT,
    )

    p.add_argument(
        "--toks-per-batch",
        type=int,
        default=0,
        help="0 = auto A100 token budget",
    )

    p.add_argument(
        "--workers",
        type=int,
        default=4,
    )

    p.add_argument(
        "--log-interval",
        type=int,
        default=30,
    )

    p.add_argument(
        "--disable-tf32",
        action="store_true",
    )

    p.add_argument(
        "--overwrite",
        action="store_true",
    )

    return p.parse_args()


class Heartbeat:
    def __init__(self, interval):
        self.interval = max(5, int(interval))
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.phase = "startup"
        self.done = 0
        self.total = 0
        self.note = ""
        self.started = time.time()

    def update(
        self,
        phase=None,
        done=None,
        total=None,
        note=None,
    ):
        with self.lock:
            if phase is not None:
                self.phase = str(phase)
            if done is not None:
                self.done = int(done)
            if total is not None:
                self.total = int(total)
            if note is not None:
                self.note = str(note)

    def emit(self):
        with self.lock:
            phase = self.phase
            done = self.done
            total = self.total
            note = self.note
            started = self.started

        elapsed = max(time.time() - started, 1e-9)

        if total > 0:
            pct = 100.0 * done / total
            rate = done / elapsed
            progress = (
                f"{done:,}/{total:,} "
                f"({pct:.2f}%) | "
                f"{rate:.1f} seq/s"
            )
        else:
            progress = "progress=NA"

        try:
            alloc = torch.cuda.memory_allocated(0) / (1024 ** 3)
            reserved = torch.cuda.memory_reserved(0) / (1024 ** 3)
            gpu = (
                f"GPU_alloc={alloc:.2f}GB | "
                f"GPU_reserved={reserved:.2f}GB"
            )
        except Exception:
            gpu = "GPU_mem=NA"

        print(
            f"[HEARTBEAT] "
            f"{time.strftime('%Y-%m-%d %H:%M:%S')} | "
            f"phase={phase} | "
            f"{progress} | "
            f"{gpu}"
            f"{' | ' + note if note else ''}",
            flush=True,
        )

    def loop(self):
        while not self.stop_event.wait(self.interval):
            self.emit()

    def start(self):
        self.started = time.time()
        self.thread = threading.Thread(
            target=self.loop,
            daemon=True,
        )
        self.thread.start()
        self.emit()

    def stop(self):
        self.stop_event.set()

        if self.thread is not None:
            self.thread.join(timeout=5)

        self.emit()


def sha_ids(ids):
    h = hashlib.sha256()

    for seq_id in ids:
        h.update(seq_id.encode("utf-8"))
        h.update(b"\0")

    return h.hexdigest()


def atomic_json(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open("w", encoding="utf-8") as f:
        json.dump(
            obj,
            f,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(tmp, path)


def safe_save(obj, path):
    tmp = path.with_suffix(path.suffix + ".tmp")

    if tmp.exists():
        tmp.unlink()

    torch.save(obj, tmp)

    if (
        not tmp.is_file()
        or tmp.stat().st_size <= 0
    ):
        raise RuntimeError(
            f"Invalid temporary PT: {tmp}"
        )

    os.replace(tmp, path)


def load_model(device):
    print(
        "\n===== LOAD OFFICIAL ESM-2 =====",
        flush=True,
    )

    model, alphabet = (
        esm.pretrained
        .esm2_t33_650M_UR50D()
    )

    model = model.to(device).eval()

    if int(model.num_layers) != LAYER:
        raise RuntimeError(
            f"Unexpected num_layers: {model.num_layers}"
        )

    if int(model.embed_dim) != DIM:
        raise RuntimeError(
            f"Unexpected embed_dim: {model.embed_dim}"
        )

    print(f"Model       : {MODEL_NAME}", flush=True)
    print(f"Layer       : {LAYER}", flush=True)
    print(f"Dimension   : {DIM}", flush=True)
    print(f"Max AA      : {MAX_AA}", flush=True)
    print(
        "Pooling     : residue mean; BOS/EOS excluded",
        flush=True,
    )

    return model, alphabet


def normalize_for_esm(
    dataset,
    alphabet,
    audit_csv,
    hb,
):
    supported = {
        tok
        for tok in alphabet.standard_toks
        if len(tok) == 1
    }

    if "X" not in supported:
        raise RuntimeError(
            "Official ESM alphabet lacks X."
        )

    total = len(dataset.sequence_strs)

    hb.update(
        phase="residue_preflight",
        done=0,
        total=total,
        note="unsupported residue -> X",
    )

    rows = []
    counts = Counter()
    normalized_seq = 0
    normalized_res = 0
    new_sequences = []

    for i, (
        header,
        raw,
    ) in enumerate(
        zip(
            dataset.sequence_labels,
            dataset.sequence_strs,
        ),
        start=1,
    ):
        seq_id = header.split()[0]
        seq = raw.upper()
        chars = list(seq)

        bad_pos = []
        bad_chars = []

        for j, residue in enumerate(chars):
            if residue not in supported:
                bad_pos.append(j + 1)
                bad_chars.append(residue)
                counts[residue] += 1
                chars[j] = "X"

        new_seq = "".join(chars)

        if len(new_seq) != len(seq):
            raise RuntimeError(
                f"Length changed: {seq_id}"
            )

        if bad_pos:
            normalized_seq += 1
            normalized_res += len(bad_pos)

            rows.append(
                {
                    "id":
                        seq_id,
                    "sequence_length_aa":
                        len(seq),
                    "unsupported_symbols":
                        ";".join(
                            sorted(set(bad_chars))
                        ),
                    "unsupported_residue_count":
                        len(bad_pos),
                    "positions_1based":
                        ";".join(
                            str(x)
                            for x in bad_pos
                        ),
                    "normalization":
                        "unsupported_ESM2_residue_to_X",
                }
            )

        remaining = set(new_seq) - supported

        if remaining:
            raise RuntimeError(
                f"Unsupported residues remain "
                f"for {seq_id}: {sorted(remaining)}"
            )

        new_sequences.append(new_seq)

        if (
            i % 5000 == 0
            or i == total
        ):
            hb.update(
                phase="residue_preflight",
                done=i,
                total=total,
                note=(
                    f"normalized_seq={normalized_seq:,}; "
                    f"normalized_res={normalized_res:,}"
                ),
            )

            print(
                f"[PRECHECK] {i:,}/{total:,} | "
                f"normalized_seq={normalized_seq:,} | "
                f"normalized_res={normalized_res:,}",
                flush=True,
            )

    dataset.sequence_strs = new_sequences

    fields = [
        "id",
        "sequence_length_aa",
        "unsupported_symbols",
        "unsupported_residue_count",
        "positions_1based",
        "normalization",
    ]

    tmp = audit_csv.with_suffix(
        audit_csv.suffix + ".tmp"
    )

    with tmp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as f:
        writer = csv.DictWriter(
            f,
            fieldnames=fields,
        )

        writer.writeheader()

        if rows:
            writer.writerows(rows)

    os.replace(tmp, audit_csv)

    return {
        "supported_tokens":
            "".join(sorted(supported)),
        "normalized_sequence_count":
            normalized_seq,
        "normalized_residue_count":
            normalized_res,
        "unsupported_symbol_counts":
            dict(sorted(counts.items())),
        "audit_csv":
            str(audit_csv),
    }


def auto_budget(
    device,
    user_value,
):
    if user_value > 0:
        return user_value

    gb = (
        torch.cuda.get_device_properties(
            device
        ).total_memory
        / (1024 ** 3)
    )

    # Full-length sequences: conservative enough for up to 1022 aa,
    # but substantially larger than official CLI default.
    if gb >= 75:
        return 32768

    if gb >= 39:
        return 16384

    if gb >= 23:
        return 8192

    return 4096


def make_loader(
    dataset,
    alphabet,
    budget,
    workers,
):
    batches = dataset.get_batch_indices(
        budget,
        extra_toks_per_seq=1,
    )

    kwargs = {
        "dataset":
            dataset,
        "collate_fn":
            alphabet.get_batch_converter(
                MAX_AA
            ),
        "batch_sampler":
            batches,
        "num_workers":
            workers,
        "pin_memory":
            True,
    }

    if workers > 0:
        kwargs[
            "persistent_workers"
        ] = True
        kwargs[
            "prefetch_factor"
        ] = 4

    return (
        batches,
        DataLoader(**kwargs),
    )


def extract_once(
    dataset,
    model,
    alphabet,
    device,
    budget,
    workers,
    hb,
):
    batches, loader = make_loader(
        dataset,
        alphabet,
        budget,
        workers,
    )

    headers = list(
        dataset.sequence_labels
    )

    ids = [
        x.split()[0]
        for x in headers
    ]

    seqs = list(
        dataset.sequence_strs
    )

    if len(ids) != len(set(ids)):
        raise RuntimeError(
            "Duplicate protein FASTA IDs."
        )

    header_to_index = {
        h: i
        for i, h
        in enumerate(headers)
    }

    original_lengths = torch.tensor(
        [
            len(x)
            for x in seqs
        ],
        dtype=torch.long,
    )

    model_lengths = torch.clamp(
        original_lengths,
        max=MAX_AA,
    )

    embeddings = torch.empty(
        (
            len(ids),
            DIM,
        ),
        dtype=torch.float32,
        device="cpu",
    )

    written = torch.zeros(
        len(ids),
        dtype=torch.bool,
    )

    processed = 0
    started = time.time()

    hb.update(
        phase="esm2_gpu_inference",
        done=0,
        total=len(ids),
        note=(
            f"token_budget={budget:,}; "
            f"batches={len(batches):,}"
        ),
    )

    with torch.inference_mode():

        for batch_no, (
            batch_headers,
            batch_seqs,
            toks,
        ) in enumerate(
            loader,
            start=1,
        ):
            toks = toks.to(
                device,
                non_blocking=True,
            )

            out = model(
                toks,
                repr_layers=[LAYER],
                return_contacts=False,
            )

            reps = (
                out[
                    "representations"
                ][
                    LAYER
                ]
                .cpu()
            )

            for bi, header in enumerate(
                batch_headers
            ):
                out_idx = (
                    header_to_index[
                        header
                    ]
                )

                length = min(
                    MAX_AA,
                    len(
                        batch_seqs[
                            bi
                        ]
                    ),
                )

                # Official scripts/extract.py --include mean:
                embeddings[
                    out_idx
                ] = (
                    reps[
                        bi,
                        1:
                        length + 1,
                    ]
                    .mean(0)
                    .clone()
                    .float()
                )

                written[
                    out_idx
                ] = True

            processed += len(
                batch_headers
            )

            hb.update(
                phase="esm2_gpu_inference",
                done=processed,
                total=len(ids),
                note=(
                    f"batch={batch_no:,}/"
                    f"{len(batches):,}; "
                    f"token_budget={budget:,}"
                ),
            )

            if (
                batch_no == 1
                or batch_no % 20 == 0
                or batch_no == len(batches)
            ):
                elapsed = max(
                    time.time() - started,
                    1e-9,
                )

                print(
                    f"[PROGRESS] "
                    f"batch={batch_no:,}/"
                    f"{len(batches):,} | "
                    f"seq={processed:,}/"
                    f"{len(ids):,} | "
                    f"{100.0*processed/len(ids):.2f}% | "
                    f"{processed/elapsed:.1f} seq/s | "
                    f"GPU_alloc="
                    f"{torch.cuda.memory_allocated(0)/(1024**3):.2f}GB | "
                    f"GPU_reserved="
                    f"{torch.cuda.memory_reserved(0)/(1024**3):.2f}GB",
                    flush=True,
                )

            del toks
            del out
            del reps

    if not bool(written.all()):
        raise RuntimeError(
            f"Missing embeddings: "
            f"{int((~written).sum().item())}"
        )

    return {
        "ids":
            ids,
        "original_lengths":
            original_lengths,
        "model_lengths":
            model_lengths,
        "embeddings":
            embeddings,
        "batches":
            len(batches),
        "budget":
            budget,
    }


def extract_with_backoff(
    dataset,
    model,
    alphabet,
    device,
    initial_budget,
    workers,
    hb,
):
    budget = initial_budget

    while True:
        try:
            print(
                f"\nTrying ESM-2 token budget: "
                f"{budget:,}",
                flush=True,
            )

            return extract_once(
                dataset,
                model,
                alphabet,
                device,
                budget,
                workers,
                hb,
            )

        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            gc.collect()

            if budget <= OFFICIAL_BATCH_TOKENS:
                raise RuntimeError(
                    "CUDA OOM at official 4096 "
                    "token budget. CPU fallback disabled."
                )

            new_budget = max(
                OFFICIAL_BATCH_TOKENS,
                budget // 2,
            )

            print(
                f"[CUDA OOM] "
                f"{budget:,} -> "
                f"{new_budget:,} tokens/batch",
                flush=True,
            )

            hb.update(
                phase="OOM_retry",
                note=(
                    f"{budget:,} -> "
                    f"{new_budget:,}"
                ),
            )

            budget = new_budget


def valid_existing(
    pt,
    complete,
    ids,
    digest,
):
    if (
        not pt.is_file()
        or not complete.is_file()
    ):
        return False

    try:
        with complete.open(
            "r",
            encoding="utf-8",
        ) as f:
            x = json.load(f)

        return (
            x.get("status")
            == "COMPLETED"
            and x.get("model_name")
            == MODEL_NAME
            and x.get("pooling")
            == POOLING
            and int(
                x.get(
                    "num_sequences",
                    -1,
                )
            )
            == len(ids)
            and x.get("id_sha256")
            == digest
            and int(
                x.get(
                    "output_size_bytes",
                    -1,
                )
            )
            == pt.stat().st_size
        )

    except Exception:
        return False


def main():
    args = parse_args()

    input_fasta = (
        args.input
        .expanduser()
        .resolve()
    )

    out_dir = (
        args.out
        .expanduser()
        .resolve()
    )

    if not input_fasta.is_file():
        raise FileNotFoundError(
            input_fasta
        )

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA unavailable. CPU fallback disabled."
        )

    torch.cuda.set_device(0)
    device = torch.device("cuda:0")

    tf32 = not args.disable_tf32

    torch.backends.cuda.matmul.allow_tf32 = (
        tf32
    )

    if hasattr(
        torch,
        "set_float32_matmul_precision"
    ):
        torch.set_float32_matmul_precision(
            "high"
            if tf32
            else "highest"
        )

    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_pt = (
        out_dir
        / "BGC_nonBGC_esm2_mean.pt"
    )

    complete_json = (
        out_dir
        / "BGC_nonBGC_esm2_mean.complete.json"
    )

    summary_json = (
        out_dir
        / "summary.json"
    )

    audit_csv = (
        out_dir
        / "residue_audit.csv"
    )

    print(
        "=" * 100,
        flush=True,
    )

    print(
        "BGC/NONBGC OFFICIAL ESM-2 MEAN",
        flush=True,
    )

    print(
        "=" * 100,
        flush=True,
    )

    print(
        f"Input    : {input_fasta}",
        flush=True,
    )

    print(
        f"Output   : {out_dir}",
        flush=True,
    )

    print(
        f"GPU      : "
        f"{torch.cuda.get_device_name(0)}",
        flush=True,
    )

    print(
        f"TF32     : {tf32}",
        flush=True,
    )

    print(
        f"Heartbeat: "
        f"{args.log_interval}s",
        flush=True,
    )

    hb = Heartbeat(
        args.log_interval
    )

    hb.start()

    try:
        hb.update(
            phase="loading_fasta",
            note=str(
                input_fasta
            ),
        )

        dataset = (
            FastaBatchedDataset
            .from_file(
                input_fasta
            )
        )

        ids = [
            label.split()[0]
            for label
            in dataset.sequence_labels
        ]

        if not ids:
            raise RuntimeError(
                "No FASTA records."
            )

        if len(ids) != len(set(ids)):
            raise RuntimeError(
                "Duplicate FASTA IDs."
            )

        digest = sha_ids(ids)

        print(
            f"Records  : {len(ids):,}",
            flush=True,
        )

        if (
            not args.overwrite
            and valid_existing(
                output_pt,
                complete_json,
                ids,
                digest,
            )
        ):
            print(
                f"[SKIP] valid output exists: "
                f"{output_pt}",
                flush=True,
            )

            hb.update(
                phase="completed_existing",
                done=len(ids),
                total=len(ids),
            )

            return

        hb.update(
            phase="loading_model",
            done=0,
            total=len(ids),
        )

        model, alphabet = load_model(
            device
        )

        norm = normalize_for_esm(
            dataset,
            alphabet,
            audit_csv,
            hb,
        )

        print(
            "\n===== RESIDUE AUDIT =====",
            flush=True,
        )

        print(
            f"Normalized sequences : "
            f"{norm['normalized_sequence_count']:,}",
            flush=True,
        )

        print(
            f"Normalized residues  : "
            f"{norm['normalized_residue_count']:,}",
            flush=True,
        )

        print(
            f"Unsupported symbols  : "
            f"{norm['unsupported_symbol_counts']}",
            flush=True,
        )

        budget = auto_budget(
            device,
            args.toks_per_batch,
        )

        print(
            "\n===== A100 SETTINGS =====",
            flush=True,
        )

        print(
            f"Official CLI default : "
            f"{OFFICIAL_BATCH_TOKENS:,}",
            flush=True,
        )

        print(
            f"Initial token budget : "
            f"{budget:,}",
            flush=True,
        )

        started = time.time()

        result = extract_with_backoff(
            dataset,
            model,
            alphabet,
            device,
            budget,
            args.workers,
            hb,
        )

        if result["ids"] != ids:
            raise RuntimeError(
                "Output ID order changed."
            )

        original_lengths = (
            result[
                "original_lengths"
            ]
        )

        model_lengths = (
            result[
                "model_lengths"
            ]
        )

        was_truncated = (
            original_lengths
            > MAX_AA
        )

        hb.update(
            phase="saving_pt",
            done=len(ids),
            total=len(ids),
            note=str(output_pt),
        )

        save_obj = {
            "ids":
                ids,
            "embeddings":
                result[
                    "embeddings"
                ],
            "original_sequence_lengths":
                original_lengths,
            "model_input_lengths":
                model_lengths,
            "was_truncated":
                was_truncated,
            "source_protein_fasta":
                str(
                    input_fasta
                ),
            "model_name":
                MODEL_NAME,
            "representation_layer":
                LAYER,
            "embedding_dimension":
                DIM,
            "embedding_dtype":
                "float32",
            "truncation_sequence_length":
                MAX_AA,
            "pooling":
                POOLING,
            "special_tokens_in_pooling":
                False,
            "official_mean_formula":
                (
                    "representations"
                    "[i,1:truncate_len+1]"
                    ".mean(0)"
                ),
            "input_normalization":
                (
                    "unsupported residues "
                    "mapped to official X"
                ),
            "normalized_sequence_count":
                norm[
                    "normalized_sequence_count"
                ],
            "normalized_residue_count":
                norm[
                    "normalized_residue_count"
                ],
            "unsupported_symbol_counts":
                norm[
                    "unsupported_symbol_counts"
                ],
            "num_sequences":
                len(ids),
            "BGC_nonBGC_ratio":
                "1:1",
            "TF32_enabled":
                tf32,
            "toks_per_batch":
                result[
                    "budget"
                ],
            "id_sha256":
                digest,
            "script_version":
                SCRIPT_VERSION,
        }

        safe_save(
            save_obj,
            output_pt,
        )

        elapsed = (
            time.time()
            - started
        ) / 60.0

        summary = {
            "status":
                "COMPLETED",
            "input_fasta":
                str(
                    input_fasta
                ),
            "output_pt":
                str(
                    output_pt
                ),
            "num_sequences":
                len(ids),
            "model_name":
                MODEL_NAME,
            "representation_layer":
                LAYER,
            "embedding_dimension":
                DIM,
            "pooling":
                POOLING,
            "minimum_original_aa_length":
                int(
                    original_lengths
                    .min()
                    .item()
                ),
            "maximum_original_aa_length":
                int(
                    original_lengths
                    .max()
                    .item()
                ),
            "records_longer_than_1022":
                int(
                    was_truncated
                    .sum()
                    .item()
                ),
            "normalized_sequence_count":
                norm[
                    "normalized_sequence_count"
                ],
            "normalized_residue_count":
                norm[
                    "normalized_residue_count"
                ],
            "unsupported_symbol_counts":
                norm[
                    "unsupported_symbol_counts"
                ],
            "residue_audit_csv":
                str(
                    audit_csv
                ),
            "used_token_budget":
                result[
                    "budget"
                ],
            "number_of_batches":
                result[
                    "batches"
                ],
            "TF32_enabled":
                tf32,
            "elapsed_minutes":
                round(
                    elapsed,
                    4,
                ),
            "output_size_bytes":
                output_pt
                .stat()
                .st_size,
            "id_sha256":
                digest,
        }

        completion = {
            "status":
                "COMPLETED",
            "model_name":
                MODEL_NAME,
            "pooling":
                POOLING,
            "num_sequences":
                len(ids),
            "id_sha256":
                digest,
            "output_size_bytes":
                output_pt
                .stat()
                .st_size,
        }

        atomic_json(
            summary_json,
            summary,
        )

        atomic_json(
            complete_json,
            completion,
        )

        hb.update(
            phase="COMPLETED",
            done=len(ids),
            total=len(ids),
            note=(
                f"elapsed="
                f"{elapsed:.2f} min"
            ),
        )

        print(
            "\n"
            + "=" * 100,
            flush=True,
        )

        print(
            "COMPLETED",
            flush=True,
        )

        print(
            "=" * 100,
            flush=True,
        )

        for k, v in summary.items():
            print(
                f"{k:36s}: {v}",
                flush=True,
            )

    finally:
        hb.stop()


if __name__ == "__main__":
    main()
