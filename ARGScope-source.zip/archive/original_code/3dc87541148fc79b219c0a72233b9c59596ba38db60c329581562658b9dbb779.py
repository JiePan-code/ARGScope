"""Local right-click launcher for the authoritative-split Full gated fusion."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ablation_runtime import (
    add_default_structure,
    data_root_from_launcher,
    load_base,
    reject_overwrite_argument,
    set_fusion_defaults,
)

DATA = data_root_from_launcher(__file__)
m = load_base("01_gated_fusion.py", "fusion_full_local_base")
set_fusion_defaults(
    m,
    DATA,
    "Long_fusion_subtype2_newsplit",
    "long_fusion_subtype2_newsplit.pt",
)
reject_overwrite_argument()
add_default_structure(DATA)
m.main()
