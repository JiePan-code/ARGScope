#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DNA Student grid-search visualization.

Place this script directly inside:

    1.DNA_student_long_gridsearch/

Expected files:
    grid_stage1_81_results.csv
    grid_stage2_27_results.csv
    grid_robustness_top3_x3_runs.csv
    grid_robustness_top3_summary.csv
    best_parameters_and_test_results.csv

Outputs:
    DNA_grid_figures/
        DNA_ALL_PARAMETER_RESULTS.csv

        Figure1_DNA_tradeoff.png
        Figure1_DNA_tradeoff.pdf

        Figure2_DNA_stage1_interaction.png
        Figure2_DNA_stage1_interaction.pdf

        Figure3_DNA_hyperparameter_sensitivity.png
        Figure3_DNA_hyperparameter_sensitivity.pdf

        Figure4_DNA_stage2_interaction.png
        Figure4_DNA_stage2_interaction.pdf

        Figure5_DNA_top3_robustness.png
        Figure5_DNA_top3_robustness.pdf

        Figure6_DNA_binary_threshold_selection.png
        Figure6_DNA_binary_threshold_selection.pdf

        DNA_top5_primary_search.csv
        DNA_pareto_front.csv
        DNA_hyperparameter_sensitivity_summary.csv

Balance score:
    0.5 * Validation end-to-end Accuracy
  + 0.5 * Validation end-to-end Weighted Precision

The script is written to tolerate small column-name differences between
grid-search CSV versions. It automatically detects metric and parameter
columns from aliases.
"""

from __future__ import annotations

from pathlib import Path
import math
import warnings

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


# =============================================================================
# Paths
# =============================================================================

ROOT = Path(__file__).resolve().parent

STAGE1_FILE = (
    ROOT
    / "grid_stage1_81_results.csv"
)

STAGE2_FILE = (
    ROOT
    / "grid_stage2_27_results.csv"
)

ROBUST_FILE = (
    ROOT
    / "grid_robustness_top3_x3_runs.csv"
)

ROBUST_SUMMARY_FILE = (
    ROOT
    / "grid_robustness_top3_summary.csv"
)

BEST_FILE = (
    ROOT
    / "best_parameters_and_test_results.csv"
)

THRESHOLD_FILE = (
    ROOT
    / "best_binary_threshold_validation_sweep.csv"
)

OUTPUT_DIR = (
    ROOT
    / "DNA_grid_figures"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

COMBINED_FILE = (
    OUTPUT_DIR
    / "DNA_ALL_PARAMETER_RESULTS.csv"
)

DPI = 350

# Number of high-performing configurations connected in Figure 1.
TRADEOFF_PATH_N = 4


# =============================================================================
# Aliases
# =============================================================================

METRIC_ALIASES = {
    "accuracy": [
        "val_end_accuracy",
        "validation_end_accuracy",
        "val_accuracy",
        "validation_accuracy",
        "val_acc",
        "validation_acc",
        "end_to_end_accuracy",
        "accuracy",
        "ACC",
    ],

    "weighted_precision": [
        "val_end_weighted_precision",
        "validation_end_weighted_precision",
        "val_weighted_precision",
        "validation_weighted_precision",
        "weighted_precision",
        "Precision_weighted",
        "precision_weighted",
    ],
}

STAGE1_PARAMETER_ALIASES = {
    "student_lr": [
        "student_lr",
        "lr",
        "learning_rate",
        "student_learning_rate",
    ],

    "dropout": [
        "dropout",
        "student_dropout",
    ],

    "class_weight_power": [
        "class_weight_power",
        "class_weight",
        "class_weight_exp",
        "class_weight_exponent",
        "supcon_weight",
        "supervised_contrastive_weight",
    ],

    "prototype_align": [
        "student_prototype_align",
        "prototype_align",
        "prototype_align_weight",
        "refined_weight",
        "refined_prototype_weight",
    ],
}

STAGE2_PARAMETER_ALIASES = {
    "subtype_ce": [
        "student_subtype_ce",
        "subtype_ce",
        "subtype_ce_weight",
        "subtype_weight",
    ],

    "binary_kd": [
        "student_binary_kd",
        "binary_kd",
        "binary_kd_weight",
        "same_view_kd",
        "same_view_kd_weight",
    ],

    "feature_align": [
        "student_feature_align",
        "feature_align",
        "feature_align_weight",
        "parent_kd",
        "parent_kd_weight",
    ],
}

ROBUST_PARAMETER_ALIASES = {
    "candidate_rank": [
        "candidate_rank",
        "rank",
        "top_rank",
        "top3_rank",
    ],
}


# =============================================================================
# Generic helpers
# =============================================================================

def normalize_name(text):
    return (
        str(text)
        .strip()
        .lower()
        .replace("-", "_")
        .replace(" ", "_")
        .replace(".", "_")
    )


def find_column(
    dataframe,
    aliases,
    required=False,
):
    normalized = {
        normalize_name(column):
            column
        for column
        in dataframe.columns
    }

    for alias in aliases:
        key = normalize_name(
            alias
        )

        if key in normalized:
            return normalized[
                key
            ]

    # relaxed contains search
    for alias in aliases:
        key = normalize_name(
            alias
        )

        for normalized_column, original_column in normalized.items():
            if (
                key
                in normalized_column
            ):
                return original_column

    if required:
        raise KeyError(
            "Cannot find any of these columns:\n"
            + "\n".join(
                aliases
            )
            + "\n\nAvailable columns:\n"
            + "\n".join(
                map(
                    str,
                    dataframe.columns,
                )
            )
        )

    return None


def numeric_series(
    dataframe,
    column,
):
    return pd.to_numeric(
        dataframe[
            column
        ],
        errors="coerce",
    )


def read_csv(
    path,
):
    if not path.is_file():
        raise FileNotFoundError(
            path
        )

    return pd.read_csv(
        path,
        encoding="utf-8-sig",
    )


def fmt_value(
    value,
):
    if pd.isna(
        value
    ):
        return "NA"

    if isinstance(
        value,
        str,
    ):
        return (
            value
            .replace(
                "_",
                "\n",
            )
        )

    value = float(
        value
    )

    if (
        value != 0
        and abs(
            value
        )
        < 0.001
    ):
        return f"{value:.0e}"

    if float(
        value
    ).is_integer():
        return str(
            int(
                value
            )
        )

    return f"{value:g}"


def save_figure(
    figure,
    stem,
):
    png = (
        OUTPUT_DIR
        / f"{stem}.png"
    )

    pdf = (
        OUTPUT_DIR
        / f"{stem}.pdf"
    )

    figure.savefig(
        png,
        dpi=DPI,
        bbox_inches="tight",
    )

    figure.savefig(
        pdf,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )

    print(
        f"Saved: {png}"
    )

    print(
        f"Saved: {pdf}"
    )


def pareto_front(
    dataframe,
    x_column,
    y_column,
):
    work = (
        dataframe
        .dropna(
            subset=[
                x_column,
                y_column,
            ]
        )
        .sort_values(
            [
                x_column,
                y_column,
            ],
            ascending=[
                False,
                False,
            ],
        )
    )

    selected = []

    best_y = -np.inf

    for index, row in work.iterrows():
        y = float(
            row[
                y_column
            ]
        )

        if y > best_y:
            selected.append(
                index
            )

            best_y = y

    return (
        work
        .loc[
            selected
        ]
        .sort_values(
            x_column
        )
        .copy()
    )


def jitter(
    center,
    n,
    rng,
    width=0.065,
):
    if n <= 1:
        return np.asarray(
            [
                center
            ]
        )

    return (
        center
        + rng.uniform(
            -width,
            width,
            size=n,
        )
    )


# =============================================================================
# Convert each grid file to one standard table
# =============================================================================

def standardize_stage(
    dataframe,
    stage_name,
    parameter_aliases,
):
    dataframe = dataframe.copy()

    accuracy_column = find_column(
        dataframe,
        METRIC_ALIASES[
            "accuracy"
        ],
        required=True,
    )

    precision_column = find_column(
        dataframe,
        METRIC_ALIASES[
            "weighted_precision"
        ],
        required=True,
    )

    result = pd.DataFrame()

    result[
        "stage"
    ] = [
        stage_name
    ] * len(
        dataframe
    )

    # Keep original row number as a stable run identifier.
    combo_column = find_column(
        dataframe,
        [
            "combo_id",
            "run_id",
            "configuration_id",
            "config_id",
            "trial",
            "trial_id",
        ],
        required=False,
    )

    if combo_column is None:
        result[
            "combo_id"
        ] = (
            np.arange(
                len(
                    dataframe
                )
            )
            + 1
        )

    else:
        result[
            "combo_id"
        ] = dataframe[
            combo_column
        ]

    result[
        "val_end_accuracy"
    ] = numeric_series(
        dataframe,
        accuracy_column,
    )

    result[
        "val_end_weighted_precision"
    ] = numeric_series(
        dataframe,
        precision_column,
    )

    result[
        "balance_score"
    ] = (
        0.5
        * result[
            "val_end_accuracy"
        ]
        +
        0.5
        * result[
            "val_end_weighted_precision"
        ]
    )

    for standard_name, aliases in parameter_aliases.items():
        source_column = find_column(
            dataframe,
            aliases,
            required=False,
        )

        if source_column is None:
            result[
                standard_name
            ] = np.nan

        else:
            result[
                standard_name
            ] = dataframe[
                source_column
            ]

    # Preserve all original columns using an "original_" prefix.
    for column in dataframe.columns:
        output_column = (
            f"original_{column}"
        )

        if output_column not in result.columns:
            result[
                output_column
            ] = dataframe[
                column
            ].values

    return result


def build_combined_table():

    stage1_raw = read_csv(
        STAGE1_FILE
    )

    stage2_raw = read_csv(
        STAGE2_FILE
    )

    robust_raw = read_csv(
        ROBUST_FILE
    )

    stage1 = standardize_stage(
        stage1_raw,
        "student_grid_81",
        STAGE1_PARAMETER_ALIASES,
    )

    stage2 = standardize_stage(
        stage2_raw,
        "student_grid_27",
        STAGE2_PARAMETER_ALIASES,
    )

    robustness = standardize_stage(
        robust_raw,
        "robustness",
        ROBUST_PARAMETER_ALIASES,
    )

    combined = pd.concat(
        [
            stage1,
            stage2,
            robustness,
        ],
        ignore_index=True,
        sort=False,
    )

    combined.to_csv(
        COMBINED_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print(
        "=" * 105
    )

    print(
        "DNA GRID SEARCH"
    )

    print(
        "=" * 105
    )

    print(
        f"Stage1 rows     : {len(stage1):,}"
    )

    print(
        f"Stage2 rows     : {len(stage2):,}"
    )

    print(
        f"Robustness rows : {len(robustness):,}"
    )

    print(
        f"Combined rows   : {len(combined):,}"
    )

    print(
        f"Combined CSV    : {COMBINED_FILE}"
    )

    print()

    print(
        "Detected Stage1 parameters:"
    )

    for parameter in STAGE1_PARAMETER_ALIASES:
        count = (
            stage1[
                parameter
            ]
            .dropna()
            .nunique()
        )

        print(
            f"  {parameter:22s}: "
            f"{count} levels"
        )

    print()

    print(
        "Detected Stage2 parameters:"
    )

    for parameter in STAGE2_PARAMETER_ALIASES:
        count = (
            stage2[
                parameter
            ]
            .dropna()
            .nunique()
        )

        print(
            f"  {parameter:22s}: "
            f"{count} levels"
        )

    print()

    return (
        combined,
        stage1,
        stage2,
        robustness,
    )


# =============================================================================
# Figure 1
# =============================================================================

def draw_figure1(
    combined,
):

    primary = combined[
        combined[
            "stage"
        ].isin(
            [
                "student_grid_81",
                "student_grid_27",
            ]
        )
    ].dropna(
        subset=[
            "val_end_accuracy",
            "val_end_weighted_precision",
        ]
    ).copy()

    primary[
        "ACC_percent"
    ] = (
        100
        * primary[
            "val_end_accuracy"
        ]
    )

    primary[
        "Precision_percent"
    ] = (
        100
        * primary[
            "val_end_weighted_precision"
        ]
    )

    primary[
        "Balance_percent"
    ] = (
        100
        * primary[
            "balance_score"
        ]
    )

    top5 = (
        primary
        .sort_values(
            "balance_score",
            ascending=False,
        )
        .head(
            5
        )
        .copy()
    )

    # Connect the top-N configurations by Balance score.
    # They are sorted by ACC before drawing so the dashed path reads
    # naturally from left to right.
    tradeoff_path = (
        primary
        .sort_values(
            "balance_score",
            ascending=False,
        )
        .head(
            TRADEOFF_PATH_N
        )
        .sort_values(
            "ACC_percent",
            ascending=True,
        )
        .copy()
    )

    best = (
        primary
        .sort_values(
            "balance_score",
            ascending=False,
        )
        .iloc[
            0
        ]
    )

    figure, axis = plt.subplots(
        figsize=(
            8.9,
            6.7,
        )
    )

    stage_styles = {
        "student_grid_81":
            {
                "marker":
                    "o",

                "label":
                    "Stage 1 (81)",
            },

        "student_grid_27":
            {
                "marker":
                    "^",

                "label":
                    "Stage 2 (27)",
            },
    }

    for stage, style in stage_styles.items():
        part = primary[
            primary[
                "stage"
            ]
            == stage
        ]

        axis.scatter(
            part[
                "ACC_percent"
            ],
            part[
                "Precision_percent"
            ],
            s=38,
            marker=style[
                "marker"
            ],
            alpha=0.76,
            label=style[
                "label"
            ],
        )

    if len(
        tradeoff_path
    ) > 1:
        axis.plot(
            tradeoff_path[
                "ACC_percent"
            ],
            tradeoff_path[
                "Precision_percent"
            ],
            linestyle="--",
            linewidth=1.35,
            color="black",
            marker="o",
            markersize=3.5,
            markerfacecolor="white",
            markeredgecolor="black",
            label=f"Top-{TRADEOFF_PATH_N} trade-off path",
            zorder=5,
        )

    axis.scatter(
        top5[
            "ACC_percent"
        ],
        top5[
            "Precision_percent"
        ],
        s=100,
        facecolors="none",
        edgecolors="black",
        linewidths=1.1,
        label="Top-5 screening",
        zorder=7,
    )

    axis.scatter(
        [
            best[
                "ACC_percent"
            ]
        ],
        [
            best[
                "Precision_percent"
            ]
        ],
        marker="*",
        s=155,
        color="black",
        label="Best configuration",
        zorder=9,
    )

    top5 = (
        top5
        .sort_values(
            "balance_score",
            ascending=False,
        )
        .reset_index(
            drop=True
        )
    )

    offsets = [
        (6, 8),
        (7, -14),
        (-34, 8),
        (7, 8),
        (-34, -13),
    ]

    for rank, row in top5.iterrows():
        axis.annotate(
            f"T{rank + 1}",
            xy=(
                row[
                    "ACC_percent"
                ],
                row[
                    "Precision_percent"
                ],
            ),
            xytext=offsets[
                rank
            ],
            textcoords="offset points",
            fontsize=8,
        )

    axis.set_xlabel(
        "Validation ACC (%)",
        fontsize=10,
    )

    axis.set_ylabel(
        "Validation weighted precision (%)",
        fontsize=10,
    )

    axis.set_title(
        "DNA grid search: accuracy–precision trade-off",
        fontsize=11.5,
        pad=9,
    )

    axis.grid(
        alpha=0.13,
        linewidth=0.5,
    )

    axis.legend(
        frameon=False,
        fontsize=8,
        loc="best",
    )

    figure.tight_layout()

    save_figure(
        figure,
        "Figure1_DNA_tradeoff",
    )

    top5.to_csv(
        OUTPUT_DIR
        / "DNA_top5_primary_search.csv",
        index=False,
        encoding="utf-8-sig",
    )

    tradeoff_path.to_csv(
        OUTPUT_DIR
        / f"DNA_top{TRADEOFF_PATH_N}_tradeoff_path.csv",
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# Figure 2
# =============================================================================

def draw_figure2(
    stage1,
):

    parameter_names = [
        parameter
        for parameter
        in STAGE1_PARAMETER_ALIASES
        if (
            parameter
            in stage1.columns
            and stage1[
                parameter
            ]
            .dropna()
            .nunique()
            >= 2
        )
    ]

    if len(
        parameter_names
    ) < 4:
        raise ValueError(
            "Stage1 does not expose four detected parameters.\n"
            f"Detected: {parameter_names}\n\n"
            "Check the printed columns and extend STAGE1_PARAMETER_ALIASES "
            "if your CSV uses different names."
        )

    p1, p2, p3, p4 = (
        parameter_names[
            :4
        ]
    )

    values1 = sorted(
        stage1[
            p1
        ].dropna().unique()
    )

    values2 = sorted(
        stage1[
            p2
        ].dropna().unique()
    )

    values3 = sorted(
        stage1[
            p3
        ].dropna().unique()
    )

    values4 = sorted(
        stage1[
            p4
        ].dropna().unique()
    )

    # Stage1 is expected to be 3 x 3 x 3 x 3.
    if not (
        len(
            values1
        )
        == 3
        and len(
            values2
        )
        == 3
        and len(
            values3
        )
        == 3
        and len(
            values4
        )
        == 3
    ):
        raise ValueError(
            "Stage1 is expected to be a 3x3x3x3 grid.\n"
            f"{p1}: {values1}\n"
            f"{p2}: {values2}\n"
            f"{p3}: {values3}\n"
            f"{p4}: {values4}"
        )

    plot_data = stage1.dropna(
        subset=[
            p1,
            p2,
            p3,
            p4,
            "balance_score",
        ]
    ).copy()

    plot_data[
        "Balance_percent"
    ] = (
        100
        * plot_data[
            "balance_score"
        ]
    )

    vmin = float(
        plot_data[
            "Balance_percent"
        ].min()
    )

    vmax = float(
        plot_data[
            "Balance_percent"
        ].max()
    )

    figure, axes = plt.subplots(
        3,
        3,
        figsize=(
            11.5,
            9.5,
        ),
        sharex=True,
        sharey=True,
    )

    mappable = None

    for row_index, value1 in enumerate(
        values1
    ):
        for column_index, value2 in enumerate(
            values2
        ):
            axis = axes[
                row_index,
                column_index
            ]

            panel = plot_data[
                np.isclose(
                    pd.to_numeric(
                        plot_data[
                            p1
                        ],
                        errors="coerce",
                    ),
                    float(
                        value1
                    ),
                )
                &
                np.isclose(
                    pd.to_numeric(
                        plot_data[
                            p2
                        ],
                        errors="coerce",
                    ),
                    float(
                        value2
                    ),
                )
            ]

            mappable = axis.scatter(
                panel[
                    p3
                ],
                panel[
                    p4
                ],
                c=panel[
                    "Balance_percent"
                ],
                s=105,
                vmin=vmin,
                vmax=vmax,
            )

            best_index = panel[
                "balance_score"
            ].idxmax()

            best = panel.loc[
                best_index
            ]

            axis.scatter(
                [
                    best[
                        p3
                    ]
                ],
                [
                    best[
                        p4
                    ]
                ],
                marker="*",
                s=120,
                facecolors="none",
                edgecolors="black",
                linewidths=1.1,
            )

            axis.set_title(
                (
                    f"{p1}={fmt_value(value1)}\n"
                    f"{p2}={fmt_value(value2)}"
                ),
                fontsize=8.5,
            )

            axis.set_xticks(
                values3
            )

            axis.set_yticks(
                values4
            )

            axis.grid(
                alpha=0.14,
                linewidth=0.5,
            )

            if row_index == 2:
                axis.set_xlabel(
                    p3.replace(
                        "_",
                        " ",
                    ),
                    fontsize=8.5,
                )

            if column_index == 0:
                axis.set_ylabel(
                    p4.replace(
                        "_",
                        " ",
                    ),
                    fontsize=8.5,
                )

    figure.subplots_adjust(
        left=0.08,
        right=0.87,
        bottom=0.08,
        top=0.91,
        wspace=0.18,
        hspace=0.27,
    )

    colorbar_axis = figure.add_axes(
        [
            0.90,
            0.18,
            0.02,
            0.60,
        ]
    )

    colorbar = figure.colorbar(
        mappable,
        cax=colorbar_axis,
    )

    colorbar.set_label(
        "Balance score (%)",
        fontsize=9,
    )

    figure.suptitle(
        "DNA Student Stage-1 hyperparameter interaction",
        fontsize=12,
        y=0.98,
    )

    save_figure(
        figure,
        "Figure2_DNA_stage1_interaction",
    )


# =============================================================================
# Figure 3
# =============================================================================

def parameter_panel(
    axis,
    dataframe,
    parameter,
    title,
):

    dataframe = dataframe.dropna(
        subset=[
            parameter,
            "balance_score",
        ]
    ).copy()

    if dataframe.empty:
        axis.text(
            0.5,
            0.5,
            "No data",
            ha="center",
            va="center",
            transform=axis.transAxes,
        )

        return []

    dataframe[
        "Balance_percent"
    ] = (
        100
        * dataframe[
            "balance_score"
        ]
    )

    raw_levels = (
        dataframe[
            parameter
        ]
        .drop_duplicates()
        .tolist()
    )

    try:
        levels = sorted(
            raw_levels,
            key=float,
        )
    except Exception:
        levels = sorted(
            raw_levels,
            key=str,
        )

    arrays = []
    frames = []

    for level in levels:
        column_numeric = pd.to_numeric(
            dataframe[
                parameter
            ],
            errors="coerce",
        )

        if not pd.isna(
            pd.to_numeric(
                pd.Series(
                    [
                        level
                    ]
                ),
                errors="coerce",
            ).iloc[
                0
            ]
        ):
            mask = np.isclose(
                column_numeric,
                float(
                    level
                ),
                equal_nan=False,
            )

        else:
            mask = (
                dataframe[
                    parameter
                ].astype(
                    str
                )
                == str(
                    level
                )
            )

        frame = dataframe.loc[
            mask
        ].copy()

        values = frame[
            "Balance_percent"
        ].to_numpy(
            dtype=float
        )

        arrays.append(
            values
        )

        frames.append(
            frame
        )

    positions = np.arange(
        1,
        len(
            levels
        )
        + 1,
    )

    box_colors = [
        "#BFD9EA",
        "#F2D1A2",
        "#C6D8AE",
        "#D8C4E8",
        "#E9C1C1",
    ]

    point_colors = [
        "#5DA5DA",
        "#F5A45D",
        "#76B76B",
        "#9B79C6",
        "#D86A6A",
    ]

    summary = []

    # If every level only has one run, use bars instead of meaningless boxes.
    single_run_levels = all(
        len(
            values
        )
        <= 1
        for values
        in arrays
    )

    if single_run_levels:
        values = np.asarray(
            [
                (
                    array[
                        0
                    ]
                    if len(
                        array
                    )
                    else np.nan
                )
                for array
                in arrays
            ],
            dtype=float,
        )

        finite = values[
            np.isfinite(
                values
            )
        ]

        baseline = (
            float(
                finite.min()
            )
            - 0.04
        )

        for index, (
            position,
            value,
        ) in enumerate(
            zip(
                positions,
                values,
            )
        ):
            if not np.isfinite(
                value
            ):
                continue

            axis.bar(
                position,
                value
                - baseline,
                bottom=baseline,
                width=0.48,
                facecolor=box_colors[
                    index
                    % len(
                        box_colors
                    )
                ],
                edgecolor="0.35",
                linewidth=0.8,
                alpha=0.78,
            )

            axis.scatter(
                [
                    position
                ],
                [
                    value
                ],
                s=38,
                c=point_colors[
                    index
                    % len(
                        point_colors
                    )
                ],
                edgecolors="0.25",
                linewidths=0.55,
                zorder=4,
            )

            axis.annotate(
                f"{value:.3f}",
                xy=(
                    position,
                    value,
                ),
                xytext=(
                    0,
                    6,
                ),
                textcoords="offset points",
                ha="center",
                fontsize=7,
            )

    else:
        boxplot = axis.boxplot(
            arrays,
            positions=positions,
            widths=0.56,
            showfliers=False,
            patch_artist=True,
            boxprops={
                "linewidth":
                    0.85,

                "edgecolor":
                    "0.35",
            },
            medianprops={
                "linewidth":
                    1.35,

                "color":
                    "0.20",
            },
            whiskerprops={
                "linewidth":
                    0.8,

                "color":
                    "0.35",
            },
            capprops={
                "linewidth":
                    0.8,

                "color":
                    "0.35",
            },
        )

        for index, patch in enumerate(
            boxplot[
                "boxes"
            ]
        ):
            patch.set_facecolor(
                box_colors[
                    index
                    % len(
                        box_colors
                    )
                ]
            )

            patch.set_alpha(
                0.62
            )

        rng = np.random.default_rng(
            20260824
        )

        for index, (
            position,
            values,
            frame,
        ) in enumerate(
            zip(
                positions,
                arrays,
                frames,
            )
        ):
            x = jitter(
                position,
                len(
                    values
                ),
                rng,
            )

            axis.scatter(
                x,
                values,
                s=18,
                c=point_colors[
                    index
                    % len(
                        point_colors
                    )
                ],
                alpha=0.72,
                edgecolors="none",
            )

    for level, values in zip(
        levels,
        arrays,
    ):
        if len(
            values
        ) == 0:
            continue

        summary.append(
            {
                "parameter":
                    parameter,

                "display_name":
                    title,

                "level":
                    level,

                "n":
                    len(
                        values
                    ),

                "median_balance_percent":
                    float(
                        np.median(
                            values
                        )
                    ),

                "mean_balance_percent":
                    float(
                        np.mean(
                            values
                        )
                    ),

                "min_balance_percent":
                    float(
                        np.min(
                            values
                        )
                    ),

                "max_balance_percent":
                    float(
                        np.max(
                            values
                        )
                    ),
            }
        )

    axis.set_xticks(
        positions
    )

    axis.set_xticklabels(
        [
            fmt_value(
                value
            )
            for value
            in levels
        ],
        fontsize=7.5,
    )

    axis.set_title(
        title,
        fontsize=9.2,
        pad=5,
    )

    axis.grid(
        axis="y",
        alpha=0.13,
        linewidth=0.45,
    )

    all_values = np.concatenate(
        [
            values
            for values
            in arrays
            if len(
                values
            )
            > 0
        ]
    )

    local_min = float(
        all_values.min()
    )

    local_max = float(
        all_values.max()
    )

    local_span = (
        local_max
        - local_min
    )

    visible_span = max(
        local_span,
        0.18,
    )

    padding = max(
        0.12
        * visible_span,
        0.025,
    )

    center = (
        0.5
        * (
            local_min
            + local_max
        )
    )

    if local_span < 0.18:
        lower = (
            center
            - 0.09
            - padding
        )

        upper = (
            center
            + 0.09
            + padding
        )

    else:
        lower = (
            local_min
            - padding
        )

        upper = (
            local_max
            + padding
        )

    if single_run_levels:
        upper += 0.035

    axis.set_ylim(
        lower,
        upper,
    )

    return summary


def draw_figure3(
    stage1,
    stage2,
    robustness,
):

    specifications = []

    stage1_titles = {
        "student_lr":
            "Student LR",

        "dropout":
            "Dropout",

        "class_weight_power":
            "Class-weight power",

        "prototype_align":
            "Prototype-align weight",
    }

    stage2_titles = {
        "subtype_ce":
            "Subtype CE weight",

        "binary_kd":
            "Binary KD weight",

        "feature_align":
            "Feature-align weight",
    }

    for parameter, title in stage1_titles.items():
        if (
            parameter
            in stage1.columns
            and stage1[
                parameter
            ].dropna().nunique()
            >= 2
        ):
            specifications.append(
                (
                    stage1,
                    parameter,
                    title,
                )
            )

    for parameter, title in stage2_titles.items():
        if (
            parameter
            in stage2.columns
            and stage2[
                parameter
            ].dropna().nunique()
            >= 2
        ):
            specifications.append(
                (
                    stage2,
                    parameter,
                    title,
                )
            )

    if (
        "candidate_rank"
        in robustness.columns
        and robustness[
            "candidate_rank"
        ].dropna().nunique()
        >= 2
    ):
        specifications.append(
            (
                robustness,
                "candidate_rank",
                "Top-3 candidate rank",
            )
        )

    if not specifications:
        raise ValueError(
            "No hyperparameters detected for Figure 3."
        )

    n_panels = len(
        specifications
    )

    n_columns = 4

    n_rows = math.ceil(
        n_panels
        / n_columns
    )

    figure, axes = plt.subplots(
        n_rows,
        n_columns,
        figsize=(
            14.8,
            3.45
            * n_rows,
        ),
        squeeze=False,
        sharey=False,
    )

    summary_rows = []

    for axis, (
        data,
        parameter,
        title,
    ) in zip(
        axes.ravel(),
        specifications,
    ):
        rows = parameter_panel(
            axis,
            data,
            parameter,
            title,
        )

        summary_rows.extend(
            rows
        )

    for axis in axes.ravel()[
        len(
            specifications
        ):
    ]:
        axis.axis(
            "off"
        )

    for row_index in range(
        n_rows
    ):
        axes[
            row_index,
            0
        ].set_ylabel(
            "Balance score (%)",
            fontsize=9,
        )

    figure.suptitle(
        "DNA grid search: hyperparameter sensitivity",
        fontsize=12,
        y=0.985,
    )

    figure.text(
        0.5,
        0.012,
        (
            "Balance = 0.5 × validation weighted precision "
            "+ 0.5 × validation ACC"
        ),
        ha="center",
        fontsize=7.5,
    )

    figure.tight_layout(
        rect=[
            0,
            0.04,
            1,
            0.95,
        ]
    )

    save_figure(
        figure,
        "Figure3_DNA_hyperparameter_sensitivity",
    )

    pd.DataFrame(
        summary_rows
    ).to_csv(
        OUTPUT_DIR
        / "DNA_hyperparameter_sensitivity_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )



# =============================================================================
# Figure 4: Stage-2 interaction landscape
# =============================================================================

def draw_figure4_stage2_interaction(
    stage2,
):
    """Visualize all 27 Stage-2 combinations.

    Facet = Subtype CE weight (3 levels)
    x     = Binary KD weight
    y     = Feature-align weight
    color = Balance score
    star  = best configuration within each Subtype-CE panel
    """

    required = [
        "subtype_ce",
        "binary_kd",
        "feature_align",
        "balance_score",
    ]

    missing = [
        column
        for column
        in required
        if column not in stage2.columns
    ]

    if missing:
        raise ValueError(
            f"Stage2 interaction missing columns: {missing}"
        )

    data = stage2.dropna(
        subset=required
    ).copy()

    if data.empty:
        print("[Skip] Figure 4: no Stage2 interaction data")
        return

    data["Balance_percent"] = (
        100.0
        * data["balance_score"]
    )

    subtype_ce_values = sorted(
        pd.to_numeric(
            data["subtype_ce"],
            errors="coerce",
        ).dropna().unique()
    )

    binary_kd_values = sorted(
        pd.to_numeric(
            data["binary_kd"],
            errors="coerce",
        ).dropna().unique()
    )

    feature_align_values = sorted(
        pd.to_numeric(
            data["feature_align"],
            errors="coerce",
        ).dropna().unique()
    )

    if len(subtype_ce_values) == 0:
        print("[Skip] Figure 4: no valid Stage2 levels")
        return

    vmin = float(
        data["Balance_percent"].min()
    )

    vmax = float(
        data["Balance_percent"].max()
    )

    figure, axes = plt.subplots(
        1,
        len(subtype_ce_values),
        figsize=(
            4.2 * len(subtype_ce_values),
            4.0,
        ),
        sharex=True,
        sharey=True,
        squeeze=False,
    )

    axes = axes.reshape(-1)
    mappable = None

    for index, subtype_ce in enumerate(
        subtype_ce_values
    ):
        axis = axes[index]

        panel = data[
            np.isclose(
                pd.to_numeric(
                    data["subtype_ce"],
                    errors="coerce",
                ),
                float(subtype_ce),
            )
        ].copy()

        mappable = axis.scatter(
            pd.to_numeric(
                panel["binary_kd"],
                errors="coerce",
            ),
            pd.to_numeric(
                panel["feature_align"],
                errors="coerce",
            ),
            c=panel["Balance_percent"],
            s=150,
            vmin=vmin,
            vmax=vmax,
            edgecolors="0.25",
            linewidths=0.45,
            zorder=3,
        )

        best_index = panel[
            "balance_score"
        ].idxmax()

        best = panel.loc[
            best_index
        ]

        axis.scatter(
            [float(best["binary_kd"])],
            [float(best["feature_align"])],
            marker="*",
            s=185,
            facecolors="none",
            edgecolors="black",
            linewidths=1.2,
            zorder=6,
        )

        axis.set_title(
            f"Subtype CE = {fmt_value(subtype_ce)}",
            fontsize=10,
        )

        axis.set_xticks(
            binary_kd_values
        )

        axis.set_yticks(
            feature_align_values
        )

        axis.set_xlabel(
            "Binary KD weight",
            fontsize=9,
        )

        if index == 0:
            axis.set_ylabel(
                "Feature-align weight",
                fontsize=9,
            )

        axis.grid(
            alpha=0.14,
            linewidth=0.5,
        )

    figure.suptitle(
        "DNA Stage-2 hyperparameter interaction",
        fontsize=12,
        y=0.98,
    )

    figure.subplots_adjust(
        left=0.08,
        right=0.88,
        bottom=0.16,
        top=0.84,
        wspace=0.20,
    )

    colorbar_axis = figure.add_axes(
        [
            0.91,
            0.20,
            0.018,
            0.56,
        ]
    )

    colorbar = figure.colorbar(
        mappable,
        cax=colorbar_axis,
    )

    colorbar.set_label(
        "Balance score (%)",
        fontsize=9,
    )

    save_figure(
        figure,
        "Figure4_DNA_stage2_interaction",
    )

    data.to_csv(
        OUTPUT_DIR
        / "DNA_stage2_interaction_plot_data.csv",
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# Figure 5: Top-3 robustness across three seeds
# =============================================================================

def draw_figure5_robustness():
    """Compare the Stage-2 Top-3 candidates across three independent seeds.

    Each panel shows the three individual seed runs plus mean ± SD.
    Candidate 1 is the selected robust configuration in the current result set.
    """

    if not ROBUST_FILE.is_file():
        print(
            f"[Skip] Figure 5: missing {ROBUST_FILE.name}"
        )
        return

    runs = read_csv(
        ROBUST_FILE
    )

    rank_column = find_column(
        runs,
        [
            "candidate_rank",
            "candidate_rank_stage2",
            "rank",
        ],
        required=True,
    )

    metrics = [
        (
            "val_end_accuracy",
            "Validation ACC (%)",
        ),
        (
            "val_end_weighted_precision",
            "Weighted precision (%)",
        ),
        (
            "val_end_weighted_f1",
            "Weighted F1 (%)",
        ),
        (
            "val_end_mcc",
            "MCC",
        ),
    ]

    missing = [
        metric
        for metric, _
        in metrics
        if metric not in runs.columns
    ]

    if missing:
        raise ValueError(
            f"Robustness file missing metrics: {missing}"
        )

    runs["candidate_rank_plot"] = pd.to_numeric(
        runs[rank_column],
        errors="coerce",
    )

    runs = runs.dropna(
        subset=["candidate_rank_plot"]
    ).copy()

    ranks = sorted(
        runs["candidate_rank_plot"].unique()
    )

    figure, axes = plt.subplots(
        2,
        2,
        figsize=(10.0, 7.4),
        squeeze=False,
    )

    rng = np.random.default_rng(
        20260824
    )

    summary_rows = []

    for axis, (metric, ylabel) in zip(
        axes.ravel(),
        metrics,
    ):
        is_percentage = (
            metric
            != "val_end_mcc"
        )

        all_plot_values = []

        for rank_index, rank in enumerate(
            ranks
        ):
            values = pd.to_numeric(
                runs.loc[
                    np.isclose(
                        runs["candidate_rank_plot"],
                        float(rank),
                    ),
                    metric,
                ],
                errors="coerce",
            ).dropna().to_numpy(
                dtype=float
            )

            if is_percentage:
                values_plot = (
                    100.0
                    * values
                )
            else:
                values_plot = values

            all_plot_values.extend(
                values_plot.tolist()
            )

            x_center = (
                rank_index
                + 1
            )

            x = jitter(
                x_center,
                len(values_plot),
                rng,
                width=0.065,
            )

            axis.scatter(
                x,
                values_plot,
                s=42,
                alpha=0.80,
                edgecolors="white",
                linewidths=0.45,
                zorder=3,
            )

            mean = float(
                np.mean(values_plot)
            )

            std = float(
                np.std(
                    values_plot,
                    ddof=1,
                )
            ) if len(values_plot) > 1 else 0.0

            axis.errorbar(
                x_center,
                mean,
                yerr=std,
                fmt="D",
                markersize=5.5,
                markerfacecolor="white",
                markeredgecolor="black",
                ecolor="black",
                elinewidth=1.0,
                capsize=4,
                zorder=5,
            )

            summary_rows.append({
                "candidate_rank":
                    rank,
                "metric":
                    metric,
                "mean_plot_value":
                    mean,
                "std_plot_value":
                    std,
                "n_runs":
                    len(values_plot),
            })

        axis.set_xticks(
            np.arange(
                1,
                len(ranks)
                + 1,
            )
        )

        axis.set_xticklabels(
            [
                f"Candidate {int(rank)}"
                for rank
                in ranks
            ],
            fontsize=8,
        )

        axis.set_ylabel(
            ylabel,
            fontsize=9,
        )

        axis.grid(
            axis="y",
            alpha=0.14,
            linewidth=0.5,
        )

        if all_plot_values:
            local_min = min(
                all_plot_values
            )
            local_max = max(
                all_plot_values
            )
            span = max(
                local_max
                - local_min,
                0.002
                if not is_percentage
                else 0.08,
            )
            padding = (
                0.16
                * span
            )
            axis.set_ylim(
                local_min
                - padding,
                local_max
                + padding,
            )

    figure.suptitle(
        "DNA Top-3 candidate robustness across three seeds",
        fontsize=12,
        y=0.985,
    )

    figure.text(
        0.5,
        0.012,
        (
            "Dots = independent seed runs; "
            "diamond/error bar = mean ± SD."
        ),
        ha="center",
        fontsize=7.5,
    )

    figure.tight_layout(
        rect=[
            0,
            0.04,
            1,
            0.95,
        ]
    )

    save_figure(
        figure,
        "Figure5_DNA_top3_robustness",
    )

    pd.DataFrame(
        summary_rows
    ).to_csv(
        OUTPUT_DIR
        / "DNA_top3_robustness_plot_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# Figure 6: Binary threshold selection
# =============================================================================

def get_selected_threshold(
    sweep,
):
    """Read the final selected threshold from BEST_FILE when available.

    Falls back to the maximum validation selection_score in the sweep.
    """

    if BEST_FILE.is_file():
        try:
            best = read_csv(
                BEST_FILE
            )

            column = find_column(
                best,
                [
                    "selected_binary_ARG_probability_threshold",
                    "selected_binary_threshold",
                ],
                required=False,
            )

            if column is not None:
                values = pd.to_numeric(
                    best[column],
                    errors="coerce",
                ).dropna()

                if len(values) > 0:
                    return float(
                        values.iloc[0]
                    )
        except Exception as exc:
            print(
                f"[Warning] Could not read final threshold from BEST_FILE: {exc}"
            )

    if "selection_score" in sweep.columns:
        index = pd.to_numeric(
            sweep["selection_score"],
            errors="coerce",
        ).idxmax()
        return float(
            pd.to_numeric(
                pd.Series(
                    [sweep.loc[index, "threshold"]]
                ),
                errors="coerce",
            ).iloc[0]
        )

    return float(
        pd.to_numeric(
            sweep["threshold"],
            errors="coerce",
        ).median()
    )


def draw_figure6_threshold():
    """Show the validation threshold trade-off and the final selected threshold."""

    if not THRESHOLD_FILE.is_file():
        print(
            f"[Skip] Figure 6: missing {THRESHOLD_FILE.name}"
        )
        return

    sweep = read_csv(
        THRESHOLD_FILE
    )

    required = [
        "threshold",
        "ARG_precision",
        "ARG_recall",
        "accuracy",
        "mcc",
        "selection_score",
    ]

    missing = [
        column
        for column
        in required
        if column not in sweep.columns
    ]

    if missing:
        raise ValueError(
            f"Threshold sweep missing columns: {missing}"
        )

    for column in required:
        sweep[column] = pd.to_numeric(
            sweep[column],
            errors="coerce",
        )

    sweep = sweep.dropna(
        subset=required
    ).sort_values(
        "threshold"
    ).copy()

    selected_threshold = get_selected_threshold(
        sweep
    )

    selected_row_index = (
        sweep["threshold"]
        - selected_threshold
    ).abs().idxmin()

    selected_row = sweep.loc[
        selected_row_index
    ]

    figure, axes = plt.subplots(
        1,
        2,
        figsize=(11.2, 4.4),
        sharex=True,
    )

    # Panel A: the central precision-recall trade-off.
    axes[0].plot(
        sweep["threshold"],
        100.0 * sweep["ARG_precision"],
        marker="o",
        markersize=3.2,
        linewidth=1.2,
        label="ARG precision",
    )

    axes[0].plot(
        sweep["threshold"],
        100.0 * sweep["ARG_recall"],
        marker="s",
        markersize=3.0,
        linewidth=1.2,
        label="ARG recall",
    )

    axes[0].axvline(
        selected_threshold,
        linestyle="--",
        linewidth=1.1,
        color="black",
        label=f"Selected = {selected_threshold:.2f}",
    )

    axes[0].scatter(
        [selected_threshold],
        [100.0 * float(selected_row["ARG_precision"])],
        s=55,
        facecolors="white",
        edgecolors="black",
        linewidths=0.9,
        zorder=5,
    )

    axes[0].scatter(
        [selected_threshold],
        [100.0 * float(selected_row["ARG_recall"])],
        s=55,
        facecolors="white",
        edgecolors="black",
        linewidths=0.9,
        zorder=5,
    )

    axes[0].set_ylabel(
        "Validation performance (%)",
        fontsize=9,
    )

    axes[0].set_xlabel(
        "Binary ARG probability threshold",
        fontsize=9,
    )

    axes[0].set_title(
        "Precision–recall trade-off",
        fontsize=10,
    )

    axes[0].legend(
        frameon=False,
        fontsize=7.5,
        loc="best",
    )

    axes[0].grid(
        alpha=0.14,
        linewidth=0.5,
    )

    # Panel B: overall validation quality used to choose a stable threshold.
    axes[1].plot(
        sweep["threshold"],
        100.0 * sweep["accuracy"],
        marker="o",
        markersize=3.0,
        linewidth=1.2,
        label="Accuracy",
    )

    axes[1].plot(
        sweep["threshold"],
        100.0 * sweep["mcc"],
        marker="^",
        markersize=3.2,
        linewidth=1.2,
        label="MCC",
    )

    axes[1].plot(
        sweep["threshold"],
        100.0 * sweep["selection_score"],
        marker="D",
        markersize=2.9,
        linewidth=1.2,
        label="Selection score",
    )

    axes[1].axvline(
        selected_threshold,
        linestyle="--",
        linewidth=1.1,
        color="black",
        label=f"Selected = {selected_threshold:.2f}",
    )

    axes[1].set_ylabel(
        "Validation score (%)",
        fontsize=9,
    )

    axes[1].set_xlabel(
        "Binary ARG probability threshold",
        fontsize=9,
    )

    axes[1].set_title(
        "Overall threshold quality",
        fontsize=10,
    )

    axes[1].legend(
        frameon=False,
        fontsize=7.5,
        loc="best",
    )

    axes[1].grid(
        alpha=0.14,
        linewidth=0.5,
    )

    figure.suptitle(
        "DNA validation-based binary threshold selection",
        fontsize=12,
        y=0.99,
    )

    figure.tight_layout(
        rect=[
            0,
            0,
            1,
            0.95,
        ]
    )

    save_figure(
        figure,
        "Figure6_DNA_binary_threshold_selection",
    )

    output = sweep.copy()
    output["selected_final_threshold"] = (
        np.isclose(
            output["threshold"],
            selected_threshold,
        )
    )

    output.to_csv(
        OUTPUT_DIR
        / "DNA_binary_threshold_selection_plot_data.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(
        f"Selected binary threshold: {selected_threshold:.4f}"
    )

# =============================================================================
# Main
# =============================================================================

def main():

    (
        combined,
        stage1,
        stage2,
        robustness,
    ) = build_combined_table()

    draw_figure1(
        combined
    )

    draw_figure2(
        stage1
    )

    draw_figure3(
        stage1,
        stage2,
        robustness,
    )

    # Additional complete-search visualizations.
    draw_figure4_stage2_interaction(
        stage2
    )

    draw_figure5_robustness()

    draw_figure6_threshold()

    primary = combined[
        combined[
            "stage"
        ].isin(
            [
                "student_grid_81",
                "student_grid_27",
            ]
        )
    ].dropna(
        subset=[
            "balance_score"
        ]
    )

    best = (
        primary
        .sort_values(
            "balance_score",
            ascending=False,
        )
        .iloc[
            0
        ]
    )

    print()
    print(
        "=" * 105
    )

    print(
        "COMPLETED"
    )

    print(
        "=" * 105
    )

    print(
        f"Best stage            : "
        f"{best['stage']}"
    )

    print(
        f"Best combo ID         : "
        f"{best['combo_id']}"
    )

    print(
        f"Validation ACC        : "
        f"{100 * best['val_end_accuracy']:.4f}%"
    )

    print(
        f"Weighted precision    : "
        f"{100 * best['val_end_weighted_precision']:.4f}%"
    )

    print(
        f"Balance score         : "
        f"{100 * best['balance_score']:.4f}%"
    )

    print(
        f"Output directory      : "
        f"{OUTPUT_DIR}"
    )

    print()
    print("Figures generated:")
    print("  Figure1_DNA_tradeoff")
    print("  Figure2_DNA_stage1_interaction")
    print("  Figure3_DNA_hyperparameter_sensitivity")
    print("  Figure4_DNA_stage2_interaction")
    print("  Figure5_DNA_top3_robustness")
    print("  Figure6_DNA_binary_threshold_selection")


if __name__ == "__main__":
    main()
