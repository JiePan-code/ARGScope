#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
构建多套 ARG:nonARG 比例数据集。

基于原 1:1 balanced 数据构建脚本修改，保留原来的：
    1. ARG protein/DNA ID 一一对应检查
    2. nonARG protein/DNA ID 一一对应检查
    3. 正向 frame 0 全长翻译一致性检查
    4. ARG 与 structure ID 完全一致检查
    5. nonARG 的 Type/Subtype 均写为 nonARG
    6. protein / DNA / structure 三个输出严格同步

新增：
    * 一次生成多个 ARG:nonARG ratio
    * 默认：
          1:1
          1:5
          1:10
          1:20
          1:50
    * ARG 集合在所有 ratio 中完全相同
    * nonARG 使用同一个随机种子和同一随机排列
    * 小 ratio 的 nonARG 是大 ratio 的子集，便于公平比较
    * 每个 ratio 单独输出到一个目录
    * 额外生成一个总 summary CSV

推荐实验用途：
    ratio 1:1   -> 当前 balanced baseline
    ratio 1:5   -> 轻度增加 nonARG
    ratio 1:10  -> 推荐第一版 imbalanced training
    ratio 1:20  -> 更保守的 binary detector
    ratio 1:50  -> 强负样本压力测试

注意：
    这个脚本只改变 ARG/nonARG 的总体比例。
    它不会重新平衡 ARG 内部的 Type/Subtype。
"""

from __future__ import annotations

import csv
import random
from collections import Counter
from pathlib import Path


# =============================================================================
# 1. 输入文件
# =============================================================================

ARG_PROTEIN_FASTA = "SARG_verified_paired_protein_subtype_ge3.fasta"
ARG_DNA_FASTA = "SARG_verified_paired_DNA_one_per_protein_subtype_ge3.fasta"
ARG_STRUCTURE = "SARG_verified_paired_protein_subtype_ge3_structure.txt"

NONARG_PROTEIN_FASTA = "nonARG_protein.fasta"
NONARG_DNA_FASTA = "nonARG_dna.fasta"


# =============================================================================
# 2. 多比例设置
# =============================================================================

# ARG : nonARG = 1 : ratio
NONARG_TO_ARG_RATIOS = [
    1,
    5,
    10,
    20,
    30,
]

# 固定随机种子，保证实验可重复。
RANDOM_SEED = 20260815

# True:
#   只要最大 ratio 的 nonARG 不够，就直接停止。
#
# False:
#   能生成多少 ratio 就生成多少；
#   不够的 ratio 自动跳过并打印 WARNING。
STRICT_REQUIRE_ALL_RATIOS = False


# =============================================================================
# 3. 输出设置
# =============================================================================

OUTPUT_ROOT = "ARG_nonARG_multiratio_final"

OUTPUT_PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
OUTPUT_DNA_FASTA = "all_arg_nonarg_dna.fasta"
OUTPUT_STRUCTURE = "all_arg_nonarg_structure.txt"

SUMMARY_CSV = "ARG_nonARG_multiratio_summary.csv"


# =============================================================================
# 4. 生物学检查设置
# =============================================================================

AMBIGUOUS_PROTEIN_RESIDUES = set("XBZJUO?")

SCRIPT_DIR = Path(__file__).resolve().parent

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

BACTERIAL_START_CODONS = {
    "ATG",
    "GTG",
    "TTG",
    "CTG",
    "ATT",
    "ATC",
    "ATA",
}

VALID_DNA_CHARACTERS = set("ACGTRYSWKMBDHVN")


# =============================================================================
# 5. 通用函数
# =============================================================================

def input_path(name: str) -> Path:
    path = Path(name).expanduser()

    if not path.is_absolute():
        path = SCRIPT_DIR / path

    path = path.resolve()

    if not path.is_file():
        raise FileNotFoundError(
            f"找不到输入文件：{path}"
        )

    return path


def clean_protein(sequence: str) -> str:
    return (
        "".join(sequence.split())
        .upper()
        .replace("-", "")
        .rstrip("*")
    )


def clean_dna(sequence: str) -> str:
    return (
        "".join(sequence.split())
        .upper()
        .replace("U", "T")
        .replace("-", "")
    )


def read_fasta(
    path: Path,
    molecule: str,
):
    order = []
    records = {}

    current_id = None
    current_header = None
    chunks = []

    def save_record():
        nonlocal current_id
        nonlocal current_header
        nonlocal chunks

        if current_id is None:
            return

        if current_id in records:
            raise ValueError(
                f"{path.name} 中存在重复 FASTA ID：{current_id}"
            )

        raw = "".join(chunks)

        sequence = (
            clean_protein(raw)
            if molecule == "protein"
            else clean_dna(raw)
        )

        if not sequence:
            raise ValueError(
                f"{path.name} 中存在空序列：{current_id}"
            )

        records[current_id] = {
            "header": current_header,
            "sequence": sequence,
        }

        order.append(current_id)

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line_number, raw_line in enumerate(
            handle,
            start=1,
        ):
            line = raw_line.strip()

            if not line:
                continue

            if line.startswith(">"):

                save_record()

                current_header = line[1:].strip()

                if not current_header:
                    raise ValueError(
                        f"{path.name} 第{line_number}行 FASTA 标题为空"
                    )

                current_id = current_header.split()[0]
                chunks = []

            else:

                if current_id is None:
                    raise ValueError(
                        f"{path.name} 第{line_number}行在标题前出现序列"
                    )

                chunks.append(line)

    save_record()

    return (
        order,
        records,
    )


def read_structure(
    path: Path,
):
    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                f"{path.name} 没有表头"
            )

        fields = list(
            reader.fieldnames
        )

        rows = list(reader)

    id_field = next(
        (
            field
            for field in fields
            if field.strip().lower()
            in {
                "sarg.seq.id",
                "id",
                "protein_id",
                "seq_id",
            }
        ),
        None,
    )

    type_field = next(
        (
            field
            for field in fields
            if field.strip().lower()
            == "type"
        ),
        None,
    )

    subtype_field = next(
        (
            field
            for field in fields
            if field.strip().lower()
            == "subtype"
        ),
        None,
    )

    if (
        id_field is None
        or type_field is None
        or subtype_field is None
    ):
        raise ValueError(
            f"{path.name} 必须包含 ID、Type、Subtype 列；"
            f"当前列为：{fields}"
        )

    by_id = {}

    for row in rows:
        sequence_id = row[
            id_field
        ].strip()

        if not sequence_id:
            raise ValueError(
                f"{path.name} 存在空 ID"
            )

        if sequence_id in by_id:
            raise ValueError(
                f"{path.name} 存在重复 ID：{sequence_id}"
            )

        by_id[
            sequence_id
        ] = row

    return (
        fields,
        rows,
        by_id,
        id_field,
        type_field,
        subtype_field,
    )


def translate_forward_frame0(
    dna: str,
    target_starts_with_m: bool,
) -> str:

    amino_acids = []

    for position in range(
        0,
        len(dna) - 2,
        3,
    ):
        amino_acids.append(
            CODON_TABLE.get(
                dna[
                    position:
                    position + 3
                ],
                "X",
            )
        )

    if (
        amino_acids
        and target_starts_with_m
        and dna[:3]
        in BACTERIAL_START_CODONS
    ):
        amino_acids[0] = "M"

    return "".join(
        amino_acids
    )


def residues_compatible(
    target: str,
    translated: str,
) -> bool:

    return (
        target == translated
        or target
        in AMBIGUOUS_PROTEIN_RESIDUES
    )


def validate_pair(
    protein: str,
    dna: str,
):
    """
    只接受正向 frame 0 的全长翻译对应。
    """

    protein = clean_protein(
        protein
    )

    dna = clean_dna(
        dna
    )

    invalid_characters = sorted(
        set(dna)
        - VALID_DNA_CHARACTERS
    )

    if invalid_characters:
        return (
            False,
            "INVALID_DNA_CHARACTERS",
        )

    valid_lengths = {
        len(protein) * 3,
        (len(protein) + 1) * 3,
    }

    if len(dna) not in valid_lengths:
        return (
            False,
            "DNA_LENGTH_NOT_FULL_CDS",
        )

    translated_raw = (
        translate_forward_frame0(
            dna,
            protein.startswith("M"),
        )
    )

    translated_without_terminal_stop = (
        translated_raw[:-1]
        if translated_raw.endswith("*")
        else translated_raw
    )

    if "*" in translated_without_terminal_stop:
        return (
            False,
            "INTERNAL_STOP_CODON",
        )

    if (
        len(
            translated_without_terminal_stop
        )
        != len(protein)
    ):
        return (
            False,
            "TRANSLATED_LENGTH_MISMATCH",
        )

    if not all(
        residues_compatible(
            target,
            observed,
        )
        for target, observed
        in zip(
            protein,
            translated_without_terminal_stop,
        )
    ):
        return (
            False,
            "PROTEIN_TRANSLATION_NOT_MATCHED",
        )

    if (
        translated_without_terminal_stop
        == protein
    ):
        return (
            True,
            "EXACT_FORWARD_FRAME0",
        )

    return (
        True,
        "COMPATIBLE_AMBIGUOUS_PROTEIN_RESIDUE",
    )


def validate_dataset(
    label,
    protein_order,
    proteins,
    dna_order,
    dna_records,
):
    protein_ids = set(
        proteins
    )

    dna_ids = set(
        dna_records
    )

    only_protein = (
        protein_ids
        - dna_ids
    )

    only_dna = (
        dna_ids
        - protein_ids
    )

    if only_protein or only_dna:

        examples_protein = sorted(
            only_protein
        )[:10]

        examples_dna = sorted(
            only_dna
        )[:10]

        raise ValueError(
            f"{label} protein/DNA FASTA 的ID集合不一致：\n"
            f"  仅protein中存在：{len(only_protein)}，"
            f"示例={examples_protein}\n"
            f"  仅DNA中存在：{len(only_dna)}，"
            f"示例={examples_dna}"
        )

    valid_ids = []
    failed = []
    status_counts = Counter()

    for index, sequence_id in enumerate(
        protein_order,
        start=1,
    ):

        accepted, status = validate_pair(
            proteins[
                sequence_id
            ][
                "sequence"
            ],
            dna_records[
                sequence_id
            ][
                "sequence"
            ],
        )

        status_counts[
            status
        ] += 1

        if accepted:
            valid_ids.append(
                sequence_id
            )
        else:
            failed.append(
                (
                    sequence_id,
                    status,
                )
            )

        if (
            index == 1
            or index % 5000 == 0
        ):
            print(
                f"  {label}: "
                f"checked {index}/{len(protein_order)}"
            )

    print(
        f"  {label} protein records       : "
        f"{len(protein_order)}"
    )

    print(
        f"  {label} DNA records           : "
        f"{len(dna_order)}"
    )

    print(
        f"  {label} translation matched   : "
        f"{len(valid_ids)}"
    )

    print(
        f"  {label} translation unmatched : "
        f"{len(failed)}"
    )

    for status, count in sorted(
        status_counts.items()
    ):
        print(
            f"    {status}: {count}"
        )

    if failed:
        print(
            f"  First unmatched examples: "
            f"{failed[:10]}"
        )

    return (
        valid_ids,
        failed,
    )


def wrap_sequence(
    sequence: str,
    width: int = 80,
) -> str:

    return "\n".join(
        sequence[
            i:
            i + width
        ]
        for i in range(
            0,
            len(sequence),
            width,
        )
    )


def replace_header_id(
    header: str,
    new_id: str,
) -> str:

    parts = header.split(
        maxsplit=1
    )

    return (
        new_id
        if len(parts) == 1
        else f"{new_id} {parts[1]}"
    )


# =============================================================================
# 6. 输出一套 ratio
# =============================================================================

def write_one_ratio(
    ratio: int,
    valid_arg_ids,
    selected_nonarg_ids,
    arg_proteins,
    arg_dna,
    nonarg_proteins,
    nonarg_dna,
    structure_by_id,
    fields,
    id_field,
    type_field,
    subtype_field,
    output_root: Path,
):
    ratio_dir = (
        output_root
        / f"ARG1_nonARG{ratio}"
    )

    ratio_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    protein_output = (
        ratio_dir
        / OUTPUT_PROTEIN_FASTA
    )

    dna_output = (
        ratio_dir
        / OUTPUT_DNA_FASTA
    )

    structure_output = (
        ratio_dir
        / OUTPUT_STRUCTURE
    )

    arg_id_set = set(
        valid_arg_ids
    )

    collisions = (
        arg_id_set
        .intersection(
            selected_nonarg_ids
        )
    )

    if collisions:

        nonarg_output_id = {
            sequence_id:
            f"nonARG__{sequence_id}"

            for sequence_id
            in selected_nonarg_ids
        }

        if arg_id_set.intersection(
            nonarg_output_id.values()
        ):
            raise RuntimeError(
                "添加 nonARG__ 前缀后仍存在 ID 冲突"
            )

    else:

        nonarg_output_id = {
            sequence_id:
            sequence_id

            for sequence_id
            in selected_nonarg_ids
        }

    # -------------------------------------------------------------------------
    # Protein FASTA
    # -------------------------------------------------------------------------

    with protein_output.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:

        for sequence_id in valid_arg_ids:

            record = arg_proteins[
                sequence_id
            ]

            handle.write(
                f">{record['header']}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

        for sequence_id in selected_nonarg_ids:

            record = nonarg_proteins[
                sequence_id
            ]

            header = replace_header_id(
                record[
                    "header"
                ],
                nonarg_output_id[
                    sequence_id
                ],
            )

            handle.write(
                f">{header}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

    # -------------------------------------------------------------------------
    # DNA FASTA
    # -------------------------------------------------------------------------

    with dna_output.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:

        for sequence_id in valid_arg_ids:

            record = arg_dna[
                sequence_id
            ]

            handle.write(
                f">{record['header']}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

        for sequence_id in selected_nonarg_ids:

            record = nonarg_dna[
                sequence_id
            ]

            header = replace_header_id(
                record[
                    "header"
                ],
                nonarg_output_id[
                    sequence_id
                ],
            )

            handle.write(
                f">{header}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

    # -------------------------------------------------------------------------
    # Structure
    # -------------------------------------------------------------------------

    with structure_output.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
        )

        writer.writeheader()

        for sequence_id in valid_arg_ids:

            writer.writerow(
                structure_by_id[
                    sequence_id
                ]
            )

        for sequence_id in selected_nonarg_ids:

            row = {
                field: ""
                for field
                in fields
            }

            row[
                id_field
            ] = nonarg_output_id[
                sequence_id
            ]

            row[
                type_field
            ] = "nonARG"

            row[
                subtype_field
            ] = "nonARG"

            writer.writerow(
                row
            )

    arg_count = len(
        valid_arg_ids
    )

    nonarg_count = len(
        selected_nonarg_ids
    )

    total_count = (
        arg_count
        + nonarg_count
    )

    print()
    print(
        f"[RATIO 1:{ratio}] COMPLETED"
    )
    print(
        f"  ARG records      : {arg_count}"
    )
    print(
        f"  nonARG records   : {nonarg_count}"
    )
    print(
        f"  Total records    : {total_count}"
    )
    print(
        f"  Output directory : {ratio_dir}"
    )

    return {
        "ARG_to_nonARG_ratio": f"1:{ratio}",
        "ratio_value": ratio,
        "ARG_count": arg_count,
        "nonARG_count": nonarg_count,
        "total_count": total_count,
        "ARG_fraction": (
            arg_count
            / total_count
        ),
        "nonARG_fraction": (
            nonarg_count
            / total_count
        ),
        "random_seed": RANDOM_SEED,
        "output_directory": str(
            ratio_dir
        ),
        "protein_fasta": str(
            protein_output
        ),
        "dna_fasta": str(
            dna_output
        ),
        "structure": str(
            structure_output
        ),
    }


# =============================================================================
# 7. MAIN
# =============================================================================

def main():

    ratios = sorted(
        set(
            int(x)
            for x in NONARG_TO_ARG_RATIOS
        )
    )

    if not ratios:
        raise ValueError(
            "NONARG_TO_ARG_RATIOS 为空"
        )

    if ratios[0] < 1:
        raise ValueError(
            "所有 ratio 必须 >= 1"
        )

    arg_protein_path = input_path(
        ARG_PROTEIN_FASTA
    )

    arg_dna_path = input_path(
        ARG_DNA_FASTA
    )

    arg_structure_path = input_path(
        ARG_STRUCTURE
    )

    nonarg_protein_path = input_path(
        NONARG_PROTEIN_FASTA
    )

    nonarg_dna_path = input_path(
        NONARG_DNA_FASTA
    )

    print(
        "=" * 100
    )
    print(
        "Build multi-ratio ARG/nonARG datasets"
    )
    print(
        "=" * 100
    )
    print(
        f"Requested ratios : "
        f"{['1:' + str(x) for x in ratios]}"
    )
    print(
        f"Random seed      : {RANDOM_SEED}"
    )
    print(
        "Nested sampling  : YES"
    )

    # -------------------------------------------------------------------------
    # Load
    # -------------------------------------------------------------------------

    (
        arg_order,
        arg_proteins,
    ) = read_fasta(
        arg_protein_path,
        "protein",
    )

    (
        arg_dna_order,
        arg_dna,
    ) = read_fasta(
        arg_dna_path,
        "DNA",
    )

    (
        nonarg_order,
        nonarg_proteins,
    ) = read_fasta(
        nonarg_protein_path,
        "protein",
    )

    (
        nonarg_dna_order,
        nonarg_dna,
    ) = read_fasta(
        nonarg_dna_path,
        "DNA",
    )

    (
        fields,
        structure_rows,
        structure_by_id,
        id_field,
        type_field,
        subtype_field,
    ) = read_structure(
        arg_structure_path
    )

    if (
        set(arg_proteins)
        != set(structure_by_id)
    ):

        raise ValueError(
            "ARG protein FASTA 与 ARG structure 的ID集合不一致："
            f"仅FASTA="
            f"{len(set(arg_proteins)-set(structure_by_id))}，"
            f"仅structure="
            f"{len(set(structure_by_id)-set(arg_proteins))}"
        )

    # -------------------------------------------------------------------------
    # Validate ARG
    # -------------------------------------------------------------------------

    print(
        "\n[1/2] Validate ARG pairs"
    )

    (
        valid_arg_ids,
        failed_arg,
    ) = validate_dataset(
        "ARG",
        arg_order,
        arg_proteins,
        arg_dna_order,
        arg_dna,
    )

    if failed_arg:

        raise RuntimeError(
            f"ARG 一对一数据中仍有 "
            f"{len(failed_arg)} 对翻译不匹配。"
            "程序停止，请先检查这些 ARG。"
        )

    if valid_arg_ids != arg_order:

        raise RuntimeError(
            "ARG 验证结果顺序异常"
        )

    # -------------------------------------------------------------------------
    # Validate nonARG
    # -------------------------------------------------------------------------

    print(
        "\n[2/2] Validate nonARG pairs"
    )

    (
        valid_nonarg_ids,
        failed_nonarg,
    ) = validate_dataset(
        "nonARG",
        nonarg_order,
        nonarg_proteins,
        nonarg_dna_order,
        nonarg_dna,
    )

    arg_count = len(
        valid_arg_ids
    )

    valid_nonarg_count = len(
        valid_nonarg_ids
    )

    print()
    print(
        "=" * 100
    )
    print(
        "VALIDATION SUMMARY"
    )
    print(
        "=" * 100
    )
    print(
        f"ARG count                : {arg_count}"
    )
    print(
        f"Valid nonARG             : {valid_nonarg_count}"
    )
    print(
        f"Rejected nonARG          : {len(failed_nonarg)}"
    )
    print(
        "Maximum possible ratio   : "
        f"1:{valid_nonarg_count // arg_count}"
    )

    # -------------------------------------------------------------------------
    # Determine possible ratios
    # -------------------------------------------------------------------------

    possible_ratios = []

    impossible_ratios = []

    for ratio in ratios:

        required_nonarg = (
            arg_count
            * ratio
        )

        if (
            valid_nonarg_count
            >= required_nonarg
        ):

            possible_ratios.append(
                ratio
            )

        else:

            impossible_ratios.append(
                (
                    ratio,
                    required_nonarg,
                    required_nonarg
                    - valid_nonarg_count,
                )
            )

    if impossible_ratios:

        print()
        print(
            "WARNING: insufficient valid nonARG "
            "for some requested ratios:"
        )

        for (
            ratio,
            required,
            shortage,
        ) in impossible_ratios:

            print(
                f"  1:{ratio} requires "
                f"{required} nonARG; "
                f"shortage={shortage}"
            )

        if STRICT_REQUIRE_ALL_RATIOS:

            raise RuntimeError(
                "STRICT_REQUIRE_ALL_RATIOS=True，"
                "但部分 ratio 的 nonARG 数量不足。"
            )

    if not possible_ratios:

        raise RuntimeError(
            "没有任何请求的 ratio 可以生成。"
        )

    # -------------------------------------------------------------------------
    # One deterministic random permutation
    # -------------------------------------------------------------------------

    rng = random.Random(
        RANDOM_SEED
    )

    shuffled_valid_nonarg = list(
        valid_nonarg_ids
    )

    rng.shuffle(
        shuffled_valid_nonarg
    )

    # rank 用于从随机选择集合恢复到原 FASTA 顺序输出。
    nonarg_original_rank = {
        sequence_id: index
        for index, sequence_id
        in enumerate(
            nonarg_order
        )
    }

    output_root = (
        SCRIPT_DIR
        / OUTPUT_ROOT
    ).resolve()

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    summary_rows = []

    # -------------------------------------------------------------------------
    # Generate all possible ratios
    # -------------------------------------------------------------------------

    for ratio in possible_ratios:

        target_nonarg_count = (
            arg_count
            * ratio
        )

        # Nested sampling:
        # first N in one fixed random permutation.
        selected_set = set(
            shuffled_valid_nonarg[
                :target_nonarg_count
            ]
        )

        # Output in the original nonARG FASTA order.
        selected_nonarg_ids = sorted(
            selected_set,
            key=lambda x:
            nonarg_original_rank[x],
        )

        if (
            len(selected_nonarg_ids)
            != target_nonarg_count
        ):

            raise RuntimeError(
                f"1:{ratio} nonARG 抽样数量异常"
            )

        row = write_one_ratio(
            ratio=ratio,
            valid_arg_ids=valid_arg_ids,
            selected_nonarg_ids=selected_nonarg_ids,
            arg_proteins=arg_proteins,
            arg_dna=arg_dna,
            nonarg_proteins=nonarg_proteins,
            nonarg_dna=nonarg_dna,
            structure_by_id=structure_by_id,
            fields=fields,
            id_field=id_field,
            type_field=type_field,
            subtype_field=subtype_field,
            output_root=output_root,
        )

        summary_rows.append(
            row
        )

    # -------------------------------------------------------------------------
    # Summary
    # -------------------------------------------------------------------------

    summary_path = (
        output_root
        / SUMMARY_CSV
    )

    with summary_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=list(
                summary_rows[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            summary_rows
        )

    print()
    print(
        "=" * 100
    )
    print(
        "ALL AVAILABLE RATIOS COMPLETED"
    )
    print(
        "=" * 100
    )
    print(
        f"ARG records              : {arg_count}"
    )
    print(
        f"Valid nonARG pool        : {valid_nonarg_count}"
    )
    print(
        f"Generated ratios         : "
        f"{['1:' + str(x) for x in possible_ratios]}"
    )

    if impossible_ratios:

        print(
            f"Skipped ratios           : "
            f"{['1:' + str(x[0]) for x in impossible_ratios]}"
        )

    print(
        f"Random seed              : {RANDOM_SEED}"
    )
    print(
        f"Output root              : {output_root}"
    )
    print(
        f"Summary CSV              : {summary_path}"
    )

    print()
    print(
        "Important:"
    )
    print(
        "  All datasets contain exactly the same ARG records."
    )
    print(
        "  nonARG selection is nested across ratios."
    )
    print(
        "  Therefore differences among ratios mainly reflect "
        "the amount of negative data rather than random resampling."
    )


if __name__ == "__main__":
    main()
