"""Read-only audit: uploaded Student code versus installed inputs/configurations."""
import ast
import csv
import json
from collections import Counter
from pathlib import Path
import torch
import torch.nn.functional as F

BASE = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24")
DATA = BASE / "1.training dataset"
SUITE = DATA / "ARGScope_ablation_suite_80_20"
ATTACH = Path(r"C:\Users\Jie Pan\.codex\attachments")


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def compact(value):
    if torch.is_tensor(value):
        return {"tensor_shape": list(value.shape)}
    if isinstance(value, dict):
        return {"dict_keys": list(value.keys())[:45]}
    if isinstance(value, (list, tuple)):
        return {"length": len(value), "sample": value[:3] if len(value) < 6 else []}
    if isinstance(value, str):
        return value[:600] + (" ... [long string omitted]" if len(value) > 600 else "")
    if isinstance(value, (int, float, bool, type(None))):
        return value
    return str(type(value))


def main():
    torch.set_num_threads(2)
    result = {"definitions": {}}
    for modality, attachment, current in [
        ("dna", "f584ba5b-956f-41b8-8c1c-f0dd23780f5e", "05_dna_student.py"),
        ("protein", "e2cd44d2-4c5b-4946-b6e1-d01daad69422", "04_protein_student.py"),
    ]:
        trees = [ast.parse(p.read_text(encoding="utf-8-sig")) for p in [ATTACH / attachment / "pasted-text.txt", SUITE / "core" / current]]
        defs = [{n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))} for tree in trees]
        same, changed = [], []
        for name in defs[0].keys() & defs[1].keys():
            if ast.dump(defs[0][name], include_attributes=False) == ast.dump(defs[1][name], include_attributes=False):
                same.append(name)
            else:
                changed.append(name)
        result["definitions"][modality] = {"same": sorted(same), "changed": sorted(changed), "old_only": list(defs[0].keys()-defs[1].keys()), "new_only": list(defs[1].keys()-defs[0].keys())}
    result["checkpoints"] = {}
    for label, path in [
        ("new_dna", DATA / "ARGScope_80_20_results/full/dna/DNA_student_long_model.pt"),
        ("new_protein", DATA / "ARGScope_80_20_results/full/protein/protein_100pct_epoch_features_run_best_model.pt"),
        ("older_11140_dna", BASE / "4.DNA_student_subtype2_newsplit/DNA_student_long_model.pt"),
        ("paper_8382_dna", BASE / "1.DNA_student_long_gridsearch/DNA_student_long_GRID_best_model.pt"),
    ]:
        if not path.exists():
            result["checkpoints"][label] = {"missing": str(path)}
            continue
        obj = torch.load(path, map_location="cpu", weights_only=False)
        keys = ["configuration", "best_parameters", "config", "student_best_epoch", "teacher_best_epoch", "selected_binary_ARG_probability_threshold", "source_fusion_pt", "source_refined_pt", "num_ARG_subtypes", "reference_GRID_student_best_epoch", "reference_GRID_binary_threshold"]
        result["checkpoints"][label] = {k: ({f: compact(v) for f, v in obj[k].items()} if isinstance(obj[k], dict) else compact(obj[k])) for k in keys if k in obj}
        result["checkpoints"][label]["keys"] = list(obj)
        del obj
    result["old_artifacts"] = {}
    old_fusion = torch.load(DATA / "Long_fusion/long_fusion.pt", map_location="cpu", weights_only=False)
    result["old_artifacts"]["fusion"] = {k: compact(v) for k, v in old_fusion.items() if k in ("ids", "subtypes", "splits", "model_splits", "train_ids", "model_train_ids", "validation_ids", "source", "config", "training_config", "script_version", "best_epoch")}
    old_test = {r["sequence_id"] for r in read_rows(BASE / "4.DNA_student_subtype2_newsplit/test_sequence_predictions.csv")}
    current_rows = read_rows(DATA / "split_80_20_grouped/split_manifest.csv")
    current_test = {r["sequence_id"] for r in current_rows if r["model_split"] == "test"}
    upstream_train = {str(i) for i, s in zip(old_fusion["ids"], old_fusion["model_splits"]) if s == "train"}
    result["local_old_fusion_overlap"] = {"fusion_model_train_n": len(upstream_train), "old_11140_test_intersection": len(upstream_train & old_test), "new_4574_test_intersection": len(upstream_train & current_test), "scope": "Local old artifact only; no verified hash link to historical NSCC run."}
    del old_fusion
    refined = torch.load(DATA / "Refined_subtype_prototypes_long/refined_ARG_subtype_prototypes_residual_GAT.pt", map_location="cpu", weights_only=False)
    result["old_artifacts"]["refined"] = {k: compact(v) for k, v in refined.items() if k in ("arg_subtype_names", "train_ids", "model_train_ids", "validation_ids", "train_indices", "model_train_indices", "source_gated_fusion_pt", "source_raw_prototype_pt", "split_fingerprint", "training_config", "script_version")}
    result["old_artifacts"]["refined"]["keys"] = list(refined)
    result["prototype_lineage_checks"] = {}
    old_proto_names = refined["arg_subtype_names"]
    proto_index = {str(name): i for i, name in enumerate(old_proto_names)}
    old_proto_tensor = refined["refined_arg_subtype_prototypes"].float()
    graph_train = {str(s) for s in refined.get("train_ARG_ids", [])}
    result["old_artifacts"]["refined"]["train_ARG_n"] = len(graph_train)
    result["old_artifacts"]["refined"]["evaluation_ids"] = {k: compact(v) for k, v in refined.get("evaluation_ids", {}).items()}
    for label, checkpoint, predictions in [
        ("older_11140", BASE / "4.DNA_student_subtype2_newsplit/DNA_student_long_model.pt", BASE / "4.DNA_student_subtype2_newsplit/test_sequence_predictions.csv"),
        ("paper_8382", BASE / "1.DNA_student_long_gridsearch/DNA_student_long_GRID_best_model.pt", BASE / "1.DNA_student_long_gridsearch/100%_test_sequence_predictions.csv"),
    ]:
        obj = torch.load(checkpoint, map_location="cpu", weights_only=False)
        names = [str(n) for n in obj["arg_subtype_names"]]
        subset = old_proto_tensor[[proto_index[n] for n in names]]
        saved = obj["refined_ARG_subtype_prototypes"].float()
        test_predictions = read_rows(predictions)
        test_ids = {r["sequence_id"] for r in test_predictions}
        exposed = [r for r in test_predictions if r["sequence_id"] in graph_train]
        result["prototype_lineage_checks"][label] = {
            "prototype_shape": list(saved.shape),
            "exact_match_raw": torch.equal(saved, subset),
            "exact_match_normalized": torch.equal(saved, F.normalize(subset, p=2, dim=1)),
            "normalized_max_abs_difference": float((saved-F.normalize(subset, p=2, dim=1)).abs().max()),
            "normalized_allclose_1e6": torch.allclose(saved, F.normalize(subset, p=2, dim=1), atol=1e-6, rtol=1e-6),
            "old_fusion_train_intersection_with_test": len(upstream_train & test_ids),
            "old_graph_train_ARG_intersection_with_test": len(exposed),
            "old_graph_exposed_gated_subtype_accuracy": sum(r["true_subtype"] == r["predicted_subtype"] for r in exposed) / len(exposed) if exposed else None,
            "source_gated_fusion_pt": refined.get("source_gated_fusion_pt"),
        }
        del obj
    current_refined = torch.load(DATA / "ARGScope_80_20_results/full/graph/refined_prototypes.pt", map_location="cpu", weights_only=False)
    current_graph_train = {str(s) for s in current_refined.get("train_ARG_ids", [])}
    result["prototype_lineage_checks"]["new_4574"] = {"graph_train_ARG_n": len(current_graph_train), "graph_train_ARG_intersection_with_test": len(current_graph_train & current_test), "saved_model_train_n": len(current_refined["split_manifest"]["exact_ids"]["train"]), "saved_model_train_intersection_with_test": len(set(current_refined["split_manifest"]["exact_ids"]["train"]) & current_test)}
    result["new_rare_context"] = {"train_ARG_n": sum(r["model_split"] == "train" and r["ARG_or_nonARG"] == "ARG" for r in current_rows), "test_ARG_n": sum(r["model_split"] == "test" and r["ARG_or_nonARG"] == "ARG" for r in current_rows)}
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
