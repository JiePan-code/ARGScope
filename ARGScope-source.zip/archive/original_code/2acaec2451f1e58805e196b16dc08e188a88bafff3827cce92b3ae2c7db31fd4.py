# -*- coding: utf-8 -*-
"""
ARGScope subtype training:
Fusion embedding as teacher/classifier input,
Protein embedding as student/test input.

Main idea:
1. Train subtype classifier using fusion embeddings from 60p/70p/80p/90p/100p.
2. Train protein -> fusion mapper using matched protein/fusion embeddings from the same percentage.
3. Test each percentage protein embedding separately:
       protein -> mapper -> fusion classifier
4. Output both fragment-level and base-ID-level results.

Required files in the same folder:
    1.60p_all_fusion_embedding_512_with_label.csv
    1.70p_all_fusion_embedding_512_with_label.csv
    1.80p_all_fusion_embedding_512_with_label.csv
    1.90p_all_fusion_embedding_512_with_label.csv
    1.100p_all_fusion_embedding_512_with_label.csv

    2.60p_ARG_protein_with_label.csv
    2.70p_ARG_protein_with_label.csv
    2.80p_ARG_protein_with_label.csv
    2.90p_ARG_protein_with_label.csv
    2.100p_ARG_protein_with_label.csv

    train_set.csv
    test_set.csv

    1.all_subtype_prototypes_512.csv

Output:
    ARGScope_saved_model_percentage/
"""

import os
import re
import gc
import random
import multiprocessing as mp
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    classification_report,
)


# =========================================================
# 1. CONFIG
# =========================================================

FUSION_FILES = {
    "60p": "1.60p_all_fusion_embedding_512_with_label.csv",
    "70p": "1.70p_all_fusion_embedding_512_with_label.csv",
    "80p": "1.80p_all_fusion_embedding_512_with_label.csv",
    "90p": "1.90p_all_fusion_embedding_512_with_label.csv",
    "100p": "1.100p_all_fusion_embedding_512_with_label.csv",
}

PROTEIN_FILES = {
    "60p": "2.60p_ARG_protein_with_label.csv",
    "70p": "2.70p_ARG_protein_with_label.csv",
    "80p": "2.80p_ARG_protein_with_label.csv",
    "90p": "2.90p_ARG_protein_with_label.csv",
    "100p": "2.100p_ARG_protein_with_label.csv",
}

TRAIN_SPLIT_FILE = "train_set.csv"
TEST_SPLIT_FILE = "test_set.csv"

PROTO_FILE = "1.all_subtype_prototypes_512.csv"

LABEL_COL = "Subtype"
TYPE_COL = "Type"

KEY_CANDIDATES = [
    "Geneid", "geneid",
    "id", "ID", "Id",
    "NucleotideID", "ProteinID",
]

OUTPUT_DIR = Path("ARGScope_saved_model_percentage")
OUTPUT_DIR.mkdir(exist_ok=True)

CHECKPOINT_FILE = OUTPUT_DIR / "argscope_subtype_fusion_teacher_protein_student_percentage_checkpoint.pth"
SCALER_FUSION_FILE = OUTPUT_DIR / "scaler_fusion.joblib"
SCALER_PROTEIN_FILE = OUTPUT_DIR / "scaler_protein.joblib"
LABEL_ENCODER_FILE = OUTPUT_DIR / "label_encoder.joblib"
FEATURE_INFO_FILE = OUTPUT_DIR / "feature_info.joblib"
CLASS_INFO_FILE = OUTPUT_DIR / "subtype_class_info.csv"

RESULT_DIR = OUTPUT_DIR / "prediction_results"
RESULT_DIR.mkdir(exist_ok=True)

SEED = 281

BATCH_SIZE = 256

MAX_EPOCHS_C = 300
MAX_EPOCHS_M = 300

LR_C = 5e-4
LR_M = 3e-4
WEIGHT_DECAY = 3e-5

LAMBDA_MSE = 0.10
LAMBDA_CE = 3.00
LAMBDA_PRIOR = 2.00
LAMBDA_PROTO = 1.00

SCALE = 22.0

EARLY_STOP_PATIENCE_C = 25
EARLY_STOP_PATIENCE_M = 40
MIN_DELTA = 1e-4

NUM_WORKERS = 0
PIN_MEMORY = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
USE_AMP = torch.cuda.is_available()

# 如果电脑内存不够，可以先设置成较小数字测试代码，例如 200000。
# 正式跑全部数据时保持 None。
MAX_TRAIN_ROWS_PER_PERCENT = None
MAX_TEST_ROWS_PER_PERCENT = None


# =========================================================
# 2. BASIC UTILS
# =========================================================

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True


def find_key_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def get_base_key(seq_id):
    """
    Convert expanded ID to original base ID.

    Examples:
        xxx_1 -> xxx
        xxx_2 -> xxx
        xxx_3 -> xxx
        xxx_4 -> xxx
        xxx_5 -> xxx

    Also supports:
        xxx.1 -> xxx
        xxx-1 -> xxx
    """
    seq_id = str(seq_id).strip()
    return re.sub(r"([_.-][1-5])$", "", seq_id)


def get_feature_cols(df):
    exclude_cols = {
        "KEY", "BASE_KEY", "PERCENTAGE", "SOURCE",
        "id", "ID", "Id",
        "Geneid", "geneid",
        "NucleotideID", "ProteinID",
        "Type", "Subtype",
        "type", "subtype",
        "TYPE", "SUBTYPE",
        "Type_split", "Subtype_split",
        "type_split", "subtype_split",
        "Count", "count",
    }

    cols = []

    for c in df.columns:
        if c in exclude_cols:
            continue

        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)

    return cols


def standardize_label_columns(df):
    """
    Standardize label column names:
        type / TYPE / Type_split-like exact variants -> Type
        subtype / SUBTYPE -> Subtype

    This function only handles exact label columns, not Type_split/Subtype_split.
    """
    rename_map = {}

    for c in df.columns:
        c_stripped = str(c).strip()
        c_lower = c_stripped.lower()

        if c_lower == "type" and TYPE_COL not in df.columns:
            rename_map[c] = TYPE_COL

        if c_lower == "subtype" and LABEL_COL not in df.columns:
            rename_map[c] = LABEL_COL

    if len(rename_map) > 0:
        print("[INFO] Rename label columns:", rename_map)
        df = df.rename(columns=rename_map)

    return df


def infer_type_from_subtype_value(subtype_value):
    subtype_value = str(subtype_value)

    if "__" in subtype_value:
        return subtype_value.split("__", 1)[0]

    return "Unknown"


def clean_label_columns(df):
    """
    Clean Type/Subtype columns.

    Supports:
        Type / Subtype
        type / subtype
        TYPE / SUBTYPE

    If Type is missing but Subtype exists in Type__Subtype format,
    infer Type from Subtype.
    """
    df = standardize_label_columns(df)

    if LABEL_COL not in df.columns:
        raise ValueError(
            f"Missing required label column: {LABEL_COL}. "
            f"Available columns preview: {list(df.columns[:30])}"
        )

    df[LABEL_COL] = (
        df[LABEL_COL]
        .astype(str)
        .replace(["nan", "None", "NAN", "NaN"], "Unknown")
    )

    if TYPE_COL not in df.columns:
        print(f"[WARN] Missing {TYPE_COL} column. Infer {TYPE_COL} from {LABEL_COL}.")
        df[TYPE_COL] = df[LABEL_COL].apply(infer_type_from_subtype_value)
    else:
        df[TYPE_COL] = (
            df[TYPE_COL]
            .astype(str)
            .replace(["nan", "None", "NAN", "NaN"], "Unknown")
        )

        unknown_mask = df[TYPE_COL].isin(["Unknown", "unknown", "", "nan", "None", "NAN", "NaN"])
        if unknown_mask.sum() > 0:
            df.loc[unknown_mask, TYPE_COL] = df.loc[unknown_mask, LABEL_COL].apply(
                infer_type_from_subtype_value
            )

    return df


def to_float_matrix(df, cols):
    return (
        df[cols]
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .values
        .astype(np.float32)
    )


def prefix_feature_columns(df, feature_cols, prefix):
    rename_map = {c: f"{prefix}{c}" for c in feature_cols}
    df = df.rename(columns=rename_map)
    prefixed_cols = [rename_map[c] for c in feature_cols]
    return df, prefixed_cols


def extract_type_from_subtype_label(label, subtype_to_type=None):
    label = str(label)

    if "__" in label:
        return label.split("__", 1)[0]

    if subtype_to_type is not None and label in subtype_to_type:
        return subtype_to_type[label]

    return "UNKNOWN"


def normalize_true_subtype(row):
    """
    Use raw Subtype if it already matches the model label format.
    If Subtype does not contain "__", combine Type and Subtype.
    """
    true_type = str(row[TYPE_COL])
    true_subtype = str(row[LABEL_COL])

    if "__" in true_subtype:
        return true_subtype

    return true_type + "__" + true_subtype


def build_subtype_to_type_map(df):
    tmp = df[[TYPE_COL, LABEL_COL]].copy()
    tmp[TYPE_COL] = tmp[TYPE_COL].astype(str)
    tmp[LABEL_COL] = tmp[LABEL_COL].astype(str)

    mapping = {}

    for subtype, sub_df in tmp.groupby(LABEL_COL):
        type_value = sub_df[TYPE_COL].value_counts().index[0]
        mapping[str(subtype)] = str(type_value)

    return mapping


# =========================================================
# 3. METRICS
# =========================================================

def compute_overall_metrics(y_true, y_pred):
    return {
        "ACC": accuracy_score(y_true, y_pred),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "sample_count": int(len(y_true)),
        "class_count": int(len(np.unique(y_true))),
    }


def compute_binary_mcc_for_class(y_true, y_pred, class_id):
    y_true_bin = (y_true == class_id).astype(int)
    y_pred_bin = (y_pred == class_id).astype(int)

    if len(np.unique(y_true_bin)) == 1 and len(np.unique(y_pred_bin)) == 1:
        return 0.0

    return matthews_corrcoef(y_true_bin, y_pred_bin)


def compute_per_class_metrics(
    y_true,
    y_pred,
    class_names,
    label_name,
    split_name,
    split_sample_count,
    split_class_count,
):
    rows = []
    present_labels = sorted(np.unique(y_true))

    for class_id in present_labels:
        class_name = class_names[class_id]

        support = int((y_true == class_id).sum())
        pred_count = int((y_pred == class_id).sum())
        correct_count = int(((y_true == class_id) & (y_pred == class_id)).sum())

        precision = precision_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0,
        )

        recall = recall_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0,
        )

        f1 = f1_score(
            (y_true == class_id).astype(int),
            (y_pred == class_id).astype(int),
            zero_division=0,
        )

        class_acc = correct_count / support if support > 0 else 0.0
        class_mcc = compute_binary_mcc_for_class(y_true, y_pred, class_id)

        rows.append({
            "split": split_name,
            "split_sample_count": int(split_sample_count),
            "split_class_count": int(split_class_count),
            label_name: class_name,
            "class_id": int(class_id),
            "support": support,
            "pred_count": pred_count,
            "correct_count": correct_count,
            "ACC": class_acc,
            "PRECISION": precision,
            "RECALL": recall,
            "F1": f1,
            "MCC": class_mcc,
        })

    per_class_df = pd.DataFrame(rows)

    if len(per_class_df) > 0:
        per_class_df = per_class_df.sort_values(
            by=["support", label_name],
            ascending=[False, True],
        ).reset_index(drop=True)

    return per_class_df


def save_classification_report(y_true, y_pred, out_file):
    report_dict = classification_report(
        y_true=y_true,
        y_pred=y_pred,
        output_dict=True,
        zero_division=0,
    )

    report_df = pd.DataFrame(report_dict).T
    report_df.to_csv(out_file, index=True, encoding="utf-8-sig")


# =========================================================
# 4. PRIOR MATRIX
# =========================================================

def build_prior_matrix(prior_df, label_col, label_encoder):
    if label_col not in prior_df.columns:
        raise ValueError(f"PROTO_FILE missing label column: {label_col}")

    feat_cols = get_feature_cols(prior_df)

    if len(feat_cols) == 0:
        raise ValueError("PROTO_FILE has no numeric feature columns.")

    tmp = prior_df.copy()
    tmp[label_col] = tmp[label_col].astype(str)
    tmp[feat_cols] = tmp[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

    grouped = tmp.groupby(label_col)[feat_cols].mean()

    prior_map = {
        str(k): grouped.loc[k].values.astype(np.float32)
        for k in grouped.index
    }

    missing = [
        lab for lab in label_encoder.classes_
        if lab not in prior_map
    ]

    if len(missing) > 0:
        raise ValueError(
            f"PROTO_FILE missing refined prototypes for these subtype labels: {missing[:10]}"
        )

    matrix = np.stack(
        [prior_map[lab] for lab in label_encoder.classes_],
        axis=0,
    ).astype(np.float32)

    return matrix, feat_cols


# =========================================================
# 5. LOSS AND MODEL
# =========================================================

class WeightedFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=1.5, label_smoothing=0.02):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    def forward(self, logits, targets):
        ce_loss = nn.functional.cross_entropy(
            logits,
            targets,
            weight=self.weight,
            reduction="none",
            label_smoothing=self.label_smoothing,
        )

        pt = torch.exp(-ce_loss)
        focal_loss = ((1.0 - pt) ** self.gamma) * ce_loss

        return focal_loss.mean()


class FusionPrototypeClassifier(nn.Module):
    def __init__(self, input_dim, proto_dim, num_classes, prototype_init=None, scale=22.0):
        super().__init__()

        self.projector = nn.Sequential(
            nn.Linear(input_dim, 768),
            nn.LayerNorm(768),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(768, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(512, proto_dim),
            nn.LayerNorm(proto_dim),
        )

        if prototype_init is not None:
            self.prototype = nn.Parameter(
                torch.tensor(prototype_init, dtype=torch.float32)
            )
        else:
            self.prototype = nn.Parameter(
                torch.randn(num_classes, proto_dim)
            )

        self.scale = scale

    def forward(self, x, return_embed=False):
        z = self.projector(x)
        z = nn.functional.normalize(z, p=2, dim=1)

        p = nn.functional.normalize(self.prototype, p=2, dim=1)
        logits = self.scale * (z @ p.t())

        if return_embed:
            return z, logits

        return logits


class ProteinToFusionMapper(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(in_dim, 1536),
            nn.LayerNorm(1536),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1536, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1024, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(0.1),

            nn.Linear(1024, out_dim),
        )

    def forward(self, x):
        return self.net(x)


class PriorProjector(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        if in_dim == out_dim:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.proj(x)


# =========================================================
# 6. DATA LOADING
# =========================================================

def read_embedding_file(file_path, percentage, modality, prefix):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Missing file: {file_path}")

    df = pd.read_csv(file_path)
    key_col = find_key_col(df, KEY_CANDIDATES)

    if key_col is None:
        raise ValueError(f"No key column found in file: {file_path}")

    df[key_col] = df[key_col].astype(str).str.strip()

    df = clean_label_columns(df)

    dup_n = df[key_col].duplicated().sum()
    if dup_n > 0:
        print(f"Warning: {file_path} has {dup_n} duplicated keys. Keep first occurrence.")
        df = df.drop_duplicates(subset=[key_col], keep="first").copy()

    df = df.rename(columns={key_col: "KEY"})
    df["KEY"] = df["KEY"].astype(str).str.strip()
    df["BASE_KEY"] = df["KEY"].apply(get_base_key)
    df["PERCENTAGE"] = percentage
    df["SOURCE"] = modality

    feature_cols_raw = get_feature_cols(df)

    if len(feature_cols_raw) == 0:
        raise ValueError(f"No numeric feature columns found in file: {file_path}")

    df, feature_cols_prefixed = prefix_feature_columns(df, feature_cols_raw, prefix)

    keep_cols = [
        "KEY", "BASE_KEY", "PERCENTAGE", "SOURCE",
        TYPE_COL, LABEL_COL,
    ] + feature_cols_prefixed

    df = df[keep_cols].copy()

    return df, feature_cols_raw, feature_cols_prefixed


def load_all_data():
    print("=" * 80)
    print("Loading train/test split and prototype")
    print("=" * 80)

    train_split_df = pd.read_csv(TRAIN_SPLIT_FILE)
    test_split_df = pd.read_csv(TEST_SPLIT_FILE)
    proto_ref = pd.read_csv(PROTO_FILE)

    train_key = find_key_col(train_split_df, KEY_CANDIDATES)
    test_key = find_key_col(test_split_df, KEY_CANDIDATES)

    if train_key is None:
        raise ValueError("TRAIN_SPLIT_FILE has no key column.")

    if test_key is None:
        raise ValueError("TEST_SPLIT_FILE has no key column.")

    train_split_df = clean_label_columns(train_split_df)
    test_split_df = clean_label_columns(test_split_df)

    train_split_df[train_key] = train_split_df[train_key].astype(str).str.strip()
    test_split_df[test_key] = test_split_df[test_key].astype(str).str.strip()

    train_base_keys = set(train_split_df[train_key].astype(str).values)
    test_base_keys = set(test_split_df[test_key].astype(str).values)

    print("Train base IDs:", len(train_base_keys))
    print("Test base IDs:", len(test_base_keys))
    print("Prototype shape:", proto_ref.shape)

    print()
    print("=" * 80)
    print("Loading percentage fusion and protein files")
    print("=" * 80)

    fusion_train_list = []
    mapper_train_pair_list = []
    eval_pair_by_percentage = {}

    fusion_feature_raw_ref = None
    fusion_feature_pref_ref = None

    protein_feature_raw_ref = None
    protein_feature_pref_ref = None

    for pct in FUSION_FILES.keys():
        print("-" * 80)
        print("Percentage:", pct)
        print("-" * 80)

        fusion_df, fusion_raw_cols, fusion_pref_cols = read_embedding_file(
            file_path=FUSION_FILES[pct],
            percentage=pct,
            modality="fusion",
            prefix="FUS__",
        )

        protein_df, protein_raw_cols, protein_pref_cols = read_embedding_file(
            file_path=PROTEIN_FILES[pct],
            percentage=pct,
            modality="protein",
            prefix="PROT__",
        )

        if fusion_feature_raw_ref is None:
            fusion_feature_raw_ref = fusion_raw_cols
            fusion_feature_pref_ref = fusion_pref_cols
        else:
            if len(fusion_raw_cols) != len(fusion_feature_raw_ref):
                raise ValueError(f"Fusion feature dimension mismatch at {pct}")

        if protein_feature_raw_ref is None:
            protein_feature_raw_ref = protein_raw_cols
            protein_feature_pref_ref = protein_pref_cols
        else:
            if len(protein_raw_cols) != len(protein_feature_raw_ref):
                raise ValueError(f"Protein feature dimension mismatch at {pct}")

        print("Fusion shape:", fusion_df.shape)
        print("Protein shape:", protein_df.shape)
        print("Fusion feature dim:", len(fusion_pref_cols))
        print("Protein feature dim:", len(protein_pref_cols))

        fusion_train_df = fusion_df[fusion_df["BASE_KEY"].isin(train_base_keys)].copy()
        fusion_test_df = fusion_df[fusion_df["BASE_KEY"].isin(test_base_keys)].copy()

        protein_train_df = protein_df[protein_df["BASE_KEY"].isin(train_base_keys)].copy()
        protein_test_df = protein_df[protein_df["BASE_KEY"].isin(test_base_keys)].copy()

        if MAX_TRAIN_ROWS_PER_PERCENT is not None:
            if len(fusion_train_df) > MAX_TRAIN_ROWS_PER_PERCENT:
                fusion_train_df = fusion_train_df.sample(
                    n=MAX_TRAIN_ROWS_PER_PERCENT,
                    random_state=SEED,
                ).copy()

            if len(protein_train_df) > MAX_TRAIN_ROWS_PER_PERCENT:
                protein_train_df = protein_train_df.sample(
                    n=MAX_TRAIN_ROWS_PER_PERCENT,
                    random_state=SEED,
                ).copy()

        if MAX_TEST_ROWS_PER_PERCENT is not None:
            if len(fusion_test_df) > MAX_TEST_ROWS_PER_PERCENT:
                fusion_test_df = fusion_test_df.sample(
                    n=MAX_TEST_ROWS_PER_PERCENT,
                    random_state=SEED,
                ).copy()

            if len(protein_test_df) > MAX_TEST_ROWS_PER_PERCENT:
                protein_test_df = protein_test_df.sample(
                    n=MAX_TEST_ROWS_PER_PERCENT,
                    random_state=SEED,
                ).copy()

        print("Fusion train:", len(fusion_train_df))
        print("Fusion test:", len(fusion_test_df))
        print("Protein train:", len(protein_train_df))
        print("Protein test:", len(protein_test_df))

        fusion_train_list.append(fusion_train_df)

        # Mapper training pair:
        # protein KEY must match fusion KEY under the same percentage.
        pair_train_df = pd.merge(
            protein_train_df[
                ["KEY", "BASE_KEY", "PERCENTAGE", TYPE_COL, LABEL_COL] + protein_pref_cols
            ],
            fusion_train_df[
                ["KEY", "BASE_KEY"] + fusion_pref_cols
            ],
            on=["KEY", "BASE_KEY"],
            how="inner",
        )

        pair_test_df = pd.merge(
            protein_test_df[
                ["KEY", "BASE_KEY", "PERCENTAGE", TYPE_COL, LABEL_COL] + protein_pref_cols
            ],
            fusion_test_df[
                ["KEY", "BASE_KEY"] + fusion_pref_cols
            ],
            on=["KEY", "BASE_KEY"],
            how="inner",
        )

        print("Paired train protein-fusion:", len(pair_train_df))
        print("Paired test protein-fusion:", len(pair_test_df))

        if len(pair_train_df) == 0:
            raise ValueError(f"{pct}: paired train protein-fusion is empty.")

        if len(pair_test_df) == 0:
            raise ValueError(f"{pct}: paired test protein-fusion is empty.")

        mapper_train_pair_list.append(pair_train_df)
        eval_pair_by_percentage[pct] = pair_test_df

        del fusion_df, protein_df
        gc.collect()

    train_fusion_all = pd.concat(fusion_train_list, axis=0, ignore_index=True)
    train_mapper_pair_all = pd.concat(mapper_train_pair_list, axis=0, ignore_index=True)

    print()
    print("=" * 80)
    print("Loaded all data")
    print("=" * 80)
    print("Train fusion all:", train_fusion_all.shape)
    print("Train mapper pair all:", train_mapper_pair_all.shape)
    print("Train fusion percentage counts:")
    print(train_fusion_all["PERCENTAGE"].value_counts())
    print("Train mapper percentage counts:")
    print(train_mapper_pair_all["PERCENTAGE"].value_counts())

    return (
        train_fusion_all,
        train_mapper_pair_all,
        eval_pair_by_percentage,
        proto_ref,
        fusion_feature_raw_ref,
        fusion_feature_pref_ref,
        protein_feature_raw_ref,
        protein_feature_pref_ref,
    )


# =========================================================
# 7. BASE-ID AGGREGATION
# =========================================================

def majority_vote_with_confidence(group, pred_col, conf_col):
    tmp = (
        group
        .groupby(pred_col)[conf_col]
        .agg(["count", "mean"])
        .reset_index()
        .sort_values(["count", "mean"], ascending=[False, False])
    )

    return tmp.iloc[0][pred_col]


def first_unique_value(group, col):
    values = group[col].dropna().astype(str).unique()

    if len(values) == 0:
        return "UNKNOWN"

    return values[0]


def aggregate_to_base_id(fragment_df, subtype_to_type):
    rows = []

    for base_id, group in fragment_df.groupby("base_id", sort=False):
        true_type = first_unique_value(group, "true_type")
        true_subtype = first_unique_value(group, "true_subtype")

        pred_subtype = majority_vote_with_confidence(
            group=group,
            pred_col="pred_subtype",
            conf_col="confidence",
        )

        pred_type = extract_type_from_subtype_label(
            pred_subtype,
            subtype_to_type=subtype_to_type,
        )

        n_fragments = len(group)
        mean_confidence = float(group["confidence"].mean())
        max_confidence = float(group["confidence"].max())

        subtype_vote_count = int((group["pred_subtype"] == pred_subtype).sum())
        type_vote_count = int((group["pred_type"] == pred_type).sum())

        rows.append({
            "base_id": base_id,
            "n_fragments": n_fragments,
            "true_type": true_type,
            "true_subtype": true_subtype,
            "pred_type": pred_type,
            "pred_subtype": pred_subtype,
            "mean_confidence": mean_confidence,
            "max_confidence": max_confidence,
            "subtype_vote_count": subtype_vote_count,
            "type_vote_count": type_vote_count,
            "correct_type": true_type == pred_type,
            "correct_subtype": true_subtype == pred_subtype,
        })

    return pd.DataFrame(rows)


# =========================================================
# 8. BATCH PREDICTION
# =========================================================

def predict_protein_through_mapper(
    protein_matrix_scaled,
    mapper,
    classifier,
    batch_size=4096,
):
    dataset = TensorDataset(
        torch.tensor(protein_matrix_scaled, dtype=torch.float32)
    )

    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        pin_memory=PIN_MEMORY,
        num_workers=NUM_WORKERS,
    )

    pred_indices = []
    pred_probs = []

    mapper.eval()
    classifier.eval()

    with torch.no_grad():
        for (xb,) in loader:
            xb = xb.to(DEVICE, non_blocking=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xb)
                logits = classifier(xf_hat)
                probs = torch.softmax(logits, dim=1)

            max_probs, preds = torch.max(probs, dim=1)

            pred_indices.append(preds.cpu().numpy())
            pred_probs.append(max_probs.cpu().numpy())

    pred_indices = np.concatenate(pred_indices)
    pred_probs = np.concatenate(pred_probs)

    return pred_indices, pred_probs


def evaluate_one_percentage(
    pct,
    pair_df,
    mapper,
    classifier,
    scaler_protein,
    label_encoder,
    protein_feature_cols,
    subtype_to_type,
):
    print("=" * 80)
    print(f"Evaluating percentage: {pct}")
    print("=" * 80)

    valid_labels = set(label_encoder.classes_)

    pair_df = pair_df[pair_df[LABEL_COL].astype(str).isin(valid_labels)].copy()

    if len(pair_df) == 0:
        raise ValueError(f"{pct}: no valid test samples after label filtering.")

    X_protein = to_float_matrix(pair_df, protein_feature_cols)
    X_protein_s = scaler_protein.transform(X_protein).astype(np.float32)

    y_true_label = pair_df[LABEL_COL].astype(str).values
    y_true = label_encoder.transform(y_true_label).astype(np.int64)

    pred_indices, pred_confidence = predict_protein_through_mapper(
        protein_matrix_scaled=X_protein_s,
        mapper=mapper,
        classifier=classifier,
        batch_size=4096,
    )

    pred_subtypes = label_encoder.inverse_transform(pred_indices)
    pred_types = [
        extract_type_from_subtype_label(x, subtype_to_type=subtype_to_type)
        for x in pred_subtypes
    ]

    true_types = pair_df[TYPE_COL].astype(str).values
    true_subtypes = pair_df[LABEL_COL].astype(str).values

    fragment_df = pd.DataFrame({
        "id": pair_df["KEY"].astype(str).values,
        "base_id": pair_df["BASE_KEY"].astype(str).values,
        "percentage": pct,
        "true_type": true_types,
        "true_subtype": true_subtypes,
        "pred_type": pred_types,
        "pred_subtype": pred_subtypes,
        "confidence": pred_confidence,
        "correct_type": true_types == np.array(pred_types),
        "correct_subtype": true_subtypes == np.array(pred_subtypes),
    })

    fragment_out = RESULT_DIR / f"prediction_detail_{pct}.csv"
    fragment_df.to_csv(fragment_out, index=False, encoding="utf-8-sig")

    base_df = aggregate_to_base_id(fragment_df, subtype_to_type=subtype_to_type)

    base_out = RESULT_DIR / f"prediction_baseid_{pct}.csv"
    base_df.to_csv(base_out, index=False, encoding="utf-8-sig")

    fragment_subtype_metrics = compute_overall_metrics(
        fragment_df["true_subtype"].values,
        fragment_df["pred_subtype"].values,
    )

    fragment_type_metrics = compute_overall_metrics(
        fragment_df["true_type"].values,
        fragment_df["pred_type"].values,
    )

    base_subtype_metrics = compute_overall_metrics(
        base_df["true_subtype"].values,
        base_df["pred_subtype"].values,
    )

    base_type_metrics = compute_overall_metrics(
        base_df["true_type"].values,
        base_df["pred_type"].values,
    )

    save_classification_report(
        fragment_df["true_subtype"].values,
        fragment_df["pred_subtype"].values,
        RESULT_DIR / f"classification_report_fragment_subtype_{pct}.csv",
    )

    save_classification_report(
        fragment_df["true_type"].values,
        fragment_df["pred_type"].values,
        RESULT_DIR / f"classification_report_fragment_type_{pct}.csv",
    )

    save_classification_report(
        base_df["true_subtype"].values,
        base_df["pred_subtype"].values,
        RESULT_DIR / f"classification_report_baseid_subtype_{pct}.csv",
    )

    save_classification_report(
        base_df["true_type"].values,
        base_df["pred_type"].values,
        RESULT_DIR / f"classification_report_baseid_type_{pct}.csv",
    )

    per_class_fragment_subtype_df = compute_per_class_metrics(
        y_true=label_encoder.transform(fragment_df["true_subtype"].values),
        y_pred=label_encoder.transform(fragment_df["pred_subtype"].values),
        class_names=label_encoder.classes_,
        label_name=LABEL_COL,
        split_name=f"{pct}_fragment",
        split_sample_count=len(fragment_df),
        split_class_count=fragment_df["true_subtype"].nunique(),
    )

    per_class_fragment_subtype_df.to_csv(
        RESULT_DIR / f"per_class_fragment_subtype_{pct}.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary_row = {
        "percentage": pct,
        "n_fragments": len(fragment_df),
        "n_base_ids": len(base_df),
        "mean_fragments_per_base_id": round(len(fragment_df) / max(len(base_df), 1), 4),
    }

    for k, v in fragment_subtype_metrics.items():
        summary_row[f"fragment_subtype_{k}"] = v

    for k, v in fragment_type_metrics.items():
        summary_row[f"fragment_type_{k}"] = v

    for k, v in base_subtype_metrics.items():
        summary_row[f"baseid_subtype_{k}"] = v

    for k, v in base_type_metrics.items():
        summary_row[f"baseid_type_{k}"] = v

    print(f"\n[{pct}] Fragment-level subtype ACC: {fragment_subtype_metrics['ACC']:.4f}")
    print(f"[{pct}] Fragment-level type ACC:    {fragment_type_metrics['ACC']:.4f}")
    print(f"[{pct}] Base-ID-level subtype ACC:  {base_subtype_metrics['ACC']:.4f}")
    print(f"[{pct}] Base-ID-level type ACC:     {base_type_metrics['ACC']:.4f}")
    print()

    return summary_row


# =========================================================
# 9. MAIN
# =========================================================

def main():
    seed_everything(SEED)

    print("=" * 80)
    print("ARGScope FusionTeacher + ProteinStudent percentage training")
    print("=" * 80)
    print("Using device:", DEVICE)

    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("CUDA:", torch.version.cuda)

    (
        train_fusion_all,
        train_mapper_pair_all,
        eval_pair_by_percentage,
        proto_ref,
        fusion_feature_raw_cols,
        fusion_feature_cols,
        protein_feature_raw_cols,
        protein_feature_cols,
    ) = load_all_data()

    # =====================================================
    # Label and subtype filtering
    # =====================================================

    print()
    print("=" * 80)
    print("Subtype filtering and LabelEncoder")
    print("=" * 80)

    proto_ref[LABEL_COL] = proto_ref[LABEL_COL].astype(str)

    valid_subtypes_in_proto = set(proto_ref[LABEL_COL].astype(str).unique())
    valid_subtypes_in_train = set(train_fusion_all[LABEL_COL].astype(str).unique())

    valid_subtypes = sorted(valid_subtypes_in_proto & valid_subtypes_in_train)

    print("Valid subtypes in prototype:", len(valid_subtypes_in_proto))
    print("Valid subtypes in train fusion:", len(valid_subtypes_in_train))
    print("Common valid subtypes:", len(valid_subtypes))

    train_fusion_all = train_fusion_all[
        train_fusion_all[LABEL_COL].astype(str).isin(valid_subtypes)
    ].copy()

    train_mapper_pair_all = train_mapper_pair_all[
        train_mapper_pair_all[LABEL_COL].astype(str).isin(valid_subtypes)
    ].copy()

    proto_ref = proto_ref[
        proto_ref[LABEL_COL].astype(str).isin(valid_subtypes)
    ].copy()

    if len(train_fusion_all) == 0:
        raise ValueError("train_fusion_all is empty after subtype filtering.")

    if len(train_mapper_pair_all) == 0:
        raise ValueError("train_mapper_pair_all is empty after subtype filtering.")

    le = LabelEncoder()
    le.fit(valid_subtypes)

    num_classes = len(le.classes_)

    subtype_to_type = build_subtype_to_type_map(train_fusion_all)

    print("Final class number:", num_classes)
    print("Train fusion samples:", len(train_fusion_all))
    print("Train mapper samples:", len(train_mapper_pair_all))

    # =====================================================
    # Feature matrices and scalers
    # =====================================================

    print()
    print("=" * 80)
    print("Preparing feature matrices")
    print("=" * 80)

    X_train_fusion = to_float_matrix(train_fusion_all, fusion_feature_cols)
    y_train_classifier = le.transform(
        train_fusion_all[LABEL_COL].astype(str).values
    ).astype(np.int64)

    X_mapper_protein = to_float_matrix(train_mapper_pair_all, protein_feature_cols)
    X_mapper_fusion = to_float_matrix(train_mapper_pair_all, fusion_feature_cols)
    y_train_mapper = le.transform(
        train_mapper_pair_all[LABEL_COL].astype(str).values
    ).astype(np.int64)

    scaler_fusion = StandardScaler()
    scaler_protein = StandardScaler()

    X_train_fusion_s = scaler_fusion.fit_transform(X_train_fusion).astype(np.float32)
    X_mapper_fusion_s = scaler_fusion.transform(X_mapper_fusion).astype(np.float32)

    X_mapper_protein_s = scaler_protein.fit_transform(X_mapper_protein).astype(np.float32)

    input_dim_fusion = X_train_fusion_s.shape[1]
    input_dim_protein = X_mapper_protein_s.shape[1]

    print("Fusion feature dim:", input_dim_fusion)
    print("Protein feature dim:", input_dim_protein)

    prior_matrix_raw, prior_feature_cols = build_prior_matrix(proto_ref, LABEL_COL, le)
    prior_dim = prior_matrix_raw.shape[1]

    prior_tensor = torch.tensor(
        prior_matrix_raw,
        dtype=torch.float32,
        device=DEVICE,
    )

    print("Prior/prototype dim:", prior_dim)

    # =====================================================
    # DataLoaders
    # =====================================================

    train_classifier_loader = DataLoader(
        TensorDataset(
            torch.tensor(X_train_fusion_s, dtype=torch.float32),
            torch.tensor(y_train_classifier, dtype=torch.long),
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=PIN_MEMORY,
        num_workers=NUM_WORKERS,
    )

    train_mapper_loader = DataLoader(
        TensorDataset(
            torch.tensor(X_mapper_protein_s, dtype=torch.float32),
            torch.tensor(X_mapper_fusion_s, dtype=torch.float32),
            torch.tensor(y_train_mapper, dtype=torch.long),
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=PIN_MEMORY,
        num_workers=NUM_WORKERS,
    )

    # =====================================================
    # Model initialization
    # =====================================================

    PROTO_DIM = prior_dim

    classifier = FusionPrototypeClassifier(
        input_dim=input_dim_fusion,
        proto_dim=PROTO_DIM,
        num_classes=num_classes,
        prototype_init=prior_matrix_raw,
        scale=SCALE,
    ).to(DEVICE)

    mapper = ProteinToFusionMapper(
        in_dim=input_dim_protein,
        out_dim=input_dim_fusion,
    ).to(DEVICE)

    prior_proj = PriorProjector(
        in_dim=prior_dim,
        out_dim=PROTO_DIM,
    ).to(DEVICE)

    print("Classifier device:", next(classifier.parameters()).device)
    print("Mapper device:", next(mapper.parameters()).device)

    prior_params = list(prior_proj.parameters())
    if len(prior_params) > 0:
        print("PriorProjector device:", prior_params[0].device)
    else:
        print("PriorProjector device: no parameters (Identity)")

    # =====================================================
    # Loss, optimizer, scheduler
    # =====================================================

    class_counts = np.bincount(y_train_classifier, minlength=num_classes).astype(np.float32)

    beta = 0.995
    effective_num = 1.0 - np.power(beta, class_counts)
    class_weights = (1.0 - beta) / (effective_num + 1e-8)

    class_weights = class_weights / class_weights.mean()
    class_weights = np.clip(class_weights, 0.5, 3.0)

    class_weights = torch.tensor(
        class_weights,
        dtype=torch.float32,
        device=DEVICE,
    )

    criterion_ce = WeightedFocalLoss(
        weight=class_weights,
        gamma=1.5,
        label_smoothing=0.02,
    )

    criterion_mse = nn.MSELoss()

    optimizer_c = optim.AdamW(
        list(classifier.parameters()) + list(prior_proj.parameters()),
        lr=LR_C,
        weight_decay=WEIGHT_DECAY,
    )

    optimizer_m = optim.AdamW(
        mapper.parameters(),
        lr=LR_M,
        weight_decay=WEIGHT_DECAY,
    )

    scheduler_c = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_c,
        mode="min",
        factor=0.5,
        patience=15,
    )

    scheduler_m = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer_m,
        mode="min",
        factor=0.5,
        patience=15,
    )

    scaler_amp_c = torch.amp.GradScaler("cuda", enabled=USE_AMP)
    scaler_amp_m = torch.amp.GradScaler("cuda", enabled=USE_AMP)

    # =====================================================
    # Train fusion classifier
    # =====================================================

    print()
    print("=" * 80)
    print("Starting classifier training on multi-percentage fusion embeddings")
    print("=" * 80)

    best_loss_c = float("inf")
    best_classifier_state = None
    best_prior_proj_state = None
    no_improve_c = 0

    for epoch in range(1, MAX_EPOCHS_C + 1):
        classifier.train()
        prior_proj.train()

        total_loss = 0.0

        for xb, yb in train_classifier_loader:
            xb = xb.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer_c.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                logits = classifier(xb)
                loss_ce = criterion_ce(logits, yb)

                prior_proj_mat = prior_proj(prior_tensor)

                proto_now = nn.functional.normalize(
                    classifier.prototype,
                    p=2,
                    dim=1,
                )

                proto_ref = nn.functional.normalize(
                    prior_proj_mat,
                    p=2,
                    dim=1,
                )

                loss_proto = 1.0 - torch.mean(torch.sum(proto_now * proto_ref, dim=1))
                loss = loss_ce + LAMBDA_PROTO * loss_proto

            scaler_amp_c.scale(loss).backward()
            scaler_amp_c.unscale_(optimizer_c)

            torch.nn.utils.clip_grad_norm_(
                list(classifier.parameters()) + list(prior_proj.parameters()),
                1.0,
            )

            scaler_amp_c.step(optimizer_c)
            scaler_amp_c.update()

            total_loss += loss.item() * xb.size(0)

        avg_loss = total_loss / len(train_classifier_loader.dataset)
        scheduler_c.step(avg_loss)

        if avg_loss < best_loss_c - MIN_DELTA:
            best_loss_c = avg_loss
            best_classifier_state = {
                k: v.detach().cpu().clone()
                for k, v in classifier.state_dict().items()
            }
            best_prior_proj_state = {
                k: v.detach().cpu().clone()
                for k, v in prior_proj.state_dict().items()
            }
            no_improve_c = 0
        else:
            no_improve_c += 1

        if epoch % 10 == 0 or epoch == 1 or epoch == MAX_EPOCHS_C:
            lr_now = optimizer_c.param_groups[0]["lr"]
            print(f"[Classifier] Epoch {epoch:03d} | lr={lr_now:.2e} | loss={avg_loss:.4f}")

        if no_improve_c >= EARLY_STOP_PATIENCE_C:
            print(f"[Classifier] Early stopping at epoch {epoch}, best loss={best_loss_c:.4f}")
            break

    if best_classifier_state is not None:
        classifier.load_state_dict(best_classifier_state)
        classifier = classifier.to(DEVICE)
        print(f"Loaded best classifier state, best loss={best_loss_c:.4f}")

    if best_prior_proj_state is not None:
        prior_proj.load_state_dict(best_prior_proj_state)
        prior_proj = prior_proj.to(DEVICE)
        print("Loaded best prior projector state.")

    for p in classifier.parameters():
        p.requires_grad = False

    classifier.eval()
    prior_proj.eval()

    # =====================================================
    # Train protein -> fusion mapper
    # =====================================================

    print()
    print("=" * 80)
    print("Starting mapper training: multi-percentage protein -> matched fusion")
    print("=" * 80)

    best_loss_m = float("inf")
    best_mapper_state = None
    no_improve_m = 0

    for epoch in range(1, MAX_EPOCHS_M + 1):
        mapper.train()

        total_loss = 0.0

        for xp, xf_t, yb in train_mapper_loader:
            xp = xp.to(DEVICE, non_blocking=True)
            xf_t = xf_t.to(DEVICE, non_blocking=True)
            yb = yb.to(DEVICE, non_blocking=True)

            optimizer_m.zero_grad(set_to_none=True)

            with torch.amp.autocast("cuda", enabled=USE_AMP):
                xf_hat = mapper(xp)

                loss_mse = criterion_mse(xf_hat, xf_t)

                logits = classifier(xf_hat)
                loss_ce = criterion_ce(logits, yb)

                z_hat, _ = classifier(xf_hat, return_embed=True)

                prior_batch = prior_proj(prior_tensor[yb])
                prior_batch = nn.functional.normalize(prior_batch, p=2, dim=1)

                loss_prior = 1.0 - torch.mean(torch.sum(z_hat * prior_batch, dim=1))

                loss = (
                    LAMBDA_MSE * loss_mse
                    + LAMBDA_CE * loss_ce
                    + LAMBDA_PRIOR * loss_prior
                )

            scaler_amp_m.scale(loss).backward()
            scaler_amp_m.unscale_(optimizer_m)

            torch.nn.utils.clip_grad_norm_(
                mapper.parameters(),
                1.0,
            )

            scaler_amp_m.step(optimizer_m)
            scaler_amp_m.update()

            total_loss += loss.item() * xp.size(0)

        avg_loss = total_loss / len(train_mapper_loader.dataset)
        scheduler_m.step(avg_loss)

        if avg_loss < best_loss_m - MIN_DELTA:
            best_loss_m = avg_loss
            best_mapper_state = {
                k: v.detach().cpu().clone()
                for k, v in mapper.state_dict().items()
            }
            no_improve_m = 0
        else:
            no_improve_m += 1

        if epoch % 10 == 0 or epoch == 1 or epoch == MAX_EPOCHS_M:
            lr_now = optimizer_m.param_groups[0]["lr"]
            print(f"[Mapper] Epoch {epoch:03d} | lr={lr_now:.2e} | loss={avg_loss:.4f}")

        if no_improve_m >= EARLY_STOP_PATIENCE_M:
            print(f"[Mapper] Early stopping at epoch {epoch}, best loss={best_loss_m:.4f}")
            break

    if best_mapper_state is not None:
        mapper.load_state_dict(best_mapper_state)
        mapper = mapper.to(DEVICE)
        print(f"Loaded best mapper state, best loss={best_loss_m:.4f}")

    mapper.eval()

    # =====================================================
    # Evaluate each percentage protein file
    # =====================================================

    print()
    print("=" * 80)
    print("Evaluating protein-only input for each percentage")
    print("=" * 80)

    all_summary = []

    for pct, pair_df in eval_pair_by_percentage.items():
        row = evaluate_one_percentage(
            pct=pct,
            pair_df=pair_df,
            mapper=mapper,
            classifier=classifier,
            scaler_protein=scaler_protein,
            label_encoder=le,
            protein_feature_cols=protein_feature_cols,
            subtype_to_type=subtype_to_type,
        )
        all_summary.append(row)

    summary_df = pd.DataFrame(all_summary)

    metric_cols = [
        c for c in summary_df.columns
        if c not in ["percentage", "n_fragments", "n_base_ids"]
    ]

    for c in metric_cols:
        summary_df[c] = summary_df[c].astype(float).round(4)

    summary_out = RESULT_DIR / "summary_metrics_all.csv"
    summary_df.to_csv(summary_out, index=False, encoding="utf-8-sig")

    print()
    print("=" * 80)
    print("Summary")
    print("=" * 80)
    print(summary_df)
    print("Saved:", summary_out)

    # =====================================================
    # Save model and preprocessing objects
    # =====================================================

    print()
    print("=" * 80)
    print("Saving model checkpoint and preprocessing objects")
    print("=" * 80)

    checkpoint = {
        "model_name": "ARGScope_subtype_FusionTeacher_ProteinStudent_percentage",

        "classifier_state_dict": classifier.state_dict(),
        "mapper_state_dict": mapper.state_dict(),
        "prior_proj_state_dict": prior_proj.state_dict(),

        "input_dim_fusion": int(input_dim_fusion),
        "input_dim_protein": int(input_dim_protein),
        "proto_dim": int(PROTO_DIM),
        "prior_dim": int(prior_dim),
        "num_classes": int(num_classes),
        "scale": float(SCALE),

        "label_col": LABEL_COL,
        "label_classes": le.classes_.tolist(),

        "fusion_feature_raw_cols": fusion_feature_raw_cols,
        "fusion_feature_cols": fusion_feature_cols,
        "protein_feature_raw_cols": protein_feature_raw_cols,
        "protein_feature_cols": protein_feature_cols,
        "prior_feature_cols": prior_feature_cols,

        "training_files": {
            "fusion_files": FUSION_FILES,
            "protein_files": PROTEIN_FILES,
            "train_split_file": TRAIN_SPLIT_FILE,
            "test_split_file": TEST_SPLIT_FILE,
            "proto_file": PROTO_FILE,
        },

        "hyperparameters": {
            "seed": SEED,
            "batch_size": BATCH_SIZE,
            "max_epochs_classifier": MAX_EPOCHS_C,
            "max_epochs_mapper": MAX_EPOCHS_M,
            "lr_classifier": LR_C,
            "lr_mapper": LR_M,
            "weight_decay": WEIGHT_DECAY,
            "lambda_mse": LAMBDA_MSE,
            "lambda_ce": LAMBDA_CE,
            "lambda_prior": LAMBDA_PRIOR,
            "lambda_proto": LAMBDA_PROTO,
            "scale": SCALE,
        },

        "best_losses": {
            "classifier_best_loss": float(best_loss_c),
            "mapper_best_loss": float(best_loss_m),
        },

        "summary_metrics": summary_df.to_dict(orient="records"),
    }

    torch.save(checkpoint, CHECKPOINT_FILE)

    joblib.dump(scaler_fusion, SCALER_FUSION_FILE)
    joblib.dump(scaler_protein, SCALER_PROTEIN_FILE)
    joblib.dump(le, LABEL_ENCODER_FILE)

    feature_info = {
        "fusion_feature_raw_cols": fusion_feature_raw_cols,
        "fusion_feature_cols": fusion_feature_cols,
        "protein_feature_raw_cols": protein_feature_raw_cols,
        "protein_feature_cols": protein_feature_cols,
        "prior_feature_cols": prior_feature_cols,
        "input_dim_fusion": int(input_dim_fusion),
        "input_dim_protein": int(input_dim_protein),
        "prior_dim": int(prior_dim),
        "proto_dim": int(PROTO_DIM),
        "num_classes": int(num_classes),
        "label_classes": le.classes_.tolist(),
        "subtype_to_type": subtype_to_type,
    }

    joblib.dump(feature_info, FEATURE_INFO_FILE)

    class_info_df = pd.DataFrame({
        "class_id": list(range(len(le.classes_))),
        "Subtype": le.classes_,
        "Type": [
            extract_type_from_subtype_label(x, subtype_to_type=subtype_to_type)
            for x in le.classes_
        ],
    })

    class_info_df.to_csv(
        CLASS_INFO_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print("Model and preprocessing objects saved:")
    print(" -", CHECKPOINT_FILE)
    print(" -", SCALER_FUSION_FILE)
    print(" -", SCALER_PROTEIN_FILE)
    print(" -", LABEL_ENCODER_FILE)
    print(" -", FEATURE_INFO_FILE)
    print(" -", CLASS_INFO_FILE)
    print(" -", RESULT_DIR)
    print("Done.")


if __name__ == "__main__":
    mp.freeze_support()
    main()