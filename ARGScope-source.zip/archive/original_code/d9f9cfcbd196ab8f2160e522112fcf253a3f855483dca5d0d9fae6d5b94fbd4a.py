#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Calculate Full Protein/DNA test metrics; Python standard library only.

Put beside protein/ and dna/, or inside a direct child results folder.
Run directly or: python calculate_full_metrics.py --root PATH
No training, threshold changes, row filtering, or source-file modifications.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

METRICS = ("Accuracy", "Precision", "Recall", "F1", "MCC")
NONARG = "nonARG"
REQUIRED = {"sequence_id", "true_subtype", "predicted_subtype", "true_type",
            "predicted_type", "true_ARG", "predicted_ARG"}


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError(f"Missing or duplicate CSV columns: {path}")
        rows = list(reader)
    if not rows or any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError(f"Empty CSV or malformed row: {path}")
    return rows


def write_csv(path, rows):
    if not rows:
        raise ValueError(f"Refusing empty output: {path}")
    with Path(path).open("x", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def divide(a, b):
    return a / b if b else 0.0


def binary_metrics(truth, prediction):
    if not truth or len(truth) != len(prediction) or not set(truth + prediction) <= {0, 1}:
        raise ValueError("Binary metrics require equally sized nonempty 0/1 lists")
    counts = Counter(zip(truth, prediction))
    tp, fn, fp, tn = (counts[1, 1], counts[1, 0], counts[0, 1], counts[0, 0])
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return {"Accuracy": (tp + tn) / len(truth), "Precision": divide(tp, tp + fp),
            "Recall": divide(tp, tp + fn), "F1": divide(2 * tp, 2 * tp + fp + fn),
            "MCC": divide(tp * tn - fp * fn, denominator),
            "TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "Support": tp + fn, "Predicted_positive": tp + fp}


def multiclass_metrics(truth, prediction):
    """Single-label multiclass metrics over union(true, predicted), including nonARG."""
    if not truth or len(truth) != len(prediction):
        raise ValueError("Empty or misaligned labels")
    labels = sorted(set(truth) | set(prediction))
    actual, predicted = Counter(truth), Counter(prediction)
    correct = Counter(t for t, p in zip(truth, prediction) if t == p)
    n, hits = len(truth), sum(correct.values())
    numerator = hits * n - sum(actual[k] * predicted[k] for k in labels)
    denominator = math.sqrt((n * n - sum(predicted[k] ** 2 for k in labels)) *
                            (n * n - sum(actual[k] ** 2 for k in labels)))
    mcc, accuracy = divide(numerator, denominator), hits / n
    per_label = {k: {"Precision": divide(correct[k], predicted[k]),
                     "Recall": divide(correct[k], actual[k]),
                     "F1": divide(2 * correct[k], actual[k] + predicted[k])} for k in labels}
    result = []
    for average in ("macro", "weighted", "micro"):
        row = {"Average": average, "Accuracy": accuracy}
        for metric in ("Precision", "Recall", "F1"):
            if average == "micro":
                row[metric] = accuracy
            elif average == "macro":
                row[metric] = sum(per_label[k][metric] for k in labels) / len(labels)
            else:
                row[metric] = sum(actual[k] * per_label[k][metric] for k in labels) / n
        row["MCC"] = mcc
        result.append(row)
    return result


def parse_binary(value, path, sid):
    if value not in {"0", "1"}:
        raise ValueError(f"Expected 0/1 label: {path} / {sid} / {value!r}")
    return int(value)


def validate_input(root, modality):
    path = root / modality / "test_sequence_predictions.csv"
    rows = read_csv(path)
    if not REQUIRED <= rows[0].keys():
        raise ValueError(f"Missing columns in {path}: {sorted(REQUIRED - rows[0].keys())}")
    ids = [r["sequence_id"] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError(f"Duplicate sequence IDs in {path}; nothing deduplicated automatically")
    mapping = {NONARG: NONARG}
    for r in rows:
        sid = r["sequence_id"]
        for key in REQUIRED:
            value = r[key]
            if not value or value != value.strip():
                raise ValueError(f"Missing label or surrounding whitespace: {sid} / {key}")
        if "split" in r and r["split"] != "test":
            raise ValueError(f"Non-test row in {path}: {sid}")
        for side in ("true", "predicted"):
            subtype, typ = r[f"{side}_subtype"], r[f"{side}_type"]
            binary = parse_binary(r[f"{side}_ARG"], path, sid)
            if binary != int(subtype != NONARG) or binary != int(typ != NONARG):
                raise ValueError(f"Binary / type / subtype disagree: {sid} / {side}")
            if mapping.setdefault(subtype, typ) != typ:
                raise ValueError(f"Conflicting subtype-to-type mapping: {subtype}")
    audit = {"prediction_file": str(path), "prediction_sha256": sha256(path), "N_test": len(rows),
             "N_ARG": sum(r["true_ARG"] == "1" for r in rows),
             "N_nonARG": sum(r["true_ARG"] == "0" for r in rows),
             "ARG_types_in_test": len({r["true_type"] for r in rows} - {NONARG}),
             "ARG_subtypes_in_test": len({r["true_subtype"] for r in rows} - {NONARG}),
             "duplicate_IDs": 0}
    sources = [path]
    manifest_path = path.parent / "split_manifest.csv"
    if manifest_path.exists():
        manifest = read_csv(manifest_path)
        required_manifest = {"sequence_id", "model_split", "external_split"}
        if not required_manifest <= manifest[0].keys():
            raise ValueError(f"Missing manifest columns: {manifest_path}")
        by_id = {r["sequence_id"]: r for r in manifest}
        if len(by_id) != len(manifest):
            raise ValueError("Duplicate IDs across saved train/validation/test")
        subtype_key = "Subtype" if "Subtype" in manifest[0] else "subtype"
        type_key = "Type" if "Type" in manifest[0] else "type"
        if not {subtype_key, type_key} <= manifest[0].keys():
            raise ValueError("Manifest is missing Type/Subtype ground truth")
        for r in manifest:
            if r["model_split"] not in {"train", "validation", "test"}:
                raise ValueError("Unknown model split in manifest")
            if r["external_split"] != ("test" if r["model_split"] == "test" else "train"):
                raise ValueError("Invalid external/model split pairing")
        expected_test = {r["sequence_id"] for r in manifest if r["model_split"] == "test"}
        if set(ids) != expected_test:
            raise ValueError(f"Test IDs differ from saved model manifest: {path}")
        for r in rows:
            ref = by_id[r["sequence_id"]]
            if (r["true_type"], r["true_subtype"]) != (ref[type_key], ref[subtype_key]):
                raise ValueError("Prediction truth differs from saved manifest")
        allowed = {(r[type_key], r[subtype_key]) for r in manifest}
        if any((r["predicted_type"], r["predicted_subtype"]) not in allowed for r in rows):
            raise ValueError("Prediction contains labels outside saved manifest")
        audit.update({"manifest_file": str(manifest_path), "manifest_sha256": sha256(manifest_path),
                      "test_IDs_and_truth_match_manifest": True,
                      "saved_model_split_counts": dict(Counter(r["model_split"] for r in manifest)),
                      "train_validation_test_ID_overlap": 0})
        sources.append(manifest_path)
    else:
        audit["manifest_warning"] = "Manifest absent; metrics use provided predictions without split-provenance verification"
    complete_path = path.parent / "COMPLETE.json"
    if complete_path.exists():
        receipt = json.loads(complete_path.read_text(encoding="utf-8-sig"))
        identity = receipt.get("identity", {})
        if receipt.get("status") != "complete" or identity.get("smoke_test_only") is not False:
            raise ValueError("Incomplete or smoke-only result cannot be reported as formal Full")
        if identity.get("variant") != "full" or identity.get("stage") != modality:
            raise ValueError("Completion marker is not for the requested Full modality")
        for source in sources:
            recorded = receipt.get("outputs", {}).get(source.name)
            if recorded is not None and recorded != sha256(source):
                raise ValueError(f"File changed since completion receipt: {source}")
        audit["completed_run_split_fingerprint"] = identity.get("split_fingerprint")
        sources.append(complete_path)
    audit["input_sha256"] = {str(p): sha256(p) for p in sources}
    return rows, audit


def infer_root():
    here = Path(__file__).resolve().parent
    for folder in (here, here.parent):
        if all((folder / m / "test_sequence_predictions.csv").is_file() for m in ("protein", "dna")):
            return folder
    raise FileNotFoundError("Put this script in full/ or its direct child folder, or supply --root FULL_FOLDER")


def self_test():
    b = binary_metrics([1, 1, 1, 1, 0, 0, 0, 0, 0, 0], [1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    expected = {"Accuracy": .7, "Precision": .6, "Recall": .75, "F1": 2 / 3,
                "MCC": 10 / math.sqrt(600)}
    for k, value in expected.items():
        assert math.isclose(b[k], value, abs_tol=1e-12), k
    rows = multiclass_metrics(["a", "a", "b", "c"], ["a", "b", "b", "b"])
    assert math.isclose(rows[0]["Precision"], 4 / 9)
    assert math.isclose(rows[1]["Precision"], 7 / 12)
    assert math.isclose(rows[2]["Precision"], .5)
    assert all(math.isclose(r["Accuracy"], .5) for r in rows)
    assert binary_metrics([0, 0], [0, 0])["MCC"] == 0.0
    print("SELF TEST PASS")


def calculate(root):
    inputs, audits = {}, {}
    for modality in ("protein", "dna"):
        inputs[modality], audits[modality] = validate_input(root, modality)
    truth = lambda rows: {r["sequence_id"]: (r["true_ARG"], r["true_type"], r["true_subtype"]) for r in rows}
    if truth(inputs["protein"]) != truth(inputs["dna"]):
        raise ValueError("Protein and DNA have different test IDs or truth; no intersection/subsetting performed")
    fingerprints = {a.get("completed_run_split_fingerprint") for a in audits.values()} - {None}
    if len(fingerprints) > 1:
        raise ValueError("Protein/DNA split fingerprints differ")
    binary, types, subtypes, per_type, binary_averages, binary_per_class = [], [], [], [], [], []
    for modality, rows in inputs.items():
        info = {"Model": "Full", "Modality": "Protein" if modality == "protein" else "DNA",
                "Population": "all_test_including_nonARG", "N_test": len(rows)}
        y, p = [int(r["true_ARG"]) for r in rows], [int(r["predicted_ARG"]) for r in rows]
        b = binary_metrics(y, p)
        binary.append({**info, "Average": "binary_ARG_positive", **b})
        for row in multiclass_metrics(y, p):
            binary_averages.append({**info, **row})
        for label, value in (("ARG", 1), ("nonARG", 0)):
            binary_per_class.append({**info, "Positive_class": label,
                                     **binary_metrics([int(t == value) for t in y], [int(t == value) for t in p])})
        for level, destination in (("type", types), ("subtype", subtypes)):
            y_level, p_level = [r[f"true_{level}"] for r in rows], [r[f"predicted_{level}"] for r in rows]
            for row in multiclass_metrics(y_level, p_level):
                destination.append({**info, **row})
        for typ in sorted({r["true_type"] for r in rows} | {r["predicted_type"] for r in rows}):
            per_type.append({**info, "Type": typ, "Average": "one_vs_rest",
                             **binary_metrics([int(r["true_type"] == typ) for r in rows],
                                              [int(r["predicted_type"] == typ) for r in rows])})
    combined = [{"Level": level, **{k: r[k] for k in ("Model", "Modality", "Population", "N_test", "Average", *METRICS)}}
                for level, selected in (("ARG_nonARG", binary), ("Type", types), ("Subtype", subtypes)) for r in selected]
    # All checks finish before an output directory is created.
    for audit in audits.values():
        for path, digest in audit["input_sha256"].items():
            if sha256(path) != digest:
                raise RuntimeError(f"Input changed during calculation: {path}")
    output = root / ("full_metrics_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    output.mkdir(exist_ok=False)
    tables = {"00_Full_all_metrics_summary.csv": combined,
              "01_ARG_nonARG_ARG_positive_five_metrics.csv": binary,
              "02_Type_overall_macro_weighted_micro.csv": types,
              "03_Subtype_overall_macro_weighted_micro.csv": subtypes,
              "04_Per_type_five_metrics.csv": per_type,
              "05_ARG_nonARG_macro_weighted_micro_optional.csv": binary_averages,
              "06_ARG_nonARG_each_class_five_metrics.csv": binary_per_class}
    for name, rows in tables.items():
        write_csv(output / name, rows)
    per_type_dir = output / "per_type"
    per_type_dir.mkdir()
    for typ in sorted({r["Type"] for r in per_type}):
        safe = re.sub(r"[^\w.-]+", "_", typ, flags=re.UNICODE)[:70].strip(" .") or "type"
        name = safe + "_" + hashlib.sha256(typ.encode()).hexdigest()[:8] + ".csv"
        write_csv(per_type_dir / name, [r for r in per_type if r["Type"] == typ])
    notes = {"status": "complete", "created_at": datetime.now().astimezone().isoformat(),
             "script_sha256": sha256(__file__), "source_audits": audits,
             "same_test_IDs_and_truth_between_modalities": True,
             "binary_main_positive_class": "ARG=1; nonARG=0",
             "type_and_subtype_include_nonARG": True,
             "predictions_rethresholded": False, "dropped_rows": 0,
             "overall_Accuracy_and_MCC": "single-label overall metrics, unchanged across averaging rows",
             "macro_label_set": "union of true and predicted labels, including nonARG",
             "per_type_definition": "one-versus-rest on all test sequences; Accuracy=(TP+TN)/N",
             "zero_division": 0, "MCC_zero_denominator_value": 0,
             "numeric_units": "fractions, not percentages; MCC lies in [-1,1]",
             "no_homology_or_sequence_leakage_audit_performed_by_this_metrics_script": True,
             "rows_by_table": {name: len(rows) for name, rows in tables.items()},
             "csv_sha256": {p.relative_to(output).as_posix(): sha256(p) for p in sorted(output.rglob("*.csv"))}}
    with (output / "calculation_audit.json").open("x", encoding="utf-8") as f:
        json.dump(notes, f, indent=2, ensure_ascii=False)
    readme = """Full 指标计算说明

只读取 protein/test_sequence_predictions.csv 和 dna/test_sequence_predictions.csv。
01：ARG 为阳性、nonARG 为阴性；02/03：全部测试序列，包含 nonARG。
02/03 各有 macro、weighted、micro 三行；Accuracy 和 MCC 是全局值，三行相同。
04 和 per_type/：每个 type 对其余类别的一对多二分类；保留 TP、FP、FN、TN。
每个 type 的 Accuracy 包含 TN，不等于该 type 的 Recall，稀有类的此项可能较高。
05：可选的二分类三种平均，不代替 01 的 ARG-positive 指标。
06：分别以 ARG 和 nonARG 为目标类的指标，便于区分两类。
所有指标为小数，非百分数。Precision/Recall/F1 分母为零时按 0 处理。
不修改阈值、不筛选预测正确的 ARG、不丢弃错误预测、不改动原始文件。
不混用训练脚本中的 ARG_Subtype（仅真实 ARG 样本）的指标。
本次只做指标计算，未训练模型，也未重新划分数据。

再次运行 calculate_full_metrics.py 或 RUN_calculate_full_metrics.bat，
会在 full 下建立新的带时间戳文件夹，不覆盖本次结果。
脚本只需要 Python 标准库，不依赖 pandas、numpy 或 sklearn。
"""
    with (output / "README_指标口径.txt").open("x", encoding="utf-8-sig") as f:
        f.write(readme)
    shutil.copy2(Path(__file__), output / "calculate_full_metrics.py")
    launcher = root / "RUN_calculate_full_metrics.bat"
    if launcher.exists():
        shutil.copy2(launcher, output / launcher.name)
    print(f"DONE: {output}")
    print(f"Protein/DNA: {len(inputs['protein'])} matching test IDs each")
    print(f"CSV files: {len(notes['csv_sha256'])}; per-type tables: {len(list(per_type_dir.glob('*.csv')))}")
    for row in combined:
        if row["Average"] in {"binary_ARG_positive", "macro", "weighted"}:
            print(row["Modality"], row["Level"], row["Average"],
                  " ".join(f"{k}={row[k]:.8f}" for k in METRICS))
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, help="Full folder containing protein/ and dna/")
    parser.add_argument("--self-test", action="store_true", help="Built-in mathematical checks only")
    args = parser.parse_args()
    self_test()
    if not args.self_test:
        calculate(args.root.resolve() if args.root else infer_root())


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
