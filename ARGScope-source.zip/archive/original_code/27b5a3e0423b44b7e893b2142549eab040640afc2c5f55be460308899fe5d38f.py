#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate ARGNet nucleotide results at ARG/nonARG and Type levels.

The script can process one result file or automatically scan all matching TXT
files in one folder.

Expected ARGNet result columns:
    test_id, ARG_prediction, resistance_category, probability

Expected label columns:
    id, type, subtype

Default folder layout:
    ROOT_DIR/
      dna_60pct_5parts_clean_argnet-l_nt_result.txt
      dna_70pct_5parts_clean_argnet-l_nt_result.txt
      dna_80pct_5parts_clean_argnet-l_nt_result.txt
      dna_90pct_5parts_clean_argnet-l_nt_result.txt
      dna_90nt_5parts_clean_argnet-s_nt_result.txt
      dna_120nt_5parts_clean_argnet-s_nt_result.txt
      dna_150nt_5parts_clean_argnet-s_nt_result.txt
      dna_100pct_clean_argnet-l_nt_result.txt
      expanded_id_table_5x2.csv
      all_arg_nonarg_id_label.csv

Outputs:
    argnet_type_metrics_outputs/
      <dataset>_merged_predictions.csv
      <dataset>_missing_prediction_ids.csv
      <dataset>_extra_predicted_categories.csv
      <dataset>_type_metrics_simple.csv
      <dataset>_type_metrics_detailed.csv
      all_datasets_type_overall_metrics.csv
      all_datasets_arg_nonarg_overall_metrics.csv
      all_datasets_per_type_metrics.csv
      argnet_type_metrics_all_datasets.xlsx

Important metric convention:
    Per-Type ACC = TP / support, which is numerically identical to Recall.
    This matches the class-level ACC convention used in the ARGScope project.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)


# =============================================================================
# 1. Default configuration
# =============================================================================

SCRIPT_VERSION = "ARGNet_nucleotide_project_type_mapping_v2_2026-08-05"

ROOT_DIR = Path(".")

RESULT_GLOB = "dna_*_clean_argnet-*_nt_result.txt"
EXPANDED_LABEL_FILENAME = "expanded_id_table_5x2.csv"
ALL_LABEL_FILENAME = "all_arg_nonarg_id_label.csv"
OUTPUT_FOLDER_NAME = "argnet_type_metrics_outputs"

RESULT_ID_CANDIDATES = ["test_id", "id", "ID", "key", "KEY"]
LABEL_ID_CANDIDATES = ["id", "ID", "key", "KEY", "test_id"]
TRUE_TYPE_CANDIDATES = ["type", "Type", "TYPE", "true_type", "True_Type"]
SUBTYPE_CANDIDATES = ["subtype", "Subtype", "SUBTYPE"]
ARG_PRED_CANDIDATES = ["ARG_prediction", "arg_prediction", "prediction"]
CATEGORY_CANDIDATES = [
    "resistance_category",
    "Resistance_category",
    "category",
    "pred_type",
]
PROBABILITY_CANDIDATES = ["probability", "Probability", "score", "confidence"]

# ARGNet categories that have an unambiguous correspondence to the project's
# standard Type labels. Categories not listed here are deliberately retained as
# ARGNET_EXTRA__<category> rather than being mapped subjectively.
# Project Type mapping supplied by the user.
#
# Keys are written in the canonical form produced by canonical_token():
# lowercase, surrounding whitespace removed, and internal spaces converted
# to underscores. Hyphens are retained.
#
# Categories absent from this table are not mapped subjectively. They remain
# ARGNET_EXTRA__<category> and are counted as incorrect predictions against
# the project's standard Type labels.
PROJECT_TYPE_MAPPING: Dict[str, str] = {
    # ARG/nonARG label normalization required by the evaluation pipeline.
    "non-arg": "nonARG",
    "non_arg": "nonARG",
    "nonarg": "nonARG",

    # User-supplied ARG Type mapping.
    "mls": "macrolide-lincosamide-streptogramin",
    "multidrug": "multidrug",
    "mupirocin": "mupirocin",

    "chloramphenicol": "chloramphenicol",
    "phenicol": "chloramphenicol",

    "pleuromutilin": "pleuromutilin_tiamulin",
    "pleuromutilin_tiamulin": "pleuromutilin_tiamulin",

    "polymyxin": "polymyxin",
    "rifamycin": "rifamycin",
    "sulfonamide": "sulfonamide",

    # canonical_token() lowercases tetracenomycin_C.
    "tetracenomycin_c": "tetracenomycin_C",
    "tetracycline": "tetracycline",

    "fosfomycin": "fosfomycin",

    "fusidic-acid": "fusidic_acid",
    "fusidic_acid": "fusidic_acid",

    "aminoglycoside": "aminoglycoside",

    "antibacterial_free_fatty_acids": "antibacterial_fatty_acid",
    "antibacterial_fatty_acid": "antibacterial_fatty_acid",

    "bacitracin": "bacitracin",

    "beta-lactam": "beta_lactam",
    "beta_lactam": "beta_lactam",

    "quinolone": "quinolone",
    "trimethoprim": "trimethoprim",
}


# =============================================================================
# 2. General helpers
# =============================================================================


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Calculate ARGNet ARG/nonARG and per-Type metrics."
    )
    parser.add_argument(
        "--root-dir",
        default=str(ROOT_DIR),
        help="Directory containing ARGNet TXT results and label CSV files.",
    )
    parser.add_argument(
        "--result-file",
        default=None,
        help=(
            "Optional single ARGNet result TXT. When omitted, all files matching "
            f"{RESULT_GLOB!r} under --root-dir are processed."
        ),
    )
    parser.add_argument(
        "--label-file",
        default=None,
        help=(
            "Optional explicit label CSV for --result-file. When omitted, 5parts "
            "results use expanded_id_table_5x2.csv and uncut 100pct results use "
            "all_arg_nonarg_id_label.csv."
        ),
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory. Default: <root-dir>/argnet_type_metrics_outputs",
    )
    parser.add_argument(
        "--drop-missing-predictions",
        action="store_true",
        help=(
            "Exclude label IDs with no ARGNet output. Default behavior is stricter: "
            "retain them as missing_prediction and count them as errors."
        ),
    )
    return parser.parse_args()


def find_column(df: pd.DataFrame, candidates: Iterable[str], description: str) -> str:
    mapping = {str(column).strip().casefold(): column for column in df.columns}
    for candidate in candidates:
        found = mapping.get(candidate.casefold())
        if found is not None:
            return found
    raise ValueError(
        f"Cannot find {description}. Candidates={list(candidates)}; "
        f"available columns={df.columns.tolist()}"
    )


def clean_text(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def canonical_token(value: object) -> str:
    text = clean_text(value).lower()
    text = re.sub(r"\s+", "_", text)
    return text


def normalize_true_type(value: object) -> str:
    token = canonical_token(value)
    return PROJECT_TYPE_MAPPING.get(token, clean_text(value))


def normalize_arg_prediction(value: object) -> str:
    token = canonical_token(value).replace("_", "-")
    if token in {"non-arg", "nonarg"}:
        return "nonARG"
    if token == "arg":
        return "ARG"
    if not token:
        return "missing_prediction"
    return clean_text(value)


def map_predicted_type(arg_prediction: object, category: object) -> str:
    arg_state = normalize_arg_prediction(arg_prediction)

    if arg_state == "nonARG":
        return "nonARG"
    if arg_state == "missing_prediction":
        return "missing_prediction"
    if arg_state != "ARG":
        return f"ARGNET_UNKNOWN_STATE__{canonical_token(arg_state)}"

    category_token = canonical_token(category)
    if not category_token:
        return "ARG_unknown_category"

    mapped = PROJECT_TYPE_MAPPING.get(category_token)
    if mapped is not None:
        return mapped

    return f"ARGNET_EXTRA__{category_token}"


def dataset_name_from_result(path: Path) -> str:
    name = path.stem
    name = re.sub(r"^dna_", "", name, flags=re.IGNORECASE)
    name = re.sub(
        r"_clean_argnet-[ls]_nt_result$",
        "",
        name,
        flags=re.IGNORECASE,
    )
    return name


def choose_label_file(result_path: Path, root_dir: Path) -> Path:
    name = result_path.name.lower()
    if "100pct" in name and "5parts" not in name:
        return root_dir / ALL_LABEL_FILENAME
    return root_dir / EXPANDED_LABEL_FILENAME


# =============================================================================
# 3. Reading and merging
# =============================================================================


def read_labels(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"Label file not found: {path}")

    df = pd.read_csv(path, dtype=str, low_memory=False)
    df.columns = [clean_text(column) for column in df.columns]

    id_col = find_column(df, LABEL_ID_CANDIDATES, "label ID column")
    type_col = find_column(df, TRUE_TYPE_CANDIDATES, "true Type column")

    try:
        subtype_col = find_column(df, SUBTYPE_CANDIDATES, "Subtype column")
    except ValueError:
        subtype_col = None

    output = pd.DataFrame(
        {
            "id": df[id_col].map(clean_text),
            "true_type": df[type_col].map(normalize_true_type),
        }
    )
    output["true_subtype"] = (
        df[subtype_col].map(clean_text) if subtype_col is not None else ""
    )

    if output["id"].eq("").any():
        raise ValueError(f"{path.name}: blank IDs are present.")
    if output["id"].duplicated().any():
        examples = output.loc[
            output["id"].duplicated(keep=False), "id"
        ].head(20).tolist()
        raise ValueError(f"{path.name}: duplicate label IDs. Examples={examples}")
    if output["true_type"].eq("").any():
        raise ValueError(f"{path.name}: blank true Type labels are present.")

    return output


def read_argnet_result(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"ARGNet result file not found: {path}")

    # sep=None with the Python engine handles tab-delimited TXT robustly.
    df = pd.read_csv(path, sep=None, engine="python", dtype=str)
    df.columns = [clean_text(column) for column in df.columns]

    id_col = find_column(df, RESULT_ID_CANDIDATES, "result ID column")
    arg_col = find_column(df, ARG_PRED_CANDIDATES, "ARG_prediction column")
    category_col = find_column(df, CATEGORY_CANDIDATES, "resistance category column")

    try:
        probability_col = find_column(
            df, PROBABILITY_CANDIDATES, "probability column"
        )
    except ValueError:
        probability_col = None

    output = pd.DataFrame(
        {
            "id": df[id_col].map(clean_text),
            "ARG_prediction": df[arg_col].map(clean_text),
            "resistance_category": df[category_col].map(clean_text),
        }
    )
    output["probability"] = (
        pd.to_numeric(df[probability_col], errors="coerce")
        if probability_col is not None
        else np.nan
    )
    output["pred_type"] = [
        map_predicted_type(arg_state, category)
        for arg_state, category in zip(
            output["ARG_prediction"], output["resistance_category"]
        )
    ]

    if output["id"].eq("").any():
        raise ValueError(f"{path.name}: blank result IDs are present.")
    if output["id"].duplicated().any():
        examples = output.loc[
            output["id"].duplicated(keep=False), "id"
        ].head(20).tolist()
        raise ValueError(f"{path.name}: duplicate result IDs. Examples={examples}")

    return output


def merge_labels_and_predictions(
    labels: pd.DataFrame,
    predictions: pd.DataFrame,
    drop_missing_predictions: bool,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    prediction_only = predictions.loc[
        ~predictions["id"].isin(labels["id"])
    ].copy()
    if not prediction_only.empty:
        examples = prediction_only["id"].head(20).tolist()
        raise ValueError(
            f"{len(prediction_only):,} prediction IDs are absent from the label file. "
            f"Examples={examples}"
        )

    merged = labels.merge(
        predictions,
        on="id",
        how="left",
        validate="one_to_one",
        indicator=True,
    )

    missing = merged.loc[merged["_merge"] == "left_only"].copy()

    if drop_missing_predictions:
        merged = merged.loc[merged["_merge"] == "both"].copy()
    else:
        missing_mask = merged["_merge"] == "left_only"
        merged.loc[missing_mask, "ARG_prediction"] = "missing_prediction"
        merged.loc[missing_mask, "resistance_category"] = ""
        merged.loc[missing_mask, "pred_type"] = "missing_prediction"

    merged = merged.drop(columns="_merge")

    extra_categories = (
        merged.loc[
            merged["pred_type"].str.startswith("ARGNET_EXTRA__", na=False),
            ["pred_type"],
        ]
        .value_counts()
        .rename("count")
        .reset_index()
        .sort_values(["count", "pred_type"], ascending=[False, True])
    )

    return merged, missing, extra_categories


# =============================================================================
# 4. Metrics
# =============================================================================


def safe_mcc(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(np.unique(y_true)) == 1 and len(np.unique(y_pred)) == 1:
        return 0.0
    return float(matthews_corrcoef(y_true, y_pred))


def overall_multiclass_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    dataset: str,
    level: str,
) -> Dict[str, object]:
    weighted = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )
    macro = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )

    return {
        "dataset": dataset,
        "level": level,
        "N": int(len(y_true)),
        "true_class_count": int(len(np.unique(y_true))),
        "pred_class_count": int(len(np.unique(y_pred))),
        "ACC": float(accuracy_score(y_true, y_pred)),
        "Precision_weighted": float(weighted[0]),
        "Recall_weighted": float(weighted[1]),
        "F1_weighted": float(weighted[2]),
        "Precision_macro": float(macro[0]),
        "Recall_macro": float(macro[1]),
        "F1_macro": float(macro[2]),
        "MCC": safe_mcc(y_true, y_pred),
    }


def per_type_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    true_types: List[str],
    dataset: str,
) -> pd.DataFrame:
    rows = []

    for type_name in true_types:
        true_binary = (y_true == type_name).astype(np.int8)
        pred_binary = (y_pred == type_name).astype(np.int8)

        tp = int(np.sum((true_binary == 1) & (pred_binary == 1)))
        fp = int(np.sum((true_binary == 0) & (pred_binary == 1)))
        fn = int(np.sum((true_binary == 1) & (pred_binary == 0)))
        tn = int(np.sum((true_binary == 0) & (pred_binary == 0)))

        support = tp + fn
        pred_count = tp + fp

        precision = precision_score(
            true_binary, pred_binary, zero_division=0
        )
        recall = recall_score(true_binary, pred_binary, zero_division=0)
        f1 = f1_score(true_binary, pred_binary, zero_division=0)
        mcc = safe_mcc(true_binary, pred_binary)

        # Project convention: per-class ACC is correct_count / support.
        class_acc = tp / support if support > 0 else 0.0
        binary_acc = (tp + tn) / len(y_true) if len(y_true) else 0.0

        rows.append(
            {
                "dataset": dataset,
                "Type": type_name,
                "support": support,
                "pred_count": pred_count,
                "correct_count": tp,
                "wrong_count": fn,
                "ACC": float(class_acc),
                "Precision": float(precision),
                "Recall": float(recall),
                "F1": float(f1),
                "MCC": float(mcc),
                "Binary_ACC": float(binary_acc),
                "TP": tp,
                "FP": fp,
                "FN": fn,
                "TN": tn,
            }
        )

    return pd.DataFrame(rows).sort_values(
        ["support", "Type"], ascending=[False, True]
    ).reset_index(drop=True)


def arg_nonarg_arrays(merged: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    y_true = np.where(merged["true_type"].eq("nonARG"), "nonARG", "ARG")

    pred_state = merged["ARG_prediction"].map(normalize_arg_prediction)
    y_pred = np.where(
        pred_state.eq("nonARG"),
        "nonARG",
        np.where(pred_state.eq("ARG"), "ARG", "missing_prediction"),
    )

    return y_true.astype(str), y_pred.astype(str)


# =============================================================================
# 5. Excel formatting
# =============================================================================


def safe_sheet_name(name: str, used: set[str]) -> str:
    cleaned = re.sub(r"[\\/*?:\[\]]", "_", name)[:31]
    candidate = cleaned or "Sheet"
    suffix = 1
    while candidate in used:
        suffix_text = f"_{suffix}"
        candidate = cleaned[: 31 - len(suffix_text)] + suffix_text
        suffix += 1
    used.add(candidate)
    return candidate


def format_excel(path: Path) -> None:
    workbook = load_workbook(path)
    header_fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
    header_font = Font(bold=True)

    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions
        worksheet.sheet_view.showGridLines = False

        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for column_cells in worksheet.columns:
            values = [str(cell.value) if cell.value is not None else "" for cell in column_cells]
            width = min(max(max(map(len, values)) + 2, 12), 45)
            worksheet.column_dimensions[column_cells[0].column_letter].width = width

        for row in worksheet.iter_rows(min_row=2):
            for cell in row:
                if isinstance(cell.value, float):
                    cell.number_format = "0.0000"

    workbook.save(path)


# =============================================================================
# 6. Main processing
# =============================================================================


def process_one_result(
    result_path: Path,
    label_path: Path,
    output_dir: Path,
    drop_missing_predictions: bool,
) -> Tuple[pd.DataFrame, Dict[str, object], Dict[str, object]]:
    dataset = dataset_name_from_result(result_path)

    print("\n" + "=" * 80)
    print(f"Dataset: {dataset}")
    print(f"Result : {result_path}")
    print(f"Labels : {label_path}")

    labels = read_labels(label_path)
    predictions = read_argnet_result(result_path)
    merged, missing, extra_categories = merge_labels_and_predictions(
        labels,
        predictions,
        drop_missing_predictions=drop_missing_predictions,
    )

    print(f"Label rows             : {len(labels):,}")
    print(f"Prediction rows        : {len(predictions):,}")
    print(f"Evaluated rows         : {len(merged):,}")
    print(f"Missing predictions    : {len(missing):,}")
    print(f"True Type count        : {merged['true_type'].nunique()}")
    print(f"Predicted Type count   : {merged['pred_type'].nunique()}")

    true_types = sorted(labels["true_type"].unique())
    y_true_type = merged["true_type"].to_numpy(dtype=str)
    y_pred_type = merged["pred_type"].to_numpy(dtype=str)

    type_overall = overall_multiclass_metrics(
        y_true_type,
        y_pred_type,
        dataset=dataset,
        level="Type",
    )
    type_by_class = per_type_metrics(
        y_true_type,
        y_pred_type,
        true_types=true_types,
        dataset=dataset,
    )

    y_true_binary, y_pred_binary = arg_nonarg_arrays(merged)
    binary_overall = overall_multiclass_metrics(
        y_true_binary,
        y_pred_binary,
        dataset=dataset,
        level="ARG_nonARG",
    )

    merged.to_csv(
        output_dir / f"{dataset}_merged_predictions.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.8f",
    )
    missing.to_csv(
        output_dir / f"{dataset}_missing_prediction_ids.csv",
        index=False,
        encoding="utf-8-sig",
    )
    extra_categories.to_csv(
        output_dir / f"{dataset}_extra_predicted_categories.csv",
        index=False,
        encoding="utf-8-sig",
    )

    detailed_path = output_dir / f"{dataset}_type_metrics_detailed.csv"
    type_by_class.round(4).to_csv(
        detailed_path,
        index=False,
        encoding="utf-8-sig",
    )

    simple = type_by_class[
        ["Type", "ACC", "Precision", "Recall", "F1", "MCC"]
    ].copy()
    simple.columns = ["Type", "ACC", "PRECISION", "RECALL", "F1", "MCC"]
    simple.round(4).to_csv(
        output_dir / f"{dataset}_type_metrics_simple.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return type_by_class, type_overall, binary_overall


def main() -> None:
    args = parse_args()

    root_dir = Path(args.root_dir).expanduser().resolve()
    output_dir = (
        Path(args.output_dir).expanduser().resolve()
        if args.output_dir
        else root_dir / OUTPUT_FOLDER_NAME
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    mapping_rows = [
        {"ARGNet_or_true_label": source, "Project_Type": target}
        for source, target in PROJECT_TYPE_MAPPING.items()
    ]
    pd.DataFrame(mapping_rows).to_csv(
        output_dir / "project_type_mapping_used.csv",
        index=False,
        encoding="utf-8-sig",
    )

    if args.result_file:
        result_files = [Path(args.result_file).expanduser().resolve()]
    else:
        result_files = sorted(root_dir.glob(RESULT_GLOB))

    if not result_files:
        raise FileNotFoundError(
            f"No ARGNet result files found. root={root_dir}; glob={RESULT_GLOB}"
        )

    print("=" * 80)
    print("ARGNet Type-level evaluation")
    print(f"Script version  : {SCRIPT_VERSION}")
    print("=" * 80)
    print(f"Root directory : {root_dir}")
    print(f"Output directory: {output_dir}")
    print(f"Result files    : {len(result_files)}")
    print(
        "Missing predictions: "
        + ("dropped" if args.drop_missing_predictions else "retained as errors")
    )

    per_type_parts = []
    type_overall_rows = []
    binary_overall_rows = []
    per_dataset_simple: Dict[str, pd.DataFrame] = {}

    for result_path in result_files:
        label_path = (
            Path(args.label_file).expanduser().resolve()
            if args.label_file
            else choose_label_file(result_path, root_dir)
        )

        type_by_class, type_overall, binary_overall = process_one_result(
            result_path=result_path,
            label_path=label_path,
            output_dir=output_dir,
            drop_missing_predictions=args.drop_missing_predictions,
        )

        dataset = dataset_name_from_result(result_path)
        per_type_parts.append(type_by_class)
        type_overall_rows.append(type_overall)
        binary_overall_rows.append(binary_overall)

        simple = type_by_class[
            ["Type", "ACC", "Precision", "Recall", "F1", "MCC"]
        ].copy()
        simple.columns = ["Type", "ACC", "PRECISION", "RECALL", "F1", "MCC"]
        per_dataset_simple[dataset] = simple

    all_per_type = pd.concat(per_type_parts, ignore_index=True)
    all_type_overall = pd.DataFrame(type_overall_rows)
    all_binary_overall = pd.DataFrame(binary_overall_rows)

    all_per_type.round(4).to_csv(
        output_dir / "all_datasets_per_type_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    all_type_overall.round(4).to_csv(
        output_dir / "all_datasets_type_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    all_binary_overall.round(4).to_csv(
        output_dir / "all_datasets_arg_nonarg_overall_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    excel_path = output_dir / "argnet_type_metrics_all_datasets.xlsx"
    used_sheet_names: set[str] = set()
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        all_type_overall.round(4).to_excel(
            writer,
            sheet_name=safe_sheet_name("Type_overall", used_sheet_names),
            index=False,
        )
        all_binary_overall.round(4).to_excel(
            writer,
            sheet_name=safe_sheet_name("ARG_nonARG_overall", used_sheet_names),
            index=False,
        )
        all_per_type.round(4).to_excel(
            writer,
            sheet_name=safe_sheet_name("Per_Type_all", used_sheet_names),
            index=False,
        )
        for dataset, simple in per_dataset_simple.items():
            simple.round(4).to_excel(
                writer,
                sheet_name=safe_sheet_name(dataset, used_sheet_names),
                index=False,
            )

    format_excel(excel_path)

    print("\n" + "=" * 80)
    print("Completed")
    print("=" * 80)
    print(f"Output directory: {output_dir}")
    print("Main outputs:")
    print("  project_type_mapping_used.csv")
    print("  all_datasets_type_overall_metrics.csv")
    print("  all_datasets_arg_nonarg_overall_metrics.csv")
    print("  all_datasets_per_type_metrics.csv")
    print("  argnet_type_metrics_all_datasets.xlsx")


if __name__ == "__main__":
    main()
