"""Independently compare delivered DOCX cells to source metrics and render pages."""
from pathlib import Path
import csv
import json
import re
from docx import Document
from pypdf import PdfReader
import pypdfium2 as pdfium
from update_supplement_including_nonarg import OUT, DEST, TABLES, FIELDS

def main():
    with (OUT/'data/all_metrics_including_nonARG.csv').open(encoding='utf-8-sig',newline='') as f:
        metrics=list(csv.DictReader(f))
    doc=Document(DEST)
    verified=0
    for number,(mod,model,level) in TABLES.items():
        for row in doc.tables[number-1].rows[1:]:
            pct=int(row.cells[0].text.strip().replace('%',''))
            avg=row.cells[2].text.strip()
            source=[r for r in metrics if r['Modality']==mod and r['Model']==model and r['Level']==level and int(r['Completeness'])==pct and r['Average']==avg]
            assert len(source)==1
            for i,field in enumerate(FIELDS,3):
                assert row.cells[i].text.strip()==f"{float(source[0][field]):.4f}",(number,pct,avg,field)
                verified+=1
    qa=OUT/'qa_docx'
    pdf=qa/'Supplementary_including_nonARG.pdf'
    reader=PdfReader(pdf)
    pages=[]
    pdf_images=pdfium.PdfDocument(str(pdf))
    for i,page in enumerate(reader.pages):
        text=page.extract_text()
        tables=re.findall(r'Table\s+(\d+)\.',text)
        pages.append({'page':i+1,'table_captions':tables,'text_characters':len(text)})
        image=pdf_images[i].render(scale=1.8).to_pil()
        image.save(qa/f'page-{i+1:02d}.png')
    full_text='\n'.join(page.extract_text() for page in reader.pages)
    assert [int(n) for p in pages for n in p['table_captions']]==list(range(1,21))
    assert verified==750
    result={'actual_docx_numeric_cells_verified':verified,'pages':pages,'all_20_tables_in_pdf':True,'renderer':'Microsoft Word PDF export, rasterized with PDFium'}
    (qa/'render_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
