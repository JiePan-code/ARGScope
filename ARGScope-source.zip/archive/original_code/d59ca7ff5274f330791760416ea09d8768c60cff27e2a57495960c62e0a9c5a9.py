"""Isolated seed worker; aggregate only after all workers finish to avoid races."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import run_bgc_normalized as experiment


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seed",required=True,type=int,choices=[20260915,20261006,20261007])
    args=parser.parse_args()
    # All computation/selection uses the original audited implementation.
    # Suppress shared aggregation while independent workers write separate seed folders.
    experiment.aggregate=lambda:None
    sys.argv=[str(ROOT/"run_bgc_normalized.py"),"--seeds",str(args.seed)]
    experiment.main()
    print(f"INDEPENDENT SEED WORKER {args.seed} FINISHED",flush=True)
