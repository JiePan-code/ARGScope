#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Calculate Type-level metrics from an existing novel-gene prediction CSV.

Run without arguments with this script beside test_sequence_predictions.csv.
Dependencies: numpy, pandas, scikit-learn. No model weights or GPU are needed.

DEFAULT EVALUATION
------------------
All rows in the test prediction file, including nonARG.
Truth: true_type. Prediction: predicted_type.
Never use predicted_type_oracle_binary or alter the existing decision threshold.
Never filter on pred_ARG, class support, or whether a prediction is correct.

Overall: ACC, Precision, Recall, F1, multiclass MCC.
Separate micro / weighted / macro CSVs are produced.
Per Type: one-vs-rest ACC, Precision, Recall, F1, binary MCC on the SAME rows.
The label set is the union of true and predicted Type labels. No hardcoded list.
Undefined Precision/Recall/F1 use zero_division=0; degenerate MCC is 0.
Only CSV display values are rounded, to four decimals.

Optional scope: --scope novel_arg
Select true_ARG=1 and novel_ARG_subtype=1, but KEEP missed predictions as nonARG.
This is a distinct evaluation population. Its results are put in a separate
novel_ARG_only subdirectory and must not replace the all-test result silently.

Novel-subtype flags are accepted as supplied; this script cannot establish
novelty or train/test independence without the original training records.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import math
import re
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    matthews_corrcoef,
    precision_recall_fscore_support,
)

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = SCRIPT_DIR / "test_sequence_predictions.csv"
NONARG = "nonARG"
AVERAGES = ("micro", "weighted", "macro")
FIVE_METRICS = ["ACC", "Precision", "Recall", "F1", "MCC"]
VERSION = "novel-gene-type-metrics-v1"


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, default=None,
                        help="Default: test_sequence_predictions.csv beside this script.")
    parser.add_argument("--output-dir", type=Path, default=None,
                        help="Default: <input folder>/novel_gene_type_metrics.")
    parser.add_argument("--scope", choices=("all", "novel_arg"), default="all",
                        help="all includes nonARG; novel_arg uses supplied novel ARG flags.")
    return parser.parse_args()


def locate_input(explicit):
    if explicit is not None:
        path = explicit.expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Input CSV not found: {path}")
        return path
    if DEFAULT_INPUT.is_file():
        return DEFAULT_INPUT
    candidates = sorted(SCRIPT_DIR.glob("test_sequence_predictions*.csv"))
    if len(candidates) == 1:
        return candidates[0]
    raise FileNotFoundError(
        f"Put this script beside test_sequence_predictions.csv, or pass --input.\n"
        f"Script directory: {SCRIPT_DIR}\nCandidates: {[p.name for p in candidates]}"
    )


def setup_logging(folder):
    logs = folder / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    path = logs / f"novel_gene_type_metrics_{stamp}.log"
    logger = logging.getLogger(VERSION)
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in (logging.StreamHandler(sys.stdout),
                    logging.FileHandler(path, encoding="utf-8")):
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
    return logger, path


def normalize_labels(series, name):
    text = series.astype(str).str.strip()
    invalid = text.str.casefold().isin({"", "nan", "none", "null", "na", "n/a"})
    if invalid.any():
        rows = (np.flatnonzero(invalid.to_numpy())[:10] + 2).tolist()
        raise ValueError(f"Missing/invalid labels in {name}, CSV rows: {rows}. "
                         "No rows have been dropped or imputed.")
    # Normalize only equivalent spellings of nonARG. Do not merge ARG Types.
    return text.map(lambda x: NONARG if re.fullmatch(r"non[\s_-]*arg", x, re.I) else x)


def binary_flag(series, name):
    numbers = pd.to_numeric(series, errors="coerce")
    if not numbers.isin([0, 1]).all():
        raise ValueError(f"{name} must contain only 0/1 flags, with no blanks.")
    return numbers.to_numpy(dtype=np.int64)


def read_and_validate(path):
    # Preserve label strings and detect missing values ourselves.
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        header = next(csv.reader(handle), [])
    clean_header = [x.strip() for x in header]
    if len(clean_header) != len(set(clean_header)):
        raise ValueError("Duplicate column names in the CSV header.")
    df = pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    df.columns = [x.strip() for x in df.columns]
    required = {"true_type", "predicted_type"}
    if not required.issubset(df.columns):
        raise KeyError(f"Missing columns: {sorted(required - set(df.columns))}; "
                       f"available={df.columns.tolist()}")
    if df.empty:
        raise ValueError("The prediction file has no rows.")

    label_changes = {}
    for name in ("true_type", "predicted_type"):
        before = df[name].copy()
        df[name] = normalize_labels(df[name], name)
        label_changes[name] = int((before != df[name]).sum())

    if "split" in df:
        split_values = df["split"].str.strip().str.casefold()
        if not split_values.eq("test").all():
            raise ValueError("The file contains non-test or empty split labels. "
                             "Supply a TEST-only prediction CSV; rows are not silently filtered.")

    id_check = "not available (no sequence_id column)"
    if "sequence_id" in df:
        ids = df["sequence_id"].str.strip()
        if ids.eq("").any():
            raise ValueError("Empty sequence_id in the input.")
        if ids.duplicated().any():
            examples = ids[ids.duplicated(keep=False)].head(8).tolist()
            raise ValueError(f"Duplicate sequence_id values: {examples}; "
                             "records are not silently deduplicated.")
        id_check = "PASS: unique nonempty sequence_id values"

    truth_arg = df["true_type"].ne(NONARG).to_numpy(dtype=np.int64)
    pred_arg = df["predicted_type"].ne(NONARG).to_numpy(dtype=np.int64)
    for name, expected in (("true_ARG", truth_arg), ("pred_ARG", pred_arg),
                           ("predicted_ARG", pred_arg)):
        if name in df and not np.array_equal(binary_flag(df[name], name), expected):
            raise ValueError(f"{name} disagrees with the corresponding Type label. "
                             "Inspect the input; predictions will not be changed.")

    if "type_correct" in df:
        expected = df["true_type"].eq(df["predicted_type"]).to_numpy(dtype=np.int64)
        if not np.array_equal(binary_flag(df["type_correct"], "type_correct"), expected):
            raise ValueError("type_correct disagrees with true_type == predicted_type.")
    if "novel_ARG_subtype" in df:
        novel = binary_flag(df["novel_ARG_subtype"], "novel_ARG_subtype")
        if np.any((novel == 1) & (truth_arg == 0)):
            raise ValueError("novel_ARG_subtype=1 found on a true nonARG row.")

    audit = {
        "input_rows": int(len(df)),
        "true_ARG_rows": int(truth_arg.sum()),
        "true_nonARG_rows": int((truth_arg == 0).sum()),
        "sequence_id_check": id_check,
        "label_normalization_changes": label_changes,
    }
    if "novel_ARG_subtype" in df:
        audit["rows_flagged_novel_ARG_subtype"] = int(
            binary_flag(df["novel_ARG_subtype"], "novel_ARG_subtype").sum())
    return df, audit


def divide_or_zero(numerator, denominator):
    return np.divide(numerator, denominator,
                     out=np.zeros_like(numerator, dtype=np.float64),
                     where=np.asarray(denominator) != 0)


def calculate_metrics(y_true, y_pred):
    # Unicode arrays avoid sklearn's object-integer 'unknown target type' error.
    true = np.asarray(y_true, dtype=str)
    pred = np.asarray(y_pred, dtype=str)
    if true.ndim != 1 or pred.shape != true.shape or not len(true):
        raise ValueError("Labels must be nonempty one-dimensional arrays of equal length.")
    labels = sorted(set(true) | set(pred),
                    key=lambda name: (name == NONARG, name.casefold(), name))
    cm = confusion_matrix(true, pred, labels=labels)
    n = len(true)
    support = cm.sum(axis=1).astype(np.float64)
    predicted_count = cm.sum(axis=0).astype(np.float64)
    tp = np.diag(cm).astype(np.float64)
    fp = predicted_count - tp
    fn = support - tp
    tn = n - tp - fp - fn

    precision = divide_or_zero(tp, tp + fp)
    recall = divide_or_zero(tp, tp + fn)
    f1 = divide_or_zero(2 * tp, 2 * tp + fp + fn)
    denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    per_mcc = divide_or_zero(tp * tn - fp * fn, denominator)
    accuracy = float(accuracy_score(true, pred))
    overall_mcc = float(matthews_corrcoef(true, pred))

    # Independently check sklearn metrics against confusion-matrix formulas.
    sk_p, sk_r, sk_f, sk_s = precision_recall_fscore_support(
        true, pred, labels=labels, average=None, zero_division=0)
    for computed, reference in ((precision, sk_p), (recall, sk_r),
                                (f1, sk_f), (support, sk_s)):
        np.testing.assert_allclose(computed, reference, atol=1e-12, rtol=1e-10)
    mcc_den = math.sqrt(max(0.0, n * n - float(np.dot(predicted_count, predicted_count)))
                        * max(0.0, n * n - float(np.dot(support, support))))
    manual_mcc = ((float(tp.sum()) * n - float(np.dot(predicted_count, support)))
                  / mcc_den if mcc_den else 0.0)
    if not math.isclose(overall_mcc, manual_mcc, abs_tol=1e-12, rel_tol=1e-10):
        raise RuntimeError("Multiclass MCC verification failed.")
    if not math.isclose(accuracy, float(tp.sum()) / n, abs_tol=1e-12):
        raise RuntimeError("Accuracy verification failed.")

    summary = []
    for average in AVERAGES:
        p, r, f, _ = precision_recall_fscore_support(
            true, pred, labels=labels, average=average, zero_division=0)
        if average == "micro":
            manual = [accuracy, accuracy, accuracy]
        elif average == "weighted":
            manual = [float(np.dot(v, support)) / n for v in (precision, recall, f1)]
        else:
            manual = [float(v.mean()) for v in (precision, recall, f1)]
        np.testing.assert_allclose([p, r, f], manual, atol=1e-12, rtol=1e-10)
        summary.append({"Class": "Type", "Average": average, "N": n,
                        "ACC": accuracy, "Precision": float(p), "Recall": float(r),
                        "F1": float(f), "MCC": overall_mcc})

    detailed = pd.DataFrame({
        "Type": labels, "ACC": (tp + tn) / n, "Precision": precision,
        "Recall": recall, "F1": f1, "MCC": per_mcc,
        "support": support.astype(np.int64),
        "predicted_count": predicted_count.astype(np.int64),
        "TP": tp.astype(np.int64), "FP": fp.astype(np.int64),
        "FN": fn.astype(np.int64), "TN": tn.astype(np.int64),
        "total_samples": n,
    })
    for i, label in enumerate(labels):
        expected = matthews_corrcoef((true == label).astype(np.int64),
                                     (pred == label).astype(np.int64))
        if not math.isclose(per_mcc[i], float(expected), abs_tol=1e-12, rel_tol=1e-10):
            raise RuntimeError(f"Per-Type MCC verification failed: {label}")
    matrix = pd.DataFrame(cm, index=labels, columns=labels)
    matrix.index.name = "true_type"
    return pd.DataFrame(summary), detailed, matrix


def save_csv(table, path, index=False):
    temporary = path.with_suffix(path.suffix + ".tmp")
    table.to_csv(temporary, index=index, encoding="utf-8-sig", float_format="%.4f")
    temporary.replace(path)


def run(args, path, logger, log_path):
    df, audit = read_and_validate(path)
    all_count = len(df)
    if args.scope == "novel_arg":
        needed = {"true_ARG", "novel_ARG_subtype"}
        if not needed.issubset(df.columns):
            raise KeyError("--scope novel_arg requires true_ARG and novel_ARG_subtype.")
        select = ((binary_flag(df["true_ARG"], "true_ARG") == 1)
                  & (binary_flag(df["novel_ARG_subtype"], "novel_ARG_subtype") == 1))
        df = df.loc[select].copy()
        if df.empty:
            raise ValueError("No rows satisfy the supplied novel ARG flags.")

    if args.output_dir is None:
        output = path.parent / "novel_gene_type_metrics"
        if args.scope == "novel_arg":
            output = output / "novel_ARG_only"
    else:
        output = args.output_dir.expanduser().resolve()
    if output == path.parent:
        raise ValueError("Use a separate output folder, not the input folder itself.")
    summary, detailed, matrix = calculate_metrics(df["true_type"], df["predicted_type"])

    output.mkdir(parents=True, exist_ok=True)
    for average in AVERAGES:
        table = summary.loc[summary["Average"].eq(average), ["Class"] + FIVE_METRICS]
        save_csv(table, output / f"novel_gene_type_{average}_5metrics.csv")
    save_csv(summary, output / "novel_gene_type_all_averages_summary.csv")
    save_csv(detailed[["Type"] + FIVE_METRICS], output / "novel_gene_each_type_5metrics.csv")
    save_csv(detailed, output / "novel_gene_each_type_detailed_metrics.csv")
    save_csv(matrix, output / "novel_gene_type_confusion_matrix.csv", index=True)

    audit.update({
        "script_version": VERSION,
        "input_file": str(path),
        "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "scope": args.scope, "evaluation_rows": int(len(df)),
        "rows_excluded_by_explicit_scope": int(all_count - len(df)),
        "truth_column": "true_type", "prediction_column": "predicted_type",
        "oracle_used": False, "threshold_modified": False,
        "true_Type_count": int(df["true_type"].nunique()),
        "predicted_Type_count": int(df["predicted_type"].nunique()),
        "evaluated_Type_count": int(len(matrix)),
        "evaluated_Types": matrix.index.tolist(),
        "Type_correct_count": int(matrix.to_numpy().trace()),
        "labels_rule": "union of true/predicted Type labels within the selected scope",
        "zero_division": 0,
        "manual_confusion_formula_verification": "PASS",
        "versions": {"python": sys.version.split()[0], "numpy": np.__version__,
                     "pandas": pd.__version__, "sklearn": sklearn.__version__},
        "log_file": str(log_path),
    })
    tmp = output / "calculation_audit.json.tmp"
    tmp.write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(output / "calculation_audit.json")
    note = (
        "TYPE-LEVEL METRIC DEFINITIONS\n"
        f"Source: {path}\nScope: {args.scope}; N={len(df)}\n"
        "Actual predicted_type is used; predicted_type_oracle_binary is NOT used.\n"
        "No re-training, threshold tuning, support filtering or prediction filtering.\n"
        "nonARG is included whenever present in truth or prediction.\n"
        "No absent Types are added from earlier experiments.\n"
        "Overall ACC = number of correct Type predictions / number of rows.\n"
        "Precision/Recall/F1: micro, support-weighted or macro (equal class weight).\n"
        "Overall MCC is multiclass MCC, NOT an average of per-Type MCCs.\n"
        "Each Type is evaluated one-vs-rest on the same complete selected rows.\n"
        "Per-Type ACC = (TP+TN)/N, not TP/support (which is Recall).\n"
        "Undefined Precision/Recall/F1 and degenerate MCC are set to 0.\n"
        "ACC and multiclass MCC are the same across the three averaging files.\n"
        "Single-label micro Precision=Recall=F1=ACC; weighted Recall=ACC.\n"
        "CSV metric columns are formatted to four decimals; calculations are not rounded.\n"
        "Optional --scope novel_arg selects true_ARG=1 AND novel_ARG_subtype=1.\n"
        "Novel-only false-negative nonARG predictions are retained as errors.\n"
        "In novel-only scope, predicted-only nonARG is a zero-support class in\n"
        "the label union and therefore contributes a zero to the macro average.\n"
        "Novelty flags are taken from the file, not independently established.\n"
    )
    (output / "calculation_info.txt").write_text(note, encoding="utf-8")

    logger.info("Input      : %s", path)
    logger.info("Device     : CPU (prediction-table metrics only; no model/GPU required)")
    logger.info("Scope      : %s", args.scope)
    logger.info("Rows       : %s", f"{len(df):,}")
    logger.info("True Types : %d (including nonARG if present)", df["true_type"].nunique())
    logger.info("Correct    : %d / %d", matrix.to_numpy().trace(), len(df))
    logger.info("Oracle     : NOT USED")
    logger.info("\n%s", summary.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    logger.info("\nPer-Type rows: %d", len(detailed))
    logger.info("Confusion-matrix formula checks: PASS")
    logger.info("Results    : %s", output)
    logger.info("Log        : %s", log_path)
    return output


def main():
    args = parse_args()
    path = locate_input(args.input)
    logger, log_path = setup_logging(path.parent)
    try:
        run(args, path, logger, log_path)
    except Exception:
        logger.exception("Metric calculation failed; no records have been silently altered.")
        raise


if __name__ == "__main__":
    main()
