#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Calculate VF/non-VF, Type-level, and subtype-level test metrics.

Usage
-----
Place this script in the same folder as test_sequence_predictions.csv, then
run it without arguments. The same script works for DNA and Protein results.

The script creates a new folder named ``five_metrics_results`` beside itself.
It uses only the Python standard library.

Overall outputs contain three rows: micro, weighted, and macro. Accuracy and
multiclass MCC are global metrics, so they are repeated in those three rows.
Per-Type metrics are calculated one-vs-rest, one row for each Type.
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = SCRIPT_DIR / "test_sequence_predictions.csv"
DEFAULT_OUTPUT_DIR = SCRIPT_DIR / "five_metrics_results"

AVERAGES = ("micro", "weighted", "macro")
LEVELS = (
    ("VF/non-VF", "true_binary", "predicted_binary"),
    ("Type", "true_type", "predicted_type"),
    ("Subtype", "true_subtype", "predicted_subtype"),
)

OVERALL_FILENAMES = {
    "VF/non-VF": "VF_nonVF_level_metrics.csv",
    "Type": "type_level_metrics.csv",
    "Subtype": "subtype_level_metrics.csv",
}

METRIC_NAMES = ("accuracy", "precision", "recall", "f1", "mcc")


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Calculate five metrics for VF/non-VF, Type, subtype, and every "
            "individual Type from sequence-level test predictions."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT,
        help=(
            "Prediction CSV. Default: test_sequence_predictions.csv beside "
            "this script."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=(
            "Output folder. Default: five_metrics_results beside this script."
        ),
    )
    parser.add_argument(
        "--split",
        default="test",
        help=(
            "Value retained from the split column. Default: test. "
            "Use 'all' to disable split filtering."
        ),
    )
    return parser.parse_args()


def safe_divide(numerator, denominator):
    return numerator / denominator if denominator else 0.0


def standard_multiclass_mcc(
    labels,
    true_counts,
    predicted_counts,
    true_positive_counts,
    total,
):
    """Calculate the standard multiclass Matthews correlation coefficient."""

    correct = sum(true_positive_counts.values())
    predicted_true_product = sum(
        predicted_counts[label] * true_counts[label]
        for label in labels
    )
    predicted_square_sum = sum(
        predicted_counts[label] ** 2
        for label in labels
    )
    true_square_sum = sum(
        true_counts[label] ** 2
        for label in labels
    )

    numerator = correct * total - predicted_true_product
    denominator = math.sqrt(
        (total**2 - predicted_square_sum)
        * (total**2 - true_square_sum)
    )
    return safe_divide(numerator, denominator)


def binary_mcc(tp, tn, fp, fn):
    numerator = tp * tn - fp * fn
    denominator = math.sqrt(
        (tp + fp)
        * (tp + fn)
        * (tn + fp)
        * (tn + fn)
    )
    return safe_divide(numerator, denominator)


def label_statistics(y_true, y_pred):
    if len(y_true) != len(y_pred):
        raise ValueError("True and predicted label counts do not match.")
    if not y_true:
        raise ValueError("No prediction rows are available for evaluation.")

    labels = sorted(set(y_true).union(y_pred))
    true_counts = Counter(y_true)
    predicted_counts = Counter(y_pred)
    true_positive_counts = {
        label: sum(
            true_label == label and predicted_label == label
            for true_label, predicted_label in zip(y_true, y_pred)
        )
        for label in labels
    }

    return labels, true_counts, predicted_counts, true_positive_counts


def calculate_overall_rows(level, y_true, y_pred):
    (
        labels,
        true_counts,
        predicted_counts,
        true_positive_counts,
    ) = label_statistics(y_true, y_pred)

    total = len(y_true)
    correct = sum(true_positive_counts.values())
    accuracy = safe_divide(correct, total)
    mcc = standard_multiclass_mcc(
        labels,
        true_counts,
        predicted_counts,
        true_positive_counts,
        total,
    )

    per_class = {}
    for label in labels:
        tp = true_positive_counts[label]
        precision = safe_divide(tp, predicted_counts[label])
        recall = safe_divide(tp, true_counts[label])
        f1 = safe_divide(2.0 * precision * recall, precision + recall)
        per_class[label] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
        }

    true_positive_sum = correct
    false_positive_sum = sum(
        predicted_counts[label] - true_positive_counts[label]
        for label in labels
    )
    false_negative_sum = sum(
        true_counts[label] - true_positive_counts[label]
        for label in labels
    )

    micro_precision = safe_divide(
        true_positive_sum,
        true_positive_sum + false_positive_sum,
    )
    micro_recall = safe_divide(
        true_positive_sum,
        true_positive_sum + false_negative_sum,
    )
    micro_f1 = safe_divide(
        2.0 * micro_precision * micro_recall,
        micro_precision + micro_recall,
    )

    rows = []
    for average in AVERAGES:
        if average == "micro":
            precision = micro_precision
            recall = micro_recall
            f1 = micro_f1
        elif average == "weighted":
            precision = sum(
                per_class[label]["precision"] * true_counts[label]
                for label in labels
            ) / total
            recall = sum(
                per_class[label]["recall"] * true_counts[label]
                for label in labels
            ) / total
            f1 = sum(
                per_class[label]["f1"] * true_counts[label]
                for label in labels
            ) / total
        else:
            precision = sum(
                per_class[label]["precision"]
                for label in labels
            ) / len(labels)
            recall = sum(
                per_class[label]["recall"]
                for label in labels
            ) / len(labels)
            f1 = sum(
                per_class[label]["f1"]
                for label in labels
            ) / len(labels)

        rows.append(
            {
                "level": level,
                "average": average,
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": mcc,
                "n_sequences": total,
                "n_classes": len(labels),
            }
        )

    return rows


def calculate_per_type_rows(y_true, y_pred):
    (
        labels,
        true_counts,
        predicted_counts,
        true_positive_counts,
    ) = label_statistics(y_true, y_pred)

    total = len(y_true)
    rows = []
    for label in labels:
        tp = true_positive_counts[label]
        fp = predicted_counts[label] - tp
        fn = true_counts[label] - tp
        tn = total - tp - fp - fn

        accuracy = safe_divide(tp + tn, total)
        precision = safe_divide(tp, tp + fp)
        recall = safe_divide(tp, tp + fn)
        f1 = safe_divide(2.0 * precision * recall, precision + recall)
        mcc = binary_mcc(tp, tn, fp, fn)

        rows.append(
            {
                "level": "Type one-vs-rest",
                "type": label,
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "mcc": mcc,
                "support": true_counts[label],
                "predicted_count": predicted_counts[label],
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "tn": tn,
                "n_sequences": total,
            }
        )

    return rows


def rounded_rows(rows):
    output = []
    for row in rows:
        new_row = dict(row)
        for metric in METRIC_NAMES:
            if metric in new_row:
                new_row[metric] = round(float(new_row[metric]), 8)
        output.append(new_row)
    return output


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rounded_rows(rows))


def load_and_validate_rows(input_csv, split_name):
    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("The input CSV has no header row.")

        fieldnames = list(reader.fieldnames)
        required_columns = {
            "true_binary",
            "predicted_binary",
            "true_type",
            "predicted_type",
            "true_subtype",
            "predicted_subtype",
        }
        missing_columns = sorted(required_columns.difference(fieldnames))
        if missing_columns:
            raise ValueError(
                "Missing required column(s): " + ", ".join(missing_columns)
            )

        if split_name.lower() != "all" and "split" not in fieldnames:
            raise ValueError(
                "--split was requested, but the CSV has no 'split' column. "
                "Use --split all only if every row should be evaluated."
            )

        rows = list(reader)

    available_splits = sorted(
        {
            (row.get("split") or "").strip()
            for row in rows
            if (row.get("split") or "").strip()
        }
    )
    if split_name.lower() != "all":
        rows = [
            row
            for row in rows
            if (row.get("split") or "").strip() == split_name
        ]
        if not rows:
            raise ValueError(
                f"No rows found for split={split_name!r}. "
                f"Available split values: {available_splits}"
            )

    for row in rows:
        for _, true_column, predicted_column in LEVELS:
            row[true_column] = (row.get(true_column) or "").strip()
            row[predicted_column] = (row.get(predicted_column) or "").strip()

    invalid_label_rows = sum(
        any(
            not row[column]
            for _, true_column, predicted_column in LEVELS
            for column in (true_column, predicted_column)
        )
        for row in rows
    )
    if invalid_label_rows:
        raise ValueError(
            f"Found {invalid_label_rows} row(s) with missing prediction labels."
        )

    if "id" in fieldnames:
        ids = [(row.get("id") or "").strip() for row in rows]
        missing_id_count = sum(not sequence_id for sequence_id in ids)
        if missing_id_count:
            raise ValueError(
                f"Found {missing_id_count} row(s) with missing sequence IDs."
            )

        duplicate_count = len(ids) - len(set(ids))
        if duplicate_count:
            raise ValueError(
                f"Found {duplicate_count} duplicated sequence ID row(s)."
            )

    return rows


def main():
    args = parse_args()
    input_csv = args.input.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()

    if not input_csv.is_file():
        raise FileNotFoundError(
            "Prediction CSV not found. Put this script beside "
            f"test_sequence_predictions.csv. Expected: {input_csv}"
        )

    data_rows = load_and_validate_rows(input_csv, args.split)

    overall_by_level = {}
    all_overall_rows = []
    for level, true_column, predicted_column in LEVELS:
        y_true = [row[true_column] for row in data_rows]
        y_pred = [row[predicted_column] for row in data_rows]
        level_rows = calculate_overall_rows(level, y_true, y_pred)
        overall_by_level[level] = level_rows
        all_overall_rows.extend(level_rows)

    per_type_rows = calculate_per_type_rows(
        [row["true_type"] for row in data_rows],
        [row["predicted_type"] for row in data_rows],
    )

    overall_fields = [
        "level",
        "average",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
        "n_sequences",
        "n_classes",
    ]
    per_type_fields = [
        "level",
        "type",
        "accuracy",
        "precision",
        "recall",
        "f1",
        "mcc",
        "support",
        "predicted_count",
        "tp",
        "fp",
        "fn",
        "tn",
        "n_sequences",
    ]

    output_dir.mkdir(parents=True, exist_ok=True)

    created_files = []
    combined_path = output_dir / "all_overall_five_metrics.csv"
    write_csv(combined_path, all_overall_rows, overall_fields)
    created_files.append(combined_path)

    for level, level_rows in overall_by_level.items():
        output_path = output_dir / OVERALL_FILENAMES[level]
        write_csv(output_path, level_rows, overall_fields)
        created_files.append(output_path)

    per_type_path = output_dir / "per_type_five_metrics.csv"
    write_csv(per_type_path, per_type_rows, per_type_fields)
    created_files.append(per_type_path)

    print("\nOverall five metrics")
    print(
        f"{'level':<12} {'average':<9} {'accuracy':>10} "
        f"{'precision':>10} {'recall':>10} {'f1':>10} {'mcc':>10}"
    )
    for row in rounded_rows(all_overall_rows):
        print(
            f"{row['level']:<12} {row['average']:<9} "
            f"{row['accuracy']:>10.8f} {row['precision']:>10.8f} "
            f"{row['recall']:>10.8f} {row['f1']:>10.8f} "
            f"{row['mcc']:>10.8f}"
        )

    print(f"\nEvaluated sequences: {len(data_rows):,}")
    print(f"Per-Type rows: {len(per_type_rows)}")
    print(f"Output folder: {output_dir}")
    for path in created_files:
        print(f"  {path.name}")
    print(
        "\nNote: overall Accuracy and multiclass MCC are global metrics and "
        "are repeated across micro, weighted, and macro rows. Per-Type "
        "metrics use one-vs-rest calculations."
    )


if __name__ == "__main__":
    main()

