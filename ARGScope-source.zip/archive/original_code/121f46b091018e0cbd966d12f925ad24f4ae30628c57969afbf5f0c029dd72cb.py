"""Compact VF/BGC manuscript figures. Source predictions and prior outputs are unchanged."""
from pathlib import Path
import argparse
import json
import shutil
import zipfile
import textwrap
import plot_vf_bgc_full_length as base
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator, FormatStrFormatter
from matplotlib.text import Text

HERE=Path(__file__).resolve().parent
OLD=HERE/'outputs'/'vf_bgc_full_length_figures_20260921'
if not OLD.exists():
    OLD=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\VF_BGC_100pct_20260921')
OUT=HERE/'outputs'/'vf_bgc_merged_20260922'
DEST=Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\VF_BGC_合并组图_20260922')
COLORS=base.MODEL_COLORS
FONTPATH=font_manager.findfont('Arial',fallback_to_default=False)
plt.rcParams.update({'font.family':'Arial','font.size':13,'axes.labelsize':13,
    'axes.titlesize':14,'xtick.labelsize':12,'ytick.labelsize':12,
    'axes.linewidth':.9,'hatch.linewidth':.4,'pdf.fonttype':42,'svg.fonttype':'none',
    'axes.spines.top':False,'axes.spines.right':False})
FIGURE_AUDITS=[]

def textwrap_type(label,width=27):
    return base.wrapped(label,width)

def model_handles():
    return [Patch(facecolor=COLORS[m],edgecolor='#4A5661',lw=.55,
        hatch='--' if m=='AA' else '//',label='AA (protein)' if m=='AA' else 'NT (DNA)') for m in ['AA','NT']]

def panel(fig,char,x,y):
    fig.text(x,y,char,fontsize=18,weight='bold',ha='left',va='top')

def scores(data,mod,task,avg=None):
    name=data['models'][mod]['name']
    frame=data['all_avg'] if avg else data['main']
    found=frame.loc[frame.Model.eq(name)&frame.Task.eq(task)]
    if avg: found=found.loc[found.Average.eq(avg)]
    assert len(found)==1,(name,task,avg)
    return found[base.METRICS].iloc[0].to_numpy(float)

def radar(ax,data):
    theta=np.linspace(0,2*np.pi,5,endpoint=False)
    angles=np.r_[theta,theta[0]]
    ax.set_theta_offset(np.pi/2); ax.set_theta_direction(-1)
    task='VF/non-VF' if data['domain']=='VF' else 'BGC/nonBGC'
    for mod in ['AA','NT']:
        val=scores(data,mod,task)
        ax.plot(angles,np.r_[val,val[0]],color=COLORS[mod],lw=2.1,
            linestyle='-' if mod=='AA' else '--',marker='o' if mod=='AA' else 's',ms=4.5)
        ax.fill(angles,np.r_[val,val[0]],color=COLORS[mod],alpha=.07)
    ax.set_xticks(theta,['ACC','Precision','Recall','F1','MCC'],fontsize=13)
    ax.tick_params(axis='x',pad=7)
    ax.set_yticks([.25,.5,.75,1],['0.25','0.50','0.75','1.00'],fontsize=9.5,color='#737B82')
    ax.set_rlabel_position(80); ax.set_ylim(0,1)
    ax.grid(color='#DDE2E6',lw=.7)
    ax.spines['polar'].set_color('#9DA7AD')
    ax.set_title(f'{data["domain"]}/non-{data["domain"]}',pad=21,fontsize=15)

def functional_bars(ax,data,task='Type',avg='macro'):
    groups=[(task,avg)]
    width=.35
    for block,(task,avg) in enumerate(groups):
        x=np.arange(5)+block*6.0
        for j,mod in enumerate(['AA','NT']):
            val=scores(data,mod,task,avg)
            ax.bar(x+(j-.5)*width,val,width,color=COLORS[mod],edgecolor='#485761',
                linewidth=.5,hatch='--' if mod=='AA' else '//',zorder=3)
        ax.text(x.mean(),1.085,f'{task} ({avg})',ha='center',va='bottom',fontsize=13,weight='normal')
    ax.set_xlim(-.65,4.65); ax.set_ylim(0,1.05)
    ax.set_xticks(np.arange(5),['ACC','Precision','Recall','F1','MCC'],fontsize=13)
    ax.set_yticks([0,.25,.5,.75,1],['0','0.25','0.50','0.75','1.00'],fontsize=11)
    ax.set_ylabel('Score',fontsize=13); ax.tick_params(length=3)
    ax.set_axisbelow(True); ax.yaxis.grid(color='#E3E7EA',lw=.7)

def heatmap(ax,data):
    labels=data['labels']; n=len(labels)
    # Fixed physical blank row separates Average from individual types.
    mat=np.zeros((n+1,6))
    for k,metric in enumerate(['Precision','Recall','F1']):
        for j,mod in enumerate(['AA','NT']):
            val=data['models'][mod]['per'].set_index('Type').loc[labels,metric]
            mat[0,k*2+j]=val.mean()
            mat[1:,k*2+j]=val
    y=np.r_[0,np.arange(1,n+1)+.42]
    ax.set_xlim(-.5,5.5); ax.set_ylim(n+1.0,-.75)
    cmap=plt.colormaps['Blues']
    for i,yy in enumerate(y):
        for j in range(6):
            ax.add_patch(plt.Rectangle((j-.49,yy-.46),.98,.92,
                facecolor=cmap(mat[i,j]),edgecolor='white',lw=.8))
            ax.text(j,yy,f'{mat[i,j]:.4f}',ha='center',va='center',fontsize=11.2,
                color='white' if mat[i,j]>.6 else '#203446')
    for x in [1.5,3.5]: ax.axvline(x,color='white',lw=4)
    ax.set_yticks(y,['Average']+[textwrap_type(l,27) for l in labels],fontsize=12)
    ax.tick_params(axis='y',length=0,pad=15)
    ax.set_xticks(range(6),['AA','NT']*3,fontsize=12)
    ax.tick_params(axis='x',length=0,pad=4)
    for lbl in ax.get_xticklabels(): lbl.set_color(COLORS[lbl.get_text()])
    for k,label in enumerate(['Precision','Recall','F1']):
        ax.text((k*2+1)/6,1.015,label,transform=ax.transAxes,ha='center',va='bottom',fontsize=13)
    for i,yy in enumerate(y[1:]):
        ax.scatter(-.73,yy,s=29,c=base.TYPE_COLORS[i],marker='o',clip_on=False,zorder=5)
    for s in ax.spines.values(): s.set_visible(False)
    return mat

def cached_embedding(data,mod,path):
    source=OLD/data['domain']/'plot_data'/'umap'/f'{mod}_{path.stem}_umap.csv'
    config=json.loads(source.with_suffix('.json').read_text(encoding='utf-8'))
    assert config['configuration']['source_sha256']==base.digest(path)
    frame=base.csv_read(source)
    model=data['models'][mod]
    assert frame.id.is_unique and set(frame.id)==set(model['positive'].id)
    truth=model['positive'].set_index('id').loc[frame.id,'true_type'].tolist()
    assert truth==frame.Type.tolist()
    return frame

def embedding_panel(ax,frame,data,title):
    order=np.random.default_rng(20260921).permutation(len(frame))
    points=frame.iloc[order]
    mapping={label:base.TYPE_COLORS[i] for i,label in enumerate(data['labels'])}
    ax.scatter(points.UMAP1,points.UMAP2,c=[mapping[l] for l in points.Type],
        s=4.2,alpha=.8,linewidths=0,rasterized=True)
    lo=frame[['UMAP1','UMAP2']].min().to_numpy()
    hi=frame[['UMAP1','UMAP2']].max().to_numpy()
    center=(lo+hi)/2; half=max(hi-lo)*.55
    ax.set_xlim(center[0]-half,center[0]+half); ax.set_ylim(center[1]-half,center[1]+half)
    ax.set_box_aspect(1); ax.set_aspect('equal',adjustable='box')
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_xlabel('UMAP1',fontsize=12,labelpad=3)
    ax.set_ylabel('UMAP2',fontsize=12,labelpad=3)
    ax.set_title(title,fontsize=12.5,pad=6)
    for spine in ax.spines.values(): spine.set_visible(True); spine.set_linewidth(.8)

def save(fig,name,subfolder=''):
    folder=OUT/subfolder; folder.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw()
    texts=[t for t in fig.findobj(Text) if t.get_visible() and t.get_text()]
    # Every authored and auto-generated text object must use Arial.
    assert all(t.get_fontfamily()==['Arial'] for t in texts)
    sizes=sorted({float(t.get_fontsize()) for t in texts})
    renderer=fig.canvas.get_renderer()
    figbox=fig.bbox
    outside=[]
    for t in texts:
        b=t.get_window_extent(renderer)
        if b.x0<figbox.x0-2 or b.x1>figbox.x1+2 or b.y0<figbox.y0-2 or b.y1>figbox.y1+2:
            outside.append(t.get_text())
    assert not outside,('Text outside figure',name,outside)
    for ext in ['png','pdf','svg']:
        fig.savefig(folder/f'{name}.{ext}',dpi=300,facecolor='white',bbox_inches='tight',pad_inches=.10)
    preview=OUT/'previews'; preview.mkdir(exist_ok=True)
    fig.savefig(preview/f'{name}.png',dpi=110,facecolor='white',bbox_inches='tight',pad_inches=.08)
    FIGURE_AUDITS.append({'name':name,'inches':list(fig.get_size_inches()),'font':'Arial',
        'font_sizes_pt':sizes,'all_text_inside_canvas':True,'formats':['png','pdf','svg']})
    plt.close(fig)
    print(f'SAVED {name}',flush=True)

def main_figure(all_data):
    fig=plt.figure(figsize=(14,15.2))
    fig.legend(handles=model_handles(),loc='upper center',bbox_to_anchor=(.53,.999),
        ncol=2,frameon=False,fontsize=14,handlelength=2.2,columnspacing=2.1)
    for col,domain in enumerate(['VF','BGC']):
        data=all_data[domain]
        x=.078+col*.505; w=.392
        ax=fig.add_axes([x+.035,.757,w-.07,.174],projection='polar')
        radar(ax,data); panel(fig,'AB'[col],x-.054,.933)
        ax=fig.add_axes([x,.566,w,.134]); functional_bars(ax,data)
        panel(fig,'CD'[col],x-.054,.724)
        ax=fig.add_axes([.193+col*.505,.214,.282,.283])
        heatmap(ax,data); panel(fig,'EF'[col],x-.054,.515)
        # Best AA and NT projections stay in the main figure, using the same type palette as E/F.
        for j,mod in enumerate(['AA','NT']):
            model=data['models'][mod]
            frame=cached_embedding(data,mod,model['best'])
            ax=fig.add_axes([x+j*(w+.016)/2,.030,(w-.035)/2,.153])
            embedding_panel(ax,frame,data,f'{mod} · epoch {model["best_epoch"]}')
        panel(fig,'GH'[col],x-.054,.192)
    # A single numerical scale belongs to both type-wise heatmaps.
    cax=fig.add_axes([.510,.227,.009,.247])
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,1),cmap='Blues'),cax=cax)
    cb.set_ticks([0,.25,.5,.75,1]); cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=10,length=2,pad=2); cb.outline.set_linewidth(.6)
    cb.ax.yaxis.set_ticks_position('right')
    save(fig,'VF_BGC_main_combined')

def type_legend(ax,data,ncol):
    ax.axis('off')
    handles=[Line2D([0],[0],color=base.TYPE_COLORS[i],marker='o',linestyle='',ms=6,
                   label=textwrap_type(label,30)) for i,label in enumerate(data['labels'])]
    ax.legend(handles=handles,loc='center',bbox_to_anchor=(0,0,1,1),mode='expand',ncol=ncol,
        frameon=False,fontsize=11.5,handlelength=.8,handletextpad=.4,borderaxespad=0,
        columnspacing=1,labelspacing=.6)

def trajectory_figure(data,number):
    fig=plt.figure(figsize=(14.6,10.2 if data['domain']=='VF' else 9.3))
    for row,mod in enumerate(['AA','NT']):
        v=data['models'][mod]; files=sorted(p for p in v['features'] if p.name.startswith('epoch_'))+[v['best']]
        top=.927-row*.365; bottom=top-.295
        grid=fig.add_gridspec(1,len(files),left=.055,right=.982,top=top,bottom=bottom,wspace=.22)
        for j,path in enumerate(files):
            frame=cached_embedding(data,mod,path)
            title=f'Epoch {int(frame.epoch.iloc[0])}'
            if path==v['best']: title=f'Best · epoch {v["best_epoch"]}'
            ax=fig.add_subplot(grid[j]); embedding_panel(ax,frame,data,title)
        fig.text(.022,(top+bottom)/2,mod,rotation=90,ha='center',va='center',fontsize=16,weight='bold')
        panel(fig,'AB'[row],.019,top+.042)
    fig.text(.52,.982,data['domain'],ha='center',va='top',fontsize=18,weight='bold')
    type_legend(fig.add_axes([.055,.040,.927,.20]),data,4)
    save(fig,f'S{number}_{data["domain"]}_UMAP_training','supplementary')

def matrix(ax,data,mod,errors=False):
    labels=data['labels']; cm=data['models'][mod]['cm']; k=len(labels)
    if errors:
        values=cm.astype(float); values[np.arange(k),np.arange(k)]=np.nan
        upper=data['error_vmax']; label='Count'
    else:
        values=cm/cm.sum(axis=1,keepdims=True); upper=1; label='Proportion'
    cmap=plt.colormaps['Blues' if mod=='AA' else 'Oranges'].copy(); cmap.set_bad('#ECEEEF')
    im=ax.imshow(np.ma.masked_invalid(values),vmin=0,vmax=upper,cmap=cmap,aspect='equal')
    short={'Antimicrobial activity/Competitive advantage':'Activity/adv.',
           'Effector delivery system':'Delivery system','Immune modulation':'Immune mod.',
           'Nutritional/Metabolic factor':'Nutrition/metab.',
           'Post-translational modification':'PTM','Stress survival':'Stress survival'}
    xtypes=[short.get(l,l) for l in labels]+['Missed']
    ax.set_xticks(range(k+1),xtypes,rotation=90 if k>10 else 55,
                  ha='center' if k>10 else 'right',fontsize=10)
    ax.set_yticks(range(k),[textwrap_type(l,26) for l in labels],fontsize=10.5)
    ax.tick_params(length=2,pad=2)
    ax.set_xlabel('Predicted type',fontsize=12); ax.set_ylabel('True type',fontsize=12)
    ax.axvline(k-.5,color='#58626A',ls='--',lw=.8)
    ax.set_title(f'{mod} · '+('Type errors' if errors else 'Type confusion'),fontsize=14,pad=10)
    for i in range(k):
        for j in range(k+1):
            if errors and np.isfinite(values[i,j]) and values[i,j]>0:
                text=f'{int(values[i,j])}'
            elif not errors and i==j: text=f'{values[i,j]:.2f}'
            else: continue
            ax.text(j,i,text,ha='center',va='center',fontsize=7.8 if k>10 else 10.5,
                color='white' if values[i,j]>.6*upper else '#253F50')
    for s in ax.spines.values(): s.set_visible(True); s.set_linewidth(.6)
    cb=ax.figure.colorbar(im,ax=ax,fraction=.035,pad=.025)
    cb.ax.tick_params(labelsize=10,length=2)
    cb.outline.set_linewidth(.6)
    if errors: cb.locator=MaxNLocator(nbins=4,integer=True); cb.update_ticks()
    else: cb.set_ticks([0,.5,1])

def error_pairs(ax,data,mod,top=10):
    frame=data['models'][mod]['errors'].head(top).iloc[::-1]
    y=np.arange(len(frame)); maximum=int(frame.Count.max())
    ax.barh(y,frame.Type_correct,color='#389C8E',height=.67,edgecolor='#5B6A71',lw=.5)
    ax.barh(y,frame.Type_incorrect,left=frame.Type_correct,color='#D47D54',
        hatch='///',height=.67,edgecolor='#5B6A71',lw=.5)
    labels=[]
    for i,(_,r) in enumerate(frame.iterrows()):
        pred=f'non-{data["domain"]}' if r.predicted_subtype==data['negative'] else r.predicted_subtype
        labels.append(base.wrapped(f'{r.true_subtype} → {pred}',34))
        ax.text(r.Count+maximum*.018,i,f'{int(r.Count)} ({r.Type_correct_fraction:.0%})',
            va='center',ha='left',fontsize=10)
    ax.set_yticks(y,labels,fontsize=10.5); ax.tick_params(length=2,pad=3)
    ax.set_xlim(0,maximum*1.34); ax.set_ylim(-.65,len(frame)-.35)
    ax.set_xlabel('Count',fontsize=12)
    ax.set_title(f'{mod} · Subtype errors',fontsize=14,pad=10)
    ticks=MaxNLocator(nbins=4,integer=True).tick_values(0,maximum*1.34)
    ax.set_xticks(ticks[(ticks>=0)&(ticks<=maximum*1.34)])
    ax.tick_params(axis='x',labelsize=11); ax.set_axisbelow(True); ax.xaxis.grid(color='#E3E7EA',lw=.7)

def error_figure(data,number):
    fig=plt.figure(figsize=(14.2,17.0))
    fig.text(.52,.984,data['domain'],ha='center',va='top',fontsize=19,weight='bold')
    for col,mod in enumerate(['AA','NT']):
        x=.19+col*.50
        ax=fig.add_axes([x,.715,.278,.225]); matrix(ax,data,mod)
        panel(fig,'AB'[col],.02+col*.50,.96)
        ax=fig.add_axes([x,.380,.278,.225]); matrix(ax,data,mod,True)
        panel(fig,'CD'[col],.02+col*.50,.63)
        ax=fig.add_axes([.258+col*.5,.061,.222,.216]); error_pairs(ax,data,mod,top=8)
        panel(fig,'EF'[col],.02+col*.5,.300)
    handles=[Patch(facecolor='#389C8E',edgecolor='#59636A',label='Type retained'),
        Patch(facecolor='#D47D54',edgecolor='#59636A',hatch='///',label='Incorrect type or missed')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.54,.006),ncol=2,
        frameon=False,fontsize=11,handlelength=1.5)
    save(fig,f'S{number}_{data["domain"]}_confusion_and_errors','supplementary')

def subtype_macro(data_all):
    fig,axes=plt.subplots(2,2,figsize=(12.5,7.6))
    for col,domain in enumerate(['VF','BGC']):
        for row,avg in enumerate(['macro','weighted']):
            ax=axes[row,col]; data=data_all[domain]; x=np.arange(5)
            for j,mod in enumerate(['AA','NT']):
                val=scores(data,mod,'Subtype',avg)
                ax.bar(x+(j-.5)*.34,val,.34,color=COLORS[mod],edgecolor='#485761',lw=.5,
                    hatch='--' if mod=='AA' else '//',zorder=3)
            ax.set_xticks(x,['ACC','Precision','Recall','F1','MCC'],fontsize=12)
            ax.set_ylim(0,1.03); ax.set_yticks([0,.25,.5,.75,1])
            ax.set_ylabel('Score'); ax.set_title(f'{domain} · Subtype ({avg})',fontsize=15)
            ax.set_axisbelow(True); ax.yaxis.grid(color='#E3E7EA',lw=.7)
            ax.text(-.1,1.16,'ABCD'[row*2+col],transform=ax.transAxes,fontsize=18,weight='bold')
    fig.subplots_adjust(left=.065,right=.987,bottom=.08,top=.87,wspace=.20,hspace=.54)
    fig.legend(handles=model_handles(),loc='upper center',ncol=2,frameon=False,fontsize=13)
    save(fig,'S5_VF_BGC_subtype_metrics','supplementary')

def documents(all_data):
    notes='''# VF/BGC 合并主图与补充图

## 本次布局

主图左列 VF，右列 BGC。A/B 为二分类雷达图。C/D 为 type 的五指标。E/F 为逐 type Precision、Recall、F1 热图。G/H 各包含 AA、NT 最佳模型的 UMAP。热图类别名称旁的彩色圆点同时充当 UMAP 的类别图例。Subtype 指标和错误分析均放在补充材料。

所有文字均为 Arial，主图文字为 9.5–18 pt，大部分标签 12–15 pt，热图数字 11.2 pt。主图为 14 × 15.2 英寸设计画布，PNG 为 300 dpi，PDF/SVG 保留矢量文字。缩放整张图时，文字也会等比例缩放。若期刊最终宽度限制较窄，可用提供的 PDF/SVG 继续拆分排版。

只展示自己的 AA 和 NT 版本，没有其他方法的对比模型。本次改变版式和字体，不改变预测、阈值、类别映射、测试集或指标定义。

## 主图简短图注

Performance of VFScope and BGCScope on full-length test sequences. (A,B) Binary classification. (C,D) Type-level ACC, macro precision, macro recall, macro F1 and MCC. (E,F) Type-resolved precision, recall and F1, with macro averages shown separately. (G,H) UMAP projections at the selected AA and NT checkpoints. Colors follow the type markers in E and F. Type evaluation excludes reference negatives but retains missed positives as errors. Precision, recall and F1 in A and B are macro-averaged.

## 补充图

- S1：VF，AA 和 NT 的全部已保存 epoch UMAP，最佳模型放在每行末尾。
- S2：BGC，AA 和 NT 的全部已保存 epoch UMAP。BGC 仅有 epoch 0、20 和最佳模型，未补造快照。
- S3：VF 的混淆矩阵、错误计数和最常见的 8 个 subtype 错误对。
- S4：BGC 的对应错误分析。
- S5：VF 与 BGC 的 subtype 五指标，上排为 macro，下排为 weighted。

## 保留的统计约定

1. Type 仅在真实阳性样本上计算，真实负类不进入统计。漏检保留在分母中。补充混淆矩阵 Missed 列表示预测为负类的阳性样本，不是新增生物学 type。
2. Subtype 沿用论文最新口径，包含全部测试样本及负类。macro 与 weighted 均在 S5 明确标记，不以两者替代。
3. 主图的雷达、柱状图和热图使用统一 0–1 尺度。不隐藏任一版本的零分，不添加未计算的误差线或显著性标记。
4. UMAP 原封不动复用上一版已核查的坐标。此次没有重新拟合、重新挑种子、移动簇或删除点。跨面板坐标不代表定量可比的距离。
5. 错误对后的百分比表示该错误对中仍保留正确 type 的比例，不是错误率。
6. plot_data 保留每张图的数据与来源。绘图脚本在 code 内，原始预测和旧版图保留不动。
7. S3/S4 混淆矩阵按真实类别归一化。错误图色标为样本计数，两版本使用同一数值上限。VF 矩阵横轴对长类别名称使用缩写，对应的纵轴保留完整名称。PTM 指 Post-translational modification，Activity/adv. 指 Antimicrobial activity/Competitive advantage。
'''
    (OUT/'图注与排版说明.md').write_text(notes,encoding='utf-8')
    target=OUT/'plot_data'; target.mkdir(exist_ok=True)
    for domain,data in all_data.items():
        shutil.copytree(OLD/domain/'plot_data',target/domain,dirs_exist_ok=True)
    code=OUT/'code'; code.mkdir(exist_ok=True)
    for filename in ['compose_vf_bgc_merged.py','plot_vf_bgc_full_length.py']:
        shutil.copy2(HERE/filename,code/filename)
    audit={'font':'Arial','font_file':FONTPATH,'source_predictions_unchanged':True,
        'all_metrics_revalidated_from_sequence_predictions':True,'umap_coordinates_reused_unchanged':True,
        'only_own_AA_NT_variants':True,'main_includes_best_UMAP':True,'subtype_in_supplement_only':True,
        'figures':FIGURE_AUDITS,'visual_review':'pending'}
    (OUT/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')

def publish():
    shutil.copytree(OUT,DEST,dirs_exist_ok=True)
    archive=DEST/'VF_BGC_merged_main_and_supplementary.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file() and p!=archive: z.write(p,p.relative_to(DEST))
    with zipfile.ZipFile(archive) as z: assert z.testzip() is None
    print(f'DELIVERED {DEST}',flush=True)

def run():
    OUT.mkdir(parents=True,exist_ok=True)
    data={domain:base.read_domain(domain) for domain in ['VF','BGC']}
    print('SOURCE METRICS VERIFIED. Arial:',FONTPATH,flush=True)
    main_figure(data)
    for i,domain in enumerate(['VF','BGC']):
        trajectory_figure(data[domain],i+1)
        error_figure(data[domain],i+3)
    subtype_macro(data)
    documents(data)

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--publish',action='store_true')
    parser.add_argument('--previous-dir',type=Path,default=OLD)
    parser.add_argument('--output-dir',type=Path,default=OUT)
    args=parser.parse_args()
    OLD=args.previous_dir.resolve(); OUT=args.output_dir.resolve()
    if args.publish: publish()
    else: run()
