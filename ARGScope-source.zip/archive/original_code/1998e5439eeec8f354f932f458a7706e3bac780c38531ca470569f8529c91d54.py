"""Independently verify metric results with sklearn and the exported XLSX XML."""
import csv
import json
import math
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

BASE = Path(__file__).resolve().parent / "outputs" / "ablation_supplement_20260918"
payload = json.loads((BASE / "reviewed_results.json").read_text(encoding="utf-8"))
audit = json.loads((BASE / "audit.json").read_text(encoding="utf-8"))
tested = 0
for source in audit["ablation_inputs"]:
    with Path(source["path"]).open(encoding="utf-8-sig", newline="") as f:
        data = list(csv.DictReader(f))
    for level, stem in (("ARG/nonARG", "ARG"), ("Type", "type"), ("Subtype", "subtype")):
        y = [r[f"true_{stem}"] for r in data]
        p = [r[f"predicted_{stem}"] for r in data]
        results = [r for r in payload["rows"] if r["Modality"] == source["modality"]
                   and r["Model"] == source["model"] and r["Class"] == level]
        for r in results:
            avg = "binary" if stem == "ARG" else r["Average"]
            options = {"pos_label": "1"} if stem == "ARG" else {}
            prf = precision_recall_fscore_support(y, p, average=avg, zero_division=0, **options)
            expected = (accuracy_score(y, p), *prf[:3], matthews_corrcoef(y, p))
            for m, value in zip(("ACC", "Precision", "Recall", "F1", "MCC"), expected):
                assert math.isclose(r[m], value, abs_tol=1e-12), (source, level, r["Average"], m, r[m], value)
                tested += 1

# Check all 56 result rows in the saved XLSX, not just the in-memory workbook.
ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
expected_ranges = json.loads((BASE / "expected_ranges.json").read_text(encoding="utf-8"))
xlsx = BASE / "消融结果汇总.xlsx"
with zipfile.ZipFile(xlsx) as z:
    strings = []
    if "xl/sharedStrings.xml" in z.namelist():
        tree = ET.fromstring(z.read("xl/sharedStrings.xml"))
        strings = ["".join(t.text or "" for t in s.findall(".//s:t", ns)) for s in tree]
    workbook = ET.fromstring(z.read("xl/workbook.xml"))
    sheets = [s.attrib["name"] for s in workbook.findall("s:sheets/s:sheet", ns)]
    assert sheets == ["Protein", "DNA"]
    for sheet_number, sheet_name in enumerate(sheets, 1):
        tree = ET.fromstring(z.read(f"xl/worksheets/sheet{sheet_number}.xml"))
        cells = {}
        for c in tree.findall(".//s:sheetData/s:row/s:c", ns):
            v = c.find("s:v", ns)
            if c.get("t") == "s":
                value = strings[int(v.text)]
            elif c.get("t") == "inlineStr":
                value = "".join(t.text or "" for t in c.findall(".//s:t", ns))
            elif c.get("t") == "str":
                value = v.text if v is not None else ""
            elif v is not None and v.text is not None:
                value = float(v.text)
            else:
                value = None
            cells[c.attrib["r"]] = value
        for expected in (r for r in expected_ranges if r["sheet"] == sheet_name):
            start = int(expected["range"].split(":")[0][1:])
            for i, row in enumerate(expected["matrix"]):
                for j, value in enumerate(row):
                    actual = cells[f"{chr(65+j)}{start+i}"]
                    if isinstance(value, (float, int)):
                        assert math.isclose(value, actual, abs_tol=1e-12), (sheet_name, i, j, value, actual)
                    else:
                        assert value == actual, (sheet_name, i, j, value, actual)
audit["independent_sklearn_verification"] = {"metric_values_checked": tested, "absolute_tolerance": 1e-12, "passed": True}
audit["exported_xlsx_all_56_rows_verified"] = True
(BASE / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"PASS: {tested} independently recomputed metric values; all 56 saved workbook rows match.")
