"""Audit the four fixed VF/BGC test predictions and update only type heatmaps.

Raw predictions, source documents, other plots and UMAP coordinates stay untouched.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import math
import textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
from matplotlib.ticker import FormatStrFormatter
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
OLD = HERE / 'outputs/vf_bgc_merged_20260922_v6'
OUT = HERE / 'outputs/vf_bgc_including_negative_20260922'
METRICS = ['ACC', 'Precision', 'Recall', 'F1', 'MCC']
SPECS = {
    'VF': dict(root=Path(r'E:\1. ARGmodel\毒力因子数据处理\独立因子新结果'), negative='non-VF',
               metadata='VF_nonVF_ID表_split.csv', test='VF_nonVF_ID表_test.csv',
               models=['1.result/1Protein_student_VF', '1.result/2DNA_student_VF']),
    'BGC': dict(root=Path(r'E:\1. ARGmodel\BGC数据处理\BGC_novel dataset'), negative='nonBGC',
                metadata='BGC_nonBGC_id_type_subtype_split.csv', test='BGC_nonBGC_id_type_subtype_test.csv',
                models=['1 Result/1.Protein_student_BGC', '1 Result/2.DNA_student_BGC'])}
SUPPLEMENT = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary_materials_including_nonARG_20260922.docx')
MANUSCRIPT = SUPPLEMENT.with_name('1. ARGScope_manuscript.docx')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return pd.read_csv(path, encoding='utf-8-sig', keep_default_na=False)


def calculate(ytrue, ypred, labels):
    """Independent marginal-count calculation, verified against sklearn."""
    truth, pred = list(ytrue), list(ypred)
    assert truth and len(truth) == len(pred)
    assert set(truth) <= set(labels) and set(pred) <= set(labels)
    actual, predicted = Counter(truth), Counter(pred)
    correct = Counter(t for t, p in zip(truth, pred) if t == p)
    n = len(truth)
    per = []
    for label in labels:
        tp, support, calls = correct[label], actual[label], predicted[label]
        per.append(dict(Label=label, Support=support, Predicted=calls, TP=tp,
                        FP=calls-tp, FN=support-tp, TN=n-support-calls+tp,
                        Precision=tp/calls if calls else 0., Recall=tp/support if support else 0.,
                        F1=2*tp/(support+calls) if support+calls else 0.))
    counts = sum(correct.values())
    denom = math.sqrt((n*n-sum(v*v for v in actual.values())) *
                      (n*n-sum(v*v for v in predicted.values())))
    mcc = (counts*n-sum(actual[k]*predicted[k] for k in labels))/denom if denom else 0.
    rows = []
    for avg in ['macro', 'weighted', 'micro']:
        row = dict(Average=avg, ACC=counts/n, MCC=mcc)
        for metric in ['Precision', 'Recall', 'F1']:
            if avg == 'micro':
                row[metric] = counts/n
            elif avg == 'weighted':
                row[metric] = sum(c[metric]*c['Support'] for c in per)/n
            else:
                row[metric] = sum(c[metric] for c in per)/len(labels)
        p, r, f, _ = precision_recall_fscore_support(truth, pred, labels=labels,
                                                    average=avg, zero_division=0)
        np.testing.assert_allclose([row[k] for k in METRICS],
            [accuracy_score(truth, pred), p, r, f, matthews_corrcoef(truth, pred)],
            rtol=0, atol=1e-12)
        rows.append(row)
    return rows, per


def audit_data():
    protected = {str(p): sha(p) for p in [SUPPLEMENT, MANUSCRIPT]}
    all_rows, all_per, audits, hashes, changes = [], [], [], [], []
    domains = {}
    for domain, spec in SPECS.items():
        root, neg = spec['root'], spec['negative']
        meta_path = root/'Dataset_split'/spec['metadata']
        test_path = root/'Dataset_split'/spec['test']
        ids_path = root/'Dataset_split/test_ids.txt'
        meta, test = read(meta_path), read(test_path)
        assert meta.id.is_unique and test.id.is_unique
        ids = ids_path.read_text(encoding='utf-8-sig').splitlines()
        assert len(ids) == len(set(ids)) == len(test)
        assert set(ids) == set(test.id) == set(meta.loc[meta.split.eq('test'), 'id'])
        palette = read(OLD/f'plot_data/{domain}/type_palette.csv')
        labels = palette.Type.tolist() + [neg]
        assert set(labels) == set(meta.type)
        subtype_labels = sorted(set(meta.subtype))
        assert neg in subtype_labels
        domains[domain] = dict(labels=labels, negative=neg, palette=palette, models={})
        previous_manifest = read(OLD/f'plot_data/{domain}/source_manifest.csv')
        for _, source in previous_manifest.iterrows():
            source_path = Path(source.Path)
            assert sha(source_path) == source.SHA256, ('Source changed', source_path)
            hashes.append(dict(Domain=domain, Path=str(source_path), SHA256=source.SHA256))
        original_all = read(root/'统一口径结果_20260921/02_all_averages.csv')
        original_per = read(OLD/f'plot_data/{domain}/per_type_metrics.csv')
        for mod, rel in zip(['AA', 'NT'], spec['models']):
            model = f'{domain}Scope-{mod}'
            path = root/rel/'test_sequence_predictions.csv'
            frame = read(path)
            assert frame.id.is_unique and set(frame.id) == set(ids)
            assert frame.split.eq('test').all()
            frame = frame.set_index('id').loc[test.id].reset_index()
            for key in ['type', 'subtype']:
                assert frame[f'true_{key}'].tolist() == test[key].tolist()
            for prefix in ['true', 'predicted']:
                assert frame[f'{prefix}_binary'].eq(neg).equals(frame[f'{prefix}_type'].eq(neg))
                assert frame[f'{prefix}_binary'].eq(neg).equals(frame[f'{prefix}_subtype'].eq(neg))
            # Confirm that including the full fixed subtype universe does not change C/D.
            assert set(subtype_labels) == set(frame.true_subtype) | set(frame.predicted_subtype)
            for task, key, universe in [('Binary', 'binary', [domain, neg]),
                                         ('Type', 'type', labels),
                                         ('Subtype', 'subtype', subtype_labels)]:
                values, per = calculate(frame[f'true_{key}'], frame[f'predicted_{key}'], universe)
                for row in values:
                    result = dict(Domain=domain, Model=model, Task=task, N=len(frame),
                                  N_labels=len(universe), **row)
                    all_rows.append(result)
                    old = original_all.loc[original_all.Model.eq(model) &
                        original_all.Average.eq(row['Average']) &
                        (original_all.Task.eq(task) if task != 'Binary' else
                         ~original_all.Task.isin(['Type', 'Subtype']))].iloc[0]
                    if task != 'Type':
                        np.testing.assert_allclose([row[k] for k in METRICS],
                                                   old[METRICS].to_numpy(float), rtol=0, atol=1e-12)
                    for metric in METRICS:
                        changes.append(dict(Model=model, Task=task, Average=row['Average'],
                                            Metric=metric, Old=float(old[metric]), New=row[metric],
                                            Difference=row[metric]-float(old[metric])))
                if task == 'Type':
                    all_per.extend(dict(Domain=domain, Model=model, **r) for r in per)
                    domains[domain]['models'][mod] = pd.DataFrame(per).set_index('Label')
                    # Independent confirmation of the prior positive-only heatmap.
                    positive = frame.loc[frame.true_type.ne(neg)]
                    _, old_per = calculate(positive.true_type, positive.predicted_type, labels)
                    for row in old_per:
                        if row['Label'] == neg:
                            continue
                        reported = original_per.loc[original_per.Model.eq(model) &
                                                    original_per.Label.eq(row['Label'])].iloc[0]
                        np.testing.assert_allclose([row[k] for k in ['Precision','Recall','F1']],
                            reported[['Precision','Recall','F1']].to_numpy(float), rtol=0, atol=1e-12)
            audits.append(dict(Model=model, N=len(frame), Reference_positive=int(frame.true_type.ne(neg).sum()),
                               Reference_negative=int(frame.true_type.eq(neg).sum()),
                               False_negative=int((frame.true_type.ne(neg)&frame.predicted_type.eq(neg)).sum()),
                               False_positive=int((frame.true_type.eq(neg)&frame.predicted_type.ne(neg)).sum()),
                               Type_labels=len(labels), Subtype_labels=len(subtype_labels),
                               Source=str(path), SHA256=sha(path)))
    return domains, pd.DataFrame(all_rows), pd.DataFrame(all_per), audits, hashes, changes, protected


def label_text(label, domain):
    if label == SPECS[domain]['negative']:
        return f'Non-{domain}'
    overrides = {'Antimicrobial activity/Competitive advantage': 'Antimicrobial activity/\nCompetitive advantage',
                 'Nutritional/Metabolic factor': 'Nutritional/Metabolic\nfactor',
                 'Post-translational modification': 'Post-translational\nmodification'}
    return overrides.get(label, '\n'.join(textwrap.wrap(label, 27, break_long_words=False)))


def heatmap(domain, data, metrics):
    labels = data['labels']
    n = len(labels)
    vf = domain == 'VF'
    fig = plt.figure(figsize=(10.3 if vf else 8.3, 8.7 if vf else 5.5))
    # Larger type labels and numerical text, fixed AA/NT order, no outer frame.
    ax = fig.add_axes([.345 if vf else .18, .075, .575 if vf else .73, .86])
    ys = np.r_[0., np.arange(1, n+1)+.43]
    mat = np.zeros((n+1, 6))
    for k, metric in enumerate(['Precision', 'Recall', 'F1']):
        for j, mod in enumerate(['AA', 'NT']):
            vals = data['models'][mod].loc[labels, metric].to_numpy(float)
            mat[0, k*2+j], mat[1:, k*2+j] = vals.mean(), vals
            expected = metrics.loc[metrics.Model.eq(f'{domain}Scope-{mod}') &
                metrics.Task.eq('Type') & metrics.Average.eq('macro'), metric].item()
            assert abs(mat[0,k*2+j]-expected) < 1e-12
    cmap = plt.colormaps['Blues']
    for i, y in enumerate(ys):
        for j in range(6):
            ax.add_patch(Rectangle((j-.49, y-.46), .98, .92, facecolor=cmap(mat[i,j]),
                                   edgecolor='white', linewidth=.65))
            ax.text(j, y, f'{mat[i,j]:.4f}', ha='center', va='center', fontsize=13.4,
                    color='white' if mat[i,j]>.60 else '#243642')
    ax.set_xlim(-.5, 5.5)
    ax.set_ylim(ys[-1]+.54, -.65)
    ax.set_yticks(ys, ['Average']+[label_text(x, domain) for x in labels], fontsize=14)
    ax.tick_params(axis='y', length=0, pad=14)
    ax.set_xticks(range(6), ['AA', 'NT']*3, fontsize=14)
    ax.tick_params(axis='x', length=0, pad=5)
    for tick in ax.get_xticklabels():
        tick.set_color('#397E9C' if tick.get_text()=='AA' else '#C68537')
    colors = dict(zip(data['palette'].Type, data['palette'].Color))
    colors[data['negative']] = '#91999E'
    for y, label in zip(ys[1:], labels):
        ax.scatter(-.64, y, c=colors[label], s=27, clip_on=False, linewidths=0)
    for x in [1.5, 3.5]:
        ax.axvline(x, color='white', linewidth=3.3)
    for k, title in enumerate(['Precision', 'Recall', 'F1']):
        ax.text((k*2+1)/6, 1.014, title, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=15.5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    pos = ax.get_position()
    cax = fig.add_axes([pos.x1+.017, pos.y0+.07, .014, pos.height-.14])
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,1), cmap=cmap), cax=cax)
    cb.solids.set_rasterized(False)
    cb.set_ticks([0,.25,.5,.75,1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.4f'))
    cb.ax.tick_params(labelsize=11.5, length=2, pad=3)
    cb.outline.set_linewidth(.6)
    stem = f'Figure5{"E" if vf else "F"}_{domain}_type_heatmap_including_non{domain}'
    fig.canvas.draw()
    assert all(t.get_fontfamily()==['Arial'] for t in fig.findobj(matplotlib.text.Text) if t.get_text())
    for fonttype, folder in [('path', OUT), ('none', OUT/'editable_text')]:
        with plt.rc_context({'svg.fonttype':fonttype}):
            fig.savefig(folder/f'{stem}.svg', transparent=True, bbox_inches='tight', pad_inches=.025)
    fig.savefig(OUT/'previews'/f'{stem}.png', dpi=160, facecolor='white', bbox_inches='tight', pad_inches=.025)
    plt.close(fig)
    pd.DataFrame(mat, index=['Average']+labels,
                 columns=[f'{metric}_{mod}' for metric in ['Precision','Recall','F1'] for mod in ['AA','NT']]
                 ).to_csv(OUT/'data'/f'{domain}_heatmap_values.csv', encoding='utf-8-sig')
    return dict(File=stem+'.svg', Panel='E' if vf else 'F', Classes=n,
                Numeric_cells=int(mat.size), Macro_average_over_all_classes=True,
                Non_target_included=True, Arial=True, Transparent=True,
                Annotation_font_pt=13.4, Label_font_pt=14, Outer_padding_pt=1.8)


def main():
    for p in [OUT, OUT/'editable_text', OUT/'previews', OUT/'data']:
        p.mkdir(parents=True, exist_ok=True)
    font_manager.findfont('Arial', fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial', 'font.size':14, 'axes.spines.top':False,
                         'axes.spines.right':False, 'svg.fonttype':'path'})
    domains, overall, per, audit, sources, changes, protected = audit_data()
    overall.to_csv(OUT/'data/all_averages_including_negative.csv', index=False, encoding='utf-8-sig')
    macro = overall.loc[overall.Average.eq('macro')].copy()
    macro.to_csv(OUT/'data/S19_S20_replacement_macro_values.csv', index=False, encoding='utf-8-sig')
    per.to_csv(OUT/'data/per_type_including_negative.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(audit).to_csv(OUT/'data/population_audit.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(sources).drop_duplicates().to_csv(OUT/'data/source_manifest.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(changes).to_csv(OUT/'data/changes_vs_previous_definition.csv', index=False, encoding='utf-8-sig')
    panels = [heatmap(domain, data, overall) for domain, data in domains.items()]
    for p, expected in protected.items():
        assert sha(p) == expected, p
    for s in sources:
        assert sha(s['Path']) == s['SHA256']
    verification = dict(Independent_calculation='Marginal TP/FP/FN counts and sklearn agree within 1e-12',
        Panels_updated=panels, A_B_binary_values_unchanged=True, C_D_subtype_macro_values_unchanged=True,
        G_H_UMAP_not_modified=True, Protected_documents=protected,
        Documents_and_source_predictions_unmodified=True, Population_audit=audit)
    (OUT/'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding='utf-8')
    print(macro[['Model','Task',*METRICS]].to_string(index=False, float_format=lambda v:f'{v:.4f}'))
    print('WROTE', OUT)


if __name__ == '__main__':
    main()
