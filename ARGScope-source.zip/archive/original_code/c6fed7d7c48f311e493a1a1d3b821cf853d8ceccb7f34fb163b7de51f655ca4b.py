"""Read-only ARGNet audit. Writes diagnostic evidence only, never result tables."""
import ast
import json
from pathlib import Path
import numpy as np
import pandas as pd

TRAIN=Path(r'E:\1. ARGmodel\1. NonARG_training')
RAW=TRAIN/'ARGscope_result_9.16/ARGnet'
RESULT=TRAIN/'new model result8.24/1.training dataset/ALL_result'
EVIDENCE=Path(__file__).resolve().parent/'argnet_mapping_audit_20260921'
EVIDENCE.mkdir(exist_ok=True)
LABELS=sorted(pd.read_csv(RESULT/'ARGScope_23_types.csv').Type)
METRICS=['Accuracy','Precision','Recall','F1','MCC']

def mapping_dict(path):
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    return ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.AnnAssign) and getattr(n.target,'id','')=='TYPE_MAPPING'))

def measures(y,p,labels=LABELS):
    y=np.asarray(y,str); p=np.asarray(p,str); universe=np.union1d(np.union1d(y,p),labels)
    yi=np.searchsorted(universe,y); pi=np.searchsorted(universe,p); n=len(y)
    t=np.bincount(yi,minlength=len(universe)); q=np.bincount(pi,minlength=len(universe))
    tp=np.bincount(yi[y==p],minlength=len(universe)); mask=np.isin(universe,labels)
    prec=np.divide(tp,q,out=np.zeros(len(t)),where=q!=0)
    rec=np.divide(tp,t,out=np.zeros(len(t)),where=t!=0)
    f1=np.divide(2*tp,t+q,out=np.zeros(len(t)),where=t+q!=0)
    d=((float(n*n)-q.astype(float)@q)*(float(n*n)-t.astype(float)@t))**.5
    return dict(Accuracy=float(np.mean(y==p)),Precision=float(prec[mask].mean()),
        Recall=float(rec[mask].mean()),F1=float(f1[mask].mean()),
        MCC=float((n*tp.sum()-t.astype(float)@q)/d) if d else 0.)

maps={mod:mapping_dict(RAW/('protein' if mod=='Protein' else 'DNA')/f'calculate_ARGNet_{"protein" if mod=="Protein" else "DNA"}_type_metrics.py') for mod in ['Protein','DNA']}
assert maps['Protein']==maps['DNA']
checks=[]; rules=[]; stages=[]; perclasses=[]
for mod in ['Protein','DNA']:
    folder=RAW/('protein' if mod=='Protein' else 'DNA')
    truth=pd.read_csv(folder/'all_arg_nonarg_id_label.csv',keep_default_na=False).set_index('id')
    assert truth.index.is_unique
    reported=pd.read_csv(RESULT/mod/'01_Type_barplot_macro_five_metrics.csv').query("Model == 'ARGNet'")
    for pct in [60,70,80,90,100]:
        stem=(f'protein_{pct}pct_5parts_argnet-l_aa_result' if mod=='Protein' else
              ('dna_100pct_clean_argnet-l_nt_result' if pct==100 else f'dna_{pct}pct_5parts_clean_argnet-l_nt_result'))
        raw=pd.read_csv(folder/(stem+'.txt'),sep='\t',keep_default_na=False).set_index('test_id')
        mapped_path=folder/('ARGNet_type_metrics_results' if mod=='Protein' else 'ARGNet_DNA_type_metrics_results')/'mapped_predictions'/(stem+'_mapped_type_predictions.csv')
        mapped=pd.read_csv(mapped_path,keep_default_na=False).set_index('test_id')
        assert raw.index.is_unique and mapped.index.is_unique and set(raw.index)==set(mapped.index)
        mapped=mapped.loc[raw.index]
        base=raw.index if pct==100 else raw.index.str.replace(r'_[1-5]$','',regex=True)
        assert set(base)<=set(truth.index)
        expected_truth=truth.loc[base,'type'].to_numpy()
        assert np.array_equal(mapped.true_type,expected_truth)
        assert np.array_equal(mapped.true_subtype,truth.loc[base,'subtype'].to_numpy())
        bp=raw.ARG_prediction.str.replace(r'[\s_-]+','',regex=True).str.lower().map({'arg':'ARG','nonarg':'nonARG'})
        assert not bp.isna().any() and np.array_equal(bp,mapped.ARG_prediction)
        assert np.array_equal(raw.resistance_category,mapped.raw_resistance_category)
        # ARGNet leaves probability blank on some nonARG calls; verify exact tokens.
        assert np.array_equal(raw.probability.astype(str),mapped.probability.astype(str))
        category=raw.resistance_category.str.strip().str.lower().str.replace(' ','_',regex=False)
        pred=category.map({k:v[0] for k,v in maps[mod].items()}).fillna('__ARGNET_UNMAPPED__')
        pred.loc[bp.eq('nonARG')]='nonARG'
        assert np.array_equal(pred,mapped.predicted_type)
        mask=np.isin(expected_truth,LABELS)
        y=expected_truth[mask]; p=pred.to_numpy()[mask]
        metric=measures(y,p)
        np.testing.assert_allclose([metric[k] for k in METRICS],reported.query('Completeness == @pct')[METRICS].to_numpy()[0],rtol=0,atol=1e-12)
        checks.append(dict(Modality=mod,Completeness=pct,Raw_rows=len(raw),Evaluated_rows=int(mask.sum()),
            Truth_mismatches=0,Raw_prediction_mapping_mismatches=0,Duplicate_IDs=0,Correct=int(np.sum(y==p)),
            Outside23_predictions_retained=int(np.sum(~np.isin(p,LABELS))),**metric))
        for cat in sorted(set(category)):
            ix=(category==cat)&mask&bp.eq('ARG')
            if not ix.any():continue
            target,status,_=maps[mod].get(cat,('__ARGNET_UNMAPPED__','unmapped',''))
            yy=expected_truth[ix.to_numpy()]; pp=pred[ix].to_numpy()
            rules.append(dict(Modality=mod,Completeness=pct,Raw_category=cat,Target=target,Status=status,
                Evaluated_predictions=len(yy),Correct=int(np.sum(yy==pp)),
                Truth_distribution=json.dumps(pd.Series(yy).value_counts().to_dict(),ensure_ascii=False)))
        if pct==100:
            for name,sel,lab in [('all_samples_all_labels',np.ones(len(raw),bool),np.union1d(expected_truth,pred)),
                ('all_samples_fixed23_P_R_F1',np.ones(len(raw),bool),LABELS),
                ('true_ARG_fixed23_P_R_F1',expected_truth!='nonARG',LABELS),('fixed23',mask,LABELS)]:
                stages.append(dict(Modality=mod,Stage=name,Labels_averaged=len(lab),N=int(sel.sum()),**measures(expected_truth[sel],pred.to_numpy()[sel],lab)))
            alternative=p.copy(); cats=category.to_numpy()[mask]
            alternate_mask=np.isin(cats,['aminocoumarin','glycopeptide','tetracenomycin']) & (p!='nonARG')
            alternative[alternate_mask]='__BROAD_LABEL_NOT_RESOLVED__'
            stages.append(dict(Modality=mod,Stage='sensitivity_only_no_broad_to_narrow_credit',Labels_averaged=23,N=len(y),**measures(y,alternative)))
            for label in LABELS:
                tp=int(np.sum((y==label)&(p==label))); fp=int(np.sum((y!=label)&(p==label))); fn=int(np.sum((y==label)&(p!=label)))
                perclasses.append(dict(Modality=mod,Type=label,Support=int(np.sum(y==label)),TP=tp,FP=fp,FN=fn,
                    Precision=tp/(tp+fp) if tp+fp else 0.,Recall=tp/(tp+fn) if tp+fn else 0.))
        print(f'{mod} {pct}%: raw/truth/mapping/metrics all match; {int(np.sum(y==p))}/{len(y)} Type correct.',flush=True)

frames={'raw_to_metrics_checks':pd.DataFrame(checks),'mapping_rule_counts':pd.DataFrame(rules),
        'scope_and_mapping_sensitivity':pd.DataFrame(stages),'per_type_100pct_check':pd.DataFrame(perclasses)}
for name,df in frames.items():df.to_csv(EVIDENCE/(name+'.csv'),index=False,encoding='utf-8-sig',float_format='%.15g')
(EVIDENCE/'audit_summary.json').write_text(json.dumps({'Protein_DNA_mapping_identical':True,
    'Files_checked':len(checks),'Total_raw_rows':sum(x['Raw_rows'] for x in checks),
    'Mismatch_rows':0,'Result_files_modified':False,'Checks':checks,'Sensitivity':stages},ensure_ascii=False,indent=2),encoding='utf-8')
print(frames['scope_and_mapping_sensitivity'].to_string(index=False))
print(frames['per_type_100pct_check'].query("Modality == 'Protein'").sort_values('Recall').head(8).to_string(index=False))
