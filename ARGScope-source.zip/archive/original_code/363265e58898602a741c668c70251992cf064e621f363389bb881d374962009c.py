#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查 DNA 与 protein 是否能通过翻译对应（PyCharm 直接运行版）。

对应优先级：
1. Nucleotide_SARG 结构表：NucleotideID -> AminoAcidID
2. DNA FASTA ID 与 protein FASTA ID 完全相同
3. 可选的两列自定义映射表：dna_id -> protein_id

主要判定：
- 正向第 1 阅读框（+0）完全一致：标准 CDS/反向翻译序列应满足
- 其他阅读框完全一致：序列能编码该蛋白，但方向或起始位置不是标准 +0
- 部分一致或不一致
"""

from __future__ import annotations

import gzip
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd


# =============================================================================
# 只需要修改这里
# =============================================================================
# 把脚本、FASTA 和结构表放在同一个文件夹时，只填写文件名即可。
PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
DNA_FASTA = "all_arg_nonarg_dna.fasta"

# 用来建立 NucleotideID -> AminoAcidID 对应关系。
# 如果文件就在脚本同一目录，默认值无需修改。
NUCLEOTIDE_STRUCTURE = "Nucleotide_SARG_v3.2_Long_structure.txt"

# 可选：当 DNA ID 既不是 NucleotideID，也不等于 protein ID 时使用。
# 表格必须有 dna_id 和 protein_id 两列；不需要时保持空字符串。
CUSTOM_ID_MAP = ""

OUTPUT_DIR = "DNA_protein_translation_check"

# “部分匹配”阈值，只影响结果标签，不影响实际 identity 数值。
HIGH_IDENTITY_THRESHOLD = 0.95


SCRIPT_DIR = Path(__file__).resolve().parent

CODON_TABLE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

COMPLEMENT = str.maketrans(
    "ACGTRYMKBDHVNacgtrymkbdhvn",
    "TGCAYRKMVHDBNtgcayrkmvhdbn",
)


def resolve_file(value: str, description: str, required: bool = True) -> Optional[Path]:
    value = value.strip()
    if not value:
        if required:
            raise ValueError(f"尚未填写 {description}")
        return None
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = SCRIPT_DIR / path
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(
            f"找不到 {description}:\n{path}\n"
            f"请检查代码顶部的文件名。脚本目录为：{SCRIPT_DIR}"
        )
    return path


def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("rt", encoding="utf-8")


def read_fasta(path: Path) -> Dict[str, str]:
    """使用 FASTA 标题中第一个空格前的内容作为 ID。"""
    records: Dict[str, str] = {}
    current_id: Optional[str] = None
    chunks: List[str] = []

    def save_record() -> None:
        nonlocal current_id, chunks
        if current_id is None:
            return
        if current_id in records:
            raise ValueError(f"{path.name} 中存在重复 FASTA ID：{current_id}")
        records[current_id] = "".join(chunks).replace(" ", "").upper()

    with open_text(path) as handle:
        for line_number, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                save_record()
                header = line[1:].strip()
                if not header:
                    raise ValueError(f"{path}:{line_number} 的 FASTA 标题为空")
                current_id = header.split()[0]
                chunks = []
            else:
                if current_id is None:
                    raise ValueError(f"{path}:{line_number} 在标题前出现序列")
                chunks.append(line)
        save_record()
    return records


def clean_protein(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("-", "").rstrip("*")


def clean_dna(sequence: str) -> str:
    return "".join(sequence.split()).upper().replace("U", "T").replace("-", "")


def reverse_complement(sequence: str) -> str:
    return sequence.translate(COMPLEMENT)[::-1]


def translate(dna: str, frame: int, reverse: bool) -> Tuple[str, int]:
    dna = clean_dna(dna)
    if reverse:
        dna = reverse_complement(dna)
    amino_acids: List[str] = []
    for position in range(frame, len(dna) - 2, 3):
        amino_acids.append(CODON_TABLE.get(dna[position:position + 3], "X"))
    raw_protein = "".join(amino_acids)
    internal_stops = raw_protein.rstrip("*").count("*")
    return raw_protein.rstrip("*"), internal_stops


def compatible(a: str, b: str) -> bool:
    # X、B、Z、J、U、O 视为模糊氨基酸；严格一致结果会另外输出。
    ambiguous = set("XBZJUO?")
    return a == b or a in ambiguous or b in ambiguous


def identity(reference: str, query: str) -> float:
    """全长 identity；长度差异也会受到惩罚。"""
    denominator = max(len(reference), len(query))
    if denominator == 0:
        return 1.0
    matches = sum(compatible(a, b) for a, b in zip(reference, query))
    return matches / denominator


def longest_exact_compatible_run(reference: str, query: str) -> int:
    longest = 0
    current = 0
    for a, b in zip(reference, query):
        if compatible(a, b):
            current += 1
            longest = max(longest, current)
        else:
            current = 0
    return longest


def check_pair(protein: str, dna: str) -> Dict[str, object]:
    protein = clean_protein(protein)
    dna = clean_dna(dna)
    invalid_dna = sorted(set(dna) - set("ACGTRYSWKMBDHVN"))
    invalid_protein = sorted(set(protein) - set("ABCDEFGHIKLMNPQRSTVWXYZJUO?"))

    frames = []
    for reverse in (False, True):
        strand = "-" if reverse else "+"
        for offset in range(3):
            translated, stops = translate(dna, offset, reverse)
            frames.append({
                "frame": f"{strand}{offset}",
                "translated": translated,
                "strict_exact": translated == protein,
                "compatible_exact": (
                    len(translated) == len(protein)
                    and all(compatible(a, b) for a, b in zip(protein, translated))
                ),
                "identity": identity(protein, translated),
                "longest_run": longest_exact_compatible_run(protein, translated),
                "internal_stops": stops,
            })

    frame_preference = {"+0": 5, "+1": 4, "+2": 3, "-0": 2, "-1": 1, "-2": 0}
    best = max(
        frames,
        key=lambda x: (
            int(x["compatible_exact"]),
            x["identity"],
            x["longest_run"],
            frame_preference[x["frame"]],
        ),
    )
    forward0 = next(x for x in frames if x["frame"] == "+0")
    expected_length = len(dna) in {3 * len(protein), 3 * (len(protein) + 1)}

    if invalid_dna:
        result = "invalid_DNA_characters"
    elif invalid_protein:
        result = "invalid_protein_characters"
    elif forward0["strict_exact"] and expected_length:
        result = "EXACT_forward_frame0"
    elif forward0["compatible_exact"] and expected_length:
        result = "EXACT_frame0_with_ambiguous_residues"
    elif best["compatible_exact"]:
        result = "EXACT_but_other_frame_or_length"
    elif best["identity"] >= HIGH_IDENTITY_THRESHOLD:
        result = "HIGH_IDENTITY_not_exact"
    else:
        result = "NOT_MATCHED"

    return {
        "protein_length_aa": len(protein),
        "dna_length_nt": len(dna),
        "dna_length_is_3x_or_plus_stop": expected_length,
        "invalid_DNA_characters": "".join(invalid_dna),
        "invalid_protein_characters": "".join(invalid_protein),
        "forward_frame0_identity": forward0["identity"],
        "forward_frame0_strict_exact": forward0["strict_exact"],
        "forward_frame0_compatible_exact": forward0["compatible_exact"],
        "forward_frame0_internal_stops": forward0["internal_stops"],
        "best_frame": best["frame"],
        "best_frame_identity": best["identity"],
        "best_frame_compatible_exact": best["compatible_exact"],
        "best_frame_internal_stops": best["internal_stops"],
        "longest_matching_run_aa": best["longest_run"],
        "translation_result": result,
    }


def read_custom_map(path: Optional[Path]) -> pd.DataFrame:
    if path is None:
        return pd.DataFrame(columns=["dna_id", "protein_id"])
    table = pd.read_csv(path, sep=None, engine="python", dtype=str,
                        keep_default_na=False)
    required = {"dna_id", "protein_id"}
    if not required.issubset(table.columns):
        raise ValueError(
            f"自定义映射表必须包含 dna_id 和 protein_id 两列；实际列："
            f"{list(table.columns)}"
        )
    return table[["dna_id", "protein_id"]].drop_duplicates()


def main() -> None:
    protein_path = resolve_file(PROTEIN_FASTA, "protein FASTA")
    dna_path = resolve_file(DNA_FASTA, "DNA FASTA")
    structure_path = resolve_file(NUCLEOTIDE_STRUCTURE, "nucleotide 结构表")
    custom_map_path = resolve_file(CUSTOM_ID_MAP, "自定义 ID 映射表", required=False)
    output_dir = (SCRIPT_DIR / OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 90)
    print("DNA / protein translation correspondence check")
    print("=" * 90)
    print(f"Protein FASTA       : {protein_path}")
    print(f"DNA FASTA           : {dna_path}")
    print(f"Nucleotide structure: {structure_path}")
    print(f"Output directory    : {output_dir}")

    proteins = read_fasta(protein_path)
    dna_records = read_fasta(dna_path)
    structure = pd.read_csv(structure_path, sep="\t", dtype=str,
                            keep_default_na=False)
    required = {"AminoAcidID", "NucleotideID"}
    if not required.issubset(structure.columns):
        raise ValueError(
            f"结构表缺少 {sorted(required - set(structure.columns))}；"
            f"实际列：{list(structure.columns)}"
        )
    natural_map = (
        structure[["NucleotideID", "AminoAcidID"]]
        .drop_duplicates()
        .rename(columns={"NucleotideID":"dna_id", "AminoAcidID":"protein_id"})
    )
    custom_map = read_custom_map(custom_map_path)

    dna_to_links: Dict[str, List[Tuple[str, str]]] = {}
    for row in natural_map.itertuples(index=False):
        dna_to_links.setdefault(row.dna_id, []).append((row.protein_id, "NucleotideID_to_AminoAcidID"))
    for row in custom_map.itertuples(index=False):
        dna_to_links.setdefault(row.dna_id, []).append((row.protein_id, "custom_ID_map"))
    for dna_id in dna_records:
        if dna_id in proteins:
            dna_to_links.setdefault(dna_id, []).append((dna_id, "same_ID"))

    rows: List[Dict[str, object]] = []
    for dna_id, dna_sequence in dna_records.items():
        links = list(dict.fromkeys(dna_to_links.get(dna_id, [])))
        if not links:
            rows.append({
                "dna_id": dna_id,
                "protein_id": "",
                "ID_link_method": "",
                "protein_ID_found_in_FASTA": False,
                "dna_length_nt": len(clean_dna(dna_sequence)),
                "translation_result": "NO_PROTEIN_ID_MAPPING",
            })
            continue

        for protein_id, method in links:
            if protein_id not in proteins:
                rows.append({
                    "dna_id": dna_id,
                    "protein_id": protein_id,
                    "ID_link_method": method,
                    "protein_ID_found_in_FASTA": False,
                    "dna_length_nt": len(clean_dna(dna_sequence)),
                    "translation_result": "MAPPED_PROTEIN_ID_NOT_IN_FASTA",
                })
                continue
            result = check_pair(proteins[protein_id], dna_sequence)
            rows.append({
                "dna_id": dna_id,
                "protein_id": protein_id,
                "ID_link_method": method,
                "protein_ID_found_in_FASTA": True,
                **result,
            })

    details = pd.DataFrame(rows)
    details_path = output_dir / "DNA_protein_translation_details.csv"
    details.to_csv(details_path, index=False, encoding="utf-8-sig")

    # ID 对应汇总。
    linked_dna_ids = set(details.loc[details.protein_id.ne(""), "dna_id"])
    linked_protein_ids = set(details.loc[details.protein_ID_found_in_FASTA.eq(True), "protein_id"])
    dna_without_map = sorted(set(dna_records) - linked_dna_ids)
    protein_without_dna = sorted(set(proteins) - linked_protein_ids)
    pd.DataFrame({"dna_id": dna_without_map}).to_csv(
        output_dir / "DNA_IDs_without_protein_mapping.csv", index=False,
        encoding="utf-8-sig"
    )
    pd.DataFrame({"protein_id": protein_without_dna}).to_csv(
        output_dir / "protein_IDs_without_DNA_mapping.csv", index=False,
        encoding="utf-8-sig"
    )

    result_counts = details.translation_result.value_counts()
    checked = details[details.protein_ID_found_in_FASTA.eq(True)]
    exact_frame0 = int(checked.translation_result.isin([
        "EXACT_forward_frame0", "EXACT_frame0_with_ambiguous_residues"
    ]).sum())
    exact_any = int(checked.translation_result.str.startswith("EXACT", na=False).sum())
    summary_rows = [
        ("protein_FASTA_records", len(proteins)),
        ("DNA_FASTA_records", len(dna_records)),
        ("DNA_protein_pairs_checked", len(checked)),
        ("DNA_IDs_without_protein_mapping", len(dna_without_map)),
        ("protein_IDs_without_DNA_mapping", len(protein_without_dna)),
        ("exact_forward_frame0_pairs", exact_frame0),
        ("exact_in_any_frame_pairs", exact_any),
        ("exact_forward_frame0_pct_of_checked",
         exact_frame0 / len(checked) * 100 if len(checked) else 0.0),
    ]
    for name, count in result_counts.items():
        summary_rows.append((f"result::{name}", int(count)))
    pd.DataFrame(summary_rows, columns=["metric", "value"]).to_csv(
        output_dir / "translation_check_summary.csv", index=False,
        encoding="utf-8-sig"
    )

    print("\n" + "=" * 90)
    print("CHECK COMPLETED")
    print("=" * 90)
    print(f"Protein FASTA records              : {len(proteins)}")
    print(f"DNA FASTA records                  : {len(dna_records)}")
    print(f"DNA-protein pairs checked          : {len(checked)}")
    print(f"Exact forward frame-0 pairs        : {exact_frame0}")
    print(f"Exact in any of six frames         : {exact_any}")
    print(f"DNA IDs without protein mapping    : {len(dna_without_map)}")
    print(f"Protein IDs without DNA mapping    : {len(protein_without_dna)}")
    print("\nResult counts:")
    print(result_counts.to_string())
    print(f"\nResults saved to: {output_dir}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\n" + "=" * 90, file=sys.stderr)
        print(f"ERROR: {exc}", file=sys.stderr)
        print("=" * 90, file=sys.stderr)
        raise
