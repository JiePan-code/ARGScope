# -*- coding: utf-8 -*-
"""
Draw ARGScope vs STRICT-BLASTN Venn diagrams directly from original result files.

Put this script in:
    E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed\
    ARGScope_150nt_无diamond\

Expected structure:
    ARGScope_150nt_无diamond/
    ├── draw_ARGScope_vs_STRICT_BLAST_venn.py
    ├── ARGScope 结果/
    │   ├── argbert_1_1_kneaddata/
    │   │   └── ARGScope_primary_150nt_fragment_gate_final_predictions.csv
    │   ├── argbert_2_1_kneaddata/
    │   └── ...
    └── BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt/
        ├── argbert_1/
        │   ├── argbert_1_strict_all_hits.tsv
        │   ├── argbert_1_strict_besthit.tsv
        │   └── argbert_1_strict_subject_counts.csv
        ├── argbert_2/
        └── ...

BLAST set used for Venn:
    Prefer *_strict_besthit.tsv

Why:
    strict_besthit.tsv has exactly one row per strict-BLAST-positive read.
    If it is missing, the script falls back to *_strict_all_hits.tsv and
    deduplicates qseqid, so the read set is still correct.

ARGScope set:
    ARGScope_primary_150nt_fragment_gate_final_predictions.csv
    = Gate-final results from the first run (Gate 0.99, without Q0.20).

Outputs:
    ARGScope_STRICT_BLAST_Venn_results/
        argbert_1_ARGScope_vs_STRICT_BLAST_venn.png
        ...
        argscope_6_ARGScope_vs_STRICT_BLAST_venn.png
        ALL_9_SAMPLES_ARGScope_vs_STRICT_BLAST_venn.png
        ALL_9_SAMPLES_3x3_Venn_panel.png
        ARGScope_STRICT_BLAST_Venn_summary.csv
        intersection_ids/
            argbert_1_intersection_read_ids.csv
            ...
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

import pandas as pd
import matplotlib.pyplot as plt

try:
    from matplotlib_venn import venn2
except ImportError as exc:
    raise ImportError(
        "matplotlib-venn is required.\n"
        "Install it in the current Python environment with:\n"
        "pip install matplotlib-venn"
    ) from exc


# =============================================================================
# 1. PATHS
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

ARGSCOPE_ROOT = ROOT_DIR / "ARGScope 结果"

BLAST_ROOT = (
    ROOT_DIR
    / "BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt"
)

OUT_DIR = (
    ROOT_DIR
    / "ARGScope_STRICT_BLAST_Venn_results"
)
OUT_DIR.mkdir(parents=True, exist_ok=True)

ID_OUT_DIR = OUT_DIR / "intersection_ids"
ID_OUT_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 2. INPUT
# =============================================================================

ARGSCOPE_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_final_predictions.csv"
)

ARGSCOPE_ID_CANDIDATES = [
    "Original_ID",
    "read_id",
    "Read_ID",
    "ID",
    "id",
    "qseqid",
]

SAMPLES: Dict[str, Tuple[str, str]] = {
    "argbert_1": ("argbert_1_1_kneaddata", "argbert_1"),
    "argbert_2": ("argbert_2_1_kneaddata", "argbert_2"),
    "argbert_3": ("argbert_3_1_kneaddata", "argbert_3"),
    "argscope_1": ("argscope_1_1_kneaddata", "argscope_1"),
    "argscope_2": ("argscope_2_1_kneaddata", "argscope_2"),
    "argscope_3": ("argscope_3_1_kneaddata", "argscope_3"),
    "argscope_4": ("argscope_4_1_kneaddata", "argscope_4"),
    "argscope_5": ("argscope_5_1_kneaddata", "argscope_5"),
    "argscope_6": ("argscope_6_1_kneaddata", "argscope_6"),
}

DPI = 600


# =============================================================================
# 3. HELPERS
# =============================================================================

def normalize_ids(series: pd.Series) -> set[str]:
    values = (
        series.astype(str)
        .str.strip()
    )

    values = values[
        values.ne("")
        & values.ne("nan")
        & values.ne("None")
    ]

    return set(values.tolist())


def find_argscope_id_column(csv_file: Path) -> str:
    header = pd.read_csv(
        csv_file,
        nrows=0,
        encoding="utf-8-sig",
    )

    for col in ARGSCOPE_ID_CANDIDATES:
        if col in header.columns:
            return col

    raise ValueError(
        f"Cannot find ARGScope read-ID column in:\n{csv_file}\n"
        f"Available columns: {header.columns.tolist()}"
    )


def read_argscope_ids(csv_file: Path) -> set[str]:
    id_col = find_argscope_id_column(csv_file)

    df = pd.read_csv(
        csv_file,
        usecols=[id_col],
        encoding="utf-8-sig",
        dtype={id_col: str},
    )

    return normalize_ids(df[id_col])


def find_strict_blast_file(
    sample_dir: Path,
    sample: str,
) -> Tuple[Path, str]:
    """
    Prefer strict_besthit because it contains one row per strict-positive read.

    Fallback:
        strict_all_hits -> deduplicate qseqid after reading.
    """

    besthit = (
        sample_dir
        / f"{sample}_strict_besthit.tsv"
    )

    if besthit.exists():
        return besthit, "strict_besthit"

    all_hits = (
        sample_dir
        / f"{sample}_strict_all_hits.tsv"
    )

    if all_hits.exists():
        return all_hits, "strict_all_hits"

    candidates = sorted(
        sample_dir.glob("*strict_besthit.tsv")
    )

    if len(candidates) == 1:
        return candidates[0], "strict_besthit"

    candidates = sorted(
        sample_dir.glob("*strict_all_hits.tsv")
    )

    if len(candidates) == 1:
        return candidates[0], "strict_all_hits"

    raise FileNotFoundError(
        f"No strict_besthit.tsv or strict_all_hits.tsv found under:\n"
        f"{sample_dir}"
    )


def read_strict_blast_ids(
    tsv_file: Path,
) -> set[str]:
    """
    Strict BLAST TSV files have a header and qseqid column.

    Even for strict_all_hits.tsv, qseqid is converted to a set, so multiple
    target hits for one read do not inflate the Venn count.
    """

    df = pd.read_csv(
        tsv_file,
        sep="\t",
        usecols=["qseqid"],
        dtype={"qseqid": str},
        low_memory=False,
    )

    return normalize_ids(
        df["qseqid"]
    )


def save_id_set(
    ids: set[str],
    output_file: Path,
) -> None:

    pd.DataFrame({
        "read_id": sorted(ids)
    }).to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig",
    )


def format_count(n: int) -> str:
    return f"{int(n):,}"


# =============================================================================
# 4. VENN DRAWING
# =============================================================================

def style_venn_labels(
    venn,
    argscope_only: int,
    blast_only: int,
    intersection: int,
) -> None:

    values = {
        "10": argscope_only,
        "01": blast_only,
        "11": intersection,
    }

    for region_id, value in values.items():

        label = venn.get_label_by_id(
            region_id
        )

        if label is not None:
            label.set_text(
                format_count(value)
            )
            label.set_fontsize(12)
            label.set_fontweight("bold")

    for label_id in [
        "A",
        "B",
    ]:

        label = venn.get_label_by_id(
            label_id
        )

        if label is not None:
            label.set_fontsize(13)


def calculate_stats(
    argscope_ids: set[str],
    blast_ids: set[str],
    sample_name: str,
    blast_source: str,
    blast_file: Path,
) -> Dict[str, object]:

    argscope_only = (
        argscope_ids
        - blast_ids
    )

    blast_only = (
        blast_ids
        - argscope_ids
    )

    intersection = (
        argscope_ids
        & blast_ids
    )

    union = (
        argscope_ids
        | blast_ids
    )

    n_argscope = len(
        argscope_ids
    )

    n_blast = len(
        blast_ids
    )

    n_intersection = len(
        intersection
    )

    return {
        "sample": sample_name,
        "ARGScope_count": n_argscope,
        "STRICT_BLAST_count": n_blast,
        "ARGScope_only": len(
            argscope_only
        ),
        "STRICT_BLAST_only": len(
            blast_only
        ),
        "Intersection": n_intersection,
        "Intersection_pct_of_ARGScope": (
            100.0
            * n_intersection
            / n_argscope
            if n_argscope
            else 0.0
        ),
        "Intersection_pct_of_STRICT_BLAST": (
            100.0
            * n_intersection
            / n_blast
            if n_blast
            else 0.0
        ),
        "Jaccard_percent": (
            100.0
            * n_intersection
            / len(union)
            if union
            else 0.0
        ),
        "blast_source": blast_source,
        "blast_file": str(
            blast_file
        ),
        "_argscope_only_set": argscope_only,
        "_blast_only_set": blast_only,
        "_intersection_set": intersection,
    }


def draw_single_venn(
    stats: Dict[str, object],
    output_file: Path,
) -> None:

    argscope_only = int(
        stats["ARGScope_only"]
    )

    blast_only = int(
        stats["STRICT_BLAST_only"]
    )

    intersection = int(
        stats["Intersection"]
    )

    fig, ax = plt.subplots(
        figsize=(7.3, 6.3)
    )

    venn = venn2(
        subsets=(
            argscope_only,
            blast_only,
            intersection,
        ),
        set_labels=(
            "ARGScope",
            "Strict BLASTN",
        ),
        ax=ax,
    )

    style_venn_labels(
        venn,
        argscope_only,
        blast_only,
        intersection,
    )

    sample_label = str(
        stats["sample"]
    ).replace(
        "_",
        "-",
    )

    ax.set_title(
        f"{sample_label}\n"
        f"ARGScope ∩ Strict BLASTN = "
        f"{intersection:,} reads",
        fontsize=14,
        pad=14,
    )

    ax.text(
        0.5,
        -0.08,
        (
            f"Intersection / ARGScope = "
            f"{float(stats['Intersection_pct_of_ARGScope']):.2f}%"
            f"    |    "
            f"Intersection / Strict BLASTN = "
            f"{float(stats['Intersection_pct_of_STRICT_BLAST']):.2f}%"
        ),
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=10,
    )

    fig.tight_layout()

    fig.savefig(
        output_file,
        dpi=DPI,
        bbox_inches="tight",
    )

    fig.savefig(
        output_file.with_suffix(
            ".pdf"
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


# =============================================================================
# 5. 3x3 PANEL FOR ALL SAMPLES
# =============================================================================

def draw_3x3_panel(
    stats_list,
) -> None:

    fig, axes = plt.subplots(
        3,
        3,
        figsize=(14, 13),
    )

    for ax, stats in zip(
        axes.flat,
        stats_list,
    ):

        argscope_only = int(
            stats["ARGScope_only"]
        )

        blast_only = int(
            stats["STRICT_BLAST_only"]
        )

        intersection = int(
            stats["Intersection"]
        )

        venn = venn2(
            subsets=(
                argscope_only,
                blast_only,
                intersection,
            ),
            set_labels=(
                "ARGScope",
                "Strict BLASTN",
            ),
            ax=ax,
        )

        values = {
            "10": argscope_only,
            "01": blast_only,
            "11": intersection,
        }

        for region_id, value in values.items():

            label = venn.get_label_by_id(
                region_id
            )

            if label is not None:
                label.set_text(
                    format_count(value)
                )
                label.set_fontsize(9)
                label.set_fontweight(
                    "bold"
                )

        for label_id in [
            "A",
            "B",
        ]:

            label = venn.get_label_by_id(
                label_id
            )

            if label is not None:
                label.set_fontsize(
                    9
                )

        sample_label = str(
            stats["sample"]
        ).replace(
            "_",
            "-",
        )

        ax.set_title(
            (
                f"{sample_label}\n"
                f"Intersection = "
                f"{intersection:,}"
            ),
            fontsize=11,
        )

    fig.suptitle(
        "ARGScope vs Strict BLASTN",
        fontsize=16,
        y=0.99,
    )

    fig.tight_layout()

    panel_png = (
        OUT_DIR
        / "ALL_9_SAMPLES_3x3_Venn_panel.png"
    )

    panel_pdf = (
        OUT_DIR
        / "ALL_9_SAMPLES_3x3_Venn_panel.pdf"
    )

    fig.savefig(
        panel_png,
        dpi=DPI,
        bbox_inches="tight",
    )

    fig.savefig(
        panel_pdf,
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


# =============================================================================
# 6. MAIN
# =============================================================================

def main() -> None:

    print("=" * 100)
    print(
        "ARGScope vs STRICT BLASTN Venn analysis"
    )
    print("=" * 100)

    print(
        f"ARGScope root : {ARGSCOPE_ROOT}"
    )

    print(
        f"Strict BLAST  : {BLAST_ROOT}"
    )

    print(
        f"Output        : {OUT_DIR}"
    )

    print()

    if not ARGSCOPE_ROOT.is_dir():
        raise FileNotFoundError(
            f"ARGScope folder not found:\n"
            f"{ARGSCOPE_ROOT}"
        )

    if not BLAST_ROOT.is_dir():
        raise FileNotFoundError(
            f"Strict BLAST folder not found:\n"
            f"{BLAST_ROOT}"
        )

    summary_rows = []
    plot_stats = []

    pooled_argscope = set()
    pooled_blast = set()

    for sample, (
        argscope_folder,
        blast_folder,
    ) in SAMPLES.items():

        print("-" * 100)
        print(
            f"Processing: {sample}"
        )

        argscope_file = (
            ARGSCOPE_ROOT
            / argscope_folder
            / ARGSCOPE_FILENAME
        )

        blast_sample_dir = (
            BLAST_ROOT
            / blast_folder
        )

        if not argscope_file.exists():
            raise FileNotFoundError(
                f"Missing ARGScope file:\n"
                f"{argscope_file}"
            )

        if not blast_sample_dir.is_dir():
            raise FileNotFoundError(
                f"Missing strict-BLAST folder:\n"
                f"{blast_sample_dir}"
            )

        blast_file, blast_source = (
            find_strict_blast_file(
                blast_sample_dir,
                sample,
            )
        )

        argscope_ids = (
            read_argscope_ids(
                argscope_file
            )
        )

        blast_ids = (
            read_strict_blast_ids(
                blast_file
            )
        )

        stats = calculate_stats(
            argscope_ids=argscope_ids,
            blast_ids=blast_ids,
            sample_name=sample,
            blast_source=blast_source,
            blast_file=blast_file,
        )

        plot_stats.append(
            stats
        )

        intersection_ids = stats[
            "_intersection_set"
        ]

        save_id_set(
            intersection_ids,
            ID_OUT_DIR
            / f"{sample}_intersection_read_ids.csv",
        )

        output_file = (
            OUT_DIR
            / f"{sample}_ARGScope_vs_STRICT_BLAST_venn.png"
        )

        draw_single_venn(
            stats=stats,
            output_file=output_file,
        )

        summary_rows.append({
            key: value
            for key, value
            in stats.items()
            if not key.startswith("_")
        })

        # Prefix sample name so identical IDs across samples do not collide.
        pooled_argscope.update(
            f"{sample}::{read_id}"
            for read_id in argscope_ids
        )

        pooled_blast.update(
            f"{sample}::{read_id}"
            for read_id in blast_ids
        )

        print(
            f"ARGScope={stats['ARGScope_count']:,} | "
            f"Strict BLASTN={stats['STRICT_BLAST_count']:,} | "
            f"Intersection={stats['Intersection']:,}"
        )

        print(
            f"Intersection / ARGScope="
            f"{stats['Intersection_pct_of_ARGScope']:.4f}% | "
            f"Intersection / Strict BLASTN="
            f"{stats['Intersection_pct_of_STRICT_BLAST']:.4f}%"
        )

        print(
            f"BLAST source: {blast_source}"
        )

    # -------------------------------------------------------------------------
    # 3x3 sample panel
    # -------------------------------------------------------------------------

    draw_3x3_panel(
        plot_stats
    )

    # -------------------------------------------------------------------------
    # Pooled all-9-sample Venn
    # -------------------------------------------------------------------------

    pooled_stats = calculate_stats(
        argscope_ids=pooled_argscope,
        blast_ids=pooled_blast,
        sample_name="ALL_9_SAMPLES",
        blast_source="pooled_strict_besthit",
        blast_file=BLAST_ROOT,
    )

    pooled_png = (
        OUT_DIR
        / "ALL_9_SAMPLES_ARGScope_vs_STRICT_BLAST_venn.png"
    )

    draw_single_venn(
        stats=pooled_stats,
        output_file=pooled_png,
    )

    summary_rows.append({
        key: value
        for key, value
        in pooled_stats.items()
        if not key.startswith("_")
    })

    # -------------------------------------------------------------------------
    # Summary
    # -------------------------------------------------------------------------

    summary_df = pd.DataFrame(
        summary_rows
    )

    summary_file = (
        OUT_DIR
        / "ARGScope_STRICT_BLAST_Venn_summary.csv"
    )

    summary_df.to_csv(
        summary_file,
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 100)
    print("DONE")
    print(
        f"Summary CSV : {summary_file}"
    )
    print(
        "3x3 panel   : "
        f"{OUT_DIR / 'ALL_9_SAMPLES_3x3_Venn_panel.png'}"
    )
    print(
        "Pooled Venn : "
        f"{pooled_png}"
    )
    print("=" * 100)


if __name__ == "__main__":
    main()
