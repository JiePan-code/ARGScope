"""Novel-gene type heatmaps matching Table 1 Type_on_true_ARG results."""
from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle
from matplotlib.text import Text
import numpy as np
import pandas as pd
from PIL import Image
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

OUT = Path(__file__).resolve().parent
SOURCE = Path(r'E:\1. ARGmodel\1. NonARG_training\new model result8.24\5. novel gene')
DESTINATIONS = [
    Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\result图片\Novel_gene_Type_heatmaps_20260923'),
    Path(r'E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW\Novel_gene_Type_heatmaps_20260923'),
]
MODELS = {'AA': '1.Protein_novel_gene_100pct', 'NT': '2.DNA_novel_gene_100pct'}
METRICS = ['Precision','Recall','F1']
ORDER = ['beta_lactam','trimethoprim','macrolide-lincosamide-streptogramin',
         'fusidic_acid','fosfomycin','aminoglycoside','quinolone','multidrug',
         'vancomycin','chloramphenicol','florfenicol','rifamycin','tetracycline',
         'other_peptide_antibiotics','bacitracin','sulfonamide','tetracenomycin_C',
         'novobiocin','tunicamycin','streptothricin','polymyxin','bleomycin','puromycin']
LABELS = dict(zip(ORDER, ['Beta-lactams','Trimethoprim','MLS','Fusidic acid','Fosfomycin',
    'Aminoglycosides','Quinolones','Multidrug','Vancomycin','Chloramphenicol','Florfenicol',
    'Rifamycin','Tetracyclines','Other peptides','Bacitracin','Sulfonamide','Tetracenomycin C',
    'Novobiocin','Tunicamycin','Streptothricin','Polymyxin','Bleomycin','Puromycin']))
TABLE_VALUES = {
    'AA':[.7214,.8737,.7214,.7814,.6809],
    'NT':[.3801,.6702,.3801,.4638,.3760],
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def calculate():
    ids = (SOURCE/'Dataset'/'test_ids.txt').read_text(encoding='utf-8-sig').splitlines()
    ids = [v.strip() for v in ids if v.strip()]
    assert len(ids) == len(set(ids)) == 4494
    per_class, summary, sources, selected = [], [], [], {}
    for model, folder in MODELS.items():
        path = SOURCE/folder/'test_sequence_predictions.csv'
        data = pd.read_csv(path)
        assert len(data) == data.sequence_id.nunique() == 4494
        assert set(data.sequence_id) == set(ids)
        assert data[['true_type','predicted_type','true_ARG']].notna().all().all()
        assert data.split.eq('test').all()
        sub = data.loc[data.true_ARG.eq(1)].copy()
        assert len(sub) == 2247 and sub.novel_ARG_subtype.eq(1).all()
        assert set(sub.true_type) <= set(ORDER)
        assert set(sub.predicted_type) <= set(ORDER+['nonARG'])
        selected[model] = sub.set_index('sequence_id').sort_index()
        truth, pred = sub.true_type.to_numpy(), sub.predicted_type.to_numpy()
        p,r,f,_ = precision_recall_fscore_support(truth,pred,average='weighted',zero_division=0)
        five = [accuracy_score(truth,pred),p,r,f,matthews_corrcoef(truth,pred)]
        assert [float(f'{v:.4f}') for v in five] == TABLE_VALUES[model]
        existing = pd.read_csv(SOURCE/folder/'test_metrics.csv').set_index('task').loc['Type_on_true_ARG']
        for value, field in zip(five,['accuracy','weighted_precision','weighted_recall','weighted_f1','mcc']):
            assert abs(value-float(existing[field])) < .000051
        assert (pred=='nonARG').any()
        summary.append(dict(Model='ARGScope-'+model,Modality=model,Scope='True ARG only',
            Average='weighted',N=len(sub),ACC=five[0],Precision=p,Recall=r,F1=f,MCC=five[4],
            Correct=int((truth==pred).sum()),Missed_ARG=int((pred=='nonARG').sum())))
        for typ in ORDER:
            true_mask, pred_mask = truth==typ, pred==typ
            tp = int((true_mask & pred_mask).sum())
            fp = int((~true_mask & pred_mask).sum())
            fn = int((true_mask & ~pred_mask).sum())
            support = tp+fn
            prec = tp/(tp+fp) if tp+fp else 0.
            rec = tp/(tp+fn) if tp+fn else 0.
            f1 = 2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
            sk = precision_recall_fscore_support(truth,pred,labels=[typ],zero_division=0)
            np.testing.assert_allclose([prec,rec,f1],[x[0] for x in sk[:3]],atol=1e-14)
            per_class.append(dict(Model='ARGScope-'+model,Modality=model,Type=typ,
                Type_display=LABELS[typ],Support=support,Predicted=tp+fp,TP=tp,FP=fp,FN=fn,
                Precision=prec,Recall=rec,F1=f1,Displayed=support>0,Scope='True ARG only',
                Zero_precision_denominator=(tp+fp==0),Zero_recall_denominator=(support==0)))
        sources.append(dict(model='ARGScope-'+model,predictions=str(path),sha256=sha(path),
            saved_metrics=str(SOURCE/folder/'test_metrics.csv'),selected_rows=len(sub)))
    pd.testing.assert_series_equal(selected['AA'].true_type,selected['NT'].true_type)
    pd.testing.assert_series_equal(selected['AA'].true_subtype,selected['NT'].true_subtype)
    per, overall = pd.DataFrame(per_class), pd.DataFrame(summary)
    shown = [t for t in ORDER if int(per.loc[(per.Modality=='AA') & (per.Type==t),'Support'].iloc[0])>0]
    assert len(shown)==16
    for model in MODELS:
        records=per.loc[per.Modality.eq(model)].set_index('Type')
        assert records.Support.sum()==2247
        assert [t for t in ORDER if records.loc[t,'Support']>0]==shown
        for metric in METRICS:
            checked=np.average(records[metric],weights=records.Support)
            target=overall.loc[overall.Modality.eq(model),metric].iloc[0]
            assert abs(checked-target)<1e-12
    return per,overall,shown,sources


def ink(cmap,value):
    rgb=np.asarray(cmap(value)[:3])
    linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
    luminance=float(linear @ [.2126,.7152,.0722])
    return 'white' if luminance < .18 else '#18242B'


def draw(per,overall,shown,models,stem,cmap_name):
    # Three metric blocks; within each block, modalities are paired.
    nmod,nrow=len(models),len(shown)
    cell_w,cell_h=.87,.36
    left,bottom,top=2.1,.42,.40
    gap,average_gap,cbar_gap,cbar_w,right=.17,.16,.16,.13,.50
    plot_w=nmod*cell_w
    heat_h=nrow*cell_h
    total_h=heat_h+average_gap+cell_h
    width=left+3*plot_w+2*gap+cbar_gap+cbar_w+right
    height=bottom+total_h+top
    if nmod==1:
        top=.79
        height=bottom+total_h+top
    fig=plt.figure(figsize=(width,height))
    fig.patch.set_alpha(0)
    cmap=plt.get_cmap(cmap_name)
    annotations=[]
    exported=[]
    row_labels=[LABELS[t] for t in shown]
    def rect(x,y,w,h):
        return [x/width,y/height,w/width,h/height]
    for mi,metric in enumerate(METRICS):
        x=left+mi*(plot_w+gap)
        a=fig.add_axes(rect(x,bottom,plot_w,heat_h))
        av=fig.add_axes(rect(x,bottom+heat_h+average_gap,plot_w,cell_h))
        values=np.array([[float(per.loc[(per.Modality==m)&(per.Type==t),metric].iloc[0]) for m in models] for t in shown])
        avg=np.array([[float(overall.loc[overall.Modality==m,metric].iloc[0]) for m in models]])
        for ax,arr,is_average in [(a,values,False),(av,avg,True)]:
            ax.set_facecolor('none')
            for (i,j),v in np.ndenumerate(arr):
                ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=cmap(v),edgecolor='white',lw=.8))
                txt=ax.text(j,i,f'{v:.4f}',ha='center',va='center',fontsize=13,color=ink(cmap,v))
                annotations.append((ax,txt,i,j))
                exported.append(dict(Modality=models[j],Model='ARGScope-'+models[j],Metric=metric,
                    Type='Weighted average' if is_average else shown[i],Value=float(v)))
            ax.set_xlim(-.5,nmod-.5)
            ax.set_ylim(len(arr)-.5,-.5)
            ax.tick_params(which='both',length=0)
            for spine in ax.spines.values(): spine.set_visible(False)
        av.set_title(metric,fontsize=16,pad=7)
        av.set_xticks([])
        av.set_yticks([0],['Weighted average'] if mi==0 else [''],fontsize=13.5)
        av.tick_params(axis='y',pad=7)
        a.set_yticks(range(nrow),row_labels if mi==0 else ['']*nrow,fontsize=14)
        a.tick_params(axis='y',pad=7)
        if nmod==2:
            a.set_xticks(range(nmod),['AA','NT'],fontsize=14)
            a.tick_params(axis='x',pad=5)
            for tick,color in zip(a.get_xticklabels(),['#2C698C','#B85E25']):
                tick.set_color(color)
        else:
            a.set_xticks([])
    if nmod==1:
        model=models[0]
        fig.text((left+1.5*plot_w+gap)/width,(bottom+total_h+.66)/height,
            'ARGScope-AA (protein)' if model=='AA' else 'ARGScope-NT (DNA)',
            ha='center',va='center',fontsize=16)
    cax=fig.add_axes(rect(left+3*plot_w+2*gap+cbar_gap,bottom,cbar_w,total_h))
    cb=fig.colorbar(ScalarMappable(norm=Normalize(0,1),cmap=cmap),cax=cax,ticks=[0,.25,.50,.75,1])
    cb.solids.set_rasterized(False)
    cb.ax.set_yticklabels(['0.00','0.25','0.50','0.75','1.00'])
    cb.ax.tick_params(labelsize=11,length=2,width=.5,pad=3)
    cb.outline.set_linewidth(.5)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for ax,txt,i,j in annotations:
        bbox=txt.get_window_extent(renderer)
        bounds=ax.transData.transform([[j-.5,i-.5],[j+.5,i+.5]])
        assert bbox.x0>bounds[:,0].min() and bbox.x1<bounds[:,0].max()
        assert bbox.y0>bounds[:,1].min() and bbox.y1<bounds[:,1].max()
    for artist in fig.findobj(match=Text):
        if artist.get_visible() and artist.get_text():
            assert artist.get_fontfamily()==['Arial']
    for ext in ['svg','png']:
        with matplotlib.rc_context({'svg.fonttype':'path'}):
            fig.savefig(OUT/(stem+'.'+ext),transparent=True,bbox_inches='tight',pad_inches=.01,dpi=450)
    (OUT/'editable_text').mkdir(exist_ok=True)
    with matplotlib.rc_context({'svg.fonttype':'none'}):
        fig.savefig(OUT/'editable_text'/(stem+'.svg'),transparent=True,bbox_inches='tight',pad_inches=.01)
    for path in [OUT/(stem+'.svg'),OUT/'editable_text'/(stem+'.svg')]:
        svg=ET.parse(path).getroot()
        assert not svg.findall('.//{http://www.w3.org/2000/svg}image')
    with Image.open(OUT/(stem+'.png')) as im:
        pixels=np.asarray(im.convert('RGBA'))
        assert pixels[0,0,3]==0
        ys,xs=np.where(pixels[:,:,3]>0)
        margins=[int(xs.min()),int(ys.min()),int(im.width-1-xs.max()),int(im.height-1-ys.max())]
        assert max(margins)<32,(stem,margins)
        im.thumbnail((1500,1500))
        im.save(OUT/'previews'/(stem+'.png'))
    plt.close(fig)
    return dict(stem=stem,models=models,rows=17,numeric_cells=len(exported),transparent=True,
        vector_cells=True,Arial=True,annotation_font_pt=13,category_font_pt=14,
        no_clipped_annotations=True,outer_margins_px=margins),exported


def main():
    (OUT/'previews').mkdir(exist_ok=True)
    (OUT/'data').mkdir(exist_ok=True)
    arial=font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','svg.fonttype':'path','pdf.fonttype':42,
                         'axes.unicode_minus':False,'savefig.transparent':True})
    per,overall,shown,sources=calculate()
    per.to_csv(OUT/'data'/'Novel_gene_per_type_precision_recall_F1.csv',index=False)
    overall.to_csv(OUT/'data'/'Novel_gene_type_weighted_summary.csv',index=False)
    audits,plotted=[],[]
    for models,stem,cmap in [(['AA','NT'],'Novel_gene_Type_heatmap_AA_NT','Blues'),
                             (['AA'],'Novel_gene_Type_heatmap_Protein','Blues'),
                             (['NT'],'Novel_gene_Type_heatmap_DNA','Oranges')]:
        audit,values=draw(per,overall,shown,models,stem,cmap)
        audits.append(audit)
        plotted.extend([dict(Figure=stem,**r) for r in values])
    pd.DataFrame(plotted).to_csv(OUT/'data'/'plotted_values.csv',index=False)
    audit={'evaluation':'Type_on_true_ARG','test_N':4494,'selected_N':2247,
        'true_nonARG_excluded':True,'nonARG_predictions_retained_as_errors':True,
        'actual_predicted_type_used':True,'oracle_predictions_used':False,
        'summary_average':'weighted','all_five_table_metrics_match_to_4dp':True,
        'independent_TP_FP_FN_checks_passed':True,'same_test_ids_and_labels':True,
        'displayed_types':shown,'zero_support_types_not_displayed':[t for t in ORDER if t not in shown],
        'zero_score_types_retained':True,'undefined_PRF_zero_division':0,
        'font_file':arial,'sources':sources,'figures':audits}
    (OUT/'data'/'verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'README.txt').write_text(
        'Novel-gene resistance-type heatmaps\n\n'
        'Primary figure: Novel_gene_Type_heatmap_AA_NT.svg\n'
        'AA = ARGScope-AA (protein), NT = ARGScope-NT (DNA).\n'
        'All figures use Arial, transparent backgrounds, vector cells and a common 0-1 scale.\n'
        'Main SVG files use outlined text for portable display. editable_text/ contains editable Arial text.\n\n'
        'Evaluation matches the supplied Table 1 Type rows: Type_on_true_ARG.\n'
        'Only the 2,247 reference ARG sequences are evaluated. Reference non-ARG sequences are excluded.\n'
        'ARG sequences predicted as nonARG remain errors. Actual predicted_type, not oracle predictions, is used.\n'
        'The summary row is support-weighted, not macro, matching the table.\n'
        'All 16 types with reference test support are shown, including types scoring zero.\n'
        'Seven types have zero reference support and are not drawn. Their counts are retained in the data CSV.\n'
        'Undefined precision/recall/F1 is recorded as zero, consistent with the saved metric calculation.\n'
        'This scope differs from the all-test, including-nonARG evaluation used for some other figures.\n'
        'No model retraining, threshold changes, prediction relabelling or performance-based type filtering was performed.\n\n'
        +overall.to_string(index=False)+'\n',encoding='utf-8')
    files=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    for dest in DESTINATIONS:
        dest.mkdir(parents=True,exist_ok=True)
        for source in files:
            target=dest/source.relative_to(OUT)
            target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists() and sha(source)!=sha(target):
                raise FileExistsError('Refusing to replace different existing output: '+str(target))
            shutil.copy2(source,target)
    print(overall.to_string(index=False))
    print(json.dumps({'output':str(OUT),'destinations':[str(d) for d in DESTINATIONS],
        'verification':'PASSED','figures':audits},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
