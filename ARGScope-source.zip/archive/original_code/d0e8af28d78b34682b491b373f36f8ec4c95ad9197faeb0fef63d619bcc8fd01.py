import os
import pandas as pd
from tqdm import tqdm

# ==========================================================
# 文件路径
# ==========================================================
DNA_EMBEDDING_TXT = "dna_150nt_5parts_embedding.txt"
LABEL_FILE = "1. 数据IDARG_nonARG_table_5x.csv"

OUTPUT_DNA_CSV = "3.60p_ARG_DNA_with_label.csv"

TXT_SEP = r"\s+"
CHUNK_SIZE = 200000


# ==========================================================
# 读取 label
# ==========================================================
def load_label_file(label_file):
    print(f"\nLoading label file: {label_file}")

    df = pd.read_csv(
        label_file,
        usecols=["id", "Type", "Subtype"],
        dtype={"id": "string", "Type": "string", "Subtype": "string"},
        na_filter=False
    )

    df["id"] = df["id"].str.strip()

    # 如果 label 文件里存在重复 id，保留第一个
    df = df.drop_duplicates(subset="id", keep="first")

    type_map = df.set_index("id")["Type"]
    subtype_map = df.set_index("id")["Subtype"]

    print(f"Label loaded: {df.shape}")

    return type_map, subtype_map


# ==========================================================
# 获取 embedding 文件列数
# ==========================================================
def get_n_cols(txt_file):
    with open(txt_file, "r") as f:
        first_line = f.readline().strip()

    if not first_line:
        raise ValueError(f"{txt_file} 是空文件")

    return len(first_line.split())


# ==========================================================
# 只处理 DNA embedding
# ==========================================================
def process_dna_embedding(txt_file, output_file, type_map, subtype_map):
    print(f"\nProcessing DNA embedding: {txt_file}")
    print(f"Output: {output_file}")

    n_cols = get_n_cols(txt_file)

    if n_cols < 2:
        raise ValueError(f"{txt_file} 列数异常，至少应包含 id 和 embedding")

    col_names = ["id"] + [f"emb_{i}" for i in range(1, n_cols)]
    emb_cols = col_names[1:]

    # 删除旧输出，避免追加到旧文件
    if os.path.exists(output_file):
        os.remove(output_file)

    total_rows = 0
    matched_rows = 0
    first_write = True

    reader = pd.read_csv(
        txt_file,
        sep=TXT_SEP,
        header=None,
        names=col_names,
        chunksize=CHUNK_SIZE,
        engine="c",
        dtype={0: "string"},
        na_filter=False
    )

    for chunk in tqdm(reader, desc=f"Reading {txt_file}"):

        # 清洗 id
        chunk["id"] = (
            chunk["id"]
            .astype("string")
            .str.strip()
            .str.replace(">", "", regex=False)
        )

        # embedding 转 float32
        chunk[emb_cols] = chunk[emb_cols].astype("float32", copy=False)

        # 添加标签
        chunk.insert(1, "Type", chunk["id"].map(type_map))
        chunk.insert(2, "Subtype", chunk["id"].map(subtype_map))

        matched_rows += chunk["Type"].notna().sum()
        total_rows += len(chunk)

        # 分块写出
        chunk.to_csv(
            output_file,
            index=False,
            mode="w" if first_write else "a",
            header=first_write
        )

        first_write = False

    print(f"Saved: {output_file}")
    print(f"Matched: {matched_rows} / {total_rows}")


# ==========================================================
# 主程序
# ==========================================================
def main():
    print("===== START =====")

    type_map, subtype_map = load_label_file(LABEL_FILE)

    process_dna_embedding(
        DNA_EMBEDDING_TXT,
        OUTPUT_DNA_CSV,
        type_map,
        subtype_map
    )

    print("===== DONE =====")


if __name__ == "__main__":
    main()