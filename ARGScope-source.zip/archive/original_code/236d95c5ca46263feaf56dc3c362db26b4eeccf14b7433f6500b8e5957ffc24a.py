"""Native, editable reconstruction of the user-supplied ARGScope overview.

All panels, text, graph nodes, formula components, and workflow connectors are
draw.io cells. Molecule glyphs use native draw.io stencils, not raster images.
The 1200 x 900 reference grid is scaled uniformly for a readable editor canvas.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import math, json, zlib, base64
from urllib.parse import quote

OUT = Path(__file__).resolve().parent
S = 1.5
W, H = 1200, 900
PAL = {'blue': ('#DAE8FC', '#6C8EBF'), 'purple': ('#E1D5E7', '#9673A6'),
       'gray': ('#F5F5F5', '#666666'), 'clear': ('none', 'none')}
INK = '#000000'
mx = ET.Element('mxfile', host='Electron', version='30.0.0', agent='Native scientific figure authoring')
dg = ET.SubElement(mx, 'diagram', id='argscope-reference-redraw', name='ARGScope overview')
model = ET.SubElement(dg, 'mxGraphModel', dx=str(W*S), dy=str(H*S), grid='0', gridSize='10',
    guides='1', tooltips='1', connect='1', arrows='1', fold='1', page='1', pageScale='1',
    pageWidth=str(W*S), pageHeight=str(H*S), math='0', shadow='0', background='#FFFFFF')
root = ET.SubElement(model, 'root')
ET.SubElement(root, 'mxCell', id='0')
ET.SubElement(root, 'mxCell', id='1', parent='0')
boxes = {'1': (0, 0, W, H)}
manifest = {'nodes': [], 'edges': []}

def node(id, value, x, y, w, h, role='blue', parent='1', size=14, bold=False,
         extra='', container=False, rounded=False, fill=None, stroke=None):
    f, st = PAL[role]
    if fill is not None: f=fill
    if stroke is not None: st=stroke
    px, py, _, _ = boxes[parent]
    style=(f'rounded={int(rounded)};arcSize=7;whiteSpace=wrap;html=1;fillColor={f};strokeColor={st};'
           f'strokeWidth={1.05*S};fontFamily=Arial;fontSize={size*S};fontColor={INK};'
           f'align=center;verticalAlign=middle;spacing=0;shadow=0;')
    if bold: style+='fontStyle=1;'
    if container: style+='container=1;collapsible=0;recursiveResize=0;pointerEvents=0;'
    style+=extra
    c=ET.SubElement(root,'mxCell',id=id,value=value,style=style,vertex='1',parent=parent)
    ET.SubElement(c,'mxGeometry',x=str((x-px)*S),y=str((y-py)*S),width=str(w*S),height=str(h*S),attrib={'as':'geometry'})
    boxes[id]=(x,y,w,h)
    manifest['nodes'].append(dict(id=id,value=value,box=[x,y,w,h],role=role,parent=parent,container=container))
    return id

def text(id,value,x,y,w,h,size=14,bold=False,parent='1',align='center',color=INK,extra=''):
    return node(id,value,x,y,w,h,'clear',parent,size,bold,
                f'align={align};fontColor={color};overflow=visible;{extra}')

def panel(id,x,y,w,h,parent='1',role='gray',dashed=False,fill=None,stroke=None):
    return node(id,'',x,y,w,h,role,parent,container=True,rounded=True,fill=fill,stroke=stroke,
                extra=('dashed=1;dashPattern=7 4;' if dashed else ''))

def line(id, pts, parent='1', color=INK, width=1.35, arrow=True, dashed=False,
         curved=False, startarrow=False, source=None, target=None, sp=(1,.5),tp=(0,.5),kind='flow',opacity=100):
    px,py,*_=boxes[parent]
    style=(f'edgeStyle=none;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;strokeColor={color};'
           f'strokeWidth={width*S};endArrow={"block" if arrow else "none"};endSize={6*S};endFill=1;'
           f'startArrow={"block" if startarrow else "none"};startSize={6*S};startFill=1;'
           f'opacity={opacity};fontFamily=Arial;')
    if dashed:style+='dashed=1;dashPattern=6 4;'
    if curved:style+='curved=1;'
    attrs=dict(id=id,value='',style=style,edge='1',parent=parent)
    if source:
        attrs['source']=source
        attrs['style']+=f'exitX={sp[0]};exitY={sp[1]};exitDx=0;exitDy=0;exitPerimeter=0;'
    if target:
        attrs['target']=target
        attrs['style']+=f'entryX={tp[0]};entryY={tp[1]};entryDx=0;entryDy=0;entryPerimeter=0;'
    c=ET.SubElement(root,'mxCell',attrs)
    g=ET.SubElement(c,'mxGeometry',relative='1',attrib={'as':'geometry'})
    coords=list(pts)
    if not source:
        x,y=coords.pop(0); ET.SubElement(g,'mxPoint',x=str((x-px)*S),y=str((y-py)*S),attrib={'as':'sourcePoint'})
    if not target:
        x,y=coords.pop(); ET.SubElement(g,'mxPoint',x=str((x-px)*S),y=str((y-py)*S),attrib={'as':'targetPoint'})
    if coords:
        a=ET.SubElement(g,'Array',attrib={'as':'points'})
        for x,y in coords:ET.SubElement(a,'mxPoint',x=str((x-px)*S),y=str((y-py)*S))
    manifest['edges'].append(dict(id=id,points=pts,parent=parent,kind=kind,source=source,target=target,curved=curved))
    return id

def flow(id, pts, source=None,target=None,sp=(1,.5),tp=(0,.5),parent='A'):
    return line(id,pts,parent=parent,source=source,target=target,sp=sp,tp=tp)

def circle(id,x,y,r=6,role='purple',parent='1',label='',size=12,fill=None,stroke=None):
    return node(id,label,x-r,y-r,2*r,2*r,role,parent,size,False,
                'ellipse;perimeter=ellipsePerimeter;',fill=fill,stroke=stroke)

def stencil_style(name,paths,w=100,h=100):
    shape=ET.Element('shape',name=name,w=str(w),h=str(h),aspect='variable',strokewidth='inherit')
    ET.SubElement(shape,'connections')
    fg=ET.SubElement(shape,'foreground')
    for commands,mode in paths:
        path=ET.SubElement(fg,'path')
        for cmd,args in commands:
            keys={'move':['x','y'],'line':['x','y'],'curve':['x1','y1','x2','y2','x3','y3'],
                  'quad':['x1','y1','x2','y2'],'close':[]}[cmd]
            ET.SubElement(path,cmd,dict(zip(keys,[str(round(v,4)) for v in args])))
        ET.SubElement(fg,mode)
    raw=quote(ET.tostring(shape,encoding='unicode'),safe="~()*!.'-").encode()
    z=zlib.compressobj(wbits=-15)
    encoded=base64.b64encode(z.compress(raw)+z.flush()).decode()
    return f'shape=stencil({encoded});'

def custom(id,paths,x,y,w,h,role='blue',parent='1',sw=1):
    return node(id,'',x,y,w,h,role,parent,extra=stencil_style(id,paths)+f'strokeWidth={sw*S};')

def polygon(id,points,x,y,w,h,role='blue',parent='1',sw=1):
    cmds=[('move',points[0])]+[('line',p) for p in points[1:]]+[('close',[])]
    return custom(id,[(cmds,'fillstroke')],x,y,w,h,role,parent,sw)

def protein(id,x,y,w,h,parent):
    panel(id,x,y,w,h,parent,role='clear')
    # A ribbon helix with alternating front bands and connecting turns.
    for i in range(5):
        yy=3+i*18
        back=[('move',[36,yy]),('curve',[63,yy+2,63,yy+18,30,yy+23]),
              ('line',[22,yy+16]),('curve',[47,yy+12,47,yy+5,31,yy+6]),('close',[])]
        front=[('move',[31,yy+6]),('curve',[3,yy+11,8,yy+24,41,yy+25]),
               ('line',[46,yy+17]),('curve',[24,yy+18,19,yy+15,36,yy+12]),('close',[])]
        custom(id+f'-back{i}',[(back,'fillstroke')],x,y,w,h,'blue',id,.9)
        custom(id+f'-front{i}',[(front,'fillstroke')],x,y,w,h,'blue',id,.9)
    return id

def dna(id,x,y,w,h,parent):
    panel(id,x,y,w,h,parent,role='clear')
    for i in range(12):
        yy=5+i*8.1
        xx=50+28*math.cos(yy/100*2*math.pi)
        custom(id+f'-rung{i}',[([('move',[xx,yy]),('line',[100-xx,yy])],'stroke')],x,y,w,h,'blue',id,1.1)
    for strand in (0,1):
        coords=[]
        for i in range(101):
            coords.append((50+(1 if strand==0 else -1)*28*math.cos(i/100*2*math.pi),i))
        cmds=[('move',coords[0])]+[('line',p) for p in coords[1:]]
        custom(id+f'-strand{strand}',[(cmds,'stroke')],x,y,w,h,'blue',id,2.6)
    return id

def sequence(id,x,y,w,h,title,kind,parent='1',paired=False):
    panel(id,x,y,w,h,parent,'gray',stroke='#6C8EBF')
    text(id+'-label',title,x+8,y+5,w-16,23,14,True,id,align='left')
    (protein if kind=='aa' else dna)(id+'-glyph',x+13,y+30,44,h-38,id)
    node(id+'-seqbox','',x+63,y+30,w-76,h-42,'blue',id,rounded=True,stroke='none')
    value='MKTAYIAKQR<br>QISFVKSHFS<br>•••' if kind=='aa' else 'ATGAAATACG<br>CAGATTTTCA<br>•••'
    text(id+'-seq',value,x+70,y+34,w-87,h-49,12.5,False,id,align='left',extra='fontFamily=Consolas;')
    return id

def encoder(id,x,y,w,h,title,sub,parent='1'):
    polygon(id,[(0,0),(100,22),(100,76),(0,100)],x,y,w,h,'blue',parent)
    text(id+'-title',title,x+3,y+h*.30,w-6,22,17,True,parent)
    text(id+'-sub',sub,x+4,y+h*.56,w-8,22,12.5,False,parent)
    return id

def bars(id,x,y,w,h,count=4,parent='1',role='blue',ellipsis=True):
    panel(id,x,y,w,h,parent,'clear')
    gap=4
    bh=(h-(count-1)*gap)/count
    for i in range(count):node(id+f'-bar{i}','',x,y+i*(bh+gap),w,bh,role,id,extra=f'strokeWidth={.7*S};')
    if ellipsis:text(id+'-dots','•••',x,y+h+2,w,15,15,False,parent)
    return id

def mlp(id,x,y,w,h,parent='1'):
    panel(id,x,y,w,h,parent,'clear')
    pts=[(x+w*.1,y+h*.30),(x+w*.1,y+h*.72),
         (x+w*.35,y+h*.08),(x+w*.35,y+h*.5),(x+w*.35,y+h*.92),
         (x+w*.60,y+h*.24),(x+w*.60,y+h*.76),(x+w*.88,y+h*.50)]
    for n,(i,j) in enumerate([(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(2,5),(2,6),(3,5),(3,6),(4,5),(4,6),(5,7),(6,7)]):
        line(id+f'-e{n}',[pts[i],pts[j]],id,color=PAL['purple'][1],width=1.1,arrow=False,kind='glyph')
    for i,(xx,yy) in enumerate(pts):circle(id+f'-n{i}',xx,yy,7.5,'purple',id)
    return id

def teacher_graph(id,x,y,w,h,parent='1'):
    panel(id,x,y,w,h,parent,'clear')
    pts=[(x+w*.5,y+h*.06),(x+w*.2,y+h*.3),(x+w*.82,y+h*.3),
         (x+w*.5,y+h*.48),(x+w*.15,y+h*.65),(x+w*.85,y+h*.65),(x+w*.5,y+h*.91)]
    for n,(i,j) in enumerate([(0,1),(0,2),(0,3),(1,3),(1,4),(2,3),(2,5),(3,4),(3,5),(3,6),(4,6),(5,6),(4,5)]):
        line(id+f'-e{n}',[pts[i],pts[j]],id,width=1.0,arrow=False,kind='glyph')
    for i,(xx,yy) in enumerate(pts):circle(id+f'-n{i}',xx,yy,6.5,'purple',id)

def star(id,cx,cy,r,parent,role='purple'):
    pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5
        rr=50 if i%2==0 else 21
        pts.append((50+rr*math.cos(a),50+rr*math.sin(a)))
    return polygon(id,pts,cx-r,cy-r,2*r,2*r,role,parent,.9)

# Broad panel hierarchy preserves the attached reference's relative placement.
panel('A',12,6,1176,616,role='clear')
text('A-letter','A',14,5,34,40,33,True,'A',align='left')
text('A-title','Training',67,7,123,37,29,True,'A',align='left')
text('A-bar','|',190,8,14,34,26,False,'A')
text('A-subtitle','multimodal teacher–student learning',212,9,600,32,20,False,'A',align='left')

panel('paired',16,61,190,301,'A','gray',stroke='#6C8EBF')
text('paired-title','Paired ARG sequences',24,70,175,25,17,True,'paired',align='left')
text('paired-protein-label','Protein sequence',32,111,165,23,14.5,True,'paired',align='left')
protein('paired-protein-glyph',29,140,48,79,'paired')
node('paired-protein-seqbox','',82,138,112,61,'blue','paired',rounded=True,stroke='none')
text('paired-protein-seq','MKTAYIAKQR<br>QISFVKSHFS<br>•••',91,145,99,48,12.5,parent='paired',align='left',extra='fontFamily=Consolas;')
line('paired-divider',[(27,238),(195,238)],'paired',PAL['blue'][1],.65,False,kind='divider',opacity=45)
text('paired-nt-label','Nucleotide sequence',32,251,170,23,14.5,True,'paired',align='left')
dna('paired-nt-glyph',33,279,41,71,'paired')
node('paired-nt-seqbox','',82,279,112,65,'blue','paired',rounded=True,stroke='none')
text('paired-nt-seq','ATGAAATACG<br>CAGATTTTCA<br>•••',91,286,99,50,12.5,parent='paired',align='left',extra='fontFamily=Consolas;')
encoder('aa-encoder',234,107,117,91,'ESM-2','(protein encoder)','A')
encoder('nt-encoder',234,248,117,91,'DNABERT-2','(nucleotide encoder)','A')
text('aa-rep-label','Protein<br>representation',352,61,102,39,14,parent='A')
text('nt-rep-label','Nucleotide<br>representation',351,223,104,38,14,parent='A')
bars('aa-rep',379,102,45,75,4,'A')
bars('nt-rep',379,262,45,56,3,'A')
flow('aa-input',[(206,153),(234,153)],target='aa-encoder')
flow('nt-input',[(206,294),(234,294)],target='nt-encoder')
flow('aa-encode',[],source='aa-encoder',target='aa-rep')
flow('nt-encode',[],source='nt-encoder',target='nt-rep')

panel('shared',465,94,280,179,'A','gray',stroke='#6C8EBF')
text('shared-title','Shared representation learning',476,103,258,27,18,True,'shared')
panel('projection',474,143,99,129,'shared','clear',stroke='#6C8EBF')
text('projection-title','Projection',479,149,88,21,13.5,False,'projection')
bars('projection-in',483,178,27,75,4,'projection')
bars('projection-out',536,178,28,75,4,'projection','gray')
line('project-arrow',[(514,209),(533,209)],'projection',width=1.2)
flow('aa-project',[(424,140),(447,140),(447,192),(474,192)],parent='A')
flow('nt-project',[(424,291),(448,291),(448,226),(474,226)],parent='A')
panel('gate',586,167,85,92,'shared','purple')
text('gate-label','Adaptive<br>gated fusion',591,177,75,36,13.5,True,'gate')
circle('gate-sigma',629,234,16,'gray','gate','σ',24,fill='#FFFFFF',stroke='#9673A6')
line('gate-mini-in',[(591,234),(610,234)],'gate',width=1.15)
line('gate-mini-out',[(646,234),(665,234)],'gate',width=1.15)
flow('projection-gate',[(574,212),(586,212)],parent='shared')
text('fused-title','Fused<br>representation',668,136,77,36,13.5,parent='shared')
bars('fused',698,178,31,69,4,'shared','purple')
flow('gate-fused',[(671,212),(694,212)],parent='shared')

panel('teacher',751,213,121,178,'A','purple')
teacher_graph('teacher-network',779,225,65,65,'teacher')
text('teacher-title','Fusion teacher',755,295,113,23,16,True,'teacher')
text('teacher-sub','(multimodal)',756,319,111,20,14,parent='teacher')
node('teacher-binary','ARG / non-ARG',761,341,101,21,'gray','teacher',13,rounded=True,stroke='none')
node('teacher-subtype','Subtype',761,367,101,20,'purple','teacher',13,rounded=True,stroke='none',extra='fillOpacity=60;')
flow('fused-teacher',[(746,143),(811,143),(811,211)],target='teacher',tp=(.5,0))

text('transfer-title','Knowledge<br>transfer',883,102,111,39,17,True,'A')
panel('transfer',884,149,106,207,'A','clear',dashed=True,stroke='#9673A6')
for id,title,yy in [('prediction','Prediction<br>distillation',158),('feature','Feature<br>alignment',227),('prototype','Prototype<br>alignment',296)]:
    node('transfer-'+id,title,894,yy,87,52,'purple','transfer',14.5,rounded=True,stroke='none')

# One shared supervision bus avoids the crossing colored routes in the bitmap.
line('teacher-supervision-bus',[(879,184),(879,322)],'A',PAL['purple'][1],1.2,False,True)
line('teacher-to-transfer',[(872,302),(879,302)],'A',PAL['purple'][1],1.2,False,True)
for id,yy in [('prediction',184),('feature',253),('prototype',322)]:
    line('teacher-to-'+id,[(879,yy),(891,yy)],'A',PAL['purple'][1],1.2,True,True)
    line(id+'-to-bus',[(981,yy),(1019,yy)],'A',PAL['purple'][1],1.2,False,True)
line('student-supervision-bus',[(1019,155),(1019,388)],'A',PAL['purple'][1],1.2,False,True)
for id,yy in [('AA',155),('NT',388)]:
    line('supervision-'+id,[(1019,yy),(1043,yy)],'A',PAL['purple'][1],1.3,True,True)
for i,yy in enumerate([184,253,322]):circle('supervision-junction-'+str(i),1019,yy,1.6,'purple','A',fill=PAL['purple'][1],stroke='none')

for kind,title,sub,y in [('aa','ARGScope-AA','(protein student)',70),('nt','ARGScope-NT','(nucleotide student)',303)]:
    parent='student-'+kind
    panel(parent,1045,y,146,162,'A','purple')
    text(parent+'-title',title,1052,y+10,132,25,18,True,parent)
    text(parent+'-sub',sub,1050,y+38,137,22,14,parent=parent)
    mlp(parent+'-network',1075,y+69,87,61,parent)
    text(parent+'-mlp','MLP',1085,y+139,66,18,14,parent=parent)

# Prototype-space learning: same three subpanels and formulas as the reference.
panel('graph-learning',104,369,724,254,'A','gray',dashed=True,stroke='#6C8EBF')
text('graph-title','<b>Subtype graph learning</b> (in prototype space)',225,376,477,25,17,parent='graph-learning')
flow('gate-to-graph',[(629,259),(629,366)],source='gate',sp=(.5,1),parent='A')
for id,x,w,n,title in [('construction',115,254,'1','Subtype prototype construction'),
                       ('knn',376,231,'2','Mutual kNN graph'),
                       ('gat',615,204,'3','Residual GAT refinement')]:
    panel(id,x,405,w,207,'graph-learning','clear',stroke='#6C8EBF')
    circle(id+'-badge',x+20,421,13,'blue',id,n,15,fill=PAL['blue'][1],stroke='none')
    # Native white number, with a compact title to retain the reference's layout.
    root.find(f"mxCell[@id='{id}-badge']").set('style',root.find(f"mxCell[@id='{id}-badge']").get('style')+'fontColor=#FFFFFF;fontStyle=1;')
    text(id+'-title',title,x+42,409,w-46,25,12.1,True,id,align='left')

centers=[(159,470),(229,463),(163,529),(239,528)]
for i,(cx,cy) in enumerate(centers):
    node(f'cluster-{i}','',cx-29,cy-26,58,52,'blue','construction',extra='ellipse;dashed=1;dashPattern=4 4;fillOpacity=40;strokeWidth=1;')
    for j,(dx,dy) in enumerate([(-17,-7),(-7,-18),(13,-14),(21,0),(7,17),(-16,13)]):
        circle(f'cluster-{i}-sample{j}',cx+dx,cy+dy,3.4,'blue','construction')
    star(f'cluster-{i}-centroid',cx,cy,9,'construction')
line('cluster-construction-arrow',[(188,484),(215,502)],'construction',width=1.2,kind='glyph')
panel('prototype-legend',280,449,77,66,'construction','clear',stroke='#6C8EBF')
circle('legend-sample',291,466,3.2,'blue','prototype-legend')
text('legend-sample-label','Samples',301,457,52,18,11.5,parent='prototype-legend',align='left')
star('legend-centroid',291,491,7,'prototype-legend')
text('legend-centroid-label','Prototype<br>(centroid)',301,480,53,28,11,parent='prototype-legend',align='left')
panel('formula-one',124,564,234,39,'construction','gray',stroke='#6C8EBF')
text('mean-lhs','<i>p</i><sub>c</sub> =',137,573,42,22,15,parent='formula-one')
text('mean-frac-top','1',188,565,23,17,13,parent='formula-one')
line('mean-fraction',[(188,583),(210,583)],'formula-one',width=.75,arrow=False,kind='formula')
text('mean-frac-bot','<i>N</i><sub>c</sub>',188,584,24,17,13,parent='formula-one')
text('mean-sum','∑',215,571,25,25,25,parent='formula-one')
text('mean-sum-upper','<i>N</i>',219,562,17,14,10.5,parent='formula-one')
text('mean-sum-lower','<i>i</i> = 1',212,590,31,13,9.5,parent='formula-one')
text('mean-term','I(<i>y</i><sub>i</sub> = <i>c</i>)<i>z</i><sub>i</sub>',244,572,102,24,14,parent='formula-one')

# Mutual kNN: separate editable graph edges, six indexed prototype nodes.
kpts=[(467,454),(417,493),(509,493),(469,542),(408,542),(519,542)]
for n,(i,j) in enumerate([(0,1),(0,2),(1,2),(0,3),(2,3)]):
    line('knn-solid-'+str(n),[kpts[i],kpts[j]],'knn',PAL['blue'][1],1.3,True,startarrow=True,kind='graph')
for n,(i,j) in enumerate([(1,4),(4,3),(3,5),(2,5),(1,3)]):
    line('knn-nonedge-'+str(n),[kpts[i],kpts[j]],'knn',PAL['gray'][1],1,False,True,kind='graph',opacity=65)
for i,(x,y) in enumerate(kpts):circle('knn-p'+str(i+1),x,y,11.5,'blue','knn',f'<i>p</i><sub>{i+1}</sub>',12)
panel('knn-legend',533,459,66,67,'knn','clear',stroke='#6C8EBF')
line('legend-knn-edge',[(539,479),(550,479)],'knn-legend',PAL['blue'][1],1.6,False,kind='legend')
text('legend-knn-text','Mutual kNN<br>edge',553,463,43,30,10.2,parent='knn-legend',align='left')
line('legend-nonedge',[(539,509),(550,509)],'knn-legend',PAL['gray'][1],1,False,True,kind='legend')
text('legend-nonedge-text','Non-edge',553,499,43,21,10.2,parent='knn-legend',align='left')
panel('formula-two',385,565,213,39,'knn','gray',stroke='#6C8EBF')
text('adj-lhs','<i>A</i><sub>cd</sub> =',389,575,39,21,13,parent='formula-two')
text('adj-brace','{',426,567,13,36,31,parent='formula-two')
text('adj-one','1,',438,568,12,18,11.4,parent='formula-two')
text('adj-neighbors','<i>d</i> ∈ <i>N</i><sub>k</sub>(<i>c</i>) and <i>c</i> ∈ <i>N</i><sub>k</sub>(<i>d</i>)',453,568,141,18,10.9,parent='formula-two',align='left')
text('adj-zero','0, otherwise',438,585,147,16,11.4,parent='formula-two',align='left')

# Residual GAT: a single purple family, weight shown by line width/opacity.
gpts=[(706,454),(655,493),(748,493),(708,542),(644,542),(760,542)]
for n,(i,j,off,weight) in enumerate([(0,1,-10,3),(1,0,-11,1.5),(0,2,-11,3.2),(2,0,-10,1.7),
                                    (1,2,8,1.9),(2,1,-5,2.3),(1,3,5,1.3),(3,2,0,1.8),
                                    (4,1,-10,3),(4,3,0,2),(0,3,8,1.1),(3,5,0,1.2)]):
    a,b=gpts[i],gpts[j]
    mid=((a[0]+b[0])/2+off,(a[1]+b[1])/2+off)
    line('gat-attention-'+str(n),[a,mid,b],'gat',PAL['purple'][1],weight,True,curved=True,kind='graph',opacity=100 if weight>2 else 55)
for i,(x,y) in enumerate(gpts):circle('gat-p'+str(i+1),x,y,11.5,'purple','gat',f'<i>p</i><sub>{i+1}</sub>' if i<4 else '',12)
text('attention-label','Attention<br>weight',766,445,45,28,10.8,parent='gat')
for i in range(12):node('attention-scale-'+str(i),'',773,482+i*4.9,9,5,'purple','gat',fill=PAL['purple'][1],stroke='none',extra=f'fillOpacity={100-i*7};')
text('attention-high','High',787,480,29,15,10.5,parent='gat',align='left')
text('attention-low','Low',787,528,29,15,10.5,parent='gat',align='left')
panel('formula-three',624,566,186,38,'gat','gray',stroke='#6C8EBF')
text('residual-formula','<i>p</i><sub>c</sub><sup>ref</sup> = <i>norm</i>(<i>p</i><sub>c</sub><sup>raw</sup> + α Δ<i>p</i><sub>c</sub><sup>GAT</sup>)',627,571,180,28,13.1,parent='formula-three')
flow('refinement-to-teacher',[(828,507),(851,507),(851,394)],target='teacher',tp=(100/121,1))

# Inference panel follows the supplied reference, including the merged route.
line('panel-divider',[(14,638),(1190,638)],color=PAL['gray'][1],width=.8,arrow=False,dashed=True,kind='divider',opacity=70)
panel('B',12,642,1176,253,role='clear')
text('B-letter','B',15,643,34,40,33,True,'B',align='left')
text('B-title','Inference',68,646,135,36,29,True,'B',align='left')
text('B-bar','|',204,647,15,33,26,parent='B')
text('B-subtitle','single-modality deployment',224,650,500,30,20,parent='B',align='left')
sequence('infer-aa-input',28,686,218,90,'Protein sequence only','aa','B')
sequence('infer-nt-input',28,798,218,90,'Nucleotide sequence only','nt','B')
encoder('infer-aa-encoder',302,689,117,80,'ESM-2','(protein encoder)','B')
encoder('infer-nt-encoder',302,801,117,80,'DNABERT-2','(nucleotide encoder)','B')
text('infer-aa-embedding-label','Protein<br>embedding',464,679,80,32,13.3,parent='B')
text('infer-nt-embedding-label','Nucleotide<br>embedding',461,792,86,33,13.3,parent='B')
bars('infer-aa-embedding',478,713,46,42,3,'B')
bars('infer-nt-embedding',478,825,46,42,3,'B')
for kind,y,title,sub in [('aa',677,'ARGScope-AA','(protein student)'),('nt',790,'ARGScope-NT','(nucleotide student)')]:
    parent='infer-student-'+kind
    panel(parent,626,y,203,99,'B','purple')
    text(parent+'-title',title,646,y+4,164,22,16,True,parent)
    text(parent+'-sub',sub,643,y+25,169,20,13.5,parent=parent)
    mlp(parent+'-network',686,y+47,70,40,parent)
    text(parent+'-mlp','MLP',765,y+76,45,19,12.5,parent=parent)
for kind,yy in [('aa',730),('nt',842)]:
    flow('infer-'+kind+'-input-flow',[(247,yy),(300,yy)],parent='B')
    flow('infer-'+kind+'-encode',[(420,yy),(476,yy)],parent='B')
    flow('infer-'+kind+'-student',[(537,yy),(623,yy)],parent='B')

panel('annotation',990,677,193,157,'B','gray',stroke='#6C8EBF')
text('annotation-title','ARG annotation',1003,684,167,25,17,True,'annotation')
for i,(title,yy) in enumerate([('ARG / non-ARG',711),('Subtype',751),('Resistance type',793)]):
    node('annotation-'+str(i),title,1004,yy,165,30,'blue','annotation',14.5,rounded=True,stroke='none')
for i,(y1,y2) in enumerate([(741,751),(781,793)]):line('annotation-arrow-'+str(i),[(1087,y1),(1087,y2)],'annotation',width=1.1)
line('infer-aa-result',[(829,721),(908,721),(908,758)],'B',width=1.25,arrow=False)
line('infer-nt-result',[(829,842),(908,842),(908,758)],'B',width=1.25,arrow=False)
line('infer-annotation-flow',[(908,758),(987,758)],'B',width=1.4)
line('legend-forward',[(910,855),(965,855)],'B',width=1.35)
text('legend-forward-label','Forward flow',977,845,202,22,13,parent='B',align='left')
line('legend-supervision',[(910,879),(965,879)],'B',PAL['purple'][1],1.25,True,True)
text('legend-supervision-label','Knowledge transfer (training only)',977,868,213,23,11.9,parent='B',align='left')

# Apply the user's stricter follow-up: retain the original geometry, icon
# silhouettes, wording, and separate transfer routes; change colors only.
from exact_reference import match_reference
match_reference(root, boxes, manifest, model, S, OUT)

# Make the whole document's native units easy to inspect, and preserve provenance.
filename=OUT/'ARGScope_overview_recreated.drawio'
ET.indent(mx,space='  ')
ET.ElementTree(mx).write(filename,encoding='utf-8',xml_declaration=True)
manifest.update(canvas=[W,H],scale=S,source_image='codex-clipboard-c936a1f6-2610-4280-a05f-ad308012a98e.png',
    palette=PAL,notes=['Native draw.io vectors and editable text; no raster image objects.',
    'Uses the latest supplied single-fusion-teacher architecture.',
    'Separate supervision routes preserve the supplied reference; no shared objective bus.'])
(OUT/'reconstruction_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'drawio':str(filename),'vertices':len(manifest['nodes']),'edges':len(manifest['edges'])},ensure_ascii=False))
