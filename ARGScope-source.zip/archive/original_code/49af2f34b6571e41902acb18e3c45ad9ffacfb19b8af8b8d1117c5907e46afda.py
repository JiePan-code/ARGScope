import pandas as pd
import numpy as np


def split_by_subtype_train_test_all_cover_8_2(
    file_path,
    subtype_col="Subtype",
    test_ratio=0.2,
    random_state=42,
    train_output="train_set.csv",
    test_output="test_set.csv",
    stats_output="subtype_split_statistics.csv"
):
    # =========================
    # 1. 读取数据
    # =========================
    df = pd.read_csv(file_path).copy()
    df = df.reset_index(drop=True)

    if subtype_col not in df.columns:
        raise ValueError(f"数据中未找到必要列: {subtype_col}")

    if len(df) == 0:
        raise ValueError("输入数据为空。")

    df[subtype_col] = df[subtype_col].astype(str)

    # 保留原始行号，用于检查 train/test 是否有重复样本
    df["_original_index"] = df.index

    train_parts = []
    test_parts = []
    stats = []

    # =========================
    # 2. 按 Subtype 单独划分
    # =========================
    for subtype, sub_df in df.groupby(subtype_col, sort=False):
        sub_df = sub_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
        n = len(sub_df)

        # =====================================================
        # n = 1：
        # 同一条样本同时放入 train 和 test
        # 保证 train/test 都覆盖该 Subtype
        # =====================================================
        if n == 1:
            train_sub = sub_df.copy()
            test_sub = sub_df.copy()
            split_mode = "duplicated_single_sample"

        # =====================================================
        # n >= 2：
        # 按 8:2 划分
        # 同时保证 train/test 都至少 1 条
        # =====================================================
        else:
            n_test = int(round(n * test_ratio))

            # 保证 test 至少 1 条
            n_test = max(1, n_test)

            # 保证 train 至少 1 条
            n_test = min(n_test, n - 1)

            n_train = n - n_test

            train_sub = sub_df.iloc[:n_train].copy()
            test_sub = sub_df.iloc[n_train:].copy()

            split_mode = "subtype_8_2_with_min_train_test"

        train_parts.append(train_sub)
        test_parts.append(test_sub)

        stats.append({
            "Subtype": subtype,
            "Total_count": n,
            "Train_count": len(train_sub),
            "Test_count": len(test_sub),
            "Train_ratio": len(train_sub) / n,
            "Test_ratio": len(test_sub) / n,
            "Split_mode": split_mode
        })

    # =========================
    # 3. 合并 train / test
    # =========================
    train_df = pd.concat(train_parts, ignore_index=True)
    test_df = pd.concat(test_parts, ignore_index=True)

    # 打乱最终数据
    train_df = train_df.sample(frac=1, random_state=random_state).reset_index(drop=True)
    test_df = test_df.sample(frac=1, random_state=random_state).reset_index(drop=True)

    # =========================
    # 4. 检查 Subtype 覆盖
    # =========================
    all_subtypes = set(df[subtype_col].astype(str).unique())
    train_subtypes = set(train_df[subtype_col].astype(str).unique())
    test_subtypes = set(test_df[subtype_col].astype(str).unique())

    missing_train = sorted(all_subtypes - train_subtypes)
    missing_test = sorted(all_subtypes - test_subtypes)

    if len(missing_train) > 0:
        raise RuntimeError(
            "错误：以下 Subtype 没有出现在 train 中：\n"
            + "\n".join(map(str, missing_train[:50]))
        )

    if len(missing_test) > 0:
        raise RuntimeError(
            "错误：以下 Subtype 没有出现在 test 中：\n"
            + "\n".join(map(str, missing_test[:50]))
        )

    # =========================
    # 5. 检查 train/test 重复样本
    # =========================
    train_original_ids = set(train_df["_original_index"].tolist())
    test_original_ids = set(test_df["_original_index"].tolist())
    overlap_ids = train_original_ids & test_original_ids

    # 注意：
    # 按你的规则，n=1 的 subtype 会故意重复进入 train/test
    # 因此这里不报错，只统计重复数量

    # 删除辅助列后再保存
    train_df_out = train_df.drop(columns=["_original_index"])
    test_df_out = test_df.drop(columns=["_original_index"])

    # =========================
    # 6. 保存结果
    # =========================
    train_df_out.to_csv(train_output, index=False, encoding="utf-8-sig")
    test_df_out.to_csv(test_output, index=False, encoding="utf-8-sig")

    stats_df = pd.DataFrame(stats)
    stats_df.to_csv(stats_output, index=False, encoding="utf-8-sig")

    # =========================
    # 7. 输出统计
    # =========================
    total_n = len(df)
    train_n = len(train_df_out)
    test_n = len(test_df_out)

    duplicated_single_count = int((stats_df["Split_mode"] == "duplicated_single_sample").sum())
    multi_sample_count = int((stats_df["Split_mode"] == "subtype_8_2_with_min_train_test").sum())

    print("数据划分完成")
    print(f"原始总样本数: {total_n}")
    print(f"原始 Subtype 数: {len(all_subtypes)}")

    print("\n划分规则:")
    print("n = 1: 同一样本同时放入 train 和 test")
    print("n >= 2: 每个 Subtype 内部按 8:2 划分，并保证 train/test 都至少 1 条")
    print("test 集覆盖所有 Subtype")

    print("\n最终数据集:")
    print(f"Train 样本数: {train_n}")
    print(f"Test 样本数: {test_n}")
    print(f"Train 比例: {train_n / (train_n + test_n):.4f}")
    print(f"Test 比例: {test_n / (train_n + test_n):.4f}")

    print("\nSubtype 覆盖检查:")
    print(f"Train Subtype 数: {train_df_out[subtype_col].nunique()}")
    print(f"Test Subtype 数: {test_df_out[subtype_col].nunique()}")
    print(f"原始 Subtype 数: {len(all_subtypes)}")
    print("Train 是否覆盖所有 Subtype:", len(missing_train) == 0)
    print("Test 是否覆盖所有 Subtype:", len(missing_test) == 0)

    print("\n重复情况:")
    print(f"只有 1 条样本并被复制到 train/test 的 Subtype 数: {duplicated_single_count}")
    print(f"有 2 条及以上样本并按 8:2 划分的 Subtype 数: {multi_sample_count}")
    print(f"Train/Test 重复原始样本数: {len(overlap_ids)}")

    print("\nTrain 中 Subtype 样本数最少的前 20 个:")
    print(train_df_out[subtype_col].value_counts().sort_values().head(20))

    print("\nTest 中 Subtype 样本数最少的前 20 个:")
    print(test_df_out[subtype_col].value_counts().sort_values().head(20))

    print(f"\n已保存 train: {train_output}")
    print(f"已保存 test: {test_output}")
    print(f"已保存统计文件: {stats_output}")

    return train_df_out, test_df_out, stats_df


# =========================
# 执行
# =========================
split_by_subtype_train_test_all_cover_8_2(
    file_path="all_arg_nonarg_id_label.csv",
    subtype_col="Subtype",
    test_ratio=0.2,
    random_state=42,
    train_output="train_set.csv",
    test_output="test_set.csv",
    stats_output="subtype_split_statistics.csv"
)