from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

PRED_FILE = BASE_DIR / "subtype_test_predictions_protein.csv"
METRIC_FILE = BASE_DIR / "subtype_metrics_by_class.csv"

OUTPUT_DIR = BASE_DIR / "top_bottom_nonARG_combined_figure"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "top10_bottom10_nonARG_combined.pdf"
OUTPUT_TIF = OUTPUT_DIR / "top10_bottom10_nonARG_combined.tif"
OUTPUT_SUMMARY = OUTPUT_DIR / "top10_bottom10_nonARG_summary.csv"
OUTPUT_NONARG = OUTPUT_DIR / "nonARG_prediction_outcome_summary.csv"


# =========================================================
# 2. 参数设置
# =========================================================

TOP_N = 10
BOTTOM_N = 10

COLOR_TOP = "#3C5488"
COLOR_BOTTOM = "#E64B35"
COLOR_NONARG_CORRECT = "#3C5488"
COLOR_NONARG_MISCLASS = "#E64B35"

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取预测文件
# =========================================================

if not PRED_FILE.exists():
    raise FileNotFoundError(f"找不到文件: {PRED_FILE}")

df = pd.read_csv(PRED_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["Subtype", "Pred_Subtype"]
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"{PRED_FILE.name} 缺少这些列: {missing_cols}")

df["Subtype"] = df["Subtype"].astype(str).str.strip()
df["Pred_Subtype"] = df["Pred_Subtype"].astype(str).str.strip()

df["Correct"] = df["Subtype"] == df["Pred_Subtype"]


# =========================================================
# 4. 统计 subtype 数量与准确率
# =========================================================

summary = (
    df.groupby("Subtype")
    .agg(
        Count=("Subtype", "size"),
        Correct=("Correct", "sum"),
        Accuracy=("Correct", "mean"),
    )
    .reset_index()
)

summary["Accuracy"] = summary["Accuracy"].astype(float)

# nonARG 单独统计，不参与 top/bottom 10 的筛选
nonarg_summary = summary[summary["Subtype"] == "nonARG"].copy()

# 只在 ARG subtype 中选数量最多和最少的 10 个
arg_summary = summary[summary["Subtype"] != "nonARG"].copy()

if len(arg_summary) == 0:
    raise ValueError("除 nonARG 外没有其他 ARG subtype，无法绘制雷达图。")

top10 = (
    arg_summary
    .sort_values(["Count", "Accuracy", "Subtype"], ascending=[False, False, True])
    .head(TOP_N)
    .copy()
)

bottom10 = (
    arg_summary
    .sort_values(["Count", "Accuracy", "Subtype"], ascending=[True, False, True])
    .head(BOTTOM_N)
    .copy()
)

top10["Group"] = "Top 10 abundant ARG subtypes"
bottom10["Group"] = "Bottom 10 abundant ARG subtypes"

if len(nonarg_summary) > 0:
    nonarg_summary["Group"] = "nonARG"
    output_summary = pd.concat([top10, bottom10, nonarg_summary], axis=0)
else:
    output_summary = pd.concat([top10, bottom10], axis=0)

output_summary.to_csv(OUTPUT_SUMMARY, index=False, encoding="utf-8-sig")


# =========================================================
# 5. 统计 nonARG prediction outcome
# =========================================================

nonarg_df = df[df["Subtype"] == "nonARG"].copy()

if len(nonarg_df) == 0:
    raise ValueError("预测文件中没有找到真实标签为 nonARG 的样本。")

total_nonarg = len(nonarg_df)
correct_nonarg = int((nonarg_df["Pred_Subtype"] == "nonARG").sum())
misclassified_nonarg = total_nonarg - correct_nonarg

correct_pct = correct_nonarg / total_nonarg * 100
misclassified_pct = misclassified_nonarg / total_nonarg * 100

nonarg_outcome = pd.DataFrame({
    "Category": [
        "Predicted as nonARG",
        "Misclassified as ARG subtype",
    ],
    "Count": [
        correct_nonarg,
        misclassified_nonarg,
    ],
    "Percentage": [
        correct_pct,
        misclassified_pct,
    ],
})

nonarg_outcome.to_csv(OUTPUT_NONARG, index=False, encoding="utf-8-sig")


# =========================================================
# 6. 如果存在 subtype_metrics_by_class.csv，则读取 nonARG 指标
#    这一步不是绘图必需，只用于控制台打印参考信息
# =========================================================

if METRIC_FILE.exists():
    metric_df = pd.read_csv(METRIC_FILE)
    metric_df.columns = metric_df.columns.astype(str).str.strip()

    if "Subtype" in metric_df.columns:
        metric_df["Subtype"] = metric_df["Subtype"].astype(str).str.strip()
        metric_nonarg = metric_df[metric_df["Subtype"] == "nonARG"].copy()

        if len(metric_nonarg) > 0:
            print("\nnonARG metrics from subtype_metrics_by_class.csv:")
            print(metric_nonarg)


# =========================================================
# 7. 雷达图函数
# =========================================================

def shorten_label(x):
    x = str(x)
    if "__" in x:
        return x.split("__", 1)[1]
    return x


def plot_radar(ax, data, title, line_color):
    labels = [shorten_label(x) for x in data["Subtype"].tolist()]
    values = data["Accuracy"].astype(float).tolist()
    counts = data["Count"].astype(int).tolist()

    n = len(labels)

    if n == 0:
        raise ValueError(f"{title} 没有可绘制的数据。")

    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)

    values_closed = values + values[:1]
    angles_closed = np.concatenate([angles, angles[:1]])

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    ax.plot(
        angles_closed,
        values_closed,
        color=line_color,
        linewidth=1.8,
        marker="o",
        markersize=4,
    )

    ax.fill(
        angles_closed,
        values_closed,
        color=line_color,
        alpha=0.18,
    )

    ax.set_xticks(angles)
    ax.set_xticklabels(
        [f"{lab}\n(n={cnt})" for lab, cnt in zip(labels, counts)],
        fontsize=6.5,
    )

    ax.set_ylim(0, 1.0)
    yticks = np.arange(0.2, 1.01, 0.2)
    ax.set_yticks(yticks)
    ax.set_yticklabels([f"{x:.1f}" for x in yticks], fontsize=7)

    ax.set_title(title, fontsize=10, pad=18)

    ax.grid(
        True,
        linestyle="-",
        linewidth=0.45,
        alpha=0.45,
    )

    ax.spines["polar"].set_linewidth(1.0)
    ax.spines["polar"].set_color("black")


# =========================================================
# 8. nonARG 柱状图函数
# =========================================================

def plot_nonarg_bar(ax):
    categories = [
        "Predicted\nas nonARG",
        "Misclassified\nas ARG subtype",
    ]

    counts = [
        correct_nonarg,
        misclassified_nonarg,
    ]

    percentages = [
        correct_pct,
        misclassified_pct,
    ]

    colors = [
        COLOR_NONARG_CORRECT,
        COLOR_NONARG_MISCLASS,
    ]

    x = np.arange(len(categories))

    bars = ax.bar(
        x,
        percentages,
        color=colors,
        edgecolor="black",
        linewidth=0.6,
        width=0.62,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(categories, fontsize=8)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Percentage (%)")
    ax.set_title("Prediction outcomes of nonARG samples", fontsize=10, pad=10)

    for bar, count, pct in zip(bars, counts, percentages):
        height = bar.get_height()

        ax.text(
            bar.get_x() + bar.get_width() / 2,
            height + 2,
            f"{count}\n({pct:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=8,
        )

    ax.grid(
        axis="y",
        linestyle="-",
        linewidth=0.45,
        alpha=0.45,
    )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


# =========================================================
# 9. 绘图
# =========================================================

fig = plt.figure(figsize=(13.2, 4.6), dpi=600)

gs = fig.add_gridspec(
    1,
    3,
    width_ratios=[1.1, 1.1, 0.85],
    wspace=0.45,
)

ax1 = fig.add_subplot(gs[0, 0], polar=True)
ax2 = fig.add_subplot(gs[0, 1], polar=True)
ax3 = fig.add_subplot(gs[0, 2])

plot_radar(
    ax1,
    top10,
    "Top 10 abundant ARG subtypes",
    COLOR_TOP,
)

plot_radar(
    ax2,
    bottom10,
    "Bottom 10 abundant ARG subtypes",
    COLOR_BOTTOM,
)

plot_nonarg_bar(ax3)

plt.tight_layout()


# =========================================================
# 10. 保存
# =========================================================

fig.savefig(OUTPUT_PDF, bbox_inches="tight")
fig.savefig(
    OUTPUT_TIF,
    dpi=600,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 11. 输出信息
# =========================================================

print("\nTop 10 abundant ARG subtypes:")
print(top10[["Subtype", "Count", "Correct", "Accuracy"]])

print("\nBottom 10 abundant ARG subtypes:")
print(bottom10[["Subtype", "Count", "Correct", "Accuracy"]])

print("\nnonARG prediction outcome:")
print(nonarg_outcome)

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_SUMMARY)
print(OUTPUT_NONARG)