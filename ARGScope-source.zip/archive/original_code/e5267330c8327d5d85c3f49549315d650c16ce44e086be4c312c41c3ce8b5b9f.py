"""Export the latest VF/BGC figure without panel-letter annotations."""
from pathlib import Path
import json
import shutil
from matplotlib.text import Text
import redraw_vf_bgc_typebars_only_20260925 as layout

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/vf_bgc_no_panel_labels_20260925'
base = layout.base
layout.OUT = OUT
base.OUT = OUT
original_export = base.export
RENAMES = {
    'VF_BGC_typebars_only_A4_300DPI': 'VF_BGC_no_panel_labels_A4_300DPI',
    'AB_VF_BGC_dataset_types': 'VF_BGC_dataset_types',
    'A_VF_dataset_types': 'VF_dataset_types',
    'B_BGC_dataset_types': 'BGC_dataset_types',
    'C_VF_binary_unchanged': 'VF_binary',
    'D_VF_subtype_unchanged': 'VF_subtype_weighted',
    'E_BGC_binary_unchanged': 'BGC_binary',
    'F_BGC_subtype_unchanged': 'BGC_subtype_weighted',
    'G_VF_type_unchanged': 'VF_type',
    'H_BGC_type_unchanged': 'BGC_type',
}


def no_letter(*args, **kwargs):
    return None


def export_without_letters(fig):
    old_name = fig.get_label()
    fig.set_label(RENAMES[old_name])
    for item in fig.texts:
        if item.get_text().startswith('A–B:'):
            item.set_text('Dataset bars: target sequences only; AA and NT use the same sequence records.')
    texts = [item.get_text().strip() for item in fig.findobj(match=Text) if item.get_visible()]
    assert not any(value in set('ABCDEFGH') for value in texts), (old_name, texts)
    assert not any(value.startswith('A–B:') for value in texts)
    # The original export uses a prefix to recognize A4 figures; this paired
    # chart is a separate, intentionally wide standalone dataset figure.
    if old_name == 'AB_VF_BGC_dataset_types':
        fig.set_label('Dataset_types_VF_BGC')
    original_export(fig)
    base.AUDIT['figures'][-1]['panel_letter_annotations_absent'] = True


def main():
    base.letter = no_letter
    base.export = export_without_letters
    layout.main()
    verification = OUT / 'verification.json'
    audit = json.loads(verification.read_text(encoding='utf-8'))
    audit['panel_letter_annotations_absent_in_all_figures'] = True
    verification.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(Path(__file__), OUT / 'code' / Path(__file__).name)


if __name__ == '__main__':
    main()
