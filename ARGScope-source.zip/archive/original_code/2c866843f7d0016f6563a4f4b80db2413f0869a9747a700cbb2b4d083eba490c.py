from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

# 优先使用标准文件名；如果不存在，会自动寻找 subtype_test_predictions*.csv
PRED_FILE = BASE_DIR / "subtype_test_predictions_protein.csv"

if not PRED_FILE.exists():
    candidate_files = sorted(BASE_DIR.glob("subtype_test_predictions*.csv"))
    if len(candidate_files) == 0:
        raise FileNotFoundError(
            "当前文件夹中没有找到 subtype_test_predictions_protein.csv 或 subtype_test_predictions*.csv"
        )
    PRED_FILE = candidate_files[0]

OUTPUT_DIR = BASE_DIR / "type_confusion_matrix"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "type_confusion_matrix.pdf"
OUTPUT_TIF = OUTPUT_DIR / "type_confusion_matrix.tif"
OUTPUT_COUNT_CSV = OUTPUT_DIR / "type_confusion_matrix_counts.csv"
OUTPUT_NORM_CSV = OUTPUT_DIR / "type_confusion_matrix_row_normalized.csv"
OUTPUT_PRED_WITH_TYPE = OUTPUT_DIR / "predictions_with_inferred_type.csv"


# =========================================================
# 2. 参数设置
# =========================================================

# 是否按真实 Type 的样本数排序
SORT_BY_SUPPORT = True

# 是否把 nonARG 放在最后
PUT_NONARG_LAST = True

# 是否在图中显示数值
# 类别较多时建议 False，图更干净
SHOW_VALUES = False

# 混淆矩阵使用行归一化：
# 每一行加和为 1，表示真实 Type 中被预测为各 Type 的比例
NORMALIZE_BY_ROW = True

# 色阶范围
VMIN = 0.0
VMAX = 1.0

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取预测文件
# =========================================================

df = pd.read_csv(PRED_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = ["Type", "Subtype", "Pred_Subtype"]
missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"{PRED_FILE.name} 缺少这些列: {missing_cols}")

df["Type"] = df["Type"].astype(str).str.strip()
df["Subtype"] = df["Subtype"].astype(str).str.strip()
df["Pred_Subtype"] = df["Pred_Subtype"].astype(str).str.strip()


# =========================================================
# 4. 根据 Subtype -> Type 映射反推 Pred_Type
# =========================================================

if "Pred_Type" in df.columns:
    df["Pred_Type"] = df["Pred_Type"].astype(str).str.strip()

else:
    subtype_to_type = {}

    for subtype, sub_df in df.groupby("Subtype"):
        type_counts = Counter(sub_df["Type"].tolist())
        most_common_type, most_common_count = type_counts.most_common(1)[0]
        subtype_to_type[subtype] = most_common_type

        if len(type_counts) > 1:
            print(
                f"Warning: Subtype '{subtype}' 对应多个 Type，"
                f"使用出现次数最多的 Type: {most_common_type}"
            )

    # nonARG 特殊处理
    subtype_to_type["nonARG"] = "nonARG"

    df["Pred_Type"] = df["Pred_Subtype"].map(subtype_to_type)

    unknown_mask = df["Pred_Type"].isna()

    if unknown_mask.any():
        unknown_subtypes = sorted(df.loc[unknown_mask, "Pred_Subtype"].unique())
        print("\nWarning: 以下 Pred_Subtype 无法映射到 Type，将标记为 Unknown:")
        for x in unknown_subtypes:
            print(f"  {x}")

        df.loc[unknown_mask, "Pred_Type"] = "Unknown"


df.to_csv(OUTPUT_PRED_WITH_TYPE, index=False, encoding="utf-8-sig")


# =========================================================
# 5. 构建 Type-level confusion matrix
# =========================================================

all_types = sorted(set(df["Type"].unique()) | set(df["Pred_Type"].unique()))

if SORT_BY_SUPPORT:
    support_order = (
        df["Type"]
        .value_counts()
        .reset_index()
    )
    support_order.columns = ["Type", "support"]

    ordered_types = support_order["Type"].tolist()

    for t in all_types:
        if t not in ordered_types:
            ordered_types.append(t)

else:
    ordered_types = all_types

if PUT_NONARG_LAST and "nonARG" in ordered_types:
    ordered_types = [x for x in ordered_types if x != "nonARG"] + ["nonARG"]

if "Unknown" in ordered_types:
    ordered_types = [x for x in ordered_types if x != "Unknown"] + ["Unknown"]

count_matrix = pd.crosstab(
    df["Type"],
    df["Pred_Type"],
    rownames=["Real label"],
    colnames=["Prediction label"],
)

count_matrix = count_matrix.reindex(
    index=ordered_types,
    columns=ordered_types,
    fill_value=0,
)

if NORMALIZE_BY_ROW:
    norm_matrix = count_matrix.div(
        count_matrix.sum(axis=1).replace(0, np.nan),
        axis=0
    ).fillna(0)
else:
    norm_matrix = count_matrix.copy()

count_matrix.to_csv(OUTPUT_COUNT_CSV, encoding="utf-8-sig")
norm_matrix.to_csv(OUTPUT_NORM_CSV, encoding="utf-8-sig")


# =========================================================
# 6. 标签格式美化
# =========================================================

def format_type_label(x):
    x = str(x)

    replace_dict = {
        "beta_lactam": "Beta-lactam",
        "multidrug": "Multidrug",
        "aminoglycoside": "Aminoglycoside",
        "macrolide-lincosamide-streptogramin": "MLS",
        "trimethoprim": "Trimethoprim",
        "tetracycline": "Tetracycline",
        "glycopeptide": "Glycopeptide",
        "sulfonamide": "Sulfonamide",
        "quinolone": "Quinolone",
        "fluoroquinolone": "Fluoroquinolone",
        "phenicol": "Phenicol",
        "rifamycin": "Rifamycin",
        "peptide": "Peptide",
        "bacitracin": "Bacitracin",
        "fosfomycin": "Fosfomycin",
        "fusidic_acid": "Fusidic acid",
        "nucleoside": "Nucleoside",
        "aminocoumarin": "Aminocoumarin",
        "triclosan": "Triclosan",
        "mupirocin": "Mupirocin",
        "nonARG": "Non-ARGs",
        "Unknown": "Unknown",
    }

    if x in replace_dict:
        return replace_dict[x]

    x = x.replace("_", " ")
    x = x.replace("-", "-")
    return x[:1].upper() + x[1:]


display_labels = [format_type_label(x) for x in ordered_types]


# =========================================================
# 7. 绘制 confusion matrix
# =========================================================

n_types = len(ordered_types)

fig_size = max(5.2, n_types * 0.34)

fig, ax = plt.subplots(
    figsize=(fig_size, fig_size),
    dpi=600,
)

im = ax.imshow(
    norm_matrix.values,
    cmap="Blues",
    vmin=VMIN,
    vmax=VMAX,
    interpolation="nearest",
    aspect="equal",
)

ax.set_title("Confusion matrix", fontsize=12, pad=10)

ax.set_xlabel("Prediction label", fontsize=11, labelpad=10)
ax.set_ylabel("Real label", fontsize=11, labelpad=10)

ax.set_xticks(np.arange(n_types))
ax.set_yticks(np.arange(n_types))

ax.set_xticklabels(
    display_labels,
    rotation=45,
    ha="right",
    rotation_mode="anchor",
    fontsize=8,
)

ax.set_yticklabels(
    display_labels,
    fontsize=8,
)

# 小刻度网格线
ax.set_xticks(np.arange(n_types + 1) - 0.5, minor=True)
ax.set_yticks(np.arange(n_types + 1) - 0.5, minor=True)

ax.grid(
    which="minor",
    color="white",
    linestyle="-",
    linewidth=0.5,
)

ax.tick_params(which="minor", bottom=False, left=False)

# 外框
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.0)
    spine.set_color("black")

# colorbar
cbar = fig.colorbar(
    im,
    ax=ax,
    fraction=0.046,
    pad=0.04,
)

if NORMALIZE_BY_ROW:
    cbar.set_label("Row-normalized proportion", fontsize=9)
else:
    cbar.set_label("Count", fontsize=9)

cbar.ax.tick_params(labelsize=8)


# =========================================================
# 8. 可选：显示矩阵数值
# =========================================================

if SHOW_VALUES:
    values = norm_matrix.values

    for i in range(n_types):
        for j in range(n_types):
            value = values[i, j]

            if value == 0:
                continue

            text_color = "white" if value >= 0.5 else "black"

            if NORMALIZE_BY_ROW:
                label = f"{value:.2f}"
            else:
                label = str(int(value))

            ax.text(
                j,
                i,
                label,
                ha="center",
                va="center",
                fontsize=6,
                color=text_color,
            )


# =========================================================
# 9. 保存
# =========================================================

plt.tight_layout()

fig.savefig(OUTPUT_PDF, bbox_inches="tight")
fig.savefig(
    OUTPUT_TIF,
    dpi=600,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 10. 输出信息
# =========================================================

print("\nInput file:")
print(PRED_FILE)

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_COUNT_CSV)
print(OUTPUT_NORM_CSV)
print(OUTPUT_PRED_WITH_TYPE)

print("\nType-level confusion matrix counts:")
print(count_matrix)