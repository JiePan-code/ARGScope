import random

# =========================
# 配置区
# =========================
PROTEIN_FASTA = "all_arg_nonarg_protein.fasta"
DNA_FASTA = "all_arg_nonarg_dna.fasta"

NUM_PARTS = 5
SEED = 42

PERCENTAGES = [30, 40, 50, 60, 70, 80]

random.seed(SEED)

# =========================
# FASTA 读取函数
# =========================
def read_fasta(fasta_file):
    records = []
    header = None
    seq_lines = []

    with open(fasta_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines)))
                header = line[1:]
                seq_lines = []
            else:
                seq_lines.append(line)

        if header is not None:
            records.append((header, "".join(seq_lines)))

    return records

# =========================
# FASTA 写出函数
# =========================
def write_fasta(records, out_file, line_width=60):
    with open(out_file, "w", encoding="utf-8") as f:
        for header, seq in records:
            f.write(f">{header}\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")

# =========================
# 提取主ID
# 默认只取 header 空格前的第一段
# 例如：
# >gene001 something else -> gene001
# =========================
def get_main_id(header):
    return header.split()[0].strip()

# =========================
# 构建 ID -> (header, seq) 字典
# 若有重复 ID，直接报错
# =========================
def build_record_dict(records, source_name="fasta"):
    record_dict = {}
    duplicate_ids = []

    for header, seq in records:
        seq_id = get_main_id(header)
        if seq_id in record_dict:
            duplicate_ids.append(seq_id)
        else:
            record_dict[seq_id] = (header, seq)

    if duplicate_ids:
        show_ids = ", ".join(duplicate_ids[:10])
        raise ValueError(
            f"{source_name} 中发现重复ID，无法唯一自动配对。示例重复ID: {show_ids}"
        )

    return record_dict

# =========================
# protein-DNA 自动配对
# 只保留共同 ID
# =========================
def build_paired_records(protein_records, dna_records):
    protein_dict = build_record_dict(protein_records, source_name="protein fasta")
    dna_dict = build_record_dict(dna_records, source_name="dna fasta")

    protein_ids = set(protein_dict.keys())
    dna_ids = set(dna_dict.keys())

    common_ids = sorted(protein_ids & dna_ids)
    protein_only_ids = sorted(protein_ids - dna_ids)
    dna_only_ids = sorted(dna_ids - protein_ids)

    paired_records = []
    for seq_id in common_ids:
        p_header, p_seq = protein_dict[seq_id]
        d_header, d_seq = dna_dict[seq_id]
        paired_records.append((seq_id, p_header, p_seq, d_header, d_seq))

    print(f"Protein 总ID数: {len(protein_ids)}")
    print(f"DNA 总ID数: {len(dna_ids)}")
    print(f"成功配对ID数: {len(common_ids)}")
    print(f"仅在 Protein 中存在的ID数: {len(protein_only_ids)}")
    print(f"仅在 DNA 中存在的ID数: {len(dna_only_ids)}")

    if protein_only_ids:
        print("示例 Protein-only IDs:", protein_only_ids[:10])
    if dna_only_ids:
        print("示例 DNA-only IDs:", dna_only_ids[:10])

    if len(common_ids) == 0:
        raise ValueError("Protein 和 DNA 没有可配对的共同ID。")

    return paired_records

# =========================
# 联动按比例切割
# 关键规则：
# 1. aa_len 按 protein 长度 * 百分比
# 2. nt_len = aa_len * 3
# 3. 同一个片段共用 protein 起点
# 4. DNA 起点 = protein 起点 * 3
# =========================
def make_paired_percent_reads_by_id(paired_records, percent, num_parts=5):
    protein_out = []
    dna_out = []

    for seq_id, p_header, p_seq, d_header, d_seq in paired_records:
        p_seq = p_seq.strip()
        d_seq = d_seq.strip()

        p_len = len(p_seq)
        d_len = len(d_seq)

        # 按 protein 长度计算 aa 片段长度
        aa_len = round(p_len * percent / 100.0)
        if aa_len < 1:
            aa_len = 1

        # DNA 长度固定对应同一区域
        nt_len = aa_len * 3

        for i in range(1, num_parts + 1):
            new_header = f"{seq_id}_{i}"

            # 任一序列不足对应长度，则直接保留全长
            if p_len <= aa_len or d_len <= nt_len:
                p_sub = p_seq
                d_sub = d_seq
            else:
                max_p_start_by_protein = p_len - aa_len
                max_p_start_by_dna = (d_len - nt_len) // 3
                max_p_start = min(max_p_start_by_protein, max_p_start_by_dna)

                if max_p_start < 0:
                    p_sub = p_seq
                    d_sub = d_seq
                else:
                    p_start = random.randint(0, max_p_start)
                    d_start = p_start * 3

                    p_sub = p_seq[p_start:p_start + aa_len]
                    d_sub = d_seq[d_start:d_start + nt_len]

            protein_out.append((new_header, p_sub))
            dna_out.append((new_header, d_sub))

    return protein_out, dna_out

# =========================
# 主程序
# =========================
def main():
    protein_records = read_fasta(PROTEIN_FASTA)
    dna_records = read_fasta(DNA_FASTA)

    print(f"Protein 原始记录数: {len(protein_records)}")
    print(f"DNA 原始记录数: {len(dna_records)}")

    paired_records = build_paired_records(protein_records, dna_records)

    for pct in PERCENTAGES:
        protein_outfile = f"protein_{pct}pct_5parts.fasta"
        dna_outfile = f"dna_{pct}pct_5parts.fasta"

        protein_short, dna_short = make_paired_percent_reads_by_id(
            paired_records=paired_records,
            percent=pct,
            num_parts=NUM_PARTS
        )

        write_fasta(protein_short, protein_outfile)
        write_fasta(dna_short, dna_outfile)

        print(f"[{pct}%] 已输出:")
        print(f"  - {protein_outfile}  共 {len(protein_short)} 条")
        print(f"  - {dna_outfile}      共 {len(dna_short)} 条")

    print("Done.")

if __name__ == "__main__":
    main()