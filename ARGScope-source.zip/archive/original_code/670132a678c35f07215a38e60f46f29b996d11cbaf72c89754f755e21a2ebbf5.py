"""GAT refinement for the fixed-equal-weight fusion ablation."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, load_base

DATA = Path(__file__).resolve().parents[3]
m = load_base("03_refine_gat.py", "gat_wo_gate_base")
m.ROOT = DATA
m.DEFAULT_RAW_PT = DATA / "Raw_subtype_prototypes_subtype2_nogate" / "raw_ARG_subtype_prototypes_and_baseline.pt"
m.DEFAULT_FUSED_PT = DATA / "Long_fusion_subtype2_nogate" / "long_fusion_subtype2_nogate.pt"
m.DEFAULT_OUTPUT_PT = DATA / "Refined_subtype_prototypes_subtype2_nogate" / "refined_ARG_subtype_prototypes_residual_GAT.pt"
add_default_structure(DATA)
m.main()
