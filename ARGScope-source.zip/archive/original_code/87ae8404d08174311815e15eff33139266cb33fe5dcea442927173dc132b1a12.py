"""Regression check for the actual DNA/Protein no-transfer adapter calls."""
from pathlib import Path
from tempfile import TemporaryDirectory

import torch

import ablation_runtime as runtime


def main():
    assert torch.cuda.is_available(), "This test requires the local training CUDA environment."
    for filename, modality in [
        ("04_protein_student.py", "protein"),
        ("05_dna_student.py", "dna"),
    ]:
        module = runtime.load_base(filename, f"test_transfer_{modality}")
        config = module.Config()
        original_coefficients = (config.student_binary_ce, config.student_subtype_ce)
        captured = {}

        def student_probe(teacher, data, conf, amp, hb, snapshot_epochs, snapshot_dir):
            captured.update(vars(conf))
            return "student_called"

        module.train_student = student_probe
        runtime.disable_learned_transfer(module)
        data = {"refined_gpu": torch.ones(3, config.embedding_dim, device="cuda")}
        with TemporaryDirectory() as temp:
            kwargs = {"progress_dir": Path(temp)} if modality == "dna" else {}
            teacher, history, best_epoch, _ = module.train_teacher(
                data, config, False, None, **kwargs
            )
            assert history == [] and best_epoch == 0
            assert not torch.equal(teacher.arg_head.weight, data["refined_gpu"])
            assert list(Path(temp).iterdir()) == [], "No trained-Teacher artifacts expected"
            result = module.train_student(
                teacher, data, config, False, None,
                snapshot_epochs=[0], snapshot_dir=Path(temp),
            )
            assert result == "student_called"
            for field in (
                "student_binary_kd", "student_subtype_kd", "student_feature_align",
                "student_prototype_align", "student_head_anchor",
            ):
                assert captured[field] == 0.0, field
            assert (config.student_binary_ce, config.student_subtype_ce) == original_coefficients
        print(f"PASS: {modality} call signature, random head, no Teacher optimization, five transfer coefficients zero")
        del teacher, data
    print("PASS: both real module interfaces compatible")


if __name__ == "__main__":
    main()
