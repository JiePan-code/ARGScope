#!/usr/bin/env python3
"""Verify unchanged estimates, linear zero-based radial geometry and exports."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
DATA=ROOT/'data'


def main():
    for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
    render=json.loads((ROOT/'render_status.json').read_text())
    assert render['status']=='COMPLETE'
    assert render['script_sha256']==hashlib.sha256((ROOT/'plot_sector_comparison.py').read_bytes()).hexdigest()
    figdir=ROOT/render['figure_directory']
    hashes=json.loads((DATA/'input_hashes.json').read_text())
    for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
    points=pd.read_csv(SOURCE/'boxplot_revision/data/all_model_points_and_intervals.csv')
    copied=pd.read_csv(DATA/'unchanged_point_estimates_and_intervals.csv')
    pd.testing.assert_frame_equal(points,copied,check_exact=False,rtol=0,atol=1e-12)
    rendered=pd.read_csv(DATA/'rendered_bar_values.csv',dtype={'Label':str})
    keys=['Modality','Model','Completeness','Metric']
    reference=points[points.Level.eq('Type')].set_index(keys)
    assert len(reference)==160 and len(rendered)==480
    assert rendered.groupby(keys).size().eq(3).all()
    for row in rendered.itertuples():
        ref=reference.loc[(row.Modality,row.Model,row.Completeness,row.Metric)]
        assert abs(row.Point_estimate-ref.Point_estimate)<1e-12
        assert row.Label==f'{ref.Point_estimate:.4f}'
        assert row.Radius_bottom==.44
        assert abs(row.Radius_top-row.Radius_bottom-ref.Point_estimate)<1e-10
        assert abs(row.CI_low-ref.CI_low)<1e-12 and abs(row.CI_high-ref.CI_high)<1e-12
        assert row.Population==ref.Population
    matrix=pd.read_csv(DATA/'Type_matrix_without_puromycin.csv',index_col=0)
    full=pd.read_csv(SOURCE/'type_level_revision/data/combined_Type_profile_spearman.csv',index_col=0)
    assert matrix.shape==(22,22) and 'puromycin' not in matrix.index and 'puromycin' not in matrix.columns
    pd.testing.assert_frame_equal(matrix,full.loc[matrix.index,matrix.columns],check_exact=False,rtol=0,atol=1e-12)
    arcs=pd.read_csv(DATA/'model_Type_arcs_without_puromycin.csv')
    fullarcs=pd.read_csv(SOURCE/'type_level_revision/data/combined_model_Type_arcs.csv')
    pd.testing.assert_frame_equal(arcs,fullarcs[fullarcs.Type.ne('puromycin')].reset_index(drop=True),check_exact=False,rtol=0,atol=1e-12)
    assert arcs.Type.nunique()==22 and len(arcs)==176
    layout=json.loads((ROOT/'layout_validation.json').read_text())
    manifest=json.loads((ROOT/'figure_manifest.json').read_text())
    assert len(layout)==11 and all(not r['visible_text_outside_canvas'] for r in layout)
    assert len(manifest)==33
    output_hashes={}
    for row in manifest:
        p=figdir/row['file']
        assert p.stat().st_size>1000 and p.stat().st_mtime>=render['started']-1
        if p.suffix=='.png':
            with Image.open(p) as im:im.verify()
        elif p.suffix=='.svg':
            assert ET.parse(p).getroot().tag.endswith('svg')
            if 'network' in p.name.lower():
                assert 'Puromycin' not in p.read_text(encoding='utf-8')
        elif p.suffix=='.pdf':
            raw=p.read_bytes();assert raw.startswith(b'%PDF') and b'%%EOF' in raw[-100:]
        output_hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    report=dict(status='PASS',designs=11,formal_exports=33,unique_Type_scores=160,rendered_bars=480,
                point_estimates_unchanged=True,bootstrap_intervals_unchanged=True,linear_radial_zero=.44,
                removed_display_type='puromycin',remaining_network_types=22,test_sample_filter=False,
                matched_model_cohorts=False,text_outside_canvas=0,figure_directory=figdir.name,output_sha256=output_hashes)
    (ROOT/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    members=list(ROOT.glob('*.py'))+list(ROOT.glob('*.md'))+list(ROOT.glob('*.json'))+list(DATA.glob('*'))
    members += [figdir/r['file'] for r in manifest]+list(figdir.glob('*_preview.png'))
    members += [SOURCE/'plot_fragment_figure.py',SOURCE/'type_level_revision/plot_type_network_revision.py',
                SOURCE/'boxplot_revision/data/all_model_points_and_intervals.csv',
                SOURCE/'violin_revision/data/ARGScope_parent_bootstrap_five_metrics.csv',
                SOURCE/'type_level_revision/data/combined_Type_profile_spearman.csv',
                SOURCE/'type_level_revision/data/combined_model_Type_arcs.csv']
    members += list((SOURCE/'data').glob('*.csv'))
    archive=SOURCE.parent/'ARGScope_sector_bar_revision.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(members)):
            if p.is_file():z.write(p,p.relative_to(SOURCE.parent))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        print(f'PASS: {len(z.namelist())} files; {archive.stat().st_size/2**20:.2f} MiB',flush=True)
    print(archive)
    print(json.dumps({k:v for k,v in report.items() if k!='output_sha256'},indent=2))


if __name__=='__main__':main()
