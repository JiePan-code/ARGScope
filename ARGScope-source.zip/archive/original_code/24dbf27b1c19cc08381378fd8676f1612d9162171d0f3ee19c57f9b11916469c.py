import pandas as pd

# 输入文件
infile = "final_equal_BGC_nonBGC_id_type_subtype.csv"

# 输出文件
outfile = "final_equal_BGC_nonBGC_id_type_subtype_fixed.csv"

# 读取完整标签表
df = pd.read_csv(infile)

# 检查必要列
required_cols = {"Type", "Subtype"}
missing = required_cols - set(df.columns)
if missing:
    raise ValueError(f"缺少必要列: {missing}")

# 统计每个 Subtype 对应不同 Type 的数量
count_table = (
    df.groupby(["Subtype", "Type"])
      .size()
      .reset_index(name="count")
)

# 对每个 Subtype，只保留数量最多的 Type
# 如果并列，默认保留排序后第一个
dominant_map = (
    count_table
    .sort_values(["Subtype", "count", "Type"], ascending=[True, False, True])
    .drop_duplicates(subset=["Subtype"], keep="first")
    [["Subtype", "Type"]]
    .rename(columns={"Type": "Dominant_Type"})
)

# 合并主对应关系
df_fixed = df.merge(dominant_map, on="Subtype", how="left")

# 只保留 Subtype 对应数量最多的 Type 的记录
df_fixed = df_fixed[df_fixed["Type"] == df_fixed["Dominant_Type"]].copy()

# 删除辅助列
df_fixed = df_fixed.drop(columns=["Dominant_Type"])

# 保存结果
df_fixed.to_csv(outfile, index=False)

print(f"处理完成，保存到: {outfile}")
print(f"原始行数: {len(df)}")
print(f"处理后行数: {len(df_fixed)}")
print(f"删除行数: {len(df) - len(df_fixed)}")

# 输出最终 Subtype-Type 对应表
final_map = (
    df_fixed.groupby(["Subtype", "Type"])
            .size()
            .reset_index(name="count")
            .sort_values(["Subtype", "count"], ascending=[True, False])
)

print("\n最终 Subtype-Type 对应表:")
print(final_map)