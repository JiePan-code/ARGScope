import csv
import math
from pathlib import Path
import subprocess
import sys
import plot_precision_60_90 as p

root = Path('_verification_data').resolve()
root.mkdir(exist_ok=True)
assert p.normalize_type('macrolide-lincosamide-streptogramin') == 'MLS'
assert p.normalize_type('β-lactam') == 'beta_lactam'
assert p.pct_of('protein_60pct_report.csv') == 60
assert p.pct_of('90p_perType_metrics_ARG_only.csv') == 90
assert p.pct_of('deeparg_type_protein_all_classification_report.csv') is None
assert p.average({'bleomycin': 0, 'MLS': 1}) == (0.5, 2)
for mod in ('Protein', 'DNA'):
    for model in p.MODEL_ORDER:
        if mod == 'DNA' and model == 'PLM-ARG':
            continue
        folder = root / model / ('LongAA' if mod == 'Protein' else 'LongNT')
        folder.mkdir(parents=True, exist_ok=True)
        for pct in (60, 70, 80, 90, 100):
            with (folder / f'{pct}p_type_classification_report.csv').open('w', newline='') as f:
                w = csv.writer(f)
                w.writerow(['Type', 'Precision'])
                for i, typ in enumerate(p.TYPE_ORDER):
                    w.writerow([typ, (i + pct) % 19 / 18])
batch = root / 'deeparg_type_batch.csv'
batch.write_text('dataset,Type,precision\nprotein_60pct,MLS,0.5\ndna_70pct,MLS,0.8\n', encoding='utf-8')
groups = p.extract(batch, root, 'fraction')
assert groups[('Protein', 'DeepARG', 60)]['MLS'] == 0.5
batch.unlink()
subprocess.run([sys.executable, 'plot_precision_60_90.py', '--root', str(root), '--dpi', '100', '--formats', 'png', 'tif', 'pdf', 'svg'], check=True)
out = root / 'Protein_DNA_60_90pct_Precision_heatmaps'
rows = list(csv.DictReader((out / 'selected_files.csv').open(encoding='utf-8-sig')))
assert len(rows) == 36
assert {r['completeness'] for r in rows} == {'60','70','80','90'}
assert len(list(out.glob('*.png'))) == 2
print('PASS: normalization, percent detection, batch filtering, Average, 36 selected reports and all figure formats')
