#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
STEP 1
Check the COMPLETE SARG protein database for DNA coverage BEFORE any new download.

Put this script directly in:
    SARG_full_DNA_completion/

Expected files in the SAME directory:
    3.SARG_v3.2_20220917_Long_subdatabase.fasta
    3.SARG_v3.2_20220917_Long_subdatabase_structure.txt

    Nucleotide_SARG_v3.2_Long.fasta
    Nucleotide_SARG_v3.2_Long_structure.txt

    all_arg_nonarg_dna.fasta
    all_arg_nonarg_structure.txt

Interpretation
--------------
1. Nucleotide_SARG_v3.2_Long.*:
   DNA already present in the original SARG nucleotide database.

2. all_arg_nonarg_dna.fasta + all_arg_nonarg_structure.txt:
   Previously constructed/verified DNA dataset, including the already completed
   subtype >= 3 ARG DNA data. These proteins MUST NOT be downloaded again.

3. Only proteins absent from BOTH sources are written to the new NCBI missing list.

NO subtype-count threshold is used here.
Subtype size 1, 2, 3, ... are all included.

Outputs:
    01_full_SARG_DNA_check/
        SARG_full_protein_DNA_coverage_audit.csv
        SARG_full_proteins_truly_missing_DNA.csv
        SARG_full_proteins_truly_missing_DNA.fasta
        SARG_full_subtype_DNA_coverage_before_new_NCBI.csv
        SARG_reused_previous_ge3_DNA_proteins.csv
        SARG_previous_DNA_label_mismatches.csv
        SARG_full_DNA_check_summary.txt
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent

FULL_PROTEIN_FASTA = (
    SCRIPT_DIR
    / "3.SARG_v3.2_20220917_Long_subdatabase.fasta"
)

FULL_PROTEIN_STRUCTURE = (
    SCRIPT_DIR
    / "3.SARG_v3.2_20220917_Long_subdatabase_structure.txt"
)

ORIGINAL_DNA_FASTA = (
    SCRIPT_DIR
    / "Nucleotide_SARG_v3.2_Long.fasta"
)

ORIGINAL_DNA_STRUCTURE = (
    SCRIPT_DIR
    / "Nucleotide_SARG_v3.2_Long_structure.txt"
)

PREVIOUS_GE3_DNA_FASTA = (
    SCRIPT_DIR
    / "all_arg_nonarg_dna.fasta"
)

PREVIOUS_GE3_STRUCTURE = (
    SCRIPT_DIR
    / "all_arg_nonarg_structure.txt"
)

OUTPUT_DIR = (
    SCRIPT_DIR
    / "01_full_SARG_DNA_check"
)


def require_file(
    path: Path,
    description: str,
) -> Path:
    path = path.resolve()

    if not path.is_file():
        raise FileNotFoundError(
            f"{description} not found:\n{path}"
        )

    return path


def canonical_id(
    value: Any,
) -> str:
    text = str(
        value
    ).strip()

    return (
        text.split()[0]
        if text
        else ""
    )


def read_fasta(
    path: Path,
):
    order = []
    records = {}

    current_id = None
    header = ""
    chunks = []

    def save():
        nonlocal current_id
        nonlocal header
        nonlocal chunks

        if current_id is None:
            return

        if current_id in records:
            raise ValueError(
                f"Duplicate FASTA ID in {path.name}: "
                f"{current_id}"
            )

        records[
            current_id
        ] = {
            "header":
                header,

            "sequence":
                "".join(
                    chunks
                )
                .replace(
                    " ",
                    "",
                )
                .replace(
                    "\t",
                    "",
                ),
        }

        order.append(
            current_id
        )

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        for line_number, raw in enumerate(
            handle,
            start=1,
        ):
            line = raw.strip()

            if not line:
                continue

            if line.startswith(
                ">"
            ):
                save()

                header = line[
                    1:
                ].strip()

                if not header:
                    raise ValueError(
                        f"Empty FASTA header: "
                        f"{path}:{line_number}"
                    )

                current_id = canonical_id(
                    header
                )

                chunks = []

            else:
                if current_id is None:
                    raise ValueError(
                        "Sequence before first FASTA header: "
                        f"{path}:{line_number}"
                    )

                chunks.append(
                    line
                )

        save()

    return (
        order,
        records,
    )


def detect_delimiter(
    path: Path,
) -> str:
    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:
        first = handle.readline()

    if "\t" in first:
        return "\t"

    return ","


def read_table(
    path: Path,
):
    delimiter = detect_delimiter(
        path
    )

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        reader = csv.DictReader(
            handle,
            delimiter=delimiter,
        )

        if reader.fieldnames is None:
            raise ValueError(
                f"No header in: {path}"
            )

        return (
            list(
                reader.fieldnames
            ),
            list(
                reader
            ),
        )


def first_existing_value(
    row: dict,
    candidates: list[str],
) -> str:
    for column in candidates:
        if column not in row:
            continue

        value = canonical_id(
            row.get(
                column,
                "",
            )
        )

        if value:
            return value

    return ""


def wrap_sequence(
    sequence: str,
    width: int = 80,
) -> str:
    return "\n".join(
        sequence[
            index:
            index + width
        ]
        for index
        in range(
            0,
            len(
                sequence
            ),
            width,
        )
    )


def write_csv(
    path: Path,
    fields: list[str],
    rows: list[dict],
):
    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            extrasaction="ignore",
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def main():
    full_protein_fasta = require_file(
        FULL_PROTEIN_FASTA,
        "Full SARG protein FASTA",
    )

    full_protein_structure = require_file(
        FULL_PROTEIN_STRUCTURE,
        "Full SARG protein structure",
    )

    original_dna_fasta = require_file(
        ORIGINAL_DNA_FASTA,
        "Original SARG nucleotide FASTA",
    )

    original_dna_structure = require_file(
        ORIGINAL_DNA_STRUCTURE,
        "Original SARG nucleotide structure",
    )

    previous_dna_fasta = require_file(
        PREVIOUS_GE3_DNA_FASTA,
        "Previous subtype>=3 all_arg_nonarg DNA FASTA",
    )

    previous_structure = require_file(
        PREVIOUS_GE3_STRUCTURE,
        "Previous subtype>=3 all_arg_nonarg structure",
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "=" * 110,
        flush=True,
    )

    print(
        "FULL SARG DNA CHECK BEFORE NEW NCBI DOWNLOAD",
        flush=True,
    )

    print(
        "=" * 110,
        flush=True,
    )

    print(
        "NO subtype-count filtering is applied.",
        flush=True,
    )

    print(
        "Existing DNA sources:",
        flush=True,
    )

    print(
        f"  1. Original SARG DNA : {original_dna_fasta}",
        flush=True,
    )

    print(
        f"  2. Previous >=3 DNA  : {previous_dna_fasta}",
        flush=True,
    )

    # ------------------------------------------------------------------
    # Full protein database.
    # ------------------------------------------------------------------

    protein_order, proteins = read_fasta(
        full_protein_fasta
    )

    protein_fields, protein_rows = read_table(
        full_protein_structure
    )

    required_protein_columns = {
        "SARG.Seq.ID",
        "Type",
        "Subtype",
    }

    missing_columns = (
        required_protein_columns
        - set(
            protein_fields
        )
    )

    if missing_columns:
        raise ValueError(
            "Full protein structure missing columns: "
            f"{sorted(missing_columns)}"
        )

    protein_by_id = {}

    subtype_to_type = {}

    subtype_to_proteins = defaultdict(
        list
    )

    for row in protein_rows:
        protein_id = canonical_id(
            row[
                "SARG.Seq.ID"
            ]
        )

        type_name = str(
            row[
                "Type"
            ]
        ).strip()

        subtype = str(
            row[
                "Subtype"
            ]
        ).strip()

        if not protein_id:
            raise ValueError(
                "Full protein structure contains empty SARG.Seq.ID"
            )

        if protein_id in protein_by_id:
            raise ValueError(
                f"Duplicate protein ID in full structure: {protein_id}"
            )

        if (
            subtype in subtype_to_type
            and subtype_to_type[
                subtype
            ] != type_name
        ):
            raise ValueError(
                f"Subtype maps to multiple Types: {subtype}"
            )

        protein_by_id[
            protein_id
        ] = row

        subtype_to_type[
            subtype
        ] = type_name

        subtype_to_proteins[
            subtype
        ].append(
            protein_id
        )

    full_protein_ids = set(
        protein_by_id
    )

    if set(
        proteins
    ) != full_protein_ids:
        raise ValueError(
            "Full SARG protein FASTA and structure ID sets differ:\n"
            f"  FASTA only     = "
            f"{len(set(proteins)-full_protein_ids)}\n"
            f"  Structure only = "
            f"{len(full_protein_ids-set(proteins))}"
        )

    # ------------------------------------------------------------------
    # Original nucleotide SARG coverage:
    # AminoAcidID -> NucleotideID.
    # ------------------------------------------------------------------

    original_dna_order, original_dna_records = read_fasta(
        original_dna_fasta
    )

    original_fields, original_rows = read_table(
        original_dna_structure
    )

    required_original_columns = {
        "AminoAcidID",
        "NucleotideID",
    }

    missing_columns = (
        required_original_columns
        - set(
            original_fields
        )
    )

    if missing_columns:
        raise ValueError(
            "Original DNA structure missing columns: "
            f"{sorted(missing_columns)}"
        )

    original_dna_ids = set(
        original_dna_records
    )

    original_structure_dna_ids = []

    original_protein_to_dna = defaultdict(
        list
    )

    for row in original_rows:
        protein_id = canonical_id(
            row.get(
                "AminoAcidID",
                "",
            )
        )

        dna_id = canonical_id(
            row.get(
                "NucleotideID",
                "",
            )
        )

        if not dna_id:
            raise ValueError(
                "Original nucleotide structure contains empty NucleotideID"
            )

        original_structure_dna_ids.append(
            dna_id
        )

        if (
            protein_id in full_protein_ids
            and dna_id in original_dna_ids
        ):
            original_protein_to_dna[
                protein_id
            ].append(
                dna_id
            )

    if len(
        original_structure_dna_ids
    ) != len(
        set(
            original_structure_dna_ids
        )
    ):
        raise ValueError(
            "Original nucleotide structure contains duplicate NucleotideIDs"
        )

    if original_dna_ids != set(
        original_structure_dna_ids
    ):
        raise ValueError(
            "Original SARG nucleotide FASTA/structure ID sets differ:\n"
            f"  FASTA only = "
            f"{len(original_dna_ids-set(original_structure_dna_ids))}\n"
            f"  Structure only = "
            f"{len(set(original_structure_dna_ids)-original_dna_ids)}"
        )

    proteins_with_original_dna = set(
        original_protein_to_dna
    )

    # ------------------------------------------------------------------
    # Previously completed subtype>=3 all_arg_nonarg DNA.
    #
    # We use TWO checks:
    # 1) Direct FASTA ID == full SARG protein ID.
    # 2) If structure has explicit protein/DNA columns, use those mappings.
    # ------------------------------------------------------------------

    previous_dna_order, previous_dna_records = read_fasta(
        previous_dna_fasta
    )

    previous_dna_ids = set(
        previous_dna_records
    )

    previous_fields, previous_rows = read_table(
        previous_structure
    )

    previous_protein_to_dna = defaultdict(
        list
    )

    previous_label_mismatches = []

    # Direct ID match is expected for the one-DNA-per-protein final dataset.
    for dna_id in previous_dna_order:
        if dna_id in full_protein_ids:
            previous_protein_to_dna[
                dna_id
            ].append(
                dna_id
            )

    protein_id_candidates = [
        "protein_id",
        "AminoAcidID",
        "Original.SARG.Seq.ID",
        "SARG.Seq.ID",
        "output_DNA_id",
    ]

    dna_id_candidates = [
        "DNA_id",
        "NucleotideID",
        "original_DNA_id",
        "output_DNA_id",
        "SARG.Seq.ID",
    ]

    for row in previous_rows:
        protein_id = first_existing_value(
            row,
            protein_id_candidates,
        )

        dna_id = first_existing_value(
            row,
            dna_id_candidates,
        )

        if (
            not protein_id
            or protein_id not in full_protein_ids
        ):
            continue

        # If no separate DNA ID column can be identified, the final paired
        # dataset normally uses protein ID as the DNA FASTA first token.
        if not dna_id:
            dna_id = protein_id

        if dna_id not in previous_dna_ids:
            # Try direct protein-ID FASTA convention.
            if protein_id in previous_dna_ids:
                dna_id = protein_id
            else:
                continue

        labels_consistent = True

        if (
            "Type" in row
            and "Subtype" in row
        ):
            expected = protein_by_id[
                protein_id
            ]

            old_type = str(
                row.get(
                    "Type",
                    "",
                )
            ).strip()

            old_subtype = str(
                row.get(
                    "Subtype",
                    "",
                )
            ).strip()

            expected_type = str(
                expected[
                    "Type"
                ]
            ).strip()

            expected_subtype = str(
                expected[
                    "Subtype"
                ]
            ).strip()

            if (
                old_type
                and old_subtype
                and (
                    old_type != expected_type
                    or old_subtype != expected_subtype
                )
            ):
                labels_consistent = False

                previous_label_mismatches.append(
                    {
                        "protein_id":
                            protein_id,

                        "previous_DNA_id":
                            dna_id,

                        "full_Type":
                            expected_type,

                        "previous_Type":
                            old_type,

                        "full_Subtype":
                            expected_subtype,

                        "previous_Subtype":
                            old_subtype,
                    }
                )

        if labels_consistent:
            previous_protein_to_dna[
                protein_id
            ].append(
                dna_id
            )

    # Remove duplicate DNA IDs per protein.
    for protein_id in list(
        previous_protein_to_dna
    ):
        previous_protein_to_dna[
            protein_id
        ] = sorted(
            set(
                previous_protein_to_dna[
                    protein_id
                ]
            )
        )

    proteins_with_previous_dna = set(
        previous_protein_to_dna
    )

    # ------------------------------------------------------------------
    # Combined coverage.
    # ------------------------------------------------------------------

    covered_by_any = (
        proteins_with_original_dna
        | proteins_with_previous_dna
    )

    truly_missing_ids = [
        protein_id
        for protein_id
        in protein_order
        if protein_id not in covered_by_any
    ]

    audit_rows = []

    reused_previous_rows = []

    for protein_id in protein_order:
        structure = protein_by_id[
            protein_id
        ]

        original_ids = original_protein_to_dna.get(
            protein_id,
            [],
        )

        previous_ids = previous_protein_to_dna.get(
            protein_id,
            [],
        )

        if (
            original_ids
            and previous_ids
        ):
            status = "covered_original_and_previous"

        elif original_ids:
            status = "covered_original_SARG_DNA"

        elif previous_ids:
            status = "covered_previous_ge3_DNA"

        else:
            status = "TRULY_MISSING_NEEDS_NCBI"

        audit_rows.append(
            {
                "protein_id":
                    protein_id,

                "Type":
                    str(
                        structure[
                            "Type"
                        ]
                    ).strip(),

                "Subtype":
                    str(
                        structure[
                            "Subtype"
                        ]
                    ).strip(),

                "original_SARG_DNA_available":
                    "Yes"
                    if original_ids
                    else "No",

                "original_SARG_DNA_count":
                    len(
                        original_ids
                    ),

                "original_SARG_NucleotideIDs":
                    ";".join(
                        original_ids
                    ),

                "previous_ge3_DNA_available":
                    "Yes"
                    if previous_ids
                    else "No",

                "previous_ge3_DNA_count":
                    len(
                        previous_ids
                    ),

                "previous_ge3_DNA_ids":
                    ";".join(
                        previous_ids
                    ),

                "combined_DNA_available":
                    "Yes"
                    if (
                        original_ids
                        or previous_ids
                    )
                    else "No",

                "coverage_status":
                    status,
            }
        )

        if previous_ids:
            reused_previous_rows.append(
                {
                    "protein_id":
                        protein_id,

                    "Type":
                        str(
                            structure[
                                "Type"
                            ]
                        ).strip(),

                    "Subtype":
                        str(
                            structure[
                                "Subtype"
                            ]
                        ).strip(),

                    "previous_DNA_ids":
                        ";".join(
                            previous_ids
                        ),

                    "also_has_original_SARG_DNA":
                        "Yes"
                        if original_ids
                        else "No",
                }
            )

    # ------------------------------------------------------------------
    # Per-subtype summary.
    # ------------------------------------------------------------------

    subtype_rows = []

    for subtype, protein_ids in subtype_to_proteins.items():
        original_ids = [
            protein_id
            for protein_id
            in protein_ids
            if protein_id
            in proteins_with_original_dna
        ]

        previous_ids = [
            protein_id
            for protein_id
            in protein_ids
            if protein_id
            in proteins_with_previous_dna
        ]

        combined_ids = [
            protein_id
            for protein_id
            in protein_ids
            if protein_id
            in covered_by_any
        ]

        missing_ids = [
            protein_id
            for protein_id
            in protein_ids
            if protein_id
            not in covered_by_any
        ]

        subtype_rows.append(
            {
                "Type":
                    subtype_to_type[
                        subtype
                    ],

                "Subtype":
                    subtype,

                "total_proteins":
                    len(
                        protein_ids
                    ),

                "proteins_with_original_SARG_DNA":
                    len(
                        original_ids
                    ),

                "proteins_with_previous_ge3_DNA":
                    len(
                        previous_ids
                    ),

                "proteins_with_any_existing_DNA":
                    len(
                        combined_ids
                    ),

                "proteins_truly_missing_DNA":
                    len(
                        missing_ids
                    ),

                "existing_DNA_coverage_percent":
                    (
                        100.0
                        * len(
                            combined_ids
                        )
                        / len(
                            protein_ids
                        )
                    ),

                "missing_protein_ids":
                    ";".join(
                        missing_ids
                    ),
            }
        )

    subtype_rows.sort(
        key=lambda row: (
            row[
                "total_proteins"
            ],
            row[
                "Type"
            ],
            row[
                "Subtype"
            ],
        )
    )

    # ------------------------------------------------------------------
    # Write outputs.
    # ------------------------------------------------------------------

    write_csv(
        OUTPUT_DIR
        / "SARG_full_protein_DNA_coverage_audit.csv",
        [
            "protein_id",
            "Type",
            "Subtype",
            "original_SARG_DNA_available",
            "original_SARG_DNA_count",
            "original_SARG_NucleotideIDs",
            "previous_ge3_DNA_available",
            "previous_ge3_DNA_count",
            "previous_ge3_DNA_ids",
            "combined_DNA_available",
            "coverage_status",
        ],
        audit_rows,
    )

    missing_rows = []

    for protein_id in truly_missing_ids:
        structure = protein_by_id[
            protein_id
        ]

        missing_rows.append(
            {
                "protein_id":
                    protein_id,

                "Type":
                    str(
                        structure[
                            "Type"
                        ]
                    ).strip(),

                "Subtype":
                    str(
                        structure[
                            "Subtype"
                        ]
                    ).strip(),

                "reason":
                    (
                        "No DNA in original Nucleotide_SARG "
                        "and no DNA in previous all_arg_nonarg_dna"
                    ),
            }
        )

    write_csv(
        OUTPUT_DIR
        / "SARG_full_proteins_truly_missing_DNA.csv",
        [
            "protein_id",
            "Type",
            "Subtype",
            "reason",
        ],
        missing_rows,
    )

    with (
        OUTPUT_DIR
        / "SARG_full_proteins_truly_missing_DNA.fasta"
    ).open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as handle:
        for protein_id in truly_missing_ids:
            record = proteins[
                protein_id
            ]

            handle.write(
                f">{record['header']}\n"
                f"{wrap_sequence(record['sequence'])}\n"
            )

    write_csv(
        OUTPUT_DIR
        / "SARG_full_subtype_DNA_coverage_before_new_NCBI.csv",
        [
            "Type",
            "Subtype",
            "total_proteins",
            "proteins_with_original_SARG_DNA",
            "proteins_with_previous_ge3_DNA",
            "proteins_with_any_existing_DNA",
            "proteins_truly_missing_DNA",
            "existing_DNA_coverage_percent",
            "missing_protein_ids",
        ],
        subtype_rows,
    )

    write_csv(
        OUTPUT_DIR
        / "SARG_reused_previous_ge3_DNA_proteins.csv",
        [
            "protein_id",
            "Type",
            "Subtype",
            "previous_DNA_ids",
            "also_has_original_SARG_DNA",
        ],
        reused_previous_rows,
    )

    write_csv(
        OUTPUT_DIR
        / "SARG_previous_DNA_label_mismatches.csv",
        [
            "protein_id",
            "previous_DNA_id",
            "full_Type",
            "previous_Type",
            "full_Subtype",
            "previous_Subtype",
        ],
        previous_label_mismatches,
    )

    status_counts = Counter(
        row[
            "coverage_status"
        ]
        for row
        in audit_rows
    )

    subtype_size_distribution = Counter(
        len(
            protein_ids
        )
        for protein_ids
        in subtype_to_proteins.values()
    )

    summary_lines = [
        "subtype_filter_applied\tFalse",

        f"full_SARG_proteins\t"
        f"{len(protein_order)}",

        f"full_SARG_subtypes\t"
        f"{len(subtype_to_proteins)}",

        f"original_SARG_DNA_records\t"
        f"{len(original_dna_records)}",

        f"previous_all_arg_nonarg_DNA_records\t"
        f"{len(previous_dna_records)}",

        f"proteins_with_original_SARG_DNA\t"
        f"{len(proteins_with_original_dna)}",

        f"proteins_with_previous_ge3_DNA\t"
        f"{len(proteins_with_previous_dna)}",

        f"proteins_with_any_existing_DNA\t"
        f"{len(covered_by_any)}",

        f"proteins_truly_missing_DNA\t"
        f"{len(truly_missing_ids)}",

        f"existing_DNA_coverage_percent\t"
        f"{100.0*len(covered_by_any)/len(protein_order):.4f}",

        f"previous_DNA_label_mismatches\t"
        f"{len(previous_label_mismatches)}",
    ]

    for status, count in sorted(
        status_counts.items()
    ):
        summary_lines.append(
            f"coverage_status::{status}\t{count}"
        )

    for subtype_size, count in sorted(
        subtype_size_distribution.items()
    ):
        summary_lines.append(
            f"subtype_size::{subtype_size}_proteins\t{count}"
        )

    summary_path = (
        OUTPUT_DIR
        / "SARG_full_DNA_check_summary.txt"
    )

    summary_path.write_text(
        "\n".join(
            summary_lines
        )
        + "\n",
        encoding="utf-8",
    )

    print()
    print(
        "=" * 110,
        flush=True,
    )

    print(
        "STEP 1 COMPLETED",
        flush=True,
    )

    print(
        "=" * 110,
        flush=True,
    )

    print(
        f"Full SARG proteins              : {len(protein_order):,}",
        flush=True,
    )

    print(
        f"Full SARG subtypes              : {len(subtype_to_proteins):,}",
        flush=True,
    )

    print(
        f"Proteins with original DNA      : {len(proteins_with_original_dna):,}",
        flush=True,
    )

    print(
        f"Proteins reused from old >=3 DNA: {len(proteins_with_previous_dna):,}",
        flush=True,
    )

    print(
        f"Proteins with ANY existing DNA  : {len(covered_by_any):,}",
        flush=True,
    )

    print(
        f"TRULY missing, need NCBI        : {len(truly_missing_ids):,}",
        flush=True,
    )

    print(
        f"Existing DNA coverage           : "
        f"{100.0*len(covered_by_any)/len(protein_order):.4f}%",
        flush=True,
    )

    print(
        f"Previous-label mismatches        : "
        f"{len(previous_label_mismatches):,}",
        flush=True,
    )

    print()
    print(
        "NCBI download input:",
        flush=True,
    )

    print(
        OUTPUT_DIR
        / "SARG_full_proteins_truly_missing_DNA.fasta",
        flush=True,
    )

    print(
        OUTPUT_DIR
        / "SARG_full_proteins_truly_missing_DNA.csv",
        flush=True,
    )


if __name__ == "__main__":
    main()
