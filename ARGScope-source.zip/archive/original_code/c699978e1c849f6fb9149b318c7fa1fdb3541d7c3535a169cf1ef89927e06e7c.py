#!/usr/bin/env python3
"""Source-backed static figure; no fitted models, fake values or significance.

Run analyze_fragment_results.py first. Main comparison panels are explicitly
reported summaries, not matched-test benchmarks. Exploratory panels use only
the verified ARGScope cohort. Missing source scores are not measured zeros.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, PathPatch, Patch
from matplotlib.path import Path as MPath
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.ticker import FormatStrFormatter
from matplotlib.text import Text

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
FIG = ROOT / 'figures'
PCTS = [60,70,80,90]
METRICS = ['Accuracy','Precision','Recall','F1','MCC']
MODELS = {'protein':['ARGNet','DeepARG','PLM-ARG','FunGeneTyper','ARGScope'], 'dna':['ARGNet','DeepARG','ARGScope']}
COLORS = {'ARGNet':'#89949E', 'DeepARG':'#8472B0', 'PLM-ARG':'#BDA364', 'FunGeneTyper':'#64A598', 'ARGScope':'#CF4877'}
MODCOL = {'protein':'#2D799D','dna':'#D58448'}
FEATS = ['Protein_length','Training_support','protein_ARG_confidence','protein_subtype_confidence','dna_ARG_confidence','dna_subtype_confidence']
SHORT = ['Length','Train n','AA ARG','AA subtype','NT ARG','NT subtype']
LONG = ['Protein length','Subtype train count','Protein ARG confidence','Protein subtype confidence','DNA ARG confidence','DNA subtype confidence']
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':7,'axes.titlesize':8,
                     'xtick.labelsize':6.5,'ytick.labelsize':6.5,'axes.linewidth':.6,
                     'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                     'savefig.facecolor':'white','axes.spines.top':False,'axes.spines.right':False})
mapping = pd.read_csv(DATA/'type_display_mapping.csv')
ORDER = mapping.Type.tolist()
DISPLAY = dict(zip(mapping.Type,mapping.Display))
overall = pd.read_csv(DATA/'reported_overall_NOT_matched.csv')
type_reported = pd.read_csv(DATA/'reported_per_type_NOT_matched.csv')
own_types = pd.read_csv(DATA/'ARGScope_per_type_five_metrics.csv')
stability = pd.read_csv(DATA/'five_fragment_stability.csv')
matrix = pd.read_csv(DATA/'feature_spearman_matrix.csv',index_col=0).loc[FEATS,FEATS]
links = pd.read_csv(DATA/'feature_robustness_links.csv')
exports = []
LAYOUT_QA = []


def canvas(w,h):
    return plt.figure(figsize=(w/25.4,h/25.4))


def ax_mm(fig, x, top, w, h):
    fw,fh = fig.get_size_inches()*25.4
    return fig.add_axes([x/fw,1-(top+h)/fh,w/fw,h/fh])


def text_mm(fig,x,top,txt,**kw):
    fw,fh = fig.get_size_inches()*25.4
    return fig.text(x/fw,1-top/fh,txt,**kw)


def save(fig,name):
    FIG.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    outside=[]
    for txt in fig.findobj(match=Text):
        if not txt.get_visible() or not txt.get_text().strip(): continue
        box=txt.get_window_extent(renderer)
        if box.width and box.height and (box.x0 < -.5 or box.y0 < -.5 or box.x1 > fig.bbox.width+.5 or box.y1 > fig.bbox.height+.5):
            outside.append(txt.get_text())
    LAYOUT_QA.append(dict(figure=name,visible_text_outside_canvas=outside))
    if outside: raise RuntimeError(f'Clipped text in {name}: {outside}')
    for ext in ['png','pdf','svg']:
        path=FIG/f'{name}.{ext}'
        fig.savefig(path,dpi=400 if 'main' in name else 450)
        exports.append(dict(file=path.name,width_mm=round(fig.get_figwidth()*25.4,2),height_mm=round(fig.get_figheight()*25.4,2)))
    if 'main' in name:
        fig.savefig(FIG/f'{name}_preview.png',dpi=140)
    plt.close(fig)


def clean(ax):
    ax.set_axisbelow(True)
    ax.grid(axis='y',color='#E8EBEE',linewidth=.5)
    ax.tick_params(length=2.5,width=.6)


def performance(ax,mod,metric,first=False):
    for model in MODELS[mod]:
        sub=overall[(overall.modality==mod)&(overall.Model==model)].sort_values('pct')
        ax.plot(sub.pct,sub[metric],color=COLORS[model],marker='o' if model=='ARGScope' else 's',
                ms=3.5 if model=='ARGScope' else 2.2,lw=1.6 if model=='ARGScope' else .85,
                ls='-' if model=='ARGScope' else '--',zorder=5 if model=='ARGScope' else 2)
    ax.set(ylim=(0,1.03),xlim=(58,92),xticks=PCTS,yticks=[0,.5,1])
    ax.set_xticklabels([f'{v}%' for v in PCTS])
    ax.set_title(metric,pad=4)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    if first: ax.set_ylabel('Score')
    clean(ax)


def table_for(mod,metric='Precision'):
    pieces=[]
    for pct in PCTS:
        v=type_reported[(type_reported.Modality==mod)&(type_reported.Completeness==pct)&(type_reported.Metric==metric)]
        pieces.append(v.pivot(index='Type',columns='Model',values='Value').reindex(index=ORDER,columns=MODELS[mod]).to_numpy())
    return np.concatenate(pieces,axis=1)


def heatmap(fig,mod,x,top,w,h,labels=True,annotate=False,metric='Precision',font=5.4):
    values=table_for(mod,metric)
    models=MODELS[mod]
    n=len(models)
    ax=ax_mm(fig,x,top,w,h)
    cmap=plt.get_cmap('Blues').copy(); cmap.set_bad('#ECEDEF')
    im=ax.imshow(np.ma.masked_invalid(values),aspect='auto',cmap=cmap,vmin=0,vmax=1,interpolation='none')
    ax.set_yticks(range(23),[DISPLAY[t] for t in ORDER] if labels else ['']*23)
    ax.set_xticks(range(4*n),models*4,rotation=60,ha='right',rotation_mode='anchor',fontsize=5.7)
    ax.tick_params(length=0,pad=2)
    for sp in ax.spines.values(): sp.set_visible(False)
    ax.set_xticks(np.arange(-.5,4*n,1),minor=True)
    ax.set_yticks(np.arange(-.5,23,1),minor=True)
    ax.grid(which='minor',color='white',lw=.35)
    ax.tick_params(which='minor',length=0)
    for v in np.arange(n-.5,4*n,n): ax.axvline(v,color='white',lw=2.1)
    for tick in ax.get_xticklabels():
        if tick.get_text()=='ARGScope': tick.set_color(COLORS['ARGScope']);tick.set_fontweight('bold')
    if annotate:
        for i in range(23):
            for j in range(4*n):
                val=values[i,j]
                ax.text(j,i,'—' if np.isnan(val) else f'{val:.4f}',fontsize=font,ha='center',va='center',color='white' if val>.58 else '#26313A')
    else:
        for i,j in zip(*np.where(np.isnan(values))):
            ax.text(j,i,'–',fontsize=5,ha='center',va='center',color='#7D8289')
    cell_h=h/23
    avg=ax_mm(fig,x,top-cell_h-3,w,cell_h)
    average=np.nanmean(values,axis=0)[None,:]
    avg.imshow(average,cmap=cmap,vmin=0,vmax=1,aspect='auto')
    avg.set_xticks([]);avg.set_yticks([0],['Average'] if labels else [''])
    avg.tick_params(length=0,pad=2)
    for sp in avg.spines.values():sp.set_visible(False)
    for j in range(4*n):
        if annotate: avg.text(j,0,f'{average[0,j]:.4f}',ha='center',va='center',fontsize=font,color='white' if average[0,j]>.58 else '#26313A')
    for v in np.arange(n-.5,4*n,n):avg.axvline(v,color='white',lw=2.1)
    for k,pct in enumerate(PCTS):
        avg.text((k+.5)*n-.5,-.95,f'{pct}%',ha='center',va='bottom',fontsize=7,clip_on=False)
    return im


def association(ax):
    """Mantel-inspired layout; actual statistic is descriptive Spearman rho."""
    cmap=plt.get_cmap('PRGn')
    norm=Normalize(-1,1)
    n=6
    for i in range(n):
        for j in range(i,n):
            ax.add_patch(Rectangle((j-.48,i-.48),.96,.96,facecolor='white',edgecolor='#C3C8CC',lw=.45))
            rho=float(matrix.iloc[i,j])
            size=.84*np.sqrt(abs(rho))
            ax.add_patch(Rectangle((j-size/2,i-size/2),size,size,facecolor=cmap(norm(rho)),edgecolor='none'))
    for j,name in enumerate(SHORT):
        ax.text(j,-.75,name,rotation=48,ha='left',va='bottom',fontsize=7.5)
        ax.text(5.75,j,name,ha='left',va='center',fontsize=7.4)
    # A small node on each diagonal cell anchors a measured feature.
    for j in range(n): ax.scatter(j,j,s=14,c='white',edgecolor='#4A5257',lw=.6,zorder=8)
    starts={'protein':(-3.6,2.9),'dna':(-2.9,5.6)}
    for mod,(sx,sy) in starts.items():
        for j,feat in enumerate(FEATS):
            row=links[(links.Outcome==f'{mod}_subtype_robustness')&(links.Feature==feat)].iloc[0]
            rho=row.Spearman_rho
            width=.45+2.5*abs(rho)
            # Curved edges remain outside the triangular cells, to avoid hiding values.
            verts=[(sx,sy),(sx+.8,sy+.75),(j-1.25,j+.5),(j-.08,j+.1)]
            ax.add_patch(PathPatch(MPath(verts,[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4]),
                                   facecolor='none',edgecolor=MODCOL[mod],lw=width,alpha=.70,
                                   ls='-' if rho>=0 else '--',zorder=3))
        ax.scatter(sx,sy,s=95,marker='D',facecolor=MODCOL[mod],edgecolor='white',lw=.75,zorder=9)
        ax.text(sx-.15,sy-.5,('Protein' if mod=='protein' else 'DNA')+'\nsubtype robustness',ha='center',va='bottom',fontsize=8,color=MODCOL[mod],fontweight='bold')
    for i,r in enumerate([.25,.50,.75]):
        y=7.1+i*.45
        ax.plot([-3.6,-2.8],[y,y],color='#485058',lw=.45+2.5*r)
        ax.text(-2.55,y,f'|ρ| = {r:.2f}',va='center',fontsize=6.7)
    ax.text(.15,6.8,'Links: mean subtype correctness over 20 fragments',fontsize=6.4,va='top')
    ax.text(.15,7.25,'2,287 ARG parents · descriptive Spearman ρ',fontsize=6.4,va='top')
    ax.text(.15,7.7,'No Mantel test or causal claim',fontsize=6.4,va='top',color='#5D6369')
    ax.set_xlim(-5.2,8.35);ax.set_ylim(8.8,-2.4);ax.set_aspect('equal');ax.axis('off')
    return ScalarMappable(norm=norm,cmap=cmap)


def boxes(ax):
    rng=np.random.default_rng(62)
    for mod,offset in [('protein',-.19),('dna',.19)]:
        seq=[]
        for pct in PCTS:
            v=own_types[(own_types.Modality==mod)&(own_types.Completeness==pct)].set_index('Type').loc[ORDER,'Precision'].to_numpy()
            seq.append(v)
        pos=np.arange(4)+offset
        bp=ax.boxplot(seq,positions=pos,widths=.30,patch_artist=True,showfliers=False,
                      boxprops={'lw':.6},whiskerprops={'lw':.6},capprops={'lw':.6},medianprops={'color':'#26313A','lw':1})
        for patch in bp['boxes']:patch.set_facecolor(MODCOL[mod]);patch.set_alpha(.36)
        for x,vals in zip(pos,seq):
            ax.scatter(x+rng.uniform(-.095,.095,len(vals)),vals,s=4.5,c=MODCOL[mod],alpha=.65,lw=0,zorder=3)
    ax.set(xticks=range(4),xticklabels=[f'{p}%' for p in PCTS],ylim=(-.03,1.05),yticks=[0,.5,1],ylabel='Type precision')
    ax.set_title('ARGScope · distribution across 23 Types',fontsize=8,pad=5)
    clean(ax)


def stable(ax,level='Subtype'):
    for mod in ['protein','dna']:
        d=stability[(stability.Modality==mod)&(stability.Level==level)].sort_values('Completeness')
        ax.errorbar(d.Completeness,d.All_five_correct,yerr=[d.All_five_correct-d.CI_low,d.CI_high-d.All_five_correct],
                    color=MODCOL[mod],marker='o',ms=3,lw=1.4,capsize=2,elinewidth=.8,label='Protein' if mod=='protein' else 'DNA')
    ax.set(xticks=PCTS,xticklabels=[f'{p}%' for p in PCTS],ylim=(0,1.03),yticks=[0,.5,1],ylabel='Fraction of ARG parents')
    ax.set_title(f'All 5 fragments correct · {level.lower()}',fontsize=8,pad=5)
    clean(ax)


def main_figure():
    fig=canvas(280,330)
    handles=[Line2D([0],[0],color=COLORS[m],lw=1.6 if m=='ARGScope' else 1,ls='-' if m=='ARGScope' else '--',marker='o',ms=3,label=m) for m in MODELS['protein']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.55,.997),ncol=5,frameon=False,fontsize=8,columnspacing=2.5)
    for mod,top in [('protein',20),('dna',60)]:
        for j,metric in enumerate(METRICS): performance(ax_mm(fig,18+j*52,top,44,27),mod,metric,j==0)
        text_mm(fig,4,top+13,'Protein' if mod=='protein' else 'DNA',rotation=90,ha='center',va='center',fontsize=10,fontweight='bold')
    text_mm(fig,144,96,'Reported Type-level summaries · test cohorts / aggregation not harmonized',ha='center',fontsize=7,color='#5C6168')
    text_mm(fig,106,104,'Protein · Type precision',ha='center',fontsize=9,fontweight='bold')
    text_mm(fig,224,104,'DNA · Type precision',ha='center',fontsize=9,fontweight='bold')
    heatmap(fig,'protein',40,122,132,80.5,True,False)
    im=heatmap(fig,'dna',184,122,79.2,80.5,False,False)
    cb=fig.colorbar(im,cax=ax_mm(fig,268,115.5,2.2,87));cb.ax.tick_params(labelsize=6,length=2);cb.set_ticks([0,.25,.5,.75,1])
    cb.ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    text_mm(fig,84,224,'Sequence features and truncation robustness',ha='center',fontsize=9,fontweight='bold')
    network=ax_mm(fig,3,226,166,101)
    sm=association(network)
    cb=fig.colorbar(sm,cax=ax_mm(fig,164,239,2.2,46));cb.set_ticks([-1,-.5,0,.5,1]);cb.ax.tick_params(labelsize=6,length=2);cb.set_label('Spearman ρ',fontsize=7)
    boxes(ax_mm(fig,193,237,76,31))
    fig.legend(handles=[Patch(facecolor=MODCOL[m],label='Protein' if m=='protein' else 'DNA',alpha=.6) for m in ['protein','dna']],
               loc='center',bbox_to_anchor=(.825,.156),ncol=2,frameon=False,fontsize=7)
    stable(ax_mm(fig,193,290,76,29))
    save(fig,'fragment_robustness_main')


def standalone():
    fig=canvas(198,136)
    sm=association(ax_mm(fig,4,2,166,124))
    cb=fig.colorbar(sm,cax=ax_mm(fig,178,24,2.8,55));cb.set_label('Spearman ρ');cb.set_ticks([-1,-.5,0,.5,1])
    save(fig,'association_network_Spearman_not_Mantel')
    for mod in ['protein','dna']:
        for metric in ['Precision','Recall','F1']:
            fig=canvas(241 if mod=='protein' else 184,141)
            w=180 if mod=='protein' else 123
            im=heatmap(fig,mod,40,23,w,91,True,True,metric,font=5.5 if mod=='protein' else 6)
            cb=fig.colorbar(im,cax=ax_mm(fig,224 if mod=='protein' else 167,16,2,98));cb.set_ticks([0,.5,1]);cb.ax.tick_params(labelsize=5)
            save(fig,f'{mod}_{metric.lower()}_all_23_types')
    fig=canvas(270,117)
    for mod,top in [('protein',19),('dna',69)]:
        for j,metric in enumerate(METRICS):performance(ax_mm(fig,18+j*50,top,42,31),mod,metric,j==0)
        text_mm(fig,4,top+14,mod.title() if mod=='protein' else 'DNA',rotation=90,fontsize=9,fontweight='bold',ha='center')
    fig.legend(handles=[Line2D([0],[0],color=COLORS[m],lw=1,ls='-' if m=='ARGScope' else '--',label=m) for m in MODELS['protein']],
               loc='upper center',ncol=5,frameon=False,bbox_to_anchor=(.55,1),fontsize=8)
    text_mm(fig,142,114,'Reported summaries; cohorts and metric aggregation are not harmonized',ha='center',fontsize=7,color='#5C6168')
    save(fig,'reported_model_comparison_five_metrics')
    fig=canvas(220,150)
    boxes(ax_mm(fig,17,13,88,45));stable(ax_mm(fig,129,13,81,45))
    errors=pd.read_csv(DATA/'error_decomposition.csv')
    colors=['#68A99C','#A9BCCB','#B69BC2','#D78274']
    categories=['Correct subtype','Wrong subtype, correct Type','Wrong Type','Missed ARG']
    for mod,x in [('protein',17),('dna',129)]:
        ax=ax_mm(fig,x,84,88 if mod=='protein' else 81,37)
        left=np.zeros(4)
        for cat,c in zip(categories,colors):
            d=errors[(errors.Modality==mod)&(errors.Category==cat)].set_index('Completeness').loc[PCTS]
            ax.barh(np.arange(4),d.Fraction,left=left,height=.65,color=c,edgecolor='white',lw=.4)
            left+=d.Fraction.to_numpy()
        ax.set(yticks=range(4),yticklabels=[f'{p}%' for p in PCTS],xlim=(0,1),xticks=[0,.5,1],xlabel='Fraction of true ARG fragments')
        ax.invert_yaxis();ax.set_title('Protein' if mod=='protein' else 'DNA',loc='left',fontsize=9)
        clean(ax)
    fig.legend(handles=[Patch(facecolor=MODCOL[m],label='Protein' if m=='protein' else 'DNA',alpha=.6) for m in ['protein','dna']],
               loc='center',bbox_to_anchor=(.5,.52),ncol=2,frameon=False,fontsize=8)
    fig.legend(handles=[Patch(facecolor=c,label=cat) for c,cat in zip(colors,categories)],loc='lower center',ncol=2,frameon=False,fontsize=7,bbox_to_anchor=(.5,.01))
    save(fig,'ARGScope_robustness_and_error_decomposition')


def circular_alternative():
    """A circular heatmap, NOT a phylogenetic tree or inferred clustering."""
    fig=canvas(210,215)
    ax=fig.add_axes([.10,.13,.80,.80],projection='polar')
    ax.set_theta_zero_location('N');ax.set_theta_direction(-1)
    gap=np.deg2rad(34)
    width=(2*np.pi-gap)/23
    angles=gap/2+width*(np.arange(23)+.5)
    cmap=plt.get_cmap('Blues')
    radii=[]
    for k,(mod,pct) in enumerate([(m,p) for m in ['protein','dna'] for p in PCTS]):
        bottom=.59+k*.098+(.045 if k>=4 else 0)
        radii.append(bottom+.046)
        vals=own_types[(own_types.Modality==mod)&(own_types.Completeness==pct)].set_index('Type').loc[ORDER,'Precision']
        ax.bar(angles,np.full(23,.092),width=width*.975,bottom=bottom,color=cmap(vals.to_numpy()),edgecolor='white',lw=.2)
        ax.text(0,bottom+.046,f'{pct}%',ha='center',va='center',fontsize=6.4,color=MODCOL[mod])
    ax.set_ylim(0,2.05);ax.set_axis_off()
    for angle,typ in zip(angles,ORDER):
        deg=np.degrees(angle)
        rotation=90-deg
        align='left'
        if 180<deg<360:
            rotation+=180
            align='right'
        ax.text(angle,1.45,DISPLAY[typ],ha=align,va='center',rotation=rotation,rotation_mode='anchor',fontsize=7)
    ax.text(.5,.54,'ARGScope',transform=ax.transAxes,ha='center',va='center',fontsize=12,fontweight='bold',color=COLORS['ARGScope'])
    ax.text(.5,.48,'Type precision',transform=ax.transAxes,ha='center',va='center',fontsize=9)
    ax.text(.5,.43,'60–90% completeness',transform=ax.transAxes,ha='center',va='center',fontsize=7.5)
    cb=fig.colorbar(ScalarMappable(norm=Normalize(0,1),cmap=cmap),cax=ax_mm(fig,66,197,78,2.8),orientation='horizontal')
    cb.set_ticks([0,.25,.5,.75,1]);cb.ax.tick_params(labelsize=7,length=2)
    text_mm(fig,105,185,'Inner four rings: Protein     Outer four rings: DNA',ha='center',fontsize=8)
    save(fig,'ARGScope_circular_type_precision_alternative')


if __name__=='__main__':
    main_figure()
    standalone()
    circular_alternative()
    (ROOT/'figure_manifest.json').write_text(json.dumps(exports,indent=2),encoding='utf-8')
    (ROOT/'layout_validation.json').write_text(json.dumps(LAYOUT_QA,indent=2),encoding='utf-8')
    print(f'Saved {len(exports)//3} figure designs in PNG / SVG / PDF to {FIG}')
