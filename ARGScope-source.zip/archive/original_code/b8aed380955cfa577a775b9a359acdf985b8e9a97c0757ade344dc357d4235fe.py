import csv
import random

# ===== 输入 =====
bgc_protein_fasta = "mibig_final_protein.fasta"
bgc_dna_fasta = "mibig_final_dna.fasta"
bgc_csv = "mibig_final_annotation.csv"

non_bgc_csv = "merged_shared_mapping_excludeMIBIG.csv"

# ===== 输出 =====
out_protein = "merged_protein.fasta"
out_dna = "merged_dna.fasta"
out_csv = "merged_annotation.csv"


# ===== Step 1: 读取 BGC annotation =====
bgc_ids = []
bgc_map = {}

with open(bgc_csv) as f:
    reader = csv.DictReader(f)
    for row in reader:
        pid = row["ID"]
        bgc_ids.append(pid)
        bgc_map[pid] = (row["type"], row["subtype"])

bgc_count = len(bgc_ids)
print("BGC数量:", bgc_count)


# ===== Step 2: 读取 non-BGC 数据 =====
non_bgc_data = []

with open(non_bgc_csv) as f:
    reader = csv.DictReader(f)
    for row in reader:
        non_bgc_data.append(row)

print("non-BGC总数:", len(non_bgc_data))


# ===== Step 3: 随机采样 =====
sampled_non_bgc = random.sample(non_bgc_data, bgc_count)


# ===== Step 4: 写合并 protein & DNA =====
with open(out_protein, "w") as f_prot, open(out_dna, "w") as f_dna:

    # ===== 4.1 写 BGC =====
    def read_fasta(path):
        data = {}
        with open(path) as f:
            pid = ""
            seq = ""
            for line in f:
                line = line.strip()
                if line.startswith(">"):
                    if pid:
                        data[pid] = seq
                    pid = line[1:]
                    seq = ""
                else:
                    seq += line
            if pid:
                data[pid] = seq
        return data

    bgc_prot_dict = read_fasta(bgc_protein_fasta)
    bgc_dna_dict = read_fasta(bgc_dna_fasta)

    for pid in bgc_ids:
        f_prot.write(f">{pid}\n{bgc_prot_dict[pid]}\n")
        f_dna.write(f">{pid}\n{bgc_dna_dict[pid]}\n")

    # ===== 4.2 写 non-BGC =====
    for row in sampled_non_bgc:
        pid = row["protein_id"]

        prot_seq = row["protein_sequence"]
        dna_seq = row["dna_sequence"]

        f_prot.write(f">{pid}\n{prot_seq}\n")
        f_dna.write(f">{pid}\n{dna_seq}\n")


# ===== Step 5: 写 annotation =====
with open(out_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["ID", "type", "subtype"])

    # BGC
    for pid in bgc_ids:
        t, st = bgc_map[pid]
        writer.writerow([pid, t, st])

    # non-BGC
    for row in sampled_non_bgc:
        pid = row["protein_id"]
        writer.writerow([pid, "nonBGC", "nonBGC"])


# ===== Step 6: 检查 =====
print("\n===== 检查 =====")
print("BGC:", bgc_count)
print("non-BGC采样:", len(sampled_non_bgc))
print("总数:", bgc_count * 2)