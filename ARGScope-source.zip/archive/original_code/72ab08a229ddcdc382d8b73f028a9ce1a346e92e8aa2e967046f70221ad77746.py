import os
import re
import json
import glob
from pathlib import Path
from collections import Counter

import pandas as pd
from Bio import SeqIO


# ==========================================================
# 1. 路径设置
# ==========================================================

BASE_DIR = Path(r"E:\1. ARG模型对比\BGC数据处理")

BGC_DATA_DIR = BASE_DIR / "BGC数据"
GBK_DIR = BASE_DIR / "mibig_gbk_4.0"
JSON_DIR = BASE_DIR / "mibig_json_4.0"

OUT_CSV = BGC_DATA_DIR / "mibig_bgc_id_type_subtype_fixed.csv"


# ==========================================================
# 2. 基础函数
# ==========================================================

def normalize_text(x):
    if x is None:
        return ""

    if isinstance(x, list):
        x = ";".join([str(i) for i in x])

    x = str(x).strip()

    if x.lower() in {"", "none", "nan", "null", "unknown"}:
        return ""

    return x


def normalize_type(raw_type):
    x = normalize_text(raw_type)

    if x == "":
        return ""

    x_low = x.lower()

    # 多类混合
    hybrid_keys = [
        "hybrid",
        "nrps-pks",
        "pks-nrps",
        "nrp-pks",
        "pks-nrp",
        "nrps/ripp",
        "nrps-ripp",
        "pks-ripp",
        "pks-saccharide",
        "nrps-saccharide",
        "polyketide-nrp",
        "polyketide-nrps",
    ]

    if any(k in x_low for k in hybrid_keys):
        return "Hybrid"

    if "ripp" in x_low:
        return "RiPP"

    if "nrps" in x_low or "nrp" in x_low or "nonribosomal" in x_low:
        return "NRPS"

    if "pks" in x_low or "polyketide" in x_low:
        return "PKS"

    if "terpene" in x_low or "terpenoid" in x_low:
        return "Terpene"

    if "saccharide" in x_low or "glycan" in x_low or "polysaccharide" in x_low:
        return "Saccharide"

    if "alkaloid" in x_low:
        return "Alkaloid"

    if "other" in x_low:
        return "Other"

    return x


def normalize_subtype(raw_subtype):
    x = normalize_text(raw_subtype)

    if x == "":
        return ""

    x = x.replace("_", "-")
    x = re.sub(r"\s+", " ", x).strip()

    return x


def get_bgc_id_from_filename(path):
    name = os.path.basename(str(path))
    m = re.search(r"(BGC\d{7})", name)

    if m:
        return m.group(1)

    return None


def build_file_index(folder, suffix):
    files = glob.glob(str(folder / f"*.{suffix}"))

    index = {}

    for fp in files:
        bgc_id = get_bgc_id_from_filename(fp)

        if bgc_id:
            index[bgc_id] = fp

    return index


# ==========================================================
# 3. JSON 递归搜索
# ==========================================================

def iter_json_paths(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k), v

            for sub_k, sub_v in iter_json_paths(v):
                yield f"{k}.{sub_k}", sub_v

    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield f"[{i}]", v

            for sub_k, sub_v in iter_json_paths(v):
                yield f"[{i}].{sub_k}", sub_v


def collect_json_values_by_keywords(data, keywords):
    values = []

    for path, value in iter_json_paths(data):
        key = path.split(".")[-1].lower()

        if any(k in key for k in keywords):
            if isinstance(value, str):
                values.append(value)

            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, str):
                        values.append(item)
                    elif isinstance(item, dict):
                        for _, sub_v in iter_json_paths(item):
                            if isinstance(sub_v, str):
                                values.append(sub_v)

            elif isinstance(value, dict):
                for _, sub_v in iter_json_paths(value):
                    if isinstance(sub_v, str):
                        values.append(sub_v)

    values = [normalize_text(v) for v in values]
    values = [v for v in values if v]

    return values


# ==========================================================
# 4. 从 JSON 提取 type / subtype
# ==========================================================

def extract_from_json(json_file):
    try:
        with open(json_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    except UnicodeDecodeError:
        with open(json_file, "r", encoding="latin1") as f:
            data = json.load(f)
    except Exception:
        return "", ""

    type_candidates = []
    subtype_candidates = []

    # 常见 type 字段
    type_candidates.extend(
        collect_json_values_by_keywords(
            data,
            keywords=[
                "biosyn-class",
                "biosyn_class",
                "biosynthetic-class",
                "biosynthetic_class",
                "product-type",
                "product_type",
                "product-types",
                "product_types",
                "class",
                "type",
            ]
        )
    )

    # 常见 subtype / product 字段
    subtype_candidates.extend(
        collect_json_values_by_keywords(
            data,
            keywords=[
                "subtype",
                "subclass",
                "chemical-subclass",
                "chemical_subclass",
                "product",
                "compound",
                "name",
            ]
        )
    )

    # 清理 subtype 候选，去掉明显不是分类的信息
    bad_words = [
        "mibig",
        "accession",
        "submitter",
        "publication",
        "evidence",
        "ncbi",
        "genbank",
        "organism",
        "locus",
        "sequence",
        "doi",
        "pubmed",
    ]

    subtype_candidates = [
        x for x in subtype_candidates
        if not any(b in x.lower() for b in bad_words)
    ]

    # type 决策
    norm_types = [normalize_type(x) for x in type_candidates]
    norm_types = [x for x in norm_types if x]

    if len(set(norm_types)) >= 2:
        type_final = "Hybrid"
    elif len(norm_types) == 1:
        type_final = norm_types[0]
    elif len(norm_types) > 1:
        type_final = Counter(norm_types).most_common(1)[0][0]
    else:
        type_final = ""

    # subtype 决策
    norm_subtypes = [normalize_subtype(x) for x in subtype_candidates]
    norm_subtypes = [x for x in norm_subtypes if x]

    if len(norm_subtypes) > 0:
        count = Counter(norm_subtypes)
        max_count = max(count.values())
        top = [k for k, v in count.items() if v == max_count]
        top = sorted(top, key=lambda x: (len(x), x))
        subtype_final = top[0]
    else:
        subtype_final = ""

    return type_final, subtype_final


# ==========================================================
# 5. 从 GBK 兜底提取 type / subtype
# ==========================================================

def extract_from_gbk(gbk_file):
    try:
        records = list(SeqIO.parse(str(gbk_file), "genbank"))
    except Exception:
        return "", ""

    text_chunks = []

    for record in records:
        text_chunks.append(str(record.description))

        for k, v in record.annotations.items():
            if isinstance(v, str):
                text_chunks.append(v)
            elif isinstance(v, list):
                text_chunks.extend([str(i) for i in v])

        for feature in record.features:
            for k, values in feature.qualifiers.items():
                for v in values:
                    text_chunks.append(str(v))

    text = " ; ".join(text_chunks)
    text_low = text.lower()

    detected_types = []

    if any(k in text_low for k in ["nrps", "nonribosomal", "nrp"]):
        detected_types.append("NRPS")

    if any(k in text_low for k in ["pks", "polyketide"]):
        detected_types.append("PKS")

    if "ripp" in text_low:
        detected_types.append("RiPP")

    if any(k in text_low for k in ["terpene", "terpenoid"]):
        detected_types.append("Terpene")

    if any(k in text_low for k in ["saccharide", "glycan", "polysaccharide"]):
        detected_types.append("Saccharide")

    if "alkaloid" in text_low:
        detected_types.append("Alkaloid")

    detected_types = list(set(detected_types))

    if len(detected_types) >= 2:
        type_final = "Hybrid"
    elif len(detected_types) == 1:
        type_final = detected_types[0]
    else:
        type_final = ""

    subtype_patterns = [
        "lanthipeptide",
        "lasso peptide",
        "cyanobactin",
        "thiopeptide",
        "siderophore",
        "terpene",
        "meroterpenoid",
        "glycopeptide",
        "lipopeptide",
        "nucleoside",
        "phenazine",
        "polysaccharide",
        "T1PKS",
        "T2PKS",
        "T3PKS",
        "transAT-PKS",
        "PKS-NRPS",
        "PKS-RiPP",
        "NRPS-RiPP",
        "NRPS",
        "PKS",
    ]

    subtype_final = ""

    for subtype in subtype_patterns:
        if subtype.lower() in text_low:
            subtype_final = subtype
            break

    return type_final, subtype_final


# ==========================================================
# 6. 强制一个 subtype 只对应一个 type
# ==========================================================

def enforce_one_type_per_subtype(df):
    """
    如果同一个 subtype 对应多个 type:
    只保留该 subtype 下数量最多的 type。
    """

    valid_df = df[
        (df["type"].astype(str).str.strip() != "")
        & (df["subtype"].astype(str).str.strip() != "")
    ].copy()

    count_table = (
        valid_df
        .groupby(["subtype", "type"])
        .size()
        .reset_index(name="count")
        .sort_values(["subtype", "count", "type"], ascending=[True, False, True])
    )

    dominant_map = (
        count_table
        .drop_duplicates(subset=["subtype"], keep="first")
        [["subtype", "type"]]
        .rename(columns={"type": "dominant_type"})
    )

    fixed_df = valid_df.merge(dominant_map, on="subtype", how="left")

    fixed_df = fixed_df[
        fixed_df["type"] == fixed_df["dominant_type"]
    ].copy()

    fixed_df = fixed_df[["id", "type", "subtype"]].copy()

    return fixed_df


# ==========================================================
# 7. 主程序
# ==========================================================

def main():
    print("Checking folders...")

    print("GBK_DIR:", GBK_DIR, "exists:", GBK_DIR.exists())
    print("JSON_DIR:", JSON_DIR, "exists:", JSON_DIR.exists())
    print("BGC_DATA_DIR:", BGC_DATA_DIR, "exists:", BGC_DATA_DIR.exists())

    if not GBK_DIR.exists():
        raise FileNotFoundError(f"GBK_DIR 不存在: {GBK_DIR}")

    if not JSON_DIR.exists():
        raise FileNotFoundError(f"JSON_DIR 不存在: {JSON_DIR}")

    BGC_DATA_DIR.mkdir(parents=True, exist_ok=True)

    print("\nBuilding file indexes...")

    gbk_index = build_file_index(GBK_DIR, "gbk")
    json_index = build_file_index(JSON_DIR, "json")

    print("GBK files:", len(gbk_index))
    print("JSON files:", len(json_index))

    all_ids = sorted(set(gbk_index.keys()) | set(json_index.keys()))

    print("Total BGC IDs:", len(all_ids))

    rows = []

    for i, bgc_id in enumerate(all_ids, 1):
        json_file = json_index.get(bgc_id, "")
        gbk_file = gbk_index.get(bgc_id, "")

        type_final = ""
        subtype_final = ""

        # 优先 JSON
        if json_file:
            type_final, subtype_final = extract_from_json(json_file)

        # JSON 不完整时，用 GBK 兜底
        if (type_final == "" or subtype_final == "") and gbk_file:
            gbk_type, gbk_subtype = extract_from_gbk(gbk_file)

            if type_final == "" and gbk_type != "":
                type_final = gbk_type

            if subtype_final == "" and gbk_subtype != "":
                subtype_final = gbk_subtype

        rows.append({
            "id": bgc_id,
            "type": normalize_type(type_final),
            "subtype": normalize_subtype(subtype_final),
        })

        if i % 1000 == 0:
            print(f"Processed {i}/{len(all_ids)}")

    df = pd.DataFrame(rows)

    # 删除 type 或 subtype 缺失的记录
    df = df[
        (df["type"].astype(str).str.strip() != "")
        & (df["subtype"].astype(str).str.strip() != "")
    ].copy()

    # 强制一个 subtype 只对应一个 type
    df_fixed = enforce_one_type_per_subtype(df)

    # 按 id 排序
    df_fixed = df_fixed.sort_values("id").reset_index(drop=True)

    # 保存最终文件，只包含 id,type,subtype
    df_fixed.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")

    print("\nDone.")
    print("Final records:", len(df_fixed))
    print("Unique type:", df_fixed["type"].nunique())
    print("Unique subtype:", df_fixed["subtype"].nunique())
    print("Saved to:", OUT_CSV)

    # 最后再验证 subtype 是否只对应一个 type
    check = (
        df_fixed.groupby("subtype")["type"]
        .nunique()
        .reset_index(name="type_count")
    )

    bad = check[check["type_count"] > 1]

    if len(bad) == 0:
        print("Check passed: each subtype corresponds to only one type.")
    else:
        print("Warning: some subtypes still correspond to multiple types:")
        print(bad)


if __name__ == "__main__":
    main()