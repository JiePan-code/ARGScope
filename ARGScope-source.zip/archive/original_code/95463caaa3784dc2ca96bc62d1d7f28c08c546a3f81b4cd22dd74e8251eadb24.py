"""Figure 4E: orange row-normalized matrix rebuilt from original DNA predictions.

The prediction CSV and all reference files are read-only. Counts are checked
against the original 24-class count matrix, and row proportions against the
original normalized matrix. No classes, samples or errors are removed.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

FIGURE_ROOT = Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\结果图\SVG素材")
RUNTIME = FIGURE_ROOT / "Figure3_Figure4_type_heatmaps_20261013" / ".build" / "plot_runtime"
sys.path.insert(0, str(RUNTIME))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import PercentFormatter
import numpy as np

PREDICTIONS = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ARGScope_80_20_results\apply_argscope_protein_and_DNA\dna\100%_test_sequence_predictions.csv")
REFERENCE_ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW\Including_nonARG_20260922\Figure2_Figure3_SVG\plot_data\DNA")
COUNT_SOURCE = REFERENCE_ROOT / "E_full_24class_confusion_counts.csv"
NORMALIZED_SOURCE = REFERENCE_ROOT / "E_row_normalized_24classes.csv"
DEST = FIGURE_ROOT / "Figure4E_confusion_orange_20261013"
BUILD = DEST / ".build"
STEM = "Figure4E_DNA_row_normalized_confusion_orange_larger"

LABELS = [
    "beta_lactam", "trimethoprim", "macrolide-lincosamide-streptogramin",
    "fusidic_acid", "fosfomycin", "aminoglycoside", "quinolone", "multidrug",
    "vancomycin", "chloramphenicol", "florfenicol", "rifamycin", "tetracycline",
    "other_peptide_antibiotics", "bacitracin", "sulfonamide", "tetracenomycin_C",
    "novobiocin", "tunicamycin", "streptothricin", "polymyxin", "bleomycin",
    "puromycin", "nonARG",
]
DISPLAY = [
    "Beta-lactams", "Trimethoprim", "MLS", "Fusidic acid", "Fosfomycin",
    "Aminoglycosides", "Quinolones", "Multidrug", "Vancomycin", "Chloramphenicol",
    "Florfenicol", "Rifamycin", "Tetracyclines", "Other peptides", "Bacitracin",
    "Sulfonamide", "Tetracenomycin C", "Novobiocin", "Tunicamycin", "Streptothricin",
    "Polymyxin", "Bleomycin", "Puromycin", "Non-ARG",
]
ORANGE = LinearSegmentedColormap.from_list(
    "ARGScope_single_orange",
    ["#fff8f1", "#fde8d0", "#fbd2a5", "#f9b36f", "#f79343", "#de7024", "#a94d0a"],
    N=1024,
)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_matrix(path: Path, dtype) -> np.ndarray:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle))
    assert rows[0][1:] == LABELS, ("column order differs", path)
    assert [row[0] for row in rows[1:]] == LABELS, ("row order differs", path)
    matrix = np.asarray([row[1:] for row in rows[1:]], dtype=dtype)
    assert matrix.shape == (24, 24)
    return matrix


def write_matrix(path: Path, values: np.ndarray) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["true_type"] + LABELS)
        for label, row in zip(LABELS, values):
            writer.writerow([label] + row.tolist())


def main() -> None:
    DEST.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(exist_ok=True)
    source_hashes = {str(path): sha(path) for path in (PREDICTIONS, COUNT_SOURCE, NORMALIZED_SOURCE)}
    rows = read_rows(PREDICTIONS)
    counts = np.zeros((24, 24), dtype=np.int64)
    index = {label: i for i, label in enumerate(LABELS)}
    identifiers = set()
    for row in rows:
        assert row["split"] == "test" and row["sequence_level"] == "full_length"
        assert float(row["completeness_percent"]) == 100
        assert row["sequence_id"] not in identifiers, "Duplicate sequence in original test predictions"
        identifiers.add(row["sequence_id"])
        counts[index[row["true_type"]], index[row["predicted_type"]]] += 1
    assert len(rows) == counts.sum() == 4574
    np.testing.assert_array_equal(counts, read_matrix(COUNT_SOURCE, np.int64))
    support = counts.sum(axis=1)
    proportions = np.divide(
        counts, support[:, None], out=np.zeros((24, 24), dtype=float),
        where=support[:, None] != 0,
    )
    np.testing.assert_allclose(proportions, read_matrix(NORMALIZED_SOURCE, float), rtol=0, atol=1e-14)
    np.testing.assert_allclose(proportions.sum(axis=1), (support > 0).astype(float), rtol=0, atol=1e-14)

    font_manager.findfont("Arial", fallback_to_default=False)
    plt.rcParams.update({
        "font.family": "Arial", "svg.fonttype": "none", "pdf.fonttype": 42,
        "font.weight": "normal", "axes.titleweight": "normal", "axes.labelweight": "normal",
        "text.color": "#17232d", "axes.labelcolor": "#17232d",
        "xtick.color": "#17232d", "ytick.color": "#17232d", "axes.unicode_minus": False,
    })
    side, left, bottom, top = 5.88, 2.95, .88, .54
    color_gap, color_w, right = .13, .13, .63
    width = left + side + color_gap + color_w + right
    height = bottom + side + top
    fig = plt.figure(figsize=(width, height), facecolor="none")
    ax = fig.add_axes([left / width, bottom / height, side / width, side / height])
    im = ax.pcolormesh(
        np.arange(25) - .5, np.arange(25) - .5, proportions,
        cmap=ORANGE, vmin=0, vmax=1, shading="flat", rasterized=False,
        linewidth=0, antialiased=False,
    )
    ax.set_xlim(-.5, 23.5)
    ax.set_ylim(23.5, -.5)
    ax.set_aspect("equal")
    ax.set_xticks(range(24), [str(i + 1) for i in range(24)], rotation=90, fontsize=14, fontweight="normal")
    ax.set_yticks(range(24), [f"{i + 1}  {name}" for i, name in enumerate(DISPLAY)], fontsize=15, fontweight="normal")
    ax.tick_params(length=2.5, width=.6, pad=3)
    ax.set_xlabel("Predicted type (1–24, as listed on the y-axis)", fontsize=16, fontweight="normal", labelpad=7)
    ax.set_ylabel("True type", fontsize=17, fontweight="normal", labelpad=7)
    ax.set_title("Row-normalized confusion matrix", fontsize=18, fontweight="normal", pad=10)
    for spine in ax.spines.values():
        spine.set_linewidth(.6)
        spine.set_color("#899198")

    cax = fig.add_axes([(left + side + color_gap) / width, bottom / height, color_w / width, side / height])
    cb = fig.colorbar(im, cax=cax, ticks=[0, .25, .5, .75, 1])
    cb.ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
    cb.ax.tick_params(labelsize=13.5, length=2.5, width=.6, pad=4)
    for label in cb.ax.get_yticklabels():
        label.set_fontweight("normal")
    cb.outline.set_linewidth(.6)
    cb.outline.set_edgecolor("#899198")
    cb.solids.set_rasterized(False)

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    boxes = [text.get_window_extent(renderer) for text in ax.get_yticklabels()]
    for upper, lower in zip(boxes, boxes[1:]):
        assert upper.y0 > lower.y1, "Neighboring category labels overlap"
    all_labels = ax.get_xticklabels() + ax.get_yticklabels() + cb.ax.get_yticklabels()
    all_labels += [ax.title, ax.xaxis.label, ax.yaxis.label]
    assert all(text.get_fontweight() == "normal" for text in all_labels)
    svg = DEST / f"{STEM}.svg"
    png = BUILD / f"{STEM}_preview.png"
    pdf = BUILD / f"{STEM}.pdf"
    options = {"bbox_inches": "tight", "pad_inches": .04}
    fig.savefig(svg, transparent=True, metadata={
        "Title": "ARGScope-NT: row-normalized resistance-type confusion matrix",
        "Description": "Rebuilt from 4574 original full-length test predictions. All 24 classes retained; linear 0-100 percent orange scale.",
    }, **options)
    fig.savefig(pdf, transparent=True, **options)
    fig.savefig(png, dpi=300, facecolor="white", transparent=False, **options)
    plt.close(fig)

    root = ET.parse(svg).getroot()
    namespace = {"svg": "http://www.w3.org/2000/svg"}
    assert not root.findall(".//svg:image", namespace), "SVG contains a raster image"
    texts = ["".join(item.itertext()) for item in root.findall(".//svg:text", namespace)]
    assert "Row-normalized confusion matrix" in texts
    assert all(f"{i + 1}  {name}" in texts for i, name in enumerate(DISPLAY))
    assert all(label in texts for label in ["0%", "25%", "50%", "75%", "100%"])
    assert "E" not in texts
    write_matrix(BUILD / "original_confusion_counts_verified.csv", counts)
    write_matrix(BUILD / "row_normalized_values_verified.csv", proportions)
    assert source_hashes == {str(path): sha(path) for path in (PREDICTIONS, COUNT_SOURCE, NORMALIZED_SOURCE)}
    audit = {
        "source_sha256": source_hashes, "n_test_sequences": len(rows), "n_classes": 24,
        "label_order": LABELS, "row_support": support.tolist(),
        "counts_rebuilt_from_original_prediction_file": True,
        "counts_equal_original_confusion_csv": True,
        "proportions_equal_original_row_normalized_csv": True,
        "row_normalization": "count / reference class support",
        "palette": "single orange; matches Figure 4C orange heatmap",
        "scale": "linear 0-100 percent", "font": "Arial",
        "font_weight": "normal",
        "font_sizes_pt": {"title": 18, "category_labels": 15, "x_ticks": 14, "colorbar_ticks": 13.5, "x_axis_label": 16, "y_axis_label": 17},
        "neighboring_category_labels_do_not_overlap": True,
        "editable_svg_text": True, "raster_images_embedded": 0,
        "transparent_svg_background": True, "panel_letter_omitted": True,
        "svg": str(svg), "preview": str(png), "pdf": str(pdf),
    }
    with (BUILD / f"{STEM}_verification.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, ensure_ascii=False, indent=2)
    print(f"Verified: {len(rows)} predictions, 24 classes, exact original counts and normalized values.")
    print(f"SVG: {svg.name}")


if __name__ == "__main__":
    main()
