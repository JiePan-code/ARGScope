"""Read-only XLSX verification against reviewed numeric export and source hashes."""
import hashlib
import json
import math
import ntpath
from pathlib import Path
import csv
import sys
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parent
books=json.loads((ROOT/'workbook_data.json').read_text(encoding='utf-8'))
columns={
 'Type bars':['Model','Completeness','N','Accuracy','Precision','Recall','F1','MCC','N_labels_averaged'],
 'Type averages':['Model','Completeness','Average','N','Accuracy','Precision','Recall','F1','MCC','N_labels_averaged'],
 'Per Type':['Model','Completeness','Type_display','Support','Accuracy','Precision','Recall','F1','MCC','TP','FP','FN','TN'],
 'ARG nonARG':['Model','Completeness','Average','N','Accuracy','Precision','Recall','F1','MCC'],
 'Subtype':['Model','Completeness','Average','N','Accuracy','Precision','Recall','F1','MCC','N_labels_averaged'],
 'Supplement check':['Table','Completeness','Average_in_document','Status','Compared_main_average','Compared_main_scope'],
 'Sources':['Model','Completeness','N_input','N_true_ARG','N_true_nonARG','N_parent','N_true_types','Population','Source']}
status_names={'Matches_current_definition':'一致','Includes_nonARG_instead_of_ARG_only':'包含nonARG',
 'Legacy_mapping_removed_name_only_now':'旧映射已取消，现按同名对应',
 'Extra_Type_labels_instead_of_fixed23':'含额外Type，非固定23类',
 'Binary_averaging_definition_differs':'二分类平均方式不同','Matches_old_predictions_only':'匹配旧模型结果',
 'Unexplained_numeric_difference':'数值未匹配 需核查'}
checked=0
for mod,specs in books.items():
 path=ROOT/mod/f'{mod}_60_to_100_results.xlsx'
 wb=load_workbook(path,read_only=True,data_only=True)
 assert wb.sheetnames==[x['name'] for x in specs]
 for spec in specs:
  ws=wb[spec['name']]
  if ws.max_row is None:
   ws.calculate_dimension(force=True)
  keys=columns[spec['name']]
  assert ws.max_row==len(spec['rows'])+5,(mod,ws.title,ws.max_row)
  indexes=[spec['columns'].index(k) for k in keys]
  for rnum,(actual,original) in enumerate(zip(ws.iter_rows(min_row=6,max_col=len(keys),values_only=True),spec['rows']),6):
   for j,(got,i) in enumerate(zip(actual,indexes)):
    expected=original[i]
    if keys[j]=='Source':expected=ntpath.basename(expected)
    if keys[j]=='Status':expected=status_names.get(expected,expected)
    if isinstance(expected,(float,int)):
     assert isinstance(got,(float,int)) and math.isclose(got,expected,abs_tol=2e-14,rel_tol=0),(mod,ws.title,rnum,j,got,expected)
    else: assert got==expected,(mod,ws.title,rnum,j,got,expected)
    checked+=1
 wb.close()
 print(f'{mod}: all seven sheets and all saved cells match.')
with (ROOT/'input_file_manifest.csv').open(encoding='utf-8-sig',newline='') as f:
 records=list(csv.DictReader(f))
for rec in records:
 h=hashlib.sha256()
 with Path(rec['Path']).open('rb') as f:
  for block in iter(lambda:f.read(2**20),b''):h.update(block)
 assert h.hexdigest()==rec['SHA256'],rec['Path']
print(f'{checked} exported cells checked; {len(records)} original inputs remain unchanged.')
if len(sys.argv)>1:
 with (Path(sys.argv[1])/'input_file_manifest.csv').open(encoding='utf-8-sig',newline='') as f:
  previous={r['Path']:r['SHA256'] for r in csv.DictReader(f)}
 current={r['Path']:r['SHA256'] for r in records}
 predictions={p:h for p,h in previous.items() if not p.lower().endswith('.docx')}
 assert all(current.get(p)==h for p,h in predictions.items()), 'Previous prediction sources changed or disappeared'
 print('All previous prediction source hashes match. The supplied DOCX now has the updated 18-table structure.')
(ROOT/'workbook_readback_validation.json').write_text(json.dumps({'Checked_cells':checked,
 'Sheets':14,'Original_sources_unchanged':len(records),'Compared_with_previous_delivery':len(sys.argv)>1},indent=2),encoding='utf-8')
