#!/usr/bin/env python3
"""Recompute saved predictions; never train, change thresholds, or modify inputs.

Main Type outputs use a fixed ARGScope 23-label universe and true-label filter.
Out-of-universe predictions remain errors. Legacy calculations are audit-only.
The supplied Supplementary materials.docx is read-only and audited cell by cell.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import math
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np
import pandas as pd
import strict_type_names as strict
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

OUT = Path(__file__).resolve().parent
TRAIN = OUT.parents[2]
APP = OUT.parent / 'ARGScope_80_20_results/apply_argscope_protein_and_DNA'
RAW = TRAIN / 'ARGscope_result_9.16'
DOC = Path(r'C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写\Supplementary materials.docx')
PCTS = [60, 70, 80, 90, 100]
MODELS = {'Protein': ['ARGNet', 'DeepARG', 'PLM-ARG', 'FunGeneTyper', 'ARGScope'],
          'DNA': ['ARGNet', 'DeepARG', 'ARGScope']}
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1', 'MCC']
AVERAGES = ['macro', 'weighted', 'micro']
FILES, AUDITS, CHECKS, PLM_CHECKS, CANDIDATES = {}, [], [], [], []
TYPE_LABELS = []
LEGACY_MAPPING_ROWS = []
DISPLAY = {'beta_lactam': 'Beta-lactams', 'macrolide-lincosamide-streptogramin': 'MLS',
           'other_peptide_antibiotics': 'Other peptides', 'tetracenomycin_C': 'Tetracenomycin C',
           'fusidic_acid': 'Fusidic acid', 'quinolone': 'Quinolones'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''): h.update(block)
    return h.hexdigest()


def record(path):
    path = Path(path)
    if str(path) not in FILES:
        FILES[str(path)] = dict(SHA256=sha(path), Bytes=path.stat().st_size,
                               Modified=datetime.fromtimestamp(path.stat().st_mtime).isoformat())


def read(path, **kwargs):
    record(path)
    return pd.read_csv(path, keep_default_na=False, low_memory=False, **kwargs)


def load_module(name, path):
    record(path)
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def clean_frame(df, idcol, ycol='true_type', pcol='predicted_type', pct=100, parentcol=None):
    df = df.copy()
    if 'split' in df:
        assert df['split'].eq('test').all(), 'Unexpected non-test observations'
    for col in [idcol, ycol, pcol]:
        assert df[col].astype(str).str.strip().ne('').all(), f'Empty required {col}'
    assert df[idcol].is_unique, f'Duplicate {idcol}'
    df['_id'] = df[idcol].astype(str)
    df['_y'], df['_p'] = df[ycol].astype(str), df[pcol].astype(str)
    # Full IDs can naturally end _1..._5. Strip augmentation suffix only in fragments.
    df['_parent'] = (df['_id'] if pct == 100 else df[parentcol].astype(str) if parentcol
                     else df['_id'].str.replace(r'_[1-5]$', '', regex=True))
    assert df.groupby('_parent')['_y'].nunique().eq(1).all()
    return df


def mapped_path(mod, model, pct):
    if model == 'ARGNet' and mod == 'Protein':
        return RAW / f'ARGnet/protein/ARGNet_type_metrics_results/mapped_predictions/protein_{pct}pct_5parts_argnet-l_aa_result_mapped_type_predictions.csv'
    if model == 'ARGNet':
        condition = '100pct' if pct == 100 else f'{pct}pct_5parts'
        return RAW / f'ARGnet/DNA/ARGNet_DNA_type_metrics_results/mapped_predictions/dna_{condition}_clean_argnet-l_nt_result_mapped_type_predictions.csv'
    if model == 'FunGeneTyper':
        return RAW / f'FunGenetyper/Protein/FunGeneTyper_Protein_metrics_results/mapped_predictions/{pct}p_result_mapped_type_predictions.csv'
    condition = '100pct' if pct == 100 else f'{pct}pct_5parts'
    return RAW / f'PLMARG/Protein/PLMARG_Protein_metrics_results/mapped_predictions/protein_{condition}_plmarg_result_mapped_type_predictions.csv'


def verify_plm(df, pct, mapping):
    path = TRAIN / f'Type_level_performance/PLM_ARG/plmarg_eval_outputs_{pct}p/merged_plmarg_predictions_with_labels.csv'
    raw = read(path)
    assert raw.seq_id.is_unique and set(raw.seq_id) == set(df.test_id)
    indexed = df.set_index('test_id').loc[raw.seq_id]
    np.testing.assert_array_equal(raw.type, indexed.true_type)
    np.testing.assert_array_equal(raw.pred, indexed.raw_pred)
    np.testing.assert_allclose(raw.ARG.astype(float), indexed.ARG_score.astype(float), atol=1e-12, rtol=0)
    binary = np.where(raw.ARG.astype(float) >= mapping.ARG_THRESHOLD, 'ARG', 'nonARG')
    np.testing.assert_array_equal(binary, indexed.ARG_prediction)
    pairs = list(zip(binary, raw.pred.astype(str)))
    lookup = {x: mapping.map_plmarg_prediction(*x)[0] for x in set(pairs)}
    np.testing.assert_array_equal([lookup[x] for x in pairs], indexed.predicted_type)
    PLM_CHECKS.append(dict(Completeness=pct, N=len(df), Threshold=mapping.ARG_THRESHOLD,
                          IDs_truth_probabilities_raw_predictions_match=True,
                          Mapping_reproduced_without_truth=True, Raw_source=str(path)))


def metrics(y, p, mod, model, pct, level, scope, population, source, fixed_labels=None):
    y, p = np.asarray(y, str), np.asarray(p, str)
    assert len(y) == len(p) and len(y) > 0
    labels = np.union1d(np.union1d(y, p), [] if fixed_labels is None else fixed_labels)
    idx_y, idx_p = np.searchsorted(labels, y), np.searchsorted(labels, p)
    support = np.bincount(idx_y, minlength=len(labels)).astype(float)
    predicted = np.bincount(idx_p, minlength=len(labels)).astype(float)
    tp = np.bincount(idx_y[y == p], minlength=len(labels)).astype(float)
    fn, fp = support-tp, predicted-tp
    n = len(y)
    tn = n-tp-fp-fn
    div = lambda a,b: np.divide(a,b,out=np.zeros_like(np.asarray(a,dtype=float)),where=np.asarray(b)!=0)
    precision, recall = div(tp,tp+fp), div(tp,tp+fn)
    f1 = div(2*tp,2*tp+fp+fn)
    denominator = math.sqrt(max(0., (n*n-float(predicted@predicted))*(n*n-float(support@support))))
    mcc = (float(tp.sum())*n-float(support@predicted))/denominator if denominator else 0.
    acc = float(tp.sum()/n)
    assert abs(acc-accuracy_score(y,p)) < 1e-12
    assert abs(mcc-matthews_corrcoef(y,p)) < 1e-12
    eligible = np.array([s != 'nonARG' and not s.startswith('__') for s in labels]) if scope == 'ARG_only' else np.ones(len(labels),bool)
    if scope == 'legacy_all_ARG_types':
        eligible = np.array([s != 'nonARG' and not s.startswith('__') for s in labels])
    if fixed_labels is not None:
        assert len(set(fixed_labels)) == len(fixed_labels)
        assert np.isin(y, fixed_labels).all(), 'Truth outside the fixed evaluation universe'
        eligible = np.isin(labels, fixed_labels)
    assert scope != 'ARG_only' or not np.any(y=='nonARG')
    use_labels = labels[eligible] if fixed_labels is None else np.asarray(fixed_labels)
    ovr_mcc = div(tp*tn-fp*fn,np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
    counts = pd.DataFrame(dict(Type=labels, Support=support.astype(int), Predicted_count=predicted.astype(int),
                               TP=tp.astype(int), FP=fp.astype(int), FN=fn.astype(int), TN=tn.astype(int),
                               Accuracy=(tp+tn)/n, Precision=precision, Recall=recall, F1=f1, MCC=ovr_mcc,
                               Included_in_average=eligible))
    base = dict(Modality=mod, Model=model, Completeness=pct, Level=level, Scope=scope,
                N=n, N_labels_averaged=len(use_labels), Population=population, Source=str(source))
    rows=[]
    for average in AVERAGES:
        pp,rr,ff,_ = precision_recall_fscore_support(y,p,labels=use_labels,average=average,zero_division=0)
        if average=='macro': expected=[v[eligible].mean() for v in (precision,recall,f1)]
        elif average=='weighted': expected=[float(v[eligible]@support[eligible]/support[eligible].sum()) for v in (precision,recall,f1)]
        else:
            tt,fp_sum,fn_sum = tp[eligible].sum(),fp[eligible].sum(),fn[eligible].sum()
            expected=[div(tt,tt+fp_sum),div(tt,tt+fn_sum),div(2*tt,2*tt+fp_sum+fn_sum)]
        np.testing.assert_allclose([pp,rr,ff],expected,rtol=0,atol=1e-12)
        rows.append(dict(**base,Average=average,Accuracy=acc,Precision=pp,Recall=rr,F1=ff,MCC=mcc,
                         Averaged_labels=';'.join(use_labels)))
    if level=='ARG_nonARG':
        pp,rr,ff,_=precision_recall_fscore_support(y,p,labels=['ARG'],average='macro',zero_division=0)
        rows.append(dict(**base,Average='ARG_positive',Accuracy=acc,Precision=pp,Recall=rr,F1=ff,MCC=mcc,Averaged_labels='ARG'))
    for k,v in base.items(): counts[k]=v
    # Independently check per-class binary MCC, including degenerate zero cases.
    checked_indices = range(len(labels)) if level != 'Subtype' else sorted(set([0,len(labels)//2,len(labels)-1]))
    for j in checked_indices:
        label = labels[j]
        assert abs(ovr_mcc[j]-matthews_corrcoef(y==label,p==label)) < 1e-12
    CHECKS.append(dict(**{k:base[k] for k in ('Modality','Model','Completeness','Level','Scope','N')},
                       Overall_ACC_MCC_verified=True, Three_averages_verified=True,
                       Per_class_MCC_checked=len(checked_indices), Per_class_MCC_total=len(labels)))
    return rows,counts


def evaluate_df(df, mod, model, pct, path, population, include_subtype=False):
    all_rows, all_counts=[],[]
    for scope in ['ARG_only','legacy_all_ARG_types','including_nonARG']:
        subset = (df.loc[df['_y'].isin(TYPE_LABELS)] if scope=='ARG_only' else
                  df.loc[df['_y'].ne('nonARG')] if scope=='legacy_all_ARG_types' else df)
        rows,cnt=metrics(subset['_y'],subset['_p'],mod,model,pct,'Type',scope,population,path,
                         fixed_labels=TYPE_LABELS if scope=='ARG_only' else None)
        all_rows+=rows
        if scope=='ARG_only': all_counts.append(cnt)
        if include_subtype and scope != 'legacy_all_ARG_types':
            subdf=df.loc[df['_y'].ne('nonARG')] if scope=='ARG_only' else df
            subrows,_=metrics(subdf.true_subtype,subdf.predicted_subtype,mod,model,pct,'Subtype',scope,population,path)
            all_rows+=subrows
    if '_binary_pred' in df:
        br,_=metrics(np.where(df['_y'].ne('nonARG'),'ARG','nonARG'),df['_binary_pred'],mod,model,pct,'ARG_nonARG','ARG_and_nonARG',population,path)
        all_rows+=br
    counts=pd.concat(all_counts,ignore_index=True)
    arg=df.loc[df['_y'].ne('nonARG')]
    AUDITS.append(dict(Modality=mod,Model=model,Completeness=pct,N_input=len(df),N_true_ARG=len(arg),
                       N_true_nonARG=len(df)-len(arg),N_parent=df['_parent'].nunique(),
                       N_true_types=arg['_y'].nunique(),ARG_predicted_nonARG=int(arg['_p'].eq('nonARG').sum()),
                       ARG_predicted_unmapped=int(arg['_p'].str.startswith('__').sum()),
                       N_fixed23_evaluated=int(df._y.isin(TYPE_LABELS).sum()),
                       N_true_extra_types_removed=int((df._y.ne('nonARG') & ~df._y.isin(TYPE_LABELS)).sum()),
                       Extra_true_types_removed=';'.join(sorted(set(arg._y)-set(TYPE_LABELS))),
                       Fixed23_predictions_outside23_retained=int((df._y.isin(TYPE_LABELS) & ~df._p.isin(TYPE_LABELS)).sum()),
                       Duplicate_IDs=0,Population=population,Matched_new_ARGScope_test=model=='ARGScope',Source=str(path)))
    print(f'{mod} {pct}% {model}: input={len(df):,}, ARG={len(arg):,}, true Types={arg._y.nunique()}',flush=True)
    return all_rows,counts


def read_own(mod,pct,old=False):
    folder=(RAW / ('ARGScope/protein_result' if mod=='Protein' else 'ARGScope/DNA_result')) if old else APP/mod.lower()
    name='100%_test_sequence_predictions.csv' if pct==100 else (f'{pct}%_protein_fragment_test_predictions.csv' if old and mod=='Protein' else f'{pct}%_fragment_predictions_test.csv')
    path=folder/name
    df=read(path)
    if 'split' in df: df=df[df.split.eq('test')].copy()
    idcol=next(c for c in ['sequence_id','fragment_id'] if c in df)
    parent=next((c for c in ['parent_sequence_id','original_id'] if c in df),None)
    df=clean_frame(df,idcol,pct=pct,parentcol=parent)
    assert np.array_equal(df.true_ARG.astype(int),df._y.ne('nonARG').astype(int))
    df['_binary_pred']=np.where(df.predicted_ARG.astype(int)==1,'ARG','nonARG')
    return path,df


def compute_all():
    global TYPE_LABELS
    strict.self_test()
    _, own_full_protein=read_own('Protein',100)
    _, own_full_dna=read_own('DNA',100)
    TYPE_LABELS=sorted(set(own_full_protein._y)-{'nonARG'})
    assert len(TYPE_LABELS)==23
    assert set(TYPE_LABELS)==set(own_full_dna._y)-{'nonARG'}
    mapping=load_module('plm_mapping_for_all_result',RAW/'PLMARG/Protein/calculate_PLMARG_Protein_metrics.py')
    rows,counts=[],[]
    own_ids,own_truth={},{}
    own_labels=set()
    full_ref=clean_frame(read(mapped_path('Protein','ARGNet',100)),'test_id')
    for pct in PCTS:
        protein_ref=None
        for mod in ['Protein','DNA']:
            for model in MODELS[mod]:
                if model in ['ARGNet','PLM-ARG','FunGeneTyper']:
                    path=mapped_path(mod,model,pct)
                    df=clean_frame(read(path),'test_id',pct=pct)
                    df['_binary_pred']=df.ARG_prediction
                    assert df._binary_pred.isin(['ARG','nonARG']).all()
                    if model=='PLM-ARG': verify_plm(df,pct,mapping)
                    if model=='PLM-ARG':
                        rawpath=TRAIN/f'Type_level_performance/PLM_ARG/plmarg_eval_outputs_{pct}p/merged_plmarg_predictions_with_labels.csv'
                        rawcol='raw_pred'
                    else:
                        rawpath,rawcol=strict.verify_raw(df,mod,model,pct,RAW,read)
                    df=strict.remap(df,mod,model,pct,TYPE_LABELS,rawcol,rawpath)
                    population='archived_cleaned_input' if mod=='DNA' else 'archived_labelled_input'
                    if mod=='Protein':
                        if model=='ARGNet': protein_ref=df.copy()
                        else:
                            pd.testing.assert_series_equal(df.set_index('_id')._y.sort_index(),protein_ref.set_index('_id')._y.sort_index())
                        parent_truth=full_ref.set_index('_id')._y
                        assert set(df._parent)<=set(parent_truth.index)
                        np.testing.assert_array_equal(df._y,parent_truth.loc[df._parent])
                elif model=='ARGScope':
                    path,df=read_own(mod,pct)
                    population='new_80_20_heldout_test'
                    own_ids[mod,pct]=set(df._parent)
                    own_truth[mod,pct]=df.set_index('_id')._y.sort_index()
                    assert len(df)==(4574 if pct==100 else 22870)
                    if pct!=100: assert df.groupby('_parent').size().eq(5).all()
                    own_labels.update(df.loc[df._y.ne('nonARG'),'_y'])
                else:
                    if mod=='Protein':
                        folder='all_arg_nonarg_protein_deeparg_LS_prot' if pct==100 else f'protein_{pct}pct_5parts_deeparg_SS_prot'
                        path=TRAIN/f'柱状图结果/longaa/Deeparg/{folder}/predictions_used_for_type_evaluation.csv'
                    else:
                        folder='dna_all' if pct==100 else f'dna_{pct}pct'
                        path=TRAIN/f'柱状图结果/longNT/deeparg/{folder}/deeparg_type_{folder}_predictions_used_for_evaluation.csv'
                    df=clean_frame(read(path),'read_id','type','predicted_type_teacher_system',pct)
                    population='archived_selected_ARG_hits_only'
                    assert df._y.ne('nonARG').all()
                    # Detection has a different denominator: all labelled input records.
                    callname=('all_arg_nonarg_protein_deeparg_LS_prot' if pct==100 else f'protein_{pct}pct_5parts_deeparg_SS_prot') if mod=='Protein' else ('all_arg_nonarg_dna_deeparg_SS_nucl' if pct==100 else f'dna_{pct}pct_5parts_deeparg_SS_nucl')
                    callpath=RAW/f'DeepARG/{"protein" if mod=="Protein" else "DNA"}/{callname}.mapping.ARG'
                    calls=read(callpath,sep='\t')
                    assert calls.read_id.is_unique
                    assert set(df._id)<=set(calls.read_id)
                    np.testing.assert_array_equal(df['predicted_ARG-class'],calls.set_index('read_id').loc[df._id,'predicted_ARG-class'])
                    strict.RAW_CHECKS.append(dict(Modality=mod,Model=model,Completeness=pct,N=len(df),
                        Unique_IDs_and_raw_names_match=True,Binary_calls_match=True,Source=str(callpath)))
                    df=strict.remap(df,mod,model,pct,TYPE_LABELS,'predicted_ARG-class',callpath)
                    if mod=='Protein':
                        universe=protein_ref
                        assert universe is not None and set(calls.read_id)<=set(universe._id)
                        bid,by=universe._id,universe._y
                        bp=np.where(bid.isin(set(calls.read_id)),'ARG','nonARG')
                        source=f'{callpath} ; denominator and truth: {mapped_path(mod,"ARGNet",pct)}'
                    else:
                        bp_path=path.parent/'ARG_nonARG_prediction_details.csv'
                        b=read(bp_path)
                        assert b.id.is_unique and set(calls.read_id)<=set(b.id)
                        np.testing.assert_array_equal(b.pred_ARG_binary.eq('ARG'),b.id.isin(set(calls.read_id)))
                        bid,by,bp=b.id,b.type,b.pred_ARG_binary
                        source=str(bp_path)
                    assert len(bid)==(26878 if pct==100 else 134390)
                    assert set(df._id)<=set(bid)
                    np.testing.assert_array_equal(df._y,pd.Series(by.to_numpy(),index=bid).loc[df._id])
                    rr,_=metrics(np.where(by.ne('nonARG'),'ARG','nonARG'),bp,mod,model,pct,'ARG_nonARG','ARG_and_nonARG','archived_labelled_input',source)
                    rows+=rr
                if '_legacy_p' in df:
                    for scope in ['ARG_only','legacy_all_ARG_types','including_nonARG']:
                        mask=(df._y.isin(TYPE_LABELS) if scope=='ARG_only' else df._y.ne('nonARG') if scope=='legacy_all_ARG_types' else np.ones(len(df),bool))
                        legacy,_=metrics(df.loc[mask,'_y'],df.loc[mask,'_legacy_p'],mod,model,pct,'Type',scope,
                            'LEGACY_MAPPING_REFERENCE_ONLY',path,fixed_labels=TYPE_LABELS if scope=='ARG_only' else None)
                        LEGACY_MAPPING_ROWS.extend(legacy)
                rr,cc=evaluate_df(df,mod,model,pct,path,population,include_subtype=model=='ARGScope')
                rows+=rr; counts.append(cc)
        pd.testing.assert_series_equal(own_truth['Protein',pct],own_truth['DNA',pct])
    for mod in MODELS:
        for pct in PCTS: assert own_ids[mod,pct]==own_ids[mod,100]
    assert own_labels==set(TYPE_LABELS)
    return pd.DataFrame(rows),pd.concat(counts,ignore_index=True),sorted(own_labels)


def supplementary_rows():
    record(DOC)
    w={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with zipfile.ZipFile(DOC) as z: root=ET.fromstring(z.read('word/document.xml'))
    def text(e): return ''.join(e.itertext()) if False else ''.join(t.text or '' for t in e.findall('.//w:t',w)).strip()
    rows=[]; table_no=0; title=''
    for block in root.find('w:body',w):
        if block.tag.endswith('}p'):
            if text(block): title=text(block)
        if not block.tag.endswith('}tbl'): continue
        table_no+=1
        tr=block.findall('w:tr',w)
        header=[text(c) for c in tr[0].findall('w:tc',w)]
        prior={}
        for rownum,row in enumerate(tr[1:],2):
            cells=[text(c) for c in row.findall('w:tc',w)]
            assert len(cells)==len(header),(table_no,cells,header)
            item=dict(zip(header,cells))
            for k in ['Condition','Class']:
                if not item.get(k): item[k]=prior.get(k,'')
            prior=item.copy()
            pct=int(item['Condition'].rstrip('%'))
            avg=item.get('Average','unspecified')
            for metric in METRICS:
                token=item['ACC' if metric=='Accuracy' else metric].strip()
                value=float(token) if token else None
                rows.append(dict(Table=table_no,Title=title,Word_row=rownum,Completeness=pct,
                                 Average_in_document=avg,Metric=metric,Document_token=token,Document_value=value))
    assert table_no==18, f'Unexpected supplement table structure: {table_no}'
    return pd.DataFrame(rows)


TABLE_MAP={1:('Protein','ARGScope','ARG_nonARG'),2:('Protein','ARGScope','Type'),3:('Protein','ARGScope','Subtype'),
           4:('DNA','ARGScope','ARG_nonARG'),5:('DNA','ARGScope','Type'),6:('DNA','ARGScope','Subtype'),
           7:('Protein','ARGNet','ARG_nonARG'),8:('Protein','ARGNet','Type'),9:('DNA','ARGNet','ARG_nonARG'),
           10:('DNA','ARGNet','Type'),11:('Protein','FunGeneTyper','ARG_nonARG'),12:('Protein','FunGeneTyper','Type'),
           13:('Protein','PLM-ARG','ARG_nonARG'),14:('Protein','PLM-ARG','Type'),
           15:('Protein','DeepARG','ARG_nonARG'),16:('Protein','DeepARG','Type'),
           17:('DNA','DeepARG','ARG_nonARG'),18:('DNA','DeepARG','Type')}


def audit_supplement(all_metrics):
    doc=supplementary_rows()
    refs=all_metrics.copy(); refs['Version']='current_selected_predictions'
    # Previous ARGScope results can explain stale copied figures. They are reference-only.
    oldrows=[]
    for mod in MODELS:
        for pct in PCTS:
            path,df=read_own(mod,pct,old=True)
            for level,y,p in [('Type',df._y,df._p),('Subtype',df.true_subtype,df.predicted_subtype)]:
                for scope in ['ARG_only','including_nonARG']:
                    mask=df._y.ne('nonARG') if scope=='ARG_only' else np.ones(len(df),bool)
                    rr,_=metrics(y[mask],p[mask],mod,'ARGScope',pct,level,scope,'old_ARGScope_reference_only',path)
                    oldrows+=rr
            rr,_=metrics(np.where(df._y.ne('nonARG'),'ARG','nonARG'),df._binary_pred,mod,'ARGScope',pct,'ARG_nonARG','ARG_and_nonARG','old_ARGScope_reference_only',path)
            oldrows+=rr
    old=pd.DataFrame(oldrows); old['Version']='old_ARGScope_reference_only'
    legacy=pd.DataFrame(LEGACY_MAPPING_ROWS); legacy['Version']='legacy_mapping_reference_only'
    refs=pd.concat([refs,old,legacy],ignore_index=True)
    comparisons=[]; summaries=[]
    for (table,pct,avg),group in doc.groupby(['Table','Completeness','Average_in_document'],sort=False):
        mod,model,level=TABLE_MAP[table]
        candidates=refs[(refs.Modality==mod)&(refs.Model==model)&(refs.Level==level)&(refs.Completeness==pct)]
        if avg!='unspecified': candidates=candidates[candidates.Average==avg]
        matches=[]
        for candidate in candidates.to_dict('records'):
            diffs=[abs(candidate[r.Metric]-r.Document_value) if pd.notna(r.Document_value) else math.inf for r in group.itertuples()]
            # The document displays at most four decimal places; shorter strings often omit trailing zeroes.
            if max(diffs)<=0.0000500001: matches.append(candidate)
        current_matches=[r for r in matches if r['Version']=='current_selected_predictions']
        best=(current_matches or matches or [None])[0]
        if level=='ARG_nonARG':
            main_scope='ARG_and_nonARG'; main_avg='macro' if avg=='unspecified' else avg
        else: main_scope='ARG_only'; main_avg=avg
        target=refs[(refs.Version=='current_selected_predictions')&(refs.Modality==mod)&(refs.Model==model)&
                    (refs.Completeness==pct)&(refs.Level==level)&(refs.Scope==main_scope)&(refs.Average==main_avg)].iloc[0]
        if best is None: status='Unexplained_numeric_difference'
        elif best['Version']=='legacy_mapping_reference_only': status='Legacy_mapping_removed_name_only_now'
        elif best['Version']!='current_selected_predictions': status='Matches_old_predictions_only'
        elif best['Scope']=='legacy_all_ARG_types': status='Extra_Type_labels_instead_of_fixed23'
        elif best['Scope']!=main_scope: status='Includes_nonARG_instead_of_ARG_only'
        elif best['Average']!=main_avg: status='Binary_averaging_definition_differs'
        else: status='Matches_current_definition'
        # Multiple indistinguishable average schemes (e.g. balanced macro/weighted) are retained.
        match_description='; '.join(f"{r['Version']} | {r['Scope']} | {r['Average']} | N={r['N']}" for r in matches)
        summaries.append(dict(Table=table,Title=group.Title.iloc[0],Modality=mod,Model=model,Level=level,
                              Completeness=pct,Average_in_document=avg,Status=status,Matching_definitions=match_description,
                              Compared_main_average=main_avg,Compared_main_scope=main_scope,
                              Matched_source='' if best is None else best['Source']))
        for r in group.to_dict('records'):
            comparisons.append(dict(**r,Modality=mod,Model=model,Level=level,Current_average=main_avg,Current_scope=main_scope,
                                    Current_value=target[r['Metric']],Difference=target[r['Metric']]-r['Document_value'],
                                    Matched_original_value=None if best is None else best[r['Metric']],
                                    Status=status,Matching_definitions=match_description,Current_source=target.Source))
    return doc,pd.DataFrame(comparisons),pd.DataFrame(summaries),old


def csv(df,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(path,index=False,encoding='utf-8-sig',float_format='%.15g')


def output_tables(all_metrics,counts,labels,comparison,summary,doc,old):
    front=['Modality','Model','Completeness','Level','Scope','Average','N','Accuracy','Precision','Recall','F1','MCC']
    all_metrics=all_metrics[front+[c for c in all_metrics if c not in front]]
    main=all_metrics[(all_metrics.Level=='Type')&(all_metrics.Scope=='ARG_only')]
    all_per=counts[counts.Included_in_average].copy()
    all_per['Type_display']=all_per.Type.map(lambda t: DISPLAY.get(t,t.replace('_',' ').capitalize()))
    all_per['Is_ARGScope23']=all_per.Type.isin(labels)
    assert main.N_labels_averaged.eq(23).all()
    assert all_per.Is_ARGScope23.all()
    for _,g in all_per.groupby(['Modality','Model','Completeness']):
        assert len(g)==23 and set(g.Type)==set(labels)
    csv(pd.DataFrame({'Type':labels,'Type_display':[DISPLAY.get(t,t.replace('_',' ').capitalize()) for t in labels]}), OUT/'ARGScope_23_types.csv')
    per_front=['Modality','Model','Completeness','Type','Type_display','N','Support','Predicted_count','Accuracy','Precision','Recall','F1','MCC','TP','FP','FN','TN']
    all_per=all_per[per_front+[c for c in all_per if c not in per_front]]
    audit_dir=OUT/'supplementary_check'; audit_dir.mkdir(exist_ok=True)
    csv(doc,audit_dir/'01_document_extracted_cells.csv')
    csv(comparison,audit_dir/'02_cell_by_cell_comparison.csv')
    csv(summary,audit_dir/'03_table_row_status.csv')
    csv(old,audit_dir/'04_old_ARGScope_reference_only.csv')
    csv(all_metrics[all_metrics.Scope=='including_nonARG'],audit_dir/'05_current_including_nonARG_REFERENCE_ONLY.csv')
    csv(all_metrics[all_metrics.Scope=='legacy_all_ARG_types'],audit_dir/'06_legacy_all_ARG_types_AUDIT_ONLY.csv')
    csv(pd.DataFrame(LEGACY_MAPPING_ROWS),audit_dir/'08_PREVIOUS_MAPPING_REFERENCE_ONLY.csv')
    csv(pd.DataFrame(strict.AUDIT),OUT/'Type_name_mapping_audit.csv')
    csv(pd.DataFrame(strict.RAW_CHECKS),OUT/'raw_prediction_checks.csv')
    books={}
    for mod in MODELS:
        folder=OUT/mod; folder.mkdir(exist_ok=True)
        m=main[main.Modality==mod].copy()
        assert len(m)==len(MODELS[mod])*5*3
        tables={
            '01_Type_barplot_macro_five_metrics':m[m.Average=='macro'],
            '02_Type_overall_macro_weighted_micro':m,
            '03_Per_Type_fixed23_five_metrics':all_per[all_per.Modality==mod],
            '04_Per_Type_ARGScope23_display_view':all_per[(all_per.Modality==mod)&all_per.Is_ARGScope23],
            '05_ARG_nonARG_ARG_positive_five_metrics':all_metrics[(all_metrics.Modality==mod)&(all_metrics.Level=='ARG_nonARG')&(all_metrics.Average=='ARG_positive')],
            '06_ARG_nonARG_macro_weighted_micro':all_metrics[(all_metrics.Modality==mod)&(all_metrics.Level=='ARG_nonARG')&(all_metrics.Average!='ARG_positive')],
            '07_ARGScope_Subtype_ARG_only_macro_weighted_micro':all_metrics[(all_metrics.Modality==mod)&(all_metrics.Level=='Subtype')&(all_metrics.Scope=='ARG_only')],
            '08_source_population_audit':pd.DataFrame(AUDITS).query('Modality == @mod'),
            '09_supplementary_comparison':comparison[comparison.Modality==mod],
        }
        for name,df in tables.items(): csv(df,folder/(name+'.csv'))
        for pct in PCTS:
            sub=folder/f'{pct}pct'
            csv(m[m.Completeness==pct],sub/'Type_overall_macro_weighted_micro.csv')
            csv(tables['03_Per_Type_fixed23_five_metrics'].query('Completeness == @pct'),sub/'Per_Type_five_metrics.csv')
            csv(all_metrics[(all_metrics.Modality==mod)&(all_metrics.Completeness==pct)&(all_metrics.Level=='ARG_nonARG')],sub/'ARG_nonARG_all_averages.csv')
        for label,df in tables['03_Per_Type_fixed23_five_metrics'].groupby('Type',sort=True):
            safe=re.sub(r'[^A-Za-z0-9_-]','_',label)
            csv(df,folder/'per_type'/f'{safe}_{hashlib.sha1(label.encode()).hexdigest()[:6]}.csv')
        for model,df in m.groupby('Model',sort=False):
            csv(df,folder/'per_model'/f'{model}_Type_overall.csv')
        sheets=[('Type bars',tables['01_Type_barplot_macro_five_metrics']),
                ('Type averages',m),('Per Type',tables['03_Per_Type_fixed23_five_metrics']),
                ('ARG nonARG',pd.concat([tables['05_ARG_nonARG_ARG_positive_five_metrics'],tables['06_ARG_nonARG_macro_weighted_micro']])),
                ('Subtype',tables['07_ARGScope_Subtype_ARG_only_macro_weighted_micro']),
                ('Supplement check',summary[summary.Modality==mod]),('Sources',tables['08_source_population_audit'])]
        books[mod]=[dict(name=name,columns=list(df.columns),rows=json.loads(df.to_json(orient='values',force_ascii=False,double_precision=15))) for name,df in sheets]
    (OUT/'workbook_data.json').write_text(json.dumps(books,ensure_ascii=False,allow_nan=False),encoding='utf-8')
    csv(pd.DataFrame(CHECKS),OUT/'calculation_checks.csv')
    csv(pd.DataFrame(PLM_CHECKS),OUT/'PLMARG_mapping_checks.csv')
    csv(pd.DataFrame([dict(Path=p,**v) for p,v in FILES.items()]),OUT/'input_file_manifest.csv')
    return main


def main():
    global TYPE_LABELS
    for name in MODELS:
        target=OUT/name
        if target.exists() and any(target.iterdir()) and '--replace-generated' not in sys.argv:
            raise RuntimeError(f'Output folder is not empty; preserve prior outputs: {target}')
    cache=OUT/'calculation_cache'; cache.mkdir(exist_ok=True)
    if '--resume-cache' in sys.argv:
        saved=json.loads((cache/'state.json').read_text(encoding='utf-8'))
        FILES.update(saved['FILES'])
        for path,entry in FILES.items(): assert sha(path)==entry['SHA256'],f'Cache input changed: {path}'
        AUDITS.extend(saved['AUDITS']); CHECKS.extend(saved['CHECKS']); PLM_CHECKS.extend(saved['PLM_CHECKS'])
        LEGACY_MAPPING_ROWS.extend(saved['LEGACY_MAPPING_ROWS']); strict.AUDIT.extend(saved['MAPPING_AUDIT'])
        strict.RAW_CHECKS.extend(saved['RAW_CHECKS']); TYPE_LABELS=saved['TYPE_LABELS']; labels=TYPE_LABELS
        frame=pd.read_csv(cache/'all_metrics.csv',keep_default_na=False)
        counts=pd.read_csv(cache/'all_counts.csv',keep_default_na=False)
    else:
        frame,counts,labels=compute_all()
        csv(frame,cache/'all_metrics.csv'); csv(counts,cache/'all_counts.csv')
        state=dict(FILES=FILES,AUDITS=AUDITS,CHECKS=CHECKS,PLM_CHECKS=PLM_CHECKS,LEGACY_MAPPING_ROWS=LEGACY_MAPPING_ROWS,
            MAPPING_AUDIT=strict.AUDIT,RAW_CHECKS=strict.RAW_CHECKS,TYPE_LABELS=TYPE_LABELS)
        (cache/'state.json').write_text(json.dumps(state,ensure_ascii=False),encoding='utf-8')
    doc,comparison,summary,old=audit_supplement(frame)
    type_main=output_tables(frame,counts,labels,comparison,summary,doc,old)
    for path,entry in FILES.items(): assert sha(path)==entry['SHA256'],f'Input changed during run: {path}'
    report=dict(Generated=datetime.now().isoformat(),Source_files=len(FILES),All_sources_unchanged=True,
                Protein_Type_rows=len(type_main[type_main.Modality=='Protein']),
                DNA_Type_rows=len(type_main[type_main.Modality=='DNA']),
                Conditions=PCTS,ARGScope_types=labels,Supplement_tables=doc.Table.nunique(),
                Supplement_cells=len(doc),Supplement_status_counts=summary.Status.value_counts().to_dict(),
                Metric_check_groups=len(CHECKS),No_figure_files_modified=True)
    report.update(Type_scope='Fixed ARGScope 23 Types; truth membership filter; outside predictions retained as errors',
                  All_Type_groups_have_exactly_23_labels=True,Mapping_policy=strict.POLICY,
                  No_ontology_alignment=True,Raw_prediction_checks=len(strict.RAW_CHECKS)+len(PLM_CHECKS))
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
    print(summary.groupby(['Table','Status']).size().to_string(),flush=True)


if __name__=='__main__': main()
