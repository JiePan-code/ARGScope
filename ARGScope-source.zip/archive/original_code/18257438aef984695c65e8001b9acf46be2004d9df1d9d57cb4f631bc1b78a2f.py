"""Generate a readable result artifact only after all runs independently verify."""
from pathlib import Path
from collections import defaultdict
import csv
import json
import statistics

ROOT=Path(__file__).resolve().parents[1]
RESULTS=ROOT/"Results"


def read(path):
    with path.open(encoding="utf-8-sig",newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    complete=json.loads((RESULTS/"completion_status.json").read_text(encoding="utf-8"))
    verified=json.loads((RESULTS/"verification_status.json").read_text(encoding="utf-8"))
    assert complete["complete"] and verified["all_requested_runs_verified"]
    data=json.loads((ROOT/"Dataset/dataset_manifest.json").read_text(encoding="utf-8"))
    means=read(RESULTS/"mean_std_metrics.csv")
    lookup={(r["method"],r["branch"],r["task"],r["metric"]):r for r in means}
    display=lambda r:f"{float(r['mean']):.4f} ± {float(r['sample_std']):.4f}"
    wide=[]
    lines=["# BGC 标签规范重跑结果", "", "全部三个预设种子和两个模态分支已完成，逐条预测指标通过独立复算。所有结果为固定划分上三个种子的均值 ± 样本标准差。", "",
           "## 数据与标签", "",
           "保留 64,926 条配对序列，包括 32,463 条 BGC 阳性和 32,463 条 nonBGC 候选阴性。阳性来自 MIBiG 4.0 父 BGC 中的 CDS。预测标签是来源 BGC 的生物合成类别，不是单条基因已经实验验证的功能。原有样本及父 BGC 分组划分均保持不变。",
           "", "七个阳性粗类保留。原 RiPP 更名为 Ribosomal peptide，包含 RiPP 和 unmodified peptide。PKS 架构属性与类型分开，Hybrid 统一为生物合成组成标签，RiPP 细类读取真实 ripp_type。保留 38 个满足来源支持规则的阳性细类。缺失或稀有细标签的阳性样本仍用于二分类和粗分类。", "",
           "训练 44,255 条，验证 7,645 条，测试 13,026 条。没有父 BGC 跨集合，也未发现任何模态中的完全相同序列重复。近同源序列独立性尚未验证。", ""]
    tasks=[("binary","二分类：全部 13,026 条测试序列",["accuracy","positive_precision","positive_recall","positive_f1","mcc"],"ACC | Precision (BGC) | Recall (BGC) | F1 (BGC) | MCC"),
           ("type","粗分类：七个阳性类别和 nonBGC",["accuracy","macro_precision","macro_recall","macro_f1","mcc"],"ACC | Macro precision | Macro recall | Macro F1 | MCC"),
           ("subtype","细分类：有细标签的阳性和全部阴性",["accuracy","weighted_precision","weighted_recall","weighted_f1","mcc"],"ACC | Weighted precision | Weighted recall | Weighted F1 | MCC")]
    for task,title,fields,header in tasks:
        lines += [f"## {title}","",f"| 模型 | {header} |","|---|---:|---:|---:|---:|---:|"]
        for branch in ("AA","NT"):
            values=[lookup["ARGScope",branch,task,f] for f in fields]
            assert all(int(r["seeds_completed"])==3 for r in values)
            lines.append("| BGCScope-"+branch+" | "+" | ".join(map(display,values))+" |")
            wide.append({"method":"ARGScope","branch":branch,"task":task,"N":values[0]["evaluation_records"],
                         **{f:display(v) for f,v in zip(fields,values)}})
        lines += [""]
    coverage=data["coverage"]["test"]
    lines += [f"细分类评价包含 {coverage['fine_annotated_BGC_records']:,} 条有可用细标签的 BGC 序列及 {coverage['nonBGC_records']:,} 条 nonBGC，共 {coverage['fine_end_to_end_evaluation_records']:,} 条。阳性细标签覆盖率为 {coverage['fine_BGC_annotation_coverage']*100:.2f}%。该结果不能视为全部 BGC 阳性记录的细分类表现。", "",
              "## 阳性细分类：忽略二分类门控的辅助结果", "", "只在 3,960 条有细标签的阳性测试序列上评价，以补充包含大量阴性记录的端到端加权指标。", "",
              "| 模型 | ACC | Weighted precision | Weighted recall | Weighted F1 | MCC |", "|---|---:|---:|---:|---:|---:|"]
    for branch in ("AA","NT"):
        runs=[json.loads((ROOT/f"seed_{seed}"/branch/"run_summary.json").read_text(encoding="utf-8")) for seed in (20260915,20261006,20261007)]
        fields=["accuracy","weighted_precision","weighted_recall","weighted_f1","mcc"]
        cells=[]
        for field in fields:
            values=[s["student_test_metrics"]["BGC_subtype_oracle_binary"][field] for s in runs]
            cells.append(f"{statistics.mean(values):.4f} ± {statistics.stdev(values):.4f}")
        lines.append(f"| BGCScope-{branch} | "+" | ".join(cells)+" |")
    lines += ["", "## 简单线性对照", "", "该对照使用相同冻结单模态特征、标签和划分，只接受监督损失，不使用图、教师或对齐。它不是单个组件的消融实验。", "",
              "| 模型 | Binary ACC | Type macro F1 | Subtype weighted F1 |", "|---|---:|---:|---:|"]
    for branch in ("AA","NT"):
        for method in ("ARGScope","Linear probe"):
            values=[lookup[method,branch,t,f] for t,f in (("binary","accuracy"),("type","macro_f1"),("subtype","weighted_f1"))]
            lines.append(f"| {method}-{branch} | "+" | ".join(map(display,values))+" |")
    comparisons=read(RESULTS/"old_vs_new_same_cohort.csv")
    lines += ["", "## 与旧版相同测试样本的描述性比较", "",
              "旧版是单次运行，新版是三个种子的均值。二分类真值一致，粗标签更名后真值一致。这里的差值不是显著性结论。细标签集合和评价分母发生变化，不作新旧 subtype 数值提升比较。", "",
              "| 分支 | 任务 | 指标 | 旧版单次 | 新版均值 | 差值 |", "|---|---|---|---:|---:|---:|"]
    for r in comparisons:
        if r["metric"] not in ("accuracy","precision","recall","f1"):
            continue
        lines.append(f"| {r['branch']} | {r['task']} | {r['metric']} | {float(r['old_single_run_value']):.4f} | {float(r['new_mean']):.4f} | {float(r['descriptive_difference']):+.4f} |")
    lines += ["", "## 论文使用注意", "",
              "此次规范解决了标签粒度混杂和缺失标签处理问题，并不保证所有指标提高。应逐项报告二分类和粗分类的变化，不把细分类评价范围的改变写成模型提升。",
              "", "没有明确细标签的阳性序列采用 type-marginal negative log likelihood，在已知粗类对应的可用细类上汇总概率。没有新增 type 分类头。该处理属于明确的方法适配，需要在补充方法中说明。",
              "", "该闭集映射不验证缺失细注释记录的具体 subtype。NRPS 和 Saccharide 在本数据中各只有一个保留子类，不构成其类内多细类区分的证据。Hybrid 子类是组合标签，不是同一粒度的基因家族。部分细类无验证集支持，两类无测试集支持，见支持审计表。",
              "", "随机种子：20260915、20261006、20261007。没有按测试分数选择种子。均值和标准差不是置信区间，也不代表跨数据划分的泛化不确定性。原始候选阴性集排除流程仍未充分溯源，且尚未完成近同源聚类审计。",
              "", "任务可以表述为 BGC-associated sequence classification by parent-cluster biosynthetic categories，不宜表述为直接预测单基因生物合成功能或完整 BGC 检测。任务特异重训说明框架可以在新的标签系统上重新训练，不等同于 ARG 模型无重训的跨数据集迁移。", "",
              "## 核查和文件", "",
              "原始代码、标签与划分未修改。原型独立重算匹配，逐条预测采用 scikit-learn 独立复算，各分支、各任务指标匹配。结果文件不包含中断的串行 NT 尝试。", "",
              "- mean_std_metrics.csv：全部方法和任务的均值与样本标准差。",
              "- old_vs_new_same_cohort.csv：相同测试样本上的新旧二分类/粗分类比较。",
              "- independent_verification.csv 与 verification_status.json：独立复核结果。",
              "- exact_sequence_overlap_audit.json：完全相同序列检查。",
              "- Dataset/subtype_support_and_exclusions.csv：每个细类的父 BGC 支持数及排除原因。",
              "- seed_*/AA、NT：训练记录、验证集选择、模型检查点及逐条测试预测。", ""]
    (RESULTS/"BGC规范化重跑结果.md").write_text("\n".join(lines),encoding="utf-8")
    # A compact rectangular CSV is convenient for direct Excel viewing.
    columns=sorted({k for r in wide for k in r})
    with (RESULTS/"compact_main_results.csv").open("w",encoding="utf-8-sig",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=columns)
        writer.writeheader()
        writer.writerows(wide)
    print("Verified readable report:",RESULTS/"BGC规范化重跑结果.md")


if __name__=="__main__":
    main()
