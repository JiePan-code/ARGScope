#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Generate paired protein/DNA simulated fragments for ALL ARG:nonARG ratio datasets.

Input layout expected from build_ARG_nonARG_multiratio_datasets.py:

ARG_nonARG_multiratio_final/
|
|-- ARG1_nonARG1/
|   |-- all_arg_nonarg_protein.fasta
|   |-- all_arg_nonarg_dna.fasta
|   `-- all_arg_nonarg_structure.txt
|
|-- ARG1_nonARG5/
|-- ARG1_nonARG10/
|-- ARG1_nonARG20/
`-- ARG1_nonARG50/

For every available ratio dataset, generate:

    fixed_30aa_90nt
    fixed_40aa_120nt
    fixed_50aa_150nt
    percent_60
    percent_70
    percent_80
    percent_90

For every retained original protein/DNA pair, five paired fragments are made.
The protein start is selected first; DNA coordinates are always:

    NT_start = AA_start * 3
    NT_end   = AA_end   * 3

Therefore protein and nucleotide fragments remain codon-aligned and share
identical fragment IDs.

Important reproducibility property:
The local random seed for a sequence depends only on:
    GLOBAL_RANDOM_SEED + original sequence ID + simulation condition

Therefore the SAME original sequence gets the SAME simulated fragments in
1:1, 1:5, 1:10, 1:20 and 1:50 datasets. This is appropriate because the
multi-ratio datasets were constructed with nested nonARG sampling.

No third-party Python package is required.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator


# =============================================================================
# 1. WINDOWS DEFAULTS
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# 自动使用“脚本所在目录”下的 ARG_nonARG_multiratio_final。
# 例如脚本位于：
# E:\\1. ARGmodel\\1. NonARG_training\\1. Dataset\\最后的数据集\\
# 1.Final SARG dataset with over 3 subtype\\
#
# 则自动读取：
# ...\\1.Final SARG dataset with over 3 subtype\\ARG_nonARG_multiratio_final
BASE_DIR = SCRIPT_DIR / "ARG_nonARG_multiratio_final"

PROTEIN_FILENAME = "all_arg_nonarg_protein.fasta"
DNA_FILENAME = "all_arg_nonarg_dna.fasta"
STRUCTURE_FILENAME = "all_arg_nonarg_structure.txt"

OUTPUT_DIRNAME = "paired_simulated_fragments_5parts"

# None = automatically detect all folders matching ARG1_nonARG*
# Example:
# SELECTED_RATIOS = [1, 10, 20]
SELECTED_RATIOS = None

PARTS_PER_ORIGINAL = 5
GLOBAL_RANDOM_SEED = 20260817
FASTA_LINE_WIDTH = 80
STRUCTURE_ID_COLUMN = "SARG.Seq.ID"

# False:
# Always retain five parts. Very short sequences may have repeated start sites
# when fewer than five distinct valid starts exist.
#
# True:
# Exclude an original from that condition unless five unique starts exist.
REQUIRE_FIVE_UNIQUE_STARTS = False

SCRIPT_VERSION = "2026-08-18-multiratio-paired-fragments-5parts-v2-autopath"


# =============================================================================
# 2. DATA CLASSES / CONDITIONS
# =============================================================================

@dataclass(frozen=True)
class FastaRecord:
    seq_id: str
    header: str
    sequence: str


@dataclass(frozen=True)
class Condition:
    name: str
    fixed_aa_length: int | None = None
    fraction: float | None = None

    def fragment_aa_length(
        self,
        full_aa_length: int,
    ) -> int:
        if self.fixed_aa_length is not None:
            return self.fixed_aa_length

        assert self.fraction is not None

        return max(
            1,
            math.floor(
                full_aa_length
                * self.fraction
            ),
        )

    @property
    def protein_filename(self) -> str:
        if self.fixed_aa_length is not None:
            return (
                f"protein_"
                f"{self.fixed_aa_length}aa_5parts.fasta"
            )

        return (
            f"protein_"
            f"{int(self.fraction * 100)}pct_5parts.fasta"
        )

    @property
    def dna_filename(self) -> str:
        if self.fixed_aa_length is not None:
            return (
                f"dna_"
                f"{self.fixed_aa_length * 3}nt_5parts.fasta"
            )

        return (
            f"dna_"
            f"{int(self.fraction * 100)}pct_5parts.fasta"
        )

    @property
    def structure_filename(self) -> str:
        if self.fixed_aa_length is not None:
            return (
                f"structure_{self.fixed_aa_length}aa_"
                f"{self.fixed_aa_length * 3}nt_5parts.txt"
            )

        return (
            f"structure_"
            f"{int(self.fraction * 100)}pct_5parts.txt"
        )


ALL_CONDITIONS = [
    Condition(
        "fixed_30aa_90nt",
        fixed_aa_length=30,
    ),
    Condition(
        "fixed_40aa_120nt",
        fixed_aa_length=40,
    ),
    Condition(
        "fixed_50aa_150nt",
        fixed_aa_length=50,
    ),
    Condition(
        "percent_60",
        fraction=0.60,
    ),
    Condition(
        "percent_70",
        fraction=0.70,
    ),
    Condition(
        "percent_80",
        fraction=0.80,
    ),
    Condition(
        "percent_90",
        fraction=0.90,
    ),
]


EXTRA_STRUCTURE_COLUMNS = [
    "Original.SARG.Seq.ID",
    "Simulation.condition",
    "Simulation.part",
    "AA.start.0based",
    "AA.end.exclusive",
    "AA.length",
    "NT.start.0based",
    "NT.end.exclusive",
    "NT.length",
    "Target.fraction",
    "Random.seed",
]


# =============================================================================
# 3. BIOLOGICAL TABLES
# =============================================================================

CODON_TABLE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

ALTERNATIVE_START_CODONS = {
    "GTG",
    "TTG",
    "CTG",
    "ATA",
    "ATT",
    "ATC",
}

AMBIGUOUS_PROTEIN_RESIDUES = set(
    "XBZJUO"
)

VALID_DNA = set(
    "ACGTRYSWKMBDHVN"
)

VALID_PROTEIN = set(
    "ACDEFGHIKLMNPQRSTVWYXBZJUO*"
)


# =============================================================================
# 4. ARGUMENTS
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate five codon-aligned protein/DNA fragments for "
            "multiple ARG:nonARG ratio datasets."
        )
    )

    parser.add_argument(
        "--base-dir",
        type=Path,
        default=BASE_DIR,
    )

    parser.add_argument(
        "--ratios",
        nargs="*",
        type=int,
        default=SELECTED_RATIOS,
        help=(
            "Optional nonARG ratios. Example: --ratios 1 5 10 20. "
            "Default auto-detects all ARG1_nonARG* folders."
        ),
    )

    parser.add_argument(
        "--parts",
        type=int,
        default=PARTS_PER_ORIGINAL,
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=GLOBAL_RANDOM_SEED,
    )

    parser.add_argument(
        "--require-unique-starts",
        action="store_true",
        default=REQUIRE_FIVE_UNIQUE_STARTS,
    )

    parser.add_argument(
        "--conditions",
        nargs="*",
        choices=[
            condition.name
            for condition
            in ALL_CONDITIONS
        ],
        default=None,
        help=(
            "Optional subset. Default generates all seven conditions."
        ),
    )

    parser.add_argument(
        "--audit-only",
        action="store_true",
        help=(
            "Validate all selected ratio datasets without creating "
            "simulated fragment files."
        ),
    )

    return parser.parse_args()


# =============================================================================
# 5. INPUT DISCOVERY
# =============================================================================

def ratio_from_folder_name(
    name: str,
) -> int | None:
    match = re.fullmatch(
        r"ARG1_nonARG(\d+)",
        name,
    )

    if not match:
        return None

    return int(
        match.group(1)
    )


def discover_ratio_dirs(
    base_dir: Path,
    selected_ratios: list[int] | None,
) -> list[tuple[int, Path]]:

    if selected_ratios is not None:

        ratios = sorted(
            set(
                int(x)
                for x
                in selected_ratios
            )
        )

        if any(
            ratio < 1
            for ratio
            in ratios
        ):
            raise ValueError(
                "All ratios must be >= 1."
            )

        candidates = [
            (
                ratio,
                base_dir
                / f"ARG1_nonARG{ratio}",
            )
            for ratio
            in ratios
        ]

    else:

        candidates = []

        for path in base_dir.iterdir():

            if not path.is_dir():
                continue

            ratio = ratio_from_folder_name(
                path.name
            )

            if ratio is not None:
                candidates.append(
                    (
                        ratio,
                        path,
                    )
                )

        candidates.sort(
            key=lambda item:
            item[0]
        )

    if not candidates:
        raise FileNotFoundError(
            "No ARG1_nonARG* dataset folders found in:\n"
            f"  {base_dir}"
        )

    missing = []

    for ratio, ratio_dir in candidates:

        required = [
            ratio_dir
            / PROTEIN_FILENAME,
            ratio_dir
            / DNA_FILENAME,
            ratio_dir
            / STRUCTURE_FILENAME,
        ]

        missing_files = [
            path
            for path
            in required
            if not path.is_file()
        ]

        if missing_files:
            missing.append(
                (
                    ratio,
                    missing_files,
                )
            )

    if missing:

        lines = []

        for ratio, missing_files in missing:

            lines.append(
                f"ARG1_nonARG{ratio}:"
            )

            lines.extend(
                f"  {path}"
                for path
                in missing_files
            )

        raise FileNotFoundError(
            "Missing required dataset file(s):\n"
            + "\n".join(lines)
        )

    return candidates


# =============================================================================
# 6. FASTA / STRUCTURE I/O
# =============================================================================

def read_fasta(
    path: Path,
) -> dict[str, FastaRecord]:

    records: dict[
        str,
        FastaRecord,
    ] = {}

    header: str | None = None

    sequence_parts: list[str] = []

    def store_record() -> None:

        if header is None:
            return

        seq_id = (
            header.split()[0]
        )

        if seq_id in records:
            raise ValueError(
                f"Duplicate FASTA ID in "
                f"{path}: {seq_id}"
            )

        sequence = (
            "".join(sequence_parts)
            .upper()
            .replace(" ", "")
        )

        if not sequence:
            raise ValueError(
                f"Empty FASTA sequence in "
                f"{path}: {seq_id}"
            )

        records[
            seq_id
        ] = FastaRecord(
            seq_id,
            header,
            sequence,
        )

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line_number, raw_line in enumerate(
            handle,
            start=1,
        ):

            line = raw_line.strip()

            if not line:
                continue

            if line.startswith(">"):

                store_record()

                header = (
                    line[1:].strip()
                )

                if not header:
                    raise ValueError(
                        f"Empty FASTA header at "
                        f"{path}:{line_number}"
                    )

                sequence_parts = []

            else:

                if header is None:
                    raise ValueError(
                        "Sequence before first header at "
                        f"{path}:{line_number}"
                    )

                sequence_parts.append(
                    "".join(
                        line.split()
                    )
                )

    store_record()

    return records


def read_structure(
    path: Path,
):
    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        if not reader.fieldnames:
            raise ValueError(
                f"Structure has no header: {path}"
            )

        fieldnames = list(
            reader.fieldnames
        )

        if STRUCTURE_ID_COLUMN not in fieldnames:
            raise ValueError(
                "Structure missing required column "
                f"{STRUCTURE_ID_COLUMN!r}: {path}"
            )

        rows: dict[
            str,
            dict[str, str],
        ] = {}

        for line_number, row in enumerate(
            reader,
            start=2,
        ):

            seq_id = (
                row.get(
                    STRUCTURE_ID_COLUMN
                )
                or ""
            ).strip()

            if not seq_id:
                raise ValueError(
                    f"Empty structure ID at "
                    f"{path}:{line_number}"
                )

            if seq_id in rows:
                raise ValueError(
                    f"Duplicate structure ID: {seq_id}"
                )

            rows[
                seq_id
            ] = dict(row)

    return (
        fieldnames,
        rows,
    )


# =============================================================================
# 7. INPUT VALIDATION
# =============================================================================

def translate_dna(
    dna: str,
) -> str:

    return "".join(
        CODON_TABLE.get(
            dna[
                index:
                index + 3
            ],
            "X",
        )
        for index
        in range(
            0,
            len(dna) - 2,
            3,
        )
    )


def infer_label_fields(
    structure_fieldnames: list[str],
) -> tuple[
    str | None,
    str | None,
]:

    type_field = next(
        (
            field
            for field
            in structure_fieldnames
            if field.strip().lower()
            == "type"
        ),
        None,
    )

    subtype_field = next(
        (
            field
            for field
            in structure_fieldnames
            if field.strip().lower()
            == "subtype"
        ),
        None,
    )

    return (
        type_field,
        subtype_field,
    )


def is_nonarg_row(
    row: dict[str, str],
    type_field: str | None,
    subtype_field: str | None,
) -> bool:

    type_value = (
        (
            row.get(type_field)
            or ""
        ).strip().lower()
        if type_field
        else ""
    )

    subtype_value = (
        (
            row.get(subtype_field)
            or ""
        ).strip().lower()
        if subtype_field
        else ""
    )

    return (
        type_value == "nonarg"
        or subtype_value == "nonarg"
    )


def validate_inputs(
    proteins: dict[str, FastaRecord],
    dnas: dict[str, FastaRecord],
    structure_fieldnames: list[str],
    structure_rows: dict[str, dict[str, str]],
) -> dict[str, int | float]:

    protein_ids = set(
        proteins
    )

    dna_ids = set(
        dnas
    )

    structure_ids = set(
        structure_rows
    )

    if (
        protein_ids != dna_ids
        or protein_ids != structure_ids
    ):

        details = {
            "protein_only":
                sorted(
                    protein_ids
                    - dna_ids
                    - structure_ids
                )[:10],

            "dna_only":
                sorted(
                    dna_ids
                    - protein_ids
                    - structure_ids
                )[:10],

            "structure_only":
                sorted(
                    structure_ids
                    - protein_ids
                    - dna_ids
                )[:10],

            "protein_not_dna":
                sorted(
                    protein_ids
                    - dna_ids
                )[:10],

            "dna_not_protein":
                sorted(
                    dna_ids
                    - protein_ids
                )[:10],

            "protein_not_structure":
                sorted(
                    protein_ids
                    - structure_ids
                )[:10],

            "structure_not_protein":
                sorted(
                    structure_ids
                    - protein_ids
                )[:10],
        }

        raise ValueError(
            "Protein, DNA and structure ID sets "
            "are not identical:\n"
            + json.dumps(
                details,
                ensure_ascii=False,
                indent=2,
            )
        )

    exact_pairs = 0
    ambiguous_compatible_pairs = 0
    alternative_start_pairs = 0
    terminal_stop_pairs = 0
    no_terminal_stop_pairs = 0

    for seq_id, protein_record in proteins.items():

        protein = (
            protein_record.sequence
        )

        dna = (
            dnas[
                seq_id
            ]
            .sequence
            .replace(
                "U",
                "T",
            )
        )

        invalid_protein = sorted(
            set(protein)
            - VALID_PROTEIN
        )

        invalid_dna = sorted(
            set(dna)
            - VALID_DNA
        )

        if invalid_protein:
            raise ValueError(
                "Invalid protein character(s), "
                f"{seq_id}: {invalid_protein}"
            )

        if invalid_dna:
            raise ValueError(
                "Invalid DNA character(s), "
                f"{seq_id}: {invalid_dna}"
            )

        coding_nt_length = (
            3 * len(protein)
        )

        extra_nt = (
            len(dna)
            - coding_nt_length
        )

        if extra_nt not in (
            0,
            3,
        ):
            raise ValueError(
                "DNA length is not 3*protein or "
                f"3*protein+3 for {seq_id}: "
                f"protein={len(protein)}, "
                f"DNA={len(dna)}, "
                f"extra={extra_nt}"
            )

        if extra_nt == 3:

            terminal_translation = (
                translate_dna(
                    dna[
                        coding_nt_length:
                    ]
                )
            )

            if terminal_translation not in {
                "*",
                "X",
            }:
                raise ValueError(
                    "Extra terminal codon is not a stop "
                    f"for {seq_id}: "
                    f"{dna[coding_nt_length:]}"
                )

            terminal_stop_pairs += 1

        else:

            no_terminal_stop_pairs += 1

        translated = (
            translate_dna(
                dna[
                    :coding_nt_length
                ]
            )
        )

        alternative_start_used = False
        ambiguous_used = False
        mismatch_positions: list[int] = []

        for index, (
            observed_aa,
            expected_aa,
        ) in enumerate(
            zip(
                translated,
                protein,
            )
        ):

            if observed_aa == expected_aa:
                continue

            codon = dna[
                index * 3:
                index * 3 + 3
            ]

            if (
                index == 0
                and expected_aa == "M"
                and codon
                in ALTERNATIVE_START_CODONS
            ):

                alternative_start_used = True
                continue

            if (
                observed_aa == "X"
                or expected_aa
                in AMBIGUOUS_PROTEIN_RESIDUES
            ):

                ambiguous_used = True
                continue

            mismatch_positions.append(
                index
            )

        if mismatch_positions:
            raise ValueError(
                f"Translation mismatch for {seq_id}; "
                "first positions: "
                f"{mismatch_positions[:10]}"
            )

        if alternative_start_used:
            alternative_start_pairs += 1

        elif ambiguous_used:
            ambiguous_compatible_pairs += 1

        else:
            exact_pairs += 1

    (
        type_field,
        subtype_field,
    ) = infer_label_fields(
        structure_fieldnames
    )

    input_nonarg = sum(
        1
        for row
        in structure_rows.values()
        if is_nonarg_row(
            row,
            type_field,
            subtype_field,
        )
    )

    input_arg = (
        len(structure_rows)
        - input_nonarg
    )

    return {
        "protein_records": len(
            proteins
        ),
        "dna_records": len(
            dnas
        ),
        "structure_rows": len(
            structure_rows
        ),
        "verified_pairs": len(
            proteins
        ),
        "ARG_original_pairs": input_arg,
        "nonARG_original_pairs": input_nonarg,
        "effective_input_nonARG_per_ARG": (
            input_nonarg / input_arg
            if input_arg
            else 0.0
        ),
        "exact_translation_pairs":
            exact_pairs,
        "ambiguous_compatible_pairs":
            ambiguous_compatible_pairs,
        "alternative_start_codon_pairs":
            alternative_start_pairs,
        "pairs_with_terminal_stop_codon":
            terminal_stop_pairs,
        "pairs_without_terminal_stop_codon":
            no_terminal_stop_pairs,
    }


# =============================================================================
# 8. SIMULATION RANDOMIZATION
# =============================================================================

def stable_rng(
    global_seed: int,
    seq_id: str,
    condition_name: str,
) -> random.Random:

    text = (
        f"{global_seed}\0"
        f"{seq_id}\0"
        f"{condition_name}"
    ).encode(
        "utf-8"
    )

    digest = hashlib.sha256(
        text
    ).digest()

    local_seed = int.from_bytes(
        digest[:8],
        byteorder="big",
        signed=False,
    )

    return random.Random(
        local_seed
    )


def stratified_random_starts(
    maximum_start: int,
    parts: int,
    rng: random.Random,
) -> list[int]:

    number_of_positions = (
        maximum_start + 1
    )

    if number_of_positions >= parts:

        starts = []

        for part_index in range(
            parts
        ):

            lower = (
                part_index
                * number_of_positions
            ) // parts

            upper_exclusive = (
                (
                    part_index + 1
                )
                * number_of_positions
            ) // parts

            starts.append(
                rng.randrange(
                    lower,
                    upper_exclusive,
                )
            )

        return starts

    if parts == 1:
        return [
            maximum_start // 2
        ]

    return [
        round(
            i
            * maximum_start
            / (parts - 1)
        )
        for i
        in range(parts)
    ]


# =============================================================================
# 9. OUTPUT HELPERS
# =============================================================================

def wrap_fasta(
    sequence: str,
    width: int = FASTA_LINE_WIDTH,
) -> str:

    return "\n".join(
        sequence[
            index:
            index + width
        ]
        for index
        in range(
            0,
            len(sequence),
            width,
        )
    )


def iter_fasta_ids(
    path: Path,
) -> Iterator[str]:

    with path.open(
        "r",
        encoding="utf-8-sig",
    ) as handle:

        for line in handle:

            if line.startswith(">"):

                yield (
                    line[1:]
                    .strip()
                    .split()[0]
                )


def read_structure_ids(
    path: Path,
) -> list[str]:

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        reader = csv.DictReader(
            handle,
            delimiter="\t",
        )

        return [
            (
                row.get(
                    STRUCTURE_ID_COLUMN
                )
                or ""
            ).strip()
            for row
            in reader
        ]


def write_json(
    path: Path,
    payload: dict,
) -> None:

    with path.open(
        "w",
        encoding="utf-8",
    ) as handle:

        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )


# =============================================================================
# 10. GENERATE ONE CONDITION
# =============================================================================

def generate_condition(
    condition: Condition,
    proteins: dict[str, FastaRecord],
    dnas: dict[str, FastaRecord],
    structure_fieldnames: list[str],
    structure_rows: dict[str, dict[str, str]],
    output_root: Path,
    parts: int,
    global_seed: int,
    require_unique_starts: bool,
) -> dict[str, object]:

    condition_dir = (
        output_root
        / condition.name
    )

    condition_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    protein_output = (
        condition_dir
        / condition.protein_filename
    )

    dna_output = (
        condition_dir
        / condition.dna_filename
    )

    structure_output = (
        condition_dir
        / condition.structure_filename
    )

    output_fields = list(
        structure_fieldnames
    )

    for field in EXTRA_STRUCTURE_COLUMNS:

        if field not in output_fields:
            output_fields.append(
                field
            )

    (
        type_field,
        subtype_field,
    ) = infer_label_fields(
        structure_fieldnames
    )

    included_originals = 0
    included_arg_originals = 0
    included_nonarg_originals = 0

    excluded_too_short = 0
    excluded_too_short_arg = 0
    excluded_too_short_nonarg = 0

    excluded_insufficient_unique_starts = 0
    excluded_unique_arg = 0
    excluded_unique_nonarg = 0

    originals_with_repeated_starts = 0
    repeated_fragment_records = 0

    generated_records = 0
    generated_arg_records = 0
    generated_nonarg_records = 0

    with (
        protein_output.open(
            "w",
            encoding="utf-8",
            newline="\n",
        ) as protein_handle,

        dna_output.open(
            "w",
            encoding="utf-8",
            newline="\n",
        ) as dna_handle,

        structure_output.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as structure_handle,
    ):

        structure_writer = csv.DictWriter(
            structure_handle,
            fieldnames=output_fields,
            delimiter="\t",
            extrasaction="ignore",
            lineterminator="\n",
        )

        structure_writer.writeheader()

        for seq_id, protein_record in proteins.items():

            original_row = (
                structure_rows[
                    seq_id
                ]
            )

            is_nonarg = is_nonarg_row(
                original_row,
                type_field,
                subtype_field,
            )

            full_protein = (
                protein_record.sequence
            )

            full_dna = (
                dnas[
                    seq_id
                ]
                .sequence
                .replace(
                    "U",
                    "T",
                )
            )

            aa_length = (
                condition.fragment_aa_length(
                    len(full_protein)
                )
            )

            if aa_length > len(full_protein):

                excluded_too_short += 1

                if is_nonarg:
                    excluded_too_short_nonarg += 1
                else:
                    excluded_too_short_arg += 1

                continue

            maximum_start = (
                len(full_protein)
                - aa_length
            )

            available_starts = (
                maximum_start + 1
            )

            if (
                require_unique_starts
                and available_starts < parts
            ):

                excluded_insufficient_unique_starts += 1

                if is_nonarg:
                    excluded_unique_nonarg += 1
                else:
                    excluded_unique_arg += 1

                continue

            rng = stable_rng(
                global_seed,
                seq_id,
                condition.name,
            )

            starts = (
                stratified_random_starts(
                    maximum_start,
                    parts,
                    rng,
                )
            )

            unique_starts = len(
                set(starts)
            )

            if unique_starts < parts:

                originals_with_repeated_starts += 1

                repeated_fragment_records += (
                    parts
                    - unique_starts
                )

            included_originals += 1

            if is_nonarg:
                included_nonarg_originals += 1
            else:
                included_arg_originals += 1

            for part_number, aa_start in enumerate(
                starts,
                start=1,
            ):

                aa_end = (
                    aa_start
                    + aa_length
                )

                nt_start = (
                    aa_start * 3
                )

                nt_end = (
                    aa_end * 3
                )

                protein_fragment = (
                    full_protein[
                        aa_start:
                        aa_end
                    ]
                )

                dna_fragment = (
                    full_dna[
                        nt_start:
                        nt_end
                    ]
                )

                if (
                    len(protein_fragment)
                    != aa_length
                    or len(dna_fragment)
                    != 3 * aa_length
                ):
                    raise RuntimeError(
                        "Internal slicing error for "
                        f"{seq_id}"
                    )

                fragment_id = (
                    f"{seq_id}"
                    f"__SIM_{condition.name}"
                    f"__P{part_number:02d}"
                    f"__A{aa_start:06d}"
                )

                target_fraction = (
                    f"{condition.fraction:.2f}"
                    if condition.fraction
                    is not None
                    else ""
                )

                description = (
                    f"original_id={seq_id} "
                    f"condition={condition.name} "
                    f"part={part_number} "
                    f"aa_start={aa_start} "
                    f"aa_length={aa_length} "
                    f"nt_start={nt_start} "
                    f"nt_length={len(dna_fragment)}"
                )

                protein_handle.write(
                    f">{fragment_id} "
                    f"{description}\n"
                    f"{wrap_fasta(protein_fragment)}\n"
                )

                dna_handle.write(
                    f">{fragment_id} "
                    f"{description}\n"
                    f"{wrap_fasta(dna_fragment)}\n"
                )

                output_row = dict(
                    original_row
                )

                output_row[
                    STRUCTURE_ID_COLUMN
                ] = fragment_id

                output_row.update(
                    {
                        "Original.SARG.Seq.ID":
                            seq_id,

                        "Simulation.condition":
                            condition.name,

                        "Simulation.part":
                            str(part_number),

                        "AA.start.0based":
                            str(aa_start),

                        "AA.end.exclusive":
                            str(aa_end),

                        "AA.length":
                            str(aa_length),

                        "NT.start.0based":
                            str(nt_start),

                        "NT.end.exclusive":
                            str(nt_end),

                        "NT.length":
                            str(
                                len(
                                    dna_fragment
                                )
                            ),

                        "Target.fraction":
                            target_fraction,

                        "Random.seed":
                            str(global_seed),
                    }
                )

                structure_writer.writerow(
                    output_row
                )

                generated_records += 1

                if is_nonarg:
                    generated_nonarg_records += 1
                else:
                    generated_arg_records += 1

    # -------------------------------------------------------------------------
    # Output correspondence audit
    # -------------------------------------------------------------------------

    protein_ids = list(
        iter_fasta_ids(
            protein_output
        )
    )

    dna_ids = list(
        iter_fasta_ids(
            dna_output
        )
    )

    structure_ids = (
        read_structure_ids(
            structure_output
        )
    )

    ids_correspond = (
        protein_ids
        == dna_ids
        == structure_ids
    )

    if not ids_correspond:
        raise RuntimeError(
            "Output ID/order audit failed for "
            f"{condition.name}"
        )

    if (
        generated_records
        != len(protein_ids)
    ):
        raise RuntimeError(
            "Output record count audit failed for "
            f"{condition.name}"
        )

    effective_ratio = (
        generated_nonarg_records
        / generated_arg_records
        if generated_arg_records
        else 0.0
    )

    summary = {
        "condition":
            condition.name,

        "input_original_pairs":
            len(proteins),

        "included_original_pairs":
            included_originals,

        "included_ARG_original_pairs":
            included_arg_originals,

        "included_nonARG_original_pairs":
            included_nonarg_originals,

        "effective_included_nonARG_per_ARG":
            (
                included_nonarg_originals
                / included_arg_originals
                if included_arg_originals
                else 0.0
            ),

        "excluded_too_short":
            excluded_too_short,

        "excluded_too_short_ARG":
            excluded_too_short_arg,

        "excluded_too_short_nonARG":
            excluded_too_short_nonarg,

        "excluded_insufficient_unique_starts":
            excluded_insufficient_unique_starts,

        "excluded_unique_ARG":
            excluded_unique_arg,

        "excluded_unique_nonARG":
            excluded_unique_nonarg,

        "parts_per_original":
            parts,

        "generated_protein_records":
            generated_records,

        "generated_dna_records":
            generated_records,

        "generated_structure_rows":
            generated_records,

        "generated_ARG_fragment_records":
            generated_arg_records,

        "generated_nonARG_fragment_records":
            generated_nonarg_records,

        "effective_fragment_nonARG_per_ARG":
            effective_ratio,

        "originals_with_repeated_starts":
            originals_with_repeated_starts,

        "repeated_fragment_records":
            repeated_fragment_records,

        "protein_DNA_structure_ID_order_identical":
            ids_correspond,

        "protein_fasta":
            str(protein_output),

        "dna_fasta":
            str(dna_output),

        "structure_file":
            str(structure_output),
    }

    write_json(
        condition_dir
        / "simulation_summary.json",
        summary,
    )

    return summary


# =============================================================================
# 11. PROCESS ONE RATIO DATASET
# =============================================================================

def process_ratio_dataset(
    ratio: int,
    ratio_dir: Path,
    conditions: list[Condition],
    args: argparse.Namespace,
) -> dict:

    protein_path = (
        ratio_dir
        / PROTEIN_FILENAME
    )

    dna_path = (
        ratio_dir
        / DNA_FILENAME
    )

    structure_path = (
        ratio_dir
        / STRUCTURE_FILENAME
    )

    output_dir = (
        ratio_dir
        / OUTPUT_DIRNAME
    )

    print()
    print(
        "#" * 118
    )
    print(
        f"ARG:nonARG = 1:{ratio}"
    )
    print(
        "#" * 118
    )
    print(
        f"Protein FASTA    : {protein_path}"
    )
    print(
        f"DNA FASTA        : {dna_path}"
    )
    print(
        f"Structure        : {structure_path}"
    )
    print(
        f"Output directory : {output_dir}"
    )

    proteins = read_fasta(
        protein_path
    )

    dnas = read_fasta(
        dna_path
    )

    (
        structure_fieldnames,
        structure_rows,
    ) = read_structure(
        structure_path
    )

    audit = validate_inputs(
        proteins,
        dnas,
        structure_fieldnames,
        structure_rows,
    )

    print()
    print(
        "INPUT CORRESPONDENCE AUDIT"
    )

    for key, value in audit.items():
        print(
            f"{key:42s}: {value}"
        )

    print(
        "ID sets identical                        : True"
    )
    print(
        "Protein/DNA codon coordinates valid     : True"
    )

    if args.audit_only:

        return {
            "ratio":
                ratio,

            "ratio_name":
                f"ARG1_nonARG{ratio}",

            "dataset_directory":
                str(ratio_dir),

            "audit_only":
                True,

            **audit,
        }

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    write_json(
        output_dir
        / "input_pair_audit.json",
        audit,
    )

    condition_summaries: list[
        dict[str, object]
    ] = []

    for index, condition in enumerate(
        conditions,
        start=1,
    ):

        print()
        print(
            "-" * 118
        )
        print(
            f"[1:{ratio}] "
            f"[{index}/{len(conditions)}] "
            f"Generating {condition.name}"
        )

        summary = generate_condition(
            condition=condition,
            proteins=proteins,
            dnas=dnas,
            structure_fieldnames=structure_fieldnames,
            structure_rows=structure_rows,
            output_root=output_dir,
            parts=args.parts,
            global_seed=args.seed,
            require_unique_starts=args.require_unique_starts,
        )

        condition_summaries.append(
            summary
        )

        print(
            "Included originals       : "
            f"{summary['included_original_pairs']}"
        )
        print(
            "  ARG originals          : "
            f"{summary['included_ARG_original_pairs']}"
        )
        print(
            "  nonARG originals       : "
            f"{summary['included_nonARG_original_pairs']}"
        )
        print(
            "Generated paired parts   : "
            f"{summary['generated_protein_records']}"
        )
        print(
            "  ARG fragments          : "
            f"{summary['generated_ARG_fragment_records']}"
        )
        print(
            "  nonARG fragments       : "
            f"{summary['generated_nonARG_fragment_records']}"
        )
        print(
            "Effective nonARG/ARG      : "
            f"{summary['effective_fragment_nonARG_per_ARG']:.6f}"
        )
        print(
            "Excluded too short       : "
            f"{summary['excluded_too_short']}"
        )
        print(
            "Repeated-start originals : "
            f"{summary['originals_with_repeated_starts']}"
        )
        print(
            "ID/order identical       : "
            f"{summary['protein_DNA_structure_ID_order_identical']}"
        )

    condition_summary_csv = (
        output_dir
        / "all_simulation_conditions_summary.csv"
    )

    with condition_summary_csv.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=list(
                condition_summaries[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            condition_summaries
        )

    run_config = {
        "script_version":
            SCRIPT_VERSION,

        "ratio":
            f"1:{ratio}",

        "parts_per_original":
            args.parts,

        "global_random_seed":
            args.seed,

        "require_unique_starts":
            args.require_unique_starts,

        "fixed_conditions": [
            "30aa/90nt",
            "40aa/120nt",
            "50aa/150nt",
        ],

        "percentage_conditions": [
            "60%",
            "70%",
            "80%",
            "90%",
        ],

        "percentage_length_rule":
            "floor(full_protein_length*fraction); DNA=3*AA",

        "start_selection":
            "reproducible stratified random across valid AA starts",

        "coordinate_rule":
            "NT_start=3*AA_start; NT_end=3*AA_end",

        "cross_ratio_reproducibility":
            (
                "Same sequence ID + same condition + same global seed "
                "produces identical fragment coordinates across ratios."
            ),
    }

    write_json(
        output_dir
        / "simulation_run_config.json",
        run_config,
    )

    return {
        "ratio":
            ratio,

        "ratio_name":
            f"ARG1_nonARG{ratio}",

        "dataset_directory":
            str(ratio_dir),

        "output_directory":
            str(output_dir),

        "input_original_pairs":
            len(proteins),

        "input_ARG_original_pairs":
            audit[
                "ARG_original_pairs"
            ],

        "input_nonARG_original_pairs":
            audit[
                "nonARG_original_pairs"
            ],

        "input_effective_nonARG_per_ARG":
            audit[
                "effective_input_nonARG_per_ARG"
            ],

        "conditions_generated":
            len(condition_summaries),

        "condition_summary_csv":
            str(condition_summary_csv),

        "audit_only":
            False,
    }


# =============================================================================
# 12. MAIN
# =============================================================================

def main() -> None:

    args = parse_args()

    base_dir = (
        args.base_dir
        .expanduser()
        .resolve()
    )

    if not base_dir.is_dir():
        raise NotADirectoryError(
            f"Base directory not found: {base_dir}"
        )

    if args.parts < 1:
        raise ValueError(
            "--parts must be positive"
        )

    selected_names = set(
        args.conditions
        or [
            condition.name
            for condition
            in ALL_CONDITIONS
        ]
    )

    conditions = [
        condition
        for condition
        in ALL_CONDITIONS
        if condition.name
        in selected_names
    ]

    ratio_datasets = (
        discover_ratio_dirs(
            base_dir,
            args.ratios,
        )
    )

    print(
        "=" * 118
    )
    print(
        "MULTI-RATIO PAIRED PROTEIN/DNA SIMULATED FRAGMENT GENERATION"
    )
    print(
        "=" * 118
    )
    print(
        f"Script version             : {SCRIPT_VERSION}"
    )
    print(
        f"Base directory             : {base_dir}"
    )
    print(
        "Detected ratio datasets   : "
        + ", ".join(
            f"1:{ratio}"
            for ratio, _
            in ratio_datasets
        )
    )
    print(
        f"Parts per original         : {args.parts}"
    )
    print(
        f"Global random seed         : {args.seed}"
    )
    print(
        "Require five unique starts : "
        f"{args.require_unique_starts}"
    )
    print(
        "Conditions                 : "
        + ", ".join(
            condition.name
            for condition
            in conditions
        )
    )
    print(
        f"Audit only                 : {args.audit_only}"
    )

    overall_rows = []

    for index, (
        ratio,
        ratio_dir,
    ) in enumerate(
        ratio_datasets,
        start=1,
    ):

        print()
        print(
            "=" * 118
        )
        print(
            f"RATIO DATASET "
            f"{index}/{len(ratio_datasets)}"
            f" -> 1:{ratio}"
        )
        print(
            "=" * 118
        )

        result = process_ratio_dataset(
            ratio=ratio,
            ratio_dir=ratio_dir,
            conditions=conditions,
            args=args,
        )

        overall_rows.append(
            result
        )

    overall_summary_csv = (
        base_dir
        / "ALL_RATIOS_simulation_summary.csv"
    )

    with overall_summary_csv.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:

        writer = csv.DictWriter(
            handle,
            fieldnames=list(
                overall_rows[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            overall_rows
        )

    overall_config = {
        "script_version":
            SCRIPT_VERSION,

        "base_directory":
            str(base_dir),

        "ratios_processed": [
            f"1:{ratio}"
            for ratio, _
            in ratio_datasets
        ],

        "parts_per_original":
            args.parts,

        "global_random_seed":
            args.seed,

        "conditions": [
            condition.name
            for condition
            in conditions
        ],

        "cross_ratio_fragment_rule":
            (
                "For an original sequence shared by multiple ratio datasets, "
                "the simulated coordinates are identical because RNG depends "
                "only on global seed, sequence ID and condition name."
            ),
    }

    write_json(
        base_dir
        / "ALL_RATIOS_simulation_run_config.json",
        overall_config,
    )

    print()
    print(
        "=" * 118
    )
    print(
        "ALL RATIO DATASETS COMPLETED"
    )
    print(
        "=" * 118
    )
    print(
        "Ratios processed : "
        + ", ".join(
            f"1:{ratio}"
            for ratio, _
            in ratio_datasets
        )
    )
    print(
        f"Conditions/ratio : {len(conditions)}"
    )
    print(
        f"Summary CSV      : {overall_summary_csv}"
    )
    print(
        f"Base directory   : {base_dir}"
    )


if __name__ == "__main__":
    try:
        main()

    except Exception as exc:

        print(
            f"\nERROR: {exc}",
            file=sys.stderr,
        )

        raise
