// Change only SVG canvas bounds. Preserve all vector geometry, text and data.
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const sharp=require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve('outputs/argscope_subtype_argonly_20260922/Figure2_Figure3_transparent_SVG');
function header(s,box){
 return s.replace(/<svg\b[^>]*>/,m=>m.replace(/\bwidth="[^"]*"/,`width="${box[2]}pt"`)
 .replace(/\bheight="[^"]*"/,`height="${box[3]}pt"`)
 .replace(/\bviewBox="[^"]*"/,`viewBox="${box.join(' ')}"`));
}
function digest(s){return crypto.createHash('sha256').update(s).digest('hex');}
(async()=>{
 const report=[];
 for(const folder of ['Figure2_Protein','Figure3_DNA'])for(const file of fs.readdirSync(path.join(root,folder)).filter(x=>x.endsWith('.svg'))){
  const p=path.join(root,folder,file), original=fs.readFileSync(p,'utf8');
  const box=original.match(/viewBox="([^"]+)"/)[1].split(/\s+/).map(Number);
  const margin=20, expanded=[box[0]-margin,box[1]-margin,box[2]+2*margin,box[3]+2*margin];
  const result=await sharp(Buffer.from(header(original,expanded)),{density:216}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const {width,height,channels}=result.info;
  let x0=width,y0=height,x1=-1,y1=-1;
  for(let y=0;y<height;y++)for(let x=0;x<width;x++)if(result.data[(y*width+x)*channels+channels-1]>0){
   x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);
  }
  if(x0<=2||y0<=2||x1>=width-3||y1>=height-3)throw Error('Expanded bounds insufficient: '+file);
  const sx=expanded[2]/width,sy=expanded[3]/height,guard=.2;
  const finalBox=[expanded[0]+x0*sx-guard,expanded[1]+y0*sy-guard,(x1-x0+1)*sx+2*guard,(y1-y0+1)*sy+2*guard].map(v=>+v.toFixed(6));
  const updated=header(original,finalBox);
  if(updated.replace(/<svg\b[^>]*>/,'<svg>')!==original.replace(/<svg\b[^>]*>/,'<svg>'))throw Error('Content altered');
  fs.writeFileSync(p,updated);
  report.push({file,original_viewBox:box,final_viewBox:finalBox,guard_pt:guard,
   only_canvas_bounds_changed:true,sha256_before:digest(original),sha256_after:digest(updated)});
 }
 fs.writeFileSync(path.join(root,'plot_data/canvas_crop_verification.json'),JSON.stringify(report,null,2));
 console.log('PASS: cropped 14 SVG canvas bounds without changing any vector objects.');
})().catch(e=>{console.error(e);process.exit(1)});
