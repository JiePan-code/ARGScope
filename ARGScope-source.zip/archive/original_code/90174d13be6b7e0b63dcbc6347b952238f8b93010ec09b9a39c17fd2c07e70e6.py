"""Recompute subtype metrics without reference nonARG, preserving missed ARGs."""
from pathlib import Path
import hashlib
import json
import math
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
ROOT = Path(r"E:\1. ARGmodel\1. NonARG_training\new model result8.24\1.training dataset\ALL_RESULT_NEW")
OUT = HERE / "outputs" / "argscope_subtype_argonly_20260922"
FIELDS = ["Accuracy", "Precision", "Recall", "F1", "MCC"]


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    data_out = OUT / "plot_data"
    data_out.mkdir(exist_ok=True)
    cols = ["Modality", "Completeness", "Level", "Scope", "Average", "N", "N_labels_averaged", "Source"] + FIELDS
    cache = pd.read_csv(ROOT / "calculation_cache" / "all_metrics.csv", usecols=cols)
    cache = cache[(cache.Level == "Subtype") & (cache.Scope == "ARG_only")]
    manifest = pd.read_csv(ROOT / "input_file_manifest.csv")
    results, checks, count_frames = [], [], []
    truth_cohorts = {}
    for modality in ["Protein", "DNA"]:
        for pct in [60, 70, 80, 90, 100]:
            ref = cache[(cache.Modality == modality) & (cache.Completeness == pct)]
            assert len(ref) == 3 and ref.Source.nunique() == 1
            path = Path(ref.Source.iloc[0])
            filehash = sha(path)
            expected_hash = manifest[manifest.Path == str(path)]
            assert len(expected_hash) == 1 and filehash == expected_hash.SHA256.iloc[0]
            df = pd.read_csv(path, keep_default_na=False)
            assert df.split.eq("test").all() and df.completeness_percent.eq(pct).all()
            assert df.sequence_id.is_unique
            assert df.true_subtype.eq("nonARG").equals(df.true_type.eq("nonARG"))
            positives = df.loc[df.true_subtype.ne("nonARG")].copy()
            assert not positives.true_subtype.eq("nonARG").any()
            assert len(positives) == int(ref.N.iloc[0])
            assert positives.true_subtype.ne("").all() and positives.predicted_subtype.ne("").all()
            y, p = positives.true_subtype.to_numpy(str), positives.predicted_subtype.to_numpy(str)
            universe = np.union1d(y, p)
            averaged = universe[universe != "nonARG"]
            assert len(averaged) == int(ref.N_labels_averaged.iloc[0])
            yi, pi = np.searchsorted(universe, y), np.searchsorted(universe, p)
            support = np.bincount(yi, minlength=len(universe)).astype(float)
            predictions = np.bincount(pi, minlength=len(universe)).astype(float)
            tp = np.bincount(yi[y == p], minlength=len(universe)).astype(float)
            fp, fn = predictions - tp, support - tp
            eligible = universe != "nonARG"
            div = lambda a, b: np.divide(a, b, out=np.zeros_like(np.asarray(a, dtype=float)), where=np.asarray(b) != 0)
            per_precision = div(tp, predictions)
            per_recall = div(tp, support)
            per_f1 = div(2*tp, 2*tp + fp + fn)
            n = len(y)
            acc = float(tp.sum()/n)
            denom = math.sqrt(max(0, (n*n-float(predictions@predictions))*(n*n-float(support@support))))
            mcc = float((tp.sum()*n-support@predictions)/denom) if denom else 0.0
            assert abs(acc-accuracy_score(y,p)) < 1e-12
            assert abs(mcc-matthews_corrcoef(y,p)) < 1e-12
            for average in ["macro", "weighted", "micro"]:
                pr, re, f1, _ = precision_recall_fscore_support(y,p,labels=averaged,average=average,zero_division=0)
                if average == "macro":
                    independent = [v[eligible].mean() for v in (per_precision,per_recall,per_f1)]
                elif average == "weighted":
                    independent = [float(v[eligible]@support[eligible]/support[eligible].sum()) for v in (per_precision,per_recall,per_f1)]
                else:
                    tt, ff, nn = tp[eligible].sum(), fp[eligible].sum(), fn[eligible].sum()
                    independent = [tt/(tt+ff),tt/(tt+nn),2*tt/(2*tt+ff+nn)]
                np.testing.assert_allclose([pr,re,f1],independent,atol=1e-12,rtol=0)
                values = [acc,float(pr),float(re),float(f1),mcc]
                expected = ref[ref.Average == average].iloc[0]
                np.testing.assert_allclose(values,expected[FIELDS].to_numpy(float),atol=1e-12,rtol=0)
                results.append(dict(Modality=modality,Model="ARGScope-AA" if modality=="Protein" else "ARGScope-NT",
                    Completeness=pct,Level="Subtype",Scope="ARG_only",Average=average,
                    N=n,N_labels_averaged=len(averaged),Source=str(path),**dict(zip(FIELDS,values))))
            counts = pd.DataFrame(dict(Subtype=universe,Support=support.astype(int),Predicted_count=predictions.astype(int),
                TP=tp.astype(int),FP=fp.astype(int),FN=fn.astype(int),Included_in_average=eligible))
            counts.insert(0,"Completeness",pct)
            counts.insert(0,"Modality",modality)
            count_frames.append(counts)
            checks.append(dict(Modality=modality,Completeness=pct,Source=str(path),SHA256=filehash,
                Total_test_sequences=len(df),Excluded_reference_nonARG=len(df)-n,Retained_ARG=n,
                Retained_missed_ARG=int((p=="nonARG").sum()),Averaged_ARG_subtypes=len(averaged),
                Zero_F1_subtypes_retained=int((per_f1[eligible]==0).sum()),Raw_calculation_matches_cache=True,
                Independent_formula_matches_sklearn=True))
            truth_cohorts[modality,pct] = positives.set_index("sequence_id").true_subtype.sort_index()
    for pct in [60,70,80,90,100]:
        pd.testing.assert_series_equal(truth_cohorts["Protein",pct],truth_cohorts["DNA",pct])
    result = pd.DataFrame(results)
    result.to_csv(data_out / "ARGScope_subtype_ARGonly_60_100_macro_weighted_micro.csv",index=False)
    pd.concat(count_frames,ignore_index=True).to_csv(data_out / "ARGScope_subtype_per_label_counts.csv",index=False)
    pd.DataFrame(checks).to_csv(data_out / "source_population_audit.csv",index=False)
    (data_out / "calculation_verification.json").write_text(json.dumps(dict(
        scope="Reference ARG sequences only. Predicted nonARG retained as errors. NonARG excluded from averaged labels.",
        paired_modality_truth_verified=True,checks=checks),ensure_ascii=False,indent=2),encoding="utf-8")
    print(result[(result.Completeness==100)&(result.Average=="macro")][["Modality"]+FIELDS].to_string(index=False))
    print("Verified",len(result),"metric rows from",len(checks),"prediction files")


if __name__ == "__main__":
    main()
