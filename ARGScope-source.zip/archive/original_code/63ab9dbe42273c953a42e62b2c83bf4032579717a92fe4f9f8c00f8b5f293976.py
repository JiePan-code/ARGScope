#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope Protein + DNA Student
Reference-style shared UNSUPERVISED UMAP
Split output: Protein 1 row x 6 columns + DNA 1 row x 6 columns
Each figure keeps its own full legend

Protein:
    Epoch 0 | Epoch 20 | Epoch 50 | Epoch 100 | Epoch 150 | Best model

DNA:
    Epoch 0 | Epoch 20 | Epoch 50 | Epoch 100 | Epoch 150 | Best model

This script follows the UMAP logic of the supplied reference script:
1. USE_SUPERVISED_UMAP = False
2. Stack all selected epoch representations within one modality.
3. Fit ONE shared UMAP to the stacked matrix.
4. Split the resulting 2-D coordinates back into epochs.
5. Use one global axis range within each modality row.
6. Type labels are used ONLY for coloring, not for UMAP fitting.

Expected folder structure:
    5.umap_figure/
    ├── plot_Protein_DNA_reference_style_shared_UMAP.py
    ├── Protein_epoch_features/
    │   ├── epoch_000_test_ARG_type_features.pt
    │   ├── epoch_020_test_ARG_type_features.pt
    │   ├── epoch_050_test_ARG_type_features.pt
    │   ├── epoch_100_test_ARG_type_features.pt
    │   ├── epoch_150_test_ARG_type_features.pt
    │   └── run_best_epoch_200_test_ARG_type_features.pt
    └── DNA_epoch_features/
        ├── epoch_000_test_ARG_type_features.pt
        ├── epoch_020_test_ARG_type_features.pt
        ├── epoch_050_test_ARG_type_features.pt
        ├── epoch_100_test_ARG_type_features.pt
        ├── epoch_150_test_ARG_type_features.pt
        └── run_best_epoch_084_test_ARG_type_features.pt

Expected PT keys:
    sequence_ids
    true_subtypes
    true_types
    features
"""

from __future__ import annotations

import re
import warnings
from collections import Counter
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from matplotlib.lines import Line2D

try:
    import umap
except ImportError as exc:
    raise ImportError(
        "Please install umap-learn first: pip install umap-learn"
    ) from exc


# =============================================================================
# 1. Paths
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent
PROTEIN_DIR = ROOT_DIR / "Protein_epoch_features"
DNA_DIR = ROOT_DIR / "DNA_epoch_features"

OUTPUT_DIR = ROOT_DIR / "shared_umap_reference_style"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 2. Selected epochs
# =============================================================================

PROTEIN_DISPLAY_EPOCHS = [0, 20, 50, 100, 150]
DNA_DISPLAY_EPOCHS = [0, 20, 50, 100, 150]

FIXED_PATTERN = re.compile(
    r"^epoch_(\d+)_test_ARG_type_features\.pt$",
    flags=re.IGNORECASE,
)

BEST_PATTERN = re.compile(
    r"^run_best_epoch_(\d+)_test_ARG_type_features\.pt$",
    flags=re.IGNORECASE,
)


# =============================================================================
# 3. UMAP settings
#    EXACTLY follows the supplied reference UMAP logic.
# =============================================================================

USE_SUPERVISED_UMAP = True
TARGET_WEIGHT = 0.10
RANDOM_STATE = 42

UMAP_PARAMS = dict(
    n_neighbors=25,
    min_dist=0.10,
    spread=1.25,
    metric="cosine",
    random_state=42,
)

SAVE_DPI = 600


# =============================================================================
# 4. Point / figure style
# =============================================================================

FONT_FAMILY = "Arial"

POINT_SIZE = 5.0
POINT_ALPHA = 0.62
POINT_LINEWIDTH = 0.0
EDGE_COLOR = "none"

FIG_WIDTH = 25.8
FIG_HEIGHT = 8.8
SINGLE_FIG_HEIGHT = 5.15

PANEL_TITLE_SIZE = 11.5
AXIS_LABEL_SIZE = 10.5
ROW_LABEL_SIZE = 14.0
LEGEND_FONT_SIZE = 8.8
LEGEND_MARKER_SIZE = 5.6
LEGEND_NCOL = 6

# Compact layout.
LEFT = 0.045
RIGHT = 0.985
TOP = 0.955
BOTTOM = 0.165
WSPACE = 0.10
HSPACE = 0.20

# Same idea as the reference script: one global axis range within each row.
GLOBAL_AXIS_PADDING = 0.035


# =============================================================================
# 5. Colors
# =============================================================================

# Keep the dominant/current main Type in light blue.
DOMINANT_TYPE_COLOR = "#A9D4F7"

TYPE_COLOR_LIST = [
    "#E64B35", "#1F78B4", "#00A087", "#3C5488", "#F39B7F",
    "#7E6148", "#4DBBD5", "#D00000", "#B09C85", "#91D1C2",
    "#A6CEE3", "#FF7F00", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDB462", "#6A3D9A", "#CAB2D6", "#B15928",
    "#5E548E", "#8C510A", "#80CDC1", "#35978F", "#F781BF",
    "#377EB8", "#FFB000", "#66A61E", "#E7298A", "#984EA3",
    "#A6DBA0",
]

DISPLAY_NAME_MAP = {
    "macrolide-lincosamide-streptogramin": "MLS",
}


# =============================================================================
# 6. Matplotlib style
# =============================================================================

warnings.filterwarnings("ignore", category=UserWarning)

mpl.rcParams.update({
    "font.family": FONT_FAMILY,
    "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans"],
    "font.size": 9,
    "axes.linewidth": 1.0,
    "axes.titlesize": PANEL_TITLE_SIZE,
    "axes.labelsize": AXIS_LABEL_SIZE,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": LEGEND_FONT_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 7. Utilities
# =============================================================================

def torch_load_cpu(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def parse_epoch_file(path: Path):
    m = BEST_PATTERN.fullmatch(path.name)
    if m:
        return int(m.group(1)), True

    m = FIXED_PATTERN.fullmatch(path.name)
    if m:
        return int(m.group(1)), False

    return None, None


def display_type_name(raw_name: str) -> str:
    return DISPLAY_NAME_MAP.get(raw_name, raw_name)


# =============================================================================
# 8. Snapshot discovery
# =============================================================================

def discover_snapshots(
    folder: Path,
    modality: str,
    display_epochs: list[int],
):
    if not folder.is_dir():
        raise FileNotFoundError(
            f"{modality} folder not found:\n{folder}"
        )

    regular = {}
    best = []

    print(f"\n[{modality}: detected snapshots]")

    for path in sorted(
        folder.glob("*_test_ARG_type_features.pt")
    ):
        epoch, is_best = parse_epoch_file(path)

        if epoch is None:
            continue

        if is_best:
            best.append((epoch, path))
            print(
                f"  BEST    | epoch={epoch:3d} | {path.name}"
            )
        else:
            regular[epoch] = path
            print(
                f"  regular | epoch={epoch:3d} | {path.name}"
            )

    missing = [
        epoch
        for epoch in display_epochs
        if epoch not in regular
    ]

    if missing:
        raise FileNotFoundError(
            f"{modality}: missing required epoch(s): {missing}"
        )

    if not best:
        raise FileNotFoundError(
            f"{modality}: no run_best_epoch_XXX_test_ARG_type_features.pt found."
        )

    best.sort(key=lambda x: x[0])
    best_epoch, best_path = best[-1]

    selected = [
        {
            "modality": modality,
            "epoch": epoch,
            "is_best": False,
            "path": regular[epoch],
            "title": f"Epoch {epoch}",
        }
        for epoch in display_epochs
    ]

    selected.append({
        "modality": modality,
        "epoch": best_epoch,
        "is_best": True,
        "path": best_path,
        "title": f"Best model (epoch {best_epoch})",
    })

    print(f"\n[{modality}: selected snapshots]")
    for item in selected:
        print(
            f"  epoch={item['epoch']:3d} | "
            f"best={str(item['is_best']):5s} | "
            f"{item['path'].name}"
        )

    return selected


# =============================================================================
# 9. Load snapshot
# =============================================================================

def load_snapshot(
    path: Path,
    modality: str,
):
    obj = torch_load_cpu(path)

    if not isinstance(obj, dict):
        raise TypeError(
            f"{path.name}: snapshot must be a dictionary."
        )

    required = {
        "sequence_ids",
        "true_subtypes",
        "true_types",
        "features",
    }

    missing = sorted(
        required - set(obj.keys())
    )

    if missing:
        raise KeyError(
            f"{path.name}: missing keys {missing}\n"
            f"Available keys: {sorted(map(str, obj.keys()))}"
        )

    ids = np.asarray(
        [str(x).strip() for x in obj["sequence_ids"]],
        dtype=object,
    )

    subtypes = np.asarray(
        [str(x).strip() for x in obj["true_subtypes"]],
        dtype=object,
    )

    types = np.asarray(
        [str(x).strip() for x in obj["true_types"]],
        dtype=object,
    )

    features = obj["features"]

    if isinstance(features, torch.Tensor):
        features = (
            features
            .detach()
            .cpu()
            .float()
            .numpy()
        )
    else:
        features = np.asarray(
            features,
            dtype=np.float32,
        )

    if features.ndim != 2:
        raise ValueError(
            f"{path.name}: features must be 2-D; "
            f"found {features.shape}"
        )

    n = features.shape[0]

    if not (
        len(ids)
        == len(subtypes)
        == len(types)
        == n
    ):
        raise ValueError(
            f"{path.name}: row-count mismatch."
        )

    if len(ids) != len(set(ids)):
        raise ValueError(
            f"{path.name}: duplicate sequence IDs detected."
        )

    if not np.isfinite(features).all():
        raise ValueError(
            f"{path.name}: features contain NaN or Inf."
        )

    print(
        f"\n[{modality} load] {path.name}\n"
        f"  rows        : {n:,}\n"
        f"  feature dim : {features.shape[1]}\n"
        f"  Type count  : {len(set(types))}"
    )

    return {
        "path": path,
        "ids": ids,
        "true_subtypes": subtypes,
        "true_types": types,
        "features": np.asarray(
            features,
            dtype=np.float32,
        ),
    }


# =============================================================================
# 10. Align epochs within each modality
# =============================================================================

def align_snapshots(
    snapshots: list[dict],
    modality: str,
):
    common_ids = set(
        snapshots[0]["ids"]
    )

    for snapshot in snapshots[1:]:
        common_ids &= set(
            snapshot["ids"]
        )

    if not common_ids:
        raise ValueError(
            f"{modality}: no common sequence IDs across snapshots."
        )

    first_ids = snapshots[0]["ids"].tolist()
    ordered_common = [
        x
        for x in first_ids
        if x in common_ids
    ]

    print(
        f"\n[{modality} alignment] "
        f"common samples across selected epochs: "
        f"{len(ordered_common):,}"
    )

    aligned = []

    for snapshot in snapshots:
        id_to_index = {
            sequence_id: index
            for index, sequence_id
            in enumerate(snapshot["ids"])
        }

        idx = np.asarray(
            [
                id_to_index[sequence_id]
                for sequence_id in ordered_common
            ],
            dtype=np.int64,
        )

        aligned.append({
            "path": snapshot["path"],
            "ids": snapshot["ids"][idx],
            "true_subtypes":
                snapshot["true_subtypes"][idx],
            "true_types":
                snapshot["true_types"][idx],
            "features":
                snapshot["features"][idx],
        })

    ref = aligned[0]

    for snapshot in aligned[1:]:
        if not np.array_equal(
            ref["ids"],
            snapshot["ids"],
        ):
            raise RuntimeError(
                f"{modality}: ID alignment failed."
            )

        if not np.array_equal(
            ref["true_types"],
            snapshot["true_types"],
        ):
            raise ValueError(
                f"{modality}: Type metadata differ across snapshots."
            )

        if (
            ref["features"].shape[1]
            != snapshot["features"].shape[1]
        ):
            raise ValueError(
                f"{modality}: feature dimensions differ."
            )

    return aligned


# =============================================================================
# 11. Reference-style shared UMAP
# =============================================================================

def compute_shared_umap(
    aligned: list[dict],
    modality: str,
):
    print(f"\n[{modality} shared UMAP]")
    print(f"  supervised = {USE_SUPERVISED_UMAP}")
    print(f"  params     = {UMAP_PARAMS}")

    blocks = [
        snapshot["features"]
        for snapshot in aligned
    ]

    X_all = np.vstack(
        blocks
    )

    sizes = [
        len(snapshot["ids"])
        for snapshot in aligned
    ]

    print(
        f"  combined matrix = {X_all.shape}"
    )

    reducer = umap.UMAP(
        **UMAP_PARAMS,
        target_metric=(
            "categorical"
            if USE_SUPERVISED_UMAP
            else "euclidean"
        ),
        target_weight=(
            TARGET_WEIGHT
            if USE_SUPERVISED_UMAP
            else 0.0
        ),
    )

    # Current setting is intentionally unsupervised.
    Z_all = reducer.fit_transform(
        X_all
    )

    Z_all = np.asarray(
        Z_all,
        dtype=np.float32,
    )

    coordinates = []
    cursor = 0

    for n in sizes:
        coordinates.append(
            Z_all[
                cursor:cursor + n
            ].copy()
        )
        cursor += n

    return coordinates


# =============================================================================
# 12. Color mapping
# =============================================================================

def build_color_mapping(
    protein_labels,
    dna_labels,
):
    protein_labels = np.asarray(
        protein_labels
    ).astype(str)

    dna_labels = np.asarray(
        dna_labels
    ).astype(str)

    combined_counts = Counter(
        list(protein_labels)
        + list(dna_labels)
    )

    all_types = sorted(
        set(protein_labels)
        | set(dna_labels),
        key=lambda x: x.lower(),
    )

    dominant_type = max(
        all_types,
        key=lambda x: combined_counts[x],
    )

    color_map = {
        dominant_type: DOMINANT_TYPE_COLOR
    }

    other_types = [
        x
        for x in all_types
        if x != dominant_type
    ]

    for i, type_name in enumerate(other_types):
        color_map[type_name] = (
            TYPE_COLOR_LIST[
                i % len(TYPE_COLOR_LIST)
            ]
        )

    print(
        f"\n[Colors] dominant Type: "
        f"{dominant_type} -> {DOMINANT_TYPE_COLOR}"
    )

    return (
        all_types,
        color_map,
        combined_counts,
    )


# =============================================================================
# 13. Global row axis ranges
# =============================================================================

def global_axis_limits(
    coordinates: list[np.ndarray],
):
    Z = np.vstack(
        coordinates
    )

    xmin = float(
        Z[:, 0].min()
    )
    xmax = float(
        Z[:, 0].max()
    )
    ymin = float(
        Z[:, 1].min()
    )
    ymax = float(
        Z[:, 1].max()
    )

    x_range = xmax - xmin
    y_range = ymax - ymin

    x_pad = max(
        x_range * GLOBAL_AXIS_PADDING,
        1.0e-6,
    )

    y_pad = max(
        y_range * GLOBAL_AXIS_PADDING,
        1.0e-6,
    )

    return (
        xmin - x_pad,
        xmax + x_pad,
        ymin - y_pad,
        ymax + y_pad,
    )


# =============================================================================
# 14. Plot helpers
# =============================================================================

def style_axis(
    axis,
    limits,
    show_ylabel=True,
):
    xmin, xmax, ymin, ymax = limits

    axis.set_xlim(
        xmin,
        xmax,
    )

    axis.set_ylim(
        ymin,
        ymax,
    )

    axis.set_xticks([])
    axis.set_yticks([])

    axis.set_xlabel(
        "UMAP1",
        labelpad=1.5,
    )

    if show_ylabel:
        axis.set_ylabel(
            "UMAP2",
            labelpad=1.5,
        )
    else:
        axis.set_ylabel("")

    for spine in axis.spines.values():
        spine.set_linewidth(
            1.0
        )
        spine.set_color(
            "black"
        )


def plot_snapshot(
    axis,
    Z,
    labels,
    item,
    color_map,
    limits,
    show_ylabel,
):
    labels = np.asarray(
        labels
    ).astype(str)

    # Large classes first, rare classes last.
    counts = pd.Series(
        labels
    ).value_counts(
        ascending=False
    )

    for label in counts.index:
        mask = (
            labels
            == label
        )

        axis.scatter(
            Z[mask, 0],
            Z[mask, 1],
            s=POINT_SIZE,
            c=color_map[label],
            alpha=POINT_ALPHA,
            linewidths=POINT_LINEWIDTH,
            edgecolors=EDGE_COLOR,
            rasterized=True,
        )

    style_axis(
        axis,
        limits,
        show_ylabel=show_ylabel,
    )

    axis.set_title(
        item["title"],
        fontweight=(
            "bold"
            if item["is_best"]
            else "normal"
        ),
        pad=5,
    )


def make_legend_handles(
    type_order,
    color_map,
):
    handles = []

    for raw_name in type_order:
        handles.append(
            Line2D(
                [0],
                [0],
                linestyle="none",
                marker="o",
                markerfacecolor=color_map[raw_name],
                markeredgecolor="none",
                markersize=LEGEND_MARKER_SIZE,
                label=display_type_name(raw_name),
            )
        )

    return handles


# =============================================================================
# 15. Plot Protein and DNA as TWO separate 1 x 6 figures
# =============================================================================

def plot_single_modality(
    modality,
    selected,
    aligned,
    coordinates,
    type_order,
    color_map,
):
    """
    Plot one modality as a standalone 1 x 6 UMAP figure.

    IMPORTANT
    ---------
    - UMAP coordinates are NOT recomputed here.
    - The exact same per-modality shared UMAP coordinates are used.
    - Point style, titles, colors, axis limits, legend style and output formats
      remain the same as in the original combined figure.
    - Each standalone figure keeps the full Type legend.
    """

    n_cols = len(selected)

    if len(aligned) != n_cols or len(coordinates) != n_cols:
        raise ValueError(
            f"{modality}: panel-count mismatch: "
            f"selected={len(selected)}, "
            f"aligned={len(aligned)}, "
            f"coordinates={len(coordinates)}"
        )

    fig, axes = plt.subplots(
        1,
        n_cols,
        figsize=(
            FIG_WIDTH,
            SINGLE_FIG_HEIGHT,
        ),
        dpi=SAVE_DPI,
        facecolor="white",
        squeeze=False,
    )

    axes = axes[0]

    limits = global_axis_limits(
        coordinates
    )

    labels = aligned[0][
        "true_types"
    ]

    for col, (
        axis,
        Z,
        item,
    ) in enumerate(
        zip(
            axes,
            coordinates,
            selected,
        )
    ):
        plot_snapshot(
            axis=axis,
            Z=Z,
            labels=labels,
            item=item,
            color_map=color_map,
            limits=limits,
            show_ylabel=(col == 0),
        )

    # Keep the left-side modality label, as in the original combined figure.
    # fig.text(
    #     0.018,
    #     0.585,
    #     modality,
    #     rotation=90,
    #     ha="center",
    #     va="center",
    #     fontsize=ROW_LABEL_SIZE,
    #     fontweight="bold",
    #     fontfamily=FONT_FAMILY,
    # )

    # Full-width legend retained for EACH standalone figure.
    handles = make_legend_handles(
        type_order,
        color_map,
    )

    fig.legend(
        handles=handles,
        loc="lower left",
        bbox_to_anchor=(
            LEFT,
            0.020,
            RIGHT - LEFT,
            0.145,
        ),
        mode="expand",
        ncol=LEGEND_NCOL,
        frameon=False,
        fontsize=LEGEND_FONT_SIZE,
        handlelength=0.8,
        handletextpad=0.30,
        columnspacing=1.10,
        labelspacing=0.55,
        borderaxespad=0.0,
    )

    # Preserve the original horizontal panel spacing.
    # Bottom is enlarged only because the legend now belongs to this figure.
    fig.subplots_adjust(
        left=LEFT,
        right=RIGHT,
        top=TOP,
        bottom=0.285,
        wspace=WSPACE,
    )

    prefix = (
        f"{modality}_reference_style_"
        f"shared_unsupervised_UMAP"
    )

    png = OUTPUT_DIR / f"{prefix}.png"
    pdf = OUTPUT_DIR / f"{prefix}.pdf"
    svg = OUTPUT_DIR / f"{prefix}.svg"

    fig.savefig(
        png,
        dpi=SAVE_DPI,
        bbox_inches="tight",
        pad_inches=0.06,
    )

    fig.savefig(
        pdf,
        bbox_inches="tight",
        pad_inches=0.06,
    )

    fig.savefig(
        svg,
        bbox_inches="tight",
        pad_inches=0.06,
    )

    plt.close(fig)

    print(
        f"\n[Saved {modality} figure]\n"
        f"  PNG : {png}\n"
        f"  PDF : {pdf}\n"
        f"  SVG : {svg}"
    )


def plot_separate_figures(
    protein_selected,
    dna_selected,
    protein_aligned,
    dna_aligned,
    protein_coordinates,
    dna_coordinates,
    type_order,
    color_map,
):
    """
    Save two separate figures:
      1) Protein: 1 x 6
      2) DNA:     1 x 6

    Both figures use the same unified Type-color mapping and each retains
    the complete legend.
    """

    plot_single_modality(
        modality="Protein",
        selected=protein_selected,
        aligned=protein_aligned,
        coordinates=protein_coordinates,
        type_order=type_order,
        color_map=color_map,
    )

    plot_single_modality(
        modality="DNA",
        selected=dna_selected,
        aligned=dna_aligned,
        coordinates=dna_coordinates,
        type_order=type_order,
        color_map=color_map,
    )


# =============================================================================
# 16. Save coordinates
# =============================================================================

def save_coordinates(
    modality,
    coordinates,
    selected,
    aligned,
):
    frames = []

    for Z, item, snapshot in zip(
        coordinates,
        selected,
        aligned,
    ):
        frames.append(
            pd.DataFrame({
                "modality": modality,
                "epoch": item["epoch"],
                "is_best": item["is_best"],
                "sequence_id": snapshot["ids"],
                "true_type": snapshot["true_types"],
                "true_subtype": snapshot["true_subtypes"],
                "UMAP1": Z[:, 0],
                "UMAP2": Z[:, 1],
            })
        )

    return pd.concat(
        frames,
        ignore_index=True,
    )


# =============================================================================
# 17. Main
# =============================================================================

def main():
    print("=" * 118)
    print(
        "ARGScope Protein + DNA: "
        "reference-style shared UNSUPERVISED UMAP"
    )
    print("=" * 118)

    print(f"ROOT_DIR     : {ROOT_DIR}")
    print(f"PROTEIN_DIR  : {PROTEIN_DIR}")
    print(f"DNA_DIR      : {DNA_DIR}")
    print(f"OUTPUT_DIR   : {OUTPUT_DIR}")
    print(f"UMAP params  : {UMAP_PARAMS}")
    print(f"Supervised   : {USE_SUPERVISED_UMAP}")

    # Protein
    protein_selected = discover_snapshots(
        PROTEIN_DIR,
        "Protein",
        PROTEIN_DISPLAY_EPOCHS,
    )

    protein_loaded = [
        load_snapshot(
            item["path"],
            "Protein",
        )
        for item in protein_selected
    ]

    protein_aligned = align_snapshots(
        protein_loaded,
        "Protein",
    )

    protein_coordinates = compute_shared_umap(
        protein_aligned,
        "Protein",
    )

    # DNA
    dna_selected = discover_snapshots(
        DNA_DIR,
        "DNA",
        DNA_DISPLAY_EPOCHS,
    )

    dna_loaded = [
        load_snapshot(
            item["path"],
            "DNA",
        )
        for item in dna_selected
    ]

    dna_aligned = align_snapshots(
        dna_loaded,
        "DNA",
    )

    dna_coordinates = compute_shared_umap(
        dna_aligned,
        "DNA",
    )

    # Unified color mapping.
    type_order, color_map, _ = build_color_mapping(
        protein_aligned[0]["true_types"],
        dna_aligned[0]["true_types"],
    )

    # Plot as TWO separate figures.
    # Protein and DNA keep the same unified Type colors,
    # and each figure retains the complete legend.
    plot_separate_figures(
        protein_selected=protein_selected,
        dna_selected=dna_selected,
        protein_aligned=protein_aligned,
        dna_aligned=dna_aligned,
        protein_coordinates=protein_coordinates,
        dna_coordinates=dna_coordinates,
        type_order=type_order,
        color_map=color_map,
    )

    # Save coordinates.
    protein_df = save_coordinates(
        "Protein",
        protein_coordinates,
        protein_selected,
        protein_aligned,
    )

    dna_df = save_coordinates(
        "DNA",
        dna_coordinates,
        dna_selected,
        dna_aligned,
    )

    coordinates_path = (
        OUTPUT_DIR
        / "Protein_DNA_reference_style_UMAP_coordinates.csv"
    )

    pd.concat(
        [
            protein_df,
            dna_df,
        ],
        ignore_index=True,
    ).to_csv(
        coordinates_path,
        index=False,
        encoding="utf-8-sig",
    )

    print(
        f"\n[Saved coordinates]\n"
        f"  {coordinates_path}"
    )

    print("\n" + "=" * 118)
    print("Done.")
    print("=" * 118)


if __name__ == "__main__":
    main()
