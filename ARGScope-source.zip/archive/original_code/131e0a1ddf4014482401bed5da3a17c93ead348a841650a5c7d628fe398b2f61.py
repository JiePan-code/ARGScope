# -*- coding: utf-8 -*-
"""
Apply the trained ARGScope DNABERT-2 DNA Student model to new embedding CSV files.

The script may be placed either in the ``endtoend`` folder or directly inside
``ARGScope_DNA_student_user_train_test_outputs``.

endtoend/
├── ARGScope_DNA_student_user_train_test_outputs/
│   ├── model_checkpoint.pth
│   ├── scaler_dna.joblib
│   └── subtype_encoder.joblib
└── ARGScope_DNA_student_user_train_test_outputs/embedding/
    ├── 3.60p_ARG_DNA_with_label.csv
    ├── 3.70p_ARG_DNA_with_label.csv
    └── ...

Each input CSV must contain an ID column and exactly 768 numeric DNA-embedding
columns.  ``Type`` and ``Subtype`` are optional: when ``Subtype`` is present,
the script also calculates evaluation metrics.  Original input CSVs are never
modified.
"""

from pathlib import Path
import re

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef


# =========================
# Configuration
# =========================
BASE_DIR = Path(__file__).resolve().parent


def resolve_model_dir():
    """Support running the script from either the parent or model directory."""
    if (BASE_DIR / "model_checkpoint.pth").is_file():
        return BASE_DIR
    candidate = BASE_DIR / "ARGScope_DNA_student_user_train_test_outputs"
    if (candidate / "model_checkpoint.pth").is_file():
        return candidate
    # Keep the expected path in the later error message if neither exists.
    return candidate


MODEL_DIR = resolve_model_dir()
INPUT_DIR = MODEL_DIR / "embedding"
OUTPUT_DIR = MODEL_DIR / "new_embedding_inference"

# Set to another folder only if your four CSV files are stored elsewhere.
# INPUT_DIR = Path(r"E:\\1. ARG模型对比\\1. NonARG 训练\\endtoend\\...")

CHECKPOINT_FILE = MODEL_DIR / "model_checkpoint.pth"
SCALER_FILE = MODEL_DIR / "scaler_dna.joblib"
ENCODER_FILE = MODEL_DIR / "subtype_encoder.joblib"

EXPECTED_DNA_DIM = 768
BATCH_SIZE = 1024
DEFAULT_MIN_PROB = 0.40
DEFAULT_MIN_MARGIN = 0.08
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

KEY_CANDIDATES = [
    "KEY", "Geneid", "geneid", "id", "ID", "Id", "NucleotideID",
    "ProteinID", "protein_id", "Protein_id",
]
LABEL_COLUMNS = {
    "KEY", "id", "ID", "Id", "Geneid", "geneid", "NucleotideID",
    "ProteinID", "protein_id", "Protein_id", "Type", "Subtype", "split",
    "Split", "Count", "subtype_index", "type_index", "Pred_Subtype",
}


# =========================
# Model definition: must match the training script exactly
# =========================
class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.18):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim), nn.LayerNorm(dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(dim, dim), nn.LayerNorm(dim),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.net(x))


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=1024, embed_dim=512, dropout=0.18, num_blocks=2):
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.GELU(), nn.Dropout(dropout),
        )
        self.blocks = nn.Sequential(*[ResidualBlock(hidden_dim, dropout) for _ in range(num_blocks)])
        self.embedding = nn.Sequential(
            nn.Linear(hidden_dim, embed_dim), nn.LayerNorm(embed_dim), nn.GELU(), nn.Dropout(dropout),
        )

    def forward(self, x):
        return nn.functional.normalize(self.embedding(self.blocks(self.input(x))), p=2, dim=1)


class ArcMarginHead(nn.Module):
    def __init__(self, embed_dim, num_classes, scale=28.0):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(num_classes, embed_dim))
        self.scale = scale

    def forward(self, z):
        return nn.functional.linear(
            nn.functional.normalize(z, p=2, dim=1),
            nn.functional.normalize(self.weight, p=2, dim=1),
        ) * self.scale


class DNAStudentInference(nn.Module):
    def __init__(self, dna_dim, num_classes, embed_dim=512):
        super().__init__()
        self.encoder = Encoder(dna_dim, hidden_dim=1024, embed_dim=embed_dim, dropout=0.18, num_blocks=2)
        self.head = ArcMarginHead(embed_dim, num_classes, scale=28.0)

    def forward(self, x):
        return self.head(self.encoder(x))


# =========================
# Input/output helpers
# =========================
def require_file(path, description):
    if not Path(path).is_file():
        raise FileNotFoundError(f"{description} not found: {path}")


def find_key_column(df):
    for col in KEY_CANDIDATES:
        if col in df.columns:
            return col
    return None


def natural_key(value):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", str(value))]


def get_feature_columns(df):
    cols = []
    for col in df.columns:
        if col in LABEL_COLUMNS:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            cols.append(col)
    return sorted(cols, key=natural_key)


def read_embedding_csv(path, expected_feature_cols):
    df = pd.read_csv(path, low_memory=False)
    key_col = find_key_column(df)
    if key_col is None:
        raise ValueError(f"{path.name}: no ID column found. Columns: {df.columns.tolist()[:20]}")
    if key_col != "KEY":
        df = df.rename(columns={key_col: "KEY"})
    df["KEY"] = df["KEY"].astype(str).str.strip()
    if df["KEY"].eq("").any() or df["KEY"].duplicated().any():
        raise ValueError(f"{path.name}: IDs must be non-empty and unique")

    cols = get_feature_columns(df)
    if len(cols) != EXPECTED_DNA_DIM:
        raise ValueError(
            f"{path.name}: expected exactly {EXPECTED_DNA_DIM} numeric embedding columns, found {len(cols)}. "
            "Do not include extra numeric metadata columns in this CSV."
        )
    # The training data use dna_0...dna_767. Newly exported DNABERT-2 files may
    # use emb_0...emb_767 or the one-based form emb_1...emb_768. These are the
    # same 768 positions, so prefixes and whether numbering starts at 0 or 1
    # must not be compared directly.
    def dim_index(name):
        match = re.search(r"(\d+)$", str(name))
        return int(match.group(1)) if match else None

    input_indices = [dim_index(c) for c in cols]
    if all(i is not None for i in input_indices):
        valid_zero_based = input_indices == list(range(0, EXPECTED_DNA_DIM))
        valid_one_based = input_indices == list(range(1, EXPECTED_DNA_DIM + 1))
        if not (valid_zero_based or valid_one_based):
            raise ValueError(
                f"{path.name}: the 768 embedding columns are not consecutively ordered. "
                f"Found first columns {cols[:5]} and last columns {cols[-5:]}. "
                "Expected emb_0...emb_767 or emb_1...emb_768."
            )

    # Only the number and order of dimensions matter. For example, emb_1 is
    # position 1 in a one-based export and corresponds to dna_0 in training.
    if expected_feature_cols and len(expected_feature_cols) != EXPECTED_DNA_DIM:
        raise ValueError(
            f"Checkpoint records {len(expected_feature_cols)} DNA feature columns; "
            f"expected {EXPECTED_DNA_DIM}."
        )
    X = df[cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    if not np.isfinite(X).all():
        raise ValueError(f"{path.name}: embedding values contain missing, NaN, or Inf")
    if np.any(np.linalg.norm(X, axis=1) <= 1e-12):
        raise ValueError(f"{path.name}: contains all-zero embedding rows")
    return df, X


def compute_metrics(y_true, y_pred):
    return {
        "sample_count": int(len(y_true)),
        "known_label_count": int(len(y_true)),
        "ACC": accuracy_score(y_true, y_pred),
        "WEIGHTED_PRECISION": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_RECALL": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "WEIGHTED_F1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "MACRO_PRECISION": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_RECALL": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "MACRO_F1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "MCC": matthews_corrcoef(y_true, y_pred),
    }


def predict_probabilities(model, X):
    loader = DataLoader(TensorDataset(torch.from_numpy(X)), batch_size=BATCH_SIZE, shuffle=False)
    chunks = []
    model.eval()
    with torch.no_grad():
        for (xb,) in loader:
            logits = model(xb.to(DEVICE, non_blocking=True)).float()
            chunks.append(torch.softmax(logits, dim=1).cpu().numpy())
    return np.concatenate(chunks, axis=0)


def build_type_mapping(input_frames):
    rows = []
    for df in input_frames:
        if "Subtype" in df.columns and "Type" in df.columns:
            x = df[["Subtype", "Type"]].dropna().copy()
            x["Subtype"] = x["Subtype"].astype(str).str.strip()
            x["Type"] = x["Type"].astype(str).str.strip()
            rows.append(x)
    if not rows:
        return {}
    mapping_df = pd.concat(rows, ignore_index=True).drop_duplicates()
    conflicts = mapping_df.groupby("Subtype")["Type"].nunique()
    if (conflicts > 1).any():
        bad = conflicts[conflicts > 1].index[:10].tolist()
        raise ValueError(f"The input labels map some Subtypes to multiple Types: {bad}")
    return mapping_df.set_index("Subtype")["Type"].to_dict()


def build_type_mapping_from_files(files):
    """Read only the two label columns first, so 1+ GB CSVs are never all held in RAM."""
    label_frames = []
    for path in files:
        header = pd.read_csv(path, nrows=0)
        if "Subtype" in header.columns and "Type" in header.columns:
            label_frames.append(pd.read_csv(path, usecols=["Subtype", "Type"], low_memory=False))
    return build_type_mapping(label_frames)


def main():
    print("=" * 80)
    print("ARGScope DNA Student: inference on new embedding CSV files")
    print("=" * 80)
    print("Device:", DEVICE)
    for path, desc in [(CHECKPOINT_FILE, "Model checkpoint"), (SCALER_FILE, "DNA scaler"), (ENCODER_FILE, "Subtype encoder")]:
        require_file(path, desc)
    if not INPUT_DIR.is_dir():
        raise FileNotFoundError(f"Input embedding folder not found: {INPUT_DIR}")

    files = sorted(INPUT_DIR.glob("*.csv"), key=lambda p: natural_key(p.name))
    if not files:
        raise FileNotFoundError(f"No CSV files found in: {INPUT_DIR}")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    checkpoint = torch.load(CHECKPOINT_FILE, map_location="cpu", weights_only=False)
    scaler = joblib.load(SCALER_FILE)
    subtype_encoder = joblib.load(ENCODER_FILE)
    expected_cols = checkpoint.get("dna_feature_cols", [])
    num_classes = int(checkpoint["num_classes"])
    dna_dim = int(checkpoint["dna_dim"])
    embed_dim = int(checkpoint.get("embed_dim", 512))
    if dna_dim != EXPECTED_DNA_DIM or len(subtype_encoder.classes_) != num_classes:
        raise ValueError(f"Checkpoint inconsistency: dna_dim={dna_dim}, classes={num_classes}")

    states = checkpoint.get("student_state_dicts")
    if not states:
        raise ValueError("Checkpoint contains no DNA Student weights: student_state_dicts")
    models = []
    for state in states:
        model = DNAStudentInference(dna_dim, num_classes, embed_dim).to(DEVICE)
        model.load_state_dict(state, strict=True)
        model.eval()
        models.append(model)
    print(f"Loaded {len(models)} DNA Student model(s), {num_classes} Subtypes.")

    # Process one file at a time.  The embeddings shown in your screenshot are
    # around 1.21 GB each, so loading all four together would consume too much RAM.
    type_map = build_type_mapping_from_files(files)

    summary_rows = []
    for path in files:
        df, X_raw = read_embedding_csv(path, expected_cols)
        print(f"Input: {path.name} | rows={len(df):,} | DNA dim={X_raw.shape[1]}")
        X = scaler.transform(X_raw).astype(np.float32)
        all_probs = [predict_probabilities(model, X) for model in models]
        probs = np.mean(np.stack(all_probs, axis=0), axis=0)
        top2 = np.argpartition(-probs, kth=1, axis=1)[:, :2]
        top2_prob = np.take_along_axis(probs, top2, axis=1)
        order = np.argsort(-top2_prob, axis=1)
        top2 = np.take_along_axis(top2, order, axis=1)
        top2_prob = np.take_along_axis(top2_prob, order, axis=1)
        pred_idx = top2[:, 0]
        pred_subtype = subtype_encoder.inverse_transform(pred_idx)

        out = df.copy()
        out["Pred_Subtype"] = pred_subtype
        out["Pred_Type"] = pd.Series(pred_subtype, index=out.index).map(type_map).fillna("Unknown")
        out["Pred_Probability"] = top2_prob[:, 0]
        out["Second_Pred_Subtype"] = subtype_encoder.inverse_transform(top2[:, 1])
        out["Second_Probability"] = top2_prob[:, 1]
        out["Probability_Margin"] = top2_prob[:, 0] - top2_prob[:, 1]
        out["High_Confidence"] = (out["Pred_Probability"] >= DEFAULT_MIN_PROB) & (out["Probability_Margin"] >= DEFAULT_MIN_MARGIN)

        safe_stem = path.stem
        out.to_csv(OUTPUT_DIR / f"{safe_stem}_predictions.csv", index=False, encoding="utf-8-sig")
        out.loc[out["High_Confidence"]].to_csv(OUTPUT_DIR / f"{safe_stem}_high_confidence.csv", index=False, encoding="utf-8-sig")
        out.loc[~out["High_Confidence"]].to_csv(OUTPUT_DIR / f"{safe_stem}_rejected.csv", index=False, encoding="utf-8-sig")

        row = {
            "dataset": path.name,
            "sample_count": len(out),
            "high_confidence_count": int(out["High_Confidence"].sum()),
            "high_confidence_rate": float(out["High_Confidence"].mean()),
            "unique_predicted_subtypes": int(out["Pred_Subtype"].nunique()),
        }
        if "Subtype" in out.columns:
            truth = out["Subtype"].astype(str).str.strip()
            known = truth.isin(subtype_encoder.classes_)
            if known.any():
                y_true = subtype_encoder.transform(truth.loc[known])
                y_pred = pred_idx[known.to_numpy()]
                metrics = compute_metrics(y_true, y_pred)
                row.update(metrics)
                pd.DataFrame([metrics]).round(6).to_csv(OUTPUT_DIR / f"{safe_stem}_metrics.csv", index=False, encoding="utf-8-sig")
                print(f"{path.name}: ACC={metrics['ACC']:.4f}, weighted F1={metrics['WEIGHTED_F1']:.4f}, MCC={metrics['MCC']:.4f}")
            else:
                row["known_label_count"] = 0
                print(f"{path.name}: no labels overlap the 2,825 model Subtypes; predictions only.")
        else:
            print(f"{path.name}: labels absent; predictions only.")
        summary_rows.append(row)

    pd.DataFrame(summary_rows).round(6).to_csv(OUTPUT_DIR / "new_embedding_inference_summary.csv", index=False, encoding="utf-8-sig")
    print("\nDone. Results:", OUTPUT_DIR.resolve())
    print("Main summary: new_embedding_inference_summary.csv")


if __name__ == "__main__":
    main()
