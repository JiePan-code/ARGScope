#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Summarize PLM-ARG per-Type metrics across 60/70/80/90/100% completeness.

Expected directory structure
----------------------------
Put this script in the directory that contains:

plmarg_eval_outputs_60p/
plmarg_eval_outputs_70p/
plmarg_eval_outputs_80p/
plmarg_eval_outputs_90p/
plmarg_eval_outputs_100p/

Each folder should contain:
    merged_plmarg_predictions_with_labels.csv

The script calculates, for every SARG Type, one-vs-rest:
    Accuracy
    Precision
    Recall
    F1
    MCC

Two evaluation scopes are exported:
1) ARG_only
   - true nonARG sequences are removed from the evaluation universe.
   - recommended for Type-level classification among ARG classes.

2) including_nonARG
   - all sequences are retained.
   - nonARG sequences contribute as negatives for every ARG Type.

Important PLM-ARG mapping rule
------------------------------
PLM-ARG does not necessarily use the same Type labels as SARG.

For each SARG Type:
- the script reads its compatible PLM-ARG label(s) from `true_plmarg_type`;
- a sequence is counted as predicted-positive for that SARG Type if the
  predicted PLM-ARG label set intersects the compatible label set.

Thus:
    actual positive    = true SARG Type == current Type
    predicted positive = PLM-ARG predicted a compatible label for current Type

Unsupported SARG Types:
- if `true_plmarg_type` is empty for a Type, metrics are exported as NA;
- status is set to "unsupported".

Shared PLM-ARG labels:
- if several SARG Types map to the same PLM-ARG label, the script still
  computes compatibility-level one-vs-rest metrics but marks:
      mapping_status = "shared_label"
- these are not strict one-to-one Type predictions, so the audit column
  should be retained in downstream analyses.

Outputs
-------
A new folder is created automatically:

PLMARG_5conditions_perType_metrics/

Main files:
    PLMARG_perType_metrics_ARG_only_long.csv
    PLMARG_perType_metrics_ARG_only_wide.csv
    PLMARG_perType_metrics_including_nonARG_long.csv
    PLMARG_perType_metrics_including_nonARG_wide.csv
    PLMARG_5conditions_summary.csv
    PLMARG_mapping_audit.csv

Also:
    60p_perType_metrics_ARG_only.csv
    ...
    100p_perType_metrics_including_nonARG.csv
"""

from __future__ import annotations

import ast
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd


# =============================================================================
# 1. Paths
# =============================================================================

ROOT = Path(__file__).resolve().parent

CONDITIONS = {
    "60p": ROOT / "plmarg_eval_outputs_60p",
    "70p": ROOT / "plmarg_eval_outputs_70p",
    "80p": ROOT / "plmarg_eval_outputs_80p",
    "90p": ROOT / "plmarg_eval_outputs_90p",
    "100p": ROOT / "plmarg_eval_outputs_100p",
}

CONDITION_DISPLAY = {
    "60p": "60%",
    "70p": "70%",
    "80p": "80%",
    "90p": "90%",
    "100p": "100%",
}

PREDICTION_FILENAME = "merged_plmarg_predictions_with_labels.csv"

OUTDIR = ROOT / "PLMARG_5conditions_perType_metrics"
OUTDIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 2. Column aliases
# =============================================================================

TRUE_SARG_TYPE_CANDIDATES = [
    "type",
    "true_type",
    "sarg_type",
    "true_sarg_type",
    "arg_type",
]

TRUE_PLMARG_TYPE_CANDIDATES = [
    "true_plmarg_type",
    "mapped_plmarg_type",
    "plmarg_true_type",
    "compatible_plmarg_type",
]

PRED_PLMARG_SET_CANDIDATES = [
    "pred_plmarg_set_str",
    "pred_plmarg_set",
    "predicted_plmarg_set",
    "predicted_plmarg_types",
]

PRED_PLMARG_SINGLE_CANDIDATES = [
    "pred",
    "pred_plmarg_type",
    "predicted_plmarg_type",
    "prediction",
    "predicted_type",
]

TRUE_ARG_BINARY_CANDIDATES = [
    "true_ARG_binary",
    "true_arg_binary",
    "true_ARG",
    "true_arg",
]


# =============================================================================
# 3. Settings
# =============================================================================

# Exclude nonARG as a target Type. It is still retained as negative examples
# in the including_nonARG scope.
EXCLUDE_NONARG_TARGET = True

# Precision / recall / F1 use 0 when a denominator is zero, matching the
# common sklearn zero_division=0 convention.
ZERO_DIVISION_VALUE = 0.0

METRIC_COLUMNS = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1",
    "MCC",
]

SCOPES = [
    "ARG_only",
    "including_nonARG",
]


# =============================================================================
# 4. Text normalization
# =============================================================================

def clean_text(value) -> str:
    if pd.isna(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def canonical_token(value) -> str:
    """
    Canonical comparison token.

    Examples:
        beta-lactam     -> beta_lactam
        beta lactam     -> beta_lactam
        Beta_Lactam     -> beta_lactam
    """
    text = clean_text(value).lower()
    text = text.replace("%", "pct")
    text = re.sub(r"[\s/\\\-]+", "_", text)
    text = re.sub(r"[^a-z0-9_]+", "", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def is_nonarg_type(value) -> bool:
    token = canonical_token(value)
    return token in {
        "nonarg",
        "non_arg",
        "nonresistance",
        "negative",
        "non_resistance",
    }


def find_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    lookup = {
        canonical_token(col): str(col)
        for col in df.columns
    }

    for candidate in candidates:
        key = canonical_token(candidate)
        if key in lookup:
            return lookup[key]

    return None


# =============================================================================
# 5. Parse PLM-ARG label sets
# =============================================================================

def flatten_literal(obj) -> list[str]:
    """
    Recursively flatten a Python literal into strings.
    """
    if obj is None:
        return []

    if isinstance(obj, dict):
        out = []
        for key, value in obj.items():
            out.extend(flatten_literal(key))
            out.extend(flatten_literal(value))
        return out

    if isinstance(obj, (list, tuple, set)):
        out = []
        for item in obj:
            out.extend(flatten_literal(item))
        return out

    return [clean_text(obj)]


def parse_label_set(value) -> set[str]:
    """
    Parse PLM-ARG label(s) from strings such as:
        aminoglycoside
        {'aminoglycoside'}
        ['macrolide', 'lincosamide']
        macrolide|lincosamide|streptogramin
        macrolide; lincosamide; streptogramin

    Returns canonicalized tokens.
    """
    text = clean_text(value)

    if not text:
        return set()

    if canonical_token(text) in {
        "",
        "nan",
        "none",
        "null",
        "na",
        "unsupported",
        "set",
    }:
        return set()

    # First try Python literal notation.
    literal_values = None

    try:
        parsed = ast.literal_eval(text)
        literal_values = flatten_literal(parsed)
    except Exception:
        literal_values = None

    if literal_values is not None:
        tokens = {
            canonical_token(x)
            for x in literal_values
            if canonical_token(x)
            not in {"", "nan", "none", "null", "na"}
        }
        return tokens

    # Remove common brackets/quotes when not a valid literal.
    stripped = text.strip("[]{}()")
    stripped = stripped.replace('"', "").replace("'", "")

    # Split explicit multi-label separators.
    parts = re.split(r"[|;,]+", stripped)

    tokens = set()

    for part in parts:
        part = clean_text(part)

        if not part:
            continue

        token = canonical_token(part)

        if token not in {
            "",
            "nan",
            "none",
            "null",
            "na",
            "unsupported",
        }:
            tokens.add(token)

    return tokens


# =============================================================================
# 6. Binary / ARG mask helpers
# =============================================================================

def parse_binary_value(value) -> bool | None:
    if pd.isna(value):
        return None

    if isinstance(value, (int, np.integer)):
        return bool(int(value))

    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return None
        return bool(int(value))

    token = canonical_token(value)

    if token in {
        "1",
        "true",
        "yes",
        "y",
        "arg",
        "positive",
    }:
        return True

    if token in {
        "0",
        "false",
        "no",
        "n",
        "nonarg",
        "non_arg",
        "negative",
    }:
        return False

    return None


def make_true_arg_mask(
    df: pd.DataFrame,
    true_type_col: str,
    true_arg_col: str | None,
) -> pd.Series:
    """
    Prefer true_ARG_binary if available.
    Otherwise infer from the SARG Type label.
    """
    if true_arg_col is not None:
        parsed = df[true_arg_col].map(parse_binary_value)

        if parsed.notna().any():
            fallback = ~df[true_type_col].map(is_nonarg_type)
            return parsed.where(parsed.notna(), fallback).astype(bool)

    return (~df[true_type_col].map(is_nonarg_type)).astype(bool)


# =============================================================================
# 7. Metrics
# =============================================================================

def safe_divide(
    numerator: float,
    denominator: float,
    zero_value: float = ZERO_DIVISION_VALUE,
) -> float:
    if denominator == 0:
        return float(zero_value)
    return float(numerator / denominator)


def mcc_from_confusion(
    tp: int,
    fp: int,
    fn: int,
    tn: int,
) -> float:
    numerator = tp * tn - fp * fn

    denominator = (
        (tp + fp)
        * (tp + fn)
        * (tn + fp)
        * (tn + fn)
    )

    if denominator <= 0:
        return 0.0

    return float(numerator / math.sqrt(denominator))


def calculate_binary_metrics(
    actual_positive: np.ndarray,
    predicted_positive: np.ndarray,
) -> dict:
    actual_positive = np.asarray(
        actual_positive,
        dtype=bool,
    )

    predicted_positive = np.asarray(
        predicted_positive,
        dtype=bool,
    )

    if actual_positive.shape != predicted_positive.shape:
        raise ValueError(
            "actual_positive and predicted_positive must have the same shape."
        )

    tp = int(
        np.sum(
            actual_positive
            & predicted_positive
        )
    )

    fp = int(
        np.sum(
            (~actual_positive)
            & predicted_positive
        )
    )

    fn = int(
        np.sum(
            actual_positive
            & (~predicted_positive)
        )
    )

    tn = int(
        np.sum(
            (~actual_positive)
            & (~predicted_positive)
        )
    )

    n = tp + fp + fn + tn

    accuracy = safe_divide(
        tp + tn,
        n,
    )

    precision = safe_divide(
        tp,
        tp + fp,
    )

    recall = safe_divide(
        tp,
        tp + fn,
    )

    f1 = safe_divide(
        2 * precision * recall,
        precision + recall,
    )

    mcc = mcc_from_confusion(
        tp=tp,
        fp=fp,
        fn=fn,
        tn=tn,
    )

    return {
        "N": n,
        "TP": tp,
        "FP": fp,
        "FN": fn,
        "TN": tn,
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1": f1,
        "MCC": mcc,
    }


# =============================================================================
# 8. Read one condition
# =============================================================================

def resolve_prediction_file(folder: Path) -> Path:
    preferred = folder / PREDICTION_FILENAME

    if preferred.is_file():
        return preferred

    candidates = sorted(
        folder.glob("*merged*plmarg*prediction*label*.csv")
    )

    if len(candidates) == 1:
        return candidates[0]

    raise FileNotFoundError(
        f"Cannot find {PREDICTION_FILENAME} in:\n"
        f"  {folder}\n"
        f"Candidates found: {[p.name for p in candidates]}"
    )


def read_prediction_table(
    condition_key: str,
    folder: Path,
) -> tuple[pd.DataFrame, dict]:
    if not folder.is_dir():
        raise FileNotFoundError(
            f"Condition folder not found: {folder}"
        )

    csv_path = resolve_prediction_file(folder)

    df = pd.read_csv(
        csv_path,
        encoding="utf-8-sig",
        low_memory=False,
    )

    df.columns = [
        clean_text(col)
        for col in df.columns
    ]

    true_type_col = find_column(
        df,
        TRUE_SARG_TYPE_CANDIDATES,
    )

    true_plmarg_col = find_column(
        df,
        TRUE_PLMARG_TYPE_CANDIDATES,
    )

    pred_set_col = find_column(
        df,
        PRED_PLMARG_SET_CANDIDATES,
    )

    pred_single_col = find_column(
        df,
        PRED_PLMARG_SINGLE_CANDIDATES,
    )

    true_arg_col = find_column(
        df,
        TRUE_ARG_BINARY_CANDIDATES,
    )

    if true_type_col is None:
        raise ValueError(
            f"[{condition_key}] Cannot find true SARG Type column.\n"
            f"Columns: {df.columns.tolist()}"
        )

    if true_plmarg_col is None:
        raise ValueError(
            f"[{condition_key}] Cannot find true_plmarg_type-like column.\n"
            f"Columns: {df.columns.tolist()}"
        )

    if pred_set_col is None and pred_single_col is None:
        raise ValueError(
            f"[{condition_key}] Cannot find PLM-ARG prediction column.\n"
            f"Columns: {df.columns.tolist()}"
        )

    # Clean true SARG Type.
    df["__true_sarg_type__"] = (
        df[true_type_col]
        .map(clean_text)
    )

    # Remove rows without a true Type.
    df = df[
        df["__true_sarg_type__"].ne("")
    ].copy()

    # Parse true compatible PLM-ARG labels.
    df["__true_plmarg_set__"] = (
        df[true_plmarg_col]
        .map(parse_label_set)
    )

    # Parse predicted PLM-ARG labels.
    if pred_set_col is not None:
        pred_sets = (
            df[pred_set_col]
            .map(parse_label_set)
        )
    else:
        pred_sets = pd.Series(
            [set() for _ in range(len(df))],
            index=df.index,
            dtype=object,
        )

    if pred_single_col is not None:
        single_sets = (
            df[pred_single_col]
            .map(parse_label_set)
        )

        # Union set-valued and single-valued predictions.
        df["__pred_plmarg_set__"] = [
            set(a) | set(b)
            for a, b in zip(
                pred_sets,
                single_sets,
            )
        ]
    else:
        df["__pred_plmarg_set__"] = pred_sets

    df["__true_arg__"] = make_true_arg_mask(
        df=df,
        true_type_col="__true_sarg_type__",
        true_arg_col=true_arg_col,
    )

    metadata = {
        "condition_key": condition_key,
        "condition": CONDITION_DISPLAY[condition_key],
        "source_file": str(csv_path.resolve()),
        "true_type_col": true_type_col,
        "true_plmarg_col": true_plmarg_col,
        "pred_set_col": pred_set_col or "",
        "pred_single_col": pred_single_col or "",
        "true_arg_col": true_arg_col or "",
    }

    print(
        f"[READ] {condition_key:4s} | "
        f"rows={len(df):,} | "
        f"file={csv_path.name}"
    )

    print(
        f"       true Type      : {true_type_col}"
    )

    print(
        f"       true PLM-ARG   : {true_plmarg_col}"
    )

    print(
        f"       pred set       : {pred_set_col}"
    )

    print(
        f"       pred single    : {pred_single_col}"
    )

    return df, metadata


# =============================================================================
# 9. Build Type -> PLM-ARG mapping
# =============================================================================

def build_type_mapping(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Derive one mapping row per SARG Type from true_plmarg_type.
    """
    all_types = sorted(
        df["__true_sarg_type__"]
        .dropna()
        .astype(str)
        .unique()
        .tolist(),
        key=lambda x: x.lower(),
    )

    rows = []

    for type_name in all_types:
        if (
            EXCLUDE_NONARG_TARGET
            and is_nonarg_type(type_name)
        ):
            continue

        subset = df[
            df["__true_sarg_type__"]
            == type_name
        ]

        compatible = set()

        for label_set in subset["__true_plmarg_set__"]:
            compatible |= set(label_set)

        rows.append({
            "Type": type_name,
            "Type_token": canonical_token(type_name),
            "support_all": int(len(subset)),
            "support_ARG": int(subset["__true_arg__"].sum()),
            "plmarg_labels": compatible,
        })

    mapping = pd.DataFrame(rows)

    if mapping.empty:
        raise ValueError(
            "No ARG Type mapping rows could be built."
        )

    # Count how many SARG Types use each PLM-ARG label.
    label_to_types: dict[str, set[str]] = {}

    for _, row in mapping.iterrows():
        for label in row["plmarg_labels"]:
            label_to_types.setdefault(
                label,
                set(),
            ).add(
                row["Type"]
            )

    status = []
    shared_with = []

    for _, row in mapping.iterrows():
        labels = set(
            row["plmarg_labels"]
        )

        if not labels:
            status.append(
                "unsupported"
            )
            shared_with.append(
                ""
            )
            continue

        sharing_types = set()

        for label in labels:
            sharing_types |= label_to_types.get(
                label,
                set(),
            )

        sharing_types.discard(
            row["Type"]
        )

        if sharing_types:
            status.append(
                "shared_label"
            )
            shared_with.append(
                ";".join(
                    sorted(
                        sharing_types,
                        key=str.lower,
                    )
                )
            )
        else:
            status.append(
                "one_to_one"
            )
            shared_with.append(
                ""
            )

    mapping["mapping_status"] = status
    mapping["shared_with_types"] = shared_with

    mapping["plmarg_labels_str"] = (
        mapping["plmarg_labels"]
        .map(
            lambda x: ";".join(
                sorted(
                    x,
                    key=str.lower,
                )
            )
        )
    )

    return mapping


# =============================================================================
# 10. Per-Type metrics for one condition
# =============================================================================

def calculate_per_type_metrics(
    df: pd.DataFrame,
    mapping: pd.DataFrame,
    condition_key: str,
    scope: str,
    source_file: str,
) -> pd.DataFrame:
    if scope not in SCOPES:
        raise ValueError(
            f"Unknown scope: {scope}"
        )

    if scope == "ARG_only":
        eval_df = df[
            df["__true_arg__"]
        ].copy()
    else:
        eval_df = df.copy()

    rows = []

    for _, map_row in mapping.iterrows():
        type_name = str(
            map_row["Type"]
        )

        labels = set(
            map_row["plmarg_labels"]
        )

        actual_positive = (
            eval_df["__true_sarg_type__"]
            == type_name
        ).to_numpy(
            dtype=bool
        )

        support = int(
            actual_positive.sum()
        )

        base = {
            "condition_key": condition_key,
            "condition": CONDITION_DISPLAY[condition_key],
            "scope": scope,
            "Type": type_name,
            "mapping_status": map_row["mapping_status"],
            "plmarg_labels": map_row["plmarg_labels_str"],
            "shared_with_types": map_row["shared_with_types"],
            "support": support,
            "source_file": source_file,
        }

        if not labels:
            # Model has no compatible output label for this SARG Type.
            row = {
                **base,
                "N": int(len(eval_df)),
                "TP": np.nan,
                "FP": np.nan,
                "FN": np.nan,
                "TN": np.nan,
                "Accuracy": np.nan,
                "Precision": np.nan,
                "Recall": np.nan,
                "F1": np.nan,
                "MCC": np.nan,
            }

            rows.append(
                row
            )

            continue

        predicted_positive = np.array(
            [
                bool(
                    labels
                    & set(pred_set)
                )
                for pred_set
                in eval_df["__pred_plmarg_set__"]
            ],
            dtype=bool,
        )

        metrics = calculate_binary_metrics(
            actual_positive=actual_positive,
            predicted_positive=predicted_positive,
        )

        row = {
            **base,
            **metrics,
        }

        rows.append(
            row
        )

    result = pd.DataFrame(
        rows
    )

    # Stable Type order.
    result = result.sort_values(
        [
            "mapping_status",
            "Type",
        ],
        key=lambda s: (
            s.map(
                {
                    "one_to_one": 0,
                    "shared_label": 1,
                    "unsupported": 2,
                }
            )
            if s.name == "mapping_status"
            else s.astype(str).str.lower()
        ),
    ).reset_index(
        drop=True
    )

    return result


# =============================================================================
# 11. Summaries
# =============================================================================

def weighted_mean(
    values: pd.Series,
    weights: pd.Series,
) -> float:
    values = pd.to_numeric(
        values,
        errors="coerce",
    )

    weights = pd.to_numeric(
        weights,
        errors="coerce",
    )

    valid = (
        values.notna()
        & weights.notna()
        & (weights >= 0)
    )

    if not valid.any():
        return np.nan

    values = values[valid]
    weights = weights[valid]

    if float(weights.sum()) <= 0:
        return float(
            values.mean()
        )

    return float(
        np.average(
            values,
            weights=weights,
        )
    )


def summarize_condition(
    metrics_df: pd.DataFrame,
) -> dict:
    supported = metrics_df[
        metrics_df["mapping_status"]
        != "unsupported"
    ].copy()

    one_to_one = metrics_df[
        metrics_df["mapping_status"]
        == "one_to_one"
    ].copy()

    shared = metrics_df[
        metrics_df["mapping_status"]
        == "shared_label"
    ].copy()

    unsupported = metrics_df[
        metrics_df["mapping_status"]
        == "unsupported"
    ].copy()

    row = {
        "condition_key": metrics_df["condition_key"].iloc[0],
        "condition": metrics_df["condition"].iloc[0],
        "scope": metrics_df["scope"].iloc[0],
        "n_types_total": int(len(metrics_df)),
        "n_types_supported": int(len(supported)),
        "n_types_one_to_one": int(len(one_to_one)),
        "n_types_shared_label": int(len(shared)),
        "n_types_unsupported": int(len(unsupported)),
        "support_total_types": int(
            pd.to_numeric(
                metrics_df["support"],
                errors="coerce",
            ).fillna(0).sum()
        ),
    }

    for metric in METRIC_COLUMNS:
        row[
            f"macro_{metric}"
        ] = (
            float(
                supported[metric].mean()
            )
            if not supported.empty
            else np.nan
        )

        row[
            f"weighted_{metric}"
        ] = weighted_mean(
            supported[metric],
            supported["support"],
        )

        row[
            f"one_to_one_macro_{metric}"
        ] = (
            float(
                one_to_one[metric].mean()
            )
            if not one_to_one.empty
            else np.nan
        )

        row[
            f"one_to_one_weighted_{metric}"
        ] = weighted_mean(
            one_to_one[metric],
            one_to_one["support"],
        )

    return row


def make_wide_table(
    long_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    One row per Type.
    Columns such as:
        Accuracy_60%
        Precision_60%
        ...
        MCC_100%
    """
    id_cols = [
        "Type",
        "mapping_status",
        "plmarg_labels",
        "shared_with_types",
    ]

    base = (
        long_df[id_cols]
        .drop_duplicates(
            subset=[
                "Type",
            ]
        )
        .set_index(
            "Type"
        )
    )

    pieces = [
        base
    ]

    condition_order = [
        "60%",
        "70%",
        "80%",
        "90%",
        "100%",
    ]

    for metric in (
        ["support"]
        + METRIC_COLUMNS
    ):
        pivot = long_df.pivot(
            index="Type",
            columns="condition",
            values=metric,
        )

        pivot = pivot.reindex(
            columns=condition_order
        )

        pivot.columns = [
            f"{metric}_{condition}"
            for condition in pivot.columns
        ]

        pieces.append(
            pivot
        )

    wide = pd.concat(
        pieces,
        axis=1,
    ).reset_index()

    return wide


# =============================================================================
# 12. Main
# =============================================================================

def main():
    print("=" * 100)
    print("PLM-ARG: per-Type 5-metric summary across 60/70/80/90/100%")
    print("=" * 100)

    print(f"ROOT   : {ROOT}")
    print(f"OUTDIR : {OUTDIR}")

    all_metric_frames = []
    all_mapping_frames = []
    summary_rows = []
    source_rows = []

    reference_type_sets = {}

    for condition_key, folder in CONDITIONS.items():
        print("\n" + "-" * 100)
        print(
            f"[CONDITION] "
            f"{condition_key} ({CONDITION_DISPLAY[condition_key]})"
        )
        print("-" * 100)

        df, metadata = read_prediction_table(
            condition_key=condition_key,
            folder=folder,
        )

        mapping = build_type_mapping(
            df
        )

        mapping_export = mapping.drop(
            columns=[
                "plmarg_labels",
            ]
        ).copy()

        mapping_export.insert(
            0,
            "condition_key",
            condition_key,
        )

        mapping_export.insert(
            1,
            "condition",
            CONDITION_DISPLAY[condition_key],
        )

        all_mapping_frames.append(
            mapping_export
        )

        reference_type_sets[
            condition_key
        ] = set(
            mapping["Type"]
        )

        print(
            "\n[MAPPING]"
        )

        print(
            mapping[
                [
                    "Type",
                    "mapping_status",
                    "plmarg_labels_str",
                    "shared_with_types",
                    "support_all",
                ]
            ].to_string(
                index=False
            )
        )

        for scope in SCOPES:
            metrics_df = calculate_per_type_metrics(
                df=df,
                mapping=mapping,
                condition_key=condition_key,
                scope=scope,
                source_file=metadata["source_file"],
            )

            all_metric_frames.append(
                metrics_df
            )

            summary_rows.append(
                summarize_condition(
                    metrics_df
                )
            )

            per_condition_path = (
                OUTDIR
                / f"{condition_key}_perType_metrics_{scope}.csv"
            )

            metrics_df.to_csv(
                per_condition_path,
                index=False,
                encoding="utf-8-sig",
            )

            print(
                f"\n[SAVE] {per_condition_path.name}"
            )

        source_rows.append(
            metadata
        )

    # ---------------------------------------------------------------------
    # Cross-condition Type-set audit
    # ---------------------------------------------------------------------

    all_type_union = set().union(
        *reference_type_sets.values()
    )

    type_set_audit_rows = []

    for type_name in sorted(
        all_type_union,
        key=str.lower,
    ):
        row = {
            "Type": type_name,
        }

        for condition_key in CONDITIONS:
            row[
                f"present_{condition_key}"
            ] = (
                type_name
                in reference_type_sets[
                    condition_key
                ]
            )

        type_set_audit_rows.append(
            row
        )

    type_set_audit = pd.DataFrame(
        type_set_audit_rows
    )

    type_set_audit.to_csv(
        OUTDIR
        / "PLMARG_Type_presence_across_conditions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ---------------------------------------------------------------------
    # Combined mapping audit
    # ---------------------------------------------------------------------

    mapping_audit = pd.concat(
        all_mapping_frames,
        ignore_index=True,
    )

    mapping_audit.to_csv(
        OUTDIR
        / "PLMARG_mapping_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ---------------------------------------------------------------------
    # Combined metrics
    # ---------------------------------------------------------------------

    all_metrics = pd.concat(
        all_metric_frames,
        ignore_index=True,
    )

    condition_rank = {
        key: rank
        for rank, key
        in enumerate(
            CONDITIONS.keys()
        )
    }

    scope_rank = {
        "ARG_only": 0,
        "including_nonARG": 1,
    }

    all_metrics[
        "__condition_rank__"
    ] = all_metrics[
        "condition_key"
    ].map(
        condition_rank
    )

    all_metrics[
        "__scope_rank__"
    ] = all_metrics[
        "scope"
    ].map(
        scope_rank
    )

    all_metrics = all_metrics.sort_values(
        [
            "__scope_rank__",
            "__condition_rank__",
            "Type",
        ],
        key=lambda s: (
            s.astype(str).str.lower()
            if s.name == "Type"
            else s
        ),
    ).drop(
        columns=[
            "__condition_rank__",
            "__scope_rank__",
        ]
    ).reset_index(
        drop=True
    )

    # Separate long + wide tables by scope.
    for scope in SCOPES:
        scoped = all_metrics[
            all_metrics["scope"]
            == scope
        ].copy()

        long_path = (
            OUTDIR
            / f"PLMARG_perType_metrics_{scope}_long.csv"
        )

        scoped.to_csv(
            long_path,
            index=False,
            encoding="utf-8-sig",
        )

        wide = make_wide_table(
            scoped
        )

        wide_path = (
            OUTDIR
            / f"PLMARG_perType_metrics_{scope}_wide.csv"
        )

        wide.to_csv(
            wide_path,
            index=False,
            encoding="utf-8-sig",
        )

        print(
            f"[SAVE] {long_path.name}"
        )

        print(
            f"[SAVE] {wide_path.name}"
        )

    # ---------------------------------------------------------------------
    # Five-condition summary table
    # ---------------------------------------------------------------------

    summary = pd.DataFrame(
        summary_rows
    )

    summary[
        "__condition_rank__"
    ] = summary[
        "condition_key"
    ].map(
        condition_rank
    )

    summary[
        "__scope_rank__"
    ] = summary[
        "scope"
    ].map(
        scope_rank
    )

    summary = summary.sort_values(
        [
            "__scope_rank__",
            "__condition_rank__",
        ]
    ).drop(
        columns=[
            "__condition_rank__",
            "__scope_rank__",
        ]
    )

    summary.to_csv(
        OUTDIR
        / "PLMARG_5conditions_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ---------------------------------------------------------------------
    # Source audit
    # ---------------------------------------------------------------------

    pd.DataFrame(
        source_rows
    ).to_csv(
        OUTDIR
        / "PLMARG_source_files_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n" + "=" * 100)
    print("DONE")
    print("=" * 100)

    print(
        f"All files were written to:\n"
        f"{OUTDIR}"
    )

    print(
        "\nRecommended downstream Type-level table:\n"
        "  PLMARG_perType_metrics_ARG_only_long.csv\n"
        "because it avoids inflating one-vs-rest accuracy/MCC with "
        "true nonARG sequences."
    )

    print(
        "\nKeep these audit columns when interpreting PLM-ARG:\n"
        "  mapping_status\n"
        "  plmarg_labels\n"
        "  shared_with_types"
    )


if __name__ == "__main__":
    main()
