#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Right-click launcher for the DNA w/o Knowledge Transfer ablation.

Recommended location
--------------------
Place this file directly in:

E:\\1. ARGmodel\\1. NonARG_training\\new model result8.24\\3.Protein_student_subtype2_newsplit\\

The launcher is intentionally self-contained.  It does not import either copy
of ``ablation_runtime.py`` and therefore cannot accidentally use the stale
nested ablation helper.

Scientific definition
---------------------
The Student architecture and supervised binary/subtype cross-entropy losses
are retained.  Learned Teacher training, binary/subtype KD, feature alignment,
prototype alignment, and the Teacher-head anchor are disabled.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from datetime import datetime
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve()


def locate_project_root() -> Path:
    """Find the new-split project root from this launcher's location."""
    candidates = (SCRIPT_PATH.parent, *SCRIPT_PATH.parents)
    for candidate in candidates:
        has_split = (
            (candidate / "train_ids_subtype2.txt").is_file()
            and (candidate / "test_ids_subtype2.txt").is_file()
        )
        has_base = any(
            path.is_file()
            for path in (
                candidate / "argscope_subtype2_newsplit" / "05_dna_student.py",
                candidate / "ARGScope_subtype2_newsplit" / "05_dna_student.py",
                candidate / "05_dna_student.py",
            )
        )
        if has_split and has_base:
            return candidate

    checked = "\n  ".join(str(path) for path in candidates)
    raise FileNotFoundError(
        "Could not locate the ARGScope subtype2 new-split project root.\n"
        "Place this launcher anywhere under that project, preferably directly "
        "in its root folder.\nChecked:\n  "
        + checked
    )


def locate_base_script(project_root: Path) -> Path:
    candidates = (
        project_root / "argscope_subtype2_newsplit" / "05_dna_student.py",
        project_root / "ARGScope_subtype2_newsplit" / "05_dna_student.py",
        project_root / "05_dna_student.py",
    )
    for path in candidates:
        if path.is_file():
            return path

    checked = "\n  ".join(str(path) for path in candidates)
    raise FileNotFoundError(
        "Could not find the full DNA Student base script. Checked:\n  " + checked
    )


def load_base_script(base_script: Path):
    """Load the Full DNA script without executing its main block."""
    module_name = "dna_wo_transfer_base"
    sys.path.insert(0, str(base_script.parent))
    spec = importlib.util.spec_from_file_location(module_name, base_script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load base script: {base_script}")

    module = importlib.util.module_from_spec(spec)
    # Dataclasses with postponed annotations require registration before load.
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def configure_local_paths(module, project_root: Path) -> Path:
    """Set only local input/output defaults; preserve model implementation."""
    output_dir = project_root / "DNA_student_subtype2_newsplit_wo_transfer"

    module.ROOT = project_root
    module.DEFAULT_DNA_PT = (
        project_root
        / "DNABERT2_full_1to1"
        / "full_1to1_dnabert2_mean.pt"
    )
    module.DEFAULT_FUSION_PT = (
        project_root
        / "Long_fusion_subtype2_newsplit"
        / "long_fusion_subtype2_newsplit.pt"
    )
    module.DEFAULT_REFINED_PT = (
        project_root
        / "Refined_subtype_prototypes_subtype2_newsplit"
        / "refined_ARG_subtype_prototypes_residual_GAT.pt"
    )
    module.DEFAULT_TRAIN_IDS = project_root / "train_ids_subtype2.txt"
    module.DEFAULT_TEST_IDS = project_root / "test_ids_subtype2.txt"
    module.DEFAULT_OUTPUT_DIR = output_dir

    return output_dir


def disable_learned_transfer(module) -> None:
    """Train the Student with supervised CE only and no learned Teacher path."""
    original_train_student = module.train_student
    original_config = module.Config

    transfer_fields = (
        "student_binary_kd",
        "student_subtype_kd",
        "student_feature_align",
        "student_prototype_align",
        "student_head_anchor",
    )

    def zero_transfer_weights(config) -> None:
        for field in transfer_fields:
            if not hasattr(config, field):
                raise AttributeError(
                    f"DNA Config is missing the expected transfer field: {field}"
                )
            setattr(config, field, 0.0)

    class NoTransferConfig(original_config):
        """Original DNA configuration with all transfer coefficients at zero."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            zero_transfer_weights(self)

    NoTransferConfig.__name__ = original_config.__name__
    NoTransferConfig.__qualname__ = original_config.__qualname__
    module.Config = NoTransferConfig

    def untrained_teacher(
        data,
        config,
        use_amp,
        heartbeat,
        progress_dir=None,
    ):
        # A random, never-trained Teacher object is retained only because the
        # unchanged Student routine expects a Teacher-shaped argument.
        teacher = module.FusionTeacher(data["refined_gpu"], config).cuda()
        with module.torch.no_grad():
            module.nn.init.xavier_uniform_(teacher.binary_head.weight)
            module.nn.init.xavier_uniform_(teacher.arg_head.weight)

        print(
            "Knowledge transfer disabled: Teacher is untrained and random.",
            flush=True,
        )
        return teacher, [], 0, float("nan")

    def supervised_student(
        teacher,
        data,
        config,
        use_amp,
        heartbeat,
        snapshot_epochs,
        snapshot_dir,
    ):
        zero_transfer_weights(config)

        print(
            "Student objective: binary CE + subtype CE only.",
            flush=True,
        )
        return original_train_student(
            teacher,
            data,
            config,
            use_amp,
            heartbeat,
            snapshot_epochs,
            snapshot_dir,
        )

    module.train_teacher = untrained_teacher
    module.train_student = supervised_student


def archive_previous_failed_run(output_dir: Path) -> Path | None:
    """Preserve a known failed startup so right-click reruns start cleanly.

    A completed or ambiguous non-empty directory is never moved automatically.
    """
    if not output_dir.exists() or not any(output_dir.iterdir()):
        return None

    completed_markers = (
        output_dir / "test_metrics.json",
        output_dir / "test_sequence_predictions.csv",
        output_dir / "current_run_best_epoch_summary.json",
    )
    if any(path.is_file() for path in completed_markers):
        raise FileExistsError(
            "The DNA w/o transfer output folder already contains completed-result "
            f"files and will not be moved automatically: {output_dir}"
        )

    status_path = output_dir / "run_status.json"
    try:
        status = json.loads(status_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise FileExistsError(
            "The output folder is non-empty, but it is not a confirmed failed "
            f"run and will not be moved automatically: {output_dir}"
        ) from exc

    if str(status.get("phase", "")).strip().lower() != "failed":
        raise FileExistsError(
            "The output folder is non-empty and run_status.json is not marked "
            f"as failed: {output_dir}"
        )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = output_dir.with_name(f"{output_dir.name}_FAILED_{timestamp}")
    suffix = 1
    while backup.exists():
        backup = output_dir.with_name(
            f"{output_dir.name}_FAILED_{timestamp}_{suffix}"
        )
        suffix += 1

    output_dir.rename(backup)
    print(f"Archived previous failed run: {backup}", flush=True)
    return backup


def mark_saved_ablation(module) -> None:
    """Write the ablation definition into every compatible saved checkpoint."""
    if hasattr(module, "safe_save"):
        save_name = "safe_save"
    elif hasattr(module, "save_checkpoint"):
        save_name = "save_checkpoint"
    else:
        raise AttributeError(
            "The DNA base script has neither safe_save nor save_checkpoint."
        )

    original_save = getattr(module, save_name)

    def save_with_ablation_metadata(obj, path):
        if isinstance(obj, dict):
            obj.setdefault(
                "ablation",
                {
                    "label": "w/o Knowledge Transfer",
                    "removed_information_path": (
                        "trained Teacher, binary/subtype KD, feature alignment, "
                        "prototype alignment and head anchor"
                    ),
                },
            )
        return original_save(obj, path)

    setattr(module, save_name, save_with_ablation_metadata)


def add_right_click_defaults(project_root: Path) -> None:
    """Supply the structure table automatically unless CLI overrides it."""
    if "--structure" not in sys.argv:
        sys.argv.extend(
            [
                "--structure",
                str(project_root / "all_ARG_nonARG_1to1_structure.txt"),
            ]
        )


def main() -> None:
    project_root = locate_project_root()
    base_script = locate_base_script(project_root)
    module = load_base_script(base_script)
    output_dir = configure_local_paths(module, project_root)
    disable_learned_transfer(module)
    mark_saved_ablation(module)
    add_right_click_defaults(project_root)

    # The earlier launcher failure may have left split manifests in the output
    # folder. Preserve that confirmed failed run, then let the base script
    # create the intended clean output directory.
    if not any(arg in {"-h", "--help"} for arg in sys.argv[1:]):
        archive_previous_failed_run(output_dir)

    print(f"Project root : {project_root}", flush=True)
    print(f"Base script  : {base_script}", flush=True)
    print(f"Output folder: {output_dir}", flush=True)
    print("Ablation     : w/o Knowledge Transfer", flush=True)

    module.main()


if __name__ == "__main__":
    main()
