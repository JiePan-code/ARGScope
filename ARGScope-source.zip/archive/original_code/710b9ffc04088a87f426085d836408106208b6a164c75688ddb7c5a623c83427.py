#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ARGScope multi-length DNA student
UMAP plotting for Windows (legend-width optimized)

Changes from previous clean version
-----------------------------------
1. Keep colors unchanged.
2. Keep UMAP parameters unchanged.
3. Optimize bottom Type legend:
   - full-width legend area
   - legend width matches the full figure width
   - smaller font
   - more balanced multi-column arrangement
4. MLS abbreviation kept.
"""

from pathlib import Path
import re
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpec
from sklearn.preprocessing import LabelEncoder

try:
    import umap
except ImportError as e:
    raise ImportError("Please install umap-learn first: pip install umap-learn") from e


# =============================================================================
# 1. Paths
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent
INPUT_DIR = ROOT_DIR
OLD_OUTPUT_DIR = ROOT_DIR / "UMAP_figures_windows"
OUTPUT_DIR = ROOT_DIR / "DNA_UMAP_figures_windows_clean_v2"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SUBTYPE_TYPE_MAP = ROOT_DIR / "subtype_type_map.csv"
UMAP_REFERENCE_FILE = ROOT_DIR / "umap_fixed_reference_subset.csv"


# =============================================================================
# 2. UMAP settings (unchanged)
# =============================================================================

USE_SUPERVISED_UMAP = True
TARGET_WEIGHT = 0.30
RANDOM_STATE = 42

UMAP_PARAMS = dict(
    n_neighbors=12,
    min_dist=0.15,
    spread=1.8,
    metric="cosine",
    random_state=RANDOM_STATE,
)

POINT_SIZE = 5
POINT_ALPHA = 0.75
POINT_LINEWIDTH = 0.0
EDGE_COLOR = "none"

SAVE_DPI = 600


# =============================================================================
# 3. Figure / legend style
# =============================================================================

FIG_WIDTH = 17.6
FIG_HEIGHT = 10.8

PANEL_TITLE_SIZE = 11.5
AXIS_LABEL_SIZE = 10.5
MAIN_TITLE_SIZE = 15.0

SHOW_MAIN_TITLE = True
MAIN_TITLE = "UMAP of DNA-student representations colored by ARG type"

GLOBAL_AXIS_PADDING = 0.035

# Legend tuning
LEGEND_NCOL = 8
LEGEND_FONT_SIZE = 15
LEGEND_MARKER_SIZE = 10

TYPE_COLOR_LIST = [
    "#E64B35", "#1F78B4", "#00A087", "#3C5488", "#F39B7F",
    "#7E6148", "#4DBBD5", "#D00000", "#B09C85", "#91D1C2",
    "#A6CEE3", "#FF7F00", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDB462", "#6A3D9A", "#CAB2D6", "#B15928",
    "#F0E442", "#8C510A", "#80CDC1", "#35978F", "#F781BF",
    "#377EB8", "#FFB000", "#66A61E", "#E7298A", "#984EA3",
    "#A6DBA0",
]

DISPLAY_NAME_MAP = {
    "macrolide-lincosamide-streptogramin": "MLS",
}


warnings.filterwarnings("ignore", category=UserWarning)

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "axes.titlesize": PANEL_TITLE_SIZE,
    "axes.labelsize": AXIS_LABEL_SIZE,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": LEGEND_FONT_SIZE,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# =============================================================================
# 4. Helpers
# =============================================================================

def parse_snapshot_file(path: Path):
    name = path.name

    m = re.fullmatch(r"dna_student_embedding_epoch_(\d+)\.csv", name)
    if m:
        epoch = int(m.group(1))
        return {
            "path": path,
            "epoch": epoch,
            "is_best": False,
            "title": f"Epoch {epoch}",
            "sort_key": (epoch, 0),
        }

    m = re.fullmatch(r"dna_student_embedding_best_epoch_(\d+)\.csv", name)
    if m:
        epoch = int(m.group(1))
        return {
            "path": path,
            "epoch": epoch,
            "is_best": True,
            "title": f"Best model (epoch {epoch})",
            "sort_key": (10**9, epoch),
        }

    return None


def discover_snapshots():
    if not INPUT_DIR.is_dir():
        raise FileNotFoundError(f"UMAP embedding folder not found: {INPUT_DIR}")

    infos = []
    for path in INPUT_DIR.glob("dna_student_embedding_*.csv"):
        info = parse_snapshot_file(path)
        if info is not None:
            infos.append(info)

    if not infos:
        raise FileNotFoundError(f"No dna_student_embedding_epoch_*.csv found in {INPUT_DIR}")

    infos.sort(key=lambda x: x["sort_key"])

    print("\n[Discovered snapshots]")
    for x in infos:
        print(f"  {x['path'].name} | title={x['title']} | best={x['is_best']}")
    return infos


def find_first_column(df, candidates, required=True):
    lower_map = {str(c).strip().casefold(): c for c in df.columns}
    for candidate in candidates:
        c = lower_map.get(str(candidate).casefold())
        if c is not None:
            return c
    if required:
        raise ValueError(f"Cannot find one of columns {candidates}. Existing={df.columns.tolist()}")
    return None


def numeric_embed_columns(df):
    cols = [c for c in df.columns if str(c).startswith("embed_")]

    def key(c):
        try:
            return int(str(c).split("_")[-1])
        except Exception:
            return 10**9

    return sorted(cols, key=key)


def load_one_snapshot(info):
    path = info["path"]
    df = pd.read_csv(path, low_memory=False)

    key_col = find_first_column(df, ["KEY", "key"])
    length_col = find_first_column(df, ["length_name", "Length", "length"], required=False)
    type_col = find_first_column(df, ["True_Type", "Type", "true_Type", "true_type"])
    subtype_col = find_first_column(df, ["True_Subtype", "Subtype", "true_Subtype", "true_subtype"], required=False)

    if length_col is None:
        raise ValueError(f"{path.name} has no length_name column.")

    embed_cols = numeric_embed_columns(df)
    if not embed_cols:
        raise ValueError(f"No embed_* columns found in {path.name}")

    df["__KEY__"] = df[key_col].astype(str).str.strip()
    df["__LENGTH__"] = df[length_col].astype(str).str.strip()
    df["__TYPE__"] = df[type_col].astype(str).str.strip()
    df["__SUBTYPE__"] = df[subtype_col].astype(str).str.strip() if subtype_col is not None else ""

    df["__SAMPLE_ID__"] = df["__LENGTH__"] + "|||" + df["__KEY__"]

    dup_mask = df["__SAMPLE_ID__"].duplicated(keep=False)
    if dup_mask.any():
        dup = df.loc[dup_mask, "__SAMPLE_ID__"].head(20).tolist()
        raise ValueError(f"Duplicated composite sample IDs in {path.name}: {dup}")

    X = df[embed_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    if not np.isfinite(X).all():
        raise ValueError(f"{path.name}: embed_* contains NaN/Inf")

    print(
        f"[Loaded] {path.name}: N={len(df):,}, dim={X.shape[1]}, "
        f"Types={df['__TYPE__'].nunique()}, Lengths={df['__LENGTH__'].nunique()}"
    )

    return {**info, "df": df, "X": X, "embed_cols": embed_cols}


def align_snapshots(snapshots):
    common_ids = set(snapshots[0]["df"]["__SAMPLE_ID__"])
    for s in snapshots[1:]:
        common_ids &= set(s["df"]["__SAMPLE_ID__"])

    if not common_ids:
        raise ValueError("No common samples across snapshots.")

    first_ids = snapshots[0]["df"]["__SAMPLE_ID__"].tolist()
    ordered_common = [x for x in first_ids if x in common_ids]

    print(f"\n[Alignment] common samples across all snapshots: {len(ordered_common):,}")

    aligned = []
    for s in snapshots:
        df = s["df"].set_index("__SAMPLE_ID__", drop=False).loc[ordered_common].copy()
        X = df[s["embed_cols"]].to_numpy(dtype=np.float32)
        new_s = dict(s)
        new_s["df"] = df.reset_index(drop=True)
        new_s["X"] = X
        aligned.append(new_s)

    ref = aligned[0]["df"][["__SAMPLE_ID__", "__TYPE__", "__LENGTH__"]].copy()
    for s in aligned[1:]:
        cur = s["df"][["__SAMPLE_ID__", "__TYPE__", "__LENGTH__"]].copy()
        if not ref.equals(cur):
            raise ValueError(f"Sample metadata inconsistent: {s['path'].name}")

    return aligned


def read_full_type_order():
    """
    Recover the complete canonical Type order.

    Priority:
    1. subtype_type_map.csv if present;
    2. UMAP_embeddings/umap_fixed_reference_subset.csv;
    3. Types detected from snapshot CSVs.
    """
    if SUBTYPE_TYPE_MAP.is_file():
        mapping = pd.read_csv(SUBTYPE_TYPE_MAP, low_memory=False)
        type_col = find_first_column(
            mapping,
            ["Type", "type", "True_Type", "true_type"],
        )
        vals = (
            mapping[type_col]
            .dropna()
            .astype(str)
            .str.strip()
            .drop_duplicates()
            .tolist()
        )
        vals = sorted(vals)
        print(f"[Type map] full Type count from subtype_type_map.csv: {len(vals)}")
        return vals

    if UMAP_REFERENCE_FILE.is_file():
        mapping = pd.read_csv(UMAP_REFERENCE_FILE, low_memory=False)
        type_col = find_first_column(
            mapping,
            ["Type", "type", "True_Type", "true_type"],
            required=False,
        )
        if type_col is not None:
            vals = (
                mapping[type_col]
                .dropna()
                .astype(str)
                .str.strip()
                .drop_duplicates()
                .tolist()
            )
            vals = sorted(vals)
            print(
                f"[Type map] full Type count from "
                f"umap_fixed_reference_subset.csv: {len(vals)}"
            )
            return vals

    print("[Type map] no external Type table found; use snapshot Types.")
    return None

def try_load_existing_color_mapping():
    candidates = [
        ROOT_DIR / "protein_type_color_mapping.csv",
        OLD_OUTPUT_DIR / "type_color_mapping.csv",
        ROOT_DIR / "type_color_mapping.csv",
        ROOT_DIR / "UMAP_figures_windows_clean" / "type_color_mapping.csv",
        ROOT_DIR / "UMAP_figures_windows_clean_v2" / "type_color_mapping.csv",
        OUTPUT_DIR / "type_color_mapping.csv",
    ]

    for path in candidates:
        if not path.is_file():
            continue
        try:
            df = pd.read_csv(path, low_memory=False)

            raw_col = None
            color_col = None
            for c in ["raw_type", "True_Type", "Type", "type"]:
                if c in df.columns:
                    raw_col = c
                    break
            for c in ["color", "Color"]:
                if c in df.columns:
                    color_col = c
                    break

            if raw_col is None or color_col is None:
                continue

            mapping = dict(zip(df[raw_col].astype(str), df[color_col].astype(str)))
            if mapping:
                print(f"[Colors] Loaded existing color mapping: {path}")
                return mapping
        except Exception:
            pass

    return None


def build_color_mapping(snapshots):
    detected = sorted(
        pd.concat([s["df"]["__TYPE__"] for s in snapshots], ignore_index=True)
        .dropna().astype(str).unique().tolist()
    )

    full_order = read_full_type_order()
    if full_order is None:
        full_order = detected

    for x in detected:
        if x not in full_order:
            full_order.append(x)

    existing_map = try_load_existing_color_mapping()
    color_map = {}

    if existing_map is not None:
        for label in full_order:
            if label in existing_map:
                color_map[label] = existing_map[label]

    unused_colors = [c for c in TYPE_COLOR_LIST if c not in set(color_map.values())]

    for label in full_order:
        if label not in color_map:
            if unused_colors:
                color_map[label] = unused_colors.pop(0)
            else:
                cmap = plt.get_cmap("turbo")
                color_map[label] = mpl.colors.to_hex(cmap(len(color_map) / max(1, len(full_order) - 1)))

    present = set(detected)
    missing = [x for x in full_order if x not in present]

    print(f"[Types] present in snapshots: {len(present)}")
    print(f"[Types] legend total: {len(full_order)}")
    if missing:
        print("[Types absent from current snapshots]")
        for x in missing:
            print("  -", x)

    out = pd.DataFrame({
        "raw_type": full_order,
        "display_type": [DISPLAY_NAME_MAP.get(x, x) for x in full_order],
        "color": [color_map[x] for x in full_order],
        "present_in_snapshot": [x in present for x in full_order],
    })
    out.to_csv(OUTPUT_DIR / "type_color_mapping.csv", index=False, encoding="utf-8-sig")

    return full_order, color_map


def encode_labels(labels):
    le = LabelEncoder()
    return le.fit_transform(np.asarray(labels).astype(str)).astype(np.int32)


def compute_shared_umap(snapshots):
    print("\n[Shared UMAP]")
    print(f"  supervised = {USE_SUPERVISED_UMAP}")
    print(f"  params     = {UMAP_PARAMS}")

    X_all = np.vstack([s["X"] for s in snapshots])
    reducer = umap.UMAP(
        **UMAP_PARAMS,
        target_metric="categorical" if USE_SUPERVISED_UMAP else "euclidean",
        target_weight=TARGET_WEIGHT if USE_SUPERVISED_UMAP else 0.0,
    )

    if USE_SUPERVISED_UMAP:
        labels = np.concatenate([s["df"]["__TYPE__"].astype(str).to_numpy() for s in snapshots])
        Z_all = reducer.fit_transform(X_all, y=encode_labels(labels))
    else:
        Z_all = reducer.fit_transform(X_all)

    cursor = 0
    for s in snapshots:
        n = len(s["df"])
        s["Z"] = Z_all[cursor:cursor + n]
        cursor += n

    return snapshots


def global_axis_limits(snapshots):
    Z = np.vstack([s["Z"] for s in snapshots])
    xmin, xmax = float(Z[:, 0].min()), float(Z[:, 0].max())
    ymin, ymax = float(Z[:, 1].min()), float(Z[:, 1].max())
    xpad = max((xmax - xmin) * GLOBAL_AXIS_PADDING, 1e-6)
    ypad = max((ymax - ymin) * GLOBAL_AXIS_PADDING, 1e-6)
    return xmin - xpad, xmax + xpad, ymin - ypad, ymax + ypad


def style_axis(ax, limits, show_ylabel=True):
    xmin, xmax, ymin, ymax = limits
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel("UMAP1", labelpad=3)
    ax.set_ylabel("UMAP2" if show_ylabel else "", labelpad=1.5)
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)
        spine.set_color("black")


def plot_snapshot(ax, snapshot, color_map, limits, show_ylabel):
    df = snapshot["df"]
    Z = snapshot["Z"]
    labels = df["__TYPE__"].astype(str).to_numpy()

    counts = pd.Series(labels).value_counts(ascending=False)
    for label in counts.index:
        mask = labels == label
        ax.scatter(
            Z[mask, 0], Z[mask, 1],
            s=POINT_SIZE,
            c=color_map[label],
            alpha=POINT_ALPHA,
            linewidths=POINT_LINEWIDTH,
            edgecolors=EDGE_COLOR,
            rasterized=True,
        )

    style_axis(ax, limits, show_ylabel=show_ylabel)
    ax.set_title(snapshot["title"], fontweight="bold" if snapshot["is_best"] else "normal", pad=5)


def make_legend_handles(type_order, color_map):
    handles = []
    for raw_name in type_order:
        display_name = DISPLAY_NAME_MAP.get(raw_name, raw_name)
        handles.append(
            Line2D(
                [0], [0],
                linestyle="none",
                marker="o",
                markerfacecolor=color_map[raw_name],
                markeredgecolor="none",
                markersize=LEGEND_MARKER_SIZE,
                label=display_name,
            )
        )
    return handles


def plot_clean_multipanel(snapshots, type_order, color_map):
    n = len(snapshots)

    if n == 0:
        raise ValueError("No snapshots to plot.")
    if n > 7:
        raise ValueError(f"This layout is designed for <=7 snapshots, found {n}")

    limits = global_axis_limits(snapshots)

    fig = plt.figure(
        figsize=(FIG_WIDTH, FIG_HEIGHT),
        dpi=SAVE_DPI,
        constrained_layout=False,
    )

    # DNA usually has 6 panels:
    # Epoch 0 / 20 / 50 / 100 / 150 + Best model.
    # Use 3 + 3 for a balanced layout.
    if n == 6:
        ncols = 6
        panel_slots = [
            (0, slice(0, 2)),
            (0, slice(2, 4)),
            (0, slice(4, 6)),
            (1, slice(0, 2)),
            (1, slice(2, 4)),
            (1, slice(4, 6)),
        ]
        ylabel_indices = {0, 3}

    elif n == 7:
        ncols = 8
        panel_slots = [
            (0, slice(0, 2)),
            (0, slice(2, 4)),
            (0, slice(4, 6)),
            (0, slice(6, 8)),
            (1, slice(1, 3)),
            (1, slice(3, 5)),
            (1, slice(5, 7)),
        ]
        ylabel_indices = {0, 4}

    else:
        ncols = 6
        top_n = min(3, n)
        bottom_n = n - top_n
        panel_slots = []

        if top_n == 1:
            top_starts = [2]
        elif top_n == 2:
            top_starts = [1, 3]
        else:
            top_starts = [0, 2, 4]

        for s in top_starts:
            panel_slots.append((0, slice(s, s + 2)))

        if bottom_n == 1:
            bottom_starts = [2]
        elif bottom_n == 2:
            bottom_starts = [1, 3]
        elif bottom_n == 3:
            bottom_starts = [0, 2, 4]
        else:
            bottom_starts = []

        for s in bottom_starts:
            panel_slots.append((1, slice(s, s + 2)))

        ylabel_indices = {0}
        if bottom_n > 0:
            ylabel_indices.add(top_n)

    gs = GridSpec(
        nrows=3,
        ncols=ncols,
        figure=fig,
        height_ratios=[1.0, 1.0, 0.45],
        hspace=0.3,
        wspace=0.32,
        left=0.035,
        right=0.985,
        top=0.905,
        bottom=0.045,
    )

    for i, snapshot in enumerate(snapshots):
        row, col_slice = panel_slots[i]
        ax = fig.add_subplot(gs[row, col_slice])
        plot_snapshot(
            ax,
            snapshot,
            color_map,
            limits,
            show_ylabel=(i in ylabel_indices),
        )

    legend_ax = fig.add_subplot(gs[2, :])
    legend_ax.axis("off")

    handles = make_legend_handles(type_order, color_map)
    labels = [DISPLAY_NAME_MAP.get(x, x) for x in type_order]

    legend_ax.legend(
        handles=handles,
        labels=labels,
        loc="center",
        bbox_to_anchor=(0.0, 0.02, 1.0, 0.96),
        bbox_transform=legend_ax.transAxes,
        ncol=LEGEND_NCOL,
        mode="expand",
        frameon=False,
        fontsize=LEGEND_FONT_SIZE,
        handlelength=0.72,
        handletextpad=0.22,
        columnspacing=0.95,
        labelspacing=0.62,
        borderaxespad=0.0,
        markerscale=1.0,
    )

    if SHOW_MAIN_TITLE:
        fig.suptitle(
            MAIN_TITLE,
            fontsize=MAIN_TITLE_SIZE,
            y=0.968,
            fontweight="normal",
        )

    out_png = OUTPUT_DIR / "umap_DNA_ARG_type_epochs_multipanel_clean_v2.png"
    out_pdf = OUTPUT_DIR / "umap_DNA_ARG_type_epochs_multipanel_clean_v2.pdf"
    out_svg = OUTPUT_DIR / "umap_DNA_ARG_type_epochs_multipanel_clean_v2.svg"

    fig.savefig(out_png, dpi=SAVE_DPI, bbox_inches="tight", pad_inches=0.06)
    fig.savefig(out_pdf, bbox_inches="tight", pad_inches=0.06)
    fig.savefig(out_svg, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)

    print(f"[Saved] {out_png}")
    print(f"[Saved] {out_pdf}")
    print(f"[Saved] {out_svg}")

def save_coordinates(snapshots):
    all_parts = []

    for s in snapshots:
        df = s["df"].copy()

        keep_cols = [
            c for c in df.columns
            if not c.startswith("embed_")
            and not c.startswith("__")
        ]

        out = df[keep_cols].copy()

        # DNA snapshot CSV already contains epoch / is_best.
        # Overwrite them instead of inserting duplicate columns.
        out["snapshot_title"] = s["title"]
        out["snapshot_epoch"] = int(s["epoch"])
        out["is_best"] = bool(s["is_best"])

        # Put metadata columns at the front in a stable order.
        front_cols = [
            "snapshot_title",
            "snapshot_epoch",
            "is_best",
        ]

        remaining_cols = [
            c for c in out.columns
            if c not in front_cols
        ]

        out = out[
            front_cols + remaining_cols
        ].copy()

        out["UMAP1"] = s["Z"][:, 0]
        out["UMAP2"] = s["Z"][:, 1]

        safe_name = (
            f"best_epoch_{s['epoch']:03d}"
            if s["is_best"]
            else f"epoch_{s['epoch']:03d}"
        )

        out.to_csv(
            OUTPUT_DIR / f"umap_coordinates_{safe_name}.csv",
            index=False,
            encoding="utf-8-sig",
        )

        all_parts.append(out)

    pd.concat(
        all_parts,
        ignore_index=True,
    ).to_csv(
        OUTPUT_DIR / "dna_umap_coordinates_all_snapshots.csv",
        index=False,
        encoding="utf-8-sig",
    )

def main():
    print("=" * 80)
    print("ARGScope multi-length DNA student: clean UMAP plotting v2")
    print("=" * 80)
    print(f"ROOT_DIR   = {ROOT_DIR}")
    print(f"INPUT_DIR  = {INPUT_DIR}")
    print(f"OUTPUT_DIR = {OUTPUT_DIR}")

    snapshot_infos = discover_snapshots()
    snapshots = [load_one_snapshot(info) for info in snapshot_infos]
    snapshots = align_snapshots(snapshots)
    type_order, color_map = build_color_mapping(snapshots)
    snapshots = compute_shared_umap(snapshots)
    save_coordinates(snapshots)
    plot_clean_multipanel(snapshots, type_order, color_map)

    print("\nDone.")
    print(f"Results saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":
    main()
