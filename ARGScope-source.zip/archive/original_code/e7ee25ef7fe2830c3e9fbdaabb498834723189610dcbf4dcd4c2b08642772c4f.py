"""Update the approved spaced VF/BGC SVG without changing the VF results.

BGC means come from the verified normalized-label rerun. No error bars.
Original SVGs, result tables, prediction CSVs, and sample splits are read-only.
"""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import math
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
from PIL import ImageFont
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

OUT = Path(__file__).resolve().parent
PAPER = Path(r"C:\Users\Jie Pan\Desktop\ARG模型结果\论文撰写")
TEMPLATE = PAPER / "result图片/VF_BGC_组图_统一字号_宽间距_20260929/VF_BGC_uniform14pt_spaced_A3.svg"
OLD_DATA = PAPER / "result图片/VF_BGC_unified_black_20260926/data"
NEW = Path(r"E:\1. ARGmodel\BGC数据处理\BGC_standardized_20261006")
PANELS = PAPER / "结果图/BGC_normalized_20261006"
VF_ROOT = Path(r"E:\1. ARGmodel\毒力因子数据处理\独立因子新结果\1.result")
NS = "{http://www.w3.org/2000/svg}"
ET.register_namespace("", NS[1:-1])
FONTS = {False: ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 32),
         True: ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 32)}
HASHES = {}
METRICS = ("ACC", "Precision", "Recall", "F1", "MCC")
KEYS = {"ACC": "accuracy", "Precision": "precision", "Recall": "recall", "F1": "f1", "MCC": "mcc"}
ORANGES = ("#FFFAF5", "#FEE4C5", "#FBC58B", "#F5A14D", "#E87B17")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path, **kwargs):
    HASHES[str(path)] = digest(path)
    return pd.read_csv(path, keep_default_na=False, **kwargs)


def canonical(label):
    return "Ribosomal peptide" if label == "RiPP" else label


def get_group(root, name):
    return next(g for g in root if g.get("id") == name)


def shade(value):
    def rgb(color):
        return np.array([int(color[i:i + 2], 16) for i in (1, 3, 5)])
    location = max(0, min(1, value)) * (len(ORANGES) - 1)
    lo = min(int(location), len(ORANGES) - 2)
    fraction = location - lo
    color = np.rint(rgb(ORANGES[lo]) * (1 - fraction) + rgb(ORANGES[lo + 1]) * fraction).astype(int)
    return "#" + "".join(f"{x:02x}" for x in color)


def verify_vf(root):
    metrics = read(OLD_DATA / "VF_metrics_unchanged.csv")
    heat = read(OLD_DATA / "VF_heatmap_values_unchanged.csv", index_col=0)
    stored_counts = read(OLD_DATA / "VF_type_counts_by_split.csv", index_col=0)
    records = []
    for branch, directory in (("AA", "1Protein_student_VF"), ("NT", "2DNA_student_VF")):
        pred = read(VF_ROOT / directory / "test_sequence_predictions.csv")
        manifest = read(VF_ROOT / directory / "split_manifest.csv")
        assert pred.id.is_unique and len(pred) == 11753
        assert set(pred.id) == set(manifest.loc[manifest.model_split == "test", "id"])
        counts = manifest.groupby(["type", "model_split"]).size().unstack(fill_value=0)
        assert np.array_equal(counts.loc[stored_counts.index, stored_counts.columns], stored_counts)
        assert int(manifest.type.ne("non-VF").sum()) == 29083
        for task, field, average in (("Binary", "binary", "binary"), ("Subtype", "subtype", "weighted")):
            true, estimate = pred["true_" + field], pred["predicted_" + field]
            if task == "Binary":
                true, estimate = true.ne("non-VF").astype(int), estimate.ne("non-VF").astype(int)
            p, r, f, _ = precision_recall_fscore_support(true, estimate, average=average, zero_division=0)
            values = [accuracy_score(true, estimate), p, r, f, matthews_corrcoef(true, estimate)]
            selected = metrics[(metrics.Model == "VFScope-" + branch) & (metrics.Task == task)
                               & (metrics.Average == average)].iloc[0]
            np.testing.assert_allclose(values, selected[list(METRICS)].to_numpy(float), atol=1e-12, rtol=0)
            group = get_group(root, "VF_" + ("binary" if task == "Binary" else "subtype"))
            if task == "Subtype":
                for item in group:
                    if item.get("data-task") == "Subtype" and item.get("data-model") == branch:
                        assert abs(float(item.get("data-value")) - selected[item.get("data-metric")]) < 1e-12
            records.append({"branch": branch, "task": task, "metrics_recomputed_match": True})
        p, r, f, _ = precision_recall_fscore_support(
            pred.true_type, pred.predicted_type, labels=list(heat.index[1:]), zero_division=0,
        )
        for name, numbers in zip(("Precision", "Recall", "F1"), (p, r, f)):
            np.testing.assert_allclose(np.r_[np.mean(numbers), numbers], heat[name + "_" + branch], atol=1e-12, rtol=0)
    for item in get_group(root, "VF_type"):
        if item.get("data-task") == "Type":
            value = float(heat.loc[item.get("data-type"), item.get("data-metric") + "_" + item.get("data-model")])
            assert abs(float(item.get("data-value")) - value) < 1e-12
    return records


def load_bgc():
    final = json.loads((NEW / "Results/finalization_status.json").read_text(encoding="utf-8"))
    assert final["complete"]
    provenance = json.loads((PANELS / "plot_provenance_and_qa.json").read_text(encoding="utf-8"))
    for source, expected in provenance["source_sha256"].items():
        assert digest(source) == expected, source
        HASHES[source] = expected
    metrics = read(NEW / "Results/mean_std_metrics.csv")
    metrics = metrics[metrics.method == "ARGScope"]
    assert set(metrics.seeds_completed) == {3}
    heat = read(PANELS / "type_heatmap_values.csv")
    by_seed = read(PANELS / "type_values_by_seed.csv")
    assert set(by_seed.seed) == {20260915, 20261006, 20261007}
    expected = by_seed.groupby(["branch", "label", "metric"]).value.mean()
    for row in heat.itertuples():
        assert abs(row.mean - expected.loc[row.branch, row.label, row.metric]) < 1e-12
    labels = read(NEW / "Dataset/normalized_BGC_nonBGC_labels_and_fixed_splits.csv")
    counts = labels.groupby(["type", "model_split"]).size().unstack(fill_value=0)
    validation_name = "validation" if "validation" in counts.columns else "val"
    old_counts = read(OLD_DATA / "BGC_type_counts_by_split.csv", index_col=0)
    for old_label, old_row in old_counts.iterrows():
        np.testing.assert_array_equal(
            old_row[["train", "validation", "test"]].to_numpy(int),
            counts.loc[canonical(old_label), ["train", validation_name, "test"]].to_numpy(int),
        )
    assert int(labels.type.ne("nonBGC").sum()) == 32463
    values = {}
    for branch in ("AA", "NT"):
        for task in ("binary", "subtype"):
            for name in METRICS:
                key = KEYS[name]
                if name not in ("ACC", "MCC"):
                    key = ("positive_" if task == "binary" else "weighted_") + key
                selected = metrics[(metrics.branch == branch) & (metrics.task == task) & (metrics.metric == key)]
                assert len(selected) == 1
                values[(branch, task, name)] = float(selected.iloc[0]["mean"])
    hvalues = {(r.branch, r.label, r.metric.title() if r.metric != "f1" else "F1"): float(r.mean)
               for r in heat.itertuples()}
    return values, hvalues


def update_bgc(root, values, hvalues):
    radar = get_group(root, "BGC_binary")
    cx, cy, radius = 1105.0, 1125.0, 96.0
    branch = None
    for element in radar:
        tag = element.tag.removeprefix(NS)
        if tag == "polygon":
            branch = element.get("data-model")
            points = []
            for i, name in enumerate(METRICS):
                value = values[(branch, "binary", name)]
                angle = -math.pi / 2 + i * 2 * math.pi / 5
                points.append((cx + radius * value * math.cos(angle), cy + radius * value * math.sin(angle)))
            element.set("points", " ".join(f"{x:.6f},{y:.6f}" for x, y in points))
            element.set("data-statistic", "mean_of_three_seeds")
        elif element.get("data-metric"):
            name = element.get("data-metric")
            i = METRICS.index(name)
            value = values[(branch, "binary", name)]
            angle = -math.pi / 2 + i * 2 * math.pi / 5
            x, y = cx + radius * value * math.cos(angle), cy + radius * value * math.sin(angle)
            if tag == "circle":
                element.set("cx", str(x)); element.set("cy", str(y))
            else:
                element.set("x", str(x - 4.5)); element.set("y", str(y - 4.5))
            element.set("data-value", repr(value))
    bars = get_group(root, "BGC_subtype")
    for item in bars:
        if item.get("data-task") != "Subtype":
            continue
        value = values[(item.get("data-model"), "subtype", item.get("data-metric"))]
        item.set("data-value", repr(value))
        item.set("data-statistic", "mean_of_three_seeds")
        for rect in item:
            assert rect.tag == NS + "rect"
            rect.set("y", str(1200 - value * 205)); rect.set("height", str(value * 205))
    assert len([g for g in bars if g.get("data-task") == "Subtype"]) == 10
    heat = get_group(root, "BGC_type")
    for element in heat.iter():
        if element.tag == NS + "text" and element.text == "RiPP":
            element.text = "Ribosomal peptide"
        if element.get("data-task") == "Type":
            label = canonical(element.get("data-type"))
            value = hvalues[(element.get("data-model"), label, element.get("data-metric"))]
            element.set("data-type", label); element.set("data-value", repr(value))
            element.set("data-statistic", "mean_of_three_seeds")
            element.find(NS + "rect").set("fill", shade(value))
            element.find(NS + "text").text = f"{value:.4f}"
    dataset = get_group(root, "BGC_dataset")
    for element in dataset.iter():
        if element.tag == NS + "text" and element.text == "RiPP":
            element.text = "Ribosomal peptide"
        if element.get("data-type") == "RiPP":
            element.set("data-type", "Ribosomal peptide")


def check_layout(root):
    left, top, width, height = map(float, root.get("viewBox").split())
    boxes = []
    for text in root.iter(NS + "text"):
        assert text.get("font-family") == "Arial" and text.get("font-size") == "32px"
        assert text.get("fill") == "#000000"
        string = text.text or ""
        font = FONTS[text.get("font-weight") == "700"]
        w = font.getlength(string)
        bounds = font.getbbox(string)
        h = bounds[3] - bounds[1] + 2
        x, y = float(text.get("x")), float(text.get("y"))
        anchor = text.get("text-anchor")
        x0 = x - (w / 2 if anchor == "middle" else w if anchor == "end" else 0)
        box = (x0, y - h / 2, x0 + w, y + h / 2, string)
        assert box[0] >= left and box[2] <= left + width and box[1] >= top and box[3] <= top + height, box
        boxes.append(box)
    overlaps = []
    for i, a in enumerate(boxes):
        for b in boxes[i + 1:]:
            dx, dy = min(a[2], b[2]) - max(a[0], b[0]), min(a[3], b[3]) - max(a[1], b[1])
            if dx > 2 and dy > 2:
                overlaps.append([a[4], b[4], round(dx, 2), round(dy, 2)])
    assert not overlaps, overlaps
    assert not list(root.iter(NS + "image"))
    for item in root.iter(NS + "g"):
        if item.get("data-task") == "Type":
            assert item.find(NS + "text").get("font-weight") == ("700" if item.get("data-type") == "Average" else "400")
    return {"all_text_inside_canvas": True, "text_overlap_candidates": [], "font_family": "Arial",
            "uniform_font_px": 32, "native_font_pt": 14, "raster_images": 0, "subtype_error_bars": False}


def add_letters(root):
    group = ET.SubElement(root, NS + "g", {"id": "panel_letters"})
    for letter, x, y in (("A", 50, 35), ("B", 30, 934), ("C", 495, 934),
                         ("D", 900, 934), ("E", 1320, 934), ("F", 50, 1340), ("G", 50, 2240)):
        ET.SubElement(group, NS + "text", {"x": str(x), "y": str(y), "font-family": "Arial",
            "font-size": "32px", "fill": "#000000", "font-weight": "700",
            "text-anchor": "start", "dominant-baseline": "central"}).text = letter


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    HASHES[str(TEMPLATE)] = digest(TEMPLATE)
    root = ET.parse(TEMPLATE).getroot()
    protected = {name: ET.tostring(get_group(root, name)) for name in
                 ("VF_dataset", "VF_binary", "VF_subtype", "VF_type", "dataset_legend", "model_legend")}
    vf_checks = verify_vf(root)
    values, heat = load_bgc()
    update_bgc(root, values, heat)
    for name, original in protected.items():
        assert ET.tostring(get_group(root, name)) == original, name
    description = (
        "VF results and dataset counts are unchanged from the approved source figure. "
        "BGC results are arithmetic means across seeds 20260915, 20261006, and 20261007. "
        "Binary precision, recall, and F1 use the target-positive class. Subtype bars use support-weighted metrics. "
        "Type Average equally weights all positive types and the negative class. "
        "No subtype error bars. BGC subtype evaluation includes 10453 records, whereas binary and type use 13026. "
        "RiPP is normalized to Ribosomal peptide. Uniform Arial 14 pt at native A3 size."
    )
    root.find(NS + "desc").text = description
    meta = root.find(NS + "metadata")
    meta.text = json.dumps({"description": description, "source_sha256": HASHES}, ensure_ascii=False)
    no_letters = OUT / "VF_BGC_updated_no_letters.svg"
    qa_no_letters = check_layout(root)
    ET.ElementTree(root).write(no_letters, encoding="utf-8", xml_declaration=True)
    labelled = deepcopy(root)
    add_letters(labelled)
    qa_labelled = check_layout(labelled)
    primary = OUT / "VF_BGC_updated_composite.svg"
    ET.ElementTree(labelled).write(primary, encoding="utf-8", xml_declaration=True)
    for source, original in HASHES.items():
        assert digest(source) == original, source
    report = {
        "VF_groups_unchanged": True, "VF_independent_metric_checks": vf_checks,
        "BGC_seeds": [20260915, 20261006, 20261007], "BGC_statistic": "mean, not best seed",
        "BGC_binary_type_N": 13026, "BGC_subtype_N": 10453,
        "source_sha256": HASHES,
        "outputs": [{"file": str(primary), "panel_letters": True, **qa_labelled},
                    {"file": str(no_letters), "panel_letters": False, **qa_no_letters}],
    }
    (OUT / "verification.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"complete": True, "SVG": str(primary), "no_letters_SVG": str(no_letters)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
