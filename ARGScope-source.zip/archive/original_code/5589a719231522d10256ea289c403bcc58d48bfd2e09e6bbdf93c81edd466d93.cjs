const fs=require('fs');
const path=require('path');
const sharp=require('C:/Users/Jie Pan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve(process.argv[2] || 'outputs/figure4_larger_fonts_20260923');
const qa=path.join(root,'qa');fs.mkdirSync(qa,{recursive:true});
(async()=>{
 const report=[];
 for(const variant of ['','editable_text']){
  for(const file of fs.readdirSync(path.join(root,variant)).filter(f=>f.endsWith('.svg'))){
   const svg=fs.readFileSync(path.join(root,variant,file));
   if(/<image\b/.test(svg.toString()))throw Error('Raster image');
   const render=await sharp(svg,{density:150}).resize({width:2400}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
   const {width,height,channels}=render.info;
   let x0=width,y0=height,x1=-1,y1=-1,transparent=0;
   for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const a=render.data[(y*width+x)*channels+channels-1];
    if(a===0)transparent++;
    if(a>5){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
   }
   const margins=[x0,y0,width-1-x1,height-1-y1];
   if(!transparent || Math.min(...margins)<1)throw Error('Transparency/crop check failed '+file+' '+margins);
   await sharp(render.data,{raw:render.info}).flatten({background:'#ffffff'}).png().toFile(path.join(qa,(variant?'editable_':'')+file.replace('.svg','.png')));
   report.push({file,variant:variant||'outlined',transparent_pixels:transparent,margins_px:margins,pure_vector:true});
  }
 }
 fs.writeFileSync(path.join(qa,'svg_render_verification.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
