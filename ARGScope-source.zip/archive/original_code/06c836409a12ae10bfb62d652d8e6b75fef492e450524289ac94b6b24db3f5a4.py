#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
计算 60p、70p、80p、90p、100p fragment 预测结果中每个 Type 的五个指标。

输入文件名：
    subtype_predictions_60p_fragment.csv
    subtype_predictions_70p_fragment.csv
    subtype_predictions_80p_fragment.csv
    subtype_predictions_90p_fragment.csv
    subtype_predictions_100p_fragment.csv

输入文件需要包含：
    Type       真实 Type
    Pred_Type  预测 Type

每个输出表固定只有6列：
    Type, ACC, PRECISION, RECALL, F1, MCC

说明：
    ACC 沿用此前 ARGScope 逐 Type 结果的定义：
        ACC = 当前 Type 预测正确数 / 当前 Type 真实样本数
    因此逐 Type 的 ACC 与 RECALL 数值相同。

输出：
    type_metrics_outputs_60p_100p/
        type_metrics_60p_fragment.csv
        type_metrics_70p_fragment.csv
        type_metrics_80p_fragment.csv
        type_metrics_90p_fragment.csv
        type_metrics_100p_fragment.csv
        type_metrics_60p_to_100p_fragment.xlsx
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from sklearn.metrics import (
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
)


LENGTHS = ["60p", "70p", "80p", "90p", "100p"]

TRUE_TYPE_COL = "Type"
PRED_TYPE_COL = "Pred_Type"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Calculate per-Type metrics for 60p-100p fragment predictions."
    )
    parser.add_argument(
        "--input-dir",
        default=".",
        help="包含预测CSV文件的目录；默认是当前目录。",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="输出目录；默认是 input-dir/type_metrics_outputs_60p_100p。",
    )
    return parser.parse_args()


def clean_type_name(value: object) -> str:
    return str(value).strip()


def read_prediction_file(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"找不到输入文件：{path}")

    df = pd.read_csv(path, low_memory=False)
    df.columns = [
        str(column).replace("\ufeff", "").strip()
        for column in df.columns
    ]

    missing = [
        column
        for column in [TRUE_TYPE_COL, PRED_TYPE_COL]
        if column not in df.columns
    ]
    if missing:
        raise ValueError(
            f"{path.name} 缺少列：{missing}\n"
            f"当前列名：{df.columns.tolist()}"
        )

    if df[TRUE_TYPE_COL].isna().any():
        raise ValueError(
            f"{path.name} 的 {TRUE_TYPE_COL} 列存在缺失值。"
        )
    if df[PRED_TYPE_COL].isna().any():
        raise ValueError(
            f"{path.name} 的 {PRED_TYPE_COL} 列存在缺失值。"
        )

    df[TRUE_TYPE_COL] = df[TRUE_TYPE_COL].map(clean_type_name)
    df[PRED_TYPE_COL] = df[PRED_TYPE_COL].map(clean_type_name)

    return df


def calculate_one_type(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    type_name: str,
) -> dict:
    """
    将当前 Type 作为正类，其余 Type 作为负类，计算 one-vs-rest 指标。
    """
    true_mask = y_true == type_name
    pred_mask = y_pred == type_name

    tp = int(np.sum(true_mask & pred_mask))
    fn = int(np.sum(true_mask & ~pred_mask))
    support = tp + fn

    # 与此前逐 Type 表格中的 ACC 定义保持一致。
    acc = tp / support if support > 0 else 0.0

    y_true_binary = true_mask.astype(np.int8)
    y_pred_binary = pred_mask.astype(np.int8)

    precision = precision_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )
    recall = recall_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )
    f1 = f1_score(
        y_true_binary,
        y_pred_binary,
        zero_division=0,
    )

    if (
        len(np.unique(y_true_binary)) == 1
        and len(np.unique(y_pred_binary)) == 1
    ):
        mcc = 0.0
    else:
        mcc = matthews_corrcoef(
            y_true_binary,
            y_pred_binary,
        )

    return {
        "Type": type_name,
        "ACC": float(acc),
        "PRECISION": float(precision),
        "RECALL": float(recall),
        "F1": float(f1),
        "MCC": float(mcc),
    }


def calculate_file_metrics(
    df: pd.DataFrame,
    all_type_names: list[str],
) -> pd.DataFrame:
    y_true = df[TRUE_TYPE_COL].to_numpy(dtype=str)
    y_pred = df[PRED_TYPE_COL].to_numpy(dtype=str)

    rows = [
        calculate_one_type(
            y_true=y_true,
            y_pred=y_pred,
            type_name=type_name,
        )
        for type_name in all_type_names
    ]

    result = pd.DataFrame(
        rows,
        columns=[
            "Type",
            "ACC",
            "PRECISION",
            "RECALL",
            "F1",
            "MCC",
        ],
    )

    return result.sort_values("Type").reset_index(drop=True)


def format_excel(path: Path):
    workbook = load_workbook(path)

    header_fill = PatternFill(
        fill_type="solid",
        fgColor="D9EAF7",
    )
    header_font = Font(
        bold=True,
        color="000000",
    )

    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions
        worksheet.sheet_view.showGridLines = False

        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
            )

        worksheet.column_dimensions["A"].width = 38

        for column_letter in ["B", "C", "D", "E", "F"]:
            worksheet.column_dimensions[column_letter].width = 14

        for row in worksheet.iter_rows(
            min_row=2,
            min_col=2,
            max_col=6,
        ):
            for cell in row:
                cell.number_format = "0.0000"
                cell.alignment = Alignment(horizontal="center")

    workbook.save(path)


def main():
    args = parse_args()

    input_dir = Path(args.input_dir).resolve()
    output_dir = (
        Path(args.output_dir).resolve()
        if args.output_dir
        else input_dir / "type_metrics_outputs_60p_100p"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("Per-Type metrics for 60p / 70p / 80p / 90p / 100p")
    print("=" * 80)
    print("Input directory :", input_dir)
    print("Output directory:", output_dir)

    dataframes = {}
    observed_types = set()

    for length_name in LENGTHS:
        filename = f"subtype_predictions_{length_name}_fragment.csv"
        file_path = input_dir / filename

        df = read_prediction_file(file_path)
        dataframes[length_name] = df

        observed_types.update(df[TRUE_TYPE_COL].unique())
        observed_types.update(df[PRED_TYPE_COL].unique())

        print(
            f"{length_name}: rows={len(df):,}, "
            f"true Types={df[TRUE_TYPE_COL].nunique()}, "
            f"predicted Types={df[PRED_TYPE_COL].nunique()}"
        )

    # 所有长度使用同一套 Type 行和相同顺序。
    all_type_names = sorted(observed_types)

    result_tables = {}

    for length_name in LENGTHS:
        result = calculate_file_metrics(
            dataframes[length_name],
            all_type_names,
        )
        result_tables[length_name] = result

        output_csv = (
            output_dir
            / f"type_metrics_{length_name}_fragment.csv"
        )

        result.round(4).to_csv(
            output_csv,
            index=False,
            encoding="utf-8-sig",
        )
        print("Saved:", output_csv)

    output_excel = (
        output_dir
        / "type_metrics_60p_to_100p_fragment.xlsx"
    )

    with pd.ExcelWriter(
        output_excel,
        engine="openpyxl",
    ) as writer:
        for length_name in LENGTHS:
            result_tables[length_name].round(4).to_excel(
                writer,
                sheet_name=length_name,
                index=False,
            )

    format_excel(output_excel)

    print("Saved:", output_excel)
    print("\n每张结果表固定为：")
    print("Type | ACC | PRECISION | RECALL | F1 | MCC")


if __name__ == "__main__":
    main()
