from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


# =========================================================
# 1. 输入文件
# =========================================================

BASE_DIR = Path.cwd()

# 如果你的文件名不是这个，改这里
TYPE_FILE = BASE_DIR / "type_metrics_by_class.csv"

# 如果找不到 type_metrics_by_class.csv，则自动寻找当前文件夹下符合格式的 csv
if not TYPE_FILE.exists():
    candidate_files = list(BASE_DIR.glob("*.csv"))
    matched_file = None

    for file in candidate_files:
        tmp = pd.read_csv(file, nrows=3)
        tmp.columns = tmp.columns.astype(str).str.strip()
        required_cols = {"Type", "support", "F1", "MCC"}
        if required_cols.issubset(set(tmp.columns)):
            matched_file = file
            break

    if matched_file is None:
        raise FileNotFoundError(
            "当前文件夹中没有找到包含 Type, support, F1, MCC 列的 CSV 文件。"
        )

    TYPE_FILE = matched_file

OUTPUT_DIR = BASE_DIR / "type_level_performance_ranked_plot"
OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_PDF = OUTPUT_DIR / "type_level_performance_ranked_plot.pdf"
OUTPUT_TIF = OUTPUT_DIR / "type_level_performance_ranked_plot.tif"
OUTPUT_DATA = OUTPUT_DIR / "type_level_performance_ranked_plot_data.csv"


# =========================================================
# 2. 参数设置
# =========================================================

# 是否显示所有 type
SHOW_ALL_TYPES = True

# 如果不想显示所有 type，可以改成 False，并设置 TOP_N_TYPES
TOP_N_TYPES = 25

# 配色
COLOR_SUPPORT = "#8491B4"
COLOR_F1 = "#3C5488"
COLOR_MCC = "#E64B35"

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# =========================================================
# 3. 读取数据
# =========================================================

df = pd.read_csv(TYPE_FILE)
df.columns = df.columns.astype(str).str.strip()

required_cols = [
    "Type",
    "support",
    "pred_count",
    "correct_count",
    "ACC",
    "PRECISION",
    "RECALL",
    "F1",
    "MCC",
]

missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    raise ValueError(f"CSV 文件缺少这些列: {missing_cols}")

df["Type"] = df["Type"].astype(str).str.strip()

numeric_cols = [
    "support",
    "pred_count",
    "correct_count",
    "ACC",
    "PRECISION",
    "RECALL",
    "F1",
    "MCC",
]

for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

if df[numeric_cols].isna().any().any():
    bad_cols = df[numeric_cols].columns[df[numeric_cols].isna().any()].tolist()
    raise ValueError(f"这些数值列存在无法转换的内容: {bad_cols}")


# =========================================================
# 4. 排序与筛选
# =========================================================

df = df.sort_values("support", ascending=True).reset_index(drop=True)

if not SHOW_ALL_TYPES:
    df = (
        df.sort_values("support", ascending=False)
        .head(TOP_N_TYPES)
        .sort_values("support", ascending=True)
        .reset_index(drop=True)
    )

df.to_csv(OUTPUT_DATA, index=False, encoding="utf-8-sig")


# =========================================================
# 5. 绘图
# =========================================================

n_types = len(df)

fig_height = max(5.2, n_types * 0.28)

fig, axes = plt.subplots(
    1,
    2,
    figsize=(10.5, fig_height),
    dpi=600,
    gridspec_kw={"width_ratios": [1.0, 1.35], "wspace": 0.08},
    sharey=True,
)

ax_support, ax_perf = axes

y_pos = np.arange(n_types)


# =========================================================
# 5.1 左图：support 分布
# =========================================================

ax_support.barh(
    y_pos,
    df["support"],
    color=COLOR_SUPPORT,
    edgecolor="black",
    linewidth=0.4,
    height=0.65,
)

ax_support.set_yticks(y_pos)
ax_support.set_yticklabels(df["Type"], fontsize=7)
ax_support.set_xlabel("Support")
ax_support.set_title("Number of samples", fontsize=10, pad=10)

# 样本数差异大，使用 log 坐标更清楚
ax_support.set_xscale("log")

ax_support.grid(
    axis="x",
    linestyle="-",
    linewidth=0.45,
    alpha=0.45,
)

ax_support.spines["top"].set_visible(False)
ax_support.spines["right"].set_visible(False)

# 标注 support 数值
for y, support in zip(y_pos, df["support"]):
    ax_support.text(
        support * 1.08,
        y,
        str(int(support)),
        va="center",
        ha="left",
        fontsize=6.5,
    )


# =========================================================
# 5.2 右图：F1 和 MCC 点图
# =========================================================

ax_perf.scatter(
    df["F1"],
    y_pos,
    color=COLOR_F1,
    edgecolor="black",
    linewidth=0.4,
    s=28,
    label="F1-score",
    zorder=3,
)

ax_perf.scatter(
    df["MCC"],
    y_pos,
    color=COLOR_MCC,
    edgecolor="black",
    linewidth=0.4,
    s=28,
    label="MCC",
    zorder=3,
)

# 每个 type 用一条灰线连接 F1 和 MCC，方便比较
for y, f1, mcc in zip(y_pos, df["F1"], df["MCC"]):
    ax_perf.plot(
        [f1, mcc],
        [y, y],
        color="gray",
        linewidth=0.6,
        alpha=0.45,
        zorder=1,
    )

metric_min = min(df["F1"].min(), df["MCC"].min())
metric_max = max(df["F1"].max(), df["MCC"].max())

x_min = max(0, metric_min - 0.02)
x_max = min(1.01, metric_max + 0.01)

# 如果指标过于接近 1.0，自动放大 0.95-1.00 区间
if x_max - x_min < 0.06:
    x_min = max(0, x_max - 0.06)

ax_perf.set_xlim(x_min, x_max)

ax_perf.set_xlabel("Performance")
ax_perf.set_title("Type-level prediction performance", fontsize=10, pad=10)

ax_perf.grid(
    axis="x",
    linestyle="-",
    linewidth=0.45,
    alpha=0.45,
)

ax_perf.spines["top"].set_visible(False)
ax_perf.spines["right"].set_visible(False)

ax_perf.legend(
    frameon=True,
    fontsize=7,
    loc="lower left",
)


# =========================================================
# 5.3 强调 nonARG
# =========================================================

if "nonARG" in df["Type"].values:
    nonarg_idx = df.index[df["Type"] == "nonARG"][0]

    for ax in axes:
        ax.axhline(
            nonarg_idx,
            color="black",
            linewidth=0.7,
            linestyle="--",
            alpha=0.55,
        )


# =========================================================
# 6. 总标题与保存
# =========================================================

fig.suptitle(
    "Type-level performance inferred from subtype predictions",
    fontsize=12,
    y=0.995,
)

plt.tight_layout(rect=[0, 0, 1, 0.985])

fig.savefig(OUTPUT_PDF, bbox_inches="tight")
fig.savefig(
    OUTPUT_TIF,
    dpi=600,
    bbox_inches="tight",
    pil_kwargs={"compression": "tiff_lzw"},
)

plt.close(fig)


# =========================================================
# 7. 输出
# =========================================================

print(f"\nInput file:")
print(TYPE_FILE)

print("\nSaved:")
print(OUTPUT_PDF)
print(OUTPUT_TIF)
print(OUTPUT_DATA)

print("\nPreview:")
print(df[["Type", "support", "F1", "MCC"]])