# -*- coding: utf-8 -*-
"""
Local post-processing:
Convert existing ARGScope full-real-data results from Gate 0.99 + Q0.20
to Gate 0.99 + Q0.05 WITHOUT rerunning the neural network.

IMPORTANT:
    Input MUST be:
        ARGScope_primary_150nt_fragment_gate_final_predictions.csv

    Do NOT use:
        ARGScope_primary_150nt_fragment_gate_proto_q020_final_predictions.csv

Reason:
    Q0.05 is more permissive than Q0.20. Reads removed by Q0.20 cannot be
    recovered from the q020-final file. The gate-final file still contains
    all Gate-positive reads and their prototype_similarity values.

Threshold rule used here:
    1. Gate >= 0.99
    2. Pred_Subtype / Pred_Type must not be nonARG
    3. For predicted subtype:
         use exact per-subtype Q0.05 threshold if available;
         otherwise fall back to exact global Q0.05 threshold.
    4. prototype_similarity >= selected Q0.05 threshold

This script only uses local CSV files. No GPU, checkpoint, PT embedding,
or model inference is required.
"""

from __future__ import annotations

from pathlib import Path
from collections import Counter
import shutil

import numpy as np
import pandas as pd


# =============================================================================
# 1. PATHS
# =============================================================================

BASE_DIR = Path(
    r"E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed"
)

INPUT_ROOT = (
    BASE_DIR
    / "ARGScope_150nt_无diamond"
    / "ARGScope 结果"
)

MODEL_DIR = (
    BASE_DIR
    / "ARGScope_150nt_primary_multilength_gate_subtype_model"
)

PROTO_THRESHOLD_FILE = (
    MODEL_DIR
    / "prototype_similarity_thresholds.csv"
)

# Write to a NEW folder. Original Q0.20 results are not modified.
OUTPUT_ROOT = (
    BASE_DIR
    / "ARGScope_150nt_无diamond"
    / "ARGScope 结果_gate099_q005"
)

OUTPUT_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)


# =============================================================================
# 2. SETTINGS
# =============================================================================

GATE_THRESHOLD = 0.99
PROTO_QUANTILE = 0.05

INPUT_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_final_predictions.csv"
)

OUTPUT_FINAL_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_proto_q005_final_predictions.csv"
)

OUTPUT_SUBTYPE_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_proto_q005_subtype_counts.csv"
)

OUTPUT_TYPE_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_proto_q005_type_counts.csv"
)

OUTPUT_SUMMARY_FILENAME = (
    "ARGScope_primary_150nt_fragment_gate_proto_q005_summary.csv"
)


# =============================================================================
# 3. HELPERS
# =============================================================================

def find_column(
    df: pd.DataFrame,
    candidates,
    required=True,
):
    """
    Find a column by exact name first, then case-insensitive name.
    """
    for c in candidates:
        if c in df.columns:
            return c

    lower_map = {
        str(c).lower(): c
        for c in df.columns
    }

    for c in candidates:
        if str(c).lower() in lower_map:
            return lower_map[str(c).lower()]

    if required:
        raise ValueError(
            f"Cannot find required column. "
            f"Candidates={candidates}; "
            f"available={df.columns.tolist()}"
        )

    return None


def clean_text(value):
    if pd.isna(value):
        return ""
    return str(value).strip()


def is_nonarg(value):
    return clean_text(value).lower() == "nonarg"


def choose_exact_quantile_rows(
    df: pd.DataFrame,
    level_value: str,
    quantile: float,
) -> pd.DataFrame:

    level_col = find_column(
        df,
        ["level"],
    )

    quantile_col = find_column(
        df,
        ["quantile"],
    )

    q = pd.to_numeric(
        df[quantile_col],
        errors="coerce",
    )

    level = (
        df[level_col]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    mask = (
        level.eq(level_value.lower())
        & np.isclose(
            q.to_numpy(dtype=float),
            float(quantile),
            rtol=0.0,
            atol=1e-10,
            equal_nan=False,
        )
    )

    return df.loc[mask].copy()


# =============================================================================
# 4. LOAD Q0.05 THRESHOLDS
# =============================================================================

def load_q005_thresholds():

    if not PROTO_THRESHOLD_FILE.exists():
        raise FileNotFoundError(
            f"Prototype threshold file not found:\n"
            f"{PROTO_THRESHOLD_FILE}"
        )

    thr = pd.read_csv(
        PROTO_THRESHOLD_FILE,
        encoding="utf-8-sig",
    )

    subtype_col = find_column(
        thr,
        ["Subtype", "subtype"],
    )

    threshold_col = find_column(
        thr,
        [
            "similarity_threshold",
            "prototype_similarity_threshold",
            "threshold",
        ],
    )

    global_rows = choose_exact_quantile_rows(
        thr,
        level_value="global",
        quantile=PROTO_QUANTILE,
    )

    if len(global_rows) == 0:
        available = (
            pd.to_numeric(
                thr.loc[
                    thr[
                        find_column(thr, ["level"])
                    ]
                    .astype(str)
                    .str.lower()
                    .eq("global"),
                    find_column(thr, ["quantile"]),
                ],
                errors="coerce",
            )
            .dropna()
            .unique()
            .tolist()
        )

        raise ValueError(
            f"No exact GLOBAL Q{PROTO_QUANTILE:.2f} row found in:\n"
            f"{PROTO_THRESHOLD_FILE}\n"
            f"Available global quantiles={sorted(available)}"
        )

    global_threshold = float(
        pd.to_numeric(
            global_rows.iloc[0][threshold_col],
            errors="raise",
        )
    )

    per_rows = choose_exact_quantile_rows(
        thr,
        level_value="per_subtype",
        quantile=PROTO_QUANTILE,
    )

    per_subtype = {}

    for _, row in per_rows.iterrows():

        subtype = clean_text(
            row[subtype_col]
        )

        threshold = pd.to_numeric(
            row[threshold_col],
            errors="coerce",
        )

        if (
            subtype
            and pd.notna(threshold)
            and np.isfinite(float(threshold))
        ):
            per_subtype[subtype] = float(
                threshold
            )

    print("=" * 90)
    print("Q0.05 prototype thresholds")
    print("=" * 90)
    print(
        f"Threshold file : {PROTO_THRESHOLD_FILE}"
    )
    print(
        f"Global Q0.05   : {global_threshold:.8f}"
    )
    print(
        f"Per-subtype Q0.05 rows: {len(per_subtype):,}"
    )
    print(
        "Rule: per-subtype Q0.05 if available; "
        "otherwise global Q0.05."
    )
    print("=" * 90)

    return global_threshold, per_subtype


# =============================================================================
# 5. DEDUPLICATION
# =============================================================================

def deduplicate_predictions(
    df: pd.DataFrame,
) -> pd.DataFrame:

    if df.empty:
        return df.copy()

    id_col = find_column(
        df,
        ["Original_ID", "read_id", "ID", "id"],
    )

    gate_col = find_column(
        df,
        [
            "arg_gate_probability",
            "gate_probability",
        ],
        required=False,
    )

    subtype_conf_col = find_column(
        df,
        [
            "subtype_confidence",
            "subtype_probability_among_ARG_classes",
        ],
        required=False,
    )

    sim_col = find_column(
        df,
        ["prototype_similarity"],
    )

    sort_cols = [id_col]
    ascending = [True]

    if gate_col is not None:
        sort_cols.append(gate_col)
        ascending.append(False)

    sort_cols.append(sim_col)
    ascending.append(False)

    if subtype_conf_col is not None:
        sort_cols.append(
            subtype_conf_col
        )
        ascending.append(False)

    out = (
        df.sort_values(
            sort_cols,
            ascending=ascending,
            kind="mergesort",
        )
        .drop_duplicates(
            subset=[id_col],
            keep="first",
        )
        .copy()
    )

    final_sort = []

    if gate_col is not None:
        final_sort.append(gate_col)

    final_sort.append(sim_col)

    if subtype_conf_col is not None:
        final_sort.append(
            subtype_conf_col
        )

    if final_sort:
        out = out.sort_values(
            final_sort,
            ascending=[False] * len(
                final_sort
            ),
            kind="mergesort",
        )

    return out


# =============================================================================
# 6. COUNTS
# =============================================================================

def save_count_table(
    df: pd.DataFrame,
    label_col: str,
    output_file: Path,
    sample_name: str,
):

    if df.empty:
        out = pd.DataFrame(
            columns=[
                "sample",
                label_col,
                "Count",
                "gate_threshold",
                "prototype_quantile",
            ]
        )
    else:
        counts = (
            df[label_col]
            .astype(str)
            .value_counts()
        )

        out = pd.DataFrame({
            "sample": sample_name,
            label_col: counts.index,
            "Count": counts.values.astype(int),
            "gate_threshold": GATE_THRESHOLD,
            "prototype_quantile": PROTO_QUANTILE,
        })

    out.to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig",
    )


# =============================================================================
# 7. PROCESS ONE SAMPLE
# =============================================================================

def process_one_sample(
    sample_dir: Path,
    global_threshold: float,
    per_subtype: dict,
):

    sample_name = sample_dir.name

    input_file = (
        sample_dir
        / INPUT_FILENAME
    )

    if not input_file.exists():
        print(
            f"[SKIP] {sample_name}: "
            f"missing {INPUT_FILENAME}"
        )
        return None

    print()
    print("=" * 90)
    print(
        f"Processing: {sample_name}"
    )
    print(
        f"Input: {input_file}"
    )

    df = pd.read_csv(
        input_file,
        encoding="utf-8-sig",
    )

    original_gate_rows = len(df)

    subtype_col = find_column(
        df,
        ["Pred_Subtype", "subtype"],
    )

    type_col = find_column(
        df,
        ["Pred_Type", "type"],
    )

    sim_col = find_column(
        df,
        ["prototype_similarity"],
    )

    id_col = find_column(
        df,
        ["Original_ID", "read_id", "ID", "id"],
    )

    gate_prob_col = find_column(
        df,
        [
            "arg_gate_probability",
            "gate_probability",
        ],
        required=False,
    )

    # -------------------------------------------------------------------------
    # Protect old Q0.20 diagnostic columns from being mislabeled as Q0.05.
    # -------------------------------------------------------------------------

    rename_old = {}

    if "prototype_similarity_threshold" in df.columns:
        rename_old[
            "prototype_similarity_threshold"
        ] = (
            "prototype_similarity_threshold_original_q020"
        )

    if "prototype_threshold_source" in df.columns:
        rename_old[
            "prototype_threshold_source"
        ] = (
            "prototype_threshold_source_original_q020"
        )

    if "Is_ARG_by_prototype" in df.columns:
        rename_old[
            "Is_ARG_by_prototype"
        ] = (
            "Is_ARG_by_prototype_original_q020"
        )

    if "Is_ARG_final" in df.columns:
        rename_old[
            "Is_ARG_final"
        ] = (
            "Is_ARG_final_original_q020"
        )

    if rename_old:
        df = df.rename(
            columns=rename_old
        )

    # Numeric similarity.
    df[sim_col] = pd.to_numeric(
        df[sim_col],
        errors="coerce",
    )

    # -------------------------------------------------------------------------
    # The source file should already be Gate 0.99 positive.
    # Recheck it if gate probability is present.
    # -------------------------------------------------------------------------

    if gate_prob_col is not None:

        df[gate_prob_col] = pd.to_numeric(
            df[gate_prob_col],
            errors="coerce",
        )

        gate_mask = (
            df[gate_prob_col]
            >= GATE_THRESHOLD
        )

    else:
        gate_mask = pd.Series(
            True,
            index=df.index,
        )

        print(
            "[WARNING] Gate probability column not found. "
            "Assuming gate_final_predictions.csv is already Gate 0.99 filtered."
        )

    nonarg_mask = (
        ~df[subtype_col]
        .astype(str)
        .str.strip()
        .str.lower()
        .eq("nonarg")
        &
        ~df[type_col]
        .astype(str)
        .str.strip()
        .str.lower()
        .eq("nonarg")
    )

    gate_and_arg = (
        gate_mask
        & nonarg_mask
    )

    # -------------------------------------------------------------------------
    # Build exact Q0.05 threshold for each predicted subtype.
    # -------------------------------------------------------------------------

    selected_thresholds = []
    selected_sources = []

    for subtype in df[
        subtype_col
    ].astype(str):

        subtype = subtype.strip()

        if subtype in per_subtype:

            selected_thresholds.append(
                float(
                    per_subtype[
                        subtype
                    ]
                )
            )

            selected_sources.append(
                "per_subtype_q005"
            )

        else:

            selected_thresholds.append(
                float(
                    global_threshold
                )
            )

            selected_sources.append(
                "global_q005_fallback"
            )

    df[
        "prototype_similarity_threshold"
    ] = np.asarray(
        selected_thresholds,
        dtype=np.float64,
    )

    df[
        "prototype_threshold_source"
    ] = selected_sources

    df[
        "prototype_quantile"
    ] = PROTO_QUANTILE

    df[
        "gate_threshold"
    ] = GATE_THRESHOLD

    prototype_mask = (
        df[sim_col]
        >= df[
            "prototype_similarity_threshold"
        ]
    )

    df[
        "Is_ARG_by_gate"
    ] = gate_mask.astype(int)

    df[
        "Is_ARG_by_prototype"
    ] = prototype_mask.astype(int)

    df[
        "Is_ARG_final"
    ] = (
        gate_and_arg
        & prototype_mask
    ).astype(int)

    final_df = df.loc[
        df["Is_ARG_final"].eq(1)
    ].copy()

    before_dedup = len(
        final_df
    )

    final_df = deduplicate_predictions(
        final_df
    )

    after_dedup = len(
        final_df
    )

    # -------------------------------------------------------------------------
    # Output in a new root, keeping source folder names.
    # -------------------------------------------------------------------------

    sample_out = (
        OUTPUT_ROOT
        / sample_name
    )

    sample_out.mkdir(
        parents=True,
        exist_ok=True,
    )

    final_file = (
        sample_out
        / OUTPUT_FINAL_FILENAME
    )

    subtype_file = (
        sample_out
        / OUTPUT_SUBTYPE_FILENAME
    )

    type_file = (
        sample_out
        / OUTPUT_TYPE_FILENAME
    )

    summary_file = (
        sample_out
        / OUTPUT_SUMMARY_FILENAME
    )

    final_df.to_csv(
        final_file,
        index=False,
        encoding="utf-8-sig",
    )

    save_count_table(
        final_df,
        subtype_col,
        subtype_file,
        sample_name,
    )

    save_count_table(
        final_df,
        type_col,
        type_file,
        sample_name,
    )

    summary = {
        "sample": sample_name,
        "source_file": str(
            input_file
        ),
        "source_gate_final_rows": int(
            original_gate_rows
        ),
        "gate_threshold": float(
            GATE_THRESHOLD
        ),
        "prototype_quantile": float(
            PROTO_QUANTILE
        ),
        "prototype_global_q005_threshold": float(
            global_threshold
        ),
        "per_subtype_q005_threshold_count": int(
            len(
                per_subtype
            )
        ),
        "gate_and_nonARG_filtered_rows": int(
            gate_and_arg.sum()
        ),
        "q005_pass_before_dedup": int(
            before_dedup
        ),
        "q005_pass_after_dedup": int(
            after_dedup
        ),
        "q005_removed_from_gate_final": int(
            int(
                gate_and_arg.sum()
            )
            - before_dedup
        ),
        "q005_retained_fraction_of_gate_final": (
            after_dedup
            / int(
                gate_and_arg.sum()
            )
            if int(
                gate_and_arg.sum()
            ) > 0
            else 0.0
        ),
        "predicted_type_count": int(
            final_df[
                type_col
            ].nunique()
            if after_dedup > 0
            else 0
        ),
        "predicted_subtype_count": int(
            final_df[
                subtype_col
            ].nunique()
            if after_dedup > 0
            else 0
        ),
        "threshold_rule": (
            "exact per-subtype Q0.05 if available; "
            "otherwise exact global Q0.05"
        ),
        "final_file": str(
            final_file
        ),
    }

    pd.DataFrame(
        [summary]
    ).to_csv(
        summary_file,
        index=False,
        encoding="utf-8-sig",
    )

    print(
        f"Gate-final input        : "
        f"{original_gate_rows:,}"
    )

    print(
        f"Gate0.99 + nonARG check : "
        f"{int(gate_and_arg.sum()):,}"
    )

    print(
        f"Gate0.99 + Q0.05        : "
        f"{before_dedup:,} before dedup"
    )

    print(
        f"Final unique reads      : "
        f"{after_dedup:,}"
    )

    print(
        f"Saved: {final_file}"
    )

    return summary


# =============================================================================
# 8. MAIN
# =============================================================================

def main():

    print("=" * 90)
    print(
        "ARGScope local re-filter: "
        "Gate 0.99 + Prototype Q0.05"
    )
    print("=" * 90)

    print(
        f"Input root : {INPUT_ROOT}"
    )

    print(
        f"Model dir  : {MODEL_DIR}"
    )

    print(
        f"Output root: {OUTPUT_ROOT}"
    )

    print()

    print(
        "IMPORTANT: source file is "
        "gate_final_predictions.csv, "
        "NOT q020_final_predictions.csv."
    )

    if not INPUT_ROOT.is_dir():
        raise FileNotFoundError(
            f"Input root not found:\n"
            f"{INPUT_ROOT}"
        )

    global_threshold, per_subtype = (
        load_q005_thresholds()
    )

    sample_dirs = sorted([
        p
        for p in INPUT_ROOT.iterdir()
        if p.is_dir()
    ])

    if not sample_dirs:
        raise RuntimeError(
            f"No sample directories found under:\n"
            f"{INPUT_ROOT}"
        )

    summaries = []

    for sample_dir in sample_dirs:

        result = process_one_sample(
            sample_dir=sample_dir,
            global_threshold=global_threshold,
            per_subtype=per_subtype,
        )

        if result is not None:
            summaries.append(
                result
            )

    if not summaries:
        raise RuntimeError(
            "No sample was processed successfully."
        )

    summary_df = pd.DataFrame(
        summaries
    )

    all_summary_file = (
        OUTPUT_ROOT
        / "ARGScope_primary_150nt_fragment_gate099_q005_all_sample_summary.csv"
    )

    summary_df.to_csv(
        all_summary_file,
        index=False,
        encoding="utf-8-sig",
    )

    count_matrix = summary_df[
        [
            "sample",
            "source_gate_final_rows",
            "gate_and_nonARG_filtered_rows",
            "q005_pass_before_dedup",
            "q005_pass_after_dedup",
            "q005_removed_from_gate_final",
            "q005_retained_fraction_of_gate_final",
        ]
    ].copy()

    count_matrix_file = (
        OUTPUT_ROOT
        / "ARGScope_primary_150nt_fragment_gate099_q005_count_matrix.csv"
    )

    count_matrix.to_csv(
        count_matrix_file,
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 90)
    print("ALL DONE")
    print(
        f"Samples processed: "
        f"{len(summaries)}"
    )
    print(
        f"Summary: {all_summary_file}"
    )
    print(
        f"Count matrix: {count_matrix_file}"
    )
    print("=" * 90)


if __name__ == "__main__":
    main()
