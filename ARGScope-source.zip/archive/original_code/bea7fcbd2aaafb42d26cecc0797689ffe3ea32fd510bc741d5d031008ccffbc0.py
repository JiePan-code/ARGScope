# -*- coding: utf-8 -*-
"""
ARGScope real-data gate scan - LOCAL SUMMARY ONLY

功能：
1. 直接读取已经下载到本地的：
       *_DNA_model_818_predictions.csv.gz
2. 不重新跑 DNABERT-2
3. 不重新跑 DNA_model_818
4. 不生成逐 read 新结果
5. 不生成每个样品单独的结果文件夹
6. 只在结果根目录生成汇总 CSV

推荐目录结构：

DNA_model_818_realdata_predictions/
|
|-- summarize_ARGScope_gate_thresholds_LOCAL.py
|-- argscope_1_all_reads/
|   |-- *_DNA_model_818_predictions.csv.gz
|   `-- ...
|-- argscope_2_all_reads/
|   `-- ...
`-- argscope_3_all_reads/
    `-- ...

最终只输出：
    ALL_SAMPLES_binary_threshold_summary.csv
    ALL_SAMPLES_dual_gate_summary.csv
    ALL_SAMPLES_gate_summary.json

其中：
binary-only:
    ARG_probability >= T_binary

dual-gate:
    ARG_probability >= T_binary
    AND
    ARG_subtype_max_probability >= T_subtype
"""

from __future__ import annotations

import csv
import gzip
import json
import os
import time
from pathlib import Path

import numpy as np


# =============================================================================
# 1. PATH
# =============================================================================

HERE = Path(__file__).resolve().parent

# 最推荐：
# 把这个脚本直接放在 DNA_model_818_realdata_predictions 目录下
PRED_ROOT = HERE

# 如果脚本放在其他位置，则改成你的本地路径，例如：
# PRED_ROOT = Path(
#     r"E:\1. ARG模型对比\1. ARG真实数据\DNA_model_818_realdata_predictions"
# )

# None = 自动扫描所有 argscope_*_all_reads 文件夹
SAMPLES = None

# 如果只想跑 argscope_1：
# SAMPLES = ["argscope_1_all_reads"]


# =============================================================================
# 2. THRESHOLDS
# =============================================================================

BINARY_THRESHOLDS = np.asarray(
    [
        0.48,
        0.50,
        0.55,
        0.60,
        0.65,
        0.70,
        0.75,
        0.80,
        0.85,
        0.90,
        0.92,
        0.94,
        0.95,
        0.96,
        0.97,
        0.98,
        0.985,
        0.99,
        0.992,
        0.995,
        0.997,
        0.998,
        0.999,
        0.9995,
        0.9999,
        0.99995,
        0.99999,
        0.999995,
        0.999999,
    ],
    dtype=np.float64,
)

SUBTYPE_THRESHOLDS = np.asarray(
    [
        0.00,
        0.05,
        0.10,
        0.20,
        0.30,
        0.40,
        0.50,
        0.60,
        0.70,
        0.80,
        0.85,
        0.90,
        0.92,
        0.94,
        0.95,
        0.96,
        0.97,
        0.98,
        0.99,
        0.995,
        0.999,
    ],
    dtype=np.float64,
)

SCRIPT_VERSION = "2026-08-18-local-summary-only-v1"


# =============================================================================
# 3. HELPERS
# =============================================================================

def discover_samples(root: Path) -> list[str]:
    if SAMPLES is not None:
        result = []

        for sample in SAMPLES:
            sample_dir = root / sample

            if not sample_dir.is_dir():
                raise FileNotFoundError(
                    f"Sample folder not found:\n{sample_dir}"
                )

            result.append(sample)

        return result

    samples = sorted(
        path.name
        for path in root.glob("argscope_*_all_reads")
        if path.is_dir()
    )

    if not samples:
        raise FileNotFoundError(
            "No argscope_*_all_reads folder found.\n"
            f"PRED_ROOT = {root}"
        )

    return samples


def discover_prediction_files(sample_dir: Path) -> list[Path]:
    files = sorted(
        path
        for path in sample_dir.glob(
            "*_DNA_model_818_predictions.csv.gz"
        )
        if path.is_file()
    )

    if not files:
        raise FileNotFoundError(
            "No *_DNA_model_818_predictions.csv.gz found in:\n"
            f"{sample_dir}"
        )

    return files


def get_column_indices(path: Path) -> tuple[int, int]:
    with gzip.open(
        path,
        "rt",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.reader(handle)
        header = next(reader)

    required = [
        "ARG_probability",
        "ARG_subtype_max_probability",
    ]

    missing = [
        name
        for name in required
        if name not in header
    ]

    if missing:
        raise ValueError(
            f"Missing columns {missing} in {path}\n"
            f"Header = {header}"
        )

    return (
        header.index("ARG_probability"),
        header.index("ARG_subtype_max_probability"),
    )


def update_histogram(
    arg_values: np.ndarray,
    subtype_values: np.ndarray,
    histogram: np.ndarray,
) -> None:
    binary_level = np.searchsorted(
        BINARY_THRESHOLDS,
        arg_values,
        side="right",
    )

    subtype_level = np.searchsorted(
        SUBTYPE_THRESHOLDS,
        subtype_values,
        side="right",
    )

    n_subtype_levels = (
        len(SUBTYPE_THRESHOLDS)
        + 1
    )

    flat_index = (
        binary_level.astype(np.int64)
        * n_subtype_levels
        + subtype_level.astype(np.int64)
    )

    counts = np.bincount(
        flat_index,
        minlength=histogram.size,
    )

    histogram += counts.reshape(
        histogram.shape
    )


def scan_file(
    path: Path,
    histogram: np.ndarray,
    buffer_size: int = 250_000,
) -> int:
    arg_index, subtype_index = (
        get_column_indices(path)
    )

    arg_buffer = np.empty(
        buffer_size,
        dtype=np.float32,
    )

    subtype_buffer = np.empty(
        buffer_size,
        dtype=np.float32,
    )

    buffer_n = 0
    total_rows = 0

    def flush(n: int) -> None:
        if n <= 0:
            return

        arg_values = arg_buffer[:n]
        subtype_values = subtype_buffer[:n]

        if not np.isfinite(
            arg_values
        ).all():
            raise ValueError(
                f"NaN/Inf ARG probability: {path}"
            )

        if not np.isfinite(
            subtype_values
        ).all():
            raise ValueError(
                f"NaN/Inf subtype probability: {path}"
            )

        update_histogram(
            arg_values,
            subtype_values,
            histogram,
        )

    with gzip.open(
        path,
        "rt",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.reader(handle)

        next(reader)

        for row in reader:
            arg_buffer[
                buffer_n
            ] = float(
                row[arg_index]
            )

            subtype_buffer[
                buffer_n
            ] = float(
                row[subtype_index]
            )

            buffer_n += 1
            total_rows += 1

            if buffer_n == buffer_size:
                flush(
                    buffer_n
                )
                buffer_n = 0

        if buffer_n:
            flush(
                buffer_n
            )

    return total_rows


def cumulative_counts(
    histogram: np.ndarray,
) -> np.ndarray:
    return (
        histogram[::-1, ::-1]
        .cumsum(axis=0)
        .cumsum(axis=1)[::-1, ::-1]
    )


def write_csv(
    path: Path,
    rows: list[dict],
) -> None:
    if not rows:
        return

    fieldnames = list(
        rows[0].keys()
    )

    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(
            rows
        )

    os.replace(
        temp,
        path,
    )


def write_json(
    path: Path,
    payload: dict,
) -> None:
    temp = path.with_suffix(
        path.suffix + ".tmp"
    )

    with temp.open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            payload,
            handle,
            ensure_ascii=False,
            indent=2,
        )

    os.replace(
        temp,
        path,
    )


# =============================================================================
# 4. MAIN
# =============================================================================

def main() -> None:
    pred_root = (
        PRED_ROOT
        .expanduser()
        .resolve()
    )

    if not pred_root.is_dir():
        raise NotADirectoryError(
            f"PRED_ROOT not found:\n{pred_root}"
        )

    samples = discover_samples(
        pred_root
    )

    print("=" * 110)
    print("ARGScope local gate scan - SUMMARY ONLY")
    print("=" * 110)
    print(f"Prediction root : {pred_root}")
    print(f"Samples         : {', '.join(samples)}")
    print("GPU             : not required")
    print("=" * 110)

    sample_results = {}
    sample_total_reads = {}

    all_started = time.time()

    for sample in samples:
        sample_dir = (
            pred_root
            / sample
        )

        files = (
            discover_prediction_files(
                sample_dir
            )
        )

        histogram = np.zeros(
            (
                len(BINARY_THRESHOLDS)
                + 1,
                len(SUBTYPE_THRESHOLDS)
                + 1,
            ),
            dtype=np.int64,
        )

        total_reads = 0

        print()
        print("-" * 110)
        print(
            f"{sample}: "
            f"{len(files):,} prediction chunks"
        )
        print("-" * 110)

        for index, path in enumerate(
            files,
            start=1,
        ):
            started = time.time()

            rows = scan_file(
                path,
                histogram,
            )

            total_reads += rows

            print(
                f"[{index:03d}/{len(files):03d}] "
                f"{path.name} | "
                f"rows={rows:,} | "
                f"time={time.time()-started:.1f}s"
            )

        sample_results[
            sample
        ] = cumulative_counts(
            histogram
        )

        sample_total_reads[
            sample
        ] = total_reads

        print(
            f"Total reads: {total_reads:,}"
        )

    # =========================================================================
    # Binary threshold summary
    # =========================================================================

    binary_rows = []

    for b_index, binary_threshold in enumerate(
        BINARY_THRESHOLDS
    ):
        row = {
            "binary_threshold": float(
                binary_threshold
            )
        }

        for sample in samples:
            cumulative = (
                sample_results[
                    sample
                ]
            )

            # subtype threshold 0.00 -> index 1
            count = int(
                cumulative[
                    b_index + 1,
                    1,
                ]
            )

            total_reads = (
                sample_total_reads[
                    sample
                ]
            )

            row[
                f"{sample}_ARG_count"
            ] = count

            row[
                f"{sample}_ARG_fraction"
            ] = (
                count
                / total_reads
                if total_reads
                else 0.0
            )

        binary_rows.append(
            row
        )

    binary_output = (
        pred_root
        / "ALL_SAMPLES_binary_threshold_summary.csv"
    )

    write_csv(
        binary_output,
        binary_rows,
    )

    # =========================================================================
    # Dual gate summary
    # =========================================================================

    dual_rows = []

    for b_index, binary_threshold in enumerate(
        BINARY_THRESHOLDS
    ):
        for s_index, subtype_threshold in enumerate(
            SUBTYPE_THRESHOLDS
        ):
            row = {
                "binary_threshold": float(
                    binary_threshold
                ),
                "subtype_threshold": float(
                    subtype_threshold
                ),
            }

            for sample in samples:
                cumulative = (
                    sample_results[
                        sample
                    ]
                )

                count = int(
                    cumulative[
                        b_index + 1,
                        s_index + 1,
                    ]
                )

                total_reads = (
                    sample_total_reads[
                        sample
                    ]
                )

                row[
                    f"{sample}_ARG_count"
                ] = count

                row[
                    f"{sample}_ARG_fraction"
                ] = (
                    count
                    / total_reads
                    if total_reads
                    else 0.0
                )

            dual_rows.append(
                row
            )

    dual_output = (
        pred_root
        / "ALL_SAMPLES_dual_gate_summary.csv"
    )

    write_csv(
        dual_output,
        dual_rows,
    )

    # =========================================================================
    # Summary JSON
    # =========================================================================

    summary_output = (
        pred_root
        / "ALL_SAMPLES_gate_summary.json"
    )

    write_json(
        summary_output,
        {
            "script_version": SCRIPT_VERSION,
            "prediction_root": str(
                pred_root
            ),
            "samples": samples,
            "total_reads": sample_total_reads,
            "binary_thresholds": (
                BINARY_THRESHOLDS.tolist()
            ),
            "subtype_thresholds": (
                SUBTYPE_THRESHOLDS.tolist()
            ),
            "elapsed_minutes": round(
                (
                    time.time()
                    - all_started
                )
                / 60.0,
                4,
            ),
        },
    )

    print()
    print("=" * 110)
    print("COMPLETED")
    print("=" * 110)
    print(
        f"Binary summary : {binary_output}"
    )
    print(
        f"Dual summary   : {dual_output}"
    )
    print(
        f"JSON summary   : {summary_output}"
    )
    print("=" * 110)


if __name__ == "__main__":
    main()
