"""Independent export-level checks for the approved mapping and radar contract."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
from strict_type_names import map_name,key,self_test

ROOT=Path(__file__).resolve().parent
baseline=Path(sys.argv[1])
read=lambda p:pd.read_csv(p,keep_default_na=False)
labels=read(ROOT/'ARGScope_23_types.csv').Type.tolist()
self_test()
audit=read(ROOT/'Type_name_mapping_audit.csv')
for r in audit.itertuples():
    assert map_name(r.Binary_prediction,r.Raw_name,labels)==(r.Strict_mapped_Type,r.Rule)
assert set(audit.Mapping_policy)=={'strict_name_equivalence_v1'}
same=audit[audit.Binary_prediction.eq('ARG') & audit.Strict_mapped_Type.isin(labels)]
assert same.Rule.isin(['exact_or_format_only','explicit_abbreviation_or_spelling']).all()
single=audit[~audit.Raw_name.str.contains('[;:]',regex=True)]
single.groupby(['Modality','Model','Raw_name','Previous_mapped_Type','Strict_mapped_Type','Rule'],dropna=False)[['N','N_fixed23_truth','Changed_prediction']].sum().reset_index().to_csv(
    ROOT/'Type_name_single_category_correspondence.csv',index=False,encoding='utf-8-sig')
own_checks=0
for mod in ['Protein','DNA']:
    for name in ['01_Type_barplot_macro_five_metrics.csv','02_Type_overall_macro_weighted_micro.csv','03_Per_Type_fixed23_five_metrics.csv']:
        current=read(ROOT/mod/name); old=read(baseline/mod/name)
        pd.testing.assert_frame_equal(current[current.Model.eq('ARGScope')].reset_index(drop=True),
            old[old.Model.eq('ARGScope')].reset_index(drop=True),check_exact=False,rtol=0,atol=1e-13)
        own_checks+=1
    per=read(ROOT/mod/'03_Per_Type_fixed23_five_metrics.csv')
    removed=per[per.Model.eq('ARGNet')&per.Type.isin(['novobiocin','vancomycin','tetracenomycin_C'])]
    assert removed[['TP','Predicted_count','Precision','Recall','F1']].eq(0).all().all()
    before=read(baseline/mod/'01_Type_barplot_macro_five_metrics.csv').set_index(['Model','Completeness']).N
    now=read(ROOT/mod/'01_Type_barplot_macro_five_metrics.csv').set_index(['Model','Completeness']).N
    pd.testing.assert_series_equal(before,now)
radars=read(ROOT/'figures_Type_ARG_only/radar_values_source.csv')
assert len(radars)==40 and radars.Completeness.eq(100).all() and radars.Average.eq('macro').all()
for r in radars.itertuples():
    source=read(ROOT/r.Modality/'06_ARG_nonARG_macro_weighted_micro.csv')
    match=source[(source.Model==r.Model)&(source.Completeness==100)&(source.Average=='macro')].iloc[0]
    assert np.isclose(r.Value,match[r.Metric],rtol=0,atol=1e-13)
    assert r.N==match.N and r.Scope=='ARG_and_nonARG'
result={'Mapping_rows_verified':len(audit),'ARGScope_Type_exports_unchanged':own_checks,
    'ARGNet_three_forced_categories_no_longer_predicted':True,'All_Type_evaluation_populations_unchanged':True,
    'Radar_values_checked':len(radars),'Radar_completeness':100,'Radar_averaging':'macro',
    'All_unresolved_predictions_retained_as_errors':True}
(ROOT/'strict_name_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
