"""w/o Graph Prior: use train-only raw centroids, never GAT-refined prototypes."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from ablation_runtime import add_default_structure, data_root_from_launcher, guard_student_recursive_delete, load_base, raw_as_refined, reject_overwrite_argument, set_common_student_defaults, mark_saved_ablation

DATA = data_root_from_launcher(__file__)
m = load_base("05_dna_student.py", "dna_wo_graph_base")
set_common_student_defaults(m, DATA, "dna", "DNA_student_subtype2_newsplit_wo_graph")
raw = DATA / "Raw_subtype_prototypes_subtype2_newsplit" / "raw_ARG_subtype_prototypes_and_baseline.pt"
m.DEFAULT_REFINED_PT = raw
raw_as_refined(m, raw)
mark_saved_ablation(m, "w/o Graph Prior", "Mutual-KNN + residual GAT refinement; raw train-only centroids are used")
guard_student_recursive_delete(m, DATA, "DNA_student_subtype2_newsplit_wo_graph")
reject_overwrite_argument()
add_default_structure(DATA)
m.main()
