#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Recalculate fragment-level metrics for ARGScope Protein percent_60/70/80/90.

Input file in each condition:
    protein_fragment_test_predictions.csv

Expected layout (either layout is accepted):

A)
    protein_percent60_90_local_results/
    ├─ percent_60/protein_fragment_test_predictions.csv
    ├─ percent_70/protein_fragment_test_predictions.csv
    ├─ percent_80/protein_fragment_test_predictions.csv
    └─ percent_90/protein_fragment_test_predictions.csv
    └─ recalculate_percent60_90_fragment_metrics.py

or B)
    3.Protein_student_subtype2_newsplit/
    ├─ protein_percent60_90_local_results/
    │  ├─ percent_60/...
    │  ├─ percent_70/...
    │  ├─ percent_80/...
    │  └─ percent_90/...
    └─ recalculate_percent60_90_fragment_metrics.py

Output:
    protein_percent60_90_local_results/
    └─ recalculated_fragment_metrics_60_90/
       ├─ 00_ALL_overall_metrics.csv
       ├─ 01_ALL_ARG_nonARG_overall_metrics.csv
       ├─ 02_ALL_subtype_overall_metrics.csv
       ├─ 03_ALL_ARG_only_subtype_overall_metrics.csv
       ├─ 04_ALL_type_overall_metrics.csv
       ├─ 05_ALL_per_Type_metrics.csv
       ├─ 06_ALL_per_Subtype_metrics.csv
       ├─ 07_class_counts_by_condition.csv
       └─ percent_60/
          ├─ overall_metrics.csv
          ├─ ARG_nonARG_overall_metrics.csv
          ├─ subtype_overall_metrics.csv
          ├─ ARG_only_subtype_overall_metrics.csv
          ├─ type_overall_metrics.csv
          ├─ per_Type_metrics.csv
          └─ per_Subtype_metrics.csv

Definitions
-----------
1. ARG_nonARG:
   true_ARG vs predicted_ARG.

2. Subtype_end_to_end:
   true_subtype vs predicted_subtype on ALL fragments.
   nonARG is therefore included as one final subtype-level class.

3. ARG_only_subtype_final_prediction:
   Only rows whose true label is ARG are evaluated.
   The final predicted_subtype is used. If an ARG fragment is predicted as nonARG,
   that nonARG prediction is counted as a subtype error.

4. Type_end_to_end:
   true_type vs predicted_type on ALL fragments, including nonARG.

For all multiclass overall evaluations:
    ACC, MCC,
    micro Precision/Recall/F1,
    macro Precision/Recall/F1,
    weighted Precision/Recall/F1

Per-Type and per-Subtype tables use one-vs-rest calculations:
    ACC, Precision, Recall, Specificity, F1, MCC,
    support, predicted_count, TP, FP, FN, TN.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
)

CONDITIONS = ("percent_60", "percent_70", "percent_80", "percent_90")
INPUT_FILENAME = "protein_fragment_test_predictions.csv"
OUTPUT_FOLDERNAME = "recalculated_fragment_metrics_60_90"


def parse_args():
    script_dir = Path(__file__).resolve().parent

    p = argparse.ArgumentParser(
        description=(
            "Recalculate ARG/nonARG, subtype, Type and per-class metrics "
            "for Protein percent_60/70/80/90 fragment predictions."
        )
    )

    p.add_argument(
        "--results-root",
        type=Path,
        default=None,
        help=(
            "Folder containing percent_60/70/80/90. "
            "If omitted, the script auto-detects it."
        ),
    )

    p.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Output folder. Default: "
            "<results-root>/recalculated_fragment_metrics_60_90"
        ),
    )

    p.add_argument(
        "--conditions",
        nargs="+",
        default=list(CONDITIONS),
        choices=list(CONDITIONS),
    )

    p.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacing CSV files in the output folder.",
    )

    return p.parse_args()


def detect_results_root(script_dir: Path) -> Path:
    """
    Support placing the script either:
    1) inside protein_percent60_90_local_results, or
    2) one directory above it.
    """
    direct_ok = all(
        (script_dir / condition / INPUT_FILENAME).is_file()
        for condition in CONDITIONS
    )
    if direct_ok:
        return script_dir

    nested = script_dir / "protein_percent60_90_local_results"
    nested_ok = all(
        (nested / condition / INPUT_FILENAME).is_file()
        for condition in CONDITIONS
    )
    if nested_ok:
        return nested

    raise FileNotFoundError(
        "Could not auto-detect protein_percent60_90_local_results.\n"
        "Expected percent_60/70/80/90 folders containing "
        f"{INPUT_FILENAME}.\n"
        "Use --results-root to specify the folder explicitly."
    )


def normalize_labels(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip()


def validate_dataframe(df: pd.DataFrame, path: Path):
    required = [
        "condition",
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
        "true_ARG",
        "predicted_ARG",
    ]

    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(
            f"Missing required columns in {path}: {missing}\n"
            f"Available columns: {list(df.columns)}"
        )

    if len(df) == 0:
        raise ValueError(f"Empty prediction file: {path}")


def safe_mcc(y_true, y_pred) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    if len(y_true) == 0:
        return 0.0

    # sklearn MCC is defined for multiclass data as well.
    try:
        return float(matthews_corrcoef(y_true, y_pred))
    except Exception:
        return 0.0


def multiclass_overall_metrics(
    y_true,
    y_pred,
    condition: str,
    evaluation: str,
):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    row = {
        "condition": condition,
        "evaluation": evaluation,
        "n": int(len(y_true)),
        "true_class_count": int(len(np.unique(y_true))),
        "predicted_class_count": int(len(np.unique(y_pred))),
        "union_class_count": int(
            len(set(y_true.tolist()) | set(y_pred.tolist()))
        ),
        "ACC": float(accuracy_score(y_true, y_pred)),
        "MCC": safe_mcc(y_true, y_pred),
    }

    for average in ("micro", "macro", "weighted"):
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            average=average,
            zero_division=0,
        )

        prefix = average.capitalize()

        row[f"{prefix}_Precision"] = float(precision)
        row[f"{prefix}_Recall"] = float(recall)
        row[f"{prefix}_F1"] = float(f1)

    return row


def one_vs_rest_metrics(
    y_true,
    y_pred,
    class_names,
    condition: str,
    evaluation: str,
    class_column: str,
):
    y_true = np.asarray(y_true, dtype=object)
    y_pred = np.asarray(y_pred, dtype=object)

    n = len(y_true)
    rows = []

    for class_name in class_names:
        true_positive_mask = y_true == class_name
        pred_positive_mask = y_pred == class_name

        tp = int(np.sum(true_positive_mask & pred_positive_mask))
        fp = int(np.sum(~true_positive_mask & pred_positive_mask))
        fn = int(np.sum(true_positive_mask & ~pred_positive_mask))
        tn = int(n - tp - fp - fn)

        precision = (
            tp / (tp + fp)
            if (tp + fp) > 0
            else 0.0
        )

        recall = (
            tp / (tp + fn)
            if (tp + fn) > 0
            else 0.0
        )

        specificity = (
            tn / (tn + fp)
            if (tn + fp) > 0
            else 0.0
        )

        f1 = (
            2.0 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0.0
        )

        binary_true = true_positive_mask.astype(np.int64)
        binary_pred = pred_positive_mask.astype(np.int64)

        rows.append(
            {
                "condition": condition,
                "evaluation": evaluation,
                class_column: class_name,
                "ACC": (
                    (tp + tn) / n
                    if n > 0
                    else 0.0
                ),
                "Precision": precision,
                "Recall": recall,
                "Specificity": specificity,
                "F1": f1,
                "MCC": safe_mcc(binary_true, binary_pred),
                "support": int(tp + fn),
                "predicted_count": int(tp + fp),
                "TP": tp,
                "FP": fp,
                "FN": fn,
                "TN": tn,
                "total_samples": int(n),
            }
        )

    return rows


def ordered_class_names(true_values, predicted_values, nonarg_last=True):
    classes = sorted(
        set(true_values) | set(predicted_values),
        key=lambda x: str(x).lower(),
    )

    if nonarg_last:
        nonarg_matches = [
            value
            for value in classes
            if str(value).strip().lower() == "nonarg"
        ]

        if nonarg_matches:
            nonarg_value = nonarg_matches[0]
            classes = [
                value
                for value in classes
                if value != nonarg_value
            ]
            classes.append(nonarg_value)

    return classes


def save_csv(
    df: pd.DataFrame,
    path: Path,
    overwrite: bool,
):
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists() and not overwrite:
        raise FileExistsError(
            f"Output already exists: {path}\n"
            "Rerun with --overwrite if you want to replace existing results."
        )

    df.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )


def process_condition(
    condition: str,
    prediction_path: Path,
):
    df = pd.read_csv(prediction_path)
    validate_dataframe(df, prediction_path)

    # Standardize labels.
    for column in (
        "true_subtype",
        "predicted_subtype",
        "true_type",
        "predicted_type",
    ):
        df[column] = normalize_labels(df[column])

    df["true_ARG"] = pd.to_numeric(
        df["true_ARG"],
        errors="raise",
    ).astype(int)

    df["predicted_ARG"] = pd.to_numeric(
        df["predicted_ARG"],
        errors="raise",
    ).astype(int)

    observed_conditions = sorted(
        set(df["condition"].astype(str).str.strip())
    )

    if observed_conditions != [condition]:
        raise ValueError(
            f"{prediction_path} has unexpected condition values: "
            f"{observed_conditions}; expected only {condition}"
        )

    # -------------------------------------------------------------------------
    # Overall metrics
    # -------------------------------------------------------------------------

    binary_row = multiclass_overall_metrics(
        df["true_ARG"].to_numpy(),
        df["predicted_ARG"].to_numpy(),
        condition=condition,
        evaluation="ARG_nonARG",
    )

    subtype_row = multiclass_overall_metrics(
        df["true_subtype"].to_numpy(),
        df["predicted_subtype"].to_numpy(),
        condition=condition,
        evaluation="Subtype_end_to_end",
    )

    type_row = multiclass_overall_metrics(
        df["true_type"].to_numpy(),
        df["predicted_type"].to_numpy(),
        condition=condition,
        evaluation="Type_end_to_end",
    )

    # True-ARG-only subtype evaluation using the FINAL predicted subtype.
    # If predicted_subtype == nonARG, it remains a wrong subtype prediction.
    arg_only = df.loc[df["true_ARG"] == 1].copy()

    if len(arg_only) == 0:
        raise ValueError(
            f"No true ARG rows found in {prediction_path}"
        )

    arg_subtype_row = multiclass_overall_metrics(
        arg_only["true_subtype"].to_numpy(),
        arg_only["predicted_subtype"].to_numpy(),
        condition=condition,
        evaluation="ARG_only_subtype_final_prediction",
    )

    overall_rows = [
        binary_row,
        subtype_row,
        arg_subtype_row,
        type_row,
    ]

    # -------------------------------------------------------------------------
    # Per-Type one-vs-rest
    # -------------------------------------------------------------------------

    type_classes = ordered_class_names(
        df["true_type"].tolist(),
        df["predicted_type"].tolist(),
        nonarg_last=True,
    )

    per_type_rows = one_vs_rest_metrics(
        df["true_type"].to_numpy(),
        df["predicted_type"].to_numpy(),
        class_names=type_classes,
        condition=condition,
        evaluation="Type_one_vs_rest",
        class_column="Type",
    )

    # -------------------------------------------------------------------------
    # Per-Subtype one-vs-rest
    # -------------------------------------------------------------------------

    subtype_classes = ordered_class_names(
        df["true_subtype"].tolist(),
        df["predicted_subtype"].tolist(),
        nonarg_last=True,
    )

    per_subtype_rows = one_vs_rest_metrics(
        df["true_subtype"].to_numpy(),
        df["predicted_subtype"].to_numpy(),
        class_names=subtype_classes,
        condition=condition,
        evaluation="Subtype_one_vs_rest",
        class_column="Subtype",
    )

    # -------------------------------------------------------------------------
    # Class counts / QC
    # -------------------------------------------------------------------------

    count_row = {
        "condition": condition,
        "n_fragments": int(len(df)),
        "true_ARG_count": int((df["true_ARG"] == 1).sum()),
        "true_nonARG_count": int((df["true_ARG"] == 0).sum()),
        "predicted_ARG_count": int((df["predicted_ARG"] == 1).sum()),
        "predicted_nonARG_count": int((df["predicted_ARG"] == 0).sum()),
        "true_Type_count": int(df["true_type"].nunique()),
        "predicted_Type_count": int(df["predicted_type"].nunique()),
        "true_Subtype_count": int(df["true_subtype"].nunique()),
        "predicted_Subtype_count": int(df["predicted_subtype"].nunique()),
    }

    return {
        "overall_rows": overall_rows,
        "binary_row": binary_row,
        "subtype_row": subtype_row,
        "arg_subtype_row": arg_subtype_row,
        "type_row": type_row,
        "per_type_rows": per_type_rows,
        "per_subtype_rows": per_subtype_rows,
        "count_row": count_row,
    }


def main():
    args = parse_args()

    script_dir = Path(__file__).resolve().parent

    if args.results_root is None:
        results_root = detect_results_root(script_dir)
    else:
        results_root = args.results_root.expanduser().resolve()

    if args.output_dir is None:
        output_dir = results_root / OUTPUT_FOLDERNAME
    else:
        output_dir = args.output_dir.expanduser().resolve()

    print("=" * 110)
    print("ARGScope Protein percent_60/70/80/90 fragment metric recalculation")
    print("=" * 110)
    print(f"Results root : {results_root}")
    print(f"Output dir   : {output_dir}")
    print(f"Conditions   : {args.conditions}")
    print()

    all_overall_rows = []
    all_binary_rows = []
    all_subtype_rows = []
    all_arg_subtype_rows = []
    all_type_rows = []
    all_per_type_rows = []
    all_per_subtype_rows = []
    all_count_rows = []

    for condition in args.conditions:
        prediction_path = (
            results_root
            / condition
            / INPUT_FILENAME
        )

        if not prediction_path.is_file():
            raise FileNotFoundError(
                f"Prediction file not found:\n{prediction_path}"
            )

        print("-" * 110)
        print(f"Processing {condition}")
        print(f"Input: {prediction_path}")

        result = process_condition(
            condition,
            prediction_path,
        )

        condition_output = (
            output_dir
            / condition
        )

        overall_df = pd.DataFrame(
            result["overall_rows"]
        )

        binary_df = pd.DataFrame(
            [result["binary_row"]]
        )

        subtype_df = pd.DataFrame(
            [result["subtype_row"]]
        )

        arg_subtype_df = pd.DataFrame(
            [result["arg_subtype_row"]]
        )

        type_df = pd.DataFrame(
            [result["type_row"]]
        )

        per_type_df = pd.DataFrame(
            result["per_type_rows"]
        )

        per_subtype_df = pd.DataFrame(
            result["per_subtype_rows"]
        )

        save_csv(
            overall_df,
            condition_output / "overall_metrics.csv",
            args.overwrite,
        )

        save_csv(
            binary_df,
            condition_output / "ARG_nonARG_overall_metrics.csv",
            args.overwrite,
        )

        save_csv(
            subtype_df,
            condition_output / "subtype_overall_metrics.csv",
            args.overwrite,
        )

        save_csv(
            arg_subtype_df,
            condition_output / "ARG_only_subtype_overall_metrics.csv",
            args.overwrite,
        )

        save_csv(
            type_df,
            condition_output / "type_overall_metrics.csv",
            args.overwrite,
        )

        save_csv(
            per_type_df,
            condition_output / "per_Type_metrics.csv",
            args.overwrite,
        )

        save_csv(
            per_subtype_df,
            condition_output / "per_Subtype_metrics.csv",
            args.overwrite,
        )

        all_overall_rows.extend(
            result["overall_rows"]
        )
        all_binary_rows.append(
            result["binary_row"]
        )
        all_subtype_rows.append(
            result["subtype_row"]
        )
        all_arg_subtype_rows.append(
            result["arg_subtype_row"]
        )
        all_type_rows.append(
            result["type_row"]
        )
        all_per_type_rows.extend(
            result["per_type_rows"]
        )
        all_per_subtype_rows.extend(
            result["per_subtype_rows"]
        )
        all_count_rows.append(
            result["count_row"]
        )

        print(
            f"{condition} | "
            f"n={result['count_row']['n_fragments']:,} | "
            f"Subtype ACC={result['subtype_row']['ACC']:.6f} | "
            f"Type ACC={result['type_row']['ACC']:.6f} | "
            f"ARG/nonARG ACC={result['binary_row']['ACC']:.6f}"
        )

    # -------------------------------------------------------------------------
    # Combined 60-90 summary tables
    # -------------------------------------------------------------------------

    save_csv(
        pd.DataFrame(all_overall_rows),
        output_dir / "00_ALL_overall_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_binary_rows),
        output_dir / "01_ALL_ARG_nonARG_overall_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_subtype_rows),
        output_dir / "02_ALL_subtype_overall_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_arg_subtype_rows),
        output_dir / "03_ALL_ARG_only_subtype_overall_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_type_rows),
        output_dir / "04_ALL_type_overall_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_per_type_rows),
        output_dir / "05_ALL_per_Type_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_per_subtype_rows),
        output_dir / "06_ALL_per_Subtype_metrics.csv",
        args.overwrite,
    )

    save_csv(
        pd.DataFrame(all_count_rows),
        output_dir / "07_class_counts_by_condition.csv",
        args.overwrite,
    )

    print()
    print("=" * 110)
    print("FINISHED")
    print("=" * 110)
    print(f"Output folder: {output_dir}")
    print()
    print("Main files:")
    print("  00_ALL_overall_metrics.csv")
    print("  01_ALL_ARG_nonARG_overall_metrics.csv")
    print("  02_ALL_subtype_overall_metrics.csv")
    print("  03_ALL_ARG_only_subtype_overall_metrics.csv")
    print("  04_ALL_type_overall_metrics.csv")
    print("  05_ALL_per_Type_metrics.csv")
    print("  06_ALL_per_Subtype_metrics.csv")
    print("  07_class_counts_by_condition.csv")


if __name__ == "__main__":
    main()
