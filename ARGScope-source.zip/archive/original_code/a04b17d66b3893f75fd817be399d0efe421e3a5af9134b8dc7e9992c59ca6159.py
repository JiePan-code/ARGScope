import pandas as pd
import torch
import torch.nn as nn
import math

# ==========================================================
# 1 严格 Cross-Attention 模块
# ==========================================================

class StrictCrossAttention(nn.Module):
    """
    严格 Cross-Attention:
        Q = AA embedding
        K = NT embedding
        V = NT embedding
    """

    def __init__(self, dim_aa, dim_nt, d_model=512, n_heads=8):
        super().__init__()

        assert d_model % n_heads == 0, "d_model 必须能被 n_heads 整除"

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.q_proj = nn.Linear(dim_aa, d_model)
        self.k_proj = nn.Linear(dim_nt, d_model)
        self.v_proj = nn.Linear(dim_nt, d_model)

        self.out_proj = nn.Linear(d_model, d_model)
        self.layernorm = nn.LayerNorm(d_model)

    def forward(self, aa_feat, nt_feat):
        """
        aa_feat: [B, dim_aa]
        nt_feat: [B, dim_nt]
        返回:
            fused: [B, d_model]
            attn_weights: [B, n_heads]
        """
        B = aa_feat.size(0)

        Q = self.q_proj(aa_feat)
        K = self.k_proj(nt_feat)
        V = self.v_proj(nt_feat)

        Q = Q.view(B, self.n_heads, self.head_dim)
        K = K.view(B, self.n_heads, self.head_dim)
        V = V.view(B, self.n_heads, self.head_dim)

        scores = (Q * K).sum(-1) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(scores, dim=-1)

        context = attn_weights.unsqueeze(-1) * V
        context = context.reshape(B, self.d_model)

        fused = self.out_proj(context)
        fused = self.layernorm(fused + self.q_proj(aa_feat))

        return fused, attn_weights


# ==========================================================
# 2 文件路径
# ==========================================================

nt_file = "dna_60pct_5parts_embedding.txt"
aa_file = "protein_60pct_embed_1280.txt"
label_file = "1. 数据IDARG_nonARG_table_5x.csv"   # 改成你的label文件名
output_file = "1.all_fusion_embedding_512_with_label.csv"

# label文件列名，按你的实际情况修改
label_id_col = "id"
label_type_col = "Type"
label_subtype_col = "Subtype"


# ==========================================================
# 3 读取并对齐两个 TXT embedding 文件
# ==========================================================

# 默认按 tab 分隔读取 txt
nt_df = pd.read_csv(nt_file, delim_whitespace=True, header=None)
aa_df = pd.read_csv(aa_file, delim_whitespace=True, header=None)

id_col_nt = nt_df.columns[0]
id_col_aa = aa_df.columns[0]

nt_df[id_col_nt] = nt_df[id_col_nt].astype(str).str.strip()
aa_df[id_col_aa] = aa_df[id_col_aa].astype(str).str.strip()

nt_ids = nt_df[id_col_nt]
aa_ids = aa_df[id_col_aa]

common_ids = sorted(list(set(nt_ids) & set(aa_ids)))

print("NT 样本数:", len(nt_ids))
print("AA 样本数:", len(aa_ids))
print("交集样本数:", len(common_ids))

nt_aligned = (
    nt_df[nt_df[id_col_nt].isin(common_ids)]
    .set_index(id_col_nt)
    .loc[common_ids]
)

aa_aligned = (
    aa_df[aa_df[id_col_aa].isin(common_ids)]
    .set_index(id_col_aa)
    .loc[common_ids]
)

nt_feat = torch.tensor(nt_aligned.values, dtype=torch.float32)
aa_feat = torch.tensor(aa_aligned.values, dtype=torch.float32)

print("NT 特征形状:", nt_feat.shape)
print("AA 特征形状:", aa_feat.shape)


# ==========================================================
# 4 GPU 自动调用
# ==========================================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

nt_feat = nt_feat.to(device)
aa_feat = aa_feat.to(device)


# ==========================================================
# 5 初始化模型
# ==========================================================

dim_aa = aa_feat.shape[1]
dim_nt = nt_feat.shape[1]

model = StrictCrossAttention(
    dim_aa=dim_aa,
    dim_nt=dim_nt,
    d_model=512,
    n_heads=8
).to(device)

model.eval()


# ==========================================================
# 6 前向传播
# ==========================================================

with torch.no_grad():
    fused_feat, attn_weights = model(aa_feat, nt_feat)

print("融合特征形状:", fused_feat.shape)


# ==========================================================
# 7 保存融合特征
# ==========================================================

fusion_np = fused_feat.cpu().numpy()
feature_cols = [f"fusion_{i}" for i in range(fusion_np.shape[1])]

fusion_df = pd.DataFrame(fusion_np, columns=feature_cols)
fusion_df.insert(0, "id", common_ids)


# ==========================================================
# 8 读取 label，并合并 Type / Subtype
# ==========================================================

label_df = pd.read_csv(label_file)
label_df[label_id_col] = label_df[label_id_col].astype(str).str.strip()

required_cols = [label_id_col, label_type_col, label_subtype_col]
for col in required_cols:
    if col not in label_df.columns:
        raise ValueError(f"label 文件缺少列: {col}")

label_df = label_df[[label_id_col, label_type_col, label_subtype_col]].copy()
label_df.columns = ["id", "Type", "Subtype"]

final_df = fusion_df.merge(label_df, on="id", how="left")

# 调整列顺序：id, Type, Subtype, embedding...
final_df = final_df[["id", "Type", "Subtype"] + feature_cols]

matched_n = final_df["Type"].notna().sum()
unmatched_n = final_df["Type"].isna().sum()

print("匹配到标签的样本数:", matched_n)
print("未匹配到标签的样本数:", unmatched_n)


# ==========================================================
# 9 输出 CSV
# ==========================================================

final_df.to_csv(output_file, index=False)

print("已保存融合特征到:", output_file)