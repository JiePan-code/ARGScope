# -*- coding: utf-8 -*-
"""
Draw DeepARG vs STRICT BLASTN Venn diagrams for 9 real metagenomic samples.

Put this script directly under:

E:\1. ARG模型对比\1. ARG真实数据\真实数据V3_read_based_processed\
ARGScope_150nt_无diamond\

Expected directory layout:

ARGScope_150nt_无diamond/
├── draw_DeepARG_vs_STRICT_BLAST_venn.py
├── DeepARG_Fastq结果/
│   ├── argbert_1.clean.deeparg.mapping.ARG
│   ├── argbert_2.clean.deeparg.mapping.ARG
│   ├── argbert_3.clean.deeparg.mapping.ARG
│   ├── argscope_1.clean.deeparg.mapping.ARG
│   └── ...
└── BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt/
    ├── argbert_1/
    │   ├── argbert_1_strict_besthit.tsv
    │   ├── argbert_1_strict_all_hits.tsv
    │   └── argbert_1_strict_subject_counts.csv
    ├── argbert_2/
    └── ...

Comparison unit:
    read ID

DeepARG:
    use unique "read_id" from *.clean.deeparg.mapping.ARG

Strict BLASTN:
    prefer *_strict_besthit.tsv
    use unique "qseqid"

Outputs:
    DeepARG_STRICT_BLAST_Venn_results/
        argbert_1_DeepARG_vs_STRICT_BLAST_venn.png
        ...
        argscope_6_DeepARG_vs_STRICT_BLAST_venn.png
        ALL_9_SAMPLES_DeepARG_vs_STRICT_BLAST_venn.png
        DeepARG_STRICT_BLAST_Venn_summary.csv
        intersection_ids/
            argbert_1_intersection_read_ids.csv
            ...
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

import pandas as pd
import matplotlib.pyplot as plt

try:
    from matplotlib_venn import venn2
except ImportError as exc:
    raise ImportError(
        "matplotlib-venn is required.\n"
        "Install it in your current Python environment with:\n"
        "pip install matplotlib-venn"
    ) from exc


# =============================================================================
# 1. PATHS
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent

DEEPARG_ROOT = ROOT_DIR / "DeepARG_Fastq结果"

BLAST_ROOT = (
    ROOT_DIR
    / "BLASTN_strict_E1e-7_ID80_QCOV75_ALN75nt"
)

OUT_DIR = (
    ROOT_DIR
    / "DeepARG_STRICT_BLAST_Venn_results"
)
OUT_DIR.mkdir(parents=True, exist_ok=True)

ID_OUT_DIR = OUT_DIR / "intersection_ids"
ID_OUT_DIR.mkdir(parents=True, exist_ok=True)

DPI = 600


# =============================================================================
# 2. SAMPLES
# =============================================================================

SAMPLES = [
    "argbert_1",
    "argbert_2",
    "argbert_3",
    "argscope_1",
    "argscope_2",
    "argscope_3",
    "argscope_4",
    "argscope_5",
    "argscope_6",
]


# =============================================================================
# 3. HELPERS
# =============================================================================

def normalize_ids(series: pd.Series) -> set[str]:
    values = (
        series.astype(str)
        .str.strip()
    )

    values = values[
        values.ne("")
        & values.ne("nan")
        & values.ne("None")
    ]

    return set(values.tolist())


def find_deeparg_file(sample: str) -> Path:
    """
    Find:
        sample.clean.deeparg.mapping.ARG

    Also tolerates copies such as:
        sample.clean.deeparg.mapping(1).ARG
    """

    exact = (
        DEEPARG_ROOT
        / f"{sample}.clean.deeparg.mapping.ARG"
    )

    if exact.exists():
        return exact

    candidates = sorted(
        DEEPARG_ROOT.glob(
            f"{sample}.clean.deeparg.mapping*.ARG"
        )
    )

    if len(candidates) == 1:
        return candidates[0]

    if not candidates:
        raise FileNotFoundError(
            f"No DeepARG .ARG file found for {sample} under:\n"
            f"{DEEPARG_ROOT}"
        )

    raise RuntimeError(
        f"Multiple DeepARG files found for {sample}:\n"
        + "\n".join(str(p) for p in candidates)
    )


def read_deeparg_ids(path: Path) -> set[str]:
    """
    DeepARG .ARG has a tab-delimited header including read_id.
    """

    header = pd.read_csv(
        path,
        sep="\t",
        nrows=0,
    )

    if "read_id" not in header.columns:
        raise ValueError(
            f"'read_id' column not found in DeepARG file:\n{path}\n"
            f"Available columns: {header.columns.tolist()}"
        )

    df = pd.read_csv(
        path,
        sep="\t",
        usecols=["read_id"],
        dtype={"read_id": str},
        low_memory=False,
    )

    return normalize_ids(
        df["read_id"]
    )


def find_strict_blast_file(
    sample: str,
) -> Tuple[Path, str]:
    """
    Prefer strict_besthit.tsv because it already has one row per
    strict-BLAST-positive read.

    If besthit is missing, fall back to strict_all_hits.tsv and deduplicate
    qseqid in memory.
    """

    sample_dir = (
        BLAST_ROOT
        / sample
    )

    if not sample_dir.is_dir():
        raise FileNotFoundError(
            f"Strict BLAST sample folder not found:\n"
            f"{sample_dir}"
        )

    besthit = (
        sample_dir
        / f"{sample}_strict_besthit.tsv"
    )

    if besthit.exists():
        return besthit, "strict_besthit"

    all_hits = (
        sample_dir
        / f"{sample}_strict_all_hits.tsv"
    )

    if all_hits.exists():
        return all_hits, "strict_all_hits"

    best_candidates = sorted(
        sample_dir.glob(
            "*_strict_besthit.tsv"
        )
    )

    if len(best_candidates) == 1:
        return (
            best_candidates[0],
            "strict_besthit",
        )

    all_candidates = sorted(
        sample_dir.glob(
            "*_strict_all_hits.tsv"
        )
    )

    if len(all_candidates) == 1:
        return (
            all_candidates[0],
            "strict_all_hits",
        )

    raise FileNotFoundError(
        f"No strict_besthit.tsv or strict_all_hits.tsv found under:\n"
        f"{sample_dir}"
    )


def read_strict_blast_ids(
    path: Path,
) -> set[str]:
    """
    Strict BLAST TSV has a header with qseqid.
    """

    df = pd.read_csv(
        path,
        sep="\t",
        usecols=["qseqid"],
        dtype={"qseqid": str},
        low_memory=False,
    )

    return normalize_ids(
        df["qseqid"]
    )


def save_ids(
    ids: set[str],
    output_file: Path,
) -> None:

    pd.DataFrame({
        "read_id": sorted(ids)
    }).to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig",
    )


def calculate_stats(
    deeparg_ids: set[str],
    blast_ids: set[str],
    sample: str,
    deep_file: Path,
    blast_file: Path,
    blast_source: str,
) -> Dict[str, object]:

    deep_only = (
        deeparg_ids
        - blast_ids
    )

    blast_only = (
        blast_ids
        - deeparg_ids
    )

    intersection = (
        deeparg_ids
        & blast_ids
    )

    union = (
        deeparg_ids
        | blast_ids
    )

    n_deep = len(
        deeparg_ids
    )

    n_blast = len(
        blast_ids
    )

    n_intersection = len(
        intersection
    )

    return {
        "sample": sample,
        "DeepARG_count": n_deep,
        "STRICT_BLAST_count": n_blast,
        "DeepARG_only": len(
            deep_only
        ),
        "STRICT_BLAST_only": len(
            blast_only
        ),
        "Intersection": n_intersection,
        "Intersection_pct_of_DeepARG": (
            100.0
            * n_intersection
            / n_deep
            if n_deep
            else 0.0
        ),
        "Intersection_pct_of_STRICT_BLAST": (
            100.0
            * n_intersection
            / n_blast
            if n_blast
            else 0.0
        ),
        "Jaccard_percent": (
            100.0
            * n_intersection
            / len(union)
            if union
            else 0.0
        ),
        "DeepARG_file": str(
            deep_file
        ),
        "BLAST_file": str(
            blast_file
        ),
        "BLAST_source": blast_source,
        "_DeepARG_only_set": deep_only,
        "_BLAST_only_set": blast_only,
        "_intersection_set": intersection,
    }


# =============================================================================
# 4. DRAW ONE VENN
# =============================================================================

def draw_one_venn(
    stats: Dict[str, object],
    output_file: Path,
) -> None:

    deep_only = int(
        stats["DeepARG_only"]
    )

    blast_only = int(
        stats["STRICT_BLAST_only"]
    )

    intersection = int(
        stats["Intersection"]
    )

    fig, ax = plt.subplots(
        figsize=(7.3, 6.3)
    )

    venn = venn2(
        subsets=(
            deep_only,
            blast_only,
            intersection,
        ),
        set_labels=(
            "DeepARG",
            "Strict BLASTN",
        ),
        ax=ax,
    )

    values = {
        "10": deep_only,
        "01": blast_only,
        "11": intersection,
    }

    for region_id, value in values.items():

        label = venn.get_label_by_id(
            region_id
        )

        if label is not None:
            label.set_text(
                f"{value:,}"
            )
            label.set_fontsize(
                12
            )
            label.set_fontweight(
                "bold"
            )

    for label_id in [
        "A",
        "B",
    ]:

        label = venn.get_label_by_id(
            label_id
        )

        if label is not None:
            label.set_fontsize(
                13
            )

    sample_label = str(
        stats["sample"]
    ).replace(
        "_",
        "-",
    )

    ax.set_title(
        f"{sample_label}\n"
        f"DeepARG ∩ Strict BLASTN = "
        f"{intersection:,} reads",
        fontsize=14,
        pad=14,
    )

    ax.text(
        0.5,
        -0.08,
        (
            f"Intersection / DeepARG = "
            f"{float(stats['Intersection_pct_of_DeepARG']):.2f}%"
            f"    |    "
            f"Intersection / Strict BLASTN = "
            f"{float(stats['Intersection_pct_of_STRICT_BLAST']):.2f}%"
        ),
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=10,
    )

    fig.tight_layout()

    fig.savefig(
        output_file,
        dpi=DPI,
        bbox_inches="tight",
    )

    fig.savefig(
        output_file.with_suffix(
            ".pdf"
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


# =============================================================================
# 5. MAIN
# =============================================================================

def main() -> None:

    print("=" * 100)
    print(
        "DeepARG vs STRICT BLASTN Venn analysis"
    )
    print("=" * 100)

    print(
        f"DeepARG root : {DEEPARG_ROOT}"
    )

    print(
        f"Strict BLAST : {BLAST_ROOT}"
    )

    print(
        f"Output       : {OUT_DIR}"
    )

    print()

    if not DEEPARG_ROOT.is_dir():
        raise FileNotFoundError(
            f"DeepARG folder not found:\n"
            f"{DEEPARG_ROOT}"
        )

    if not BLAST_ROOT.is_dir():
        raise FileNotFoundError(
            f"Strict BLAST folder not found:\n"
            f"{BLAST_ROOT}"
        )

    summary_rows = []

    # Add sample prefix before pooling to prevent same read IDs from different
    # samples being treated as one observation.
    pooled_deeparg = set()
    pooled_blast = set()

    for sample in SAMPLES:

        print("-" * 100)
        print(
            f"Processing: {sample}"
        )

        deep_file = find_deeparg_file(
            sample
        )

        blast_file, blast_source = (
            find_strict_blast_file(
                sample
            )
        )

        deeparg_ids = read_deeparg_ids(
            deep_file
        )

        blast_ids = read_strict_blast_ids(
            blast_file
        )

        stats = calculate_stats(
            deeparg_ids=deeparg_ids,
            blast_ids=blast_ids,
            sample=sample,
            deep_file=deep_file,
            blast_file=blast_file,
            blast_source=blast_source,
        )

        output_file = (
            OUT_DIR
            / f"{sample}_DeepARG_vs_STRICT_BLAST_venn.png"
        )

        draw_one_venn(
            stats=stats,
            output_file=output_file,
        )

        intersection_ids = stats[
            "_intersection_set"
        ]

        save_ids(
            intersection_ids,
            ID_OUT_DIR
            / f"{sample}_intersection_read_ids.csv",
        )

        summary_rows.append({
            key: value
            for key, value
            in stats.items()
            if not key.startswith("_")
        })

        pooled_deeparg.update(
            f"{sample}::{read_id}"
            for read_id in deeparg_ids
        )

        pooled_blast.update(
            f"{sample}::{read_id}"
            for read_id in blast_ids
        )

        print(
            f"DeepARG={stats['DeepARG_count']:,} | "
            f"Strict BLASTN={stats['STRICT_BLAST_count']:,} | "
            f"Intersection={stats['Intersection']:,}"
        )

        print(
            f"Intersection / DeepARG="
            f"{stats['Intersection_pct_of_DeepARG']:.4f}% | "
            f"Intersection / Strict BLASTN="
            f"{stats['Intersection_pct_of_STRICT_BLAST']:.4f}%"
        )

        print(
            f"DeepARG file: {deep_file.name}"
        )

        print(
            f"BLAST source: {blast_source}"
        )

    # -------------------------------------------------------------------------
    # Pooled all-nine-sample Venn
    # -------------------------------------------------------------------------

    pooled_stats = calculate_stats(
        deeparg_ids=pooled_deeparg,
        blast_ids=pooled_blast,
        sample="ALL_9_SAMPLES",
        deep_file=DEEPARG_ROOT,
        blast_file=BLAST_ROOT,
        blast_source="pooled_strict_besthit",
    )

    pooled_file = (
        OUT_DIR
        / "ALL_9_SAMPLES_DeepARG_vs_STRICT_BLAST_venn.png"
    )

    draw_one_venn(
        stats=pooled_stats,
        output_file=pooled_file,
    )

    summary_rows.append({
        key: value
        for key, value
        in pooled_stats.items()
        if not key.startswith("_")
    })

    # -------------------------------------------------------------------------
    # Summary
    # -------------------------------------------------------------------------

    summary_df = pd.DataFrame(
        summary_rows
    )

    summary_file = (
        OUT_DIR
        / "DeepARG_STRICT_BLAST_Venn_summary.csv"
    )

    summary_df.to_csv(
        summary_file,
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 100)
    print("DONE")
    print(
        f"Summary CSV : {summary_file}"
    )
    print(
        f"Pooled Venn : {pooled_file}"
    )
    print("=" * 100)


if __name__ == "__main__":
    main()
